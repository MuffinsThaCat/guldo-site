"""Declaration of a Coppersmith-regime domain: factoring N = p q (p, q 128-bit primes) when the HIGH bits of p are known.

A solver receives (N, hi, b): hi = p >> b, so the low b bits of p are unknown. It returns any nontrivial factor of N. size = b. The reference
tries all 2^b completions of hi. Coppersmith's small-root method (lattice reduction) recovers p in polynomial time whenever b is below about half
the bit length of p; here b <= 30 of 128. Because p and q are 128-bit, factoring N without the hint is out of reach, so the hint is what a
solver must use.
"""
import hashlib
import hmac
import random

import instances  # the project's Miller-Rabin test

NAME = "copper"
VERSION = "copper-v1"           # bump whenever derive() changes
SIZE_RANGE = (20, 30)
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
DOC = "solve(N, hi, b): N = p*q with p >> b == hi. Return an integer d with 1 < d < N and N % d == 0. Return None for no answer."
REFERENCE_NOTE = ("The reference tries every completion of the known high bits (2^b). Coppersmith's method (a small lattice) is known to solve this in polynomial "
                  "time while b is below about half of p's bit length; no claim is made about which is fastest. Scope: 128-bit primes with b <= 30 unknown "
                  "bits, NOT evidence about attacks on RSA at real parameters, and a certificate here must not be read as one.")
BITS = 128


def _prime(rng, bits):
    while True:
        c = rng.getrandbits(bits) | (1 << (bits - 1)) | 1
        if instances._is_prime(c):
            return c


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"copper-v1:{size}:{idx}".encode(), hashlib.sha256).digest())
    while True:
        p, q = _prime(rng, BITS), _prime(rng, BITS)
        if p != q:
            break
    return {"args": [p * q, p >> size, size], "planted": p}


def verify(inst: dict, ans) -> bool:
    N = inst["args"][0]
    return isinstance(ans, int) and not isinstance(ans, bool) and 1 < ans < N and N % ans == 0
