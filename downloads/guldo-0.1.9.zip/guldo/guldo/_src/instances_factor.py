"""Second domain: integer factoring. Commit-reveal semiprimes N = p*q with an exact, trivial answer check.

Same contract as the lattice families (see families.py): an instance is a pure function of (master seed, size, index), the
solver sees only `args` (here [N]), and the judge verifies with exact arithmetic. An answer is ANY nontrivial divisor d of N
(1 < d < N), so a solver is not required to return the planted factor; the check is one modulo operation.

size = bits of N. p and q are random primes of about size/2 bits each, so the smaller factor is ~size/2 bits and Pollard-rho
style algorithms need ~2^(size/4) steps: cost grows smoothly and, because rho's run time is geometric-like, per-instance
difficulty is heavy-tailed, which is exactly the regime the difficulty-stratified claim is built for.
"""
import hashlib
import hmac
import random

import instances  # reuse the Miller-Rabin primality test


def _prime(rng, bits):
    while True:
        c = rng.getrandbits(bits) | (1 << (bits - 1)) | 1
        if instances._is_prime(c):
            return c


def derive(master: bytes, size: int, idx: int) -> dict:
    if size < 16:
        raise ValueError("size (bits of N) must be at least 16")
    rng = random.Random(hmac.new(master, f"factor-v1:{size}:{idx}".encode(), hashlib.sha256).digest())
    pb = size // 2
    while True:
        p, q = _prime(rng, pb), _prime(rng, size - pb)
        if p != q:
            break
    n = p * q
    return {"id": f"{size}:{idx}", "dim": size, "idx": idx, "args": [n], "n": n, "planted": sorted([p, q])}


def verify(inst: dict, ans) -> bool:
    n = inst["n"]
    return isinstance(ans, int) and not isinstance(ans, bool) and 1 < ans < n and n % ans == 0
