"""A reference VENDOR for the guldo tool service: what the party being evaluated writes. Python standard library only; it imports nothing from this project, which is the point: a vendor needs
three HTTP calls (or an MCP-capable agent product), not our code, and keeps its model, prompts and loop to itself.

  TspClient(url, arm_token)       start sessions, make calls, submit; every response's RECEIPT is kept (write them out with save_receipts and check the published transcript with
                                  `agent_service.py check-receipts`)
  run_arm(client, solver)         loop over the arm's tasks until the service says it is done; `solver(session)` is the vendor's agent
  llm_solver(base, model, ...)    a real agent: an OpenAI-compatible chat model (Ollama, vLLM, a hosted API) in a plain tool loop, written WITHOUT this project's harness

  python3 agent_vendor_example.py --url http://127.0.0.1:8790 --token ARMTOKEN --model qwen2.5:3b --llm-base http://127.0.0.1:11434/v1 --receipts my_receipts.jsonl
  GULDO_TSP_URL=... GULDO_TSP_SESSION=... python3 agent_vendor_example.py --model ...      (the `--exec` mode of the service: one task per process)

The solver here is deliberately ordinary. It is an example of the protocol, not an agent worth benchmarking.
"""
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request


class TspError(Exception):
    pass


class Ended(TspError):
    """The service refused a call because the trial is over (a cap, the deadline, or already submitted)."""


def _context(cafile):
    """An SSL context that trusts ONLY `cafile` (pin the evaluator's certificate, or its CA): a self-signed service is the common case, and the system trust store is the wrong default for it."""
    import ssl
    ctx = ssl.create_default_context(cafile=cafile)
    return ctx


def _request(url, body, token, timeout, method="POST", headers=None, cafile=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    h = {"Content-Type": "application/json"}
    if token:
        h["Authorization"] = "Bearer " + token
    h.update(headers or {})
    req = urllib.request.Request(url, data=data if method != "GET" else None, method=method, headers=h)
    ctx = _context(cafile) if cafile and url.startswith("https:") else None
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            raw = r.read()
            return r.status, (json.loads(raw.decode("utf-8")) if raw else {}), dict(r.headers)
    except urllib.error.HTTPError as e:
        raw = e.read()
        e.close()
        try:
            return e.code, json.loads(raw.decode("utf-8")), dict(e.headers)
        except ValueError:
            return e.code, {"error": raw[:200].decode("utf-8", "replace")}, dict(e.headers)


class Session(object):
    def __init__(self, client, data):
        self.client, self.token, self.sid = client, data["session"], data["sid"]
        self.task, self.tools, self.limits = data["task"], data["tools"], data["limits"]
        self.ended = False
        client.receipts.append(data["receipt"])

    def call(self, name, args=None):
        """Call a tool; returns its content (a string). Raises Ended once the trial is over."""
        code, out, _ = _request(self.client.url + "/v1/call", {"name": name, "args": args or {}}, self.token, self.client.timeout, cafile=self.client.cafile)
        if code == 409:
            self.ended = True
            if out.get("receipt"):
                self.client.receipts.append(out["receipt"])
            raise Ended(out.get("reason", "ended"))
        if code != 200:
            raise TspError("HTTP %d: %s" % (code, out.get("error")))
        self.client.receipts.append(out["receipt"])
        self.ended = out["ended"]
        return out["content"]

    def submit(self, answer, usage=None):
        args = {"answer": answer}
        if usage:
            args["usage"] = usage                    # optional and UNVERIFIED: what you claim the agent used; recorded as a claim
        return self.call("submit", args)

    def finish(self):
        code, out, _ = _request(self.client.url + "/v1/finish", {}, self.token, self.client.timeout, cafile=self.client.cafile)
        self.ended = True
        return out


class TspClient(object):
    def __init__(self, url, arm_token, timeout=120, cafile=None):
        self.url, self.arm_token, self.timeout, self.cafile = url.rstrip("/"), arm_token, timeout, cafile
        self.receipts = []

    def info(self):
        return _request(self.url + "/v1/info", None, None, self.timeout, method="GET", cafile=self.cafile)[1]

    def next_session(self, wait=60):
        """The next task, or None when the arm is finished. Waits (up to `wait` seconds) while the service is busy with another session of this arm."""
        end = time.monotonic() + wait
        while True:
            code, out, _ = _request(self.url + "/v1/session", {}, self.arm_token, self.timeout, cafile=self.cafile)
            if code == 200:
                return None if out.get("done") else Session(self, out)
            if code == 429 and time.monotonic() < end:
                time.sleep(float(out.get("retry_after", 1)))
                continue
            raise TspError("HTTP %d: %s" % (code, out.get("error")))

    def attach(self, session_token):
        """Wrap a session the service already started for us (the --exec mode hands the process its session token)."""
        code, out, _ = _request(self.url + "/v1/task", {}, session_token, self.timeout, cafile=self.cafile)
        if code != 200:
            raise TspError("HTTP %d: %s" % (code, out.get("error")))
        out["session"] = session_token
        return Session(self, out)

    def save_receipts(self, path):
        with open(path, "a", encoding="utf-8") as f:
            for r in self.receipts:
                f.write(json.dumps(r, sort_keys=True) + "\n")
        self.receipts = []


def run_arm(client, solver, limit=None):
    n = 0
    while limit is None or n < limit:
        s = client.next_session()
        if s is None:
            return n
        try:
            solver(s)
        except Ended:
            pass
        if not s.ended:
            s.finish()                                # a task the agent gave up on, or failed on, still ends cleanly
        n += 1
    return n


# ---- a real agent: an OpenAI-compatible chat model in a plain loop ---------------------------------------------------------------------------------------

def _openai_tools(tools):
    return [{"type": "function", "function": {"name": t["name"], "description": t.get("description", ""), "parameters": t.get("input_schema") or {"type": "object"}}} for t in tools]


def llm_solver(base, model, api_key=None, max_turns=24, timeout=300, system=None):
    """An agent in about forty lines: chat with `model`, execute its tool calls against the service, stop on submit. Nothing here is the evaluator's code; a vendor would put its own agent here."""
    sys_prompt = system or ("You are solving one task. Use the tools to find what you need, then call `submit` with the final answer. Be efficient and exact: a wrong answer scores nothing.")

    def solve(session):
        msgs = [{"role": "system", "content": sys_prompt}, {"role": "user", "content": session.task}]
        tools = _openai_tools(session.tools)
        nudged = 0
        for _ in range(max_turns):
            body = {"model": model, "messages": msgs, "tools": tools, "temperature": 0}
            headers = {"Authorization": "Bearer " + api_key} if api_key else {}
            code, out, _ = _request(base.rstrip("/") + "/chat/completions", body, None, timeout, headers=headers)
            if code != 200 or not out.get("choices"):
                raise TspError("the model endpoint answered HTTP %d" % code)
            m = out["choices"][0]["message"]
            calls = m.get("tool_calls") or []
            msgs.append({"role": "assistant", "content": m.get("content") or "", **({"tool_calls": calls} if calls else {})})
            if not calls:
                if nudged >= 2:
                    return
                nudged += 1
                msgs.append({"role": "user", "content": "You did not call a tool. If you have the final answer, call `submit` with it now; otherwise call the tool you need next."})
                continue
            for c in calls:
                fn = c.get("function", {})
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                    if not isinstance(args, dict):
                        raise ValueError
                except ValueError:
                    msgs.append({"role": "tool", "tool_call_id": c.get("id", ""), "content": "error: the arguments were not a JSON object"})
                    continue
                if fn.get("name") == "submit":
                    session.submit(args.get("answer"), usage={k: v for k, v in (out.get("usage") or {}).items() if isinstance(v, (int, float))})
                    return
                msgs.append({"role": "tool", "tool_call_id": c.get("id", ""), "content": session.call(fn.get("name", ""), args)})
    return solve


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default=os.environ.get("GULDO_TSP_URL"))
    ap.add_argument("--token", default=os.environ.get("GULDO_TSP_TOKEN"), help="the ARM token (pull mode)")
    ap.add_argument("--model", required=True)
    ap.add_argument("--llm-base", default="http://127.0.0.1:11434/v1")
    ap.add_argument("--receipts")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--cafile", default=os.environ.get("GULDO_TSP_CAFILE"), help="trust ONLY this certificate/CA for an https:// service (pin the evaluator's certificate)")
    a = ap.parse_args(argv)
    if not a.url:
        print("--url (or GULDO_TSP_URL) is required", file=sys.stderr)
        return 2
    client = TspClient(a.url, a.token, cafile=a.cafile)
    solver = llm_solver(a.llm_base, a.model, os.environ.get("LLM_API_KEY"))
    try:
        if os.environ.get("GULDO_TSP_SESSION"):                         # --exec mode: one task, handed to us
            s = client.attach(os.environ["GULDO_TSP_SESSION"])
            try:
                solver(s)
            except Ended:
                pass
            if not s.ended:
                s.finish()
            n = 1
        else:
            n = run_arm(client, solver, a.limit)
    finally:
        if a.receipts:
            client.save_receipts(a.receipts)
    print("done: %d task(s)" % n)
    return 0


if __name__ == "__main__":
    sys.exit(main())
