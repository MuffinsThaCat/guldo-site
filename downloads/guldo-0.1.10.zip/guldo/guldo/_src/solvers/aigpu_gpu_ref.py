"""aigpu on a GPU, REFERENCE: float32 on the device, ONE HEAD AT A TIME: for each head the scores Q K^T are formed (n x n, materialised), the softmax is its own kernel, then P V; the heads are concatenated
and read out. UNRUN on CUDA: written and run only on the development machine's Apple GPU (MPS) and CPU. The instance is regenerated on the device inside solve(): a fixed cost shared by every solver
(aigpu_gpu_noop.py pays only that)."""
import math
import os

import torch

CLASSES = 16


def _device():
    """The device the solver runs on: SVP_TORCH_DEVICE if set (cuda, mps or cpu), else CUDA, else Apple MPS, else the CPU."""
    name = os.environ.get("SVP_TORCH_DEVICE")
    if name:
        return torch.device(name)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


DEV = _device()


def _signed(x):
    return x - (1 << 64) if x >= (1 << 63) else x


def _srl(z, k):
    """Logical right shift of an int64 tensor (torch's >> is arithmetic)."""
    return (z >> k) & ((1 << (64 - k)) - 1)


def _uniform(seed, start, n):
    """n floats in [-1, 1) from the project's SplitMix64 stream, generated ON THE DEVICE with int64 arithmetic (which wraps mod 2^64, exactly as the judge's numpy uint64 does). The value is the stream's top 24
    bits, so it agrees with the judge's float64 value to within 2^-23: far below fp16, and about the rounding of a float32."""
    z = (torch.arange(start, start + n, dtype=torch.int64, device=DEV) + 1) * _signed(0x9E3779B97F4A7C15) + _signed(seed)
    z = (z ^ _srl(z, 30)) * _signed(0xBF58476D1CE4E5B9)
    z = (z ^ _srl(z, 27)) * _signed(0x94D049BB133111EB)
    z = z ^ _srl(z, 31)
    return _srl(z, 40).to(torch.float32) * (2.0 ** -23) - 1.0


def inputs(seed, n, H, dk):
    """Regenerate the instance on the device (the judge's stream) as float32."""
    m, d = H * n * dk, H * dk
    Q = (_uniform(seed, 0, m) * 3.0).reshape(H, n, dk)
    K = _uniform(seed, m, m).reshape(H, n, dk)
    V = _uniform(seed, 2 * m, m).reshape(H, n, dk)
    Wout = _uniform(seed, 3 * m, d * CLASSES).reshape(d, CLASSES) * math.sqrt(3.0 / d)
    return Q, K, V, Wout


def labels(O, Wout, n, H, dk):
    """O is H x n x dk on the device: concatenate the heads, read out, argmax, and bring the n labels back (this is the one synchronising read-back)."""
    return (O.permute(1, 0, 2).reshape(n, H * dk).float() @ Wout).argmax(dim=1).tolist()


def solve(seed, n, H, dk):
    Q, K, V, Wout = inputs(seed, n, H, dk)
    outs = []
    for h in range(H):
        S = (Q[h] @ K[h].T) / math.sqrt(dk)
        outs.append(torch.softmax(S, dim=-1) @ V[h])
    return labels(torch.stack(outs), Wout, n, H, dk)
