"""A simulated CLUSTER WITH A TOPOLOGY for counted solvers, VERSION 3 of tensorops_dist.py (which is untouched: its ladders stay valid and comparable among themselves). A run-time layer over tensorops.py, used by
tflops_dist3_runner.py in the counting child ONLY.

What version 3 adds to version 2 (read tensorops_dist.py for the rest: devices, tp.use, per-device tensors, BSP accounting, memory and capacity, host transfers):

  NODES. The cluster is `ranks` devices in nodes of `node` devices each (device d is on node d // node). A link inside a node is the INTRA link, a link between nodes the INTER link, and every message is
  charged to exactly one of them: rounds and bytes are counted per link class. A collective whose participants all sit on one node uses the intra link; one that spans nodes uses the inter link for ALL of its
  rounds and bytes (a ring across nodes is as slow as its slowest hop, so this is exact for the ring, and an overstatement for a hierarchical algorithm a solver can write itself out of intra-node and
  inter-node collectives, which is exactly what the topology is for). `exchange` is one superstep: if ANY pair crosses nodes the whole superstep is charged to the inter link (never an understatement).
  Host transfers (item, tolist, tensor(list)) cross to the host and are charged to the inter link when the cluster has more than one node, to the intra link otherwise.
  GROUPS. Every collective takes an optional `group=[d0, d1, ...]` (distinct devices): xs[i] must live on group[i], and the result tensors do. Without it the group is devices 0..p-1 as in version 2. A 2D layout
  (tensor parallel inside nodes, data parallel across them) is a program over several groups.
  Every collective is a barrier over EVERY device (BSP). Separate calls of disjoint groups therefore do not overlap (it can only overstate a solver that would run them concurrently); to run groups concurrently, pass
  a LIST of disjoint groups to ONE call of all_reduce, reduce_scatter or all_gather (xs in the order of the groups' devices): one superstep, charged once per link class some group uses.
  `exchange` differs from version 2 in one way: a device may send to and receive from SEVERAL others in one superstep (a pipeline stage that passes an activation forward and a gradient back), charged by its
  TOTAL bytes sent or received; a program that obeys version 2's one-send, one-arrival rule counts identically.

The run's numbers, all exact integers:  wcrit (busiest device's flops summed over phases), then rounds and comm for each link class: ri, ci (intra) and rx, cx (inter); comm is bytes per device on the critical path times
L = lcm(1..ranks). On a machine with intra latency/bandwidth (a_i, b_i) and inter (a_x, b_x) the time is EXACTLY
    wcrit + steps + a_i * ri + b_i * ci / L + a_x * rx + b_x * cx / L.
With node = ranks (one node) every message is intra and ri, ci equal version 2's rounds and comm: a version-2 program counts identically (tested).

What this is not: a measurement, congestion, a hierarchical-ring model of a collective that spans nodes (a solver writes the hierarchy itself), overlap of compute and communication. See PROTOCOL.md.
"""
import math

import numpy as np

_PHASE = {}
_W = [0]
_R = [0, 0]        # message rounds on the critical path: [intra link, inter link]
_C = [0, 0]        # bytes per device on the critical path times L: [intra link, inter link]
_CUR = [0]
_CFG = {"ranks": 1, "L": 1, "node": 1}
_LIVEK = {}        # per device: bytes of tensors alive on it now (8 per element; a view counts as a copy)
_PEAKK = {}        # per device: the most bytes alive on it at one instant
_CAPK = [None]     # the most bytes any one device may hold (None: unlimited); past it the run dies with OutOfDeviceMemory


class OutOfDeviceMemory(BaseException):
    """A BaseException, so a solver's `except Exception` cannot swallow it: a device was asked to hold more than its capacity."""


def lcm_upto(n):
    out = 1
    for k in range(1, n + 1):
        out = out * k // math.gcd(out, k)
    return out


def reset(ranks, cap_bytes=None, node=None):
    node = ranks if node is None else node
    if isinstance(node, bool) or not isinstance(node, int) or not 1 <= node <= ranks or ranks % node:
        raise ValueError("node: devices per node, a divisor of ranks")
    _PHASE.clear()
    _LIVEK.clear()
    _PEAKK.clear()
    _W[0] = 0
    _R[0] = _R[1] = _C[0] = _C[1] = 0
    _CUR[0] = 0
    _CAPK[0] = cap_bytes
    _CFG["ranks"], _CFG["L"], _CFG["node"] = ranks, lcm_upto(ranks), node


def counters():
    """-> (wcrit, ri, ci, rx, cx): the critical-path work including the phase still open, then rounds and bytes-times-L on the intra link and on the inter link."""
    return _W[0] + max(_PHASE.values() or [0]), _R[0], _C[0], _R[1], _C[1]


def peak_bytes():
    """The most bytes any ONE device held at one instant during the run."""
    return max(_PEAKK.values() or [0])


def _barrier():
    _W[0] += max(_PHASE.values() or [0])
    _PHASE.clear()


def _cls_of(devices):
    """0 (intra link) when every device is on one node, else 1 (inter link)."""
    return 0 if len({d // _CFG["node"] for d in devices}) <= 1 else 1


def _host_cls():
    return 0 if _CFG["node"] == _CFG["ranks"] else 1


def _message(rounds, nbytes, cls):
    _R[cls] += rounds
    _C[cls] += nbytes * _CFG["L"]


def install(tp, ranks, cap_bytes=None, node=None):
    """Wrap the tensorops module `tp` in this process, once, before any solver code runs. cap_bytes: the most any one device may hold (None: unlimited). node: devices per node (None: one node)."""
    Base = tp.Tensor
    reset(ranks, cap_bytes, node)

    class DistTensor(Base):
        __slots__ = ("_k",)

        def __init__(self, a):
            Base.__init__(self, a)
            self._k = None                      # set by `put` once the operation knows which device the result lives on

        def __del__(self):
            try:
                k = getattr(self, "_k", None)
                if k is not None:
                    _LIVEK[k] = _LIVEK.get(k, 0) - self._a.size * 8
            except (AttributeError, TypeError):      # never registered, or the interpreter is shutting down
                pass
            Base.__del__(self)

    def put(t, dev):
        """Place a freshly made tensor on a device and account for its bytes there; past the device's capacity the run ends."""
        t._k = dev
        n = _LIVEK.get(dev, 0) + t._a.size * 8
        _LIVEK[dev] = n
        if n > _PEAKK.get(dev, 0):
            _PEAKK[dev] = n
        if _CAPK[0] is not None and n > _CAPK[0]:
            raise OutOfDeviceMemory(f"device {dev} would hold {n} bytes, over its capacity of {_CAPK[0]}")
        return t

    def dev_of(args):
        """The one device the tensor operands live on (the current device if there are none); mixed devices are an error."""
        found = set()
        for a in args:
            if isinstance(a, DistTensor):
                found.add(a._k)
            elif isinstance(a, (list, tuple)):
                found |= {t._k for t in a if isinstance(t, DistTensor)}
        if len(found) > 1:
            raise ValueError("operands live on different devices " + str(sorted(found)) + ": communicate first (all_reduce, all_gather, ...)")
        return found.pop() if found else _CUR[0]

    def charged(dev, f0):
        d = tp._FLOPS[0] - f0
        if d:
            _PHASE[dev] = _PHASE.get(dev, 0) + d

    def method(name):
        fn = getattr(Base, name)

        def wrapper(self, *args):
            dev = dev_of((self,) + args)
            f0 = tp._FLOPS[0]
            r = fn(self, *args)
            charged(dev, f0)
            if isinstance(r, DistTensor):
                put(r, dev)
            return r
        return wrapper

    for name in ("__add__", "__radd__", "__sub__", "__rsub__", "__mul__", "__rmul__", "__truediv__", "__rtruediv__", "__neg__", "__matmul__", "__getitem__", "__setitem__"):
        setattr(DistTensor, name, method(name))

    base_item, base_tolist = Base.item, Base.tolist

    def host_read(base):
        def wrapper(self):
            f0 = tp._FLOPS[0]
            r = base(self)
            charged(self._k, f0)
            _barrier()
            _message(1, self._a.size * 8, _host_cls())
            return r
        return wrapper
    DistTensor.item, DistTensor.tolist = host_read(base_item), host_read(base_tolist)
    tp.Tensor = DistTensor

    def wrap(name, creator=False, host_write=False):
        fn = getattr(tp, name)

        def wrapper(*args, **kw):
            dev = _CUR[0] if creator else dev_of(args)
            f0 = tp._FLOPS[0]
            r = fn(*args, **kw)
            charged(dev, f0)
            if isinstance(r, DistTensor):
                put(r, dev)
                if host_write:
                    _message(1, r._a.size * 8, _host_cls())
            return r
        wrapper.__name__ = name
        setattr(tp, name, wrapper)

    for name in ("stream", "zeros", "causal_mask"):
        wrap(name, creator=True)
    wrap("tensor", creator=True, host_write=True)
    for name in ("take", "concat", "reshape", "transpose", "einsum", "exp", "sqrt", "relu", "sum", "max", "mean"):
        wrap(name)
    base_argmax = tp.argmax

    def argmax(x):
        f0 = tp._FLOPS[0]
        r = base_argmax(x)
        charged(x._k, f0)
        _barrier()
        _message(1, 8, _host_cls())
        return r
    tp.argmax = argmax

    def use(k):
        if isinstance(k, bool) or not isinstance(k, int) or not 0 <= k < _CFG["ranks"]:
            raise ValueError(f"use(k): a device number 0 .. {_CFG['ranks'] - 1}")
        _CUR[0] = k

    def members(n, grp):
        """The group's devices: `grp` (distinct devices) or 0 .. n-1; its length must be n."""
        if grp is None:
            grp = list(range(n))
        if not isinstance(grp, (list, tuple)) or len(grp) != n or len(set(grp)) != n or any(isinstance(d, bool) or not isinstance(d, int) or not 0 <= d < _CFG["ranks"] for d in grp):
            raise ValueError(f"group: {n} distinct devices 0 .. {_CFG['ranks'] - 1}")
        return list(grp)

    def check(xs, grp):
        """-> the list of groups (each a list of devices) the collective runs over, all of one size p: `grp` is None (one group, devices 0 .. len(xs)-1), a list of devices (one group), or a list of disjoint
        lists of devices (SEVERAL groups at once: one concurrent superstep). xs is the flat list of tensors in the order of the groups' devices, xs[k] living on the k-th device."""
        if not isinstance(xs, (list, tuple)) or not xs or not all(isinstance(t, DistTensor) for t in xs):
            raise TypeError("a collective takes a non-empty list of Tensors, one per device")
        if grp is None:
            groups = [list(range(len(xs)))]
        elif isinstance(grp, (list, tuple)) and grp and all(isinstance(g, (list, tuple)) for g in grp):
            groups = [list(g) for g in grp]
        else:
            groups = [list(grp)]
        p = len(groups[0])
        flat = [d for g in groups for d in g]
        if any(len(g) != p for g in groups) or len(flat) != len(xs) or len(set(flat)) != len(flat) or any(isinstance(d, bool) or not isinstance(d, int) or not 0 <= d < _CFG["ranks"] for d in flat):
            raise ValueError("groups: disjoint lists of the same number of devices 0 .. ranks-1, one tensor per device")
        if any(t._k != flat[k] for k, t in enumerate(xs)):
            raise ValueError("xs[k] must live on the k-th device of the groups")
        if any(t._a.shape != xs[0]._a.shape for t in xs):
            raise ValueError("every tensor in a collective has the same shape")
        return p, groups

    def charge(groups, rounds, cost):
        """One concurrent superstep over disjoint groups of equal size: a barrier, then the rounds and the per-device bytes times L (`cost`, an integer) once for each link class some group uses."""
        _barrier()
        for c in {_cls_of(g) for g in groups}:
            _R[c] += rounds
            _C[c] += cost

    def place(arrs, devices):
        out = []
        for a, d in zip(arrs, devices):
            out.append(put(DistTensor(a), d))
        return out

    def per_group(xs, groups, p, fn):
        """Apply fn(list of numpy arrays of one group) -> list of p numpy arrays, to every group; return the results as one flat list in group order."""
        out, k = [], 0
        for g in groups:
            out += fn([t._a for t in xs[k:k + p]])
            k += p
        return out

    def all_reduce(xs, group=None):
        p, groups = check(xs, group)
        n = xs[0]._a.size
        if p > 1:
            charge(groups, 2 * (p - 1), 2 * (p - 1) * n * 8 * (_CFG["L"] // p))
        res = per_group(xs, groups, p, lambda arrs: [np.sum(arrs, axis=0).copy() for _ in range(p)])
        return place(res, [d for g in groups for d in g])

    def reduce_scatter(xs, group=None):
        p, groups = check(xs, group)
        n = xs[0]._a.size
        if xs[0]._a.ndim < 1 or xs[0]._a.shape[0] % p:
            raise ValueError("reduce_scatter splits axis 0 into p equal chunks")
        if p > 1:
            charge(groups, p - 1, (p - 1) * n * 8 * (_CFG["L"] // p))
        res = per_group(xs, groups, p, lambda arrs: [c_.copy() for c_ in np.split(np.sum(arrs, axis=0), p, axis=0)])
        return place(res, [d for g in groups for d in g])

    def all_gather(xs, group=None):
        p, groups = check(xs, group)
        m = xs[0]._a.size
        if xs[0]._a.ndim < 1:
            raise ValueError("all_gather concatenates along axis 0: a tensor of at least one dimension")
        if p > 1:
            charge(groups, p - 1, (p - 1) * m * 8 * _CFG["L"])
        res = per_group(xs, groups, p, lambda arrs: [np.concatenate(arrs, axis=0).copy() for _ in range(p)])
        return place(res, [d for g in groups for d in g])

    def broadcast(x, p, group=None):
        """x lives on the group's first device (device 0 by default); every device of the group gets a copy (a binomial tree: ceil(log2 p) rounds, each moving the whole tensor)."""
        if isinstance(p, bool) or not isinstance(p, int) or not 1 <= p <= _CFG["ranks"]:
            raise ValueError("broadcast(x, p): 1 <= p <= ranks")
        g = members(p, group)
        if not isinstance(x, DistTensor) or x._k != g[0]:
            raise ValueError("broadcast(x, p): x must live on the group's first device")
        if p > 1:
            steps = (p - 1).bit_length()
            _barrier()
            c = _cls_of(g)
            _R[c] += steps
            _C[c] += steps * x._a.size * 8 * _CFG["L"]
        return place([x._a.copy() for _ in range(p)], g)

    def exchange(sends):
        """sends: a list of (tensor, dst) pairs: ONE superstep in which every pair moves at once (a pipeline's hand-off to the next stage, a shift around a ring, a stage that passes an activation forward and a
        gradient back). A device may send to and receive from several others in it (version 2 allowed one of each). Returns the received tensors in the same order, each on its dst. Cost: a barrier, one round, and
        the largest TOTAL number of bytes any one device sends or receives, on the INTER link if any pair crosses nodes, else on the intra link."""
        if not isinstance(sends, (list, tuple)) or not sends:
            raise TypeError("exchange takes a non-empty list of (tensor, dst) pairs")
        sent, recv, crosses = {}, {}, False
        for item in sends:
            if not isinstance(item, (list, tuple)) or len(item) != 2 or not isinstance(item[0], DistTensor):
                raise TypeError("exchange takes (tensor, dst) pairs")
            t, dst = item
            if isinstance(dst, bool) or not isinstance(dst, int) or not 0 <= dst < _CFG["ranks"]:
                raise ValueError(f"exchange: a destination device 0 .. {_CFG['ranks'] - 1}")
            if dst != t._k:
                sent[t._k] = sent.get(t._k, 0) + t._a.size * 8
                recv[dst] = recv.get(dst, 0) + t._a.size * 8
                crosses = crosses or _cls_of([t._k, dst]) == 1
        _barrier()
        c = 1 if crosses else 0
        _R[c] += 1
        _C[c] += max([*sent.values(), *recv.values(), 0]) * _CFG["L"]
        out = []
        for t, dst in sends:
            u = DistTensor(t._a.copy())
            out.append(put(u, dst))
        return out

    def all_to_all(xss, group=None):
        """xss: p lists of p tensors; xss[i][j] lives on device group[i] and goes to device group[j] (chunks may differ in size, even be empty: that is load imbalance). Returns p lists: out[j][i] = xss[i][j],
        on device group[j]. Cost: a barrier, p-1 rounds, and the largest number of bytes any one device sends or receives (its own chunk stays put), on the link class of the group."""
        if not isinstance(xss, (list, tuple)) or not xss or not all(isinstance(r, (list, tuple)) and len(r) == len(xss) for r in xss):
            raise TypeError("all_to_all takes p lists of p tensors")
        p = len(xss)
        if p > _CFG["ranks"]:
            raise ValueError(f"an all_to_all over {p} devices: this instance has {_CFG['ranks']}")
        g = members(p, group)
        for i, row in enumerate(xss):
            if not all(isinstance(t, DistTensor) and t._k == g[i] for t in row):
                raise ValueError("xss[i][j] must be a Tensor living on device group[i]")
        if p > 1:
            _barrier()
            c = _cls_of(g)
            _R[c] += p - 1
            sent = [sum(xss[i][j]._a.size * 8 for j in range(p) if j != i) for i in range(p)]
            recv = [sum(xss[i][j]._a.size * 8 for i in range(p) if i != j) for j in range(p)]
            _C[c] += max(sent + recv) * _CFG["L"]
        return [[put(DistTensor(xss[i][j]._a.copy()), g[j]) for i in range(p)] for j in range(p)]

    tp.use, tp.all_reduce, tp.reduce_scatter, tp.all_gather, tp.broadcast, tp.exchange, tp.all_to_all = use, all_reduce, reduce_scatter, all_gather, broadcast, exchange, all_to_all
    return DistTensor
