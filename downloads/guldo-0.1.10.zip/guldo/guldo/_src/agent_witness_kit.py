"""OPTIONAL kit for getting an outside witness for a committed agent round, quickly. Nothing else in the project depends on it, and the site card's "outside witnesses" count stays 0 until a real
witness has signed a real round.

  operator, BEFORE any entry exists (the plan hash is then fixed):
    python3 agent_witness_kit.py announce BASE ROUND_ID --out ANNOUNCE.json [--key OPERATOR.key] [--text-out MESSAGE.txt]
        send the message to the witness by any channel that gives THEM a timestamp (their inbox is the outside clock). Refused once the round has an entry or is revealed: it would fix nothing.
  operator, AFTER the reveal:
    python3 agent_witness_kit.py build BASE ROUND_ID --out KIT_DIR [--proxy-log LOG --proxy-trusted KEYFILE]
        a self-contained directory (and KIT_DIR.tar.gz): the tools, the revealed round, a README. Only an allow-listed set of round files is copied; never a key, never an unrevealed seed.
  witness (inside the kit directory; Python 3.9+ and nothing else):
    python3 agent_witness_kit.py witness . ROUND_ID --announce ANNOUNCE.json --received-at 2026-12-01T10:15:00Z [--key witness.key] [--rerun N [--agent SPEC] [--confirm-api-spend]]
        verifies the round from its files, binds the plan hash to the one in YOUR copy of the announcement, checks YOUR receipt time precedes the first entry, signs one statement per ladder and
        one bundle. A failure is signed as a DISSENT. Send back witness.bundle.json and witness.*.json; publish your public key where the operator cannot edit it.
  anyone:
    python3 agent_witness_kit.py check BASE ROUND_ID BUNDLE.json --trusted PINNED_KEYS.txt [--announce ANNOUNCE.json] [--min 1] [STATEMENT.json ...]
        recomputes everything itself (the round, the receipt-time ordering, every ladder digest); the bundle's own flags are not trusted.

WHAT THIS DOES NOT SHOW. The receipt time is the WITNESS'S word about their own copy of the message (keep the message with its mail headers: that is the real evidence); the round's timestamps are the
operator's log. The check shows the two are consistent, not that either clock is honest. A witness who only verifies shows the records are consistent and correct, not that a model produced them; for
that, use --rerun (the witness runs a sample THEY draw) or a proxy the witness holds (agent_proxy.py). A round the witness did not see announced first can still be verified but is not "witnessed".
"""
import argparse
import ast
import datetime
import glob
import json
import os
import shutil
import sys
import tarfile

import agent_core
import agent_sig

HERE = os.path.dirname(os.path.abspath(__file__))
ANNOUNCE_FORMAT = "guldo-preannounce-v1"
BUNDLE_FORMAT = "guldo-witness-bundle-v1"
ROUND_FILES = ("round.json", "plan.json", "log.jsonl", "results.json", "seed.revealed")        # the ONLY round files a kit carries (plus ladders/ and entries/)
ENTRY_MODULES = ("agent_witness_kit", "agent_proxy", "agent_cert")                               # the kit's own commands, plus what its README tells a witness to run


class KitError(Exception):
    pass


def _rd(base, rid):
    import agent_rounds
    return agent_rounds.rdir(base, rid)


def round_facts(base, rid):
    """What the round's own hash-chained log says: plan hash, commitment, when it was created / closes, when the first entry arrived, whether it is revealed."""
    p = os.path.join(_rd(base, rid), "log.jsonl")
    try:
        with open(p, "r", encoding="utf-8") as f:
            rows = [json.loads(ln) for ln in f if ln.strip()]
        first = rows[0]
        data = first["data"]
        facts = {"round_id": rid, "plan_hash": data["plan_hash"], "commitment": data["commitments"][0], "created": first["ts"], "closes_at": data["closes_at"],
                 "domain": data["plan"]["domain"] if isinstance(data.get("plan"), dict) and "domain" in data["plan"] else None}
    except (OSError, ValueError, KeyError, IndexError, TypeError) as e:
        raise KitError("cannot read the round's log (%s: %s)" % (type(e).__name__, str(e)[:100]))
    ent = [r["ts"] for r in rows if r.get("kind") == "entry"]
    facts["first_entry_ts"] = min(ent) if ent else None
    facts["log_head"] = rows[-1].get("hash")                                      # the chain hash of the last row: what a witness signs so the log cannot be swapped for a rewritten one afterwards
    facts["revealed"] = any(r.get("kind") == "revealed" for r in rows)
    return facts


def _ts(text):
    """An ISO-8601 time WITH a zone ('2026-12-01T10:15:00Z' or '+02:00') as a POSIX time. A time without a zone is refused: it would be read in the wrong zone."""
    try:
        d = datetime.datetime.fromisoformat(str(text).strip().replace("Z", "+00:00"))
    except ValueError:
        raise KitError("%r is not an ISO-8601 time (example: 2026-12-01T10:15:00Z)" % (text,))
    if d.tzinfo is None:
        raise KitError("the time %r has no zone: write it with Z or an offset, e.g. 2026-12-01T10:15:00Z" % (text,))
    return d.timestamp()


def _body(doc):
    """An announcement is either the bare statement or {statement, signature}."""
    if isinstance(doc, dict) and "statement" in doc and "signature" in doc:
        return doc["statement"], doc
    return doc, None


def announce_sha256(doc):
    return agent_core.sha256_hex(agent_core.canon(doc))


# ---- operator: announce ----------------------------------------------------------------------------------------------------------------------------------

def make_announcement(base, rid, secret=None):
    f = round_facts(base, rid)
    if f["first_entry_ts"] is not None or f["revealed"]:
        raise KitError("this round already has an entry or is revealed: an announcement made now fixes nothing (the whole point is that the witness holds the plan hash BEFORE the run)")
    body = {"format": ANNOUNCE_FORMAT, "round_id": rid, "domain": f["domain"], "plan_hash": f["plan_hash"], "commitment": f["commitment"], "created": f["created"], "closes_at": f["closes_at"],
            "note": "Keep this message with its headers (the time you received it is the evidence). After the round is revealed you will be sent a kit to check it against this."}
    return agent_sig.sign_statement(body, secret) if secret is not None else body


def announcement_text(doc):
    b, _ = _body(doc)
    return ("Guldo agent-evaluation round %s: pre-announcement.\n\nThis fixes the plan of a round BEFORE it runs. Please keep this message, with its headers, and tell nobody to change it.\n"
            "  plan hash:  %s\n  commitment: %s\n\nThe complete announcement (save exactly this as ANNOUNCE.json):\n\n%s\n" % (b["round_id"], b["plan_hash"], b["commitment"], json.dumps(doc, indent=1, sort_keys=True)))


# ---- operator: build the kit -----------------------------------------------------------------------------------------------------------------------------

def _local_imports(path):
    with open(path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read())
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                yield a.name.split(".")[0]
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            yield node.module.split(".")[0]


def module_closure(entry=ENTRY_MODULES, root=HERE):
    """Every module file of this directory reachable from `entry` by an import statement anywhere in it (including inside functions)."""
    seen, todo = set(), list(entry)
    while todo:
        m = todo.pop()
        p = os.path.join(root, m + ".py")
        if m in seen or not os.path.isfile(p):
            continue
        seen.add(m)
        todo.extend(_local_imports(p))
    return sorted(seen)


def _kit_readme(f, rid, has_proxy):
    return ("# Witness kit for round %s\n\nYou need Python 3.9 or newer and nothing else. Everything below runs inside this directory.\n\n"
            "Plan hash this round was committed to: `%s`\n\n"
            "0. **Do not trust this directory's copy of the tool.** It was supplied by the operator, and the program that signs for you, and the code that decides whether the round verifies, are part of it (a\n"
            "   revealed round pins only its core, harness and domain files, so changes to THOSE are caught, but not changes to the verification, comparison or signing code). Better: get the tool from the public package yourself, and point it at this directory's DATA:\n\n"
            "       (to compare: `KIT_MANIFEST.sha256` lists the hash of every tool file here; the same files of the public package must hash the same)\n\n"
            "       python3 /path/to/public/agent_witness_kit.py witness /path/to/this/kit %s --announce ANNOUNCE.json --received-at ...\n\n"
            "   Running it from inside the kit (as below) still works and is checked, but then you are trusting the operator's code.\n"
            "1. Find the pre-announcement the operator sent you BEFORE the round ran, and the time you received it (from your mail client's headers). Save the JSON in it as ANNOUNCE.json.\n"
            "2. Run (the time must carry a zone, e.g. Z for UTC):\n\n"
            "       python3 agent_witness_kit.py witness . %s --announce ANNOUNCE.json --received-at 2026-12-01T10:15:00Z\n\n"
            "   It verifies the round, ties it to your copy of the announcement, checks your receipt time came first, creates `witness.key` if you have none, and writes `witness.bundle.json` and one\n"
            "   `witness.<ladder>.json` per ladder. If anything fails it signs that as a DISSENT: that is correct and useful, do not edit it.\n"
            "3. Optional, stronger (a free local model costs nothing; a hosted one costs your own money and needs --confirm-api-spend): add `--rerun 6` to run 6 instances YOU draw, which the\n"
            "   operator could not have seen, and test the pass rate against the operator's. Do NOT pass --agent for a real rerun: each ladder is then run with its own recorded configuration\n"
            "   (the default); --agent would run the same agent on both.\n"
            "4. Send back `witness.bundle.json` and the `witness.*.json` files, and publish your public key (printed by step 2) somewhere the operator cannot edit.\n%s\n"
            "What you are vouching for, exactly: that this round verifies from its own files, that it is the plan you were told about before it ran, and (with --rerun) that a sample you drew\n"
            "is compatible with the operator's records. Not: that the model is good, or that the operator's clock is honest.\n"
            % (rid, f["plan_hash"], rid, rid, "\n5. The operator also supplied a recording-proxy log (`proxy_log.jsonl`) and its public key; check it with `python3 agent_proxy.py verify-round %s proxy_log.jsonl --trusted verifier.pub --base .`.\n" % rid if has_proxy else ""))


def build_kit(base, rid, out, proxy_log=None, proxy_trusted=None):
    f = round_facts(base, rid)
    rd = _rd(base, rid)
    if not f["revealed"] or not os.path.isfile(os.path.join(rd, "seed.revealed")):
        raise KitError("the round is not revealed: a kit made now would hold no seed, and a seed must never be put in one before the reveal")
    if os.path.exists(out) or os.path.exists(out + ".tar.gz"):
        raise KitError("%s (or its .tar.gz) already exists: nothing is overwritten" % out)
    if bool(proxy_log) != bool(proxy_trusted):
        raise KitError("give both --proxy-log and --proxy-trusted, or neither")
    for p in (proxy_log, proxy_trusted):
        if p and not os.path.isfile(p):
            raise KitError("%s is not a file: nothing was built" % p)                  # checked BEFORE anything is created, so a typo leaves no half-made kit behind
    os.makedirs(out)
    copied = []
    try:
        def put(src, rel):
            dst = os.path.join(out, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(src, "rb") as a, open(dst, "wb") as b:
                b.write(a.read())
            copied.append(rel)
        tool_files = []
        for m in module_closure():
            put(os.path.join(HERE, m + ".py"), m + ".py")
            tool_files.append(m + ".py")
        for p in sorted(glob.glob(os.path.join(HERE, "agent_domains", "*.py"))):
            put(p, os.path.join("agent_domains", os.path.basename(p)))
            tool_files.append("agent_domains/" + os.path.basename(p))
        # the tool files' hashes, in `shasum -a 256 -c` format: a witness compares them with the same files of the PUBLIC package (the operator's copy is not to be trusted on its word)
        with open(os.path.join(out, "KIT_MANIFEST.sha256"), "w", encoding="utf-8") as fh:
            for rel in sorted(tool_files):
                fh.write("%s  %s\n" % (agent_core.file_sha256(os.path.join(out, rel)), rel))
        copied.append("KIT_MANIFEST.sha256")
        for name in ROUND_FILES:
            if os.path.isfile(os.path.join(rd, name)):
                put(os.path.join(rd, name), os.path.join("agent-rounds", rid, name))
        for sub, pat in (("ladders", "*.jsonl"), ("entries", "*.json")):
            for p in sorted(glob.glob(os.path.join(rd, sub, pat))):
                put(p, os.path.join("agent-rounds", rid, sub, os.path.basename(p)))
        if proxy_log:
            put(proxy_log, "proxy_log.jsonl")
            put(proxy_trusted, "verifier.pub")
        with open(os.path.join(out, "WITNESS_README.md"), "w", encoding="utf-8") as fh:
            fh.write(_kit_readme(f, rid, bool(proxy_log)))
        copied.append("WITNESS_README.md")
        with tarfile.open(out + ".tar.gz", "w:gz") as t:
            t.add(out, arcname=os.path.basename(out.rstrip("/")))
    except BaseException:                                                             # never leave a half-built kit that could be handed over as if complete
        shutil.rmtree(out, ignore_errors=True)
        if os.path.exists(out + ".tar.gz"):
            os.remove(out + ".tar.gz")
        raise
    return {"dir": out, "tarball": out + ".tar.gz", "files": sorted(copied), "tarball_sha256": agent_core.file_sha256(out + ".tar.gz")}


# ---- witness ---------------------------------------------------------------------------------------------------------------------------------------------

def _ladders(rd):
    return sorted(glob.glob(os.path.join(rd, "ladders", "*.jsonl")))


def witness_round(base, rid, announce_doc, received_at, key_path, out_dir, rerun=None, agent=None, confirm=False, say=print):
    """Returns (ok, bundle, written_files). Never raises for a round that merely fails to verify: that is signed as a dissent."""
    import agent_compare
    import agent_eval
    import agent_rounds
    import agent_witness
    secret = agent_sig.load_secret(key_path)
    rd = _rd(base, rid)
    f = round_facts(base, rid)
    body, _ = _body(announce_doc)
    probs = agent_rounds.verify_round(base, rid, True)
    consistent = (isinstance(body, dict) and body.get("format") == ANNOUNCE_FORMAT and body.get("round_id") == rid and body.get("plan_hash") == f["plan_hash"]
                  and body.get("commitment") == f["commitment"])
    rts = _ts(received_at)
    anchor = f["first_entry_ts"] is not None and rts < f["first_entry_ts"] and rts <= f["closes_at"]
    master = agent_core.read_master(os.path.join(rd, "seed.revealed"), False)
    plan = json.load(open(os.path.join(rd, "plan.json"), "r", encoding="utf-8"))
    os.makedirs(out_dir, exist_ok=True)
    written, ladders = [], []
    all_ok = not probs and consistent and anchor
    for path in _ladders(rd):
        label = os.path.splitext(os.path.basename(path))[0]
        lp, _ = agent_eval.verify_ladder(path, master, plan, body.get("plan_hash") if isinstance(body, dict) else None, True)
        h, r = agent_core.read_ladder(path)
        digest = agent_compare.ladder_digest(h, r)
        outp = os.path.join(out_dir, "witness.%s.json" % label)
        # exactly one of: a rerun, or a plain verification statement (with a note saying why there is no rerun when one was asked for)
        do_rerun = bool(rerun) and not lp and not h.get("mode") and consistent
        if rerun and not lp and h.get("mode"):
            say("ladder %-10s is a BLACK-BOX arm: verified, but a witness cannot rerun a vendor's agent (use serve-arm with your own seed instead)" % label)
        elif rerun and not lp and not consistent:
            say("ladder %-10s: rerun SKIPPED, the announcement you hold does not match this round (a rerun would cost you for a round that is already not witnessed)" % label)
        if do_rerun:
            import agent_tools
            args = ["witness-rerun", path, "--key", key_path, "--sample", str(rerun), "--seed", os.path.join(rd, "seed.revealed"), "--plan", os.path.join(rd, "plan.json"),
                    "--plan-hash", f["plan_hash"], "--out", outp]
            if agent:
                args += ["--agent", agent]
            if confirm:
                args += ["--confirm-api-spend"]
            try:                                                                  # agent_tools.main() ends the PROCESS with sys.exit; run() returns the code
                rc = agent_tools.run(agent_tools.build_parser().parse_args(args))
            except SystemExit as e:                                               # a refusal inside it (_die) is a failed rerun, not the end of this witness's job
                rc = e.code if isinstance(e.code, int) and e.code else 1
            if not os.path.isfile(outp):
                raise KitError("the rerun for ladder %s wrote no statement (exit code %s); nothing was signed for it" % (label, rc))
            all_ok = all_ok and not rc
        else:
            st = agent_witness.make_statement(h, r, lp, secret, note="witnessed with agent_witness_kit")
            with open(outp, "w", encoding="utf-8") as fh:
                fh.write(json.dumps(st, indent=1, sort_keys=True) + "\n")
            all_ok = all_ok and not lp
        written.append(outp)
        ladders.append({"label": label, "ladder_digest": digest, "verified": not lp})
        say("ladder %-10s %s" % (label, "verifies" if not lp else "DOES NOT VERIFY (%d problems; first: %s)" % (len(lp), str(lp[0])[:100])))
    stmt = {"format": BUNDLE_FORMAT, "round_id": rid, "plan_hash": f["plan_hash"], "commitment": f["commitment"], "announce_sha256": announce_sha256(announce_doc),
            "received_at": received_at, "received_at_is_witness_claim": True, "first_entry_ts": f["first_entry_ts"], "log_head": f["log_head"], "round_verified": not probs, "round_problems_first": [str(p)[:200] for p in probs[:5]],
            "preannounce_consistent": consistent, "anchor_ok": anchor, "ladders": ladders, "at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
    bundle = agent_sig.sign_statement(stmt, secret)
    bp = os.path.join(out_dir, "witness.bundle.json")
    with open(bp, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(bundle, indent=1, sort_keys=True) + "\n")
    written.append(bp)
    say("round %s; matches the announcement you hold: %s; your receipt time precedes the first entry: %s" % ("VERIFIES" if not probs else "DOES NOT VERIFY", "yes" if consistent else "NO", "yes" if anchor else "NO"))
    return all_ok, bundle, written


# ---- anyone: check ---------------------------------------------------------------------------------------------------------------------------------------

def check_bundle(base, rid, bundle, trusted, announce_doc=None, statements=(), min_independent=1, replay=True, anchor=None, require_anchor=False):
    """Returns (ok, lines). Everything is recomputed here from the round's files; the bundle's own flags are never relied on.
    `anchor` is the result of announce_anchor.anchor_status for the announcement (an OpenTimestamps/Bitcoin proof): only a CONFIRMED proof whose block time precedes the round's first entry passes;
    a proof that is wrong or forged FAILS; a pending, late, single-explorer or unchecked one is a NOTE. `require_anchor` makes the absence of a passing one a failure."""
    import agent_compare
    import agent_rounds
    import agent_witness
    lines, ok = [], True

    def add(good, text):
        nonlocal ok
        ok = ok and good
        lines.append(("PASS  " if good else "FAIL  ") + text)
    if not agent_sig.statement_ok(bundle):
        add(False, "the bundle's signature is bad")
        return False, lines
    st = bundle["statement"]
    add(st.get("format") == BUNDLE_FORMAT, "the bundle is a %s document" % BUNDLE_FORMAT)
    add(st.get("pubkey") in set(trusted or []), "the bundle is signed by a key YOU pinned (%s...)" % str(st.get("pubkey"))[:12])
    f = round_facts(base, rid)
    add(st.get("round_id") == rid and st.get("plan_hash") == f["plan_hash"] and st.get("commitment") == f["commitment"], "the bundle is about this round, its plan hash and its commitment (taken from the round's own log)")
    add(f["log_head"] is not None and st.get("log_head") == f["log_head"], "the witness signed THIS round log (its final chain hash matches), so the log was not rewritten after they saw it")
    try:
        rts = _ts(st.get("received_at"))
        add(f["first_entry_ts"] is not None and rts < f["first_entry_ts"] and rts <= f["closes_at"],
            "the witness's stated receipt time (%s) precedes the round's first entry and its close (their claim against the operator's log: consistent, not independently timed)" % st.get("received_at"))
    except KitError as e:
        add(False, "the receipt time is unusable: %s" % e)
    if announce_doc is not None:
        body, _ = _body(announce_doc)
        add(announce_sha256(announce_doc) == st.get("announce_sha256") and isinstance(body, dict) and body.get("plan_hash") == f["plan_hash"] and body.get("commitment") == f["commitment"],
            "the announcement you hold is the one the witness bound to (same hash, same plan hash and commitment)")
    else:
        lines.append("NOTE  no --announce given: the bundle's reference to the announcement was not checked against a copy you hold")
    anchored = anchor is not None and anchor.get("verdict") == "before" and anchor.get("strength") == "confirmed"
    if anchor is not None:
        if anchored:
            add(True, "the announcement was anchored in Bitcoin BEFORE the round's first entry (%s): an outside clock, not the witness's word" % anchor.get("detail"))
        elif anchor.get("verdict") in ("mismatch", "invalid"):
            add(False, "the anchor proof you gave does not hold: %s" % anchor.get("detail"))
        else:
            lines.append("NOTE  anchor proof: %s%s (%s): this does not show the announcement predates the first entry" % (anchor.get("verdict"), " (" + anchor["strength"] + ")" if anchor.get("strength") else "", anchor.get("detail")))
    if require_anchor and not anchored:
        add(False, "an outside clock was REQUIRED (--require-anchor) and none confirms that the announcement predates the first entry")
    add(st.get("round_verified") is True and st.get("preannounce_consistent") is True, "the witness reports the round verified and matched the announcement (not itself relied on: see the next lines)")
    probs = agent_rounds.verify_round(base, rid, replay)
    add(not probs, "the round verifies from its files here too" + ("" if not probs else " (first problem: %s)" % str(probs[0])[:100]))
    rd = _rd(base, rid)
    listed = {x.get("ladder_digest") for x in st.get("ladders", []) if isinstance(x, dict)}
    for path in _ladders(rd):
        h, r = agent_core.read_ladder(path)
        d = agent_compare.ladder_digest(h, r)
        label = os.path.splitext(os.path.basename(path))[0]
        add(d in listed, "ladder %s is covered by the bundle" % label)
        res = agent_witness.check_witnesses(d, [s for s in statements if isinstance(s, dict)], trusted, min_independent, own_problems=[])
        add(res["ok"], "ladder %s has %d pinned witness statement(s) (%d needed)%s" % (label, res["independent"] if isinstance(res["independent"], int) else len(res["independent"]), min_independent,
                                                                                    "" if res["ok"] else ": " + "; ".join(res["lines"])[:200]))
    return ok, lines


# ---- command line ----------------------------------------------------------------------------------------------------------------------------------------

def _load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main(argv=None):
    ap = argparse.ArgumentParser(description="optional outside-witness kit for agent rounds (see the module docstring)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("announce"); p.add_argument("base"); p.add_argument("round_id"); p.add_argument("--out", required=True); p.add_argument("--key"); p.add_argument("--text-out")
    p = sub.add_parser("build"); p.add_argument("base"); p.add_argument("round_id"); p.add_argument("--out", required=True); p.add_argument("--proxy-log"); p.add_argument("--proxy-trusted")
    p = sub.add_parser("witness"); p.add_argument("base"); p.add_argument("round_id"); p.add_argument("--announce", required=True); p.add_argument("--received-at", required=True)
    p.add_argument("--key", default="witness.key"); p.add_argument("--out-dir", default="."); p.add_argument("--rerun", type=int); p.add_argument("--agent"); p.add_argument("--confirm-api-spend", action="store_true")
    p = sub.add_parser("check"); p.add_argument("base"); p.add_argument("round_id"); p.add_argument("bundle"); p.add_argument("--trusted", required=True); p.add_argument("--announce")
    p.add_argument("--min", type=int, default=1); p.add_argument("--no-replay", action="store_true")
    p.add_argument("--anchor-proof", help="an OpenTimestamps proof of the announcement (announce_anchor.py): an OUTSIDE clock; needs --announce"); p.add_argument("--online", action="store_true", help="check the anchor proof against Bitcoin block explorers")
    p.add_argument("--require-anchor", action="store_true", help="fail unless a confirmed anchor shows the announcement predates the round's first entry")
    # The witness statement files come AFTER the options. Python 3.9's argparse rejects a positional list that follows options ("unrecognized arguments"), 3.12+ accepts it, so the leftovers are
    # collected by hand: a leftover that looks like an option, or any leftover on another command, is still an error.
    a, rest = ap.parse_known_args(argv)
    if rest and (a.cmd != "check" or any(x.startswith("-") for x in rest)):
        ap.error("unrecognized arguments: %s" % " ".join(rest))
    a.statements = rest
    try:
        if a.cmd == "announce":
            secret = agent_sig.load_secret(a.key) if a.key else None
            doc = make_announcement(a.base, a.round_id, secret)
            with open(a.out, "x", encoding="utf-8") as f:
                f.write(json.dumps(doc, indent=1, sort_keys=True) + "\n")
            if a.text_out:
                with open(a.text_out, "x", encoding="utf-8") as f:
                    f.write(announcement_text(doc))
            print("wrote %s; send it to the witness NOW, before the round has any entry, by a channel that timestamps it on THEIR side" % a.out)
        elif a.cmd == "build":
            info = build_kit(a.base, a.round_id, a.out, a.proxy_log, a.proxy_trusted)
            print("kit: %s (%d files), %s sha256 %s" % (info["dir"], len(info["files"]), info["tarball"], info["tarball_sha256"]))
        elif a.cmd == "witness":
            if not os.path.exists(a.key):
                print("no key at %s: creating one. Public key (publish it somewhere the operator cannot edit): %s" % (a.key, agent_sig.keygen(a.key)))
            ok, bundle, written = witness_round(a.base, a.round_id, _load(a.announce), a.received_at, a.key, a.out_dir, a.rerun, a.agent, a.confirm_api_spend)
            print("public key: %s\nwrote: %s" % (bundle["statement"]["pubkey"], ", ".join(written)))
            print("WITNESSED: every check passed" if ok else "NOT FULLY WITNESSED: what failed is recorded in your signed bundle as a dissent. That is the honest result; send it anyway.")
            return 0 if ok else 1
        elif a.cmd == "check":
            sts = [_load(p) for p in a.statements]
            anchor = None
            if a.anchor_proof:
                if not a.announce:
                    raise KitError("--anchor-proof needs --announce (the proof is of the announcement)")
                import announce_anchor                                                       # imported here: announce_anchor itself imports this module
                with open(a.anchor_proof, "rb") as fh:
                    proof = fh.read()
                anchor = announce_anchor.anchor_status(_load(a.announce), proof, round_facts(a.base, a.round_id)["first_entry_ts"], a.online)
            ok, lines = check_bundle(a.base, a.round_id, _load(a.bundle), agent_sig.read_trusted(a.trusted), _load(a.announce) if a.announce else None, sts, a.min, not a.no_replay, anchor, a.require_anchor)
            print("\n".join(lines))
            print("WITNESSED" if ok else "NOT WITNESSED")
            return 0 if ok else 1
    except (KitError, agent_core.AgentEvalError, OSError, ValueError, KeyError, TypeError, AttributeError) as e:      # a damaged or wrongly-shaped input file is a message, never a traceback
        print("error: %s: %s" % (type(e).__name__, e), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
