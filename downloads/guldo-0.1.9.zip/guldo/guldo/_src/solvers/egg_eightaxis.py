"""Wrapper that runs the paper's eight-axis BKZ+sieve code (lattice_security_tests/test_full_eightaxis_composition_real.py)
as a solve(basis, bound2) submission.

Axes (the paper's eight; this wrapper implements six):
  M batched dots, K fused kernel, T early termination, C sieve compression round-trip, R float32 precision,
  U pump schedule  -> implemented.
  S streaming early-stop -> NOT implemented here (only read by the paper's bkz_run_timed_full, which is not called):
  inert. P speculative multiprocess -> off (serial).
Env EGG_AXES selects axes, e.g. EGG_AXES=MKTRU ("" = base). Default = "SMKTCRU", i.e. M,K,T,C,R,U effectively.

LOCAL MODE ONLY: it imports the repo's helper modules by path, so it is not self-contained and does not run in the
sandbox image until those modules are copied in (that needs Docker, not done).
Honest caveat: the paper's sieve is a toy (<=80 vectors, <=40 iterations, random +-2 coefficient samples) run on
projected sublattices of size beta; whether it reaches the SVP-challenge target at these dimensions is an empirical
question the harness answers, not something this wrapper assumes.
"""
import os
import sys

import numpy as np
from fpylll import LLL, IntegerMatrix

_REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # ~/Downloads/paper
if _REPO not in sys.path:
    sys.path.insert(0, _REPO)

from lattice_security_tests import test_full_eightaxis_composition_real as egg  # noqa: E402

BETA_FOR = [(48, 14), (64, 18), (96, 24)]  # (dim ceiling, beta) the paper measured at
TOURS = 6


def _axes():
    s = os.environ.get("EGG_AXES")
    return set("SMKTCRU") if s is None else set(s)


def _beta(n):
    if os.environ.get("EGG_BETA"):
        return int(os.environ["EGG_BETA"])
    for ceiling, beta in BETA_FOR:
        if n <= ceiling:
            return beta
    return 24


def solve(basis, bound2):
    n = len(basis)
    A = IntegerMatrix.from_matrix(basis)
    LLL.reduction(A)
    B = np.array([[int(x) for x in row] for row in A], dtype=np.float64)
    ax = _axes()
    rng = np.random.default_rng(12345)  # fixed: the solver must be deterministic given its input
    beta = min(_beta(n), n)
    stats = {"correct": 0, "total": 0}
    best = None
    for _ in range(int(os.environ.get("EGG_TOURS", TOURS))):
        B, _ = egg.run_one_tour_variant_full(
            B, n, beta, rng, None, "M" in ax, "K" in ax, "T" in ax,
            "float32" if "R" in ax else "float64", "U" in ax, egg.PUMP_BMIN, egg.PUMP_STEP, "C" in ax, stats)
        row = min((r for r in B), key=lambda r: float(r @ r))
        v = [int(round(x)) for x in row]
        if any(abs(x - y) > 1e-6 for x, y in zip(row, v)):
            return None  # float drift broke exactness: refuse rather than return a non-lattice vector
        best = v
        if sum(c * c for c in v) <= bound2:
            return v
    return None
