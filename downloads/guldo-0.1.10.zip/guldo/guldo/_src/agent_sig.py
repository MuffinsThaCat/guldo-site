"""Ed25519 signatures in pure Python (RFC 8032), so receipts, witness statements and registers verify on any machine with no packages.

VERIFYING uses the RFC's reference algorithm in pure Python (correct, a few milliseconds; nothing secret is involved, so timing does not matter). SIGNING and deriving a public key from a secret
use the `cryptography` package (OpenSSL, constant-time) when it is installed, and fall back to the pure-Python reference algorithm, which is NOT constant-time, when it is not: `backend()` says which,
and the CLI prints it. A fallback signature is fine for a key on a machine you control signing a few statements; do not use it where a local timing side channel matters. Both backends give
identical bytes (Ed25519 is deterministic); that, the RFC 8032 test vector, and the small-order-key refusal are tested in test_agent_extras.py.
"""
import hashlib
import os

P = 2 ** 255 - 19
Q = 2 ** 252 + 27742317777372353535851937790883648493


def _inv(x):
    return pow(x, P - 2, P)


D = -121665 * _inv(121666) % P
SQRT_M1 = pow(2, (P - 1) // 4, P)


def _recover_x(y, sign):
    if y >= P:
        return None
    x2 = (y * y - 1) * _inv(D * y * y + 1) % P
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P != 0:
        x = x * SQRT_M1 % P
    if (x * x - x2) % P != 0:
        return None
    if (x & 1) != sign:
        x = P - x
    return x


_GY = 4 * _inv(5) % P
_GX = _recover_x(_GY, 0)
G = (_GX, _GY, 1, _GX * _GY % P)


def _add(a, b):
    A = (a[1] - a[0]) * (b[1] - b[0]) % P
    B = (a[1] + a[0]) * (b[1] + b[0]) % P
    C = 2 * a[3] * b[3] * D % P
    Dd = 2 * a[2] * b[2] % P
    E, F, G_, H = B - A, Dd - C, Dd + C, B + A
    return (E * F % P, G_ * H % P, F * G_ % P, E * H % P)


def _mul(s, pt):
    r = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            r = _add(r, pt)
        pt = _add(pt, pt)
        s >>= 1
    return r


def _eq(a, b):
    return (a[0] * b[2] - b[0] * a[2]) % P == 0 and (a[1] * b[2] - b[1] * a[2]) % P == 0


def _compress(pt):
    zi = _inv(pt[2])
    x, y = pt[0] * zi % P, pt[1] * zi % P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % P)


def _h(s):
    return int.from_bytes(hashlib.sha512(s).digest(), "little") % Q


def _expand(secret):
    h = hashlib.sha512(secret).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def new_secret():
    return os.urandom(32)


def _openssl_key(secret):
    """The `cryptography` package's Ed25519 key (OpenSSL: constant-time scalar arithmetic), or None if the package is missing or GULDO_PURE_ED25519 is set."""
    if os.environ.get("GULDO_PURE_ED25519"):
        return None
    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519
        return ed25519.Ed25519PrivateKey.from_private_bytes(secret)
    except Exception:
        return None


def backend():
    """'openssl' when signing with a secret key goes through the `cryptography` package (constant-time), else 'pure-python' (NOT constant-time)."""
    return "openssl" if _openssl_key(bytes(32)) is not None else "pure-python"


def public_key(secret):
    k = _openssl_key(secret)
    if k is not None:
        from cryptography.hazmat.primitives import serialization
        return k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return public_key_pure(secret)


def public_key_pure(secret):
    a, _ = _expand(secret)
    return _compress(_mul(a, G))


def sign(secret, msg):
    """Ed25519 is deterministic, so both backends give the same bytes (tested). With the `cryptography` package the secret-dependent arithmetic runs in OpenSSL; without it, in pure Python."""
    k = _openssl_key(secret)
    if k is not None:
        return k.sign(msg)
    return sign_pure(secret, msg)


def sign_pure(secret, msg):
    a, prefix = _expand(secret)
    pub = _compress(_mul(a, G))
    r = _h(prefix + msg)
    rs = _compress(_mul(r, G))
    s = (r + _h(rs + pub + msg) * a) % Q
    return rs + int.to_bytes(s, 32, "little")


def verify(pub, msg, sig):
    """True only for a valid signature. Never raises on malformed input."""
    try:
        if len(pub) != 32 or len(sig) != 64:
            return False
        A = _decompress(pub)
        R = _decompress(sig[:32])
        if A is None or R is None:
            return False
        # RFC 8032 allows small-order keys, and with one (the identity, say) the signature (R = identity, S = 0) verifies for EVERY message. A real key or nonce is never small-order,
        # so refuse both, as libsodium does: otherwise a statement carrying its own public key could be forged by anyone.
        if _eq(_mul(8, A), (0, 1, 1, 0)) or _eq(_mul(8, R), (0, 1, 1, 0)):
            return False
        s = int.from_bytes(sig[32:], "little")
        if s >= Q:
            return False
        return _eq(_mul(s, G), _add(R, _mul(_h(sig[:32] + pub + msg), A)))
    except Exception:
        return False


# ---- signed JSON statements --------------------------------------------------------------------------------------------------------------------------------

def sign_statement(stmt, secret):
    """{'statement': stmt, 'signature': hex}: the signature is over the canonical JSON of stmt, which carries the signer's public key."""
    import agent_core
    stmt = dict(stmt, pubkey=public_key(secret).hex())
    return {"statement": stmt, "signature": sign(secret, agent_core.canon(stmt).encode("utf-8")).hex()}


def statement_ok(signed):
    import agent_core
    try:
        st = signed["statement"]
        return verify(bytes.fromhex(st["pubkey"]), agent_core.canon(st).encode("utf-8"), bytes.fromhex(signed["signature"]))
    except Exception:
        return False


def load_secret(path):
    with open(path, "r") as f:
        s = bytes.fromhex(f.read().strip())
    if len(s) != 32:
        raise ValueError("a key file holds 32 bytes as hex")
    return s


def keygen(path):
    """Write a new secret key (never overwrites); returns the public key hex."""
    s = new_secret()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(s.hex() + "\n")
    return public_key(s).hex()


def read_trusted(path):
    """A file of public keys, one hex per line, '# name' allowed (the same format attest.py reads)."""
    keys = set()
    with open(path, "r") as f:
        for ln in f:
            ln = ln.split("#", 1)[0].strip().lower()
            if len(ln) == 64 and all(c in "0123456789abcdef" for c in ln):
                keys.add(ln)
    return keys


# ---- signed heads of hash-chained files ---------------------------------------------------------------------------------------------------------------------
# A hash chain is not a signature: whoever holds the file can rewrite all of it consistently. A SIGNED HEAD is what a reader holds on to: "at length n the chain's head was H, signed by K".
# If the file is ever rewritten, an earlier signed head no longer appears in it, and that is detectable by anyone holding the statement, with no one having to watch continuously.

HEAD_FORMAT = "guldo-signed-head-v1"
CHAIN_START = "0" * 64


def sign_head(rows, secret, kind, now=None, field="h"):
    """`field` names the row key holding each entry's chain hash ('h' for ledgers and registers, 'hash' for a round's log)."""
    import time
    st = {"format": HEAD_FORMAT, "kind": kind, "n": len(rows), "head": rows[-1][field] if rows else CHAIN_START, "at": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    return sign_statement(st, secret)


def check_head(rows, signed, trusted, kind, field="h"):
    """(ok, message). The signature must verify under a key in `trusted`, and the file's chain must contain that head at that length (so the file has only been EXTENDED since)."""
    if not statement_ok(signed):
        return False, "the signed head has a bad signature"
    st = signed["statement"]
    if st.get("format") != HEAD_FORMAT or st.get("kind") != kind:
        return False, "not a signed head of this kind of file"
    if st.get("pubkey") not in set(trusted or []):
        return False, "the head is signed by a key you did not pin"
    n = st.get("n")
    if not (isinstance(n, int) and not isinstance(n, bool) and 0 <= n <= len(rows)):
        return False, "the file is SHORTER than the signed head says it was (truncated or replaced)"
    if (rows[n - 1][field] if n else CHAIN_START) != st.get("head"):
        return False, "the file does not contain the signed head at that position: the history was rewritten"
    return True, "ok: the file extends the signed head (length %d)" % n
