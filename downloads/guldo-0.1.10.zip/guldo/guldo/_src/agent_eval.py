"""Verifiable agent evaluation: the command line.

  python3 agent_eval.py domains
  python3 agent_eval.py checkdomain DOMAIN                          the compiler-style passes for an agent domain (determinism, seed dependence, junk rejected, no leak, controls)
  python3 agent_eval.py plan --domain D [--sizes ..] --n N --trials K (--seed FILE | --practice) --out PLAN.json     fix the test in advance; prints the plan hash to publish
  python3 agent_eval.py run --plan PLAN.json --agent SPEC --label NAME (--seed FILE | --practice) --out LADDER.jsonl [--allow-tools a,b] [--system FILE] [--resume] [--confirm-api-spend]
  python3 agent_eval.py verify LADDER (--seed FILE | --practice) [--plan PLAN.json --plan-hash HEX] [--no-replay]    re-derive, re-verify, recompute cost, replay tools, check the chain
  python3 agent_eval.py summary LADDER
  python3 agent_eval.py compare BASELINE CANDIDATE [--seed FILE | --practice] [--out CLAIM.json]    paired comparison on the same instances (verifies both ladders first if a seed is given)
  python3 agent_eval.py check CLAIM.json BASELINE CANDIDATE         recompute a comparison file: it must be identical
  python3 agent_eval.py claim CLAIM.json [--min-factor F] [--min-solve-rate R]
  python3 agent_eval.py selftest                                    the whole pipeline on the practice seed with scripted agents (free, a few seconds)

AGENT SPEC: scripted:lean | scripted:bare | scripted:cheat | scripted:lean:0.2 (fails 20% of trials) | compat:MODEL (any OpenAI-compatible server: OpenAI, vLLM, OpenRouter, Ollama, LM Studio...; the
endpoint comes from GULDO_COMPAT_BASE_URL / OPENAI_BASE_URL, the key from GULDO_COMPAT_API_KEY / OPENAI_API_KEY) | anthropic:MODEL (real API calls; costs money; seeagent_providers.py).
A practice run uses a PUBLIC seed: anyone can derive every instance, so it shows the method, not a certified number. A real round uses a secret seed, publishes the plan hash first,
and reveals the seed after the close. See AGENT_EVAL.md.
"""
import argparse
import json
import os
import sys
import tempfile

import agent_compare
import agent_core
import agent_harness
import agent_providers
import agent_domains_plus                                                            # noqa: F401  registers the extra domains (reconcile) without editing the pinned agent_core.py
from agent_core import AgentEvalError, canon, sha256_hex

PLAN_FORMAT = "guldo-agent-plan-v1"
TRUNCATION_RATIO = 0.6        # a provider's input count this far BELOW the harness's own is suspicious (see cmd_verify)
HEADER_KEYS = ("format", "domain", "version", "plan_hash", "commit", "sizes", "n_per_size", "trials", "budget", "counter", "practice", "source_hashes", "agent", "allow_tools", "system",
               "python_major_minor")
PY = "%d.%d" % sys.version_info[:2]


def _die(msg, code=2):
    print("error: " + msg, file=sys.stderr)
    sys.exit(code)


def _master(args):
    return agent_core.read_master(getattr(args, "seed", None), getattr(args, "practice", False))


def plan_hash(plan):
    return sha256_hex(canon(plan))


def build_plan(mod, master, sizes, n, trials, budget):
    allowed = agent_core.domain_sizes(mod)
    sizes = sizes or allowed
    for s in sizes:
        if s not in allowed:
            raise AgentEvalError("size %d is not in the domain's ladder %s" % (s, allowed))
    if n < 1 or trials < 1:
        raise AgentEvalError("--n and --trials must be at least 1")
    return {"format": PLAN_FORMAT, "domain": mod.NAME, "version": mod.VERSION, "sizes": sorted(set(sizes)), "n_per_size": n, "trials": trials,
            "budget": dict(agent_harness.DEFAULT_BUDGET, **budget), "commit": agent_core.commitment(master), "counter": agent_core.COUNTER,
            "practice": master == agent_core.PRACTICE_SEED, "source_hashes": agent_core.source_hashes(mod.NAME)}


# ---- domain checks (the compiler passes for an agent domain) ----------------------------------------------------------------------------------------------

def check_domain(mod, master=agent_core.PRACTICE_SEED):
    res = []

    def add(name, ok, detail=""):
        res.append((name, bool(ok), detail))
    for attr in ("NAME", "VERSION", "SIZE_RANGE", "SIZE_STEP", "derive", "prompt", "tool_specs", "make_env", "reference_answer", "verify"):
        if not hasattr(mod, attr):
            add("interface", False, "missing %s" % attr)
            return res
    add("interface", True)
    sizes = agent_core.domain_sizes(mod)
    ref_calls = getattr(mod, "reference_calls", lambda inst: [])

    def inst(size, idx, m=master):
        return agent_core.make_instance(mod, m, size, idx)
    ok = all(canon(inst(s, 0)) == canon(inst(s, 0)) for s in sizes)
    add("derive is deterministic", ok)
    other = b"another-seed-another-seed-xx"
    add("derive depends on the seed", all(canon(inst(s, 0)["public"]) != canon(inst(s, 0, other)["public"]) for s in sizes))
    add("derive depends on the index", all(canon(inst(s, 0)["public"]) != canon(inst(s, 1)["public"]) for s in sizes))
    bad = []
    for s in sizes:
        for i in range(3):
            it = inst(s, i)
            good, why = mod.verify(it, mod.reference_answer(it), ref_calls(it))
            if not good:
                bad.append("%d/%d: %s" % (s, i, why))
    add("the reference answer passes the verifier", not bad, "; ".join(bad[:3]))
    junk = [None, "", 0, -1, "junk", [], {}, [1, 2, 3], "def solve(xs):\n    return []\n", float("nan")]
    accepted = []
    for s in (sizes[0], sizes[-1]):
        it = inst(s, 0)
        for j in junk:
            try:
                good, _ = mod.verify(it, j, [])
            except Exception as e:
                add("verify never raises on junk", False, "%s on %r" % (type(e).__name__, j))
                return res
            if good:
                accepted.append("%d: %r" % (s, j))
    add("junk answers are rejected", not accepted, "; ".join(accepted[:3]))
    leak = []
    for s in sizes:
        it = inst(s, 0)
        ans = mod.reference_answer(it)
        pub = canon(it["public"]) + mod.prompt(it["public"])
        if isinstance(ans, str) and len(ans) >= 12 and ans in pub:
            leak.append("size %d: the reference answer is in the public view" % s)
        for t in it["private"].get("tests", [])[:5]:
            if canon(t["input"]) in canon(it["public"]):
                leak.append("size %d: a hidden test input is in the public view" % s)
    add("the public view does not leak the answer or the hidden tests", not leak, "; ".join(leak[:3]))
    coincide, total = 0, 0
    for s in sizes:
        a, b = inst(s, 0), inst(s, 1)
        total += 1
        good, _ = mod.verify(b, mod.reference_answer(a), ref_calls(a))
        coincide += 1 if good else 0
    add("one instance's solution does not solve another", coincide <= max(1, total // 4), "%d of %d" % (coincide, total))
    # controls: a cheating agent must earn ~0, a competent lean agent must solve what the tools allow
    ladder_hdr = None
    try:
        for style, lo_ok, hi_ok in (("cheat", 0.0, 0.2), ("lean", 1.0, 1.0)):
            agent = agent_providers.ScriptedAgent(mod.NAME, style, label="check-" + style)
            solved = total_n = 0
            for s in sizes:
                for i in range(2):
                    rec = agent_harness.run_trial(agent, mod, inst(s, i), trial=0)
                    solved += 1 if rec["solved"] else 0
                    total_n += 1
            rate = solved / float(total_n)
            add("control %s agent solves %.2f of instances" % (style, rate), lo_ok <= rate <= hi_ok, "expected %.1f..%.1f" % (lo_ok, hi_ok))
    except Exception as e:
        add("controls ran", False, "%s: %s" % (type(e).__name__, str(e)[:120]))
    return res


# ---- run -------------------------------------------------------------------------------------------------------------------------------------------------

def make_header(plan, spec, label, allow_tools, system):
    kind = "model" if agent_providers.is_real_model(spec) else "scripted"
    agent = {"label": label, "spec": spec, "kind": kind}
    if kind == "model":
        parts = spec.split(":")
        if parts[0] == "compat":
            agent["provider"] = "compat"
            agent["model"] = ":".join(parts[1:])                           # a model id may contain ':' (llama3.1:8b)
            agent["effort"] = None
        else:
            agent["provider"] = "anthropic"
            agent["model"] = parts[1] if len(parts) > 1 and parts[1] else "claude-opus-5-5"
            agent["effort"] = parts[2] if len(parts) > 2 and parts[2] else None
    return {"format": agent_core.FORMAT, "domain": plan["domain"], "version": plan["version"], "plan_hash": plan_hash(plan), "commit": plan["commit"], "sizes": plan["sizes"],
            "n_per_size": plan["n_per_size"], "trials": plan["trials"], "budget": plan["budget"], "counter": plan["counter"], "practice": plan["practice"],
            "source_hashes": plan["source_hashes"], "agent": agent, "allow_tools": sorted(allow_tools) if allow_tools is not None else None, "system": system,
            "python_major_minor": PY}


def cmd_run(args):
    master = _master(args)
    with open(args.plan, "r", encoding="utf-8") as f:
        plan = json.load(f)
    if plan.get("format") != PLAN_FORMAT or plan["commit"] != agent_core.commitment(master):
        _die("the plan is not in the right format or was made for a different seed")
    mod = agent_core.load_domain(plan["domain"])
    if plan["version"] != mod.VERSION or plan["source_hashes"] != agent_core.source_hashes(mod.NAME):
        _die("the plan's pinned files differ from the files here (the domain, core or harness changed since the plan was made); make a new plan")
    import agent_sandbox
    try:
        container = agent_sandbox.isolated(plan["domain"])
    except agent_sandbox.SandboxError as e:
        _die("GULDO_SANDBOX=docker is set but the sandbox does not work (%s); fix it or unset it: a broken sandbox would make every agent look like it failed" % e)
    if agent_core.runs_code(plan["domain"]) and not plan["practice"] and not args.accept_unsandboxed_code and not container:
        _die("the %s domain runs the agent's code" % plan["domain"] + " as THIS user on THIS machine, where the secret seed file is readable: hostile code could read it and derive every hidden test. "
             "Run in a container or VM that does not hold the seed file (pass it through a file descriptor or a mounted secret), then rerun with --accept-unsandboxed-code")
    if agent_providers.is_real_model(args.agent) and not args.confirm_api_spend:
        n = len(plan["sizes"]) * plan["n_per_size"] * plan["trials"]
        _die("this run makes up to %d trials, each up to %d turns of real model calls: it costs real money on a paid API (and real time and memory on a local model); "
             "rerun with --confirm-api-spend to go ahead" % (n, plan["budget"]["max_turns"]))
    allow = None if args.allow_tools is None else [t for t in args.allow_tools.split(",") if t]
    system = agent_harness.SYSTEM
    if args.system:
        with open(args.system, "r", encoding="utf-8") as f:
            system = f.read()
    agent = agent_providers.make_agent(args.agent, plan["domain"])
    label = args.label or args.agent
    agent.label = label if hasattr(agent, "label") else label
    header = make_header(plan, args.agent, label, allow, system)
    if getattr(agent, "endpoint", None):
        header["agent"]["endpoint"] = agent.endpoint                       # host:port only, never a credential
    part = args.out + ".part"
    done = {}
    if args.resume and os.path.exists(part):
        h, recs = agent_core.read_ladder(part)
        if canon(h) != canon(header):
            _die("the partial file's header differs from this run's: refusing to resume")
        done = {(r["size"], r["idx"], r["trial"]): r for r in recs}
    elif os.path.exists(part):
        _die("%s exists; use --resume to continue it, or delete it" % part)
    records = []
    mode = "a" if done else "w"
    with open(part, mode, encoding="utf-8") as pf:
        if not done:
            pf.write(canon(header) + "\n")
        total = len(plan["sizes"]) * plan["n_per_size"] * plan["trials"]
        for s in plan["sizes"]:
            for i in range(plan["n_per_size"]):
                instance = agent_core.make_instance(mod, master, s, i)
                for t in range(plan["trials"]):
                    if (s, i, t) in done:
                        records.append(done[(s, i, t)])
                        continue
                    rec = agent_harness.run_trial(agent, mod, instance, plan["budget"], t, allow, system)
                    records.append(rec)
                    pf.write(canon(rec) + "\n")
                    pf.flush()
                    print("[%d/%d] %s trial %d: %s, %d tokens, %d tool calls (%s)" % (len(records), total, rec["instance"], t, "solved" if rec["solved"] else "FAILED", rec["tokens"], rec["tool_calls"], rec["reason"]), file=sys.stderr)
    agent_core.write_ladder(args.out, header, records)
    served = getattr(agent, "served", None)
    if served and set(served) != {getattr(agent, "model", None)}:
        print("WARNING: the API reported serving %s but %r was asked for: a different model answered some calls (a fallback?); do not call this result %r's" % (dict(served), agent.model, agent.model), file=sys.stderr)
    if plan["practice"]:
        print("PRACTICE seed: anyone can derive every instance; this shows the method, not a certified number.")
    sm = agent_compare.summarize(header, records)
    print("wrote %s: %d/%d instances solved (95%% lower bound %.3f), median %s tokens on solved" % (args.out, sm["solved_instances"], sm["instances"], sm["solve_rate_lower95"], sm["median_tokens_on_solved"]))


# ---- verify ----------------------------------------------------------------------------------------------------------------------------------------------

def verify_ladder(path, master, plan=None, plan_hash_expected=None, replay=True):
    """Returns (problems, summary). problems empty = every record is internally consistent and correct as recorded."""
    header, records = agent_core.read_ladder(path)
    probs = []
    missing = [k for k in HEADER_KEYS if k not in header]
    if missing:
        return ["the header lacks %s" % ", ".join(missing)], None
    h = header["plan_hash"]
    if not (isinstance(h, str) and len(h) == 64 and all(c in "0123456789abcdef" for c in h)):
        probs.append("the header's plan hash is not a SHA-256 hex digest")
    if header["counter"] != agent_core.COUNTER:
        probs.append("the header's token counter %r is not %r" % (header["counter"], agent_core.COUNTER))
    try:
        mod = agent_core.load_domain(header["domain"])
    except (KeyError, TypeError, AgentEvalError):
        return ["the header names no known domain"], None
    if header.get("commit") != agent_core.commitment(master):
        return ["the seed does not match the ladder's commitment"], None
    if header.get("practice") is not (master == agent_core.PRACTICE_SEED):
        probs.append("the header's practice flag does not match the seed: a ladder made with the public practice seed must say so")
    if header.get("version") != mod.VERSION:
        probs.append("domain version differs from the files here")
    if header.get("source_hashes") != agent_core.source_hashes(mod.NAME):
        probs.append("the domain, core or harness files here differ from those the ladder was made with (the recheck uses the files here)")
    if plan is not None:
        if plan_hash(plan) != header.get("plan_hash"):
            probs.append("the plan file is not the plan this ladder was made under")
        for k in ("domain", "version", "sizes", "n_per_size", "trials", "budget", "commit", "counter", "practice"):
            if plan.get(k) != header.get(k):
                probs.append("the ladder's %s differs from the plan" % k)
    if plan_hash_expected is not None and plan_hash_expected != header.get("plan_hash"):
        probs.append("the ladder's plan hash is not the published one")
    shape_ok = True
    try:
        agent_compare.instances_of(header, records)
    except (agent_compare.CompareError, KeyError, TypeError, ValueError) as e:
        shape_ok = False
        probs.append(str(e) if isinstance(e, agent_compare.CompareError) else "malformed ladder (%s)" % type(e).__name__)
    import agent_blackbox
    blackbox = agent_blackbox.is_blackbox(header)           # a vendor's agent driven through the tool service: its own trial check, and no token cap (interaction tokens are not capped)
    for r in records:
        try:
            for p in (agent_blackbox.check_blackbox_trial if blackbox else agent_harness.check_trial)(r, mod, master, header, replay):
                probs.append("%s trial %s: %s" % (r.get("instance"), r.get("trial"), p))
            if not blackbox and r.get("tokens", 0) > header["budget"]["max_tokens"] and r.get("reason") != "over token budget":
                probs.append("%s: tokens over the cap but not ended as over budget" % r.get("instance"))
        except Exception as e:
            probs.append("%s trial %s: malformed record (%s)" % (r.get("instance"), r.get("trial"), type(e).__name__))
    summary = None
    if shape_ok and not probs:
        try:
            summary = agent_compare.summarize(header, records)
        except Exception as e:
            probs.append("malformed ladder (%s)" % type(e).__name__)
    return probs, summary


def cmd_verify(args):
    master = _master(args)
    try:
        if agent_core.runs_code(str(agent_core.read_ladder(args.ladder)[0].get("domain"))):
            print("warning: verifying a code-running (coding / bugfix) ladder EXECUTES the submitted code on this machine (the final answers, and with tool replay the run_tests calls); do it in a container or VM", file=sys.stderr)
    except AgentEvalError:
        pass
    plan = None
    if args.plan:
        with open(args.plan, "r", encoding="utf-8") as f:
            plan = json.load(f)
    probs, sm = verify_ladder(args.ladder, master, plan, args.plan_hash, not args.no_replay)
    if probs or sm is None:
        for p in probs[:40]:
            print("PROBLEM: " + p)
        print("%d problem(s): NOT verified" % len(probs))
        sys.exit(1)
    print("VERIFIED: every trial re-derived from the seed, every answer re-verified, every cost recomputed from its trajectory, %s" % ("every tool call replayed" if not args.no_replay else "tool replay skipped"))
    print("NOT shown: that this agent actually produced these trajectories (the operator could have written them); see the limits in AGENT_EVAL.md")
    _print_summary(sm)
    if sm["provider_over_proxy_tokens_median"] is not None:
        print("provider-reported tokens / proxy tokens (median over trials): %.2f  (a gap is the token-counting trust gap; see the limits)" % sm["provider_over_proxy_tokens_median"])
    lo = sm.get("provider_over_proxy_tokens_min")
    if lo is not None and lo < TRUNCATION_RATIO:
        print("WARNING: in at least one trial the provider counted only %.2fx the input tokens the harness sent. A provider normally counts MORE (chat template, tool definitions: 1.0-2.0x was seen on a "
              "real run), so this can mean the prompt was silently TRUNCATED to the model's context window (a local server's default is small): results from such trials are not about the task as posed."
              % lo)


def _print_summary(sm):
    print("agent %s: solved %d of %d instances (rate %.3f, 95%% one-sided lower bound %.3f); trial pass rate %.3f; median tokens on solved %s"
          % (sm["agent"], sm["solved_instances"], sm["instances"], sm["solve_rate"], sm["solve_rate_lower95"], sm["trial_pass_rate"], sm["median_tokens_on_solved"]))
    print("  difficulty-stratified: equal-weight solve rate >= %.3f, worst size >= %.3f (95%% simultaneous)" % (sm["solve_rate_stratified_lower95"], sm["worst_size_lower95"]))
    for row in sm["by_size"]:
        print("  size %-5d solved %d/%d  median tokens %s" % (row["size"], row["solved"], row["instances"], row["median_tokens_on_solved"]))


def render_comparison(res):
    L = []
    L.append("%s  (plan %s...%s)" % (res["domain"], res["plan_hash"][:12], "  PRACTICE SEED" if res["practice"] else ""))
    for who in ("baseline", "candidate"):
        sm = res[who]["summary"]
        L.append("%-9s %-24s solved %d/%d, 95%% lower bound %.3f, median tokens on solved %s" % (who, sm["agent"], sm["solved_instances"], sm["instances"], sm["solve_rate_lower95"], sm["median_tokens_on_solved"]))
    s = res["success"]
    L.append("success : candidate only %d, baseline only %d, both %d, neither %d; sign p %.2g -> %s" % (s["candidate_only"], s["baseline_only"], s["both"], s["neither"], s["sign_p_candidate_better"], s["verdict"]))
    c = res["cost"]
    if "mean_bits" in c:
        L.append("cost    : on %d instances both solved, the candidate used %.2fx %s tokens (mean %.2f bits, 95%% one-sided lower bound %.2f bits = %.2fx); %s"
                 % (c["both_solved"], 2 ** abs(c["mean_bits"]), "fewer" if c["mean_bits"] >= 0 else "more", c["mean_bits"], c["lower95_bits_one_sided"], c["factor_lower95"], c["verdict"]))
    else:
        L.append("cost    : " + c["verdict"])
    errs = {w: res[w]["summary"].get("agent_error_trials", 0) for w in ("baseline", "candidate")}
    if any(errs.values()):
        L.append("WARNING : trials that ended in an AGENT ERROR (baseline %d, candidate %d): usually the operator's infrastructure (a server error, a bad request, a timeout), not the model, yet they count as "
                 "failures. Read each record's `agent_error` before trusting this comparison: an adapter bug biased the first real run this way." % (errs["baseline"], errs["candidate"]))
    L.append("limits  : see the file; tokens are proxy tokens, not billed tokens; unsolved instances are excluded from the cost gap")
    return "\n".join(L)


def cmd_compare(args):
    bh, br = agent_core.read_ladder(args.baseline)
    ch, cr = agent_core.read_ladder(args.candidate)
    if args.seed or args.practice:
        master = _master(args)
        for path in (args.baseline, args.candidate):
            probs, _ = verify_ladder(path, master)
            if probs:
                _die("%s does not verify (%d problems, first: %s); not comparing" % (path, len(probs), probs[0]), 1)
    else:
        print("note: the ladders were NOT re-verified (no seed given); a certified comparison needs --seed after the reveal", file=sys.stderr)
    try:
        res = agent_compare.compare(bh, br, ch, cr)
    except agent_compare.CompareError as e:
        _die(str(e), 1)
    res["reverified"] = bool(args.seed or args.practice)
    print(render_comparison(res))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(json.dumps(res, indent=1, sort_keys=True) + "\n")
        print("wrote " + args.out)


def cmd_check(args):
    with open(args.claim, "r", encoding="utf-8") as f:
        claim = json.load(f)
    bh, br = agent_core.read_ladder(args.baseline)
    ch, cr = agent_core.read_ladder(args.candidate)
    res = agent_compare.compare(bh, br, ch, cr)
    res["reverified"] = claim.get("reverified")
    if json.loads(json.dumps(res)) == claim:
        print("CONFIRMED: the comparison recomputes identically from the two ladders")
    else:
        print("NOT CONFIRMED: the recomputed comparison differs from the file")
        sys.exit(1)


def cmd_claim(args):
    with open(args.claim, "r", encoding="utf-8") as f:
        res = json.load(f)
    rows = agent_compare.claim_check(res, args.min_factor, args.min_solve_rate, args.min_stratified_rate)
    if not rows:
        _die("give --min-factor, --min-solve-rate and/or --min-stratified-rate")
    ok = True
    for text, good in rows:
        print("%s: %s" % ("CONFIRMED" if good else "NOT CONFIRMED", text))
        ok = ok and good
    if res.get("practice"):
        print("(practice seed: this is a demonstration, not a certified result)")
    sys.exit(0 if ok else 1)


# ---- selftest --------------------------------------------------------------------------------------------------------------------------------------------

def cmd_selftest(args):
    mod = agent_core.load_domain("dataanalysis")
    master = agent_core.PRACTICE_SEED
    with tempfile.TemporaryDirectory(prefix="guldo-agent-selftest-") as tmp:
        plan = build_plan(mod, master, [200, 400], 6, 1, {})
        pp = os.path.join(tmp, "plan.json")
        json.dump(plan, open(pp, "w"))
        lad = {}
        for spec, label in (("scripted:bare", "bare"), ("scripted:lean", "harnessed")):
            out = os.path.join(tmp, label + ".jsonl")
            ns = argparse.Namespace(plan=pp, agent=spec, label=label, seed=None, practice=True, out=out, allow_tools=None, system=None, resume=False, confirm_api_spend=False)
            cmd_run(ns)
            probs, _ = verify_ladder(out, master)
            if probs:
                _die("selftest ladder %s failed verification: %s" % (label, probs[0]), 1)
            lad[label] = out
        bh, br = agent_core.read_ladder(lad["bare"])
        ch, cr = agent_core.read_ladder(lad["harnessed"])
        print(render_comparison(agent_compare.compare(bh, br, ch, cr)))
        print("selftest OK (scripted stand-in agents, practice seed: this shows the pipeline, not any model)")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def seedargs(p):
        p.add_argument("--seed", help="the secret master seed file")
        p.add_argument("--practice", action="store_true", help="use the public practice seed")
    sub.add_parser("domains")
    p = sub.add_parser("checkdomain")
    p.add_argument("domain")
    p = sub.add_parser("plan")
    p.add_argument("--domain", required=True)
    p.add_argument("--sizes", type=int, nargs="*")
    p.add_argument("--n", type=int, default=10)
    p.add_argument("--trials", type=int, default=1)
    p.add_argument("--max-tokens", type=int, default=agent_harness.DEFAULT_BUDGET["max_tokens"])
    p.add_argument("--max-tool-calls", type=int, default=agent_harness.DEFAULT_BUDGET["max_tool_calls"])
    p.add_argument("--max-turns", type=int, default=agent_harness.DEFAULT_BUDGET["max_turns"])
    p.add_argument("--max-nudges", type=int, default=0, help="how many times per trial a reply with no tool call is answered with one fixed reminder instead of ending the trial (default 0; real models "
                                                           "sometimes write 'submit 42' in prose). Part of the plan, so both arms of a comparison get the same.")
    p.add_argument("--max-wall-s", type=int, default=agent_harness.DEFAULT_BUDGET["max_wall_s"])
    p.add_argument("--out", required=True)
    g = p.add_argument_group("power check (agent_power.py): state the effect you expect BEFORE spending money; the plan reports its power for each claim you name")
    g.add_argument("--assume-p-cand", type=float, help="the candidate's assumed per-instance solve probability")
    g.add_argument("--assume-p-base", type=float, help="the baseline's assumed solve probability (for 'candidate solves more')")
    g.add_argument("--rho", type=float, default=0.0, help="assumed correlation of the two agents' outcomes on one instance (0 = independent: the conservative planning choice)")
    g.add_argument("--solve-claim", type=float, help="the solve-rate lower bound you intend to claim")
    g.add_argument("--assume-mean-bits", type=float, help="assumed mean log2(baseline tokens / candidate tokens) on instances both solve")
    g.add_argument("--assume-sd-bits", type=float)
    g.add_argument("--factor", type=float, default=2.0, help="the token-saving factor you intend to claim")
    g.add_argument("--assume-p-both", type=float, default=0.8, help="fraction of instances both agents solve")
    g.add_argument("--power", type=float, default=0.8)
    g.add_argument("--require-power", action="store_true", help="refuse to write the plan if any stated claim is underpowered")
    seedargs(p)
    p = sub.add_parser("run")
    p.add_argument("--plan", required=True)
    p.add_argument("--agent", required=True)
    p.add_argument("--label")
    p.add_argument("--out", required=True)
    p.add_argument("--allow-tools")
    p.add_argument("--system")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--confirm-api-spend", action="store_true")
    p.add_argument("--accept-unsandboxed-code", action="store_true", help="coding domain, real seed: you have isolated the seed file from the agent's code")
    seedargs(p)
    p = sub.add_parser("verify")
    p.add_argument("ladder")
    p.add_argument("--plan")
    p.add_argument("--plan-hash")
    p.add_argument("--no-replay", action="store_true")
    seedargs(p)
    p = sub.add_parser("summary")
    p.add_argument("ladder")
    p = sub.add_parser("compare")
    p.add_argument("baseline")
    p.add_argument("candidate")
    p.add_argument("--out")
    seedargs(p)
    p = sub.add_parser("check")
    p.add_argument("claim")
    p.add_argument("baseline")
    p.add_argument("candidate")
    p = sub.add_parser("claim")
    p.add_argument("claim")
    p.add_argument("--min-factor", type=float)
    p.add_argument("--min-solve-rate", type=float)
    p.add_argument("--min-stratified-rate", type=float, help="lower bound on the equal-weight-per-size solve rate (Bonferroni over sizes; stricter than the pooled bound)")
    sub.add_parser("selftest")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "domains":
            for n in agent_core.DOMAIN_NAMES:
                m = agent_core.load_domain(n)
                print("%-13s sizes %s  %s" % (n, agent_core.domain_sizes(m), m.DOC))
        elif args.cmd == "checkdomain":
            res = check_domain(agent_core.load_domain(args.domain))
            for name, ok, detail in res:
                print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  (" + detail + ")") if detail else ""))
            sys.exit(0 if all(ok for _, ok, _ in res) else 1)
        elif args.cmd == "plan":
            mod = agent_core.load_domain(args.domain)
            plan = build_plan(mod, _master(args), args.sizes, args.n, args.trials, {"max_tokens": args.max_tokens, "max_tool_calls": args.max_tool_calls, "max_turns": args.max_turns, "max_wall_s": args.max_wall_s,
                                                                                         "max_nudges": args.max_nudges})
            import agent_power
            report = agent_power.plan_report(len(plan["sizes"]) * plan["n_per_size"], args.power, args.assume_p_cand, args.solve_claim, args.assume_p_base, args.rho, args.assume_mean_bits,
                                             args.assume_sd_bits, args.factor, args.assume_p_both)
            for row in report:
                print("power: %.2f at %d instances (needs %s for %.0f%%) -- %s%s" % (row["power_at_plan"], len(plan["sizes"]) * plan["n_per_size"], row["needed_instances"], 100 * args.power, row["claim"],
                                                                                   "" if row["adequate"] else "   <-- UNDERPOWERED"))
            if args.require_power and (not report or not all(r["adequate"] for r in report)):
                _die("--require-power: %s; nothing written" % ("no claim was stated (give --solve-claim, --assume-p-base or --assume-mean-bits)" if not report else "a stated claim is underpowered at this size"), 1)
            if report:
                print("(power is computed from the assumptions you stated, which are guesses; a pilot's rates are noisy: see agent_power.py pilot)")
            with open(args.out, "w", encoding="utf-8") as f:
                f.write(json.dumps(plan, indent=1, sort_keys=True) + "\n")
            print("plan hash: " + plan_hash(plan))
            print("publish this hash BEFORE any entry exists; the plan fixes the sizes, the instance count, the caps, the seed commitment and the pinned code")
        elif args.cmd == "run":
            cmd_run(args)
        elif args.cmd == "verify":
            cmd_verify(args)
        elif args.cmd == "summary":
            h, r = agent_core.read_ladder(args.ladder)
            _print_summary(agent_compare.summarize(h, r))
        elif args.cmd == "compare":
            cmd_compare(args)
        elif args.cmd == "check":
            cmd_check(args)
        elif args.cmd == "claim":
            cmd_claim(args)
        elif args.cmd == "selftest":
            cmd_selftest(args)
    except (AgentEvalError, agent_compare.CompareError) as e:
        _die(str(e), 1)


if __name__ == "__main__":
    main()
