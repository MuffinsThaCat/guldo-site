"""Re-measure a stratified sample of a finished ladder SEQUENTIALLY and compare with the original (possibly concurrent)
timings, by baseline-cost bin. This is the direct check that --jobs K did not bias the timings of the HARD instances,
where long runs, sustained load and thermal throttling matter most (drift_check.py only covers short instances).

  python3 remeasure.py --ladder results/judged_gm_<tag>_baseline_baseline_bkz.py.jsonl --seed-file ~/judge-seeds/a.seed \
      --solver solvers/baseline_bkz.py [--per-bin 4]

Reports, per octave of the ORIGINAL cost, the median of log2(new cost / original cost). Near 0 = concurrency did not bias
the ladder. A systematic positive value means the concurrent run measured faster than sequential (or the reverse).
"""
import argparse
import json
import math
import os
import statistics

import families
import harness

FLOOR = 0.5


def octave(cost):
    return int(math.floor(math.log2(cost / FLOOR)))


def select_sample(records, per_bin):
    """Deterministic stratified sample: from each octave (original cost >= FLOOR, solved), `per_bin` records spread evenly
    over the records sorted by id."""
    bins = {}
    for r in records:
        if r["status"] == "solved" and r["cpu_net"] >= FLOOR:
            bins.setdefault(octave(r["cpu_net"]), []).append(r)
    out = []
    for k in sorted(bins):
        rs = sorted(bins[k], key=lambda r: r["id"])
        if len(rs) <= per_bin:
            out += rs
        else:
            step = len(rs) / per_bin
            out += [rs[int(i * step)] for i in range(per_bin)]
    return out


def compare(pairs):
    """pairs: [(original cpu_net, new cpu_net)] -> {octave: (n, median log2 ratio, sd)} plus an 'all' entry."""
    by = {}
    for old, new in pairs:
        by.setdefault(octave(old), []).append(math.log2(new / old))
    out = {k: (len(v), statistics.median(v), statistics.pstdev(v)) for k, v in sorted(by.items())}
    allv = [x for v in by.values() for x in v]
    if allv:
        out["all"] = (len(allv), statistics.median(allv), statistics.pstdev(allv))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ladder", required=True)
    ap.add_argument("--seed-file", required=True)
    ap.add_argument("--solver", required=True)
    ap.add_argument("--per-bin", type=int, default=4)
    a = ap.parse_args()
    with open(a.ladder) as f:
        meta = json.loads(f.readline())
        records = [json.loads(line) for line in f]
    with open(a.seed_file, "rb") as f:
        master = f.read().strip()
    sample = select_sample(records, a.per_bin)
    print(f"original ladder jobs={meta.get('jobs', 1)}; re-measuring {len(sample)} instances sequentially", flush=True)
    overhead = meta["overhead"]  # the SAME no-op overhead the original ladder subtracted, so the comparison is like-for-like
    pairs = []
    for r in sample:
        dim, idx = map(int, r["id"].split(":"))
        new = harness.run_one(os.path.abspath(a.solver), families.derive(meta["family"], master, dim, idx), meta["budget"])
        if new["status"] != "solved":
            print(f"  {r['id']}: not solved on re-measurement ({new['status']}); skipped")
            continue
        net = max(new["cpu"] - overhead, 1e-3)
        pairs.append((r["cpu_net"], net))
        print(f"  {r['id']:>7s}  original {r['cpu_net']:8.2f}s  sequential {net:8.2f}s  {math.log2(net / r['cpu_net']):+.3f} bits", flush=True)
    print("\nlog2(sequential / original) by original-cost octave [0.5*2^k s]:")
    for k, (n, med, sd) in compare(pairs).items():
        print(f"  {str(k):>4s}: n={n:2d}  median {med:+.3f} bits  sd {sd:.3f}")


if __name__ == "__main__":
    main()
