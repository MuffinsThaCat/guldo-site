"""Factoring baseline: Pollard's rho with Floyd cycle detection and a gcd on EVERY step. Textbook, deterministic."""
from math import gcd


def solve(n):
    if n % 2 == 0:
        return 2
    c = 1
    while True:
        x = y = 2
        d = 1
        while d == 1:
            x = (x * x + c) % n
            y = (y * y + c) % n
            y = (y * y + c) % n
            d = gcd(abs(x - y), n)
        if d != n:
            return d
        c += 1  # the walk collided modulo n itself: retry with another polynomial
