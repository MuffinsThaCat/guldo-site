# guldo

Command-line client and tools for verifiable speedup claims. One command, `guldo`.

    pipx install guldo-cli             # or, in a virtual environment: pip install guldo-cli. The command it installs is `guldo`.
    guldo --help                       # the client: practice, submit, status, verify, certificate, rounds, receipts
    guldo tools                        # the other tools: claims, counted, attest, cert, compile, ops, lint, judge, log

    guldo lint my_solver.py --family factor
    guldo practice my_solver.py --family factor --count --dims 38 40 42        # prints the plan; add --yes to run it (exact step counting, Python 3.12+)
    guldo verify my.cert.json --rerun all --execute                            # re-execute everything: runs the certificate's solvers, use a throwaway VM
    guldo claims correctness my.cert.json

Needs Python 3.9+ (step counting needs 3.12+) and numpy. `pip install "guldo-cli[attest]"` adds signatures (needed to check or witness the public certificate log); `[lattice]` adds fpylll for the lattice problems.
Install with pipx or in a virtual environment: some commands write under the package directory.

## The public certificate log

Verified certificates are published in an append-only, witnessed log at https://guldo.org/log. Its public key is below so you can pin it from a place other than the site that serves the log:

    origin   guldo.org/log
    log key  5f544602190d928762debb21148d28cab881b1e926c56d1a57dfea95b905afb3

    pip install "guldo-cli[attest]"
    guldo log check --log https://guldo.org/log --log-key 5f544602190d928762debb21148d28cab881b1e926c56d1a57dfea95b905afb3 --recheck

Its one witness is run by the operator, so it shows append-only behaviour only to someone who trusts the operator; independent witnesses are being sought (`WITNESS.md` in the package says how to be one). Until then three things make a rewritten past provable, none of them a witness:

    guldo log check --log https://guldo.org/log --log-key 5f544602190d928762debb21148d28cab881b1e926c56d1a57dfea95b905afb3 --remember ~/.guldo-seen.json
    guldo log anchor-verify --log https://guldo.org/log --log-key 5f544602190d928762debb21148d28cab881b1e926c56d1a57dfea95b905afb3
    guldo log archive-check --log https://guldo.org/log --log-key 5f544602190d928762debb21148d28cab881b1e926c56d1a57dfea95b905afb3

`--remember` keeps the last head you saw and fails if the log was rolled back or rewritten since (with a file that proves it to anyone). `anchor-verify` checks the log's Bitcoin timestamps against two block explorers. `archive-check` checks the Internet Archive's own copies of the head. `LOG.md` has the design, the threat model and what the log does not show.

Nothing in this package is official, and parts of it (step counting, counted rounds, claims) pass their own tests but have not been used in a real round: read
`COMPILER.md` and `SUBMIT.md` in the package (`guldo/_src/`) for what each result does and does not show.
