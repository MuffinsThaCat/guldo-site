"""Compiler for the four declaration KINDS that are not speed challenges (see NONFITTING.md): a declaration with  KIND = "advantage" | "oracle" | "precomp" | "quantum".

    advantage   distinguishing: the solver guesses 0/1; scored by the exact binomial advantage (advantage_core.py)
    oracle      interactive: solve(oracle, *args); scored by counted queries (oracle_core.py)
    precomp     preprocess(public) once, solve(state, *args) per instance; scored by amortised counted steps (precomp_core.py)
    quantum     the solver returns a Clifford+T circuit; exact simulation, scored by gate/T/oracle count (qcircuit_core.py)

Like a quality challenge, such a domain is deliberately NOT registered as a speed family (its compiled.json has another format, so declared.load_all leaves it out): the judge, harness and
portal would rank it by the clock. compile_domain.py check / compile / show / status route here; the rest is this module's own CLI (`python3 compile_kinds.py --help`, `guldo kinds --help`):

    evaluate DIR SOLVER --seed HEX --n N --out LADDER    run a solver on a seed's instances, write a ladder (JSON lines; never overwrites)
    score DIR LADDER...                                  advantage: the credit (one ladder per committed seed; the minimum counts). Re-derives every instance: only the guesses are trusted
    compare DIR REF_LADDER SUB_LADDER                    the other kinds: per-size cost ratio in bits, solved counts. DESCRIPTIVE: not the calibrated lower bound of a speed certificate
    credit DIR --pair REF SUB [--pair REF SUB ...]       the other kinds: a PROVISIONAL credit in bits (bootstrap lower bound of the mean log2 cost ratio over the declared reference,
                                                         minimum over seeds; CREDIT_CAVEATS says what is unmeasured about it)
    replay DIR SOLVER LADDER [--sample K [--sample-seed S]]   re-run records and demand identical answers/costs (oracle: transcript replay; precomp: state hash + steps; quantum: circuit hash);
                                                         a sample is chosen by a fresh random seed that is printed, never by anything the ladder's author controls

What this does NOT do: sign, log or certify (no certificate format for these kinds yet), run in the Docker sandbox, or make a round (kind_rounds.py does that, untested). Solvers run under count_runner's restricted subset, unsandboxed,
as in a counted round: READ a submission first. The scope notes of NONFITTING.md ("toy parameters", "the oracle is a model", "not a quantum speedup") belong in anything you publish from these records.
"""
import argparse
import hashlib
import json
import math
import os
import random
import re
import shutil
import stat
import statistics
import sys

import advantage_core as AC
import compile_domain as CD
import declared
import instances
import oracle_core as OC
import precomp_core as PC
import qcircuit_core as QC
import quality_core as Q

HERE = os.path.dirname(os.path.abspath(__file__))
KINDS = ("advantage", "oracle", "precomp", "quantum")
FORMAT = "svp-compiled-kind-v1"       # NOT declared.FORMAT, on purpose: declared.load_all refuses to register the domain as a speed family
LADDER_FORMAT = "svp-kind-ladder-v1"
EXAMPLES = {"advantage": "advantage_examples/lwedist", "oracle": "oracle_examples/bisect", "precomp": "precomp_examples/tabledl", "quantum": "quantum_examples/grover"}
SEEDS = 3
ADV_STEP_BUDGET = 50_000_000          # counted steps per instance for a distinguisher (about 50 "counted seconds")
ADV_TARGET_DEFAULT = 0.5              # the advantage the ladder is sized to certify at 80% power (declaration may set ADVANTAGE_TARGET)
QUANTUM_GATE_UNIT = 100               # gates that count as one "second" of cost
QUANTUM_GATE_CAP = 20000
N_DEFAULT = 12
MAX_N = 2000
CAVEATS = {
    "advantage": ["a distinguisher is not a key-recovery attack", "toy parameters: the claim is at these sizes only", "the declaration's real/random distributions are the operator's to read"],
    "oracle": ["the oracle is the declaration's MODEL of a leak or service, not a measurement of any device", "query counts are exact; time is not scored", "toy parameters"],
    "precomp": ["memory is bounded by the state size cap and (Linux only) a 2 GiB address-space limit; a table built and used inside one phase is not stored", "steps are not time", "the claim holds at the declared horizon"],
    "quantum": ["an exact resource count of one circuit at toy size: no quantum speedup, noise or hardware claim", "Clifford+T only: no arbitrary rotation angles"],
}


def packaged():
    """True when run through the installed `guldo` command (the package's dispatcher sets argv[0] to "guldo TOOL"): hints then name `guldo ...`, which is all such a user has."""
    return os.path.basename(sys.argv[0]).startswith("guldo")


def cmd(tool, rest=""):
    """The command line to show for `tool` ('compile' = compile_domain.py, 'kinds' = this file)."""
    if packaged():
        return f"guldo {tool} {rest}".strip()
    return f"python3 {'compile_domain.py' if tool == 'compile' else 'compile_kinds.py'} {rest}".strip()


def kind_of(mod):
    k = getattr(mod, "KIND", None)
    return k if k in KINDS else None


def load(dirpath):
    """declared.load_declaration, plus the simulator for a quantum declaration (its verify() uses the name QC, so the declaration needs no import)."""
    mod = declared.load_declaration(dirpath)
    if kind_of(mod) == "quantum":
        mod.QC = QC
    return mod


def sizes_of(mod):
    lo, hi = mod.SIZE_RANGE
    step = getattr(mod, "SIZE_STEP", 1)
    count = (hi - lo) // step + 1       # never materialise the range: a hostile SIZE_RANGE = (1, 10**9) would exhaust memory at compile time
    if count <= 5:
        return [lo + i * step for i in range(count)]
    return sorted({lo + round(i * (count - 1) / 4) * step for i in range(5)})   # the same five sizes list(range(...))[round(i*(count-1)/4)] picked before


def make_instance(mod, master, size, idx):
    x = mod.derive(master, size, idx)
    x["id"], x["dim"] = f"{size}:{idx}", size
    return x


def settings(mod):
    """-> the compiled plan's per-kind settings; raises CD.CompileError on a malformed one."""
    k = kind_of(mod)
    out = {"kind": k}
    try:
        if k == "oracle":
            b, u = OC.settings(mod)
            out.update({"query_budget": b, "query_unit": u})
        elif k == "precomp":
            h, m = PC.settings(mod)
            out.update({"horizon": h, "state_max_bytes": m})
        elif k == "quantum":
            q = getattr(mod, "QUBITS", None)
            s = getattr(mod, "SUCCESS", 2 / 3)
            g = getattr(mod, "ORACLE_GATE_COST", 1)
            if not (isinstance(q, int) and not isinstance(q, bool) and 1 <= q <= QC.MAX_QUBITS):
                raise ValueError(f"QUBITS must be an integer 1..{QC.MAX_QUBITS}")
            if not (isinstance(s, (int, float)) and not isinstance(s, bool) and 0.5 < s <= 1):
                raise ValueError("SUCCESS must be a number in (0.5, 1]")
            if not (isinstance(g, int) and not isinstance(g, bool) and 1 <= g <= 1000):
                raise ValueError("ORACLE_GATE_COST must be an integer 1..1000")
            out.update({"qubits": q, "success": s, "oracle_gate_cost": g})
        else:
            t = getattr(mod, "ADVANTAGE_TARGET", ADV_TARGET_DEFAULT)
            if not (isinstance(t, (int, float)) and not isinstance(t, bool) and 0.05 <= t <= 1):
                raise ValueError("ADVANTAGE_TARGET must be a number in [0.05, 1]")
            out.update({"advantage_target": float(t), "step_budget": ADV_STEP_BUDGET})
        n = getattr(mod, "N_PER_SIZE", None)
        if n is not None and not (isinstance(n, int) and not isinstance(n, bool) and 2 <= n <= MAX_N and n % 2 == 0):
            raise ValueError(f"N_PER_SIZE, if given, must be an even integer 2..{MAX_N}")
    except ValueError as e:
        raise CD.CompileError(str(e))
    return out


def plan_n(mod, st, n_sizes):
    """Instances per size. advantage: from the exact power rule (a seed holds n_sizes * n instances); the rest: N_PER_SIZE or 12."""
    n = getattr(mod, "N_PER_SIZE", None)
    if n:
        return n
    if st["kind"] != "advantage":
        return N_DEFAULT
    need = AC.instances_needed(st["advantage_target"], 0.8, AC.ALPHA, SEEDS, cap=MAX_N * n_sizes)
    if need is None:
        raise CD.CompileError(f"no instance count up to {MAX_N * n_sizes} per seed certifies advantage {st['advantage_target']}: lower ADVANTAGE_TARGET")
    per = math.ceil(need / n_sizes)
    return min(MAX_N, per + per % 2)


# ------------------------------------------------------------------------------------------------------------- running a solver on one instance
def _eval_one(mod, st, solver, inst, size):
    """-> one ladder record (see the kind's section of NONFITTING.md). Costs are in 'counted seconds' (cpu / cpu_net), floors as in every ladder."""
    k = st["kind"]
    if k == "oracle":
        rec = OC.evaluate(mod, solver, inst)
        return rec
    if k == "quantum":
        r = PC._count(solver, list(inst["args"]), PC.STEP_LIMIT, "solve")
        rec = {"id": inst["id"], "dim": inst["dim"], "steps": r["steps"]}
        cost, status = QUANTUM_GATE_CAP, "crash"
        if r["status"] == "ok":
            ans = r["ans"]
            try:
                ev = QC.evaluate_circuit(ans, st["qubits"], st["qubits"], range(1 << st["qubits"]), st["success"], st["oracle_gate_cost"])
                rec.update({"gates": ev["costs"]["gates"], "t_count": ev["costs"]["t_count"], "oracle_calls": ev["costs"]["oracle_calls"], "min_probability": ev["min_probability"],
                            "circuit_sha256": ev["circuit_sha256"], "circuit": ans})
                status = "solved" if ev["ok"] else "wrong"
                cost = ev["costs"]["gates"] if ev["ok"] else QUANTUM_GATE_CAP
            except QC.CircuitError as e:
                status, rec["err"] = "wrong", str(e)[:200]
        elif r["status"] in ("limit", "timeout"):
            status = "timeout"
        else:
            rec["err"] = r["err"]
        rec["status"] = status
        rec["cpu"] = rec["cpu_net"] = max(cost / QUANTUM_GATE_UNIT, 1e-3)
        return rec
    # advantage: one counted run, the guess is scored later from the guess itself
    r = PC._count(solver, list(inst["args"]), st["step_budget"], "solve")
    rec = {"id": inst["id"], "dim": inst["dim"], "steps": r["steps"], "guess": r["ans"] if r["status"] == "ok" and _isint(r["ans"]) else None}   # only an int is ever stored: NaN or a list would put non-standard JSON in a ladder
    if r["status"] == "ok":
        try:
            ok = bool(mod.verify(inst, r["ans"]))
        except Exception:
            ok = False
        rec["status"] = "solved" if ok and _isint(r["ans"]) and r["ans"] == inst["planted"] else ("failed" if r["ans"] is None else "wrong")   # _isint: True == 1, but only an int is a guess (and only an int is stored)
        used = r["steps"]
    else:
        rec["status"] = "timeout" if r["status"] in ("limit", "timeout") else "crash"
        used = st["step_budget"]
        rec["err"] = r["err"]
    rec["cpu"] = rec["cpu_net"] = max(used / PC.STEPS_PER_UNIT, 1e-3)
    return rec


def run_ladder(mod, st, solver, master, sizes, n):
    """-> (header, [record]). precomp preprocesses once per size; the others are one run per instance."""
    sha = file_sha256(solver)
    header = {"meta": True, "format": LADDER_FORMAT, "kind": st["kind"], "name": mod.NAME, "version": mod.VERSION, "commit": instances.commit(master), "solver": os.path.basename(solver),
              "solver_sha256": sha, "practice": instances.commit(master) == instances.commit(instances.PRACTICE_SEED), "sizes": sizes, "n": n, "python": sys.version.split()[0], "settings": st}
    recs = []
    if st["kind"] == "precomp":
        header["pre"] = {}
        for s in sizes:
            h, rs = PC.evaluate_size(mod, solver, master, s, n)
            header["pre"][str(s)] = h
            recs += rs
    else:
        for s in sizes:
            for i in range(n):
                recs.append(_eval_one(mod, st, solver, make_instance(mod, master, s, i), s))
    return header, recs


def write_ladder(path, header, recs):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)   # never overwrites
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps(header, sort_keys=True) + "\n")
        for r in recs:
            f.write(json.dumps(r, sort_keys=True) + "\n")


def read_regular(path, max_bytes):
    """The bytes of a REGULAR file of at most max_bytes, else a CompileError. Opened O_NONBLOCK (a FIFO would otherwise block the open for ever) and judged by fstat of the opened file
    (a symlink to /dev/zero reports size 0 and would otherwise be read without end). Found by probing: both hung the readers before this."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
    except OSError as e:
        raise CD.CompileError(f"cannot open {path}: {e.strerror}")
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            raise CD.CompileError(f"{path} is not a regular file")
        if st.st_size > max_bytes:
            raise CD.CompileError(f"{path} is larger than {max_bytes} bytes")
        with os.fdopen(fd, "rb", closefd=False) as f:
            data = f.read(max_bytes + 1)
        if len(data) > max_bytes:
            raise CD.CompileError(f"{path} is larger than {max_bytes} bytes")
        return data
    finally:
        os.close(fd)


def file_sha256(path, max_bytes=16 << 20):
    return hashlib.sha256(read_regular(path, max_bytes)).hexdigest()


def read_ladder(path, max_bytes=256 << 20):
    try:
        lines = [json.loads(ln) for ln in read_regular(path, max_bytes).decode("utf-8").splitlines() if ln.strip()]
    except (ValueError, RecursionError) as e:   # UnicodeDecodeError and JSONDecodeError are ValueErrors
        raise CD.CompileError(f"{path} is not a readable ladder ({type(e).__name__})")
    if not lines or not isinstance(lines[0], dict) or lines[0].get("format") != LADDER_FORMAT:
        raise CD.CompileError(f"{path} is not a {LADDER_FORMAT} ladder")
    return lines[0], lines[1:]


# ------------------------------------------------------------------------------------------------------------- validation
def validate(mod, dirpath, ref, quick=False):
    """The kind's checks as PASS/WARN/FAIL results (compile_domain.R). Runs the declaration and the reference locally: read a stranger's declaration first."""
    k = kind_of(mod)
    out = []
    try:
        st = settings(mod)
    except CD.CompileError as e:
        return [CD.R("settings", "fail", str(e))]
    sizes = sizes_of(mod)
    lo, hi = sizes[0], sizes[-1]
    master, master2 = b"svp-kinds-validate-A", b"svp-kinds-validate-B"
    out.append(CD.R("kind", "pass", f"{k}; sizes {sizes}"))

    def guarded(name, fn):
        try:
            fn()
        except CD.CompileError as e:
            out.append(CD.R(name, "fail", str(e)))
        except Exception as e:   # the author's code can raise anything
            out.append(CD.R(name, "fail", f"{type(e).__name__}: {e}"))

    def shape():
        for s in sizes:
            for i in range(2):
                x = mod.derive(master, s, i)
                if not isinstance(x, dict) or not isinstance(x.get("args"), (list, tuple)) or "planted" not in x:
                    raise CD.CompileError(f"derive({s}, {i}) must return a dict with an 'args' list and a 'planted' value")
                if len(json.dumps({"args": x["args"]}, allow_nan=False)) > (1 << 20):
                    raise CD.CompileError(f"the arguments at size {s} exceed 1 MiB")
        out.append(CD.R("shape", "pass", "args are JSON lists, 'planted' present"))
    guarded("shape", shape)
    if any(r["status"] == "fail" for r in out):
        return out

    def determinism():
        mid = sizes[len(sizes) // 2]
        for s in sizes:
            if CD.canon(mod.derive(master, s, 0)) != CD.canon(mod.derive(master, s, 0)):
                raise CD.CompileError(f"derive({s}, 0) returned different instances on two calls")
        key = lambda m, s, i: CD.canon({"args": mod.derive(m, s, i)["args"], "planted": mod.derive(m, s, i)["planted"]})   # noqa: E731  (an oracle instance is its secret: args alone can be identical)
        if k == "quantum":   # the instance space is the 2^QUBITS marked items: 8 draws would collide, so only purity is checked
            out.append(CD.R("determinism", "pass", "pure in (master, size, index); a quantum instance is its marked item, so index/seed dependence is not tested"))
            return
        if len({key(master, mid, i) for i in range(8)}) < 7:
            raise CD.CompileError("instances do not depend on the index")
        if sum(key(master, mid, i) != key(master2, mid, i) for i in range(4)) < 3:
            raise CD.CompileError("instances do not depend on the master seed: the commitment would commit to nothing")
        out.append(CD.R("determinism", "pass", "pure in (master, size, index); distinct across indices; seed-dependent"))
    guarded("determinism", determinism)

    def purity():
        picks = [[master.hex(), s, i] for s in sizes for i in range(2)]
        mine = [mod.derive(master, s, i) for _, s, i in picks]
        for seed in (1, 2):
            theirs = CD._pure_subprocess(os.path.join(os.path.abspath(dirpath), declared.DECL), picks, seed)
            for a, b, p in zip(mine, theirs, picks):
                if CD.canon({kk: a[kk] for kk in b}) != CD.canon(b):
                    raise CD.CompileError(f"derive({p[1]}, {p[2]}) differs between interpreters (PYTHONHASHSEED={seed})")
        out.append(CD.R("process purity", "pass", "identical instances in fresh interpreters with two hash seeds"))
    guarded("process purity", purity)   # derive() only: a quantum declaration's QC (injected by load()) is used in verify(), which the subprocess never calls, so this check applies to every kind

    junk = [j for j in CD.JUNK]

    def junk_check(accept_ok=()):
        x = make_instance(mod, master, lo, 0)
        raised = set()
        for j in junk:
            if any(j is a or (type(j) == type(a) and j == a) for a in accept_ok):
                continue
            try:
                if mod.verify(x, j):
                    raise CD.CompileError(f"verify() ACCEPTED {j!r}: an answer space that small is guessable")
            except CD.CompileError:
                raise
            except Exception as e:
                raised.add(type(e).__name__)
        out.append(CD.R("junk rejected", "warn" if raised else "pass", f"verify() raised {sorted(raised)} on junk (return False instead)" if raised else "verify() rejected every junk answer"))

    def balance():
        n = 48
        for s in sizes:
            for m in (master, master2, b"svp-kinds-validate-C"):
                ones = sum(int(mod.derive(m, s, i)["planted"]) for i in range(n))
                if not all(mod.derive(m, s, i)["planted"] in (0, 1) for i in range(4)) or ones != n // 2:
                    raise CD.CompileError(f"size {s}: {ones} of {n} instances have coin 1 (exactly {n // 2} are needed: pair the instances, see advantage_core.pair_coin), so a constant answer would score above chance")
        x = make_instance(mod, master, lo, 0)
        if not (mod.verify(x, 0) and mod.verify(x, 1)):
            raise CD.CompileError("verify() must accept 0 and 1 (a well-formed guess); correctness is judged against 'planted'")
        out.append(CD.R("balance", "pass", f"exactly half of 48 instances have coin 1, at every size and 3 seeds"))
        junk_check(accept_ok=(0, 1))

    def reference_runs():
        n = 4 if quick else 8
        if k == "advantage":
            acc = []
            for s in sizes:
                recs = [_eval_one(mod, st, ref, make_instance(mod, master, s, i), s) for i in range(2 * n)]
                if any(r["status"] in ("crash", "timeout") for r in recs):
                    raise CD.CompileError(f"the reference crashed or exceeded the step budget at size {s}: {next(r for r in recs if r['status'] in ('crash', 'timeout')).get('err', '')[:200]}")
                acc.append(sum(r["status"] == "solved" for r in recs) / len(recs))
            out.append(CD.R("reference runs", "pass", "accuracy by size: " + ", ".join(f"{s}: {a:.2f}" for s, a in zip(sizes, acc)) + f" ({2 * n} instances each; 0.50 = guessing)"))
            if min(acc) > 0.85:
                out.append(CD.R("baseline strength", "warn", "the reference already distinguishes well: a solver can earn little over it. State in REFERENCE_NOTE what it is"))
        elif k == "oracle":
            hashes = []
            for s in sizes:
                for i in range(2):
                    inst = make_instance(mod, master, s, i)
                    rec = OC.evaluate(mod, ref, inst)
                    if rec["status"] != "solved":
                        raise CD.CompileError(f"the reference did not solve size {s} instance {i} within {st['query_budget']} queries (status {rec['status']}: {rec.get('err', '')[:150]})")
                    again = OC.evaluate(mod, ref, inst)
                    if again["transcript_sha256"] != rec["transcript_sha256"] or again["steps"] != rec["steps"]:
                        raise CD.CompileError("the reference is not deterministic: two runs on one instance gave different transcripts or step counts")
                    hashes.append(rec["queries"])
            out.append(CD.R("reference solves", "pass", f"solved every instance tried; queries {min(hashes)}..{max(hashes)}; two runs gave identical transcripts"))

            def hostile_queries():
                inst = make_instance(mod, master, lo, 0)
                fn = OC.live_oracle(mod, inst)
                for q in (None, "x", [], {}, -1, 1.5, 10 ** 30, [[1]], True):
                    r = fn(q)
                    json.dumps(r)
                out.append(CD.R("oracle robustness", "pass", "malformed queries are answered (null) without raising and replies are JSON"))
            guarded("oracle robustness", hostile_queries)
        elif k == "precomp":
            for s in sizes:
                pub = mod.public(master, s)
                if CD.canon(pub) != CD.canon(mod.public(master, s)):
                    raise CD.CompileError(f"public({s}) is not deterministic")
                json.dumps(pub, allow_nan=False)
                x = mod.derive(master, s, 0)
                big = {v for v in CD._leaves(x["planted"]) if isinstance(v, int) and not isinstance(v, bool) and abs(v) >= 1 << 16}
                if big & set(CD._leaves(pub)):
                    raise CD.CompileError(f"public({s}) contains part of an instance's answer")
            for s in sizes[:2]:
                h, recs = PC.evaluate_size(mod, ref, master, s, 3)
                if h["pre_status"] != "ok" or any(r["status"] != "solved" for r in recs):
                    raise CD.CompileError(f"the reference did not solve size {s} (preprocessing {h['pre_status']}, statuses {[r['status'] for r in recs]})")
            out.append(CD.R("reference solves", "pass", f"solved 3 instances at each of sizes {sizes[:2]}; public() is deterministic and does not contain an answer"))
        else:
            for s in sizes:
                rec = _eval_one(mod, st, ref, make_instance(mod, master, s, 0), s)
                if rec["status"] != "solved":
                    raise CD.CompileError(f"the reference circuit was not accepted at size {s} (status {rec['status']}: {rec.get('err', '')[:200]}); min probability {rec.get('min_probability')}")
            out.append(CD.R("reference solves", "pass", f"the reference circuit meets success >= {st['success']:.3f} for every marked value; {rec['gates']} gates, {rec['t_count']} T, {rec['oracle_calls']} oracle calls"))
    if k == "advantage":
        guarded("balance", balance)
    else:
        guarded("junk rejected", junk_check)
    if not any(r["status"] == "fail" for r in out):
        guarded("reference", reference_runs)
    return out


# ------------------------------------------------------------------------------------------------------------- compile
def compiler_sha256():
    h = hashlib.sha256()
    for fn in ("compile_kinds.py", "advantage_core.py", "oracle_core.py", "oracle_runner.py", "precomp_core.py", "qcircuit_core.py"):
        with open(os.path.join(HERE, fn), "rb") as f:
            h.update(fn.encode() + b"\0" + f.read() + b"\0")
    return h.hexdigest()


def freshness_problems(dirpath, mod, compiled):
    """Why `compiled` cannot be trusted for the declaration on disk (empty = fresh)."""
    if compiled is None:
        return ["not compiled (no readable compiled.json)"]
    out = []
    if compiled.get("format") != FORMAT:
        out.append(f"compiled.json has format {compiled.get('format')!r}, expected {FORMAT!r}")
    if compiled.get("name") != mod.NAME:
        out.append("compiled.json is for a different NAME")
    if compiled.get("kind") != kind_of(mod):
        out.append("KIND changed since it was compiled")
    if compiled.get("version") != mod.VERSION:
        out.append(f"VERSION changed ({compiled.get('version')!r} -> {mod.VERSION!r})")
    if compiled.get("decl_sha256") != declared.sha256_file(os.path.join(dirpath, declared.DECL)):
        out.append("decl.py changed since it was compiled")
    try:
        if compiled.get("reference_sha256") != declared.sha256_file(declared.reference_path(dirpath, mod)):
            out.append("the reference solver changed since it was compiled")
    except declared.DeclarationError as e:
        out.append(str(e))
    return out


def compile_dir(dirpath, quick=False):
    dirpath = os.path.abspath(dirpath)
    mod = load(dirpath)
    ref = declared.reference_path(dirpath, mod)
    _, _, parsed = CD.parse(dirpath)
    results = [r for r in parsed if r["check"] != "declaration"]
    if kind_of(mod) is None:
        raise CD.CompileError(f"KIND must be one of {', '.join(KINDS)}")
    results += validate(mod, dirpath, ref, quick=quick)
    bad = [r for r in results if r["status"] == "fail"]
    if bad:
        raise CD.CompileError("; ".join(f"{r['check']}: {r['detail']}" for r in bad))
    st = settings(mod)
    sizes = sizes_of(mod)
    n = plan_n(mod, st, len(sizes))
    plan = {"sizes": sizes, "n_per_size": n, "seeds": SEEDS}
    if st["kind"] == "advantage":
        plan["instances_per_seed"] = n * len(sizes)
        plan["power"] = {str(a): AC.instances_needed(a, 0.8, AC.ALPHA, SEEDS, cap=MAX_N * len(sizes)) for a in (0.25, 0.5, 0.75, 1.0)}
        plan["false_credit_bound"] = AC.ALPHA ** SEEDS
    compiled = {"format": FORMAT, "kind": st["kind"], "name": mod.NAME, "version": mod.VERSION, "decl_sha256": declared.sha256_file(os.path.join(dirpath, declared.DECL)),
                "reference_sha256": declared.sha256_file(ref), "compiler_sha256": compiler_sha256(), "python": sys.version.split()[0], "quick": bool(quick), "settings": st, "plan": plan,
                "validation": [{"check": r["check"], "status": r["status"], "detail": r["detail"]} for r in results], "caveats": CAVEATS[st["kind"]],
                "reference_note": getattr(mod, "REFERENCE_NOTE", None)}
    tmp = os.path.join(dirpath, declared.COMPILED + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(compiled, f, indent=1, sort_keys=True)
    os.replace(tmp, os.path.join(dirpath, declared.COMPILED))
    return compiled


def verdict(compiled):
    k = compiled["kind"]
    p = compiled["plan"]
    lines = [f"{compiled['name']} ({k}, {compiled['version']}): " + ("DRAFT (--quick)" if compiled.get("quick") else "COMPILED"),
             f"  sizes {p['sizes']}, {p['n_per_size']} instances per size, {p['seeds']} committed seeds (the minimum credit counts)"]
    if k == "advantage":
        lines.append(f"  {p['instances_per_seed']} instances per seed; instances per seed for 80% power at advantage 0.25/0.5/0.75/1.0: "
                     + "/".join(str(p['power'][a]) for a in ('0.25', '0.5', '0.75', '1.0')) + f"; false credit for a guesser <= {p['false_credit_bound']:.1e}")
    lines += [f"  this is NOT a speed family: judge, portal and rounds do not run it. Run it with `{cmd('kinds', 'evaluate|score|compare|replay')}`"]
    lines += ["  what the claim does not show:"] + [f"    - {c}" for c in compiled["caveats"]]
    return "ok", lines


_ID_RE = re.compile(r"[0-9]{1,6}:[0-9]{1,6}")
_STATUSES = {"solved", "wrong", "failed", "crash", "timeout"}


def _isint(v):
    return isinstance(v, int) and not isinstance(v, bool)


def load_ladder(path, mod):
    """read_ladder + a STRICT shape check, so a hostile or damaged ladder is refused with a sentence and never reaches a raw field access (a mutation fuzz of score/compare/replay found 8 crash
    classes before this existed). Checks only shape and consistency with the declaration; what the numbers mean is the caller's (score re-derives, replay re-runs)."""
    header, recs = read_ladder(path)
    bad = lambda why: CD.CompileError(f"{path}: {why}")   # noqa: E731
    sizes, n = header.get("sizes"), header.get("n")
    if not (isinstance(sizes, list) and 1 <= len(sizes) <= 64 and all(_isint(s) and 0 <= s < 1_000_000 for s in sizes) and len(set(sizes)) == len(sizes)):
        raise bad("header 'sizes' must be a list of distinct integers")
    if not (_isint(n) and 1 <= n <= MAX_N):
        raise bad(f"header 'n' must be an integer 1..{MAX_N}")
    for k in ("commit", "name", "version", "kind", "solver_sha256"):
        if not isinstance(header.get(k), str):
            raise bad(f"header {k!r} must be a string")
    if header["kind"] != kind_of(mod):
        raise bad(f"this ladder is for kind {header['kind']!r}, the declaration is {kind_of(mod)!r}")
    if kind_of(mod) == "precomp":
        pre = header.get("pre")
        need = ("pre_status", "pre_steps", "state_bytes", "state_sha256", "horizon")
        if not (isinstance(pre, dict) and all(str(s) in pre and isinstance(pre[str(s)], dict) and all(k in pre[str(s)] for k in need) for s in sizes)):
            raise bad("a precomp ladder's header needs 'pre' with the preprocessing record of every size")
    if len(recs) > len(sizes) * n:
        raise bad("more records than sizes x n")
    seen = set()
    for r in recs:
        if not isinstance(r, dict) or not isinstance(r.get("id"), str) or not _ID_RE.fullmatch(r["id"]):
            raise bad("every record needs an id of the form SIZE:INDEX")
        s, i = (int(v) for v in r["id"].split(":"))
        if s not in sizes or i >= n or r["id"] in seen:
            raise bad(f"record {r['id']!r} is foreign or repeated")
        seen.add(r["id"])
        if r.get("dim") != s or isinstance(r.get("dim"), bool):
            raise bad(f"record {r['id']!r}: 'dim' must equal the size in its id")
        if not isinstance(r.get("status"), str) or r["status"] not in _STATUSES:   # isinstance first: an unhashable value (a list, a dict) must be refused, not crash the set lookup
            raise bad(f"record {r['id']!r}: unknown status")
        c = r.get("cpu")
        if isinstance(c, bool) or not isinstance(c, (int, float)) or not math.isfinite(c) or c <= 0:
            raise bad(f"record {r['id']!r}: 'cpu' must be a positive finite number")
        if kind_of(mod) == "oracle" and not (isinstance(r.get("transcript"), list) and isinstance(r.get("transcript_sha256"), str)):
            raise bad(f"record {r['id']!r}: an oracle record carries its transcript and its hash")
        if kind_of(mod) == "quantum" and r["status"] == "solved" and not (isinstance(r.get("circuit_sha256"), str) and isinstance(r.get("gates"), int)):
            raise bad(f"record {r['id']!r}: a solved quantum record carries its circuit hash and gate count")
        why = field_problem(mod, r)
        if why:
            raise bad(f"record {r['id']!r}: {why}")
        want = expected_cost(mod, header, r)
        if want is None:   # a field the cost derives from is missing or not a number: such a record could carry ANY cost, so it is refused, not waved through
            raise bad(f"record {r['id']!r}: its cost cannot be checked because a field it derives from (steps / online_steps / queries / gates) is missing or not a number")
        if abs(want - c) > 1e-9 * max(1.0, abs(want)):
            raise bad(f"record {r['id']!r}: its cost {c} does not follow from its own fields (they give {want}): a cost cannot be edited without the run that produced it")
    return header, recs


def field_problem(mod, r):
    """A sentence if the raw fields a cost is derived from disagree with the evidence the record carries (no solver is run): an oracle record's query count and hash against its own transcript,
    a quantum record's gate/T/oracle counts and hash against its own circuit. Otherwise None. (Steps and online steps cannot be checked without re-running: that is replay's job.)"""
    k = kind_of(mod)
    try:
        if k == "oracle":
            t = r["transcript"]
            if len(t) > settings(mod)["query_budget"] or not all(isinstance(e, list) and len(e) == 2 for e in t):
                return "the transcript is not a list of [query, reply] pairs within the query budget"
            if r.get("queries") != len(t):
                return f"it says {r.get('queries')} queries but its transcript holds {len(t)}"
            if OC.transcript_sha256(t) != r["transcript_sha256"]:
                return "its transcript does not hash to its recorded transcript_sha256"
        elif k == "quantum" and "circuit" in r:
            st = settings(mod)
            gates = QC.decode(r["circuit"], st["qubits"])
            c = QC.costs(gates, st["oracle_gate_cost"])
            for key in ("gates", "t_count", "oracle_calls"):
                if r.get(key) != c[key]:
                    return f"it says {key} = {r.get(key)} but its circuit has {c[key]}"
            if hashlib.sha256(json.dumps(r["circuit"], separators=(",", ":")).encode()).hexdigest() != r.get("circuit_sha256"):
                return "its circuit does not hash to its recorded circuit_sha256"
        elif k == "quantum" and r["status"] == "solved":
            return "a solved quantum record must carry its circuit"
    except (KeyError, TypeError, ValueError, RecursionError, QC.CircuitError) as e:
        return f"its evidence cannot be checked ({type(e).__name__})"
    return None


def expected_cost(mod, header, r):
    """The cost a record MUST carry, recomputed from its own raw fields with the declaration's settings (never from the header's copy of them), or None when a field it needs is missing
    or not a number (the shape check above has already refused the ladder in the cases that matter). The same arithmetic as the evaluators, so an honest ladder always matches."""
    k = kind_of(mod)
    num = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)   # noqa: E731
    floor = lambda v: max(v, 1e-3)   # noqa: E731
    try:
        st = settings(mod)
        solved = r["status"] == "solved"
        if k == "oracle":
            if solved:
                return floor(r["queries"] / st["query_unit"]) if _isint(r.get("queries")) else None
            return floor(st["query_budget"] / st["query_unit"])
        if k == "quantum":
            if solved:
                return floor(r["gates"] / QUANTUM_GATE_UNIT) if _isint(r.get("gates")) else None
            return floor(QUANTUM_GATE_CAP / QUANTUM_GATE_UNIT)
        if k == "precomp":
            pre = header["pre"][str(r["dim"])]
            if solved:
                return floor((r["online_steps"] + pre["pre_steps"] / st["horizon"]) / PC.STEPS_PER_UNIT) if num(r.get("online_steps")) and num(pre.get("pre_steps")) else None
            return floor(PC.STEP_LIMIT / PC.STEPS_PER_UNIT)
        if r["status"] in ("solved", "wrong", "failed"):   # advantage: an answered instance costs its steps, an unanswered one the whole budget
            return floor(r["steps"] / PC.STEPS_PER_UNIT) if num(r.get("steps")) else None
        return floor(st["step_budget"] / PC.STEPS_PER_UNIT)
    except (KeyError, TypeError, ZeroDivisionError):
        return None


# ------------------------------------------------------------------------------------------------------------- scoring
def _expect_ids(sizes, n):
    return {f"{s}:{i}" for s in sizes for i in range(n)}


def score_files(dirpath, paths, seeds_hex):
    """advantage: one ladder per committed seed, with that seed's hex (revealed) in the same order. Correctness is recomputed: each recorded GUESS is compared with a fresh derive()'s planted
    coin, the ids must be exactly sizes x 0..n-1 (a dropped instance counts as wrong, an extra or repeated one is refused), and the ladder must be for this declaration's version."""
    mod = load(dirpath)
    if kind_of(mod) != "advantage":
        raise CD.CompileError("score is for advantage declarations; use compare for the other kinds")
    if len(paths) != len(seeds_hex):
        raise CD.CompileError("one --seed per ladder, in the same order")
    try:
        norm = [bytes.fromhex(s) for s in seeds_hex]   # BYTES, not text: fromhex ignores spaces, so "00 00" and "0000" are one seed
    except ValueError:
        raise CD.CompileError("--seed must be hexadecimal")
    if len(set(norm)) != len(norm) or len({os.path.realpath(p) for p in paths}) != len(paths):
        raise CD.CompileError("the seeds (and the ladder files) must all be different: one seed repeated is not several committed seeds, and the minimum over seeds would mean nothing")
    compiled = declared.read_compiled(dirpath)
    problems = freshness_problems(dirpath, mod, compiled)
    if problems:
        raise CD.CompileError("not compiled, or stale: " + "; ".join(problems))
    plan = compiled["plan"]   # the expected instance count comes from the COMPILED plan, never from a ladder's own header (a ladder claiming n=2 would be credited on two lucky guesses)
    if len(paths) < plan["seeds"]:
        raise CD.CompileError(f"the plan commits {plan['seeds']} seeds: give {plan['seeds']} ladders (a missing seed would raise the minimum)")
    per = []
    for path, sh in zip(paths, seeds_hex):
        header, recs = load_ladder(path, mod)
        try:
            master = bytes.fromhex(sh)
        except ValueError:
            raise CD.CompileError("--seed must be hexadecimal")
        if header.get("name") != mod.NAME or header.get("version") != mod.VERSION:
            raise CD.CompileError(f"{path} is for {header.get('name')} {header.get('version')}, not {mod.NAME} {mod.VERSION}")
        if header.get("commit") != instances.commit(master):
            raise CD.CompileError(f"{path}: the revealed seed does not match the ladder's commitment")
        sizes, n = plan["sizes"], plan["n_per_size"]
        if header.get("sizes") != sizes or header.get("n") != n:
            raise CD.CompileError(f"{path} is not on the compiled plan (sizes {sizes}, {n} per size); it says sizes {header.get('sizes')}, n {header.get('n')}")
        ids = [r.get("id") for r in recs]
        if len(set(ids)) != len(ids) or not set(ids) <= _expect_ids(sizes, n):
            raise CD.CompileError(f"{path}: repeated or foreign instance ids")
        total = len(sizes) * n
        right = 0
        for r in recs:
            s, i = (int(v) for v in r["id"].split(":"))
            planted = mod.derive(master, s, i)["planted"]
            g = r.get("guess")
            right += (_isint(g) and g in (0, 1) and g == planted)   # an int only: 1.0 or True is not a guess
        c = AC.seed_credit(right, total)
        c.update({"path": os.path.basename(path), "answered": len(recs), "expected": total})
        per.append(c)
    return {"seeds": per, "credit": AC.combine([c["credit"] for c in per])}


def compare(dirpath, ref_path, sub_path):
    """Descriptive per-size comparison of two ladders of the same declaration: solved counts and the median-cost ratio in bits (log2 ref/sub over instances both solved)."""
    mod = load(dirpath)
    k = kind_of(mod)
    (hr, rr), (hs, rs) = load_ladder(ref_path, mod), load_ladder(sub_path, mod)
    for h in (hr, hs):
        if h.get("name") != mod.NAME or h.get("version") != mod.VERSION or h.get("kind") != k:
            raise CD.CompileError("a ladder is for another declaration or version")
    if hr["commit"] != hs["commit"] or hr["sizes"] != hs["sizes"] or hr["n"] != hs["n"]:
        raise CD.CompileError("the two ladders are not on the same seed, sizes and instance count")
    compiled = declared.read_compiled(dirpath)
    problems = freshness_problems(dirpath, mod, compiled)
    if problems:
        raise CD.CompileError("not compiled, or stale: " + "; ".join(problems))
    if hr["sizes"] != compiled["plan"]["sizes"] or hr["n"] != compiled["plan"]["n_per_size"]:
        raise CD.CompileError("the ladders are not on the compiled plan's sizes and instance count")
    out = {}
    for s in hr["sizes"]:
        a = {r["id"]: r for r in rr if r["dim"] == s}
        b = {r["id"]: r for r in rs if r["dim"] == s}
        both = [i for i in a if i in b and a[i]["status"] == "solved" and b[i]["status"] == "solved"]
        bits = [math.log2(a[i]["cpu"] / b[i]["cpu"]) for i in both]
        out[s] = {"ref_solved": sum(r["status"] == "solved" for r in a.values()), "sub_solved": sum(r["status"] == "solved" for r in b.values()), "total": hr["n"],
                  "both": len(both), "median_bits": statistics.median(bits) if bits else None}
    is_ref = hr.get("solver_sha256") == compiled.get("reference_sha256")
    return {"kind": k, "reference_is_declared_reference": is_ref,
            "warning": None if is_ref else "the first ladder was NOT made by the declared reference solver: the ratio is between two solvers, not a gain over the declared baseline",
            "practice_seed": instances.commit(instances.PRACTICE_SEED) in (hr.get("commit"), hs.get("commit")),
            "unit": {"oracle": "queries / QUERY_UNIT", "precomp": "(online steps + preprocessing share) / 1e6", "quantum": "gates / 100", "advantage": "steps / 1e6"}[k],
            "sizes": out, "note": "descriptive: a median over the instances both solved, not the calibrated lower bound a speed certificate gives, and not signed or logged"}


CREDIT_BOOT = 400   # bootstrap resamples for the provisional credit (quality_core.MIN_BOOT is 60; its 1st-percentile bound is about as conservative from 200 up)
CREDIT_METHOD = ("per instance, bits = log2(reference cost / submission cost) in the ladders' own cost unit, an unsolved instance charged the cap and a missing submission record charged the cap; "
                 "the mean over sizes (equal weight per size) of the per-size means; a stratified bootstrap within each size (quality_core.lower_bound: the 1st percentile of CREDIT_BOOT resamples, "
                 "seeded from the two ladders' hashes so the same inputs always give the same number); credit = max(0, that lower bound); over several seeds the MINIMUM")
CREDIT_CAVEATS = ("PROVISIONAL: the false-credit rate of this bound has NOT been measured for cost ratios (quality_core's 1st-percentile choice was calibrated on max-cut quality differences, not on log2 cost ratios), "
                  "no power analysis picked the instance count, and it is not the speed protocol's difficulty-stratified bound. A cost in 'counted' units says nothing about wall-clock time, "
                  "and for oracle / quantum / precomputation kinds the model caveats of NONFITTING.md apply. Do not publish it as a certified speedup")


def _cap_cost(mod):
    """The cost an UNSOLVED instance is charged, in the kind's cost unit: the same arithmetic as the evaluators and as expected_cost()."""
    k, st = kind_of(mod), settings(mod)
    if k == "oracle":
        return max(st["query_budget"] / st["query_unit"], 1e-3)
    if k == "quantum":
        return max(QUANTUM_GATE_CAP / QUANTUM_GATE_UNIT, 1e-3)
    if k == "precomp":
        return max(PC.STEP_LIMIT / PC.STEPS_PER_UNIT, 1e-3)
    raise CD.CompileError("a cost credit exists for oracle, precomp and quantum declarations; an advantage declaration has its own (score)")


def bits_strata(dirpath, ref_path, sub_path):
    """-> ({size: [bits, one per instance]}, reference_is_declared_reference) for one (reference ladder, submission ladder) pair on ONE seed: the data bits_credit() bootstraps and calibrate_credit.py
    simulates from. Same validation as compare(): both ladders are shape-checked, their costs must follow from their own fields, they must be on the compiled plan and on one seed."""
    mod = load(dirpath)
    cap = _cap_cost(mod)
    (hr, rr), (hs, rs) = load_ladder(ref_path, mod), load_ladder(sub_path, mod)
    for h in (hr, hs):
        if h.get("name") != mod.NAME or h.get("version") != mod.VERSION:
            raise CD.CompileError("a ladder is for another declaration or version")
    if hr["commit"] != hs["commit"] or hr["sizes"] != hs["sizes"] or hr["n"] != hs["n"]:
        raise CD.CompileError("the two ladders are not on the same seed, sizes and instance count")
    compiled = declared.read_compiled(dirpath)
    problems = freshness_problems(dirpath, mod, compiled)
    if problems:
        raise CD.CompileError("not compiled, or stale: " + "; ".join(problems))
    if hr["sizes"] != compiled["plan"]["sizes"] or hr["n"] != compiled["plan"]["n_per_size"]:
        raise CD.CompileError("the ladders are not on the compiled plan's sizes and instance count")
    ref_cost = {r["id"]: r["cpu"] for r in rr}
    sub_cost = {r["id"]: r["cpu"] for r in rs}
    strata = {}
    for s in hr["sizes"]:
        vals = []
        for i in range(hr["n"]):
            key = f"{s}:{i}"
            if key not in ref_cost:
                continue   # the REFERENCE has no record here: not an instance of this comparison
            vals.append(math.log2(ref_cost[key] / sub_cost.get(key, cap)))   # a missing SUBMISSION record is charged the cap, never skipped (dropping hard instances must not help)
        if vals:
            strata[s] = vals
    if not strata:
        raise CD.CompileError("the ladders share no instance to compare")
    return strata, hr.get("solver_sha256") == compiled.get("reference_sha256")


def bits_credit(dirpath, ref_path, sub_path, boot=CREDIT_BOOT):
    """PROVISIONAL credit, in bits, of one submission ladder over the reference ladder on ONE seed (see CREDIT_METHOD and CREDIT_CAVEATS; the validation is bits_strata's).
    -> dict with estimate_bits, lower_bits, credit_bits, instances, better, worse, reference_is_declared_reference, method, caveats."""
    if not (isinstance(boot, int) and not isinstance(boot, bool) and Q.MIN_BOOT <= boot <= 5000):
        raise CD.CompileError(f"boot must be an integer from {Q.MIN_BOOT} to 5000")
    strata, is_ref = bits_strata(dirpath, ref_path, sub_path)
    digest = hashlib.sha256((file_sha256(ref_path, 256 << 20) + file_sha256(sub_path, 256 << 20)).encode()).digest()
    rng = random.Random(int.from_bytes(digest[:8], "big"))
    lower = Q.lower_bound(strata, rng, boot)
    flat = [x for v in strata.values() for x in v]
    return {"estimate_bits": Q.estimate(strata), "lower_bits": lower, "credit_bits": max(0.0, lower), "instances": len(flat),
            "better": sum(x > 1e-12 for x in flat), "worse": sum(x < -1e-12 for x in flat),
            "reference_is_declared_reference": is_ref,
            "method": CREDIT_METHOD, "caveats": CREDIT_CAVEATS}


def pick_sample(recs, k, sample_seed):
    """k records chosen by `sample_seed` (an int). The CALLER's seed, not anything derived from the ladder: a prover who could predict the sample would forge only the records outside it."""
    return random.Random(sample_seed).sample(recs, min(k, len(recs)))


def replay(dirpath, solver, ladder_path, master, sample=None, sample_seed=None):
    """Re-run records of a ladder and demand identical results. -> (ok, [reasons]). `master` is the revealed seed (bytes). oracle/precomp/quantum/advantage each by their own rule.
    With `sample` = K only K randomly chosen records are re-run (precomp always re-runs every size: its state is one piece); `sample_seed` makes the choice reproducible (the CLI draws a fresh
    random one and prints it)."""
    mod = load(dirpath)
    k = kind_of(mod)
    header, recs = load_ladder(ladder_path, mod)
    if header.get("commit") != instances.commit(master):
        return False, ["the seed does not match the ladder's commitment"]
    if file_sha256(solver) != header.get("solver_sha256"):
        return False, ["the solver file is not the one the ladder names"]
    st = settings(mod)
    why = []
    if k == "precomp":
        for s in header["sizes"]:
            rs = [r for r in recs if r["dim"] == s]
            ok, w = PC.replay_size(mod, solver, master, s, header["pre"][str(s)], rs)
            why += w
        return (not why), why
    if sample and sample_seed is None:
        import secrets
        sample_seed = secrets.randbits(64)
    picks = recs if not sample else pick_sample(recs, sample, sample_seed)
    for r in picks:
        s, i = (int(v) for v in r["id"].split(":"))
        inst = make_instance(mod, master, s, i)
        if k == "oracle":
            ok, w = OC.replay(mod, solver, inst, r)
            why += [f"{r['id']}: {x}" for x in w]
        else:
            fresh = _eval_one(mod, st, solver, inst, s)
            keys = ("status", "steps", "guess") if k == "advantage" else ("status", "steps", "circuit_sha256", "gates", "min_probability")
            for key in keys:
                if fresh.get(key) != r.get(key):
                    why.append(f"{r['id']} {key}: {fresh.get(key)!r} != recorded {r.get(key)!r}")
    return (not why), why[:20]


# ------------------------------------------------------------------------------------------------------------- scaffold
def scaffold(kind, name, dest_root):
    """Copy the worked example of `kind` into dest_root/name as a WORKING starting point (decl.py + the reference; NAME replaced). Never overwrites."""
    if kind not in KINDS:
        raise CD.CompileError(f"--kind must be one of {', '.join(KINDS)}")
    if not declared.NAME_RE.fullmatch(name):   # fullmatch: the pinned pattern's `$` would also accept "name\n", which would then be written into decl.py as a broken NAME line
        raise CD.CompileError("NAME must be 2-16 lowercase letters")
    src = os.path.join(HERE, EXAMPLES[kind])
    dst = os.path.join(dest_root, name)
    if os.path.exists(dst):
        raise CD.CompileError(f"{dst} already exists; nothing was changed")
    os.makedirs(dst)
    for fn in ("decl.py", "reference.py"):
        shutil.copyfile(os.path.join(src, fn), os.path.join(dst, fn))
    p = os.path.join(dst, "decl.py")
    with open(p, encoding="utf-8") as f:
        text = f.read()
    text, cnt = re.subn(r'(?m)^NAME = "[a-z]{2,16}"', f'NAME = "{name}"', text)
    if cnt != 1:
        raise CD.CompileError("the example's NAME line was not found")
    with open(p, "w", encoding="utf-8") as f:
        f.write(text)
    return dst


# ------------------------------------------------------------------------------------------------------------- CLI
def _master(a):
    if a.seed is not None:   # `if a.seed:` would turn --seed '' into the public practice seed without a word
        m = bytes.fromhex(a.seed)
        if not m:
            raise ValueError("--seed must not be empty")
        return m
    return instances.PRACTICE_SEED


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("evaluate", help="run a solver on a seed's instances and write a ladder")
    p.add_argument("dir"), p.add_argument("solver"), p.add_argument("--out", required=True)
    p.add_argument("--seed", help="hex master seed (default: the public practice seed: a practice result is never a committed one)")
    p.add_argument("--n", type=int, help="instances per size (default: the compiled plan's)")
    p = sub.add_parser("score", help="advantage: credit from one ladder per committed seed")
    p.add_argument("dir"), p.add_argument("ladders", nargs="+"), p.add_argument("--seed", action="append", required=True, help="the revealed hex seed of each ladder, in order")
    p = sub.add_parser("compare", help="other kinds: descriptive per-size comparison of two ladders")
    p.add_argument("dir"), p.add_argument("ref"), p.add_argument("sub")
    p = sub.add_parser("credit", help="oracle / precomp / quantum: a PROVISIONAL credit in bits over the declared reference, from one (reference ladder, submission ladder) pair per committed seed")
    p.add_argument("dir"), p.add_argument("--pair", nargs=2, action="append", required=True, metavar=("REF_LADDER", "SUB_LADDER"), help="repeat once per committed seed")
    p.add_argument("--boot", type=int, default=CREDIT_BOOT, help=f"bootstrap resamples ({Q.MIN_BOOT}..5000)")
    p = sub.add_parser("replay", help="re-run records and demand identical results")
    p.add_argument("dir"), p.add_argument("solver"), p.add_argument("ladder"), p.add_argument("--seed", required=True), p.add_argument("--sample", type=int), p.add_argument("--sample-seed", type=int, help="make the --sample choice reproducible (default: a fresh random one, printed)")
    a = ap.parse_args(argv)
    try:
        d = CD._resolve(a.dir)
        if a.cmd == "evaluate":
            mod = load(d)
            if kind_of(mod) is None:
                raise CD.CompileError("not a KIND declaration")
            compiled = declared.read_compiled(d)
            problems = freshness_problems(d, mod, compiled)
            if problems:
                raise CD.CompileError("not compiled, or stale: " + "; ".join(problems) + f"  ({cmd('compile', 'compile ' + a.dir)})")
            st = settings(mod)
            n = a.n if a.n is not None else compiled["plan"]["n_per_size"]   # `a.n or ...` would turn --n 0 into the default
            if not (2 <= n <= MAX_N and n % 2 == 0):
                raise CD.CompileError(f"--n must be an even integer 2..{MAX_N}")
            header, recs = run_ladder(mod, st, os.path.abspath(a.solver), _master(a), compiled["plan"]["sizes"], n)
            write_ladder(a.out, header, recs)
            print(f"wrote {a.out}: {len(recs)} records; solved {sum(r['status'] == 'solved' for r in recs)}")
        elif a.cmd == "score":
            r = score_files(d, a.ladders, a.seed)
            for c in r["seeds"]:
                print(f"{c['path']}: accuracy {c['accuracy']:.3f} ({c['instances']} instances, {c['answered']} answered), advantage {c['advantage']:.3f}, credit {c['credit']:.3f}")
            print(f"CREDIT (minimum over seeds): {r['credit']:.3f}   (exact one-sided bound, alpha {AC.ALPHA}; 0 = no advantage over guessing was shown)")
        elif a.cmd == "compare":
            r = compare(d, a.ref, a.sub)
            print(json.dumps(r, indent=1))
        elif a.cmd == "credit":
            per = [bits_credit(d, ref, sub_, a.boot) for ref, sub_ in a.pair]
            for (ref, sub_), c in zip(a.pair, per):
                print(f"{os.path.basename(sub_)}: mean {c['estimate_bits']:+.3f} bits over {c['instances']} instances ({c['better']} better, {c['worse']} worse), lower bound {c['lower_bits']:+.3f}, credit {c['credit_bits']:.3f}")
            print(f"PROVISIONAL CREDIT (minimum over {len(per)} seed(s)): {min(c['credit_bits'] for c in per):.3f} bits")
            print(CREDIT_CAVEATS)
            if any(not c["reference_is_declared_reference"] for c in per):
                print("WARNING: a reference ladder was NOT made by the declared reference solver: this is a comparison between two solvers, not a gain over the declared baseline")
        else:
            if a.sample is not None and not 1 <= a.sample <= 1_000_000:
                raise CD.CompileError("--sample must be 1..1000000 (omit it to replay every record)")
            sample_seed = a.sample_seed
            if a.sample and sample_seed is None:
                import secrets
                sample_seed = secrets.randbits(64)   # drawn HERE so it can be printed: the choice is unpredictable to the prover and reproducible by anyone who is told it
            if a.sample:
                print(f"re-running {a.sample} randomly chosen records (sample seed {sample_seed}: pass --sample-seed {sample_seed} to repeat exactly this choice)")
            ok, why = replay(d, os.path.abspath(a.solver), a.ladder, bytes.fromhex(a.seed), a.sample, sample_seed)
            print("REPLAY OK" if ok else "REPLAY FAILED")
            for w in why:
                print("  -", w)
            return 0 if ok else 1
    except (CD.CompileError, declared.DeclarationError, FileExistsError, ValueError, OSError, KeyError) as e:
        raise SystemExit(f"REFUSED: {type(e).__name__}: {e}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
