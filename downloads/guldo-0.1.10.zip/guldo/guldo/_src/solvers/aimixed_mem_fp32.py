"""aimixed with bytes counted, TECHNIQUE: the reference method with every tensor in fp32 (features, labels, weights and every intermediate). Half the bytes of fp64; the rounding (about 6e-8
relative) does not stop the iteration from reaching the 1e-6 loss tolerance."""
import math

import tensorops as tp

RHO = 0.9
LAM = 1e-3
STEPS = 10000


def features(seed, d, n):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    return (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)


def solve(seed, d, n, labels):
    lr = 0.0
    X = features(seed, d, n)
    lr = 1.0 / (tp.sum(X * X).item() / (4.0 * n) + LAM)
    X = tp.cast(X, "fp32")
    y = tp.cast(tp.tensor([float(v) for v in labels]), "fp32")
    Xt = tp.transpose(X, (1, 0))
    w = tp.cast(tp.zeros((d,)), "fp32")
    for step in range(STEPS):
        w = w - (Xt @ (1.0 / (1.0 + tp.exp(-(X @ w))) - y) * (1.0 / n) + w * LAM) * lr
    return [int(v * 1048576.0) for v in w.tolist()]
