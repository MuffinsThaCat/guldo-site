"""Research with a known answer: follow a chain of facts through a library of short documents and report one number.

size = number of links to follow (1..4). The library (about 30 to 60 documents), the starting entity, the chain and the answer are a pure function of the instance seed. Three kinds of
entity (organisations, people, cities) form a cycle: an organisation is led by a person, a person was born in a city, a city hosts the headquarters of an organisation. Each document
describes one entity. The agent is told where to start and which links to follow, and must report one numeric attribute (budget, age or population) of the entity it ends on. It
reaches the documents only through `search` (all words must appear; shows up to 5 matches, which can include documents that merely MENTION the name) and `open` (the full text).
Every hop costs at least a search and an open, and an agent that opens everything it finds pays for every page in every later turn. The answer is exact.
"""
import math

import agent_core

NAME = "research"
VERSION = "research-v1"
SIZE_RANGE = (1, 4)
SIZE_STEP = 1
DOC = "Follow the stated chain of links through the library of documents and submit the requested number."
KINDS = ("org", "person", "city")
LINKS = {"org": "leader", "person": "birthplace", "city": "headquartered organisation"}
NEXT = {"org": "person", "person": "city", "city": "org"}
ATTR = {"org": "annual budget in units", "person": "age in years", "city": "population"}
MAX_HITS = 5
ORG_SUFFIX = ("Institute", "Labs", "Works", "Guild", "Society")
SYL = ("ka", "vel", "or", "tan", "mi", "ra", "sol", "den", "ur", "lis", "bre", "qua", "zen", "fa", "gor", "hel", "pi", "nox", "yu", "ash")
FIRST = ("Mara", "Teo", "Ilsa", "Brun", "Cato", "Dara", "Eben", "Fenn", "Gale", "Hana", "Ivo", "Jun", "Kira", "Lorn", "Mika", "Nils", "Odra", "Pell", "Reva", "Sven")


# Sealed pools (agent_core "sealed generators"): the FIRST k of each pool are exactly the public lists above, so the canonical generator is unchanged; a sealed round draws k of the whole pool.
POOL_SYL = SYL + ("dun", "eri", "fal", "gan", "hir", "iko", "jor", "kel", "lam", "mor", "nai", "ost", "pra", "rin", "sab", "tev", "ulm", "vor", "wen", "xal", "yar", "zul", "bol", "cyr", "dre",
                  "ely", "fos", "gry", "hov", "ima", "jav", "kru", "lyn", "mez", "nur", "oba", "pyl", "qen", "rho", "sky")
POOL_FIRST = FIRST + ("Abel", "Bree", "Cyra", "Dov", "Elan", "Faye", "Gus", "Hale", "Iris", "Jory", "Kai", "Lena", "Milo", "Nora", "Oren", "Pia", "Quin", "Rhys", "Sana", "Tomas", "Ugo", "Vera",
                      "Wren", "Xia", "Yan", "Zora", "Alma", "Boaz", "Cleo", "Dane", "Edda", "Finn", "Greta", "Hugo", "Inez", "Joss", "Kemal", "Luz", "Mace", "Nell")
POOL_SUFFIX = ORG_SUFFIX + ("Collective", "Foundry", "Council", "Bureau", "Syndicate", "Trust", "Academy", "Consortium", "Press", "Atelier")
CITY_ENDINGS = ("holm", "burg", "ford", "mere", "wick", "stead", "haven", "dale")
SEALED_DRAWS = [("syllables", agent_core.sample_bits(len(POOL_SYL), len(SYL))), ("first names", agent_core.sample_bits(len(POOL_FIRST), len(FIRST))),
                ("org suffixes", agent_core.sample_bits(len(POOL_SUFFIX), len(ORG_SUFFIX))), ("city ending", math.log2(len(CITY_ENDINGS))), ("budget low end", math.log2(491)),
                ("age low end", math.log2(16)), ("population low end", math.log2(49001)), ("founding year low end", math.log2(51))]


def _word(r, n, syl=SYL):
    return "".join(r.choice(syl) for _ in range(n)).capitalize()


def _unique(r, make, used):
    for _ in range(1000):
        name = make()
        if name not in used:
            used.add(name)
            return name
    raise RuntimeError("could not make unique names")


def _perm(r, n):
    return r.sample(range(n), n)


def derive(seed, size, style=None):
    st = style or agent_core.CANONICAL
    syl, first, suffix = st.sample("syllables", POOL_SYL, len(SYL)), st.sample("first names", POOL_FIRST, len(FIRST)), st.sample("org suffixes", POOL_SUFFIX, len(ORG_SUFFIX))
    ending = st.pick("city ending", CITY_ENDINGS)
    b_lo, a_lo, p_lo, y_lo = st.between("budget low end", 10, 500), st.between("age low end", 25, 40), st.between("population low end", 1000, 50000), st.between("founding year low end", 1900, 1950)
    r = agent_core.Rng(seed)
    t = 10 + 5 * size
    used = set()
    orgs = [_unique(r, lambda: "%s %s" % (_word(r, 2, syl), r.choice(suffix)), used) for _ in range(t)]
    people = [_unique(r, lambda: "%s %s" % (r.choice(first), _word(r, 2, syl)), used) for _ in range(t)]
    cities = [_unique(r, lambda: _word(r, 2, syl) + ending, used) for _ in range(t)]
    leader, born, hosts = _perm(r, t), _perm(r, t), _perm(r, t)      # org i -> person leader[i]; person j -> city born[j]; city k -> org hosts[k]
    attr = {"org": [r.randint(b_lo, 9999) for _ in range(t)], "person": [r.randint(a_lo, 90) for _ in range(t)], "city": [r.randint(p_lo, 999999) for _ in range(t)]}
    founded = [r.randint(y_lo, 2020) for _ in range(t)]
    docs = []
    for i in range(t):
        docs.append({"kind": "org", "i": i, "title": orgs[i], "text": "%s is an organisation. It is led by %s. It was founded in %d. Its annual budget is %d units." % (orgs[i], people[leader[i]], founded[i], attr["org"][i])})
        docs.append({"kind": "person", "i": i, "title": people[i], "text": "%s is a person. %s was born in %s. %s is %d years old." % (people[i], people[i], cities[born[i]], people[i], attr["person"][i])})
        docs.append({"kind": "city", "i": i, "title": cities[i], "text": "%s is a city. It hosts the headquarters of %s. Its population is %d." % (cities[i], orgs[hosts[i]], attr["city"][i])})
    order = _perm(r, len(docs))
    for pos, k in enumerate(order):
        docs[k]["id"] = "D%03d" % pos
    docs.sort(key=lambda d: d["id"])
    kind = r.choice(KINDS)
    idx = r.randint(0, t - 1)
    start = {"org": orgs, "person": people, "city": cities}[kind][idx]
    steps = []
    cur_kind, cur = kind, idx
    for _ in range(size):
        steps.append(LINKS[cur_kind])
        cur = {"org": lambda i: leader[i], "person": lambda i: born[i], "city": lambda i: hosts[i]}[cur_kind](cur)
        cur_kind = NEXT[cur_kind]
    answer = attr[cur_kind][cur]
    link_text = "; ".join("(%d) %s" % (n + 1, s) for n, s in enumerate(steps))
    question = ("Start at '%s'. Follow these links in order, each from the entity you reached by the previous one: %s. "
                "Report the %s of the entity you end on. Submit the number." % (start, link_text, ATTR[cur_kind]))
    return {"public": {"question": question, "n_docs": len(docs)}, "private": {"docs": docs, "answer": answer, "start": start, "steps": steps}}


def prompt(public):
    return "%s\nThe library holds %d documents, reachable only through the tools." % (public["question"], public["n_docs"])


def tool_specs(public):
    return [
        {"name": "search", "description": "List up to %d documents whose text contains ALL the words of the query (case-insensitive). A document that only mentions a name also matches." % MAX_HITS,
         "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}},
        {"name": "open", "description": "The full text of one document, by id.", "input_schema": {"type": "object", "properties": {"doc_id": {"type": "string"}}, "required": ["doc_id"]}},
    ]


class Env:
    def __init__(self, instance):
        self.docs = instance["private"]["docs"]
        self.by_id = {d["id"]: d for d in self.docs}

    def call(self, name, args):
        if not isinstance(args, dict):
            return "error: arguments must be an object"
        if name == "search":
            q = args.get("query")
            if not isinstance(q, str) or not q.strip():
                return "error: query must be a non-empty string"
            words = q.lower().split()
            hits = [d for d in self.docs if all(w in d["text"].lower() for w in words)]
            if not hits:
                return "no documents match"
            return "\n".join("%s %s" % (d["id"], d["title"]) for d in hits[:MAX_HITS]) + ("\n(%d more not shown)" % (len(hits) - MAX_HITS) if len(hits) > MAX_HITS else "")
        if name == "open":
            d = self.by_id.get(args.get("doc_id")) if isinstance(args.get("doc_id"), str) else None
            return d["text"] if d else "error: no such document"
        return "error: unknown tool %r" % name


def make_env(instance):
    return Env(instance)


def reference_answer(instance):
    return instance["private"]["answer"]


def verify(instance, answer, calls):
    if isinstance(answer, bool):
        return False, "answer is not a number"
    try:
        a = float(answer.strip()) if isinstance(answer, str) else float(answer)
    except (TypeError, ValueError, AttributeError):
        return False, "answer is not a number"
    ok = a == instance["private"]["answer"]
    return ok, "ok" if ok else "wrong value"


def parse_doc(text):
    """What a reader can pull from a document: its kind and the value that follows each link. Used by the scripted agents."""
    import re
    out = {}
    m = re.search(r"It is led by (.+?)\. It was founded in \d+\. Its annual budget is (\d+) units", text)
    if m:
        out.update(kind="org", next=m.group(1), value=int(m.group(2)))
    m = re.search(r"was born in (.+?)\. .+ is (\d+) years old", text)
    if m:
        out.update(kind="person", next=m.group(1), value=int(m.group(2)))
    m = re.search(r"It hosts the headquarters of (.+?)\. Its population is (\d+)", text)
    if m:
        out.update(kind="city", next=m.group(1), value=int(m.group(2)))
    return out
