"""Do the exact counts predict anything real? A validation study of the counted models against measured times on the machine you run it on (torch on its CPU and, if present, its GPU).

  python3 validate_counts.py [--device cpu|mps|cuda] [--out results/validate_counts_DEVICE.json] [--repeats 9]

For each TECHNIQUE PAIR below, two independent things are computed on the SAME program shapes:
  * the PREDICTION: the counted ratio B/A in the cost the counter says should matter (operations, bytes moved, or peak memory), obtained by running the program under tensorops / tensorops_mem3 on the shapes;
  * the MEASUREMENT: the ratio B/A of the median time (or peak memory) of an INDEPENDENT torch implementation of the same two programs on this device, `--repeats` runs each, after warm-up, with the min and max kept.
The report says, per pair, whether the counted ordering matches the measured one, and how far apart the sizes of the two ratios are (as a factor). It does NOT tune anything to the result: the pairs and the shapes are
fixed in this file, and a pair where the counts are wrong is reported as wrong. Where a technique cannot be measured on the device (an operation the device does not support) the pair is recorded as not measured.

What it can show: that an operation, byte or peak count points the same way as a clock on THIS device, for these shapes. What it cannot show: anything about another device, other shapes or a multi-device cluster
(the topology and pipeline counters are NOT validated here: they need a real multi-device machine); a count is an accounting convention, not a time, and a disagreement is a finding about the convention, not about the
device. Times are one operator's measurements and move with load; run it on an idle machine."""
import argparse
import json
import math
import os
import statistics
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


# ---------------------------------------------------------------------------------------------------------- the counted side

def counted(program):
    """Run program(tp) under tensorops_mem3 in this process; -> (operations, bytes moved, peak live bytes)."""
    import tensorops as tp
    import tensorops_mem3 as M
    if not hasattr(tp, "cast"):
        M.install(tp)
    M.reset()
    tp._FLOPS[0] = 0
    program(tp)
    b, peak = M.counters()
    return tp._FLOPS[0], b, peak


def rnd(shape, seed=0):
    return np.random.RandomState(seed).randn(*shape) * 0.1


# MLP inference: relu(x W1 + b1) W2 + b2, fp64-counted dense against bf16 operands
def mlp_dense(tp, n, d, h):
    x, W1, W2 = (tp.tensor(rnd(s, i).tolist()) for i, s in enumerate(((n, d), (d, h), (h, d))))
    return tp.relu(x @ W1) @ W2


def mlp_low(tp, n, d, h, fmt):
    x, W1, W2 = (tp.tensor(rnd(s, i).tolist()) for i, s in enumerate(((n, d), (d, h), (h, d))))
    c = lambda t: tp.cast(t, fmt)
    return tp.relu(c(x) @ c(W1)) @ c(W2)


# the pairs: name, what the count predicts (metric), the two programs, and how to measure them
def pairs(sizes):
    out = []
    for n, d, h in sizes:
        out.append({"name": f"mlp {n}x{d}x{h}: bf16 operands against fp32", "metric": "bytes", "kind": "mlp_dtype", "shape": (n, d, h), "a": "bf16", "b": "fp32"})
        out.append({"name": f"mlp {n}x{d}x{h}: fp16 operands against fp32", "metric": "bytes", "kind": "mlp_dtype", "shape": (n, d, h), "a": "fp16", "b": "fp32"})
    out.append({"name": "attention 8x4x256x32: fused scaled-dot-product against the written-out softmax", "metric": "bytes", "kind": "attn", "shape": (8, 4, 256, 32), "a": "fused", "b": "naive"})
    out.append({"name": "backward through 16 layers of 512x512: recompute (checkpoint) against store-all", "metric": "peak", "kind": "ckpt", "shape": (16, 256, 512), "a": "ckpt", "b": "store"})
    out.append({"name": "backward through 16 layers of 512x512: recompute (checkpoint) against store-all, time", "metric": "ops", "kind": "ckpt_time", "shape": (16, 256, 512), "a": "ckpt", "b": "store"})
    out.append({"name": "linear 2048x2048 on 1024 rows: 50% unstructured sparse (CSR) against dense", "metric": "ops", "kind": "sparse", "shape": (1024, 2048, 2048), "a": "sparse", "b": "dense"})
    return out


# ---------------------------------------------------------------------------------------------------------- predictions

def predict(p):
    kind, shape = p["kind"], p["shape"]
    if kind == "mlp_dtype":
        n, d, h = shape
        a = counted(lambda tp: mlp_low(tp, n, d, h, "bf16" if p["a"] == "bf16" else "fp16"))
        b = counted(lambda tp: mlp_dense(tp, n, d, h))                 # the counter's dense baseline is float64; fp32 is the same program under the fp32 cast below
        b32 = counted(lambda tp: mlp_low(tp, n, d, h, "fp32"))
        return {"metric": "bytes", "a": a[1], "b": b32[1], "ratio_b_over_a": b32[1] / a[1], "ops_a": a[0], "ops_b": b32[0], "fp64_bytes": b[1]}
    if kind == "attn":
        B, H, T, dh = shape

        def naive(tp):
            q, k, v = (tp.tensor(rnd((B, H, T, dh), i).tolist()) for i in range(3))
            s = tp.einsum("bhtd,bhsd->bhts", q, k) * (1.0 / math.sqrt(dh)) + tp.causal_mask(T)
            e = tp.exp(s - tp.max(s, 3, keepdims=True))
            return tp.einsum("bhts,bhsd->bhtd", e / tp.sum(e, 3, keepdims=True), v)
        # the counted model has no fused kernel: it is the same operations, so the prediction for "fused against naive" is the byte ratio of the written-out version against a version whose
        # score matrix is never materialised, which the counter cannot express. The pair is therefore a test of what the counter CANNOT see.
        c = counted(naive)
        return {"metric": "bytes", "a": None, "b": c[1], "ratio_b_over_a": 1.0, "note": "the counted API has no fused kernel: the counter predicts no difference (ratio 1)"}
    if kind in ("ckpt", "ckpt_time"):
        L, n, d = shape

        def run(tp, ckpt):
            Ws = [tp.tensor(rnd((d, d), i).tolist()) for i in range(L)]
            h = tp.tensor(rnd((n, d), 99).tolist())
            if ckpt:
                keep = [h]
                for i in range(L):
                    h = tp.relu(h @ Ws[i])
                    if i % 4 == 3:
                        keep.append(h)
                g = h
                for i in range(L - 1, -1, -1):
                    seg = i // 4 * 4
                    hh = keep[seg // 4]
                    acts = [hh]
                    for j in range(seg, i):
                        hh = tp.relu(hh @ Ws[j])
                        acts.append(hh)
                    g = (g @ tp.transpose(Ws[i], (1, 0))) * (acts[-1] / (acts[-1] + 1e-300))
            else:
                acts = [h]
                for i in range(L):
                    h = tp.relu(h @ Ws[i])
                    acts.append(h)
                g = h
                for i in range(L - 1, -1, -1):
                    g = (g @ tp.transpose(Ws[i], (1, 0))) * (acts[i] / (acts[i] + 1e-300))
            return g
        a, b = counted(lambda tp: run(tp, True)), counted(lambda tp: run(tp, False))
        if kind == "ckpt":
            return {"metric": "peak", "a": a[2], "b": b[2], "ratio_b_over_a": b[2] / a[2]}
        return {"metric": "ops", "a": a[0], "b": b[0], "ratio_b_over_a": b[0] / a[0]}
    if kind == "sparse":
        n, k, m = shape
        W = rnd((k, m), 3)
        W = W * (np.abs(W) > np.quantile(np.abs(W), 0.5))

        def sp(tp):
            return tp.spmm(tp.tensor(W.T.tolist()), tp.tensor(rnd((k, n), 4).tolist()), "csr")

        def dn(tp):
            return tp.tensor(W.T.tolist()) @ tp.tensor(rnd((k, n), 4).tolist())
        a, b = counted(sp), counted(dn)
        return {"metric": "ops", "a": a[0], "b": b[0], "ratio_b_over_a": b[0] / a[0], "bytes_a": a[1], "bytes_b": b[1]}
    raise ValueError(kind)


# ---------------------------------------------------------------------------------------------------------- the measured side

def timed(fn, device, repeats, torch):
    def sync():
        if device == "mps":
            torch.mps.synchronize()
        elif device == "cuda":
            torch.cuda.synchronize()
    for _ in range(3):
        fn()
    sync()
    out = []
    for _ in range(repeats):
        t = time.perf_counter()
        fn()
        sync()
        out.append(time.perf_counter() - t)
    return out


def peak_memory(fn, device, torch):
    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()
        fn()
        torch.cuda.synchronize()
        return torch.cuda.max_memory_allocated()
    if device == "mps":
        torch.mps.empty_cache()
        base = torch.mps.current_allocated_memory()
        fn()
        torch.mps.synchronize()
        return max(torch.mps.driver_allocated_memory() - base, 1)
    import tracemalloc
    return None


def measure(p, device, repeats, torch):
    kind, shape = p["kind"], p["shape"]
    dev = torch.device(device)
    g = torch.Generator().manual_seed(0)
    mk = lambda *s, dt=torch.float32: (torch.randn(*s, generator=g) * 0.1).to(dev).to(dt)
    if kind == "mlp_dtype":
        n, d, h = shape
        dt = {"bf16": torch.bfloat16, "fp16": torch.float16, "fp32": torch.float32}
        a_dt, b_dt = dt[p["a"]], dt[p["b"]]
        xa, W1a, W2a = mk(n, d, dt=a_dt), mk(d, h, dt=a_dt), mk(h, d, dt=a_dt)
        xb, W1b, W2b = mk(n, d, dt=b_dt), mk(d, h, dt=b_dt), mk(h, d, dt=b_dt)
        fa = lambda: torch.relu(xa @ W1a) @ W2a
        fb = lambda: torch.relu(xb @ W1b) @ W2b
        return {"a": timed(fa, device, repeats, torch), "b": timed(fb, device, repeats, torch), "unit": "s"}
    if kind == "attn":
        B, H, T, dh = shape
        q, k, v = (mk(B, H, T, dh) for _ in range(3))
        mask = torch.triu(torch.full((T, T), float("-inf"), device=dev), 1)
        fused = lambda: torch.nn.functional.scaled_dot_product_attention(q, k, v, is_causal=True)
        naive = lambda: torch.softmax(q @ k.transpose(-1, -2) / math.sqrt(dh) + mask, -1) @ v
        return {"a": timed(fused, device, repeats, torch), "b": timed(naive, device, repeats, torch), "unit": "s"}
    if kind in ("ckpt", "ckpt_time"):
        L, n, d = shape
        Ws = [mk(d, d).requires_grad_(True) for _ in range(L)]
        x0 = mk(n, d)

        def seg(h, i0, i1):
            for i in range(i0, i1):
                h = torch.relu(h @ Ws[i])
            return h

        def store():
            h = x0
            for i in range(L):
                h = torch.relu(h @ Ws[i])
            h.sum().backward()

        def ckpt():
            h = x0
            for s in range(0, L, 4):
                h = torch.utils.checkpoint.checkpoint(seg, h, s, s + 4, use_reentrant=False)
            h.sum().backward()
        if kind == "ckpt":
            if device == "cuda":
                return {"a": [float(peak_memory(ckpt, device, torch))], "b": [float(peak_memory(store, device, torch))], "unit": "bytes", "memory": True}
            return {"error": "no reliable per-program peak-memory counter on this device (a process high-water mark or a driver pool size is not a peak): not measured, not guessed"}
        return {"a": timed(ckpt, device, repeats, torch), "b": timed(store, device, repeats, torch), "unit": "s"}
    if kind == "sparse":
        n, k, m = shape
        W = mk(k, m)
        W = W * (W.abs() > W.abs().flatten().quantile(0.5))
        x = mk(n, k)
        dense = lambda: x @ W
        try:
            Wt = W.t().contiguous().to_sparse_csr()
            xt = x.t().contiguous()
            sparse = lambda: Wt @ xt
            sparse()
        except Exception as e:                      # the device has no sparse kernel: recorded, not guessed
            return {"error": f"{type(e).__name__}: {str(e)[:120]}"}
        return {"a": timed(sparse, device, repeats, torch), "b": timed(dense, device, repeats, torch), "unit": "s"}
    raise ValueError(kind)


# ---------------------------------------------------------------------------------------------------------- the report

def verdict(pred, meas):
    pr = pred["ratio_b_over_a"]
    if meas is None or "error" in meas:
        return {"status": "not measured", "why": (meas or {}).get("error", "no measurement")}
    ma, mb = statistics.median(meas["a"]), statistics.median(meas["b"])
    mr = mb / ma
    lo = min(meas["b"]) / max(meas["a"])
    hi = max(meas["b"]) / min(meas["a"])
    same = (pr > 1.02 and mr > 1.0) or (pr < 0.98 and mr < 1.0) or (0.98 <= pr <= 1.02 and 0.9 <= mr <= 1.1)
    return {"status": "agrees" if same else "DISAGREES", "predicted_ratio_b_over_a": round(pr, 4), "measured_ratio_b_over_a": round(mr, 4), "measured_range": [round(lo, 4), round(hi, 4)],
            "size_error_factor": round(max(pr, mr) / min(pr, mr), 3), "unit": meas.get("unit")}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--device", default=None)
    ap.add_argument("--repeats", type=int, default=9)
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    import torch
    import torch.utils.checkpoint
    device = a.device or ("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    sizes = [(1024, 1024, 4096), (2048, 1024, 4096)]
    rows = []
    for p in pairs(sizes):
        pred = predict(p)
        try:
            meas = measure(p, device, a.repeats, torch)
        except Exception as e:
            meas = {"error": f"{type(e).__name__}: {str(e)[:150]}"}
        v = verdict(pred, meas)
        rows.append({"pair": p["name"], "metric_predicted": pred["metric"], "prediction": {k: val for k, val in pred.items() if k != "metric"}, "measured": None if "error" in meas else {"a_seconds": meas["a"], "b_seconds": meas["b"]} if not meas.get("memory") else {"a": meas["a"], "b": meas["b"]}, "verdict": v})
        print(f"{p['name'][:84]:84s} {v['status']:12s} predicted {v.get('predicted_ratio_b_over_a', '-')}  measured {v.get('measured_ratio_b_over_a', '-')}", flush=True)
    doc = {"format": "svp-validate-counts-v1", "device": device, "torch": torch.__version__, "repeats": a.repeats, "pairs": rows,
           "summary": {s: sum(r["verdict"]["status"] == s for r in rows) for s in ("agrees", "DISAGREES", "not measured")}}
    if a.out:
        if os.path.exists(a.out):
            sys.exit(f"{a.out} exists")
        with open(a.out, "w") as f:
            json.dump(doc, f, indent=1)
        print("wrote", a.out)
    return doc


if __name__ == "__main__":
    main()
