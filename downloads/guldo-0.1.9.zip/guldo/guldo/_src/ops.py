"""Operator tool for a public competition. Run it as the OPERATOR user, never as the web tier's user (it reads seeds).

  ops.py round-new  --data D --seed-dir S --id r1 --title "..." --family gm --closes 2026-12-31T23:59:00Z [--seeds 3]
        Create k secret seeds under S/<id> (mode 0600, outside the project tree), publish their commitments as entry 0 of
        the round's log, and open the round. The commitments are public from this moment.
        With --count --count-dims 38 40 42 [--count-n 8 --count-cap 20] it is a COUNTED round (deterministic step counting on a ladder committed in
        entry 0; every submission must publish its source; the worker then needs --unsandboxed). See COMPILER.md, "Counted rounds".
  ops.py close      --data D --id r1 [--force]          close at the deadline (or earlier with --force; logged)
  ops.py worker     --data D --id r1 --seed-dir S/r1     evaluate every queued submission IN THE DOCKER SANDBOX; refuses unless the
                                                          sandbox is verified (portal.py verify-sandbox)
  ops.py reveal     --data D --id r1 --seed-dir S/r1     publish the seeds, only after evaluation, only if they match the commitments
  ops.py preflight  --data D [--seed-dir S]                is THIS host set up as DEPLOY.md says (seed permissions, no seed in the data dir, sandbox marker, logs)
  ops.py certs      --data D --id r1 --seed-dir S/r1     after the reveal: build a verified certificate per evaluated submission (stored beside the round;
                                                          public copy for everyone (no solver source unless the owner published it), full copy to the owner)
  ops.py export     --data D --out site/ledger            write rounds.json, round_<id>.json, log_<id>.jsonl for the static site
  ops.py verify-log --data D --id r1                      check a round's hash chain (exit 1 if it fails)
  ops.py status     --data D
  ops.py kill-switch --data D on|off                      pause / resume submissions at the web tier
"""
import argparse
import calendar
import json
import os
import sys
import time

import families
import official
import portal_core
import rounds

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_MAX_SUBMISSIONS = 50


def parse_when(s):
    try:
        return calendar.timegm(time.strptime(s, "%Y-%m-%dT%H:%M:%SZ"))
    except ValueError:
        raise SystemExit(f"bad time {s!r}: use UTC like 2026-12-31T23:59:00Z")


def preflight(base, seed_root=None):
    """Is THIS machine set up the way DEPLOY.md says? -> [(status, check, detail)], status in pass / warn / fail. Read-only: it creates nothing."""
    import shutil
    import stat
    out = []
    add = lambda st, name, detail: out.append((st, name, detail))
    base = os.path.abspath(base)
    if os.path.isdir(os.path.join(base, "rounds")):
        add("pass", "data directory", base)
        mode = stat.S_IMODE(os.stat(base).st_mode)
        add("pass" if mode & 0o020 else "warn", "data directory shared with the web tier",
            f"mode {oct(mode)}: group-writable" if mode & 0o020 else f"mode {oct(mode)} is not group-writable: the web tier (another user, same group) could not record submissions")
        stray = [os.path.join(dp, f) for dp, _, fs in os.walk(base) for f in fs if f.endswith(".seed")]
        add("fail" if stray else "pass", "no seed under the data directory", f"{len(stray)} seed file(s) found, e.g. {stray[0]}: the web tier can read this directory" if stray else "none")
    else:
        add("fail", "data directory", f"{base} has no rounds/ directory (create it as in DEPLOY.md step 2)")
    if seed_root:
        sr = os.path.abspath(os.path.expanduser(seed_root))
        if not os.path.isdir(sr):
            add("fail", "seed directory", f"{sr} does not exist")
        else:
            mode = stat.S_IMODE(os.stat(sr).st_mode)
            add("pass" if not mode & 0o077 else "fail", "seed directory is private", f"mode {oct(mode)}" + ("" if not mode & 0o077 else
                ": group or others can enter it, so the web tier could read the seeds. chmod 0700 and own it by the operator only"))
            inside = sr == base or sr.startswith(base + os.sep) or sr == HERE or sr.startswith(HERE + os.sep)
            add("fail" if inside else "pass", "seed directory is outside the data and code trees", "it is inside one of them" if inside else "outside both")
            loose = [os.path.join(dp, f) for dp, _, fs in os.walk(sr) for f in fs if f.endswith(".seed") and stat.S_IMODE(os.stat(os.path.join(dp, f)).st_mode) & 0o077]
            add("fail" if loose else "pass", "seed files are owner-only", f"{len(loose)} readable by others, e.g. {loose[0]}" if loose else "all 0600 or tighter")
    code_mode = stat.S_IMODE(os.stat(HERE).st_mode)
    add("fail" if code_mode & 0o002 else "pass", "code directory not world-writable", f"mode {oct(code_mode)}")
    try:
        rounds.require_python()
        add("pass", "python", sys.version.split()[0])
    except SystemExit as e:
        add("fail", "python", str(e))
    ok = portal_core.sandbox_verified(base)
    add("pass" if ok else "warn", "sandbox verified", "the marker is present and matches the sandbox files" if ok else
        "NO: submissions can be taken and logged, but no round can be evaluated (`python3 portal.py verify-sandbox --data D` on the evaluating host)")
    add("pass" if shutil.which("docker") else "warn", "docker on this host", shutil.which("docker") or "not found: evaluate on a host that has it (DEPLOY.md, separate VM)")
    add("warn" if os.path.exists(os.path.join(base, "KILL_SWITCH")) else "pass", "kill switch", "ON: submissions are paused" if os.path.exists(os.path.join(base, "KILL_SWITCH")) else "off")
    for r in rounds.list_rounds(base) if os.path.isdir(os.path.join(base, "rounds")) else []:
        good, n, head, err = rounds.verify_log(rounds.rdir(base, r["id"]), r["commitments"])
        add("pass" if good else "fail", f"round {r['id']}: log", f"{n} entries, head {head[:16]}" if good else err)
    return out


def main(argv=None):
    rounds.require_python()
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("round-new")
    for a in ("--data", "--seed-dir", "--id", "--title", "--family", "--closes"):
        p.add_argument(a, required=True)
    p.add_argument("--seeds", type=int, default=3)
    p.add_argument("--n", type=int, default=None,
                   help="instances per size (default: the family's official value, 24 for gm). A larger n is logged as the round's rule and lets a "
                        "round certify larger speedups (see PROTOCOL.md, Power at the official configuration) at proportionally more machine time.")
    p.add_argument("--require-source", action="store_true",
                   help="every submission must publish its source (after the reveal). Logged in the round's first entry as a public rule. Without it a submitter "
                        "may keep their solver private: the public certificate then carries only its hash, and its timings rest on your sandbox alone")
    p.add_argument("--max-submissions", type=int, default=DEFAULT_MAX_SUBMISSIONS,
                   help=f"submissions this round will accept (default {DEFAULT_MAX_SUBMISSIONS}; at most {rounds.MAX_PER_ROUND}). It is logged in the round's "
                        "first entry. A submission that fails everything is charged the cap on every instance, so each can cost hours: size this to your machine.")
    p.add_argument("--count", action="store_true",
                   help="a COUNTED round: submissions and the baseline are measured by deterministic step counting (counted.py) on the ladder given by --count-dims/--count-n/"
                        "--count-cap, committed in the round's first log entry. Anyone re-executes the counts to check them, so the result does not rest on your machine or "
                        "sandbox. Needs a pure-Python family (factor), Python 3.12+ here, and forces --require-source (the proof is re-execution). Its worker runs solvers "
                        "UNSANDBOXED (`worker --unsandboxed`): use a throwaway user or VM. Not available for the lattice families")
    p.add_argument("--count-dims", type=int, nargs="+", help="with --count: the sizes to count (e.g. 38 40 42 for factor)")
    p.add_argument("--count-n", type=int, default=8, help="with --count: instances per size (default 8)")
    p.add_argument("--count-cap", type=float, default=20.0, help="with --count: the most counted seconds (x 1e6 instructions) one instance may use (default 20)")
    p.add_argument("--opens")
    p.add_argument("--allow-few-seeds", action="store_true", help="demo only: a round with fewer than 3 seeds can never be official")
    p = sub.add_parser("close")
    p.add_argument("--data", required=True)
    p.add_argument("--id", required=True)
    p.add_argument("--force", action="store_true")
    for name in ("worker", "reveal"):
        p = sub.add_parser(name)
        p.add_argument("--data", required=True)
        p.add_argument("--id", required=True)
        p.add_argument("--seed-dir", required=True)
        if name == "worker":
            p.add_argument("--accept-code-change", action="store_true",
                           help="evaluate even though the ladder/baseline/scoring code differ from what the round committed to; logged publicly")
            p.add_argument("--unsandboxed", action="store_true",
                           help="COUNTED rounds only: confirm that solvers run unsandboxed under step counting (as a throwaway user or VM with nothing of value on it)")
            p.add_argument("--results-dir", help="where a counted evaluation writes its ladders (default: this project's results/)")
    p = sub.add_parser("preflight")
    p.add_argument("--data", required=True)
    p.add_argument("--seed-dir", help="the operator's seed root (e.g. /srv/ledger/seeds): its permissions are checked")
    p = sub.add_parser("certs")
    p.add_argument("--data", required=True)
    p.add_argument("--id", required=True)
    p.add_argument("--seed-dir", required=True)
    p.add_argument("--results-dir", help="where the evaluation wrote its ladders (default: this project's results/)")
    p = sub.add_parser("export")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p = sub.add_parser("verify-log")
    p.add_argument("--data", required=True)
    p.add_argument("--id", required=True)
    p = sub.add_parser("status")
    p.add_argument("--data", required=True)
    p = sub.add_parser("kill-switch")
    p.add_argument("--data", required=True)
    p.add_argument("state", choices=["on", "off"])
    a = ap.parse_args(argv)
    base = os.path.abspath(a.data)
    # The web tier runs as a DIFFERENT user in a shared group (DEPLOY.md). Under the default umask 022 everything created here is
    # 0755/0644, which that user cannot write: no submission would ever succeed. Group-writable, nothing for others.
    old_umask = os.umask(0o007)
    try:
        return _run(a, base)
    finally:
        os.umask(old_umask)  # main() is also called from tests; do not leave process-wide state changed


def _run(a, base):
    if a.cmd != "preflight":  # a read-only check must never create the directory it is checking (a mistyped --data would then "pass")
        os.makedirs(os.path.join(base, "rounds"), exist_ok=True)
    try:
        if a.cmd == "round-new":
            if not a.allow_few_seeds and a.seeds < 3:
                raise SystemExit("REFUSED: an official round needs at least 3 seeds")
            # validate EVERYTHING before any seed exists: a typo must not leave seeds on disk that make the corrected retry fail
            if not rounds.ROUND_ID_RE.match(a.id):
                raise SystemExit("REFUSED: round id must be 2-41 characters of a-z, 0-9 and '-'")
            if a.family not in families.FAMILIES:
                raise SystemExit(f"REFUSED: unknown family {a.family!r} (one of {sorted(families.FAMILIES)})")
            count = None
            if a.count:
                if a.n is not None:
                    raise SystemExit("REFUSED: --n is for timed rounds; a counted round's instances per size is --count-n")
                if not a.count_dims:
                    raise SystemExit("REFUSED: --count needs --count-dims (the sizes to count, small enough that counting finishes: e.g. --family factor --count-dims 38 40 42)")
                count = {"dims": a.count_dims, "n": a.count_n, "cap": a.count_cap}
                rounds.count_config(a.family, **count)   # every value checked before any seed exists (raises Rejected: nothing is created)
            elif a.count_dims:
                raise SystemExit("REFUSED: --count-dims only goes with --count")
            if a.n is not None and not (families.OFFICIAL[a.family]["n"] <= a.n <= rounds.MAX_N):
                raise SystemExit(f"REFUSED: n must be an integer from {families.OFFICIAL[a.family]['n']} to {rounds.MAX_N} (instances per size)")
            closes, opens = parse_when(a.closes), (parse_when(a.opens) if a.opens else time.time())
            if closes <= time.time():
                raise SystemExit("REFUSED: the deadline must be in the future")
            if closes <= opens:
                raise SystemExit("REFUSED: the deadline must be after the opening time")
            seed_dir = os.path.join(os.path.abspath(os.path.expanduser(a.seed_dir)), a.id)
            if os.path.exists(os.path.join(rounds.rdir(base, a.id), "round.json")):
                raise SystemExit(f"REFUSED: round {a.id!r} already exists")
            commits = official.make_commitments(seed_dir, a.seeds)
            r = rounds.create_round(base, a.id, a.title, a.family, commits, closes,
                                    opens_at=parse_when(a.opens) if a.opens else None, allow_few_seeds=a.allow_few_seeds,
                                    max_submissions=a.max_submissions, n=a.n, allow_private=not a.require_source, count=count)
            print(f"round {r['id']} is open until {a.closes}. Seeds are in {seed_dir} (mode 0600): keep that directory off the web tier's user.")
            if count is not None:
                import counted
                c = r["count"]
                worst_h = len(c["dims"]) * c["n"] * len(commits) * c["cap"] * counted.STEPS_PER_SECOND / counted.SLOW_STEPS_PER_SECOND / 3600.0
                print(f"COUNTED round: sizes {c['dims']}, {c['n']} instances per size, cap {c['cap']:g} counted seconds ({int(c['cap'] * counted.STEPS_PER_SECOND):,} instructions), "
                      f"on {c['python']}; all of it committed in the first log entry. Every submission must publish its source (the proof is re-execution).\n"
                      f"Counting is slow: worst case (every instance spending its whole cap at a pessimistic throughput) about {worst_h:.1f} hours per submission, plus the same "
                      f"for the baselines once; a solver that works costs far less. The worker needs `--unsandboxed` and must run as a throwaway user or VM; the same Python "
                      f"({c['python']}) must be used to evaluate and by anyone re-running.\ncommitments (already public in the log):\n" + "\n".join(r["commitments"]))
                return 0
            plan = official.plan_cost(a.family, len(commits), n=r["n"], budget=r["budget"])
            per_sub = plan["instances_per_ladder"] * len(commits) * r["budget"] / 3600.0  # a submission failing every instance, charged the cap each time
            base_h = per_sub  # the baseline ladders, measured once per seed and reused
            print(f"{r['n']} instances per size; "
                  f"worst case (every submission fails every instance, each charged the {r['budget']:g} s cap): {per_sub:.1f} CPU-hours per submission, "
                  f"so {r['max_submissions']} submissions = {per_sub * r['max_submissions']:.1f} h, plus {base_h:.1f} h for the baselines. "
                  "A solver that works costs far less. Lower --max-submissions if that exceeds your machine time.")
            print("Solvers: " + ("every submission must publish its source (a public rule, logged in the first entry)." if a.require_source else
                                 "a submitter may keep their solver private (the public certificate carries only its hash; its timings then rest on your sandbox alone). "
                                 "Use --require-source if you do not want that."))
            print("commitments (already public in the log):\n" + "\n".join(r["commitments"]))
        elif a.cmd == "close":
            r = rounds.close_round(base, a.id, force=a.force)
            print(f"round {a.id}: {r['state']}")
        elif a.cmd == "worker":
            n = rounds.evaluate_round(base, a.id, a.seed_dir, lambda: portal_core.sandbox_verified(base), allow_code_change=a.accept_code_change,
                                      results_dir=a.results_dir, allow_unsandboxed=a.unsandboxed)
            print(f"evaluated {n} submission(s); round is {rounds.get_round(base, a.id)['state']}")
        elif a.cmd == "reveal":
            seeds = rounds.reveal(base, a.id, a.seed_dir)
            print(f"revealed {len(seeds)} seed(s) for round {a.id}")
        elif a.cmd == "preflight":
            res = preflight(base, a.seed_dir)
            for st, name, detail in res:
                print(f"  {st.upper():4s} {name}: {detail}")
            bad = [r for r in res if r[0] == "fail"]
            print("\nREADY (warnings are things only you can judge)" if not bad else f"\n{len(bad)} problem(s) to fix before this host serves a round")
            return 1 if bad else 0
        elif a.cmd == "certs":
            res = rounds.build_certificates(base, a.id, a.seed_dir, a.results_dir)
            print(f"built {len(res['built'])} certificate(s) for round {a.id}")
            for sid, why in sorted(res["skipped"].items()):
                print(f"  skipped {sid}: {why}")
            print("The public certificate (GET /api/cert/<round>/<id>.json) is open to everyone: it carries the solver's source only for submissions whose owner "
                  "chose to publish it; for the others it is a PRIVATE-SOLVER copy (hash, no source, no failure text). The full certificate with the source "
                  "(GET /api/cert-full/<round>/<id>.json) is served only to the holder of the handle's token, in an `Authorization: Bearer` header.")
        elif a.cmd == "export":
            os.umask(0o022)  # these files are SERVED by another user (the static-site web server): they must be world-readable
            idx = rounds.export_public(base, a.out)
            print(f"exported {len(idx)} round(s) to {a.out}")
        elif a.cmd == "verify-log":
            r = rounds.get_round(base, a.id)
            ok, n, head, err = rounds.verify_log(rounds.rdir(base, a.id), r["commitments"])
            print(f"{'OK' if ok else 'FAILED'}: {n} entries" + (f", head {head}" if ok else f": {err}"))
            problems = rounds.check_consistency(base, a.id, hash_files=True) if ok else []
            for p in problems:  # the chain can be intact while the stored files are not: check them against the hashes it commits to
                print("INCONSISTENT: " + p)
            if ok and not problems:
                print("Publish this head hash somewhere the operator cannot edit it (a signed post, a git tag) to anchor the log.")
            return 0 if ok and not problems else 1
        elif a.cmd == "status":
            print(f"sandbox verified: {portal_core.sandbox_verified(base)}   kill switch: {os.path.exists(os.path.join(base, 'KILL_SWITCH'))}")
            for r in rounds.list_rounds(base):
                subs = rounds.list_submissions(base, r["id"])
                print(f"{r['id']:20s} {r['family']:7s} {r['state']:11s} closes {time.strftime('%Y-%m-%d %H:%M', time.gmtime(r['closes_at']))} UTC  "
                      f"{len(subs)} submission(s), {sum(1 for m in subs if m['state'] == 'queued')} queued")
        elif a.cmd == "kill-switch":
            path = os.path.join(base, "KILL_SWITCH")
            if a.state == "on":
                open(path, "w", encoding="utf-8").close()
            elif os.path.exists(path):
                os.remove(path)
            print(f"kill switch {a.state}")
    except rounds.Rejected as e:
        print(str(e), file=sys.stderr)
        return 1
    except KeyError as e:
        print(f"no such round: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
