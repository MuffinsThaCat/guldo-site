"""Declaration of a NON-CONVEX AI-training domain: train a small two-layer ReLU network to a target held-out accuracy using as few operations as you can.

size = d, the number of input features. The training set holds N = 100 d points. Features are ILL-CONDITIONED on purpose: feature j is scaled by 10^(-j/(d-1)), so the scales run
from 1 down to 1/10, and the hidden teacher's first-layer weights are scaled inversely, so every feature matters equally to the label even though most are small. The student is a
fixed 32-unit hidden layer, so the loss is non-convex (a ReLU network: plateaus, dead units, a result that depends on the optimiser and its start), unlike aitrain's convex softmax
regression. Plain gradient descent crawls on the small features; feature scaling, momentum and adaptive steps are what this domain exists to compare, on a loss where their
benefit is not guaranteed by convexity.

Neither the teacher nor the test set is shipped. The teacher is a two-layer ReLU network with 8 hidden units and 3 classes (labels = argmax of its logits); the solver gets the training
features (a pure function of one seed through a pinned SplitMix64 stream, the same one the other AI domains use, so a counted solver regenerates them with tensorops.stream) and the
training LABELS. The teacher and a 2000-point test set come from two OTHER seeds derived from the round's master seed with HMAC; nobody sees them until the seed is revealed, so there
is nothing to train on but the training set. A random ReLU teacher often sends nearly every input to one class, and then a constant answer would pass; such a teacher is drawn again
until no class takes more than half of the test inputs, and again if a LINEAR model (least squares on the instance's own training set, no hidden layer) already reaches 84% on the test inputs: so
every instance needs real learning and, with the target at 87%, genuinely needs the non-linear network. The student's own starting weights are the SOLVER's choice (a fixed rule of its own, from any stream it likes).

The answer is the student's weights as a flat list of 32*d + 32*3 INTEGERS: the d x 32 first-layer matrix row-major, then the 32 x 3 second-layer matrix row-major, each in units of 2^-20
(the timed harness accepts only integers). The judge accepts it iff its accuracy on the hidden test set is at least TARGET (0.87). Stopping early, or training a worse network, fails the
check; training longer than needed only costs operations.

The cost is counted operations (tflops.py), or operations, bytes and peak memory (tflops_mem.py): exact, reproducible on any machine, never a time.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aimlp"
VERSION = "aimlp-v3"          # bump whenever derive() or the task definition changes (v2: teachers dominated by one class are rejected; v3: ... and teachers a linear model nearly solves, target raised)
SPEEDUP = "ai-training"
SIZE_RANGE = (8, 16)
SIZE_STEP = 4
REFERENCE_SOLVER = "reference.py"
K = 3                         # classes
HIDDEN = 32                   # the student's hidden width (part of the answer format)
TEACHER_HIDDEN = 8
TEACHER_SCALE = 3.0
KAPPA = 10.0                  # ratio between the largest and smallest feature scale
N_PER_D = 100                 # training points per feature
N_TEST = 2000
MAX_SHARE = 0.50              # no class may take more than this share of the test inputs, or a constant answer would come close to the target
MAX_TEACHERS = 100            # teachers tried before giving up (a balanced one needs about 3.5 draws on average, never more than about 20)
LINEAR_MAX = 0.84            # a linear least-squares fit on the instance's own training set may not reach this on its test set, or the instance would not need the network
TARGET = 0.87                 # held-out accuracy the network must reach (a linear model stays below LINEAR_MAX < TARGET on every instance)
SCALE = 2 ** 20               # the answer's integers are weights in units of 1/SCALE
LIMIT = 2 ** 62
DOC = ("solve(seed, d, N, labels): the N = 100 d training features are x[i][j] = u * 10^(-j/(d-1)) where u is the i*d+j-th float of the SplitMix64 stream under `seed` "
       "(tensorops.stream(seed, 0, N*d), the same floats as domains/aiinfer); labels is the list of N training classes (ints 0-2). Train a network logits = relu(x @ W1) @ W2 with "
       "W1 of shape d x 32 and W2 of shape 32 x 3 (your own starting weights) and return W1 row-major then W2 row-major as a flat list of 32*d + 96 integers, each weight in units "
       "of 2^-20, whose argmax predictions are right on at least 87% of a hidden test set drawn from the same distribution. Return None for no answer.")
REFERENCE_NOTE = ("Plain full-batch gradient descent on the softmax loss: learning rate 0.5, 12000 steps, no feature scaling and no momentum, starting from small random weights. The slowest of "
                  "48 calibration instances needed 5800 steps to reach the target, so 12000 passes with margin. Known to be beaten by scaling each feature to unit size (tens of times "
                  "fewer steps), by momentum, and by adaptive step sizes.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _scales(d):
    return np.array([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])


def _features(seed, d, n):
    return _uniform(seed, 0, n * d).reshape(n, d) * _scales(d)


def _teacher(tseed, d):
    W1 = _uniform(tseed, 0, d * TEACHER_HIDDEN).reshape(d, TEACHER_HIDDEN) * math.sqrt(3.0 / d) * TEACHER_SCALE / _scales(d)[:, None]
    W2 = _uniform(tseed ^ 0x2222, 0, TEACHER_HIDDEN * K).reshape(TEACHER_HIDDEN, K) * math.sqrt(3.0 / TEACHER_HIDDEN) * TEACHER_SCALE
    return W1, W2


def _predict(X, W1, W2):
    return np.argmax(np.maximum(X @ W1, 0.0) @ W2, axis=1)


def _seed(master, tag, size, idx):
    return int.from_bytes(hmac.new(master, f"aimlp-v3:{tag}:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    d = size
    n = N_PER_D * d
    seed, vseed = _seed(master, "train", size, idx), _seed(master, "test", size, idx)
    X, probe = _features(seed, d, n), _features(vseed, d, N_TEST)
    for attempt in range(MAX_TEACHERS):          # a random ReLU teacher is often degenerate: such an instance is drawn again
        tseed = _seed(master, f"teacher{attempt}", size, idx)
        T1, T2 = _teacher(tseed, d)
        truth = _predict(probe, T1, T2)
        if np.bincount(truth, minlength=K).max() > MAX_SHARE * N_TEST:      # one class takes nearly every input: a constant answer would pass
            continue
        y = _predict(X, T1, T2)
        lin = np.linalg.lstsq(X, np.eye(K)[y], rcond=None)[0]               # ... or a linear model (no hidden layer, no non-convexity) nearly solves it
        if np.mean(np.argmax(probe @ lin, axis=1) == truth) < LINEAR_MAX:
            break
    else:
        raise ValueError("no suitable teacher found")
    W1 = np.zeros((d, HIDDEN))
    W2 = np.zeros((HIDDEN, K))
    W1[:, :TEACHER_HIDDEN], W2[:TEACHER_HIDDEN, :] = T1, T2           # the teacher itself, padded with dead units, is a valid answer
    planted = [int(v) for v in np.rint(np.concatenate([W1.ravel(), W2.ravel()]) * SCALE)]
    return {"args": [seed, d, n, [int(v) for v in y]], "planted": planted, "teacher_seed": tseed, "test_seed": vseed}


def verify(inst: dict, ans) -> bool:
    seed, d, n, labels = inst["args"]
    if not isinstance(ans, list) or len(ans) != d * HIDDEN + HIDDEN * K:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    flat = np.array(ans, dtype=np.float64) / SCALE
    W1, W2 = flat[:d * HIDDEN].reshape(d, HIDDEN), flat[d * HIDDEN:].reshape(HIDDEN, K)
    T1, T2 = _teacher(inst["teacher_seed"], d)
    Xt = _features(inst["test_seed"], d, N_TEST)
    return bool(np.mean(_predict(Xt, W1, W2) == _predict(Xt, T1, T2)) >= TARGET)
