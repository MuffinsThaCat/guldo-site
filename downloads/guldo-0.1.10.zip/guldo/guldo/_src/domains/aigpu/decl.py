"""Declaration of a GPU domain: multi-head attention followed by a linear read-out, classified per position, as fast as a GPU can, at equivalent output.

size = n, the sequence length. There are H = 4 heads of dimension dk = 64 (model width d = 256) and 16 classes. Queries, keys and values (each H x n x dk) and the read-out matrix (d x 16) are NOT shipped as data:
they are a pure function of one 63-bit seed through the pinned SplitMix64 stream that `aiinfer` and `aitrain` use (u in [-1, 1)), in this order:
    Q = 3 u[0 : H n dk],   K = u[H n dk : 2 H n dk],   V = u[2 H n dk : 3 H n dk]   (each as H x n x dk, row-major),     Wout = u[3 H n dk : 3 H n dk + 16 d] as d x 16, times sqrt(3/d).
For every head h:  P_h = softmax(Q_h K_h^T / sqrt(dk)) (n x n, row-wise) and O_h = P_h V_h (n x dk). The heads are concatenated, O = [O_0 | ... | O_{H-1}] (n x d), the logits are O Wout (n x 16), and the
answer is the list of n labels (ints 0-15), the class of the largest logit of each position. The judge recomputes the float64 logits and accepts an answer in which every label is within 0.1 standard deviations
(of all the instance's logits) of the best logit of its position, for at least 99% of positions. That is the "equivalent result" the saving is conditional on: fp16 or a fused kernel passes; a local window instead of
full attention, or a dropped softmax, fails (solvers/aigpu_gpu_window.py, aigpu_mem_window.py).

Three ways to measure the same task, and what each can and cannot say (PROTOCOL.md has the long form):
  * COUNTED (tflops_mem.py, the solvers `aigpu_mem_*`): exact operations, bytes moved and peak memory under the project's convention (every operation reads its operands and writes its result, NO fusion, NO cache),
    and from them an exact statement about speed on ANY device by roofline (roofline.py). Anyone can recompute it; it cannot see what a fused kernel does, because a fused kernel is exactly what the convention
    does not model: fusion moves fewer bytes than the count.
  * MEASURED on a device (gpu_bench.py for any PyTorch device: CUDA, Apple MPS or CPU; gpu_meter.py for the stricter NVIDIA-only protocol, the solvers `aigpu_gpu_*`): real wall-clock time of real kernels, including
    fused ones, on ONE device model, taken by whoever ran it: nobody else can re-execute it exactly.
  * FIXED COST. Every solver regenerates the inputs inside solve(): the GPU solvers generate them on the device itself, with the same SplitMix64 stream in int64 arithmetic (which wraps exactly as the judge's uint64
    does; each value is the stream's top 24 bits, within 2^-23 of the judge's float64), so a timed run includes that cost. `aigpu_gpu_noop.py` pays exactly it and nothing else, so the bench can report each
    solver's time net of it. (An earlier version generated them on the host with numpy: that took 3 to 15 ms and drowned the kernels being compared.)
The inputs are a function of the seed, not data: the answer is judged on the instance, with nothing hidden.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aigpu"
VERSION = "aigpu-v1"          # bump whenever derive() or the task definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (128, 4096)
SIZE_STEP = 128
REFERENCE_SOLVER = "reference.py"
HEADS = 4
DK = 64
CLASSES = 16
Q_SCALE = 3.0
TOL_SIGMA = 0.1               # a label is acceptable if its logit >= max logit - TOL_SIGMA * std(all logits of the instance)
MAX_BAD_FRACTION = 0.01       # at most floor(0.01 * n) labels may be unacceptable
DOC = ("solve(seed, n, H, dk): regenerate Q, K, V (each H x n x dk) and Wout (H*dk x 16) from `seed` with the SplitMix64 stream documented in domains/aiinfer/reference.py (u in [-1, 1); Q = 3u, K = u, V = u, in that "
       "order, then Wout = u * sqrt(3/(H*dk))). For each head P = softmax(Q K^T / sqrt(dk)) row-wise, O = P V; concatenate the heads to n x (H*dk), logits = O Wout, and return the list of n class labels "
       "(ints 0-15). A label counts if its logit is within 0.1 standard deviations of the position's best logit; at most 1% of labels may miss. Return None for no answer.")
REFERENCE_NOTE = ("float32 on the device, ONE HEAD AT A TIME, with the n x n score matrix materialised and a separate kernel for each step (the straightforward way to write it). Known to be beaten by batching the heads, "
                  "by a fused attention kernel (which never writes the score matrix), and by half precision.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def inputs(seed, n, H=HEADS, dk=DK):
    m = H * n * dk
    d = H * dk
    Q = (_uniform(seed, 0, m) * Q_SCALE).reshape(H, n, dk)
    K = _uniform(seed, m, m).reshape(H, n, dk)
    V = _uniform(seed, 2 * m, m).reshape(H, n, dk)
    Wout = _uniform(seed, 3 * m, d * CLASSES).reshape(d, CLASSES) * math.sqrt(3.0 / d)
    return Q, K, V, Wout


def logits(seed, n, H=HEADS, dk=DK):
    Q, K, V, Wout = inputs(seed, n, H, dk)
    S = Q @ K.transpose(0, 2, 1) / math.sqrt(dk)
    S -= S.max(axis=2, keepdims=True)
    P = np.exp(S)
    P /= P.sum(axis=2, keepdims=True)
    O = (P @ V).transpose(1, 0, 2).reshape(n, H * dk)
    return O @ Wout


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aigpu-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, HEADS, DK], "planted": [int(v) for v in np.argmax(logits(seed, size), axis=1)]}


def verify(inst: dict, ans) -> bool:
    seed, n, H, dk = inst["args"]
    if not isinstance(ans, list) or len(ans) != n:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or not 0 <= v < CLASSES for v in ans):
        return False
    L = logits(seed, n, H, dk)
    ok = L[np.arange(n), np.asarray(ans)] >= L.max(axis=1) - TOL_SIGMA * L.std()
    return bool(int((~ok).sum()) <= int(MAX_BAD_FRACTION * n))
