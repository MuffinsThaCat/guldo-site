"""Reference for aipipetrain: the dense gradient on one device in float64 (the judge's own computation)."""
import math

import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, B, P):
    x = _uniform(seed, 0, B * d).reshape(B, d)
    T = _uniform(seed, B * d, B * d).reshape(B, d)
    Ws = [_uniform(seed, 2 * B * d + l * d * d, d * d).reshape(d, d) * math.sqrt(3.0 / d) for l in range(8)]
    hs, masks = [x], []
    for l in range(7):
        a = hs[-1] @ Ws[l]
        hs.append(np.maximum(a, 0.0))
        masks.append(a > 0)
    g = (hs[-1] @ Ws[7] - T) / (B * d)
    grads = [None] * 8
    for l in range(7, -1, -1):
        grads[l] = hs[l].T @ g
        if l:
            g = (g @ Ws[l].T) * masks[l - 1]
    return [int(v) for v in np.rint(np.concatenate([w.ravel() for w in grads]) * 2 ** 40)]
