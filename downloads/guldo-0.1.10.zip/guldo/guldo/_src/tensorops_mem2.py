"""Bytes, precision and peak memory for counted solvers, VERSION 2: tensorops_mem.py plus an int8 format. A run-time layer over tensorops.py, used by tflops_mem2_runner.py in the counting child ONLY.

tensorops_mem.py (version 1) is not touched: every existing ladder pins its hash, and its counts must stay what they were. This file is a separate counting program, so a ladder made with it says
`tflops-mem2` and cannot be mixed with a version-1 ladder. Everything below is as in version 1 (read tensorops_mem.py's docstring: widths, bytes moved with no cache and no fusion, peak memory,
the per-operation profile) except what this paragraph and the next say.

int8. `cast(x, "int8")` quantises SYMMETRICALLY with an absolute-maximum scale: scale = max|x| / 127 (an all-zero tensor gets scale 1), q = round(x / scale) clipped to [-127, 127], and the tensor then
holds q * scale, so the judge sees the real quantisation error. Scales are rounded to fp32 because that is what is stored and charged. `cast(x, "int8", axis)` keeps one scale per index of that axis
(per-channel scaling: the usual choice for weights; the scale is the absolute maximum over all the other axes), and is refused unless every scale covers at least 16 values (so a scale per value, which
would be lossless at 5 bytes, is not a quantisation). A tensor is 1 byte per value plus 4 bytes (an fp32) for every scale it carries, and both are counted in bytes moved and in peak memory. Quantising costs 3 operations per
element (the absolute maximum, the division, the rounding); casting an int8 tensor back to fp16/fp32/fp64 costs 1 per element, as any cast does.

What an operation on int8 tensors gives. If the WIDEST operand of an arithmetic operation (+ - * / @ einsum exp sqrt relu sum max mean concat-free) is int8, the result is 32 bits wide and rounded to fp32:
int8 is a storage and matrix-input format, and accumulations are wider, as in integer matrix units (an int32 accumulator; the fp32 rounding here is exact for sums below 2^24 and a rounding error of 6e-8
above that, which is smaller than any quantisation error). Mixed with a wider operand the result takes the wider width, as in version 1. Moving data without computing (slicing, reshape, transpose, take,
concat) keeps int8 when every operand is int8, with the scales it came with. int8 tensors are READ-ONLY: assigning into one raises TypeError (cast again instead), because a value written into a
quantised tensor has no meaning without re-deriving its scale.

What this is not: a model of an integer kernel (no saturation behaviour, no zero-points, no asymmetric or sub-8-bit formats, no calibration choice beyond the absolute maximum (per-GROUP scaling is expressible: reshape so each row holds a group of at least 16 values and cast with axis 0; its scales are charged like any others), no fused
dequantisation), a time, or a cache model. It certifies "fewer bytes / a smaller footprint under these rules", not "faster": whether a real device has a fast int8 path is not in it.
"""
import numpy as np

BITS = {"fp64": 64, "fp32": 32, "fp16": 16, "int8": 8}
SCALE_BYTES = 4          # one fp32 per scale
MIN_VALUES_PER_SCALE = 16    # a scale must cover at least this many values: with one scale per value (or per few) "int8" would be a lossless 5-byte format that no integer format is
QUANT_OPS_PER_ELEMENT = 3
_BYTES = [0]
_LIVE = [0]
_PEAK = [0]
_PROFILE = {}      # (flops, bytes) of ONE operation -> how many operations had exactly that cost


def reset():
    _BYTES[0] = _LIVE[0] = _PEAK[0] = 0
    _PROFILE.clear()


def profile():
    """The run's operations grouped by their exact (flops, bytes): [[flops, bytes, count], ...], sorted. Their sums are the run's flops and bytes."""
    return [[f, b, n] for (f, b), n in sorted(_PROFILE.items())]


def _note(flops, nbytes):
    if flops or nbytes:
        _PROFILE[(flops, nbytes)] = _PROFILE.get((flops, nbytes), 0) + 1


def counters():
    """(bytes moved, peak live bytes) so far in this process."""
    return _BYTES[0], _PEAK[0]


def _round(a, bits):
    with np.errstate(over="ignore", invalid="ignore"):
        if bits == 32:
            return a.astype(np.float32).astype(np.float64)
        if bits == 16:
            return a.astype(np.float16).astype(np.float64)
    return a                     # 64: exact; 8: already on its quantisation grid (cast puts it there)


FP32_TINY = float(np.finfo(np.float32).tiny)      # the smallest normal fp32: a scale below it would flush to zero
FP32_MAX = float(np.finfo(np.float32).max)


def _fp32(x):
    """A scale is STORED as an fp32 and charged as 4 bytes, so it is rounded to one: otherwise a float64 scale would carry information the byte count never paid for. It is also held inside fp32's
    normal range: a scale that underflowed to 0 or overflowed to infinity would make the quantised values NaN (0 * inf), where a real fp32 scale just saturates or flushes the data."""
    with np.errstate(over="ignore", under="ignore"):
        return np.clip(np.asarray(x, dtype=np.float64).astype(np.float32).astype(np.float64), FP32_TINY, FP32_MAX)


def quantise(a, axis=None):
    """-> (values on the int8 grid, number of scales). Symmetric absolute-maximum scaling with fp32 scales; per-slice along `axis` when given."""
    a = np.asarray(a, dtype=np.float64)
    if axis is None or a.ndim == 0:
        m = np.max(np.abs(a)) if a.size else 0.0
        s = float(_fp32(m / 127.0)) if m > 0 and np.isfinite(m) else 1.0
        return np.clip(np.rint(a / s), -127, 127) * s, 1
    ax = axis % a.ndim
    others = tuple(i for i in range(a.ndim) if i != ax)
    m = np.max(np.abs(a), axis=others, keepdims=True) if others else np.abs(a)
    s = np.where((m > 0) & np.isfinite(m), _fp32(m / 127.0), 1.0)
    return np.clip(np.rint(a / s), -127, 127) * s, int(a.shape[ax])


def install(tp):
    """Wrap the tensorops module `tp` in this process. Must be called once, before any solver code runs."""
    Base = tp.Tensor

    class MemTensor(Base):
        __slots__ = ("_b", "_x")

        def __del__(self):
            try:
                _LIVE[0] -= self._a.size * self._b // 8 + self._x
            except (AttributeError, TypeError):      # never registered, or the interpreter is shutting down
                pass
            Base.__del__(self)

    def bits_of(t):
        return getattr(t, "_b", 64)

    def extra_of(t):
        return getattr(t, "_x", 0)

    def nbytes(t):
        return t._a.size * bits_of(t) // 8 + extra_of(t)

    def tensors_in(args):
        out = []
        for a in args:
            if isinstance(a, Base):
                out.append(a)
            elif isinstance(a, (list, tuple)):
                out += [x for x in a if isinstance(x, Base)]
        return out

    def register(t, bits, extra=0):
        if bits in (32, 16):
            t._a = _round(t._a, bits)
        t._b = bits
        t._x = extra
        _LIVE[0] += t._a.size * bits // 8 + extra
        if _LIVE[0] > _PEAK[0]:
            _PEAK[0] = _LIVE[0]
        return t

    def widest(ts):
        return max([bits_of(t) for t in ts] or [64])

    def wrap(fn, mode, keeps_format=False):
        def wrapper(*args, **kw):
            ts = tensors_in(args)
            f0, b0 = tp._FLOPS[0], _BYTES[0]
            r = fn(*args, **kw)
            w = widest(ts)
            read = sum(nbytes(t) for t in ts) if mode in ("rw", "read") else 0
            if isinstance(r, Base):
                if keeps_format and ts and w == 8 and all(bits_of(t) == 8 for t in ts):
                    register(r, 8, min(sum(extra_of(t) for t in ts), SCALE_BYTES * r._a.size))      # data movement: still int8, with the scales it came with
                else:
                    register(r, 32 if w == 8 else w)                                                # arithmetic on int8 accumulates wider
                if mode in ("rw", "w"):
                    _BYTES[0] += read + nbytes(r)
                elif mode == "gather":
                    _BYTES[0] += 2 * nbytes(r)
                else:
                    _BYTES[0] += read
            else:
                _BYTES[0] += read
            _note(tp._FLOPS[0] - f0, _BYTES[0] - b0)
            return r
        wrapper.__name__ = getattr(fn, "__name__", "op")
        return wrapper

    def method(fn, mode, keeps_format=False):
        def wrapper(self, *args):
            return wrap(fn, mode, keeps_format)(self, *args)
        wrapper.__name__ = getattr(fn, "__name__", "op")
        return wrapper

    for name in ("__add__", "__radd__", "__sub__", "__rsub__", "__mul__", "__rmul__", "__truediv__", "__rtruediv__", "__neg__", "__matmul__"):
        setattr(MemTensor, name, method(getattr(Base, name), "rw"))
    setattr(MemTensor, "__getitem__", method(Base.__getitem__, "view", True))
    setattr(MemTensor, "tolist", method(Base.tolist, "read"))

    base_setitem = Base.__setitem__

    def setitem(self, k, v):
        if bits_of(self) == 8:
            raise TypeError("an int8 tensor is read-only: cast the new values again instead of assigning into it")
        key = tp._key(k)
        b0 = _BYTES[0]
        region = self._a[key].size * bits_of(self) // 8
        base_setitem(self, k, v)
        if bits_of(self) < 64:
            self._a[key] = _round(self._a[key], bits_of(self))
        _BYTES[0] += region + (nbytes(v) if isinstance(v, Base) else 0)
        _note(0, _BYTES[0] - b0)
    setattr(MemTensor, "__setitem__", setitem)

    tp.Tensor = MemTensor            # the module's own functions build `Tensor(...)` by global name: from now on they build MemTensors
    for name, mode, keeps in (("stream", "w", False), ("tensor", "w", False), ("zeros", "w", False), ("causal_mask", "w", False), ("take", "gather", True), ("concat", "rw", True),
                              ("reshape", "view", True), ("transpose", "view", True), ("einsum", "rw", False), ("exp", "rw", False), ("sqrt", "rw", False), ("relu", "rw", False),
                              ("sum", "rw", False), ("max", "rw", False), ("mean", "rw", False), ("argmax", "read", False)):
        setattr(tp, name, wrap(getattr(tp, name), mode, keeps))

    def cast(x, fmt, axis=None):
        if not isinstance(x, Base):
            raise TypeError("cast: a Tensor")
        if not isinstance(fmt, str) or fmt not in BITS:
            raise ValueError("cast: 'fp64', 'fp32', 'fp16' or 'int8'")
        if axis is not None and (fmt != "int8" or isinstance(axis, bool) or not isinstance(axis, int) or not -x._a.ndim <= axis < max(x._a.ndim, 1)):
            raise ValueError("cast: `axis` is an int naming one axis of the tensor, and only with 'int8' (one scale per index of that axis)")
        f0, b0 = tp._FLOPS[0], _BYTES[0]
        if fmt == "int8":
            if axis is not None and x._a.ndim > 0 and x._a.size < MIN_VALUES_PER_SCALE * x._a.shape[axis]:
                raise ValueError("cast: per-axis int8 needs at least %d values per scale (this tensor has %d values and would carry %d scales): a scale per value is not a quantisation"
                                 % (MIN_VALUES_PER_SCALE, x._a.size, x._a.shape[axis]))
            tp._charge(QUANT_OPS_PER_ELEMENT * x._a.size)
            vals, nscales = quantise(x._a, axis)
            r = MemTensor(vals)
            register(r, 8, SCALE_BYTES * nscales)
        else:
            tp._charge(x._a.size)
            r = MemTensor(x._a.copy())
            register(r, BITS[fmt])
        _BYTES[0] += nbytes(x) + nbytes(r)
        _note(tp._FLOPS[0] - f0, _BYTES[0] - b0)
        return r
    tp.cast = cast
    return MemTensor
