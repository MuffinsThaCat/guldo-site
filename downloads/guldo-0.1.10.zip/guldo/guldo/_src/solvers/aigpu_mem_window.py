"""aigpu with bytes counted, CHEAT: local attention. Each position attends only to the 32-position block it sits in instead of to all n positions: the score matrix shrinks from n x n to n x 32 and
everything gets far cheaper, and it is not the same function: the judge must reject it."""
import math

import tensorops as tp

CLASSES = 16


def inputs(seed, n, H, dk):
    m = H * n * dk
    d = H * dk
    Q = tp.reshape(tp.stream(seed, 0, m), (H, n, dk)) * 3.0
    K = tp.reshape(tp.stream(seed, m, m), (H, n, dk))
    V = tp.reshape(tp.stream(seed, 2 * m, m), (H, n, dk))
    Wout = tp.reshape(tp.stream(seed, 3 * m, d * CLASSES), (d, CLASSES)) * math.sqrt(3.0 / d)
    return Q, K, V, Wout


def labels(O, Wout, n, H, dk):
    rows = (tp.reshape(tp.transpose(O, (1, 0, 2)), (n, H * dk)) @ Wout).tolist()
    return [row.index(max(row)) for row in rows]

BLOCK = 32


def solve(seed, n, H, dk):
    Q, K, V, Wout = inputs(seed, n, H, dk)
    g = H * (n // BLOCK)
    Qb = tp.reshape(Q, (g, BLOCK, dk))
    Kb = tp.reshape(K, (g, BLOCK, dk))
    Vb = tp.reshape(V, (g, BLOCK, dk))
    S = (Qb @ tp.transpose(Kb, (0, 2, 1))) * (1.0 / math.sqrt(dk))
    E = tp.exp(S - tp.max(S, 2, True))
    P = E / tp.sum(E, 2, True)
    return labels(tp.reshape(P @ Vb, (H, n, dk)), Wout, n, H, dk)
