"""aickpt in the counted API, TECHNIQUE: ACTIVATION CHECKPOINTING. The forward pass keeps only every S-th activation (S = round(sqrt(L/2)), about sqrt(2L) checkpoints), discarding the rest. The backward pass
then goes segment by segment from the last: it recomputes that segment's activations and masks from its checkpoint (one extra forward pass in all), backpropagates through them, and frees them before the
next segment. Peak memory about L/S + 2S activations instead of 2L, for about a third more operations. The gradient is the same."""
import math

import tensorops as tp


def parts(seed, w, B):
    X = tp.reshape(tp.stream(seed, 0, B * w), (B, w))
    W = tp.reshape(tp.stream(seed, B * w, w * w), (w, w)) * math.sqrt(3.0 / w)
    T = tp.reshape(tp.stream(seed, B * w + w * w, B * w), (B, w))
    return X, W, T


def step(h, W, alpha):
    """One forward step; returns the next activation and the ReLU mask (1 where the pre-activation was positive)."""
    a = h @ W
    ra = tp.relu(a)
    return h + ra * alpha, ra / (tp.sqrt(a * a) + 1e-300)


def fwd(h, W, alpha):
    """One forward step without the mask (a pass that will not be backpropagated)."""
    return h + tp.relu(h @ W) * alpha


def ints(dW, w):
    return [int(v * 1099511627776.0) for v in tp.reshape(dW, (w * w,)).tolist()]


def solve(seed, L, w, B):
    X, W, T = parts(seed, w, B)
    alpha = 0.5 / L
    Wt = tp.transpose(W, (1, 0))
    S = int(math.sqrt(L / 2.0) + 0.5)
    ck = []
    h = X
    X = 0
    for t in range(L):
        if t % S == 0:
            ck.append(h)
        h = fwd(h, W, alpha)
    delta = (h - T) * (1.0 / (B * w))
    h = 0
    dW = tp.zeros((w, w))
    for c in range(len(ck) - 1, -1, -1):
        start = c * S
        end = min(start + S, L)
        hs = [ck[c]]
        ms = []
        g = ck[c]
        ck[c] = 0
        for t in range(start, end):
            g, m = step(g, W, alpha)
            hs.append(g)
            ms.append(m)
        g = 0
        for j in range(end - start - 1, -1, -1):
            gm = delta * ms[j]
            dW = dW + (tp.transpose(hs[j], (1, 0)) @ gm) * alpha
            delta = delta + (gm @ Wt) * alpha
        hs = 0
        ms = 0
    return ints(dW, w)
