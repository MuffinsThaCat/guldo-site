"""Run `solve(*args)` of one solver file under EXACT counting of operations and of a simulated cluster WITH A TOPOLOGY (critical-path work, message rounds and bytes per device on the intra-node and inter-node
links). Child process of tflops_dist3.py; not meant to be run by hand. Needs Python 3.12+.

Identical to tflops_dist_runner.py except that tensorops_dist3.py is installed over tensorops.py instead of tensorops_dist.py.

  argv[1]   the solver file (a top-level `solve`), written in the restricted subset PLUS `import tensorops`
  stdin     {"args": [...], "limit": N, "ranks": P, "node": Q, "cap_bytes": B or null}      N = the most operations the solver may spend; P = the devices the instance has, Q of them per node
  stdout    the LAST line is {"status": "ok" | "limit" | "error", "steps", "flops", "wcrit", "ri", "ci", "rx", "cx", "peak", "ans": ..., "err": "..."}
"""
import gc
import json
import os
import resource
import sys

import count_runner as cr
import tensorops
import tensorops_dist3 as tensorops_dist

TOOL_ID = 4

cr.ALLOWED_MODULES = {"math": None, "itertools": None, "tensorops": tuple(tensorops.EXPORTS) + ("use", "all_reduce", "reduce_scatter", "all_gather", "broadcast", "exchange", "all_to_all")}   # this process only


class _StepLimit(BaseException):
    pass


def _emit(obj):
    sys.__stdout__.write("\n" + json.dumps(obj) + "\n")
    sys.__stdout__.flush()


def main():
    base = {"steps": 0, "flops": 0, "wcrit": 0, "ri": 0, "ci": 0, "rx": 0, "cx": 0, "peak": 0}
    if len(sys.argv) != 2:
        _emit({"status": "error", **base, "err": "usage: tflops_dist_runner.py SOLVER"})
        return
    try:
        payload = json.loads(sys.stdin.read())
        args, limit, ranks = payload["args"], int(payload["limit"]), int(payload["ranks"])
        cap_bytes = None if payload.get("cap_bytes") is None else int(payload["cap_bytes"])
        node = int(payload["node"])
    except (ValueError, KeyError, TypeError) as e:
        _emit({"status": "error", **base, "err": f"bad payload: {type(e).__name__}"})
        return
    if sys.version_info < (3, 12):
        _emit({"status": "error", **base, "err": "counting needs Python 3.12 or newer (sys.monitoring)"})
        return
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path[:] = [p for p in sys.path if p and os.path.abspath(p) != here]   # everything needed is imported already; a solver must not reach the judge's modules
    mon = sys.monitoring
    try:
        delattr(sys, "monitoring")
    except (AttributeError, TypeError):
        pass
    sys.modules.pop("sys.monitoring", None)
    if sys.platform.startswith("linux"):
        try:
            resource.setrlimit(resource.RLIMIT_AS, (4 << 30, 4 << 30))
        except (ValueError, OSError):
            pass
    tensorops_dist.install(tensorops, ranks, cap_bytes, node)
    solver_name = sys.argv[1]
    try:
        code, namespace = cr._prepare(solver_name)
    except BaseException as e:
        _emit({"status": "error", **base, "err": f"could not load the solver: {type(e).__name__}: {str(e)[:200]}"})
        return
    count = [0]
    tripped = [False]
    tensorops._FLOPS[0] = 0
    tensorops._LIMIT[0] = limit
    tensorops_dist.reset(ranks, cap_bytes, node)

    def on_instruction(c, offset):
        if c.co_filename != solver_name:
            return mon.DISABLE            # library code: never counted, and not asked about again at this location
        if tripped[0]:
            return None
        n = count[0] + 1
        count[0] = n
        if n + tensorops._FLOPS[0] > limit:
            tripped[0] = True
            raise _StepLimit()
        return None

    status, ans, err = "ok", None, ""
    real_stdout = sys.stdout
    sys.stdout = sys.stderr
    gc.collect()
    gc.disable()
    mon.use_tool_id(TOOL_ID, "svp-tflops")
    mon.register_callback(TOOL_ID, mon.events.INSTRUCTION, on_instruction)
    try:
        mon.set_events(TOOL_ID, mon.events.INSTRUCTION)
        exec(code, namespace)
        ans = namespace["solve"](*args)
    except (_StepLimit, tensorops.BudgetExceeded):
        status = "limit"
    except BaseException as e:
        status, err = "error", f"{type(e).__name__}: {str(e)[:200]}"
    finally:
        try:
            intact = mon.get_events(TOOL_ID) == mon.events.INSTRUCTION
        except ValueError:
            intact = False
        try:
            mon.set_events(TOOL_ID, mon.events.NO_EVENTS)
            mon.register_callback(TOOL_ID, mon.events.INSTRUCTION, None)
            mon.free_tool_id(TOOL_ID)
        except ValueError:
            intact = False
        gc.enable()
        sys.stdout = real_stdout
    steps, flops = count[0], tensorops._FLOPS[0]
    wcrit, ri, ci, rx, cx = tensorops_dist.counters()
    peak = tensorops_dist.peak_bytes()
    if tripped[0] or flops > limit:
        status, ans, err = "limit", None, ""
    elif status == "ok" and not intact:
        status, ans, err = "error", None, "the solver reconfigured the counter: its count means nothing"
    if status == "ok":
        try:
            json.dumps(ans)
        except (TypeError, ValueError):
            status, err, ans = "error", "the answer is not JSON-serialisable (an int, a list of ints or None is expected)", None
    _emit({"status": status, "steps": steps, "flops": flops, "wcrit": wcrit, "ri": ri, "ci": ci, "rx": rx, "cx": cx, "peak": peak, "ans": ans if status == "ok" else None, "err": err})


if __name__ == "__main__":
    main()
