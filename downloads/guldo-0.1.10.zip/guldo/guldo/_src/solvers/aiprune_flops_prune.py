"""aiprune in the counted-operations API, TECHNIQUE: structured pruning. Measure each hidden unit's importance from its weights (the norm of its incoming row times the norm of its outgoing column), drop every
unit whose importance is below 2% of the largest, and run the two batched products on what is left (the pruned rows and columns are gathered with `take`, which is data movement). The threshold is a
rule written down in advance, not tuned on the instance: on calibration instances it leaves about 28% of the units and keeps the labels within the judge's tolerance."""
import math

import tensorops as tp

C = 10
ZETA = 3.0
KEEP = 0.02           # keep a unit if its importance is at least this fraction of the largest


def solve(seed, d, Q):
    H = 4 * d
    W1 = tp.reshape(tp.stream(seed, 0, H * d), (H, d)) * math.sqrt(3.0 / d)
    gain = tp.exp((tp.stream(seed, H * d, H) + 1.0) * (-ZETA * math.log(10.0)))
    W2t = tp.transpose(tp.reshape(tp.stream(seed, H * d + H, C * H), (C, H)) * math.sqrt(3.0 / H) * tp.reshape(gain, (1, H)), (1, 0))      # H x C
    X = tp.reshape(tp.stream(seed, H * d + H + C * H, Q * d), (Q, d))
    imp = (tp.sum(W1 * W1, 1) * tp.sum(W2t * W2t, 1)).tolist()      # importance squared, per unit
    cut = KEEP * KEEP * max(imp)
    keep = [i for i in range(H) if imp[i] >= cut]
    rows = (tp.relu(X @ tp.transpose(tp.take(W1, keep), (1, 0))) @ tp.take(W2t, keep)).tolist()
    return [row.index(max(row)) for row in rows]
