"""Smoke test for a RUNNING submission service: is what is actually listening what DEPLOY.md says it is?

  python3 deploy_smoke.py https://ledger.example.org [--submit FILE --round ID --handle NAME]

Read-only by default (a few GETs and two requests that must be REFUSED). It checks, against the live address:
  * /healthz answers, over TLS if the address is https (a bad certificate fails here, not silently);
  * the security headers the page code promises are really on the wire (a proxy that strips them is a finding);
  * a request with a foreign Host header and a cross-site Origin are refused (DNS-rebinding and CSRF controls);
  * a submission without the rules accepted is refused with a JSON error and stores nothing;
  * every round's public log verifies (hash chain, commitments in entry 0) with YOUR copy of the checker, and matches the round's description;
  * the JSON API does not leak a seed before the reveal.
With --submit it also makes ONE real submission through svp.py (a real, logged, permanent entry: use a test round).
Cost to know: the refusal probe is a POST, and the portal rate-limits POSTs before it reads the form, so each OPEN round spends one of your
address's submission tokens (burst 3, 6 per hour). Run it from somewhere that is not also the address you submit from, or wait an hour.
Exit status: 0 all passed, 1 something failed, 2 could not reach the service.
"""
import argparse
import http.client
import json
import sys
import urllib.parse

import certificate
import rounds
import svp

REQUIRED_HEADERS = {"x-content-type-options": "nosniff", "x-frame-options": "DENY", "referrer-policy": "no-referrer"}


def _conn(server):
    u = urllib.parse.urlsplit(server)
    cls = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
    return cls(u.hostname, u.port or (443 if u.scheme == "https" else 80), timeout=20)


def _raw(server, method, path, headers=None, body=None):
    c = _conn(server)
    try:
        c.request(method, path, body=body, headers=headers or {})
        r = c.getresponse()
        return r.status, {k.lower(): v for k, v in r.getheaders()}, r.read(svp.MAX_JSON + 1)
    finally:
        c.close()


def smoke(server, submit=None):
    """-> [(status, check, detail)] with status in pass / fail / warn. A connection that drops or a server that answers nonsense half-way through
    is a FINDING in the report, never a traceback."""
    out = []
    try:
        _smoke(server, submit, out)
    except (OSError, http.client.HTTPException, ValueError) as e:
        out.append(("fail", "connection", f"the service stopped answering properly mid-test ({type(e).__name__}: {svp.clean(e, 100)})"))
    except (AttributeError, TypeError, KeyError, IndexError) as e:   # JSON of an unexpected shape (a log whose entries are not objects, ...)
        out.append(("fail", "response shape", f"the service sent data in an unexpected shape ({type(e).__name__}: {svp.clean(e, 100)})"))
    return out


def _smoke(server, submit, out):
    add = lambda st, name, detail="": out.append((st, name, detail))
    u = urllib.parse.urlsplit(server)
    try:
        st, hdr, body = _raw(server, "GET", "/healthz")
    except (OSError, http.client.HTTPException) as e:
        out.append(("fail", "reachable", f"cannot reach {server}: {type(e).__name__}: {svp.clean(e, 100)}"))
        return
    add("pass" if st == 200 and body.strip() == b"ok" else "fail", "healthz", f"HTTP {st}")
    add("pass" if u.scheme == "https" else "warn", "transport",
        "https (the certificate verified, or the connection would have failed)" if u.scheme == "https" else
        "plain http: fine on loopback, but a public service must be https (tokens and sources travel in the clear otherwise)")
    st, hdr, body = _raw(server, "GET", "/")
    missing = [k for k, v in REQUIRED_HEADERS.items() if hdr.get(k) != v]
    add("pass" if st == 200 and not missing else "fail", "security headers", "present" if not missing else "missing or wrong: " + ", ".join(missing))
    csp = hdr.get("content-security-policy", "")
    add("pass" if "default-src 'none'" in csp and "frame-ancestors 'none'" in csp else "fail", "content security policy", svp.clean(csp, 80) or "absent")
    if u.scheme == "https":
        add("pass" if "max-age" in hdr.get("strict-transport-security", "") else "warn", "HSTS", hdr.get("strict-transport-security", "absent (the proxy may add it)"))
    st, _, _ = _raw(server, "GET", "/", headers={"Host": "evil.invalid"})
    add("pass" if st == 403 else "fail", "foreign Host refused", f"HTTP {st} (want 403)")
    st, _, _ = _raw(server, "POST", "/round/nonexistent/submit", headers={"Origin": "https://evil.invalid", "Content-Type": "multipart/form-data; boundary=x",
                                                                          "Content-Length": "0"})
    add("pass" if st == 403 else "fail", "cross-site POST refused", f"HTTP {st} (want 403)")
    try:
        data = svp.get_json(server, "/api/rounds.json")
    except svp.SvpError as e:
        add("fail", "rounds api", str(e))
        return
    if not isinstance(data, list) or not all(isinstance(r, dict) for r in data):
        add("fail", "rounds api", "the rounds list is malformed")
        return
    add("pass", "rounds api", f"{len(data)} round(s)")        # only after the shape is known good: one finding per check, never a PASS and a FAIL
    for r in data:
        rid = r.get("id", "?")
        try:
            rj = svp._round(server, rid)
            status, logbody = svp.request(server, f"/api/log/{rid}.jsonl")
            entries = svp.parse_log(logbody) if status == 200 else []
            ok, why = certificate.commit_published(entries, rj.get("commitments", []))
            same = entries and entries[0].get("data", {}).get("commitments") == rj.get("commitments")
            add("pass" if ok and same and rj.get("log_ok") else "fail", f"round {rid}: log", why if ok else f"does not verify: {why}")
            leaked = rj.get("state") not in ("revealed",) and bool(rj.get("seeds"))
            add("fail" if leaked else "pass", f"round {rid}: no seed before the reveal", f"state {rj.get('state')}")
            if rj.get("state") == "open":
                body, ctype = svp.multipart({"handle": "smoketest"}, "x.py", b"def solve(*a):\n    return None\n")   # no `agree` field on purpose
                st, _, resp = _raw(server, "POST", f"/round/{rid}/submit", headers={"Content-Type": ctype, "Accept": "application/json"}, body=body)
                try:
                    parsed = json.loads(resp)
                    msg = parsed.get("error", "") if isinstance(parsed, dict) else ""   # a service answering with a list is a failed check, not a crash
                except ValueError:
                    msg = ""
                add("pass" if st == 422 and "rules" in msg else "fail", f"round {rid}: refuses without the rules accepted", f"HTTP {st}: {svp.clean(msg, 80)}")
        except svp.SvpError as e:
            add("fail", f"round {rid}", str(e))
    if submit:
        import argparse as _ap
        file, rid, handle, home = submit
        a = _ap.Namespace(server=server, file=file, round=rid, handle=handle, accept_rules=True, publish_source=False, token=None, no_check=False,
                          allow_insecure_http=False, home=home, json=False)
        try:
            rc = svp.cmd_submit(a)
        except svp.SvpError as e:
            add("fail", "real submission", str(e))
        else:
            add("pass" if rc == 0 else "fail", "real submission", "accepted and confirmed in the public log" if rc == 0 else f"svp exit {rc}")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("server")
    ap.add_argument("--submit", metavar="FILE", help="make ONE real submission with svp.py (permanent: use a test round)")
    ap.add_argument("--round")
    ap.add_argument("--handle")
    ap.add_argument("--home", help="where svp keeps the receipt")
    a = ap.parse_args(argv)
    if a.submit and not (a.round and a.handle):
        raise SystemExit("--submit needs --round and --handle")
    res = smoke(svp.normalize_server(a.server), (a.submit, a.round, a.handle, a.home) if a.submit else None)
    for st, name, detail in res:
        print(f"  {st.upper():4s} {name}: {detail}")
    if res and res[0][1] == "reachable":
        return 2
    bad = [r for r in res if r[0] == "fail"]
    print("\nALL CHECKS PASSED" if not bad else f"\n{len(bad)} CHECK(S) FAILED: do not open a round until these are fixed")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
