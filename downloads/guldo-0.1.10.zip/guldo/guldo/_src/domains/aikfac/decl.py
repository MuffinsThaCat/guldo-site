"""Declaration of a Kronecker-factored second-order domain (K-FAC): fit an 8-class softmax regression with CORRELATED features to within 1e-8 of its exact minimum, using as few operations as you can.

size = n, the number of features. The weights are a matrix W (n x 8). The training set holds N = 16 n points; feature j is an exponentially smoothed sum of the first j+1 independent uniform columns of the SplitMix64
stream (X[i][j] = sqrt(1 - 0.9^2) * sum_{k <= j} 0.9^(j-k) * Z[i][k], as in `aisecond` and `aimixed`), so the features are strongly correlated. The labels are noisy (class k with the probability of a hidden teacher's softmax),
so the loss has a finite minimiser:  L(W) = (1/N) sum_i [ logsumexp(x_i W) - (x_i W)_{y_i} ] + (LAMBDA / 2) |W|_F^2,  LAMBDA = 1e-3. It is fully determined by the instance's arguments: nothing is hidden. The judge computes the
exact minimiser (damped Newton in float64 on all 8 n variables) and accepts an answer W iff L(W) - L* <= EPS = 1e-8. The answer is the n*8 weights, row-major (feature a, class k at index 8 a + k), as INTEGERS in units of 2^-20.

Why this is the K-FAC regime. The Hessian of this loss is (1/N) sum_i (diag(p_i) - p_i p_i^T) (x) (x_i x_i^T) + LAMBDA I over the (n x 8) variables: a sum of Kronecker products of a CLASS factor (8 x 8) and a FEATURE factor
(n x n). Full Newton builds and inverts an 8n x 8n matrix (cost about N (8n)^2 + (8n)^3). K-FAC replaces the sum of Kronecker products by ONE product of the average factors, A = X^T X / N (features) and G = mean_i (diag(p_i) - p_i p_i^T)
(classes), whose inverse is cheap: (A (x) G)^{-1} = A^{-1} (x) G^{-1} costs n^3 + 8^3. It is not the exact Hessian, so it is used as a PRECONDITIONER for conjugate gradient on the exact Hessian (whose products cost two passes over X):
Newton-CG preconditioned by K-FAC. The curvature the correlated features create is what it removes. (Shampoo is the same family, with the factors built from gradient statistics; it needs matrix roots, which this API
has no operation for, so it is not written here.)

The cost is counted operations (tflops.py): the arithmetic asked for, exactly reproducible, not a time. It cannot see memory traffic, kernel quality or device speed.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aikfac"
VERSION = "aikfac-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 32)
SIZE_STEP = 8
REFERENCE_SOLVER = "reference.py"
K = 8                         # classes
RHO = 0.9
LAMBDA = 1e-3
N_PER_N = 16
EPS = 1e-8
SCALE = 2 ** 20
LIMIT = 2 ** 62
DOC = ("solve(seed, n, N, labels): the N = 16 n features are X[i][j] = sqrt(1-0.9^2) * sum_{k<=j} 0.9^(j-k) * Z[i][k] where Z[i][k] is the (i*n+k)-th float of the SplitMix64 stream under `seed` "
       "(tensorops.stream(seed, 0, N*n)); labels is the list of N classes (ints 0-7). Return the n x 8 weights W of the L2-regularised softmax regression L(W) = mean_i [logsumexp(x_i W) - (x_i W)[y_i]] + 0.5e-3 |W|_F^2 "
       "as a flat list of 8n integers in units of 2^-20 (row-major: feature a, class k at index 8a+k), whose loss is within 1e-8 of the exact minimum. Return None for no answer.")
REFERENCE_NOTE = ("Plain full-batch gradient descent with the safe step 1/L, L = |X|_F^2 / (2N) + lambda (an upper bound on the largest curvature), for a fixed number of steps (the slowest of 36 calibration instances, 12 at each size 16, 24, 32, "
                  "needed 15500; the reference takes 20000). Known to be beaten by Newton (which forms and inverts the 8n x 8n Hessian) and, more cheaply still, by Newton-CG preconditioned with the Kronecker-factored curvature (K-FAC).")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _features(seed, n, N):
    k = np.arange(n)
    U = np.triu(RHO ** np.clip(k[None, :] - k[:, None], 0, None))
    return (_uniform(seed, 0, N * n).reshape(N, n) @ U) * math.sqrt(1.0 - RHO * RHO)


def _probs(X, W):
    S = X @ W
    P = np.exp(S - S.max(axis=1, keepdims=True))
    return P / P.sum(axis=1, keepdims=True)


def loss(X, y, W):
    S = X @ W
    m = S.max(axis=1, keepdims=True)
    return float(np.mean(m[:, 0] + np.log(np.exp(S - m).sum(axis=1)) - S[np.arange(len(y)), y]) + 0.5 * LAMBDA * np.sum(W * W))


def minimiser(X, y):
    """The exact minimiser: damped Newton in float64 on all n*8 variables. -> (W, L*)."""
    N, n = X.shape
    W = np.zeros((n, K))
    cur = loss(X, y, W)
    for _ in range(100):
        P = _probs(X, W)
        Q = P.copy()
        Q[np.arange(N), y] -= 1.0
        g = (X.T @ Q / N + LAMBDA * W).ravel()
        F = P[:, :, None] * np.eye(K)[None] - P[:, :, None] * P[:, None, :]            # N x K x K
        H = np.einsum("ia,ib,ikl->akbl", X, X, F).reshape(n * K, n * K) / N + LAMBDA * np.eye(n * K)
        step = np.linalg.solve(H, g).reshape(n, K)
        t = 1.0
        while t > 1e-12:
            nxt = loss(X, y, W - t * step)
            if nxt <= cur:
                break
            t *= 0.5
        W, done = W - t * step, cur - nxt < 1e-16
        cur = min(cur, nxt)
        if done and np.linalg.norm(g) < 1e-9:
            break
    return W, loss(X, y, W)


def _seed(master, tag, size, idx):
    return int.from_bytes(hmac.new(master, f"aikfac-v1:{tag}:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    n = size
    N = N_PER_N * n
    seed, wseed, lseed = (_seed(master, t, size, idx) for t in ("train", "teacher", "noise"))
    X = _features(seed, n, N)
    Wt = _uniform(wseed, 0, n * K).reshape(n, K) * 3.0 / math.sqrt(n)
    u = (_uniform(lseed, 0, N) + 1.0) / 2.0
    y = np.minimum((_probs(X, Wt).cumsum(axis=1) < u[:, None]).sum(axis=1), K - 1)
    W, _ = minimiser(X, y)
    return {"args": [seed, n, N, [int(v) for v in y]], "planted": [int(v) for v in np.rint(W.ravel() * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, n, N, labels = inst["args"]
    if not isinstance(ans, list) or len(ans) != n * K:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    X, y = _features(seed, n, N), np.asarray(labels)
    _, best = minimiser(X, y)
    return bool(loss(X, y, np.array(ans, dtype=np.float64).reshape(n, K) / SCALE) - best <= EPS)
