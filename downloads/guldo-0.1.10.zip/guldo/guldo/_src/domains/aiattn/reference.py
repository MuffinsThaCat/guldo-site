"""Reference for aiattn: dense float64 attention with a window mask.

The model definition (the contract a submission must reproduce): SplitMix64 counter stream under `seed`, element k = finalise((k+1)*GOLD + seed), mapped to [-1, 1) as
(z >> 11) * 2^-52 - 1. Stream layout: Q (n*16, times 3), K (n*16, times 3), V (n*16), each n x 16 row-major. Row i of the output is the softmax over j in (i-32, i] of
q_i . k_j / sqrt(16), applied to V's rows. The answer is the output as integers in units of 2^-16.
"""
import math

import numpy as np

_D = 16
_WINDOW = 32
_QK = 3.0


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, n):
    m = n * _D
    Q = (_uniform(seed, 0, m) * _QK).reshape(n, _D)
    K = (_uniform(seed, m, m) * _QK).reshape(n, _D)
    V = _uniform(seed, 2 * m, m).reshape(n, _D)
    S = Q @ K.T / math.sqrt(_D)
    i = np.arange(n)[:, None]
    j = np.arange(n)[None, :]
    S = np.where((j <= i) & (j > i - _WINDOW), S, -1e30)
    S -= S.max(axis=1, keepdims=True)
    A = np.exp(S)
    A /= A.sum(axis=1, keepdims=True)
    return [int(v) for v in np.rint(A @ V * 65536.0).ravel()]
