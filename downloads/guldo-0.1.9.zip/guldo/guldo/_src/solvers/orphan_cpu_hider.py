"""Red-team: burns real CPU in an orphaned child and returns None via it while the parent exits at once.
A meter that only reads the direct child's rusage bills ~0 s. Correct metering bills about 4 s."""
import os
import sys
import time


def solve(basis, bound2):
    if os.fork() == 0:
        t = time.process_time()
        while time.process_time() - t < 4.0:
            pass
        sys.stdout.write("null")
        sys.stdout.flush()
        os._exit(0)
    os._exit(0)
