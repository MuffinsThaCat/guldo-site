"""Reference for hnp: full exhaustive search over alpha, filtered by the first sample, then the other samples."""


def solve(p, K, ts, us):
    sh = p.bit_length() - K
    t0, u0 = ts[0], us[0]
    rest = list(zip(ts[1:], us[1:]))
    found = None
    # scans all of 1..p-1 (no early exit), so the cost depends on the size of p alone and the ladder is predictable
    for a in range(1, p):
        if (a * t0) % p >> sh == u0 and found is None:
            if all((a * t) % p >> sh == u for t, u in rest):
                found = a
    return found
