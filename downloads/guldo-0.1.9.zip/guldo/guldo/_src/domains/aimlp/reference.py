"""Reference for aimlp: plain full-batch gradient descent on the softmax loss of a two-layer ReLU network. Learning rate 0.5, 12000 steps, no feature scaling, no momentum, float64,
starting from small random weights (SplitMix64 streams under the instance seed).

The features are regenerated from the seed with the SplitMix64 stream documented in domains/aimlp/decl.py (the same stream as the other AI domains).
"""
import math

import numpy as np

K = 3
HIDDEN = 32
KAPPA = 10.0
STEPS = 12000
LR = 0.5


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, n, labels):
    scales = np.array([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = _uniform(seed, 0, n * d).reshape(n, d) * scales
    Y = np.eye(K)[np.asarray(labels)]
    W1 = _uniform(seed ^ 0x5151, 0, d * HIDDEN).reshape(d, HIDDEN) * math.sqrt(3.0 / d)
    W2 = _uniform(seed ^ 0x5252, 0, HIDDEN * K).reshape(HIDDEN, K) * math.sqrt(3.0 / HIDDEN)
    for _ in range(STEPS):
        Z1 = X @ W1
        A = np.maximum(Z1, 0.0)
        Z2 = A @ W2
        E = np.exp(Z2 - Z2.max(axis=1, keepdims=True))
        G = (E / E.sum(axis=1, keepdims=True) - Y) / n
        dW2 = A.T @ G
        dW1 = X.T @ ((G @ W2.T) * (Z1 > 0.0))
        W1 = W1 - LR * dW1
        W2 = W2 - LR * dW2
    return [int(v) for v in np.rint(np.concatenate([W1.ravel(), W2.ravel()]) * 2 ** 20)]
