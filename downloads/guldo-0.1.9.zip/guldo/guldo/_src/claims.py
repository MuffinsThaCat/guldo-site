"""Derived claims: other things a VERIFIED certificate can prove, from the same ladders, with no new measurement.

  claims.py correctness CERT [--out F] [--rerun K|all --execute]    "this program solved X% of committed, blind questions" (a benchmark score)
  claims.py worst-case  CERT [--out F] [--rerun K|all --execute]    the largest step count observed per size (a COUNTED certificate only)
  claims.py negative    CERT [CERT ...] --threshold BITS [--out F]  "none of the N submissions in this round reached BITS": a verified negative result
  claims.py compare     CERT_A CERT_B [--out F]                      "A is ahead of B on the same test": refuses unless both measured the SAME problem, baseline and kind of measurement
  claims.py check       CLAIM CERT [CERT ...]                      recompute a claim file from the certificates: it must be identical

Every claim starts by running certificate.verify on each certificate and refuses if it does not verify; it then RECOMPUTES the claim from the raw per-instance
records. A claim file is therefore not trusted either: `check` redoes it. The claims inherit the certificate's strength and its limits (a timed ladder rests on the
operator's sandbox, a counted one is reproducible by anyone on the same Python), and each says what it does NOT show.

What these are and are not. They are statements about the committed instances and the submissions actually made. A correctness score is a rate on THIS test
set (with a Wilson interval, which is about sampling the generator, not about other test sets); the worst-case figure is the largest value SEEN, not a proof about every
input of that size (the chance a fresh instance from the same generator exceeds the maximum of n is at most 1/(n+1), by exchangeability); a negative result is about the
submissions made (participants chose to submit) and about what could be CERTIFIED, not about every possible approach: the credit is a conservative lower bound (the minimum
over seeds, with an inconclusive seed counting as 0), so "did not reach T bits" means "no speedup of T bits was shown", not "none exists".
"""
import argparse
import itertools
import json
import math
import os
import secrets
import sys

import certificate as K

FORMAT = "svp-claim-v1"
STATUSES = ("solved", "wrong", "failed", "crash", "timeout")


class ClaimError(Exception):
    pass


def _digest(cert):
    return K.sha256(K.canon(cert))


def _verified(cert, rerun=0, execute=False, sample_seed=None):
    """The certificate's verification result, or ClaimError: nothing is derived from a certificate that does not verify."""
    if sample_seed is None:
        sample_seed = secrets.randbelow(2 ** 31)   # the verifier's own draw (see certificate.py)
    res = K.verify(cert, rerun=rerun, execute=execute, sample_seed=sample_seed)
    if not res["ok"]:
        fails = [f"{c['check']}: {str(c['detail'])[:150]}" for c in res["checks"] if c["status"] == "fail"]
        raise ClaimError("the certificate does not verify, so nothing can be derived from it (" + "; ".join(fails[:3]) + ")")
    return res


def _check_status(res, name):
    return next((c["status"] for c in res["checks"] if c["check"] == name), None)


def _records(cert):
    """{role: {seed tag: [record, ...]}} from the certificate's raw ladders."""
    out = {"baseline": {}, "submission": {}}
    for tag, lad in cert["ladders"].items():
        for role in out:
            out[role][tag] = [json.loads(ln) for ln in lad[role].splitlines()[1:] if ln.strip()]
    return out


def wilson_lower(k, n, z=1.96):
    """Lower end of the Wilson score interval for k successes in n trials (z = 1.96: 95%). 0 when n is 0."""
    if n <= 0:
        return 0.0
    p = k / n
    denom = 1 + z * z / n
    centre = p + z * z / (2 * n)
    adj = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (centre - adj) / denom)


def _tally(recs):
    t = {s: 0 for s in STATUSES}
    t["other"] = 0
    for r in recs:
        t[r.get("status") if r.get("status") in STATUSES else "other"] += 1
    t["total"] = len(recs)
    return t


def _summ(t):
    acc = t["solved"] / t["total"] if t["total"] else 0.0
    return dict(t, accuracy=round(acc, 6), wilson95_lower=round(wilson_lower(t["solved"], t["total"]), 6))


def _reexecuted(res):
    """{"k", "of"} when this derivation also re-executed instances under step counting (certificate.verify --rerun --execute), else None. It describes the run that
    produced a claim, not the claim, so `check` leaves it out of the comparison."""
    rr = next((c.get("data") for c in res["checks"] if c["check"] == "rerun" and c.get("data")), None)
    return {"k": rr["k"], "of": rr["of"]} if isinstance(rr, dict) and rr.get("exact") is True else None


def _cap_of(cert):
    count = cert.get("count") if isinstance(cert.get("count"), dict) else None
    if count:
        return {"cost_model": "count", "cap": count["cap"], "cap_unit": f"counted seconds ({count['steps_per_second']:g} bytecode instructions each), on {count['python']}",
                "reproducible": True}
    head = json.loads(next(iter(cert["ladders"].values()))["submission"].splitlines()[0])
    return {"cost_model": "time", "cap": head.get("budget"), "cap_unit": "CPU seconds on the machine that measured it (see the certificate's sandbox)", "reproducible": False}


# ------------------------------------------------------------------------------------------------------------- correctness
def correctness(cert, res):
    """A benchmark score: for each solver in the certificate, the fraction of the committed questions its answer passed the family's own verifier within the cap."""
    recs = _records(cert)
    roles = {}
    for role, by_tag in recs.items():
        allr = [r for rs in by_tag.values() for r in rs]
        per_seed = {tag: _summ(_tally(rs))["accuracy"] for tag, rs in sorted(by_tag.items())}
        roles[role] = dict(_summ(_tally(allr)), per_seed=per_seed, worst_seed_accuracy=min(per_seed.values()) if per_seed else 0.0,
                           per_size={str(d): _summ(_tally([r for r in allr if r["dim"] == d])) for d in sorted({r["dim"] for r in allr})})
    cap = _cap_of(cert)
    return {"format": FORMAT, "kind": "correctness", "params": {}, "family": cert["family"], "solvers": {"submission": cert["submission"]["sha256"], "baseline": cert["baseline"]["sha256"]},
            "committed_before_submission": _check_status(res, "log") == "pass", "seeds": len(cert["ladders"]), "seeds_revealed": bool(cert.get("seeds_revealed")),
            "scoring": dict(cap, rule="solved = the answer passed the family's own verifier within the cap; wrong, no answer, a crash and a timeout all count as not solved"),
            "results": roles, "reexecuted": _reexecuted(res),
            "limits": ["a rate on THIS committed test set; the Wilson interval is for sampling variation of the generator, not a claim about other test sets",
                       "the cap is part of the question: an answer that needs longer than the cap counts as not solved"
                       + ("" if cap["reproducible"] else "; with timed costs 'within the cap' depends on the measuring machine, and only a counted certificate makes it reproducible by anyone"),
                       *([] if not cap["reproducible"] else ["a counted record is only PROVEN for the instances someone re-executes (`claims.py correctness CERT --rerun all --execute`, on the "
                                                            "same Python, in a throwaway VM): a status that was edited in an instance nobody re-ran would not be noticed by the arithmetic checks"])],
            "from": [_digest(cert)]}


# ------------------------------------------------------------------------------------------------------------- worst case (counted only)
def worst_case(cert, res):
    """The largest step count SEEN at each size, for a counted certificate (the counts are exact and re-executable). A size with any unsolved instance has no bound."""
    if not isinstance(cert.get("count"), dict):
        raise ClaimError("a worst-case claim needs a COUNTED certificate: timed costs are machine-dependent, so a maximum of them proves nothing portable "
                         "(make one with `svp.py practice --count` or from a counted round)")
    recs = _records(cert)
    roles = {}
    for role, by_tag in recs.items():
        allr = [r for rs in by_tag.values() for r in rs]
        per_size = {}
        for d in sorted({r["dim"] for r in allr}):
            at = [r for r in allr if r["dim"] == d]
            solved = [r for r in at if r.get("status") == "solved"]
            unsolved = len(at) - len(solved)
            bounded = unsolved == 0 and bool(at)
            per_size[str(d)] = {"instances": len(at), "unsolved": unsolved, "bounded": bounded,
                                "max_steps": max(r["steps"] for r in solved) if bounded else None,
                                "max_steps_among_solved": max((r["steps"] for r in solved), default=None),
                                "exceed_probability_bound": round(1 / (len(at) + 1), 6) if bounded else None}
        roles[role] = {"per_size": per_size, "all_bounded": all(v["bounded"] for v in per_size.values())}
    return {"format": FORMAT, "kind": "worst-case", "params": {}, "family": cert["family"], "solvers": {"submission": cert["submission"]["sha256"], "baseline": cert["baseline"]["sha256"]},
            "committed_before_submission": _check_status(res, "log") == "pass", "seeds": len(cert["ladders"]),
            "unit": f"bytecode instructions on {cert['count']['python']} (exactly reproducible: `--rerun K --execute` demands identical counts)",
            "cap_instructions": int(cert["count"]["cap"] * cert["count"]["steps_per_second"]), "results": roles, "reexecuted": _reexecuted(res),
            "limits": ["the largest value SEEN on the committed instances, not a bound over every input of that size: the chance that one more instance from the same "
                       "generator exceeds the maximum of n is at most 1/(n+1) (exchangeability), which is what exceed_probability_bound says",
                       "instructions are not seconds, and work inside C functions counts as one instruction (see COMPILER.md)",
                       "a size where any instance timed out or failed has no bound: those instances used more than the cap or did not finish"],
            "from": [_digest(cert)]}


# ------------------------------------------------------------------------------------------------------------- verified negative results
def submission_coverage(log, certified):
    """(logged, missing): {sha256: log data} of every submission the round's log accepted, and those among them with no certificate in `certified` (a set of sha256)."""
    logged = {}
    for e in log:
        data = e.get("data") if isinstance(e, dict) else None
        if e.get("kind") == "submission" and isinstance(data, dict) and isinstance(data.get("sha256"), str):
            logged[data["sha256"]] = data
    return logged, {h: d for h, d in logged.items() if h not in certified}


def negative(certs, results, threshold):
    """'No submission in this round reached `threshold` bits.' Needs a certificate for EVERY submission the round's log accepted, or it says the claim is incomplete.
    All certificates must verify, be of one round (same log), family, baseline and seeds."""
    if not certs:
        raise ClaimError("no certificate given")
    if not (isinstance(threshold, (int, float)) and not isinstance(threshold, bool) and math.isfinite(threshold) and threshold > 0):
        raise ClaimError("--threshold must be a positive number of bits")
    for c in certs:
        if not c.get("log"):
            raise ClaimError("a certificate without the round's log cannot support a negative result: without it nobody can know who else submitted")
    base = max((c["log"] for c in certs), key=len)
    for c in certs:
        if any(e.get("hash") != base[i].get("hash") for i, e in enumerate(c["log"])):
            raise ClaimError("these certificates are not from one round: their logs diverge")
    for key in ("family", "commitments"):
        if len({json.dumps(c[key], sort_keys=True) for c in certs}) != 1:
            raise ClaimError(f"the certificates disagree about {key}: they are not from one round")
    if len({c["baseline"]["sha256"] for c in certs}) != 1:
        raise ClaimError("the certificates were scored against different baselines")
    shas = [c["submission"]["sha256"] for c in certs]
    if len(set(shas)) != len(shas):
        raise ClaimError("two certificates are for the same submission")
    kinds = [e.get("kind") for e in base]
    if "round_closed" not in kinds:
        # a log is hash-chained, but a PREFIX of it verifies too: certificates built from a copy cut before the close would hide every later submission. The close entry
        # is the end of the submission list (nothing is accepted after it), so without it nobody can say these are all the submissions
        raise ClaimError("the round's log has no round_closed entry: submissions could still have been accepted after it ends, so these cannot be shown to be all of them")
    if "submission" in kinds[kinds.index("round_closed") + 1:]:
        raise ClaimError("the log records a submission after the round closed: the round did not follow its own rules")
    logged, missing = submission_coverage(base, set(shas))
    stray = [h for h in shas if h not in logged]
    if stray:
        raise ClaimError("a certificate is for a solver the round's log never accepted")
    rows = []
    for c in sorted(certs, key=lambda c: c["submission"]["sha256"]):
        d = logged[c["submission"]["sha256"]]
        rows.append({"id": d.get("id"), "handle": d.get("handle"), "sha256": c["submission"]["sha256"], "credit_bits": c["claim"]["credit_bits"], "status": c["claim"]["status"],
                     "reached_threshold": c["claim"]["credit_bits"] >= threshold, "private_solver": c.get("private") is True,
                     "cost_model": "count" if isinstance(c.get("count"), dict) else "time"})
    complete = not missing
    none_reached = not any(r["reached_threshold"] for r in rows)
    weak = [r["handle"] for r in rows if r["status"] not in ("OFFICIAL", "COUNTED")]
    return {"format": FORMAT, "kind": "negative", "params": {"threshold_bits": threshold}, "round": base[0]["data"].get("id"), "family": certs[0]["family"],
            "log_head": base[-1].get("hash"), "log_entries": len(base),     # publish/compare the head: it anchors "these are all the submissions"
            "baseline": certs[0]["baseline"]["sha256"], "logged_submissions": len(logged), "certified": len(rows), "complete": complete,
            "missing": [{"id": d.get("id"), "handle": d.get("handle"), "sha256": h} for h, d in sorted(missing.items())],
            "max_credit_bits": max(r["credit_bits"] for r in rows), "none_reached_threshold": none_reached,
            "claim_holds": complete and none_reached, "submissions": rows,
            "limits": ["about the submissions actually made (participants chose to submit), not about every possible approach",
                       "a credit is a conservative lower bound (minimum over seeds; an inconclusive seed counts as 0): 'did not reach the threshold' means no speedup of that size "
                       "was SHOWN, not that none exists",
                       "the list of submissions is the round's own log up to its close entry; its head hash (log_head) should be compared with one published somewhere the operator cannot edit",
                       *([] if not weak else ["PROVISIONAL credits (" + ", ".join(str(w) for w in weak) + ") were not made by the sandbox or by counting: weaker evidence that they did not reach the threshold"]),
                       "a submission whose evaluation failed has no certificate: it is listed under `missing`, and the claim is then NOT complete"
                       + ("" if all(r["cost_model"] == "count" for r in rows) else "; timed certificates rest on the operator's sandbox, only counted ones are reproducible by anyone")],
            "from": sorted(_digest(c) for c in certs)}


def _per_seed(cert):
    """({seed commitment: credit bits}, identified) for one certificate; a seed that was inconclusive counts as 0, as in the claim. `identified` is False when the
    credits are known but which seeds they belong to is not (the keys are then placeholders)."""
    es = sorted(cert["entries"], key=lambda e: e["seed_tag"])
    credits = cert["claim"]["per_seed"]
    shown = lambda xs: ["inconclusive" if e["bits"] is None else e["bits"] for e in xs]
    pool = es
    if shown(es) != credits:
        # judge.py scores only the official seeds (a Docker-sandbox run with a checked commitment) once there are enough of them, and the claim lists their credits without
        # their seeds. The scored seeds are found among the entries that could be official, and accepted only if exactly one choice reproduces the recorded credits.
        cand = [e for e in es if e.get("sandbox") == "docker" and e.get("commit_checked")]
        found = [list(c) for c in itertools.combinations(cand, len(credits)) if shown(c) == credits] if 0 < len(credits) <= len(cand) <= 16 else []
        if not found:
            raise ClaimError("this certificate's per-seed credits do not match any choice of its seeds: the certificate is inconsistent")
        if len(found) > 1:   # several seeds could have been the scored ones (identical credits): the credits themselves are still known exactly, the seeds are not
            return {f"unidentified-{i + 1}": 0.0 if b == "inconclusive" else float(b) for i, b in enumerate(credits)}, False
        pool = found[0]
    if len({e["commit"] for e in pool}) != len(pool):
        raise ClaimError("this certificate's per-seed credits cannot be matched to its seeds (two seeds share a commitment)")
    return {e["commit"]: 0.0 if e["bits"] is None else float(e["bits"]) for e in pool}, True


def _heads(cert):
    """The header line of every ladder file in the certificate."""
    return [json.loads(next((ln for ln in lad[role].splitlines() if ln.strip()), "{}")) for lad in cert["ladders"].values() for role in ("baseline", "submission")]


def _printable(text, limit=64):
    """A name from a certificate is untrusted text that ends up on a terminal: no control characters, bounded length."""
    return "".join(ch for ch in str(text)[:limit] if ch.isprintable())


def _timing_of(cert):
    return "counted" if all(e.get("sandbox") == "count" for e in cert["entries"]) else "timed"


def compare(certs, results):
    """'Solver A is faster than solver B, both measured against the same baseline.' Refuses unless both certificates verify and describe the SAME test: family, domain,
    rules, baseline and kind of measurement. It does not say how much faster: each credit is a conservative lower bound, so the difference of two lower bounds is not a
    bound on the true gap. It says only whether one is ahead on every seed (same seeds) or whether the two sets of per-seed credits do not overlap (different seeds)."""
    if len(certs) != 2:
        raise ClaimError("a comparison is about exactly two certificates")
    a, b = certs
    for key, label in (("family", "family"), ("domain", "problem declaration"), ("rules", "protocol code")):
        if K.canon(a.get(key)) != K.canon(b.get(key)):
            raise ClaimError(f"the certificates differ in {label}: they did not measure the same test")
    if a["baseline"]["sha256"] != b["baseline"]["sha256"]:
        raise ClaimError("the certificates were scored against different baselines")
    if a["submission"]["sha256"] == b["submission"]["sha256"]:
        raise ClaimError("both certificates are for the same submission")
    if len({e.get("instance_version") for e in a["entries"] + b["entries"]}) != 1:
        raise ClaimError("the certificates used different instance versions")
    ta, tb = _timing_of(a), _timing_of(b)
    if ta != tb:
        raise ClaimError(f"one certificate is {ta} and the other is {tb}: a step count and a clock time cannot be compared")
    def shape(c):   # a seed may drop its smallest sizes, so the sizes are compared as the union over the certificate's seeds
        es = c["entries"]
        return (sorted({d for e in es for d in e.get("measured_dims") or ()}), sorted({e.get("target_dim") for e in es}), sorted({e.get("budget") for e in es}), sorted({e.get("n") for e in es}))
    if shape(a) != shape(b):
        raise ClaimError("the certificates differ in the sizes measured, the size extrapolated to, the cost cap or the number of instances: they did not measure the same test")
    try:
        if ta == "counted":
            ia, ib = K._counted_info(a["ladders"]), K._counted_info(b["ladders"])
            if ia is None or ib is None or any(ia[k] != ib[k] for k in ("steps_per_second", "python", "cap", "dims", "n", "counter_sha256")):
                raise ClaimError("the counted certificates differ in the Python version, the counter, the cap or the sizes: they did not count the same way")
        else:
            hosts = {(h.get("host"), h.get("cpu"), h.get("image")) for c in (a, b) for h in _heads(c)}
            cpus = {e.get("cpu") for c in (a, b) for e in c["entries"]}
            if len(hosts) != 1 or len(cpus) != 1 or None in {x for t in hosts for x in t[:2]} | cpus:
                raise ClaimError("timed certificates from different (or unrecorded) machines cannot be compared")
    except K.CertificateError as e:
        raise ClaimError(f"the ladders cannot be compared ({str(e)[:120]})")
    (sa, ida), (sb, idb) = _per_seed(a), _per_seed(b)
    same = ida and idb and set(sa) == set(sb)
    if same:
        diffs = {k: round(sa[k] - sb[k], 6) for k in sa}
        verdict = ("A is ahead on every seed" if all(d > 0 for d in diffs.values()) else "B is ahead on every seed" if all(d < 0 for d in diffs.values())
                   else "neither is ahead on every seed")
    else:
        diffs = None
        lo_a, hi_a, lo_b, hi_b = min(sa.values()), max(sa.values()), min(sb.values()), max(sb.values())
        verdict = ("A is above B on every seed of both (the ranges do not overlap)" if lo_a > hi_b else "B is above A on every seed of both (the ranges do not overlap)" if lo_b > hi_a
                   else "the two sets of credits overlap, so neither is shown to be ahead")
    def side(c, s):
        return {"name": _printable(c["submission"]["name"]), "sha256": c["submission"]["sha256"], "credit_bits": c["claim"]["credit_bits"], "status": c["claim"]["status"], "per_seed": s}
    provisional = [label for label, c in (("A", a), ("B", b)) if "PROVISIONAL" in c["claim"]["status"]]
    return {"format": FORMAT, "kind": "compare", "family": _printable(a["family"]), "baseline_sha256": a["baseline"]["sha256"], "measurement": ta,
            "from": [_digest(a), _digest(b)], "a": side(a, sa), "b": side(b, sb), "same_seeds": same, "seeds_identified": bool(ida and idb), "per_seed_difference_bits": diffs,
            "difference_of_credits_bits": round(a["claim"]["credit_bits"] - b["claim"]["credit_bits"], 6), "verdict": verdict, "provisional": provisional,
            "limits": ["each credit is a conservative lower bound, so the difference between two credits is not a bound on how much faster one is",
                       "a few seeds is a small sample; a seed that was inconclusive counts as 0",
                       "neither certificate was re-run here: the records were checked arithmetically (use `guldo verify --rerun all --execute` on a throwaway machine to re-run them)",
                       "it compares what was submitted and measured, not every possible approach"
                       + (("; which seeds were scored could not be identified, so they are not shown to be the same" if not (ida and idb) else "; the seeds differ, so the two were not given the same questions")
                          + ("; a provisional seed may have been chosen by its owner" if provisional else "") if not same else "")
                       + ("; two timed runs on the same kind of machine are not the same machine" if ta == "timed" else ""),
                       *(["a seed that did not count toward a certificate's own credit (it was not official) is left out of the comparison"] if len(sa) != len(a["entries"]) or len(sb) != len(b["entries"]) else [])]}


# ------------------------------------------------------------------------------------------------------------- driver
def derive(kind, certs, threshold=None, rerun=0, execute=False, sample_seed=None):
    if kind == "compare":
        return compare(certs, [_verified(c) for c in certs])
    if kind == "negative":
        results = [_verified(c) for c in certs]
        return negative(certs, results, threshold)
    if len(certs) != 1:
        raise ClaimError(f"a {kind} claim is about one certificate")
    res = _verified(certs[0], rerun, execute, sample_seed)
    return correctness(certs[0], res) if kind == "correctness" else worst_case(certs[0], res)


def render(c):
    """Plain-language lines for a claim."""
    out = []
    if c["kind"] == "correctness":
        out.append(f"CORRECTNESS on family {c['family']}, {c['seeds']} committed seed(s)" + ("" if c["committed_before_submission"] else " (NO round log: the seeds were not shown to be public first)"))
        out.append(f"  scoring: {c['scoring']['rule']}; cap {c['scoring']['cap']:g} {c['scoring']['cap_unit']}")
        for role, r in c["results"].items():
            out.append(f"  {role}: {r['solved']}/{r['total']} solved = {r['accuracy']:.1%} (95% Wilson lower bound {r['wilson95_lower']:.1%}); worst seed {r['worst_seed_accuracy']:.1%}; "
                       f"wrong {r['wrong']}, no answer {r['failed']}, crashed {r['crash']}, timed out {r['timeout']}")
    elif c["kind"] == "worst-case":
        out.append(f"WORST CASE SEEN on family {c['family']}, in {c['unit']}; cap {c['cap_instructions']:,} instructions")
        for role, r in c["results"].items():
            for d, v in r["per_size"].items():
                out.append(f"  {role} size {d}: " + (f"at most {v['max_steps']:,} over {v['instances']} instances (chance a fresh one exceeds it <= {v['exceed_probability_bound']:g})" if v["bounded"] else
                                                      f"NO BOUND: {v['unsolved']} of {v['instances']} not solved within the cap"))
    elif c["kind"] == "compare":
        out.append(f"COMPARISON on family {c['family']}, same baseline, {c['measurement']} measurement, {'the same seeds' if c['same_seeds'] else 'DIFFERENT seeds' if c['seeds_identified'] else 'seeds that could not be identified'}")
        for label in ("a", "b"):
            s = c[label]
            out.append(f"  {label.upper()}: {s['name']}  credit {s['credit_bits']} bits  ({s['status']})  per seed: " + ", ".join(f"{v:g}" for v in s["per_seed"].values()))
        out.append(f"  difference of the two credits: {c['difference_of_credits_bits']:+g} bits (A minus B)")
        out.append("  " + c["verdict"][0].upper() + c["verdict"][1:])
        if c["provisional"]:
            out.append(f"  PROVISIONAL: the certificate for {' and '.join(c['provisional'])} is not official, so this comparison is not either")
    else:
        out.append(f"NEGATIVE RESULT, round {c['round']}, family {c['family']}: threshold {c['params']['threshold_bits']:g} bits")
        out.append(f"  {c['certified']} of {c['logged_submissions']} logged submission(s) certified; highest credit {c['max_credit_bits']} bits")
        for r in c["submissions"]:
            out.append(f"  {str(r['handle']):16s} {r['credit_bits']:5} bits  {r['status']}" + ("  REACHED" if r["reached_threshold"] else ""))
        if not c["complete"]:
            out.append(f"  INCOMPLETE: {len(c['missing'])} logged submission(s) have no certificate ({', '.join(str(m['handle']) for m in c['missing'])}), so the claim does not hold")
        out.append("  CLAIM HOLDS: no logged submission reached the threshold" if c["claim_holds"] else "  claim does not hold" + ("" if c["complete"] else " (incomplete)"))
    if c["kind"] not in ("negative", "compare"):
        rx = c.get("reexecuted")
        out.append(f"  re-executed here under step counting: {rx['k']} of {rx['of']} instances, all identical" if rx else
                   "  re-executed here: none (the records were checked arithmetically, not re-run)")
    out.append("  does not show: " + "; ".join(c["limits"]))
    return out


def _load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def check_claim(claim, certs):
    """Recompute `claim` from the certificates: (ok, why). Equality is exact; the claim file is not trusted."""
    if not isinstance(claim, dict) or claim.get("format") != FORMAT or claim.get("kind") not in ("correctness", "worst-case", "negative", "compare"):
        return False, "not a claim file"
    if not (isinstance(claim.get("from"), list) and all(isinstance(x, str) for x in claim["from"])):
        return False, "not a claim file (no list of certificate digests)"
    try:
        if (claim["from"] != [_digest(c) for c in certs]) if claim["kind"] == "compare" else (sorted(claim["from"]) != sorted(_digest(c) for c in certs)):
            return False, "the certificates given are not the ones this claim was derived from"
        params = claim.get("params") if isinstance(claim.get("params"), dict) else {}
        again = derive(claim["kind"], certs, threshold=params.get("threshold_bits"))
        same = _comparable(again) == _comparable(claim)
    except ClaimError as e:
        return False, str(e)
    except (KeyError, TypeError, ValueError, AttributeError, IndexError) as e:   # a malformed claim or certificate: a refusal, never a traceback
        return False, f"malformed input ({type(e).__name__})"
    return same, ("recomputed identically" if same else "the recomputed claim differs from the file")


def _comparable(claim):
    return K.canon({k: v for k, v in claim.items() if k != "reexecuted"})


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("correctness", "worst-case"):
        p = sub.add_parser(name)
        p.add_argument("cert")
        p.add_argument("--out")
        p.add_argument("--rerun", type=K.rerun_count, default=0, metavar="K|all")
        p.add_argument("--execute", action="store_true", help="re-run instances here (RUNS the certificate's solvers, unsandboxed: a throwaway VM)")
    p = sub.add_parser("negative")
    p.add_argument("certs", nargs="+")
    p.add_argument("--threshold", type=float, required=True, help="the speedup in bits that no submission should have reached")
    p.add_argument("--out")
    p = sub.add_parser("compare")
    p.add_argument("cert_a")
    p.add_argument("cert_b")
    p.add_argument("--out")
    p = sub.add_parser("check")
    p.add_argument("claim")
    p.add_argument("certs", nargs="+")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "check":
            ok, why = check_claim(_load(a.claim), [_load(c) for c in a.certs])
            print(("CONFIRMED: " if ok else "NOT CONFIRMED: ") + why)
            return 0 if ok else 1
        if a.cmd == "compare":
            claim = derive("compare", [_load(a.cert_a), _load(a.cert_b)])
        elif a.cmd == "negative":
            claim = derive("negative", [_load(c) for c in a.certs], threshold=a.threshold)
        else:
            claim = derive(a.cmd, [_load(a.cert)], rerun=a.rerun, execute=a.execute)
    except ClaimError as e:
        print(f"REFUSED: {e}", file=sys.stderr)
        return 1
    except (OSError, ValueError, KeyError, TypeError) as e:
        print(f"REFUSED: could not read the input ({type(e).__name__}: {str(e)[:120]})", file=sys.stderr)
        return 1
    print("\n".join(render(claim)))
    if a.out:
        if os.path.exists(a.out):
            print(f"REFUSED: {a.out} exists; a claim file is never overwritten", file=sys.stderr)
            return 1
        fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(claim, f, indent=1, sort_keys=True)
        print(f"wrote {a.out} (anyone can confirm it: claims.py check {a.out} CERT...)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
