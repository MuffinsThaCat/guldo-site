"""Reference for aifactor: a KV cache in float64 with the low-rank feed-forward factors multiplied out once (numpy).

The model definition is domains/aifactor/decl.py's: the SplitMix64 stream (element k = finalise((k+1)*GOLD + seed), mapped to [-1,1) as (z >> 11) * 2^-52 - 1) lays out tok (64x128, scale
sqrt(3)); then per layer Wq, Wk, Wv, Wo (128x128, scale W_SCALE*sqrt(3/128)), A1 (128x8, that scale), B1 (8x512, sqrt(3/8)), A2 (512x8, W_SCALE*sqrt(3/512)), B2 (8x128, sqrt(3/8)); then
pos ((8+T)x128, scale POS_SCALE*sqrt(3)) and 8 prompt tokens. W_SCALE = 4, POS_SCALE = 3. W1 = A1 B1 and W2 = A2 B2. Greedy decoding as in aidecode.
"""
import math

import numpy as np

V, D, H, DH, FF, L, PROMPT, R = 64, 128, 4, 32, 512, 2, 8, 8
W_SCALE, POS_SCALE = 4.0, 3.0
_GOLD, _C1, _C2 = 0x9E3779B97F4A7C15, 0xBF58476D1CE4E5B9, 0x94D049BB133111EB


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def solve(seed, prompt_len, T):
    o = [0]

    def take(shape, scale):
        n = int(np.prod(shape))
        a = (_uniform(seed, o[0], n) * scale).reshape(shape)
        o[0] += n
        return a
    sd = W_SCALE * math.sqrt(3.0 / D)
    tok = take((V, D), math.sqrt(3.0))
    layers = []
    for _ in range(L):
        l = {"Wq": take((D, D), sd), "Wk": take((D, D), sd), "Wv": take((D, D), sd), "Wo": take((D, D), sd)}
        A1, B1 = take((D, R), sd), take((R, FF), math.sqrt(3.0 / R))
        A2, B2 = take((FF, R), W_SCALE * math.sqrt(3.0 / FF)), take((R, D), math.sqrt(3.0 / R))
        l["W1"], l["W2"] = A1 @ B1, A2 @ B2
        layers.append(l)
    pos = take((PROMPT + T, D), POS_SCALE * math.sqrt(3.0))
    seq = [int(t) for t in np.minimum(((_uniform(seed, o[0], PROMPT) + 1.0) * 0.5 * V).astype(np.int64), V - 1)]
    n = PROMPT + T
    K = [np.zeros((n, D)) for _ in range(L)]
    Vv = [np.zeros((n, D)) for _ in range(L)]
    out = []
    for p in range(n - 1):
        x = tok[seq[p]] + pos[p]
        for li, l in enumerate(layers):
            h = _rms(x)
            q = (h @ l["Wq"]).reshape(H, DH)
            K[li][p], Vv[li][p] = h @ l["Wk"], h @ l["Wv"]
            kc, vc = K[li][:p + 1].reshape(p + 1, H, DH), Vv[li][:p + 1].reshape(p + 1, H, DH)
            s = np.einsum("hd,thd->ht", q, kc) / math.sqrt(DH)
            s -= s.max(-1, keepdims=True)
            a = np.exp(s)
            a /= a.sum(-1, keepdims=True)
            x = x + np.einsum("ht,thd->hd", a, vc).reshape(D) @ l["Wo"]
            x = x + np.maximum(_rms(x) @ l["W1"], 0.0) @ l["W2"]
        if p >= PROMPT - 1:
            t = int(np.argmax(_rms(x) @ tok.T))
            out.append(t)
            seq.append(t)
    return out
