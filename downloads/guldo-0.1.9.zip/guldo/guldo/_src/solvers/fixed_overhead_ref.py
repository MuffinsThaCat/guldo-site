"""Red-team reference: baseline plus 1.0 CPU-second of fixed setup cost.
Comparing baseline_bkz against this shows a large 'speedup' at small n (setup dominates) that vanishes as real work
grows, the classic constant-overhead fallacy. The verifier must refuse to extrapolate it."""
import time

from fpylll import BKZ, LLL, IntegerMatrix


def solve(basis, bound2):
    t0 = time.process_time()
    while time.process_time() - t0 < 1.0:
        pass
    n = len(basis)
    A = IntegerMatrix.from_matrix(basis)
    LLL.reduction(A)
    for beta in list(range(10, n + 1, 4)):
        if sum(x * x for x in A[0]) <= bound2:
            break
        BKZ.reduction(A, BKZ.Param(block_size=beta, flags=BKZ.AUTO_ABORT | BKZ.MAX_LOOPS, max_loops=8))
    v = [int(x) for x in A[0]]
    return v if sum(x * x for x in v) <= bound2 else None
