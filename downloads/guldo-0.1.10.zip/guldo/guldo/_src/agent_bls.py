"""BLS12-381 in pure Python (standard library only): just enough to VERIFY a drand beacon signature offline.

  verify_g1_signature(pubkey_g2: bytes(96), message: bytes, signature_g1: bytes(48), dst: bytes) -> bool      e(sig, g2) == e(H(message), pubkey)
  hash_to_g1(message, dst)            RFC 9380 BLS12381G1_XMD:SHA-256_SSWU_RO_
  g1_decompress / g2_decompress       ZCash-format compressed points, with on-curve AND prime-order-subgroup checks
  pairing(P, Q)                       the optimal ate pairing e(P in G1, Q in G2) (final exponentiation included)

This exists so that a seed can be tied to a PUBLIC RANDOMNESS BEACON (drand) with no dependency and no network trust: the signature is checked here, against a public key the reader pinned.

WHAT IT IS AND IS NOT. It is written for clarity and checked, not for speed or side-channel safety: it is variable-time, a pairing takes about a second, and it handles only PUBLIC data (a public key, a message and a signature), never a secret. Nothing here signs. It is not
a general-purpose BLS library. Correctness is established three ways in test_agent_beacon: (1) the official RFC 9380 test vectors for hash-to-curve (hash-to-field, the SWU map and the full hash), (2) group-law and bilinearity checks on the pairing, and (3) real drand beacons fetched live, whose
signatures a wrong pairing or a wrong hash-to-curve could not possibly verify. The one structure that is not taken from a spec is the untwisted affine Miller loop, which is chosen because it is short and easy to audit.
"""
import hashlib

import agent_bls_data as D

P = 0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffaaab
R = 0x73eda753299d7d483339d80809a1d80553bda402fffe5bfeffffffff00000001
X = -0xd201000000010000                     # the BLS parameter x (negative)
H_EFF_G1 = 0xd201000000010001
B1 = 4
DST_SIG_G1 = b"BLS_SIG_BLS12381G1_XMD:SHA-256_SSWU_RO_NUL_"


class BlsError(ValueError):
    pass


# ---- Fp2 = Fp[u]/(u^2+1) ---------------------------------------------------------------------------------------------------------------------------------

class F2(object):
    __slots__ = ("a", "b")

    def __init__(self, a=0, b=0):
        self.a, self.b = a % P, b % P

    def __add__(s, o):
        return F2(s.a + o.a, s.b + o.b)

    def __sub__(s, o):
        return F2(s.a - o.a, s.b - o.b)

    def __neg__(s):
        return F2(-s.a, -s.b)

    def __mul__(s, o):
        if isinstance(o, int):
            return F2(s.a * o, s.b * o)
        return F2(s.a * o.a - s.b * o.b, s.a * o.b + s.b * o.a)

    def sqr(s):
        return F2((s.a + s.b) * (s.a - s.b), 2 * s.a * s.b)

    def inv(s):
        n = pow(s.a * s.a + s.b * s.b, -1, P)
        return F2(s.a * n, -s.b * n)

    def conj(s):
        return F2(s.a, -s.b)

    def mul_xi(s):                                         # times (1 + u)
        return F2(s.a - s.b, s.a + s.b)

    def is_zero(s):
        return s.a == 0 and s.b == 0

    def __eq__(s, o):
        return s.a == o.a and s.b == o.b

    def __hash__(s):
        return hash((s.a, s.b))


F2_ZERO, F2_ONE = F2(0, 0), F2(1, 0)


def f2_pow(x, e):
    r = F2_ONE
    while e:
        if e & 1:
            r = r * x
        x = x.sqr()
        e >>= 1
    return r


def f2_sqrt(a):
    """A square root in Fp2 (p = 3 mod 4), or None if `a` is not a square."""
    if a.is_zero():
        return F2_ZERO
    a1 = f2_pow(a, (P - 3) // 4)
    alpha = a1 * a1 * a
    x0 = a1 * a
    if alpha == F2(-1, 0):
        x = F2(0, 1) * x0
    else:
        x = f2_pow(F2(1, 0) + alpha, (P - 1) // 2) * x0
    return x if x.sqr() == a else None


# ---- Fp6 = Fp2[v]/(v^3 - (1+u)) ---------------------------------------------------------------------------------------------------------------------------

class F6(object):
    __slots__ = ("c0", "c1", "c2")

    def __init__(self, c0, c1, c2):
        self.c0, self.c1, self.c2 = c0, c1, c2

    def __add__(s, o):
        return F6(s.c0 + o.c0, s.c1 + o.c1, s.c2 + o.c2)

    def __sub__(s, o):
        return F6(s.c0 - o.c0, s.c1 - o.c1, s.c2 - o.c2)

    def __neg__(s):
        return F6(-s.c0, -s.c1, -s.c2)

    def __mul__(s, o):
        t0, t1, t2 = s.c0 * o.c0, s.c1 * o.c1, s.c2 * o.c2
        c0 = t0 + ((s.c1 + s.c2) * (o.c1 + o.c2) - t1 - t2).mul_xi()
        c1 = (s.c0 + s.c1) * (o.c0 + o.c1) - t0 - t1 + t2.mul_xi()
        c2 = (s.c0 + s.c2) * (o.c0 + o.c2) - t0 - t2 + t1
        return F6(c0, c1, c2)

    def mul_v(s):
        return F6(s.c2.mul_xi(), s.c0, s.c1)

    def inv(s):
        c0 = s.c0.sqr() - (s.c1 * s.c2).mul_xi()
        c1 = s.c2.sqr().mul_xi() - s.c0 * s.c1
        c2 = s.c1.sqr() - s.c0 * s.c2
        t = ((s.c2 * c1 + s.c1 * c2).mul_xi() + s.c0 * c0).inv()
        return F6(c0 * t, c1 * t, c2 * t)

    def __eq__(s, o):
        return s.c0 == o.c0 and s.c1 == o.c1 and s.c2 == o.c2


F6_ZERO = F6(F2_ZERO, F2_ZERO, F2_ZERO)
F6_ONE = F6(F2_ONE, F2_ZERO, F2_ZERO)


# ---- Fp12 = Fp6[w]/(w^2 - v) ------------------------------------------------------------------------------------------------------------------------------

class F12(object):
    __slots__ = ("a0", "a1")

    def __init__(self, a0, a1):
        self.a0, self.a1 = a0, a1

    def __add__(s, o):
        return F12(s.a0 + o.a0, s.a1 + o.a1)

    def __sub__(s, o):
        return F12(s.a0 - o.a0, s.a1 - o.a1)

    def __neg__(s):
        return F12(-s.a0, -s.a1)

    def __mul__(s, o):
        t0, t1 = s.a0 * o.a0, s.a1 * o.a1
        return F12(t0 + t1.mul_v(), (s.a0 + s.a1) * (o.a0 + o.a1) - t0 - t1)

    def sqr(s):
        return s * s

    def inv(s):
        t = (s.a0 * s.a0 - (s.a1 * s.a1).mul_v()).inv()
        return F12(s.a0 * t, -(s.a1 * t))

    def conj(s):                                           # x^(p^6)
        return F12(s.a0, -s.a1)

    def __eq__(s, o):
        return s.a0 == o.a0 and s.a1 == o.a1


F12_ONE = F12(F6_ONE, F6_ZERO)
W = F12(F6_ZERO, F6_ONE)
W2 = W * W
W3 = W2 * W
W2_INV, W3_INV = W2.inv(), W3.inv()


def f12_pow(x, e):
    r = F12_ONE
    while e:
        if e & 1:
            r = r * x
        x = x.sqr()
        e >>= 1
    return r


def fp_to_12(a):
    return F12(F6(F2(a, 0), F2_ZERO, F2_ZERO), F6_ZERO)


def f2_to_12(x):
    return F12(F6(x, F2_ZERO, F2_ZERO), F6_ZERO)


# ---- G1: y^2 = x^3 + 4 over Fp ---------------------------------------------------------------------------------------------------------------------------------

G1_GEN = (0x17f1d3a73197d7942695638c4fa9ac0fc3688c4f9774b905a14e3a3f171bac586c55e83ff97a1aeffb3af00adb22c6bb,
          0x08b3f481e3aaa0f1a09e30ed741d8ae4fcf5e095d5d00af600db18cb2c04b3edd03cc744a2888ae40caa232946c5e7e1)


def g1_on_curve(p):
    return p is None or (p[1] * p[1] - p[0] ** 3 - B1) % P == 0


def g1_neg(p):
    return None if p is None else (p[0], (-p[1]) % P)


def g1_add(p, q):
    if p is None:
        return q
    if q is None:
        return p
    if p[0] == q[0]:
        if (p[1] + q[1]) % P == 0:
            return None
        lam = 3 * p[0] * p[0] * pow(2 * p[1], -1, P) % P
    else:
        lam = (q[1] - p[1]) * pow(q[0] - p[0], -1, P) % P
    x = (lam * lam - p[0] - q[0]) % P
    return (x, (lam * (p[0] - x) - p[1]) % P)


def g1_mul(p, k):
    if k < 0:
        return g1_mul(g1_neg(p), -k)
    r = None
    while k:
        if k & 1:
            r = g1_add(r, p)
        p = g1_add(p, p)
        k >>= 1
    return r


# ---- G2: y^2 = x^3 + 4(1+u) over Fp2 ---------------------------------------------------------------------------------------------------------------------------

B2 = F2(4, 4)
G2_GEN = (F2(0x024aa2b2f08f0a91260805272dc51051c6e47ad4fa403b02b4510b647ae3d1770bac0326a805bbefd48056c8c121bdb8,
             0x13e02b6052719f607dacd3a088274f65596bd0d09920b61ab5da61bbdc7f5049334cf11213945d57e5ac7d055d042b7e),
          F2(0x0ce5d527727d6e118cc9cdc6da2e351aadfd9baa8cbdd3a76d429a695160d12c923ac9cc3baca289e193548608b82801,
             0x0606c4a02ea734cc32acd2b02bc28b99cb3e287e85a763af267492ab572e99ab3f370d275cec1da1aaa9075ff05f79be))


def g2_on_curve(p):
    return p is None or p[1].sqr() == p[0].sqr() * p[0] + B2


def g2_neg(p):
    return None if p is None else (p[0], -p[1])


def g2_add(p, q):
    if p is None:
        return q
    if q is None:
        return p
    if p[0] == q[0]:
        if (p[1] + q[1]).is_zero():
            return None
        lam = p[0].sqr() * 3 * (p[1] * 2).inv()
    else:
        lam = (q[1] - p[1]) * (q[0] - p[0]).inv()
    x = lam.sqr() - p[0] - q[0]
    return (x, lam * (p[0] - x) - p[1])


def g2_mul(p, k):
    if k < 0:
        return g2_mul(g2_neg(p), -k)
    r = None
    while k:
        if k & 1:
            r = g2_add(r, p)
        p = g2_add(p, p)
        k >>= 1
    return r


# ---- compressed points (ZCash format) ---------------------------------------------------------------------------------------------------------------------------

def _flags(b):
    return bool(b[0] & 0x80), bool(b[0] & 0x40), bool(b[0] & 0x20)


def fp_sqrt(a):
    r = pow(a, (P + 1) // 4, P)
    return r if r * r % P == a % P else None


def g1_decompress(data):
    """A G1 point from 48 bytes. Raises BlsError unless it is a well-formed point ON the curve and IN the prime-order subgroup (or the point at infinity)."""
    if not isinstance(data, (bytes, bytearray)) or len(data) != 48:
        raise BlsError("a compressed G1 point is 48 bytes")
    comp, inf, big = _flags(data)
    if not comp:
        raise BlsError("not a compressed point")
    x = int.from_bytes(bytes([data[0] & 0x1f]) + bytes(data[1:]), "big")
    if inf:
        if x != 0 or big:
            raise BlsError("a malformed point at infinity")
        return None
    if x >= P:
        raise BlsError("x is not a field element")
    y = fp_sqrt(x ** 3 + B1)
    if y is None:
        raise BlsError("x is not on the curve")
    if (y > (P - 1) // 2) != big:
        y = P - y
    pt = (x, y)
    if g1_mul(pt, R) is not None:
        raise BlsError("the point is not in the prime-order subgroup")
    return pt


def g2_decompress(data):
    if not isinstance(data, (bytes, bytearray)) or len(data) != 96:
        raise BlsError("a compressed G2 point is 96 bytes")
    comp, inf, big = _flags(data)
    if not comp:
        raise BlsError("not a compressed point")
    c1 = int.from_bytes(bytes([data[0] & 0x1f]) + bytes(data[1:48]), "big")
    c0 = int.from_bytes(bytes(data[48:]), "big")
    if inf:
        if c0 != 0 or c1 != 0 or big:
            raise BlsError("a malformed point at infinity")
        return None
    if c0 >= P or c1 >= P:
        raise BlsError("x is not a field element")
    x = F2(c0, c1)
    y = f2_sqrt(x.sqr() * x + B2)
    if y is None:
        raise BlsError("x is not on the curve")
    ybig = (y.b > (P - 1) // 2) if y.b != 0 else (y.a > (P - 1) // 2)
    if ybig != big:
        y = -y
    pt = (x, y)
    if g2_mul(pt, R) is not None:
        raise BlsError("the point is not in the prime-order subgroup")
    return pt


def g1_compress(pt):
    if pt is None:
        return bytes([0xc0]) + bytes(47)
    b = bytearray(pt[0].to_bytes(48, "big"))
    b[0] |= 0x80 | (0x20 if pt[1] > (P - 1) // 2 else 0)
    return bytes(b)


def g2_compress(pt):
    if pt is None:
        return bytes([0xc0]) + bytes(95)
    x, y = pt
    big = (y.b > (P - 1) // 2) if y.b != 0 else (y.a > (P - 1) // 2)
    b = bytearray(x.b.to_bytes(48, "big") + x.a.to_bytes(48, "big"))
    b[0] |= 0x80 | (0x20 if big else 0)
    return bytes(b)


# ---- the pairing -------------------------------------------------------------------------------------------------------------------------------------------------

def _untwist(q):
    return (f2_to_12(q[0]) * W2_INV, f2_to_12(q[1]) * W3_INV)


def _line_and_double(t, p):
    xt, yt = t
    lam = fp_to_12(3) * xt.sqr() * (yt + yt).inv()
    line = (p[1] - yt) - lam * (p[0] - xt)
    x3 = lam.sqr() - xt - xt
    return line, (x3, lam * (xt - x3) - yt)


def _line_and_add(t, q, p):
    xt, yt = t
    lam = (q[1] - yt) * (q[0] - xt).inv()
    line = (p[1] - yt) - lam * (p[0] - xt)
    x3 = lam.sqr() - xt - q[0]
    return line, (x3, lam * (xt - x3) - yt)


def miller_loop(q, p):
    """The Miller function f_{|x|,Q}(P) for Q in G2 and P in G1 (both as ordinary affine points), conjugated because x is negative."""
    if q is None or p is None:
        return F12_ONE
    Q = _untwist(q)
    Pp = (fp_to_12(p[0]), fp_to_12(p[1]))
    T, f = Q, F12_ONE
    for bit in bin(-X)[3:]:
        line, T = _line_and_double(T, Pp)
        f = f.sqr() * line
        if bit == "1":
            line, T = _line_and_add(T, Q, Pp)
            f = f * line
    return f.conj()


_HARD = (P ** 4 - P ** 2 + 1) // R
assert (P ** 4 - P ** 2 + 1) % R == 0


def final_exponentiation(f):
    g = f.conj() * f.inv()                              # f^(p^6 - 1)
    g = f12_pow(g, P * P) * g                           # ^(p^2 + 1)
    return f12_pow(g, _HARD)                            # ^((p^4 - p^2 + 1) / r)


def pairing(p, q):
    return final_exponentiation(miller_loop(q, p))


# ---- hash to G1 (RFC 9380, BLS12381G1_XMD:SHA-256_SSWU_RO_) -----------------------------------------------------------------------------------------------------

A_ISO = 0x144698a3b8e9433d693a02c96d4982b0ea985383ee66a8d8e8981aefd881ac98936f8da0e0f97f5cf428082d584c1d
B_ISO = 0x12e2908d11688030018b12e8753eee3b2016c1f0f24f4070a0b9c14fcef35ef55a23215a316ceaa5d1cc48e98e172be0
Z_SSWU = 11


def expand_message_xmd(msg, dst, n):
    if len(dst) > 255 or n > 65535:
        raise BlsError("DST or output too long")
    ell = -(-n // 32)
    if ell > 255:
        raise BlsError("output too long")
    dst_prime = dst + bytes([len(dst)])
    b0 = hashlib.sha256(bytes(64) + msg + n.to_bytes(2, "big") + b"\x00" + dst_prime).digest()
    b = [hashlib.sha256(b0 + b"\x01" + dst_prime).digest()]
    for i in range(2, ell + 1):
        b.append(hashlib.sha256(bytes(x ^ y for x, y in zip(b0, b[-1])) + bytes([i]) + dst_prime).digest())
    return b"".join(b)[:n]


def hash_to_field(msg, dst, count=2):
    L = 64
    tv = expand_message_xmd(msg, dst, count * L)
    return [int.from_bytes(tv[L * i:L * (i + 1)], "big") % P for i in range(count)]


def _is_square(a):
    return pow(a, (P - 1) // 2, P) in (0, 1)


def map_to_curve_sswu(u):
    """RFC 9380 6.6.2 on the isogenous curve E': y^2 = x^3 + A'x + B'."""
    z, a, b = Z_SSWU, A_ISO, B_ISO
    tv1 = (z * z * pow(u, 4, P) + z * u * u) % P
    inv1 = pow(tv1, P - 2, P) if tv1 else 0
    x1 = (-b * pow(a, -1, P) * (1 + inv1)) % P if tv1 else (b * pow(z * a, -1, P)) % P
    gx1 = (x1 ** 3 + a * x1 + b) % P
    x2 = (z * u * u * x1) % P
    gx2 = (x2 ** 3 + a * x2 + b) % P
    if _is_square(gx1):
        x, y = x1, fp_sqrt(gx1)
    else:
        x, y = x2, fp_sqrt(gx2)
    if (u & 1) != (y & 1):
        y = P - y
    return x, y


def _horner(coeffs, x, monic=False):
    r = 1 if monic else 0
    for c in (reversed(coeffs) if not monic else reversed(coeffs)):
        r = (r * x + c) % P
    return r


def iso_map(xp, yp):
    """The 11-isogeny E' -> E (RFC 9380 appendix E.2)."""
    k1, k2, k3, k4 = D.ISO[1], D.ISO[2], D.ISO[3], D.ISO[4]
    xn = _horner(k1, xp)
    xd = _horner(k2, xp, monic=True)
    yn = _horner(k3, xp)
    yd = _horner(k4, xp, monic=True)
    if xd == 0 or yd == 0:
        return None
    return (xn * pow(xd, -1, P)) % P, (yp * yn % P) * pow(yd, -1, P) % P


def hash_to_g1(msg, dst=DST_SIG_G1):
    u0, u1 = hash_to_field(msg, dst, 2)
    q0, q1 = iso_map(*map_to_curve_sswu(u0)), iso_map(*map_to_curve_sswu(u1))
    return g1_mul(g1_add(q0, q1), H_EFF_G1)


# ---- verification -----------------------------------------------------------------------------------------------------------------------------------------------

def verify_g1_signature(pubkey_g2, message, signature_g1, dst=DST_SIG_G1):
    """True iff `signature_g1` (48 bytes) is a valid BLS signature of `message` under `pubkey_g2` (96 bytes), by e(sig, g2) == e(H(m), pk). Never raises: anything malformed is False."""
    try:
        pk, sig = g2_decompress(pubkey_g2), g1_decompress(signature_g1)
    except BlsError:
        return False
    if pk is None or sig is None:
        return False
    hm = hash_to_g1(message, dst)
    f = miller_loop(G2_GEN, sig) * miller_loop(g2_neg(pk), hm)
    return final_exponentiation(f) == F12_ONE
