"""aimixed with bytes counted, TECHNIQUE: the mixed-precision recipe taken to FP8. The features and the per-step weight copy are fp8 e4m3 (3 mantissa bits), the residual is cast to fp8 e5m2 (2 mantissa bits, wide range) for the gradient product; everything else is fp32 as before. A quarter of fp32's matrix-input bytes, and a rounding error of about 6% per value: the judge's 1e-6 loss tolerance almost certainly rejects it, and this solver is here to show where the format ladder ends."""
import math

import tensorops as tp

RHO = 0.9
LAM = 1e-3
STEPS = 10000


def features(seed, d, n):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    return (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)


def solve(seed, d, n, labels):
    X = features(seed, d, n)
    lr = 1.0 / (tp.sum(X * X).item() / (4.0 * n) + LAM)
    X8 = tp.cast(X, "fp8e4m3")
    X = 0
    y = tp.cast(tp.tensor([float(v) for v in labels]), "fp32")
    Xt = tp.transpose(X8, (1, 0))
    w = tp.cast(tp.zeros((d,)), "fp32")
    for step in range(STEPS):
        z = X8 @ tp.cast(w, "fp8e4m3")
        r = 1.0 / (1.0 + tp.exp(-z)) - y
        g = Xt @ tp.cast(r, "fp8e5m2") * (1.0 / n) + w * LAM
        w = w - g * lr
    return [int(v * 1048576.0) for v in w.tolist()]
