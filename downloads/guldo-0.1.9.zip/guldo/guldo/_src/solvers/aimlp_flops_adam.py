"""aimlp in the counted-operations API, TECHNIQUE: Adam (beta 0.9 and 0.999, bias-corrected) at learning rate 0.03 on the raw features, 400 steps."""
import math

import tensorops as tp

K = 3
H = 32
KAPPA = 10.0
STEPS = 400
LR = 0.03


def solve(seed, d, n, labels):
    sc = tp.tensor([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = tp.reshape(tp.stream(seed, 0, n * d), (n, d)) * sc
    Y = tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(n)])
    W1 = tp.stream(seed ^ 20817, 0, d * H, (d, H)) * math.sqrt(3.0 / d)
    W2 = tp.stream(seed ^ 21074, 0, H * K, (H, K)) * math.sqrt(3.0 / H)
    m1 = tp.zeros((d, H))
    s1 = tp.zeros((d, H))
    m2 = tp.zeros((H, K))
    s2 = tp.zeros((H, K))
    b1t = 1.0
    b2t = 1.0
    for step in range(STEPS):
        A = tp.relu(X @ W1)
        Z2 = A @ W2
        E = tp.exp(Z2 - tp.max(Z2, 1, True))
        G = (E / tp.sum(E, 1, True) - Y) * (1.0 / n)
        dA = tp.einsum("nk,hk->nh", G, W2)
        dW1 = tp.einsum("ni,nh->ih", X, dA * (A / (A + 1e-30)))
        dW2 = tp.einsum("nh,nk->hk", A, G)
        b1t = b1t * 0.9
        b2t = b2t * 0.999
        m1 = m1 * 0.9 + dW1 * 0.1
        s1 = s1 * 0.999 + dW1 * dW1 * 0.001
        m2 = m2 * 0.9 + dW2 * 0.1
        s2 = s2 * 0.999 + dW2 * dW2 * 0.001
        W1 = W1 - (m1 * (LR / (1.0 - b1t))) / (tp.sqrt(s1 * (1.0 / (1.0 - b2t))) + 1e-8)
        W2 = W2 - (m2 * (LR / (1.0 - b1t))) / (tp.sqrt(s2 * (1.0 / (1.0 - b2t))) + 1e-8)
    return [int(x * 1048576.0) for x in tp.reshape(W1, (d * H,)).tolist()] + [int(x * 1048576.0) for x in tp.reshape(W2, (H * K,)).tolist()]
