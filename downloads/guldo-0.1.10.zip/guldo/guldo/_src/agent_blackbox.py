"""Black-box vendor agents: the session core and the verifier for a trial the evaluator could only WATCH.

A white-box agent is driven by the harness (`agent_harness.run_trial`): the harness sees every message, so it can count the context the model re-reads and replay the control flow. A vendor's
agent is a program or a hosted product the evaluator does not control and cannot see inside. The one thing the evaluator CAN control is the tools: it hosts them (`agent_service.py`), the vendor's
agent calls them over HTTP (or MCP), and everything that crosses that line is recorded, hash-chained and signed by the service key. This module holds the part with no network in it:

  Session                      one trial's state machine: budget enforcement (tool calls, wall time), the chained transcript, the finished record
  interaction_tokens           the cost unit of a black-box trial (see below)
  make_blackbox_header         a ladder header with mode "blackbox-v1"
  check_blackbox_trial         re-check one stored trial from the record and the revealed seed: instance, prompt, chain, every tool result REPLAYED, caps, reason, answer re-verified, cost recomputed,
                               and (always) the service's signature over the outcome
  session_message / receipt_message   the exact bytes the service signs

WHAT IS RECORDED. Turn 0 is the task prompt (derived from the seed, so the verifier re-derives it). Then one `bb_call` turn per tool call (name, args, the content returned, service-clock milliseconds since
the session started), then exactly one `bb_end` turn: how it ended ("submit" with the answer, "over tool-call budget", "over wall-time budget", or "no submit"). The vendor's messages, model, prompts and
reasoning are NOT recorded: the evaluator never sees them.

COST UNIT. White-box cost is PROXY TOKENS of the context a model re-reads, which needs the messages. A black-box trial has none, so its cost is INTERACTION TOKENS: the proxy token count of every call's
name and arguments plus every tool result (and the submitted answer): how much the agent said to the tools and was told back. It is NOT the model's cost: an agent can think for a million tokens between two
calls and this will not show it. The two units are never compared with each other (agent_compare refuses a cost verdict across units); success CAN be compared across modes, with a warning when the arms were
held to different budgets (a black-box arm is held only to max_tool_calls and max_wall_s: nothing else can be enforced).

WHAT VERIFICATION PROVES, and what it does not.
  From the seed and the record alone: every tool result is what the tool really returns for that call; the submitted answer is (or is not) correct under the exact verifier; the counts, caps and reason
  follow from the transcript; no turn was edited unnoticed (hash chain); the outcome was signed by the service key in the header.
  NOT from the seed alone: that the service did not INSERT or DROP calls consistent with the tools (a made-up extra call replays correctly). Two things close that: the service's signature (it vouches for
  the transcript; its key is yours to pin) and the VENDOR's own receipts (every response carried a signature over the chain hash so far: the vendor can check that the published transcript contains exactly
  what it saw). Nothing here proves how the agent worked: whether a human, another service or a model produced the calls is invisible, and so is every cost the agent did not spend at the tools.
"""
import hashlib
import hmac
import time

import agent_core
from agent_core import canon, count_tokens, sha256_hex

MODE = "blackbox-v1"
COST_UNIT = "interaction-tokens"
PROTOCOL = "guldo-tsp-v1"
ENFORCED = ("max_tool_calls", "max_wall_s")
MAX_TOOL_OUTPUT = 20000
MAX_ARGS_BYTES = 100000
MAX_NAME = 100
ENDS = ("submit", "over tool-call budget", "over wall-time budget", "no submit")
REC_KEYS = {"instance", "domain", "size", "idx", "trial", "solved", "reason", "answer", "turns", "head", "tokens", "tool_calls", "n_turns", "wall_s", "provider_tokens", "bb"}
BB_KEYS = {"sid", "claimed_usage", "sig"}
TURN_KEYS = {"user": {"role", "content", "prev", "h"}, "bb_call": {"role", "seq", "name", "args", "content", "t_ms", "prev", "h"}, "bb_end": {"role", "how", "t_ms", "prev", "h"}}
UNKNOWN_TOOL = "error: tool %r is not available"
SUBMIT_NEEDS_ANSWER = "error: submit needs an answer"


class BlackboxError(Exception):
    pass


def is_blackbox(header):
    return isinstance(header, dict) and header.get("mode") == MODE


# ---- what is signed ---------------------------------------------------------------------------------------------------------------------------------

def receipt_message(sid, seq, turn_hash):
    """What the service signs after EVERY call and hands to the vendor: the session, the call's position and the chain hash through that call (which commits to every earlier turn)."""
    return canon({"v": "guldo-tsp-receipt-v1", "sid": sid, "seq": seq, "h": turn_hash}).encode("utf-8")


def session_message(plan_hash, label, rec):
    """What the service signs when a session ends: the outcome and the head of the whole chain. Bound to the plan and the arm so a signature cannot be lifted into another round or onto another arm."""
    return canon({"v": "guldo-tsp-session-v1", "plan_hash": plan_hash, "arm": label, "sid": rec["bb"]["sid"], "instance": rec["instance"], "trial": rec["trial"], "head": rec["head"],
                  "solved": rec["solved"], "reason": rec["reason"], "tokens": rec["tokens"], "tool_calls": rec["tool_calls"], "wall_s": rec["wall_s"],
                  "answer_sha256": sha256_hex(canon(rec["answer"]))}).encode("utf-8")


def tool_hash(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def token_ok(token, expected_hash):
    return isinstance(token, str) and bool(expected_hash) and hmac.compare_digest(tool_hash(token), expected_hash)


# ---- cost -------------------------------------------------------------------------------------------------------------------------------------------

def interaction_tokens(turns):
    """Proxy tokens of everything exchanged with the tools: each call's name and arguments, each result, and the submitted answer. See the module docstring for what this is NOT."""
    total = 0
    for t in turns:
        role = t.get("role")
        if role == "bb_call":
            total += count_tokens(t["name"] + canon(t["args"])) + count_tokens(t["content"])
        elif role == "bb_end" and t.get("how") == "submit":
            total += count_tokens(canon(t.get("answer")))
    return total


def _clip(content):
    return content[:MAX_TOOL_OUTPUT] + "...(truncated)" if len(content) > MAX_TOOL_OUTPUT else content


# ---- one session ------------------------------------------------------------------------------------------------------------------------------------

class Session(object):
    """One trial. Pure state: no network, no files. `now` is always passed in (seconds on ONE clock), so a test or a restart can drive it deterministically."""

    def __init__(self, mod, instance, budget, trial, allow_tools, sid, start, tools=None):
        import agent_harness
        self.mod, self.instance, self.trial, self.sid, self.start = mod, instance, int(trial), sid, float(start)
        self.max_calls, self.max_wall = int(budget["max_tool_calls"]), float(budget["max_wall_s"])
        self.deadline = self.start + self.max_wall
        self.tools = tools if tools is not None else agent_harness.effective_tools(mod, instance, allow_tools)
        self.allowed = set(s["name"] for s in self.tools)
        self.domain_tools = self.allowed - {"submit"}
        self.env = mod.make_env(instance)
        self.prompt = mod.prompt(instance["public"])
        self.turns = [{"role": "user", "content": self.prompt}]
        self.head = agent_core.CHAIN_START
        self.turns, self.head = agent_core.chain_turns(self.turns)
        self.n_calls = 0
        self.ended = None                      # None while open, else the `how` of the bb_end turn
        self.answer = None
        self.claimed = None                    # what the vendor SAYS it used (never verified)
        self.record = None

    # -- the transcript ------------------------------------------------------------------------------------------------------------------------------

    def _append(self, turn):
        t = dict(turn, prev=self.head)
        t["h"] = sha256_hex(self.head + canon({k: v for k, v in t.items() if k != "h"}))
        self.turns.append(t)
        self.head = t["h"]
        return t

    def _ms(self, now):
        return max(0, int(round((now - self.start) * 1000)))

    @property
    def is_open(self):
        return self.ended is None

    # -- calls ---------------------------------------------------------------------------------------------------------------------------------------

    def call(self, name, args, now):
        """Serve one tool call. Returns ("result", content, turn) for a served call, ("submitted", None, turn) for a submit that ended the trial, ("ended", reason, None) when the trial is over
        (this call was refused and is NOT recorded). Never raises for vendor misbehaviour."""
        if not self.is_open:
            return "ended", self.record["reason"] if self.record else str(self.ended), None
        if now > self.deadline:
            self.end("over wall-time budget", now)
            return "ended", "over wall-time budget", None
        if not isinstance(name, str) or not name or len(name) > MAX_NAME or not isinstance(args, dict):
            raise BlackboxError("a call is {name: string, args: object}")
        try:
            size = len(canon(args))
        except (TypeError, ValueError):
            raise BlackboxError("the arguments are not JSON data")
        if size > MAX_ARGS_BYTES:
            raise BlackboxError("the arguments are too large")
        if name == "submit" and "answer" in args:
            try:
                canon(args["answer"])
            except (TypeError, ValueError):
                raise BlackboxError("the answer is not JSON data")
            self.answer, self.claimed = args["answer"], self._claimed(args)
            self.end("submit", now)
            return "submitted", None, self.turns[-1]
        if self.n_calls >= self.max_calls:
            self.end("over tool-call budget", now)
            return "ended", "over tool-call budget", None
        self.n_calls += 1
        if name == "submit":
            content = SUBMIT_NEEDS_ANSWER
        elif name not in self.allowed:
            content = UNKNOWN_TOOL % name
        else:
            try:
                content = str(self.env.call(name, args))
            except Exception as e:
                content = "error: tool failed (%s)" % type(e).__name__
        content = _clip(content)
        turn = self._append({"role": "bb_call", "seq": self.n_calls, "name": name, "args": args, "content": content, "t_ms": self._ms(now)})
        return "result", content, turn

    @staticmethod
    def _claimed(args):
        u = args.get("usage")
        if isinstance(u, dict):
            out = {k: v for k, v in u.items() if isinstance(k, str) and len(k) <= 40 and isinstance(v, (int, float)) and not isinstance(v, bool)}
            return dict(list(out.items())[:8]) or None
        return None

    def end(self, how, now):
        """End the trial (idempotent). `how` is one of ENDS."""
        if not self.is_open:
            return self.record
        if how not in ENDS:
            raise BlackboxError("unknown ending %r" % how)
        end = {"role": "bb_end", "how": how, "t_ms": self._ms(now)}
        if how == "submit":
            end["answer"] = self.answer
            end["claimed"] = self.claimed                # chained and signed: the service attests that the vendor SAID this, not that it is true
        self._append(end)
        self.ended = how
        return self._finish(now)

    def _finish(self, now):
        how = self.ended
        calls_done = [{"name": t["name"], "args": t["args"]} for t in self.turns if t["role"] == "bb_call" and t["name"] in self.domain_tools]
        solved, reason = False, how
        if how == "submit":
            try:
                solved, reason = self.mod.verify(self.instance, self.answer, calls_done)
            except (TypeError, ValueError):
                solved, reason = False, "answer is not JSON data"
        wall = round(self.max_wall, 3) if how == "over wall-time budget" else round(max(0.0, now - self.start), 3)
        self.record = {"instance": self.instance["id"], "domain": self.mod.NAME, "size": self.instance["size"], "idx": int(self.instance["id"].rsplit("/", 1)[1]), "trial": self.trial,
                       "solved": bool(solved), "reason": reason, "answer": self.answer if how == "submit" else None, "turns": list(self.turns), "head": self.head,
                       "tokens": interaction_tokens(self.turns), "tool_calls": self.n_calls, "n_turns": len(self.turns) - 1, "wall_s": wall, "provider_tokens": None,
                       "bb": {"sid": self.sid, "claimed_usage": self.claimed}}
        return self.record


# ---- header -----------------------------------------------------------------------------------------------------------------------------------------

def make_blackbox_header(plan, label, spec, allow_tools, pubkey_hex, eid):
    """A ladder header for a black-box arm. Same keys as a white-box header (so every consumer keeps working) plus the mode, the cost unit, which budget keys were enforced, and the service key."""
    import agent_eval
    budget = plan["budget"]
    return {"format": agent_core.FORMAT, "domain": plan["domain"], "version": plan["version"], "plan_hash": agent_eval.plan_hash(plan), "commit": plan["commit"], "sizes": plan["sizes"],
            "n_per_size": plan["n_per_size"], "trials": plan["trials"], "budget": budget, "counter": plan["counter"], "practice": plan["practice"], "source_hashes": plan["source_hashes"],
            "agent": {"label": label, "spec": spec, "kind": "blackbox"}, "allow_tools": sorted(allow_tools) if allow_tools is not None else None, "system": None,
            "python_major_minor": agent_eval.PY, "mode": MODE, "cost_unit": COST_UNIT, "enforced_budget": {k: budget[k] for k in ENFORCED},
            "service": {"protocol": PROTOCOL, "pubkey": pubkey_hex, "arm": eid}}


# ---- the verifier -----------------------------------------------------------------------------------------------------------------------------------

def check_blackbox_trial(rec, mod, master, header, replay_tools=True):
    """Re-check one stored black-box trial. Returns a list of problems (empty = consistent and correct as recorded, and signed by the key in the header). NEVER raises on a damaged or hostile
    record: whatever it cannot make sense of is a problem."""
    try:
        return _check_blackbox_trial(rec, mod, master, header, replay_tools)
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, OverflowError, RecursionError) as e:
        return ["malformed record (%s)" % type(e).__name__]


def _check_blackbox_trial(rec, mod, master, header, replay_tools):
    import agent_harness
    import agent_sig
    probs = []
    try:
        size, idx = int(rec["size"]), int(rec["idx"])
        instance = agent_core.make_instance(mod, master, size, idx)
    except Exception as e:
        return ["cannot re-derive the instance: %s" % type(e).__name__]
    if rec.get("instance") != instance["id"] or rec.get("domain") != mod.NAME:
        probs.append("instance id does not match the seed-derived instance")
    for key, typ in (("reason", str), ("solved", bool), ("tokens", int), ("tool_calls", int), ("n_turns", int), ("trial", int)):
        if not isinstance(rec.get(key), typ) or (typ is int and isinstance(rec.get(key), bool)):
            probs.append("field %r is missing or not a %s" % (key, typ.__name__))
    if not isinstance(rec.get("wall_s"), (int, float)) or isinstance(rec.get("wall_s"), bool):
        probs.append("field 'wall_s' is missing or not a number")
    # nothing may ride along unaccounted for: a field the checks do not read is a field an editor can use
    if set(rec) - REC_KEYS or set(rec.get("bb") or {}) - BB_KEYS:
        probs.append("the record has fields a black-box record does not have: %s" % ", ".join(sorted((set(rec) - REC_KEYS) | set((rec.get("bb") or {}).keys()) - BB_KEYS)))
    if rec.get("provider_tokens") is not None:
        probs.append("a black-box trial has no provider token count")
    turns = rec.get("turns")
    if not isinstance(turns, list) or len(turns) < 2:
        return probs + ["no transcript"]
    ok, head = agent_core.check_chain(turns)
    if not ok:
        return probs + ["hash chain broken"]
    if head != rec.get("head"):
        probs.append("chain head differs from the record's head")
    if turns[0].get("role") != "user" or turns[0].get("content") != mod.prompt(instance["public"]):
        probs.append("first turn is not the task prompt derived from the seed")
    budget = header.get("enforced_budget") or {}
    max_calls, max_wall = budget.get("max_tool_calls"), budget.get("max_wall_s")
    if not (isinstance(max_calls, int) and isinstance(max_wall, (int, float))) or header.get("budget", {}).get("max_tool_calls") != max_calls or header.get("budget", {}).get("max_wall_s") != max_wall:
        return probs + ["the header's enforced budget is missing or is not the plan's"]
    tools = agent_harness.effective_tools(mod, instance, header.get("allow_tools"))
    allowed = set(s["name"] for s in tools)
    domain_tools = allowed - {"submit"}
    body, end = turns[1:-1], turns[-1]
    for n, t in enumerate(turns):
        keys = TURN_KEYS.get(t.get("role")) if isinstance(t.get("role"), str) else None
        if keys is None:
            return probs + ["trajectory: turn %d has an unknown role" % n]
        keys = set(keys) | ({"answer", "claimed"} if t.get("role") == "bb_end" and t.get("how") == "submit" else set())      # only a submit ending carries an answer and a claim
        if set(t) != keys:
            return probs + ["trajectory: turn %d has fields a %s turn does not have, or lacks required ones" % (n, t.get("role"))]
    if end.get("role") != "bb_end" or end.get("how") not in ENDS:
        return probs + ["trajectory: the transcript does not end with a recognised ending"]
    if any(t.get("role") != "bb_call" for t in body):
        return probs + ["trajectory: a turn between the prompt and the ending is not a call"]
    if len(body) > max_calls:
        probs.append("trajectory: %d calls but the cap is %d" % (len(body), max_calls))
    if end["how"] == "over tool-call budget" and len(body) != max_calls:
        probs.append("trajectory: ended over the tool-call budget with %d of %d calls used" % (len(body), max_calls))
    prev_ms, env = 0, (mod.make_env(instance) if replay_tools else None)
    for n, t in enumerate(body, 1):
        if t.get("seq") != n:
            probs.append("trajectory: call %d is numbered %r" % (n, t.get("seq")))
        if not isinstance(t.get("name"), str) or not isinstance(t.get("args"), dict) or not isinstance(t.get("content"), str):
            probs.append("trajectory: call %d is malformed" % n)
            continue
        ms = t.get("t_ms")
        if not isinstance(ms, int) or isinstance(ms, bool) or ms < prev_ms:
            probs.append("trajectory: call %d has a clock that runs backwards" % n)
        else:
            prev_ms = ms
            if ms > max_wall * 1000:
                probs.append("trajectory: call %d was served after the wall-time deadline" % n)
        name = t["name"]
        if name == "submit":
            want = SUBMIT_NEEDS_ANSWER
            if "answer" in t["args"]:
                probs.append("trajectory: call %d is a submit WITH an answer recorded as a plain call" % n)
        elif name not in allowed:
            want = UNKNOWN_TOOL % name
        elif replay_tools:
            try:
                want = _clip(str(env.call(name, t["args"])))
            except Exception as e:
                want = "error: tool failed (%s)" % type(e).__name__
        else:
            want = t["content"]
        if t["content"] != want:
            probs.append("trajectory: the result of call %d differs when the call is replayed" % n)
    calls = [{"name": t["name"], "args": t["args"]} for t in body if isinstance(t.get("name"), str) and t["name"] in domain_tools and isinstance(t.get("args"), dict)]
    if rec.get("tool_calls") != len(body) or rec.get("n_turns") != len(turns) - 1:
        probs.append("recorded tool-call or turn count does not match the transcript")
    if rec.get("tokens") != interaction_tokens(turns):
        probs.append("recorded cost does not match the transcript")
    if isinstance(end.get("t_ms"), int) and isinstance(rec.get("wall_s"), (int, float)) and end["how"] != "over wall-time budget":
        if abs(end["t_ms"] / 1000.0 - rec["wall_s"]) > 0.002:
            probs.append("the recorded wall time is not the transcript's")
    if (rec.get("bb") or {}).get("claimed_usage") != (end.get("claimed") if end["how"] == "submit" else None):
        probs.append("the recorded vendor-claimed usage is not the one in the transcript")
    if end["how"] == "submit":
        answer = end.get("answer")
        if rec.get("answer") != answer:
            probs.append("the recorded answer differs from the submitted one")
        else:
            try:
                canon(answer)
                good, why = mod.verify(instance, answer, calls)
            except (TypeError, ValueError):
                good, why = False, "answer is not JSON data"
            if bool(rec.get("solved")) != bool(good):
                probs.append("recorded %s but the verifier says %s (%s)" % ("solved" if rec.get("solved") else "unsolved", "solved" if good else "unsolved", why))
            elif rec.get("reason") != why:
                probs.append("the recorded reason %r is not the verifier's %r" % (rec.get("reason"), why))
    else:
        if rec.get("answer") is not None or rec.get("solved"):
            probs.append("recorded an answer or a success for a trajectory that never submitted one")
        if rec.get("reason") != end["how"]:
            probs.append("the trajectory ends with %r but the recorded reason is %r" % (end["how"], rec.get("reason")))
        if end["how"] == "over wall-time budget" and rec.get("wall_s") != round(float(max_wall), 3):
            probs.append("an expired session must record the full wall-time budget")
    # the service's signature: ALWAYS checked against the key the header names (anyone can sign with their own key, so a reader pins that key: agent_verifier / agent_cert do)
    bb, svc = rec.get("bb"), header.get("service") or {}
    if not isinstance(bb, dict) or not isinstance(bb.get("sid"), str) or not isinstance(bb.get("sig"), str):
        probs.append("the trial carries no service signature")
    else:
        try:
            good = agent_sig.verify(bytes.fromhex(svc.get("pubkey", "")), session_message(header.get("plan_hash"), (header.get("agent") or {}).get("label"), rec), bytes.fromhex(bb["sig"]))
        except (ValueError, TypeError, KeyError):
            good = False
        if not good:
            probs.append("the service's signature over this trial is not valid under the header's key")
    return probs


def check_receipts(records, receipts, pubkey_hex):
    """The VENDOR's check: every receipt the vendor kept (a list of {sid, seq, h, sig}) is genuine (signed by the service key) AND appears in the published transcript at that position, and every session
    the vendor holds receipts for is in the ladder. Returns a list of problems. This is what lets a vendor detect a transcript that was edited, shortened or invented after the fact."""
    import agent_sig
    probs = []
    by_sid = {r.get("bb", {}).get("sid"): r for r in records if isinstance(r, dict) and isinstance(r.get("bb"), dict)}
    chain_ok = {}
    for n, rc in enumerate(receipts):
        try:
            sid, seq, h, sig = rc["sid"], rc["seq"], rc["h"], rc["sig"]
            if not agent_sig.verify(bytes.fromhex(pubkey_hex), receipt_message(sid, seq, h), bytes.fromhex(sig)):
                probs.append("receipt %d is not signed by the service key" % n)
                continue
        except (KeyError, TypeError, ValueError):
            probs.append("receipt %d is malformed" % n)
            continue
        rec = by_sid.get(sid)
        if rec is None:
            probs.append("receipt %d names session %s, which is not in the published ladder" % (n, str(sid)[:12]))
            continue
        if sid not in chain_ok:                                  # the published transcript must itself be a valid chain, or its stored hashes mean nothing
            chain_ok[sid] = isinstance(rec.get("turns"), list) and agent_core.check_chain(rec["turns"])[0]
            if not chain_ok[sid]:
                probs.append("the published transcript of session %s is not a valid hash chain" % str(sid)[:12])
        if not chain_ok[sid]:
            continue
        # `seq` is the turn's position: 0 the task prompt, 1..n the calls, n+1 the ending
        expect = rec["turns"][seq]["h"] if isinstance(seq, int) and not isinstance(seq, bool) and 0 <= seq < len(rec["turns"]) else None
        if expect != h:
            probs.append("receipt %d (session %s call %s) does not match the published transcript" % (n, str(sid)[:12], seq))
    return probs
