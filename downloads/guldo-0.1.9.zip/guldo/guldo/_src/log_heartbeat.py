"""The hosted heartbeat of the certificate log: what a scheduled function on the website's hosting does each day. Standard library plus the log's own code. Run the tests: python3 -m unittest test_log_heartbeat -v

One run: pull the log's core files from the store, ask the Internet Archive to keep the head that is LIVE now (before signing, so there is no CDN to wait for), sign a fresh head, timestamp it in
Bitcoin and collect any finished proofs, audit the result, push only what changed, and write `status.json` for the Log page. Everything about the log's integrity fails closed: a log that does not
pass its own audit after the run is not pushed. The Archive and the calendars are best effort and become notes in the summary.

The signing key arrives as text (an encrypted environment variable on the host) and is written to a private temporary file that is never one of the files pushed. `check_auth` is the only door:
the host's scheduler sends `Authorization: Bearer <CRON_SECRET>` and nothing else may start a run."""
import hmac
import json
import os
import shutil
import tempfile
import time

import attest as A
import log_blob as B
import log_site
import otsanchor as O
import translog as T
import webarchive as W

PROOFS_LIMIT = 50           # per-entry proof files change with every head; above this many entries they are not published (`translog.py prove` computes any of them from entries.jsonl)
ARCHIVE_URL = "https://guldo.org/log/checkpoint.json"
STATUS_FORMAT = "guldo-log-status-v1"


class HeartbeatError(Exception):
    pass


def check_auth(header, secret):
    """True only for `Bearer <secret>` with a non-empty secret, compared in constant time."""
    if not secret or not isinstance(header, str) or not header.startswith("Bearer "):
        return False
    return hmac.compare_digest(header[7:].strip().encode(), secret.encode())


def respond(auth_header, env, run=None):
    """The whole of what the HTTP handler does: -> (status code, JSON-able dict). Unauthenticated callers learn nothing; an unexpected error is named by type only; and whatever the message,
    neither the signing key nor the store token can appear in it."""
    run = run or heartbeat
    if not check_auth(auth_header, env.get("CRON_SECRET") or ""):
        return 401, {"ok": False, "error": "unauthorized"}
    token, key = env.get("BLOB_READ_WRITE_TOKEN") or "", env.get("GULDO_LOG_KEY") or ""
    if not token or not key:
        return 500, {"ok": False, "error": "not configured: the store token and the signing key must both be set"}

    def scrub(s):
        for secret in (token, key.strip(), env.get("CRON_SECRET") or ""):
            if secret and len(secret) >= 8:
                s = s.replace(secret, "<redacted>")
        return s
    try:
        return 200, run(token, key)
    except HeartbeatError as e:
        return 500, {"ok": False, "error": scrub(str(e))[:400]}
    except Exception as e:  # noqa: BLE001 a scheduled function must answer, and must not echo what it was given
        return 500, {"ok": False, "error": f"unexpected {type(e).__name__}"}


def build_status(path, run=None, now=time.time):
    """The facts the Log page shows live, derived from the directory (never from anything it was told). -> dict."""
    d = T.parse_log(T.dir_reader(path))
    if d.problems or d.meta is None or not d.checkpoints:
        raise HeartbeatError("the log does not parse: " + ("; ".join(d.problems[:2]) or "no head"))
    head = d.checkpoints[-1]["body"]
    anchors, archives = log_site._anchors(path, d)
    return {"format": STATUS_FORMAT, "generated": T.now_iso(now()), "origin": d.origin, "pubkey": d.meta["pubkey"], "entries": d.size,
            "head": {"size": head["size"], "root": head["root"], "time": head["time"]}, "anchors": anchors, "archives": archives, "run": run or {}}


def _anchor_names(core_dir):
    """The proof files named by anchors.jsonl, validated against the one shape this system writes."""
    p = os.path.join(core_dir, "anchors.jsonl")
    out = []
    if os.path.isfile(p):
        for line in open(p, "rb").read().split(b"\n"):
            try:
                rec = json.loads(line.decode("utf-8")) if line.strip() else None
            except (ValueError, UnicodeDecodeError):
                rec = None
            if isinstance(rec, dict) and isinstance(rec.get("ref"), str) and T.ANCHOR_REF.fullmatch(rec["ref"]) and rec["ref"] not in out:
                out.append(rec["ref"])
    return out


def heartbeat(token, key_text, blob_http=None, calendar_http=None, archive_http=None, now=time.time, work=None, archive_url=ARCHIVE_URL, archive=True, anchors=True):
    """One run. -> a summary dict. Raises HeartbeatError (nothing was pushed) on any failure of the log's own integrity."""
    store = B.Store(token, http=blob_http or B.default_http, now=now)
    own = work is None
    work = work or tempfile.mkdtemp(prefix="guldo-heartbeat-")
    notes = []
    summary = {"started": T.now_iso(now()), "notes": notes}
    old_limit = T.STATIC_PROOF_LIMIT
    try:
        T.STATIC_PROOF_LIMIT = PROOFS_LIMIT
        logdir = os.path.join(work, "log")
        keyfile = os.path.join(work, "operator.key")           # outside logdir: local_files() only ever reads the allowed names under logdir
        fd = os.open(keyfile, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(key_text.strip() + "\n")
        try:
            B.pull(logdir, store, names=list(B.CORE))
            B.pull(logdir, store, names=_anchor_names(logdir))
        except B.BlobError as e:
            raise HeartbeatError(f"could not read the log from the store: {e}")
        if not os.path.isfile(os.path.join(logdir, "log.json")):
            raise HeartbeatError("the store holds no log (push one first)")
        try:
            log = T.Log(logdir)
            before = log.data()
        except (T.LogError, ValueError, OSError) as e:
            raise HeartbeatError(f"the log in the store is damaged or unreadable: {str(e)[:200]}")
        if before.problems or before.meta is None:
            raise HeartbeatError("the log in the store does not parse: " + ("; ".join(before.problems[:2]) or "log.json is unreadable"))
        pin = before.meta["pubkey"]
        if archive and archive_url and before.checkpoints:
            try:
                r = T.archive_save(log, archive_url, archive_http, sleep=lambda s: None, polls=2, interval=0)
                summary["archive"] = {"state": r["state"], "detail": str(r.get("detail", ""))[:200]}
            except (W.ArchiveError, OSError, ValueError) as e:
                summary["archive"] = {"state": "error", "detail": str(e)[:200]}
        try:
            cp = log.sign(keyfile)
        except (T.LogError, ValueError, OSError, A.NeedsCryptography) as e:      # a wrong or malformed key, a missing `cryptography` package, a full disk
            raise HeartbeatError(f"could not sign: {str(e)[:200]}")
        summary["signed"] = {"size": cp["body"]["size"], "time": cp["body"]["time"]}
        if anchors:
            try:
                s = T.ots_stamp(log, calendar_http)
                summary["stamp"] = s["state"]
            except (O.OtsError, T.LogError) as e:
                summary["stamp"] = "not stamped: " + str(e)[:160]
            try:
                summary["upgrade"] = [{"ref": u["ref"], "state": u["state"]} for u in T.ots_upgrade(log, calendar_http)]
            except (O.OtsError, T.LogError, OSError) as e:
                summary["upgrade"] = "error: " + str(e)[:160]
        au = T.audit(T.dir_reader(logdir), pin)
        if not au["ok"]:
            bad = [c["detail"] for c in au["checks"] if c["status"] == "fail"][:3]
            raise HeartbeatError("the log fails its own audit after the run; nothing was pushed: " + "; ".join(bad))
        try:
            pushed = B.push(logdir, store)
            summary["pushed"] = pushed["uploaded"]
            status = build_status(logdir, {k: summary.get(k) for k in ("archive", "stamp", "upgrade", "signed")}, now)
            store.put("status.json", (json.dumps(status, indent=1, sort_keys=True) + "\n").encode())
        except B.BlobError as e:
            raise HeartbeatError(f"could not write the log to the store: {e}")
        summary["finished"] = T.now_iso(now())
        summary["ok"] = True
        return summary
    finally:
        T.STATIC_PROOF_LIMIT = old_limit
        if own:
            shutil.rmtree(work, ignore_errors=True)
