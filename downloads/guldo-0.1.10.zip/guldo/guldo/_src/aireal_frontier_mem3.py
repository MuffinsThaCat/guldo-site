"""The frontier of the aireal domain for SPARSE and LOW-PRECISION networks (the version-3 byte counter): how closely each compressed network follows the dense one, and what it saves in operations and bytes.

  python3 aireal_frontier_mem3.py [--n 12] [--out results/aireal_frontier_mem3.json]

For every solver of solvers/aireal_mem3_*.py (offline-pruned unstructured 50/75/90%, the 2:4 pattern, dense bf16 and dense fp8 inference), at every size, over a fixed set of instances: agreement with the dense network (the
judge's bar is 98%), accuracy on the REAL digit labels (the dense network's own is the reference), operations and BYTES MOVED relative to the dense network run under the same counter, and how many instances cleared the bar.
Deterministic: a fixed seed, exact counts. Fixed costs that every solver pays (building the query tensor from the embedded image pool, about 75 thousand interpreter steps) are in every number, which is why the savings
at these tiny sizes are far smaller than the nonzeros alone would suggest."""
import argparse
import json
import math
import os
import statistics
import sys
import tempfile

import numpy as np

import runwatch
import tflops
import tflops_mem3

HERE = os.path.dirname(os.path.abspath(__file__))
NAMES = [("dense", "aireal_flops_ref.py"), ("sp50", "aireal_mem3_sp50.py"), ("sp75", "aireal_mem3_sp75.py"), ("sp90", "aireal_mem3_sp90.py"), ("s24", "aireal_mem3_s24.py"),
         ("bf16", "aireal_mem3_bf16.py"), ("fp8", "aireal_mem3_fp8.py")]
SEED = b"aireal-frontier-seed"


def run(solver, inst):
    """-> (answer or None, steps, flops, bytes): the version-3 counting child run directly, so the answer is kept."""
    payload = json.dumps({"args": inst["args"], "limit": int(800 * tflops.UNIT_OPS)}).encode()
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "1", "PATH": os.environ.get("PATH", "")}
    with tempfile.TemporaryDirectory() as empty:
        out, err, killed = runwatch.run_watched([sys.executable, "-B", tflops_mem3.RUNNER, os.path.abspath(solver)], payload, env, empty, 600, tflops.MAX_RSS_MB)
    r = json.loads([ln for ln in out.decode().splitlines() if ln.strip()][-1])
    return r.get("ans"), r["steps"], r["flops"], r["bytes"]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--n", type=int, default=12)
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    mod, derive, verify, d = tflops.load_family("aireal")
    rows = {}
    for size in (16, 32, 48):
        for i in range(a.n):
            inst = derive(SEED, size, i)
            planted, truth = np.array(inst["planted"]), np.array(inst["truth"])
            base_ops = base_bytes = None
            for label, fname in NAMES:
                ans, steps, flops, nbytes = run(os.path.join(HERE, "solvers", fname), inst)
                if label == "dense":
                    base_ops, base_bytes = steps + flops, nbytes
                ans = np.array(ans)
                rows.setdefault((label, size), []).append({"agree": float(np.mean(ans == planted)), "acc": float(np.mean(ans == truth)), "net_acc": float(np.mean(planted == truth)),
                                                          "ops_bits": math.log2(base_ops / (steps + flops)), "flops_ratio": None, "bytes_bits": math.log2(base_bytes / nbytes),
                                                          "passed": bool(verify(inst, [int(v) for v in ans]))})
    out = {"format": "svp-aireal-frontier-mem3-v1", "seed": SEED.decode(), "n": a.n, "agreement_bar": mod.AGREE, "queries": mod.Q, "results": {}}
    print(f"aireal sparse/low-precision frontier: {a.n} instances per size, 98% agreement bar")
    print("solver  size  cleared  agree(mean/worst)  acc on true labels (net)  operations vs dense (bits)  bytes vs dense (bits)")
    for (label, size), rs in rows.items():
        s = {"cleared": sum(r["passed"] for r in rs), "n": len(rs), "agree_mean": statistics.fmean(r["agree"] for r in rs), "agree_worst": min(r["agree"] for r in rs),
             "acc_mean": statistics.fmean(r["acc"] for r in rs), "net_acc_mean": statistics.fmean(r["net_acc"] for r in rs),
             "median_ops_bits_vs_dense": statistics.median(r["ops_bits"] for r in rs), "median_bytes_bits_vs_dense": statistics.median(r["bytes_bits"] for r in rs)}
        out["results"][f"{label}:{size}"] = s
        print(f"{label:7s} {size:4d}  {s['cleared']:2d}/{s['n']:<2d}   {s['agree_mean']:.3f}/{s['agree_worst']:.3f}      {s['acc_mean']:.3f} ({s['net_acc_mean']:.3f})        "
              f"{s['median_ops_bits_vs_dense']:+.2f}                       {s['median_bytes_bits_vs_dense']:+.2f}")
    if a.out:
        if os.path.exists(a.out):
            sys.exit(f"{a.out} exists")
        with open(a.out, "w") as f:
            json.dump(out, f, indent=1, sort_keys=True)
        print("wrote", a.out)


if __name__ == "__main__":
    main()
