"""dlog, baby-step scan with a 4-entry table: one multiplication and one lookup cover 4 candidate exponents (a true speedup of about 1.5-2 bits)."""


def solve(p, g, h):
    m = 4
    table = {}
    cur = 1
    for j in range(m):
        table.setdefault(cur, j)
        cur = cur * g % p
    step = pow(pow(g, m, p), -1, p)
    cur = h % p
    for i in range((p - 1 + m - 1) // m):
        j = table.get(cur)
        if j is not None and i * m + j < p - 1:
            return i * m + j
        cur = cur * step % p
    return None
