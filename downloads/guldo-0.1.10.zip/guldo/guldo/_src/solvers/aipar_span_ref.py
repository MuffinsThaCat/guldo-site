"""aipar in the work-and-span counted API, REFERENCE: a loop over t, one multiply-add on the C channels per step. T steps in a row: depth proportional to T."""
import tensorops as tp


def solve(seed, T, C):
    A = tp.reshape(tp.stream(seed, 0, T * C), (T, C)) * 0.049 + 0.95
    B = tp.reshape(tp.stream(seed, T * C, T * C), (T, C))
    h = tp.zeros((C,))
    rows = []
    for t in range(T):
        h = A[t] * h + B[t]
        rows.append(h)
    return list(map(int, (tp.concat(rows, 0) * 1073741824.0).tolist()))
