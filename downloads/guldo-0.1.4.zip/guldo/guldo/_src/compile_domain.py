"""The challenge compiler: a problem declaration in, a verified, calibrated challenge system out (see COMPILER.md).

  compile_domain.py init NAME                 scaffold domains/NAME/{decl.py,reference.py} (new files only; never overwrites)
  compile_domain.py compile domains/NAME      run every pass; writes compiled.json and out/ (the four emit targets)
  compile_domain.py check domains/NAME        parse + validate only (fast; no timing): CI-friendly, exit 1 on any FAIL
  compile_domain.py selftest NAME             re-run the end-to-end controls through judge.py (zero effect, failure, known effect)
  compile_domain.py emit NAME [--target T]    regenerate out/ from compiled.json
  compile_domain.py status                    every declaration under domains/: fresh, compiled, self-tested, or why not

Passes:  1 parse -> 2 validate -> 3 profile -> 4 optimize -> 5 power -> 6 emit -> 7 self-test
  parse      the declaration has the right shape; the reference solver is lint-clean and imports nothing of the judge's
  validate   derive() is deterministic and process-pure; the planted witness verifies and is not in the arguments; verify() rejects
             junk, the arguments themselves and another instance's witness; the reference solves small instances correctly
  profile    measure the reference over the size range -> a CALIBRATION PROFILE (cost vs size, per-instance spread, timeout rate)
  optimize   choose the size ladder, the CPU cap and the instances per size from the profile
  power      the real estimator on synthetic ladders drawn from the profile: the smallest speedup this challenge can certify
  emit       local kit, server plan, CI script, certificate instructions
  self-test  the compiled system, run through the real pipeline: reference-vs-reference must earn ~0, a solver that never answers must
             earn 0, a known 1-bit speedup (the same ladder, costs scaled) must be recovered

The profile is public-seed data about the REFERENCE only: it contains no competition instance. Nothing here weakens the commit-reveal
protocol; a compiled domain runs under exactly the rules of the built-in families.
"""
import argparse
import ast
import contextlib
import hashlib
import json
import math
import os
import random
import secrets
import shutil
import statistics
import subprocess
import sys
import tempfile
import time

import declared
import families
import harness
import submit_check

HERE = os.path.dirname(os.path.abspath(__file__))
BUILTIN = {"gm", "mlwe", "factor"}
PROFILE_SEED = b"svp-compiler-profile-seed-v1"   # public on purpose: profiling measures the reference, never a competition instance
CAPS = (30, 60, 120, 240)                        # CPU-second caps the optimizer may choose from (the built-in families use 60 and 120)
NS = (12, 24, 48, 96, 192)                       # instances per size it may choose from (rounds.MAX_N is 200)
MAX_SIZES, MIN_SIZES = 6, 3                      # ladder length bounds
LOW_COST = 2.0                                   # s: smallest predicted median cost of a ladder size (4x the estimator's 0.5 s floor)
Z_TAIL = 1.28                                    # the top size's median sits Z_TAIL sigma below the cap: about 10% of its instances time out
THRESHOLD = 1.0                                  # bits: "certified" in the power analysis means a credit of at least this
SELFTEST_EFFECT = 1.0                            # bits of the known-effect control
SEEDS = 3                                        # judge.MIN_SEEDS
MAX_JUNK_RATE = 0.0

JUNK = [None, True, False, 0, 1, -1, 2, "", "x", "0", [], [0], [1], [None], {}, 1.5, 10 ** 30, -10 ** 30, [[]]]


def _log(*a):
    print(*a, flush=True)  # a compile runs for minutes to hours: progress must reach a redirected log as it happens


class CompileError(Exception):
    """A pass cannot continue; the message tells the declaration's author what to change."""


def R(check, status, detail=""):
    return {"check": check, "status": status, "detail": detail}


def worst(results):
    order = {"pass": 0, "warn": 1, "fail": 2}
    return max((r["status"] for r in results), key=order.get, default="pass")


def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _sha(path):
    return declared.sha256_file(path)


# ------------------------------------------------------------------------------------------------------------- 1. parse
def parse(dirpath):
    """-> (module, reference path, results). module is None when the declaration cannot be loaded."""
    try:
        mod = declared.load_declaration(dirpath)
    except declared.DeclarationError as e:
        return None, None, [R("declaration", "fail", str(e))]
    out = [R("declaration", "pass", f"{mod.NAME} {mod.VERSION}, sizes {mod.SIZE_RANGE[0]}..{mod.SIZE_RANGE[1]} step {getattr(mod, 'SIZE_STEP', 1)}")]
    if mod.NAME in BUILTIN:
        out.append(R("name", "fail", f"{mod.NAME!r} is a built-in family"))
    try:
        ref = declared.reference_path(dirpath, mod)
    except declared.DeclarationError as e:
        return mod, None, out + [R("reference", "fail", str(e))]
    warnings, fatal = submit_check.lint(ref)
    for f in fatal:
        out.append(R("reference lint", "fail", f))
    for w in warnings:
        # the baseline is measured inside the sandbox image: an import the image lacks is not a style point, it is a crash
        out.append(R("reference lint", "fail" if "not in the sandbox image" in w else "warn", w))
    with open(ref, "rb") as f:
        try:
            tree = ast.parse(f.read())
        except (SyntaxError, ValueError):
            tree = None
    if tree is not None:
        judge_side = {"families", "instances", "instances_mlwe", "instances_factor", "harness", "judge", "declared", "decl", "rounds",
                      "extrapolate", "compile_domain", mod.NAME}
        for node in ast.walk(tree):
            mods = [a.name for a in node.names] if isinstance(node, ast.Import) else \
                [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
            for m in mods:
                if m.split(".")[0] in judge_side:
                    out.append(R("reference isolation", "fail", f"imports `{m}`: the reference must be self-contained (it runs in the sandbox, which has none of the judge's modules)"))
    if not any(r["check"].startswith("reference") for r in out):
        out.append(R("reference", "pass", os.path.basename(ref)))
    note = getattr(mod, "REFERENCE_NOTE", None)
    if isinstance(note, str) and note.strip():
        out.append(R("baseline statement", "pass", "REFERENCE_NOTE says what the reference is and what is known to beat it"))
    else:
        out.append(R("baseline statement", "warn", "no REFERENCE_NOTE: say in one or two sentences what algorithm the reference is and what is known to beat it. "
                                                  "A weak reference makes big speedups cheap and nothing else in the compile can detect that"))
    return mod, ref, out


# ------------------------------------------------------------------------------------------------------------- 2. validate
def _leaves(x, depth=0):
    if depth > 6:
        return
    if isinstance(x, dict):
        for v in x.values():
            yield from _leaves(v, depth + 1)
    elif isinstance(x, (list, tuple)):
        for v in x:
            yield from _leaves(v, depth + 1)
    else:
        yield x


def _subtrees(x, depth=0):
    """Every node of a JSON-like value (containers and leaves)."""
    yield x
    if depth > 6:
        return
    if isinstance(x, dict):
        for v in x.values():
            yield from _subtrees(v, depth + 1)
    elif isinstance(x, (list, tuple)):
        for v in x:
            yield from _subtrees(v, depth + 1)


def _witness(mod, inst):
    return mod.witness(inst) if hasattr(mod, "witness") else inst.get("planted")


@contextlib.contextmanager
def provisional(mod):
    """harness.run_one verifies answers through families.FAMILIES, and a domain is not registered until it is compiled. While the compiler
    measures its reference, register the declaration's (derive, verify) for this process only, then restore the registry exactly."""
    had = mod.NAME in families.FAMILIES
    if not had:
        families.FAMILIES[mod.NAME] = declared.make_spec(mod)
    try:
        yield
    finally:
        if not had:
            families.FAMILIES.pop(mod.NAME, None)


def _pure_subprocess(decl_path, picks, hashseed):
    code = ("import sys, json, importlib.util\nsys.path.insert(0, %r)\n"
            "spec = importlib.util.spec_from_file_location('d', %r)\nm = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)\n"
            "print(json.dumps([m.derive(bytes.fromhex(a), b, c) for a, b, c in json.loads(sys.argv[1])], sort_keys=True, separators=(',', ':')))\n"
            % (HERE, decl_path))
    r = subprocess.run([sys.executable, "-c", code, json.dumps(picks)], capture_output=True, text=True, timeout=300, cwd=os.path.dirname(decl_path),
                       env={"PATH": os.environ.get("PATH", ""), "PYTHONHASHSEED": str(hashseed)})
    if r.returncode:
        raise CompileError("derive() failed in a fresh interpreter: " + r.stderr[-300:])
    return json.loads(r.stdout)


KIND_NAMES = ("advantage", "oracle", "precomp", "quantum")   # compile_kinds.KINDS (a test pins the two together); named here so the speed paths need not import it
QUALITY_TRIVIAL = 0.9   # a quality challenge: an answer derived WITHOUT search that verify() accepts must still score at most this (valid-but-poor answers are expected)


def validate(mod, dirpath, ref, measure=None, n_ref=3, run_reference=True, quality=None):
    """The anti-cheat and sanity checks. `measure(size, idx)` runs the reference (default: the real harness) for the reference checks.
    `quality` (quality challenges only: the declaration's quality(inst, ans)) relaxes the two checks that assume a SMALL answer space: verify() may accept a no-search
    answer or another instance's witness as long as it scores at most QUALITY_TRIVIAL, because in an optimisation problem many answers are valid and the score tells them apart."""

    def counts(x, ans):
        """verify() accepted `ans`: does it count as a hit against the anti-cheat checks? Always, unless a quality score says it is a poor answer."""
        if quality is None:
            return True
        try:
            q = float(quality(x, ans))
        except Exception:
            return True   # a quality() that raises on a verified answer is a defect of its own (compile_quality reports it); do not excuse the answer
        return q > QUALITY_TRIVIAL or q != q
    derive, verify = declared.make_spec(mod)
    lo, hi = mod.SIZE_RANGE
    step = getattr(mod, "SIZE_STEP", 1)
    mid = lo + ((hi - lo) // (2 * step)) * step
    master = b"svp-compiler-validate-A"
    master2 = b"svp-compiler-validate-B"
    out = []

    def guarded(name, fn):
        try:
            fn()
        except CompileError as e:
            out.append(R(name, "fail", str(e)))
        except Exception as e:  # the author's code can raise anything
            out.append(R(name, "fail", f"{type(e).__name__}: {e}"))

    sizes = sorted({lo, mid, hi})
    cache = {}

    def inst(master_, size, idx):
        k = (master_, size, idx)
        if k not in cache:
            t0 = time.time()
            cache[k] = derive(master_, size, idx)
            cache[k]["_t"] = time.time() - t0
        return cache[k]

    def shape():
        for s in sizes:
            for i in range(2):
                x = inst(master, s, i)
                if not isinstance(x.get("args"), (list, tuple)):
                    raise CompileError(f"derive({s}, {i}) did not return an 'args' list: the solver is called as solve(*args)")
                payload = json.dumps({"args": x["args"]}, allow_nan=False)  # raises on sets, bytes, NaN: they cannot cross the process boundary
                if len(payload) > (1 << 20):
                    raise CompileError(f"the arguments at size {s} are {len(payload)} bytes; keep an instance under 1 MiB")
        slow = max(x["_t"] for x in cache.values())
        out.append(R("shape", "warn" if slow > 5 else "pass",
                     f"args are JSON-serializable lists at sizes {sizes}" + (f"; derive() took {slow:.1f} s" if slow > 5 else "")))
    guarded("shape", shape)
    if any(r["status"] == "fail" for r in out):
        return out

    def determinism():
        for s in sizes:
            a = {k: v for k, v in derive(master, s, 0).items()}
            b = {k: v for k, v in derive(master, s, 0).items()}
            if canon(a) != canon(b):
                raise CompileError(f"derive({s}, 0) returned different instances on two calls with the same inputs")
        distinct = {canon(inst(master, mid, i)["args"]) for i in range(8)}
        if len(distinct) < 7:
            raise CompileError(f"only {len(distinct)} distinct instances from 8 indices at size {mid}: instances must depend on the index")
        other = sum(canon(inst(master, mid, i)["args"]) != canon(inst(master2, mid, i)["args"]) for i in range(4))
        if other < 3:
            raise CompileError("instances do not depend on the master seed: the commit-reveal protocol would commit to nothing")
        out.append(R("determinism", "pass", f"pure in (master, size, index); {len(distinct)}/8 distinct indices; seed-dependent"))
    guarded("determinism", determinism)

    def purity():
        picks = [[master.hex(), s, i] for s in sizes for i in range(2)]
        mine = [{k: v for k, v in derive(master, s, i).items()} for _, s, i in picks]
        decl_path = os.path.join(os.path.abspath(dirpath), declared.DECL)
        for seed in (1, 2):
            theirs = _pure_subprocess(decl_path, picks, seed)
            for a, b, p in zip(mine, theirs, picks):
                # the declaration's own derive(), not the wrapper: compare only what the author produced
                if canon({k: a[k] for k in b}) != canon(b):
                    raise CompileError(f"derive({p[1]}, {p[2]}) differs between interpreters (PYTHONHASHSEED={seed}): it depends on hash "
                                       "order, the clock, global random state or the environment, so another machine would derive different instances")
        out.append(R("process purity", "pass", "identical instances in fresh interpreters with two hash seeds"))
    guarded("process purity", purity)

    def witness():
        bad = 0
        for s in sizes:
            for i in range(4):
                x = inst(master, s, i)
                if "planted" not in x and not hasattr(mod, "witness"):
                    raise CompileError("derive() must return the witness under 'planted' (or the declaration must define witness(inst)): "
                                       "without a known answer the compiler cannot prove the verifier accepts a correct one")
                if not verify(x, _witness(mod, x)):
                    bad += 1
        if bad:
            raise CompileError(f"verify() rejected the planted witness on {bad} of {len(sizes) * 4} instances")
        for s in sizes:
            x = inst(master, s, 0)
            w = _witness(mod, x)
            if len(canon(w)) >= 6 and canon(w) in {canon(t) for t in _subtrees(x["args"])}:
                raise CompileError(f"the witness appears verbatim in the arguments at size {s}: the solver is handed the answer")
            big = {v for v in _leaves(w) if (isinstance(v, int) and not isinstance(v, bool) and abs(v) >= 1 << 16) or (isinstance(v, str) and len(v) >= 8)}
            if big & set(_leaves(x["args"])):
                raise CompileError(f"a component of the witness is one of the arguments at size {s}: the solver is handed part of the answer")
        out.append(R("witness", "pass", f"verify() accepts the planted witness on {len(sizes) * 4} instances; it is not in the arguments"))
    guarded("witness", witness)

    def junk():
        raised = set()
        for s in (lo, mid):
            for i in range(3):
                x = inst(master, s, i)
                for j in JUNK:
                    try:
                        ok = verify(x, j)
                    except Exception as e:
                        raised.add(type(e).__name__)
                        continue
                    if ok:
                        raise CompileError(f"verify() ACCEPTED {j!r} at size {s}. An answer space this small is guessable; the answer must be a witness a "
                                           "solver has to search for")
        out.append(R("junk rejected", "warn" if raised else "pass",
                     f"verify() raised {sorted(raised)} on some junk answers (the harness scores that as wrong, but return False instead)" if raised
                     else f"verify() rejected all {len(JUNK)} junk answers on 6 instances"))
    guarded("junk rejected", junk)

    def trivial():
        for s in sizes:
            for i in range(3):
                x = inst(master, s, i)
                cands = [x["args"], list(x["args"])[::-1]] + [v for v in _leaves(x["args"]) if isinstance(v, int) and not isinstance(v, bool)][:64]
                cands += [v + d for v in cands[2:10] if isinstance(v, int) for d in (-1, 1)]
                for c in cands:
                    try:
                        hit = verify(x, c)
                    except Exception:
                        continue
                    if hit and counts(x, c):
                        raise CompileError(f"verify() accepts {str(c)[:60]!r}, which is derived from the arguments without any search (size {s})")
        out.append(R("no trivial answer", "pass", "no argument, its neighbour or the argument list verifies"))
    guarded("no trivial answer", trivial)

    def cross():
        pairs = hit = 0
        for i in range(6):
            w = _witness(mod, inst(master, mid, i))
            for j in range(6):
                if i != j:
                    pairs += 1
                    try:
                        xj = inst(master, mid, j)
                        hit += bool(verify(xj, w)) and counts(xj, w)
                    except Exception:
                        pass
        rate = hit / pairs
        if rate > 0.25:
            raise CompileError(f"another instance's witness is accepted {100 * rate:.0f}% of the time at size {mid}: a lookup table of past answers would solve it")
        out.append(R("witness reuse", "warn" if hit else "pass", f"{hit} of {pairs} cross-instance witnesses accepted" + (" (small answer space)" if hit else "")))
    guarded("witness reuse", cross)

    if any(r["status"] == "fail" for r in out):
        return out
    if not run_reference:
        return out + [R("reference solves", "warn", "skipped (--no-reference): the reference was not run")]

    def reference():
        meas = measure or default_measure(mod, ref, PROFILE_SEED, 10, harness.calibrate() if measure is None else 0.0)
        sub = [lo + k * step for k in range(3) if lo + k * step <= hi]
        notes = []
        for s in sub:
            recs = [meas(s, i) for i in range(n_ref)]
            for r in recs:
                if r["status"] == "wrong":
                    raise CompileError(f"the reference returned an answer verify() rejects at size {s}: either the reference or verify() is wrong")
                if r["status"] == "crash":
                    raise CompileError(f"the reference crashed at size {s}: {str(r.get('err', ''))[-200:]}")
                if r["status"] == "failed":
                    raise CompileError(f"the reference returned no answer at size {s}")
                if r["status"] == "timeout":
                    raise CompileError(f"the reference exceeded 10 s at the smallest size {s}: lower SIZE_RANGE[0]")
            notes.append(f"{s}: {statistics.median(r['cpu_net'] for r in recs):.3f}s")
        r1, r2 = meas(sub[0], 0), meas(sub[0], 0)
        if r1["status"] != r2["status"]:
            raise CompileError("the reference is not deterministic: two runs on one instance ended differently")
        out.append(R("reference solves", "pass", f"solved {n_ref} instances at each of sizes {sub}; median cost " + ", ".join(notes)))
    with provisional(mod):
        guarded("reference solves", reference)
    return out


# ------------------------------------------------------------------------------------------------------------- 3. profile
def default_measure(mod, ref, master, budget, overhead):
    derive, _ = declared.make_spec(mod)
    fam = mod.NAME

    def measure(size, idx, budget_=None):
        b = budget_ or budget
        x = derive(master, size, idx)
        x["family"] = fam
        rec = harness.run_one(ref, x, b)
        rec["cpu_net"] = max(rec["cpu"] - overhead, 1e-3)
        rec["budget"] = b
        rec["idx"] = idx   # which instance this is: a filtered or re-measured list must not be read by position
        return rec
    return measure


def _cost(r, default_cap):
    return r["cpu_net"] if r["status"] == "solved" else r.get("budget", default_cap)


class Model:
    """Cost-vs-size, piecewise linear in log2(median cost). Built from every record measured so far (timeouts count at their cap)."""

    def __init__(self, pts, cap):
        self.pts, self.cap = pts, cap
        self.xs = sorted(s for s, rs in pts.items() if statistics.median(_cost(r, cap) for r in rs) >= 0.02)  # below ~20 ms: overhead, not work
        # the trend over ALL usable sizes: a median of a few heavy-tailed instances can sit below its neighbour's, and a slope read off two
        # such points can be ~0 (it once predicted a flat cost for sizes that actually double per step)
        self.gslope = 0.0
        if len(self.xs) >= 2:
            ys = [self.y(x) for x in self.xs]
            mx, my = statistics.fmean(self.xs), statistics.fmean(ys)
            self.gslope = sum((x - mx) * (y - my) for x, y in zip(self.xs, ys)) / sum((x - mx) ** 2 for x in self.xs)

    def y(self, s):
        return math.log2(max(statistics.median(_cost(r, self.cap) for r in self.pts[s]), 1e-3))

    def _local_line(self, s):
        """Least squares of log2(cost) on size over the INDIVIDUAL instances of the (up to) four usable sizes nearest `s`. The median of 8
        heavy-tailed instances is noisy (on dlog, sizes 28/29/30 came out 3.7 s, 2.05 s, 43 s where the cost doubles per size); a line through
        all the instances is far steadier. -> (mean size, mean log2 cost, slope) or None."""
        near = sorted(self.xs, key=lambda x: (abs(x - s), x))[:4]
        px = [x for x in near for _ in self.pts[x]]
        py = [math.log2(max(_cost(r, self.cap), 1e-3)) for x in near for r in self.pts[x]]
        if len(set(px)) < 2:
            return None
        mx, my = statistics.fmean(px), statistics.fmean(py)
        return mx, my, sum((x - mx) * (y - my) for x, y in zip(px, py)) / sum((x - mx) ** 2 for x in px)

    def predict(self, s):
        if len(self.xs) < 2:
            raise CompileError("fewer than two sizes with a measurable cost: the reference is too cheap across SIZE_RANGE (raise its upper end)")
        line = self._local_line(s)
        if line is not None:
            mx, my, b = line
            return my + max(b, 0.5 * self.gslope, 1e-3) * (s - mx)  # never flatter than half the overall trend; cost does not fall with size
        if s in self.pts and s in self.xs:
            return self.y(s)
        if s <= self.xs[0]:
            a, b = self.xs[0], self.xs[1]
        elif s >= self.xs[-1]:
            a, b = self.xs[-2], self.xs[-1]
        else:
            b = next(x for x in self.xs if x > s)
            a = self.xs[self.xs.index(b) - 1]
        # cost never "falls" with size in a challenge worth compiling, and a local slope may not fall below half the overall trend
        slope = max((self.y(b) - self.y(a)) / (b - a), 0.5 * self.gslope, 1e-3)
        return self.y(a) + slope * (s - a)


def pooled_sigma(pts, sizes, cap, model=None):
    """Per-instance spread of the baseline (sd of log2 cost). With a model: the sd of the residuals of every solved instance on the ladder
    around the model's line (>= 8 of them), which pools all sizes. Without: the median over sizes of the per-size sd (>= 4 solved each),
    which on 8 instances per size is badly noisy (0.64, 2.26 and 0.64 for a true 1.44)."""
    if model is not None:
        res = [math.log2(r["cpu_net"]) - model.predict(s) for s in sizes for r in pts.get(s, []) if r["status"] == "solved" and r["cpu_net"] >= 0.05]
        if len(res) >= 8:
            return min(max(math.sqrt(sum(x * x for x in res) / (len(res) - 2)), 0.15), 3.0), True  # two fitted parameters
    sds = []
    for s in sizes:
        v = [math.log2(r["cpu_net"]) for r in pts.get(s, []) if r["status"] == "solved" and r["cpu_net"] >= 0.05]
        if len(v) >= 4:
            sds.append(statistics.pstdev(v))
    if not sds:
        return 1.0, False
    return min(max(statistics.median(sds), 0.15), 3.0), True


def probe(mod, measure, k, probe_budget, log=_log):
    """Coarse gallop up the size range until the reference costs more than probe_budget/3 (or a timeout). -> {size: [records]}"""
    lo, hi = mod.SIZE_RANGE
    step = getattr(mod, "SIZE_STEP", 1)

    def snap(s):
        return max(lo, min(hi, lo + int(round((s - lo) / step)) * step))
    pts, hist = {}, []
    gap0 = max(step, snap(lo + (hi - lo) // 6) - lo)
    s = lo
    while True:
        recs = [measure(s, i) for i in range(k)]
        pts[s] = recs
        for r in recs:
            if r["status"] in ("wrong", "crash", "failed"):
                raise CompileError(f"the reference {r['status']} at size {s}: {str(r.get('err', ''))[-200:] or 'see validate'}")
        med = statistics.median(_cost(r, probe_budget) for r in recs)
        log(f"  probe size {s}: median {med:.3f}s" + (f", {sum(r['status'] == 'timeout' for r in recs)} timeout(s)" if any(r['status'] == 'timeout' for r in recs) else ""))
        if any(r["status"] == "timeout" for r in recs) or med > probe_budget / 3 or s >= hi:
            break
        if med >= 0.02:
            hist.append((s, math.log2(med)))
        if len(hist) >= 2 and hist[-1][0] != hist[-2][0]:
            slope = (hist[-1][1] - hist[-2][1]) / (hist[-1][0] - hist[-2][0])
            if slope > 1e-3:
                want = s + (math.log2(probe_budget / 4) - hist[-1][1]) / slope
                delta = min(max(want - s, step), 3 * max(s - hist[-2][0], step))
            else:
                delta = 2 * gap0
        else:
            delta = 2 * gap0 if med < 0.02 else gap0
        nxt = snap(s + delta)
        s = nxt if nxt > s else min(hi, s + step)
    return pts


def choose_ladder(model, sigma, mod, caps=CAPS):
    lo, hi = mod.SIZE_RANGE
    step = getattr(mod, "SIZE_STEP", 1)
    grid = list(range(lo, hi + 1, step))
    best, notes = None, []
    for cap in caps:
        y_hi, y_lo = math.log2(cap) - Z_TAIL * sigma, math.log2(LOW_COST)
        S = [s for s in grid if y_lo <= model.predict(s) <= y_hi]
        if not S:
            continue
        if len(S) > MAX_SIZES:
            targets = [model.predict(S[-1]) - j * (model.predict(S[-1]) - model.predict(S[0])) / (MAX_SIZES - 1) for j in range(MAX_SIZES)]
            S = sorted({min(S, key=lambda s: abs(model.predict(s) - t)) for t in targets})
        span = model.predict(S[-1]) - model.predict(S[0])
        cand = {"cap": cap, "sizes": S, "predicted_median": [round(2 ** model.predict(s), 3) for s in S], "span_octaves": round(span, 2)}
        if best is None or (cand["span_octaves"], len(S)) > (best["span_octaves"], len(best["sizes"])):
            best = cand
        if len(S) >= MIN_SIZES + 1 and span >= 3.0:
            best = cand
            break
    if best is None:
        raise CompileError(f"no size in SIZE_RANGE {mod.SIZE_RANGE} has a predicted median cost between {LOW_COST:g} s and the cap (largest cap tried "
                           f"{caps[-1]} s); the reference is too cheap or too expensive over this range: move SIZE_RANGE")
    if best["sizes"][-1] == hi and model.predict(hi) < math.log2(best["cap"]) - Z_TAIL * sigma - 1:
        notes.append(f"the ladder is limited by SIZE_RANGE[1]={hi}: the reference is predicted to cost only {2 ** model.predict(hi):.1f} s there; raise it for a harder challenge")
    if len(best["sizes"]) < MIN_SIZES or best["span_octaves"] < 3.0:
        notes.append(f"narrow ladder: only {len(best['sizes'])} size(s), whose costs span {best['span_octaves']} doublings (about {2 ** best['span_octaves']:.0f}x); "
                     "at least 3 doublings are needed for the scoring groups to fill up: widen SIZE_RANGE or let the reference's cost grow faster with size")
    best["notes"] = notes
    return best


def missing_indices(have, n_prof):
    """The instance indices still to measure so that a size has exactly indices 0..n_prof-1. Records carry their own index: counting from len(have)
    re-measured an index already held whenever a lower-cap timeout had been dropped (one instance counted twice, the dropped one never re-measured).
    Records without an index (a caller's own measure) keep the positional rule."""
    have_idx = {r["idx"] for r in have if "idx" in r}
    return [i for i in range(n_prof) if i not in have_idx] if have_idx else list(range(len(have), n_prof))


def profile_and_plan(mod, measure, k=3, n_prof=8, probe_budget=20, caps=CAPS, log=_log, max_refine=2):
    """Passes 3 and 4. Returns (points, plan) where plan carries the ladder, the cap and sigma, validated by measuring the chosen sizes."""
    log("profile: coarse probe")
    pts = probe(mod, lambda s, i: measure(s, i, probe_budget) if _accepts_budget(measure) else measure(s, i), k, probe_budget, log)
    plan, prev_plan, off, first_pass_ok = None, None, [], True
    first = pts[min(pts)]
    if all(r["status"] == "timeout" for r in first):
        raise CompileError(f"the reference exceeds the {probe_budget:g} s probe cap even at the smallest size {min(pts)}: lower SIZE_RANGE[0] "
                           "(or raise --probe-budget)")
    for it in range(max_refine + 1):
        cap0 = caps[-1]
        model = Model(pts, cap0)
        sigma, measured_sigma = pooled_sigma(pts, model.xs, cap0, model)
        plan = choose_ladder(model, sigma, mod, caps)
        plan["sigma"], plan["sigma_measured"] = round(sigma, 3), measured_sigma
        if it > 0 and (plan["cap"], plan["sizes"]) == prev_plan:  # a re-plan that changes nothing has nothing new to measure: stop (it re-ran an identical pass before)
            log(f"optimize (pass {it + 1}): the same ladder as the previous pass; stopping")
            break
        prev_plan = (plan["cap"], list(plan["sizes"]))
        log(f"optimize (pass {it + 1}): cap {plan['cap']} s, sizes {plan['sizes']}, predicted medians {plan['predicted_median']}, sigma {sigma:.2f}")
        off = []
        for s in plan["sizes"]:
            # keep what is valid at THIS cap (a solved record, or a timeout at a cap at least this large); a timeout at a lower cap is re-measured
            have = pts[s] = [r for r in pts.get(s, []) if r.get("budget", plan["cap"]) >= plan["cap"] or r["status"] == "solved"]
            for i in missing_indices(have, n_prof):
                pts.setdefault(s, []).append(measure(s, i, plan["cap"]) if _accepts_budget(measure) else measure(s, i))
            meas_med = statistics.median(_cost(r, plan["cap"]) for r in pts[s])
            pred = 2 ** model.predict(s)
            log(f"  confirm size {s}: measured median {meas_med:.2f}s, predicted {pred:.2f}s")
            miss = abs(math.log2(max(meas_med, 1e-3) / max(pred, 1e-3)))
            if miss > 1.0:
                off.append(s)
            if miss > 2.0:  # a wildly wrong model: stop measuring the rest of this ladder (hours at the cap) and re-plan from what was learned
                log(f"  prediction off by {miss:.1f} octaves: re-planning without measuring the remaining sizes")
                break
        if it == 0:
            first_pass_ok = not off
        if not off:
            break
    sizes = plan["sizes"]
    final = Model(pts, plan["cap"])
    sigma, measured_sigma = pooled_sigma(pts, sizes, plan["cap"], final)
    plan["sigma"], plan["sigma_measured"] = round(sigma, 3), measured_sigma
    # "confirmed" means the FIRST plan's predictions held when measured. After a re-plan the model contains the very data it would be
    # confirmed by, so agreement proves nothing (the earlier version reported True for exactly that).
    plan["confirmed"] = first_pass_ok
    if not first_pass_ok:
        plan["notes"].append("the first plan's cost predictions were off by more than a factor of 2, so the ladder was re-planned from the confirming data: "
                             "it is the best available but NOT independently confirmed")
    if off:
        plan["notes"].append(f"the cost model was still off by more than a factor of 2 at size(s) {off} after {max_refine} refinements")
    # the simulated truth for the power analysis: the model's smoothed line, not 8-instance medians that can sit an octave off their neighbours
    plan["median_log2"] = {s: round(final.predict(s), 4) for s in sizes}
    raw = {s: statistics.median(math.log2(max(_cost(r, plan["cap"]), 1e-3)) for r in pts[s]) for s in sizes}
    worst_gap = max(abs(raw[s] - plan["median_log2"][s]) for s in sizes)
    if worst_gap > 1.0:
        plan["notes"].append(f"the measured typical cost at one size is a factor of {2 ** worst_gap:.1f} away from the smoothed trend (chance variation with only "
                             f"{min(len(pts[s]) for s in sizes)} instances per size): the power analysis uses the smoothed trend; raise --n-prof for a steadier profile")
    return pts, plan


def _accepts_budget(fn):
    try:
        import inspect
        return len(inspect.signature(fn).parameters) >= 3
    except (TypeError, ValueError):
        return False


def profile_json(pts, plan, overhead):
    out = {}
    for s, rs in sorted(pts.items()):
        solved = [r["cpu_net"] for r in rs if r["status"] == "solved"]
        out[str(s)] = {"n": len(rs), "solved": len(solved), "timeouts": sum(r["status"] == "timeout" for r in rs),
                       "costs": [[r.get("idx", pos), round(_cost(r, plan["cap"]), 4), r["status"] == "solved"] for pos, r in enumerate(rs)],   # [instance index, cost, solved]: lets `recheck --measure` compare the SAME instances
                       "median_cost": round(statistics.median(_cost(r, plan["cap"]) for r in rs), 4),
                       "sd_log2": round(statistics.pstdev([math.log2(c) for c in solved]), 3) if len(solved) >= 2 else None}
    return {"seed": PROFILE_SEED.decode(), "overhead": round(overhead, 4), "sizes": out}


# ------------------------------------------------------------------------------------------------------------- 5. power
def synth_base(plan, n, rng):
    """One synthetic baseline ladder drawn from the profile: per size, costs 2^(median + sigma z); above the cap = a timeout (censored)."""
    cap, sig = plan["cap"], plan["sigma"]
    base = {}
    for s in plan["sizes"]:
        m = plan["median_log2"][s] if s in plan["median_log2"] else plan["median_log2"][str(s)]
        base[s] = {}
        for i in range(n):
            c = 2 ** (m + sig * rng.gauss(0, 1))
            base[s][i] = {"status": "timeout", "cpu_net": cap} if c > cap else {"status": "solved", "cpu_net": max(c, 1e-3)}
    return base


def power_at(plan, n, effect, triples, boot, pair_noise, rng):
    """P(one seed's credit >= THRESHOLD), P(all three seeds >= THRESHOLD) for a true speedup of `effect` bits, through the REAL estimator."""
    import power
    credits = []
    for _ in range(3 * triples):
        base = synth_base(plan, n, rng)
        pool = {"__all__": [rng.gauss(0, pair_noise) for _ in range(400)]}
        c, _ = power.synth_trial(base, plan["cap"], pool, effect, rng, boot)
        credits.append(c)
    single = sum(c is not None and c >= THRESHOLD for c in credits) / len(credits)
    trip = [min(0.0 if c is None else c for c in credits[i:i + 3]) for i in range(0, len(credits) - 2, 3)]
    return {"single": round(single, 3), "all_three": round(sum(c >= THRESHOLD for c in trip) / len(trip), 3),
            "inconclusive": round(sum(c is None for c in credits) / len(credits), 3)}


def power_plan(plan, target_effect=2.0, target_power=0.8, pair_noise=0.6, triples=30, boot=60, effects=(0, 0.5, 1, 1.5, 2, 3, 4, 5, 6), ns=NS, log=_log):
    """Pass 5. Chooses the smallest n whose all-three-seeds power at `target_effect` reaches `target_power`, then tabulates power by effect."""
    rng = random.Random(0)
    chosen, tried = None, {}
    for n in ns:
        p = power_at(plan, n, target_effect, triples, boot, pair_noise, rng)
        tried[n] = p["all_three"]
        log(f"power: n={n}: P(all 3 seeds >= {THRESHOLD:g} bit | true effect {target_effect:g}) = {p['all_three']:.2f}")
        chosen = n
        if p["all_three"] >= target_power:
            break
    n = chosen
    curve = {}
    for e in effects:
        curve[str(e)] = power_at(plan, n, e, triples, boot, pair_noise, rng)
    mce = next((e for e in effects if curve[str(e)]["all_three"] >= target_power), None)
    top = max((e for e in effects if curve[str(e)]["all_three"] >= target_power), default=None)  # the ceiling: a submission cost below the 0.5 s floor is unusable
    notes = []
    if tried[n] < target_power:
        notes.append(f"even n={n} (the largest allowed) certifies a {target_effect:g}-bit speedup only {100 * tried[n]:.0f}% of the time")
    if curve["0"]["single"] > 0.10:
        notes.append(f"FALSE-CREDIT RATE {100 * curve['0']['single']:.0f}% at zero effect (> 10%): the lower bound is not holding on this ladder")
    return {"n": n, "target_effect": target_effect, "target_power": target_power, "pair_noise": pair_noise, "triples": triples, "boot": boot,
            "threshold": THRESHOLD, "tried": {str(k): v for k, v in tried.items()}, "curve": curve, "min_certifiable_effect": mce, "max_certifiable_effect": top, "notes": notes}


def cpu_hours(plan, n, sigma=None):
    """Worst case (every instance charged the cap) CPU-hours of ONE submission's evaluation: 3 seeds x (baseline + submission) ladders."""
    per = len(plan["sizes"]) * n * plan["cap"] * 2 * SEEDS / 3600.0
    exp = 0.0
    for s in plan["sizes"]:
        m = plan["median_log2"][s] if s in plan["median_log2"] else plan["median_log2"][str(s)]
        sig = plan["sigma"] if sigma is None else sigma
        exp += min(2 ** m * math.exp((sig * math.log(2)) ** 2 / 2), plan["cap"])  # mean of a lognormal whose log2 has sd sig, capped (an upper-ish figure)
    return {"worst_case": round(per, 2), "expected": round(exp * n * 2 * SEEDS / 3600.0, 2)}


# ------------------------------------------------------------------------------------------------------------- 6. emit
def practice_sizes(mod, pts, cap):
    lo, hi = mod.SIZE_RANGE
    ok = [s for s in sorted(pts) if statistics.median(_cost(r, cap) for r in pts[s]) <= 1.0 and all(r["status"] == "solved" for r in pts[s])]
    return ok[-2:] if ok else [lo]


def build_compiled(mod, dirpath, ref, plan, pw, pts, overhead, validation, selftest):
    cost = cpu_hours(plan, pw["n"])
    return {"format": declared.FORMAT, "name": mod.NAME, "version": mod.VERSION, "compiled_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "decl_sha256": _sha(os.path.join(dirpath, declared.DECL)), "reference_sha256": _sha(ref),
            "compiler_sha256": _sha(os.path.abspath(__file__)), "reference_note": (getattr(mod, "REFERENCE_NOTE", "") or "").strip(),
            "size_range": list(mod.SIZE_RANGE), "size_step": getattr(mod, "SIZE_STEP", 1),
            "official": {"n": pw["n"], "budget": plan["cap"]}, "dims": plan["sizes"], "practice_dims": practice_sizes(mod, pts, plan["cap"]),
            "plan": {k: plan[k] for k in ("cap", "sizes", "predicted_median", "span_octaves", "sigma", "sigma_measured", "confirmed", "notes", "median_log2")},
            "profile": profile_json(pts, plan, overhead), "power": pw, "cpu_hours": cost,
            "validation": validation, "selftest": selftest}


def write_compiled(dirpath, compiled):
    path = os.path.join(dirpath, declared.COMPILED)
    if os.path.exists(path):
        shutil.copyfile(path, os.path.join(dirpath, "compiled.prev.json"))  # the previous compile is kept, never discarded
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(compiled, f, indent=1, sort_keys=True)
    os.replace(tmp, path)


def _write(path, text, mode=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    if mode:
        os.chmod(path, mode)


def power_table(compiled):
    rows = ["| true speedup (bits) | P(one seed credited >= %g bit) | P(all three seeds) |" % compiled["power"]["threshold"], "|---|---|---|"]
    for e, v in compiled["power"]["curve"].items():
        rows.append(f"| {e} | {100 * v['single']:.0f}% | {100 * v['all_three']:.0f}% |")
    return "\n".join(rows)


def emit(dirpath, mod, compiled, targets=("local", "server", "ci", "certificate")):
    out = os.path.join(dirpath, "out")
    name, cap, n, dims = mod.NAME, compiled["official"]["budget"], compiled["official"]["n"], compiled["dims"]
    mce = compiled["power"]["min_certifiable_effect"]
    st = (compiled.get("selftest") or {}).get("status", "pending")
    doc = getattr(mod, "DOC", "(the declaration gives no DOC string)")
    written = []
    if "local" in targets:
        p = os.path.join(out, "CHALLENGE.md")
        _write(p, f"""# {name}: challenge

{doc}

* sizes (ladder): {dims}; CPU cap {cap} s per instance; {n} instances per size; credit = MIN over 3 committed seeds of a one-sided 95% lower bound
* the reference solver is `{mod.REFERENCE_SOLVER}`; a credit is a speedup over it, in bits (log2 of the cost ratio) on the hardest instances it solved
* what the reference is, and what is known to beat it (the author's statement; a speedup is only as meaningful as its baseline): {compiled.get('reference_note') or 'NOT STATED by the declaration author'}
* speedups this ladder can certify (all three seeds, {int(100 * compiled['power']['target_power'])}% power): {('from about %g to about %g bits' % (mce, compiled['power'].get('max_certifiable_effect'))) + ('' if compiled['power'].get('max_certifiable_effect') == max(float(e) for e in compiled['power']['curve']) else ". Above the top of that range a fast solver's own cost falls under the estimator's 0.5 s floor, so a bigger speedup cannot be certified by this ladder (a harder ladder or a model baseline is needed)") if mce is not None else 'NONE on the grid: this challenge is too weak to certify'}
* compiler self-test: {st}

## Try a solver (public practice sizes, well-formedness only)

    python3 submit_check.py my_solver.py --family {name}

## What this challenge can certify (simulated through the real estimator; pair noise {compiled['power']['pair_noise']} bit)

{power_table(compiled)}
""")
        written.append(p)
    if "server" in targets:
        cost = compiled["cpu_hours"]
        p = os.path.join(out, "server_plan.json")
        _write(p, json.dumps({"family": name, "n": n, "budget": cap, "dims": dims, "seeds": SEEDS, "cpu_hours_per_submission": cost,
                              "selftest": st, "commands": [
                                  f"python3 ops.py round-new --data DATA --seed-dir SEEDS --id {name}-1 --title \"{name} round 1\" --family {name} --closes <UTC deadline> --n {n}",
                                  "python3 ops.py close --data DATA --id " + name + "-1", "python3 ops.py worker --data DATA --id " + name + "-1 --seed-dir SEEDS/" + name + "-1",
                                  "python3 ops.py reveal --data DATA --id " + name + "-1 --seed-dir SEEDS/" + name + "-1"],
                              "note": "the domain directory is part of the round's committed rules (its hashes go into log entry 0); deploy domains/" + name + " with the code"},
                             indent=1))
        written.append(p)
    if "ci" in targets:
        p = os.path.join(out, "ci_check.sh")
        _write(p, f"""#!/bin/sh
# Pre-merge check for solver submissions to the {name} challenge. Usage: sh ci_check.sh path/to/solver.py
# Fast (no timing study): the declaration still validates, the compile is fresh, and the solver is well-formed on the public practice sizes.
set -e
SOLVER="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"   # resolve BEFORE changing directory: $1 is relative to where the caller ran this
cd "$(dirname "$0")/../../.."
python3 compile_domain.py check domains/{name}
python3 submit_check.py "$SOLVER" --family {name}
""", 0o755)
        _write(os.path.join(out, "ci_workflow.yml.template"), f"""# TEMPLATE for a CI system that supports GitHub-Actions-style files. Not installed anywhere: copy it where your CI expects it.
name: {name}-submission-check
on: [pull_request]
jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {{python-version: "3.12"}}
      - run: pip install numpy
      - run: sh domains/{name}/out/ci_check.sh solvers/submission.py   # path to the solver under review
""")
        written.append(p)
    if "certificate" in targets:
        p = os.path.join(out, "CERTIFICATE.md")
        _write(p, f"""# Certificates for {name}

After a round is evaluated and its seeds revealed, one command bundles everything a third party needs:

    python3 certificate.py build --family {name} --submission solvers/x.py --seed-dir SEEDS/{name}-1 --reveal-seeds --out x.{name}.cert.json

Anyone can check it, with no access to the operator's machine:

    python3 certificate.py verify x.{name}.cert.json

`verify` re-derives every instance from the revealed seeds with this declaration, checks the hash chain and commitments, checks that the
rules (estimator, harness, declaration, compiled ladder) are the ones the certificate names, and recomputes the credit from the raw ladders.
Add `--rerun 5` to re-measure five random instances on your own machine.

Rules fingerprint of this domain: decl {compiled['decl_sha256'][:16]}..., reference {compiled['reference_sha256'][:16]}...
""")
        written.append(p)
    return written


# ------------------------------------------------------------------------------------------------------------- 7. self-test
def evaluate_controls(zero, none, positive, effect=SELFTEST_EFFECT):
    """Pure decision rule over the three control credits (None = inconclusive). -> (status, [results])"""
    res = []
    if zero is None:
        res.append(R("zero-effect control", "fail", "inconclusive: the ladder yields fewer than 2 usable difficulty bins, so the challenge could not certify anything"))
    elif zero >= THRESHOLD:
        res.append(R("zero-effect control", "fail", f"the reference measured against ITSELF earned {zero:.2f} bits (>= {THRESHOLD:g}): the estimator credits nothing as something"))
    else:
        res.append(R("zero-effect control", "pass", f"reference vs reference earned {zero:.2f} bits"))
    if none is None or none == 0:
        res.append(R("failure control", "pass", "a solver that never answers earned 0" if none == 0 else "a solver that never answers was inconclusive (earns nothing)"))
    else:
        res.append(R("failure control", "fail", f"a solver that never answers earned {none:.2f} bits"))
    if positive is None:
        res.append(R("known-effect control", "fail", "inconclusive on a known speedup: too few usable difficulty bins"))
    elif 0.4 <= positive <= effect + 0.3:
        res.append(R("known-effect control", "pass", f"a known {effect:g}-bit speedup earned {positive:.2f} bits"))
    else:
        res.append(R("known-effect control", "fail", f"a known {effect:g}-bit speedup earned {positive:.2f} bits (expected between 0.4 and {effect + 0.3:g})"))
    return ("pass" if all(r["status"] == "pass" for r in res) else "fail"), res


def _claim_bits(sub_path):
    with open(sub_path + ".claim.json", encoding="utf-8") as f:
        return json.load(f)["measured"]


def selftest(dirpath, mod, n, runner=subprocess.run, effect=SELFTEST_EFFECT, timeout=24 * 3600, log=_log):
    """Run the COMPILED domain through the real pipeline (judge.py evaluate -> harness -> extrapolate), local mode, throwaway seed."""
    name = mod.NAME
    ref = declared.reference_path(dirpath, mod)
    work = tempfile.mkdtemp(prefix="svp-selftest-")  # outside the project: the seed must not sit in the tree
    seed = os.path.join(work, "selftest.seed")
    fd = os.open(seed, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.write(fd, secrets.token_hex(32).encode())
    os.close(fd)
    with open(seed, "rb") as f:
        tag = hashlib.sha256(f.read().strip()).hexdigest()[:8]
    shutil.copyfile(ref, os.path.join(work, "control_zero.py"))
    _write(os.path.join(work, "control_none.py"), "def solve(*args):\n    return None\n")
    env = dict(os.environ, SVP_BOARD=os.path.join(work, "board.json"), SVP_DOMAINS_DIR=os.path.dirname(os.path.abspath(dirpath)))
    results = {}
    for ctrl in ("control_zero", "control_none"):
        cmd = [sys.executable, "judge.py", "evaluate", "--seed", seed, "--submission", os.path.join(work, ctrl + ".py"), "--family", name,
               "--n", str(n), "--insecure-local", "--reuse-baseline"]
        log(f"selftest: {ctrl} ({n} instances per size)")
        r = runner(cmd, cwd=HERE, env=env, capture_output=True, text=True, timeout=timeout)
        if r.returncode:
            return {"status": "fail", "n": n, "controls": [R(ctrl, "fail", (r.stdout + r.stderr)[-400:])], "work": work}
        results[ctrl] = os.path.join(HERE, "results", f"judged_{name}_{tag}_submission_{ctrl}.py.jsonl")
    base = os.path.join(HERE, "results", f"judged_{name}_{tag}_baseline_{os.path.basename(ref)}.jsonl")
    zero, none = _claim_bits(results["control_zero"]), _claim_bits(results["control_none"])
    scaled = os.path.join(work, "scaled_effect.jsonl")
    with open(results["control_zero"], encoding="utf-8") as f, open(scaled, "w", encoding="utf-8") as g:
        for line in f:
            rec = json.loads(line)
            if not rec.get("meta") and rec["status"] == "solved":
                rec["cpu_net"] = max(rec["cpu_net"] * 2 ** -effect, 1e-3)
            g.write(json.dumps(rec) + "\n")
    r = runner([sys.executable, "extrapolate.py", "--baseline", base, "--submission", scaled], cwd=HERE, env=env, capture_output=True, text=True, timeout=timeout)
    positive = _claim_bits(scaled) if r.returncode == 0 else None
    status, res = evaluate_controls(zero, none, positive, effect)
    return {"status": status, "n": n, "effect": effect, "controls": res, "credits": {"zero": zero, "none": none, "known_effect": positive},
            "ladders": {k: os.path.relpath(v, HERE) for k, v in results.items()} | {"baseline": os.path.relpath(base, HERE)},
            "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}


# ------------------------------------------------------------------------------------------------------------- driver
def _print(results):
    for r in results:
        print(f"  {r['status'].upper():4s} {r['check']}: {r['detail']}")


def compile_dir(dirpath, *, targets=("local", "server", "ci", "certificate"), skip_selftest=False, measure=None, k=3, n_prof=8, probe_budget=20,
                caps=CAPS, target_effect=2.0, target_power=0.8, pair_noise=0.6, triples=30, boot=60, selftest_n=None, runner=subprocess.run, log=_log):
    dirpath = os.path.abspath(dirpath)
    mod, ref, res = parse(dirpath)
    log("parse:")
    _print(res)
    if worst(res) == "fail":
        raise CompileError("the declaration did not parse")
    overhead = 0.0 if measure is not None else harness.calibrate()
    meas = measure or default_measure(mod, ref, PROFILE_SEED, probe_budget, overhead)
    log("validate:")
    val = validate(mod, dirpath, ref, measure=(lambda s, i: meas(s, i)) if measure is not None else None)
    _print(val)
    if worst(val) == "fail":
        raise CompileError("validation failed; nothing was compiled. Fix the FAIL items above.")
    with provisional(mod):
        pts, plan = profile_and_plan(mod, meas, k=k, n_prof=n_prof, probe_budget=probe_budget, caps=caps, log=log)
    pw = power_plan(plan, target_effect, target_power, pair_noise, triples, boot, log=log)
    compiled = build_compiled(mod, dirpath, ref, plan, pw, pts, overhead, res + val, {"status": "pending" if not skip_selftest else "skipped"})
    write_compiled(dirpath, compiled)
    emit(dirpath, mod, compiled, targets)
    log(f"compiled: cap {plan['cap']} s, sizes {plan['sizes']}, n={pw['n']}, min certifiable effect {pw['min_certifiable_effect']} bits, "
        f"worst-case {compiled['cpu_hours']['worst_case']} CPU-h per submission")
    for note in plan["notes"] + pw["notes"]:
        log("  NOTE " + note)
    if not skip_selftest:
        # default: the chosen official n. A smaller n has less power than the compile just certified, so a known-effect control that fails at it
        # would say nothing about the compiled system (the power analysis already said n=12 certified a 2-bit effect only 23% of the time on dlog)
        st = selftest(dirpath, mod, pw["n"] if selftest_n is None else min(selftest_n, pw["n"]), runner=runner, log=log)
        compiled["selftest"] = st
        write_compiled(dirpath, compiled)
        emit(dirpath, mod, compiled, targets)
        log("selftest:")
        _print(st["controls"])
    return compiled


TEMPLATE_DECL = '''"""Declaration of the @@NAME@@ domain. This is a WORKING starting point (find x with g^x = h mod p); it already passes `compile_domain.py check`.
Change the parts marked EDIT to your own problem, keep the shape. Full reference: COMPILER.md. A larger worked example: domains/dlog."""
import hashlib
import hmac
import random

import instances  # EDIT (optional): the project's Miller-Rabin primality test; remove if you do not need primes

NAME = "@@NAME@@"            # fixed: must equal this directory's name
VERSION = "@@NAME@@-v1"      # EDIT: bump whenever derive() changes (old results then refuse to mix with new ones)
SIZE_RANGE = (16, 40)        # EDIT: the sizes the compiler may use. It finds the ladder inside this range, so be generous
SIZE_STEP = 1                # EDIT: 2 if only every other size is meaningful (e.g. even bit lengths)
REFERENCE_SOLVER = "reference.py"
DOC = "solve(p, g, h): return an integer x with pow(g, x, p) == h, 0 <= x < p - 1. Return None for no answer."   # EDIT: shown to solver authors
REFERENCE_NOTE = "A plain linear scan over exponents. Baby-step/giant-step is known to beat it by about size/2 bits."   # EDIT: what the reference is and what is known to beat it


def derive(master: bytes, size: int, idx: int) -> dict:
    """EDIT: build instance number `idx` of size `size` from the secret `master`, and NOTHING else (no clock, no global random, no files).
    Return {"args": [...JSON values the solver receives...], "planted": <a valid answer; it never reaches the solver>}."""
    rng = random.Random(hmac.new(master, f"@@NAME@@-v1:{size}:{idx}".encode(), hashlib.sha256).digest())
    while True:
        p = rng.getrandbits(size + 2) | (1 << (size + 1)) | 1
        if instances._is_prime(p):
            break
    g = rng.randrange(2, p - 1)
    x = rng.randrange(1, min(1 << size, p - 1))
    return {"args": [p, g, pow(g, x, p)], "planted": x}


def verify(inst: dict, ans) -> bool:
    """EDIT: an exact check of an answer. It must reject None, 0, 1, strings and lists of the wrong kind: an answer a solver can guess is a bug."""
    p, g, h = inst["args"]
    return isinstance(ans, int) and not isinstance(ans, bool) and 0 <= ans < p - 1 and pow(g, ans, p) == h
'''

TEMPLATE_REF = '''"""EDIT: the baseline every submission is measured against: the plain, honest algorithm. Self-contained (it runs in a sandbox that has
only the standard library, numpy and fpylll). Called as solve(*args); return an int, a list of ints, or None."""


def solve(p, g, h):
    cur = 1
    for x in range(p - 1):
        if cur == h:
            return x
        cur = cur * g % p
    return None
'''


def cmd_init(a):
    """Scaffold a WORKING declaration (so there is always something that passes `check` to edit from), and validate it at once."""
    if a.blank:
        return cmd_init_blank(a)
    if getattr(a, "kind", None):
        return cmd_init_kind(a)
    d = os.path.join(declared.domains_dir(), a.name)
    if not declared.NAME_RE.fullmatch(a.name):   # fullmatch: the pinned pattern's `$` would also accept a trailing newline (declared.py cannot change while a round is open: POSTFREEZE.md)
        raise SystemExit("REFUSED: NAME must be 2-16 lowercase letters a-z (no digits, hyphens or capitals)")
    if a.name in BUILTIN or os.path.exists(d):
        raise SystemExit(f"REFUSED: {d} exists or {a.name!r} is a built-in family; nothing was written")
    _write(os.path.join(d, "decl.py"), TEMPLATE_DECL.replace("@@NAME@@", a.name))
    _write(os.path.join(d, "reference.py"), TEMPLATE_REF)
    mod, ref, res = parse(d)
    res += validate(mod, d, ref, run_reference=False) if mod else []
    print(f"created {d}/decl.py and reference.py: a working discrete-log example. It already validates:" if worst(res) != "fail"
          else f"created {d}, but the template did not validate (this is a bug in the scaffold):")
    _print(res)
    print(f"""
next:
  1. edit the lines marked EDIT in decl.py (derive, verify, DOC, SIZE_RANGE) and reference.py (the baseline solver)
  2. python3 compile_domain.py check {a.name}        # seconds; tells you exactly what to fix
  3. python3 compile_domain.py compile {a.name} --quick    # a 1-2 minute draft to see the ladder (practice only)
  4. python3 compile_domain.py compile {a.name}            # the real thing: tens of minutes to hours, official-eligible
  5. python3 compile_domain.py show {a.name}               # plain-English summary and the exact next commands""")


def cmd_init_kind(a):
    """init --kind advantage|oracle|precomp|quantum: a WORKING declaration of that kind (compile_kinds.scaffold), validated at once."""
    import compile_kinds
    try:
        d = compile_kinds.scaffold(a.kind, a.name, declared.domains_dir())
    except CompileError as e:
        raise SystemExit(f"REFUSED: {e}")
    if a.name in BUILTIN:
        shutil.rmtree(d)
        raise SystemExit(f"REFUSED: {a.name!r} is a built-in family; nothing was written")
    mod, ref, res = parse(d)
    if mod is not None:
        res += compile_kinds.validate(compile_kinds.load(d), d, ref, quick=True)
    print(f"created {d}/decl.py and reference.py: the worked {a.kind} example (see NONFITTING.md).")
    _print(res)
    print(f"""
next: edit decl.py / reference.py, then  {compile_kinds.cmd('compile', 'check ' + a.name)}   and   {compile_kinds.cmd('compile', 'compile ' + a.name)}
      run solvers with  {compile_kinds.cmd('kinds', 'evaluate ' + a.name + ' SOLVER --out LADDER')}   (this kind is not a speed family)""")


def cmd_init_blank(a):
    d = os.path.join(declared.domains_dir(), a.name)
    if not declared.NAME_RE.fullmatch(a.name):   # fullmatch, as in cmd_init
        raise SystemExit("REFUSED: NAME must be 2-16 lowercase letters a-z")
    if a.name in BUILTIN or os.path.exists(d):
        raise SystemExit(f"REFUSED: {d} exists or {a.name!r} is a built-in family; nothing was written")
    _write(os.path.join(d, "decl.py"), f'''"""Declaration of the {a.name} domain. Fill in derive/verify; see COMPILER.md and domains/dlog for a worked example."""
import hashlib
import hmac
import random

NAME = "{a.name}"                 # must equal this directory's name: 2-16 lowercase letters
VERSION = "{a.name}-v1"           # bump whenever derive() changes
SIZE_RANGE = (16, 40)             # sizes the compiler may use; it finds the ladder inside this range
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
DOC = "solve(...): describe what the solver receives and must return (an integer, a list of integers, or None)."
REFERENCE_NOTE = "What the reference algorithm is, and what is known to beat it."   # a weak reference makes big speedups cheap


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"{a.name}-v1:{{size}}:{{idx}}".encode(), hashlib.sha256).digest())  # everything from (master, size, idx)
    raise NotImplementedError("return {{'args': [...JSON values the solver receives...], 'planted': <a valid answer>}}")


def verify(inst: dict, ans) -> bool:
    raise NotImplementedError("exact check of an answer; must reject None, 0, 1, strings, lists of the wrong kind")
''')
    _write(os.path.join(d, "reference.py"), '"""The baseline every submission is measured against. Self-contained: no imports of the judge\'s modules."""\n\n\ndef solve(*args):\n    raise NotImplementedError\n')
    print(f"wrote {d}/decl.py and reference.py; next: edit them, then  python3 compile_domain.py compile {d}")


def verdict(compiled):
    """(level, lines): the plain-English reading of a compiled record, with the exact commands to run next."""
    name, pw = compiled["name"], compiled["power"]
    st = (compiled.get("selftest") or {}).get("status", "pending")
    notes = list(compiled["plan"]["notes"]) + list(pw["notes"])
    mce, top = pw["min_certifiable_effect"], pw.get("max_certifiable_effect")
    cap, n, dims, cost = compiled["official"]["budget"], compiled["official"]["n"], compiled["dims"], compiled["cpu_hours"]
    if st == "fail" or mce is None:
        level = "NOT READY"
    elif st in ("skipped", "pending"):
        level = "DRAFT (practice only: no official round until it passes the self-test)"
    elif notes:
        level = "READY, WITH NOTES (read them: they say how far to trust the ladder)"
    else:
        level = "READY"
    lines = [f"{name}: {level}",
             f"  the challenge : sizes {dims}, CPU cap {cap} s, {n} instances per size; one submission costs about {cost['expected']} CPU-hours (worst case {cost['worst_case']})",
             "  it can certify: " + (f"speedups from about {mce:g} to about {top:g} bits over your reference" if mce is not None else
                                     "NOTHING on the grid tried: the ladder is too weak (see the notes)"),
             f"  self-test     : {st}"]
    lines += [f"  note          : {x}" for x in notes]
    if level == "NOT READY":
        why = ("a control failed: python3 compile_domain.py selftest " + name + "  (prints which one and why)" if st == "fail" else
               "widen SIZE_RANGE, or let the reference's cost grow faster with size, then compile again")
        nxt = [why]
    else:
        nxt = [f"python3 submit_check.py my_solver.py --family {name}      # try a solver on public practice sizes"]
        if st in ("skipped", "pending"):
            nxt.append(f"python3 compile_domain.py compile {name}                 # the full compile with the self-test (official-eligible)")
        else:
            nxt.append(f"python3 ops.py round-new --data DATA --seed-dir SEEDS --id {name}-1 --title \"{name} round 1\" --family {name} --closes <UTC> --n {n}")
            nxt.append("python3 certificate.py build ... / verify ...           # after the round: see domains/" + name + "/out/CERTIFICATE.md")
    lines += ["  next:"] + [f"    {x}" for x in nxt]
    return level, lines


def cmd_show(a):
    d = _resolve(a.name)
    mod = _load(d, a.name)
    compiled = declared.read_compiled(d)
    problems = _fresh(d, mod, compiled)
    if problems:
        raise SystemExit("not compiled, or stale: " + "; ".join(problems) + f"\n  run: python3 compile_domain.py compile {a.name}")
    if compiled.get("kind") == "quality":
        import compile_quality
        print("\n".join(compile_quality.verdict(compiled)[1]))
        return
    if compiled.get("kind") in KIND_NAMES:
        import compile_kinds
        print("\n".join(compile_kinds.verdict(compiled)[1]))
        return
    print("\n".join(verdict(compiled)[1]))
    print(f"\n  the full text: {os.path.join(d, 'out', 'CHALLENGE.md')}")


QUICK = dict(k=3, n_prof=4, probe_budget=5.0, caps=[30], trials=8, boot=30, skip_selftest=True)


def cmd_compile(a):
    if a.quick:  # a draft in minutes, for iterating on a declaration: small samples, one cap, no self-test (so never official-eligible)
        for k, v in QUICK.items():
            setattr(a, k, v)
        print("--quick: a DRAFT with small samples and no self-test; good for iterating, not for a real round. Run without --quick when the declaration is final.")
    else:
        print("this runs your reference solver for real (tens of minutes to hours: the confirming step alone is n-prof instances at up to the cap, per size).\n"
              "  to iterate faster use --quick (1-2 minutes). Progress prints as it goes.")
    a.dir = _resolve(a.dir)
    qmod = _load(a.dir, a.dir)
    if getattr(qmod, "KIND", None) in KIND_NAMES:   # advantage / oracle / precomp / quantum: compile_kinds.py (NONFITTING.md); the speed passes below do not apply
        import compile_kinds
        try:
            c = compile_kinds.compile_dir(a.dir, quick=a.quick)
        except CompileError as e:
            raise SystemExit(f"REFUSED: {e}\n  (nothing was written; `python3 compile_domain.py check {a.dir}` re-runs just the validation)")
        print("\n" + "\n".join(compile_kinds.verdict(c)[1]))
        return
    if callable(getattr(qmod, "quality", None)):   # a quality challenge has its own compile (compile_quality.py): the speed passes below do not apply
        import compile_quality
        try:
            c = compile_quality.compile_dir(a.dir, quick=a.quick, target_power=a.power, skip_selftest=a.skip_selftest)
        except CompileError as e:
            raise SystemExit(f"REFUSED: {e}\n  (nothing was written; `python3 compile_domain.py check {a.dir}` re-runs just the validation in seconds)")
        print("\n" + "\n".join(compile_quality.verdict(c)[1]))
        if c["selftest"].get("status") == "fail":
            raise SystemExit("SELF-TEST FAILED: see the controls above")
        return
    try:
        c = compile_dir(a.dir, targets=("local", "server", "ci", "certificate") if a.target == "all" else (a.target,), skip_selftest=a.skip_selftest,
                        k=a.k, n_prof=a.n_prof, probe_budget=a.probe_budget, caps=tuple(a.caps), target_effect=a.target_effect, target_power=a.power,
                        pair_noise=a.pair_noise, triples=a.trials, boot=a.boot, selftest_n=a.selftest_n)
    except CompileError as e:
        raise SystemExit(f"REFUSED: {e}\n  (nothing was written; `python3 compile_domain.py check {a.dir}` re-runs just the validation in seconds)")
    print("\n" + "\n".join(verdict(c)[1]))
    if c["selftest"].get("status") == "fail":  # the record is written either way (it says why); the exit code must not claim success
        raise SystemExit("SELF-TEST FAILED: the domain is compiled but no official round can be created for it (see the controls above)")


def _fresh(d, mod, compiled):
    """declared.freshness_problems, except that a QUALITY record is judged by compile_quality.freshness_problems (its format differs from a speed record's on purpose)."""
    if (compiled or {}).get("kind") == "quality":
        import compile_quality
        return compile_quality.freshness_problems(d, mod, compiled)
    if getattr(mod, "KIND", None) in KIND_NAMES or (compiled or {}).get("kind") in KIND_NAMES:
        import compile_kinds
        return compile_kinds.freshness_problems(d, mod, compiled)
    return declared.freshness_problems(d, mod, compiled)


def _resolve(arg):
    """A NAME means domains/NAME (even if a same-named directory sits in the current one); anything with a path separator is a path."""
    if os.sep not in arg and not arg.startswith("."):
        named = os.path.join(declared.domains_dir(), arg)
        if os.path.isdir(named) or not os.path.isdir(arg):
            return named
    return arg


def _load(d, name):
    """declared.load_declaration, but a missing or broken declaration exits with a sentence instead of a traceback."""
    try:
        return declared.load_declaration(d)
    except declared.DeclarationError as e:
        raise SystemExit(f"REFUSED: {e}\n  (a declaration lives in domains/NAME/decl.py; `python3 compile_domain.py init {name}` creates one, "
                         "`python3 compile_domain.py status` lists them)")


def cmd_check(a):
    d = _resolve(a.dir)
    mod, ref, res = parse(d)
    if worst(res) != "fail":
        isq = callable(getattr(mod, "quality", None))
        if getattr(mod, "KIND", None) in KIND_NAMES:   # the speed validation assumes a witness-shaped answer: these kinds have their own (compile_kinds.validate)
            import compile_kinds
            res += compile_kinds.validate(compile_kinds.load(d), d, ref, quick=True) if not a.no_reference else [R("reference", "warn", "skipped (--no-reference)")]
        else:
            res += validate(mod, d, ref, run_reference=not a.no_reference, quality=mod.quality if isq else None)
        if isq:
            import compile_quality
            res += compile_quality.quality_validation(mod, d)
        problems = _fresh(d, mod, declared.read_compiled(d))
        res.append(R("compiled record", "fail" if problems else "pass", "; ".join(problems) if problems else "compiled.json matches decl.py and the reference"))
    _print(res)
    failed = [r for r in res if r["status"] == "fail"]
    nm = os.path.basename(os.path.abspath(d))
    if not failed:
        print(f"\nOK: the declaration is valid and its compiled record is current.  python3 compile_domain.py show {nm}")
    elif all(r["check"] == "compiled record" for r in failed):
        print(f"\nThe declaration is VALID; it is just not compiled (or was edited since).  python3 compile_domain.py compile {nm} --quick   (draft, minutes)"
              f"   or   python3 compile_domain.py compile {nm}   (the real one)\n(exit status 1 on purpose: CI should not accept an uncompiled domain)")
    else:
        print(f"\n{len(failed)} problem(s) above: each FAIL line says what is wrong; fix decl.py or reference.py and run this again.")
    sys.exit(1 if failed else 0)


def cmd_recheck(a):
    import recheck
    d = _resolve(a.name)
    _load(d, a.name)
    if (declared.read_compiled(d) or {}).get("kind") in KIND_NAMES:
        raise SystemExit("REFUSED: recheck re-derives a SPEED ladder's claims; for this kind use `python3 compile_kinds.py replay` on a ladder")
    if (declared.read_compiled(d) or {}).get("kind") == "quality":
        raise SystemExit("REFUSED: recheck re-derives a SPEED ladder's claims; for a quality challenge use `compile_domain.py selftest NAME` and the bundle's own checks")
    if a.save and not a.measure:
        raise SystemExit("REFUSED: --save stores the --measure results; add --measure K")
    if a.save and os.path.exists(a.save):
        raise SystemExit(f"REFUSED: {a.save} exists; measurement files are never overwritten")
    res = recheck.recheck(d, measure_k=a.measure)
    _print(res)
    if a.save:
        recheck.save_measurements(res, declared.read_compiled(d), a.save)
        print(f"\nsaved {a.save}: send it to whoever merges them with `compile_domain.py spread FILE FILE ...` (it contains a hash of this host's name, not the name)")
    failed = [r for r in res if r["status"] == "fail"]
    print("\nrecheck: every recomputable claim reproduces." if not failed else f"\nrecheck: {len(failed)} claim(s) did NOT reproduce (FAIL lines above).")
    sys.exit(1 if failed else 0)


def cmd_spread(a):
    import recheck
    res, rec = recheck.spread(a.files)
    _print(res)
    sys.exit(1 if any(r["status"] == "fail" for r in res) else 0)


def cmd_selftest(a):
    d = _resolve(a.name)
    mod = _load(d, a.name)
    compiled = declared.read_compiled(d)
    problems = _fresh(d, mod, compiled)
    if problems:
        raise SystemExit("REFUSED: " + "; ".join(problems))
    if compiled.get("kind") in KIND_NAMES:
        raise SystemExit("REFUSED: this kind has no speed self-test; `python3 compile_domain.py compile NAME` runs its validation, `python3 compile_kinds.py replay` re-checks a ladder")
    if compiled.get("kind") == "quality":
        import compile_quality
        qc = compiled["quality"]
        st = compile_quality.selftest(qc["simulation"], compiled["official"]["n"] if a.n is None else min(a.n, compiled["official"]["n"]), qc["min_gain"], qc["power"]["noise"])
        compiled["selftest"] = st
        write_compiled(d, compiled)
        _print(st["controls"])
        sys.exit(0 if st["status"] == "pass" else 1)
    st = selftest(d, mod, compiled["official"]["n"] if a.n is None else min(a.n, compiled["official"]["n"]))
    compiled["selftest"] = st
    write_compiled(d, compiled)
    emit(d, mod, compiled)
    _print(st["controls"])
    sys.exit(0 if st["status"] == "pass" else 1)


def cmd_emit(a):
    d = _resolve(a.name)
    mod = _load(d, a.name)
    compiled = declared.read_compiled(d)
    problems = _fresh(d, mod, compiled)
    if problems:
        raise SystemExit("REFUSED: " + "; ".join(problems))
    if compiled.get("kind") in KIND_NAMES:
        raise SystemExit("REFUSED: this kind is not a speed family: there is no judge/server kit to emit (`python3 compile_kinds.py --help`)")
    if compiled.get("kind") == "quality":
        raise SystemExit("REFUSED: a quality challenge has no speed-round kit to emit; `compile_domain.py export NAME` writes its bundle")
    for p in emit(d, mod, compiled, ("local", "server", "ci", "certificate") if a.target == "all" else (a.target,)):
        print("wrote", p)


def cmd_export(a):
    if (declared.read_compiled(_resolve(a.name)) or {}).get("kind") in KIND_NAMES:
        raise SystemExit("REFUSED: no portable bundle for this kind yet (NONFITTING.md, 'Not done'); `python3 compile_kinds.py evaluate|score|compare|replay` is how it runs")
    import export_bundle
    argv = ["export", a.name, "--field", a.field] + (["--out", a.out] if a.out else []) + (["--no-selftest"] if a.no_selftest else [])
    sys.exit(export_bundle.main(argv))


def cmd_status(a):
    root = declared.domains_dir()
    for entry in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        d = os.path.join(root, entry)
        if not os.path.isfile(os.path.join(d, declared.DECL)):
            continue
        reg = entry in families.DECLARED
        c = declared.read_compiled(d)
        st = ((c or {}).get("selftest") or {}).get("status", "-")
        if (c or {}).get("kind") in KIND_NAMES:
            import compile_kinds
            old = c.get("compiler_sha256") != compile_kinds.compiler_sha256()   # these kinds are compiled by compile_kinds.py and the cores it names
        else:
            old = bool(c) and c.get("compiler_sha256") != _sha(os.path.abspath(__file__))  # advisory: the registry only checks decl.py and the reference
        why = ("quality challenge: a bundle, not a speed family (no judge/portal rounds); `compile_domain.py export` writes it" if (c or {}).get("kind") == "quality"
               else f"{c['kind']} challenge: not a speed family (no judge/portal rounds); run it with `python3 compile_kinds.py`" if (c or {}).get("kind") in KIND_NAMES
               else families.DECLARED_ERRORS.get(entry, "unknown"))
        print(f"{entry:14s} {'REGISTERED' if reg else 'not registered':15s} selftest={st:8s}" + ("" if reg else f"  ({why})")
              + ("  [compiled by an older compile_domain.py: consider compiling again]" if old else ""))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter, epilog="""\
the whole workflow (a NAME is 2-16 lowercase letters; every command also accepts a path like domains/NAME):
  python3 compile_domain.py init NAME             a working example to edit (the lines marked EDIT)
  python3 compile_domain.py check NAME            seconds: what is wrong with the declaration, and how to fix it
  python3 compile_domain.py compile NAME --quick  minutes: a draft ladder, for iterating
  python3 compile_domain.py compile NAME          the real compile + self-test (long); prints a READY / NOT READY verdict
  python3 compile_domain.py show NAME             that verdict again, with the exact next commands
  python3 compile_domain.py status                every declaration: registered? self-tested? stale?
more: COMPILER.md""")
    sub = ap.add_subparsers(dest="cmd", required=True, metavar="{init,check,compile,show,selftest,emit,export,status,recheck,spread}")
    p = sub.add_parser("init", help="scaffold a WORKING declaration to edit")
    p.add_argument("name")
    p.add_argument("--blank", action="store_true", help="a skeleton with NotImplementedError instead of the working example")
    p.add_argument("--kind", choices=("advantage", "oracle", "precomp", "quantum"), help="a working example of a KIND that is not a speed challenge (NONFITTING.md)")
    p = sub.add_parser("show", help="plain-English summary of a compiled domain and the next commands")
    p.add_argument("name")
    p = sub.add_parser("compile", help="validate, profile, choose the ladder, simulate power, emit, self-test")
    p.add_argument("dir", metavar="NAME_or_dir")
    p.add_argument("--quick", action="store_true", help="a 1-2 minute DRAFT (small samples, no self-test): practice only, for iterating")
    p.add_argument("--target", choices=["local", "server", "ci", "certificate", "all"], default="all")
    p.add_argument("--skip-selftest", action="store_true", help="the domain can then be practised but no OFFICIAL round can be created for it")
    p.add_argument("--k", type=int, default=5, help="instances per size in the coarse probe")
    p.add_argument("--n-prof", type=int, default=8, help="instances per ladder size in the confirming measurement")
    p.add_argument("--probe-budget", type=float, default=20, help="CPU-second cap during the coarse probe")
    p.add_argument("--caps", type=int, nargs="+", default=list(CAPS), help="CPU caps the optimizer may choose from")
    p.add_argument("--target-effect", type=float, default=2.0, help="speedup (bits) the chosen n must certify with --power probability")
    p.add_argument("--power", type=float, default=0.8)
    p.add_argument("--pair-noise", type=float, default=0.6, help="ASSUMED sd (bits) of a submission's per-instance log2 speedup; measured values in this project: see PROTOCOL.md")
    p.add_argument("--trials", type=int, default=30, help="independent seed triples per power estimate")
    p.add_argument("--boot", type=int, default=60)
    p.add_argument("--selftest-n", type=int, default=None, help="instances per size in the self-test (default: the chosen official n; fewer saves machine time but then "
                   "the known-effect control may fail for lack of power, not because anything is broken)")
    p = sub.add_parser("check")
    p.add_argument("dir")
    p.add_argument("--no-reference", action="store_true", help="skip running the reference solver (CI without the solver's dependencies)")
    p = sub.add_parser("selftest")
    p.add_argument("name")
    p.add_argument("--n", type=int, default=None, help="instances per size (default: the compiled official n)")
    p = sub.add_parser("emit")
    p.add_argument("name")
    p.add_argument("--target", choices=["local", "server", "ci", "certificate", "all"], default="all")
    p = sub.add_parser("export", help="write a platform-neutral challenge bundle (checker, scorer, power analysis, manifest) for a compiled, fresh domain; see COMPILER.md")
    p.add_argument("name")
    p.add_argument("--out", help="bundle directory (default domains/NAME/out/bundle-VERSION-HASH); never overwritten")
    p.add_argument("--field", default="Computer Science", help="the Field entry PROPOSAL.md pre-fills")
    p.add_argument("--no-selftest", action="store_true", help="skip the clean-interpreter self-test of the bundle")
    p = sub.add_parser("recheck", help="recompute the compiled record's checkable claims (and optionally re-measure on this machine). "
                       "Executes the declaration and reference unsandboxed: only for declarations you have read")
    p.add_argument("name")
    p.add_argument("--measure", type=int, default=0, metavar="K", help="also re-measure each ladder size with K instances here and report the gap to the recorded profile")
    p.add_argument("--save", metavar="FILE", help="write the --measure gaps to FILE (never overwritten) so measurements from several machines can be merged with `spread`")
    p = sub.add_parser("spread", help="merge --save files from different machines and recommend a re-measurement tolerance")
    p.add_argument("files", nargs="+")
    sub.add_parser("status")
    a = ap.parse_args(argv)
    {"init": cmd_init, "compile": cmd_compile, "check": cmd_check, "selftest": cmd_selftest, "emit": cmd_emit, "status": cmd_status,
     "show": cmd_show, "recheck": cmd_recheck, "spread": cmd_spread, "export": cmd_export}[a.cmd](a)


if __name__ == "__main__":
    main()
