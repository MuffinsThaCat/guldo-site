"""Tool use with a final-state check: move money between accounts until every account holds at least a minimum.

size = number of accounts (4..12). The balances and the minimum are a pure function of the instance seed. Tools: `balances` (all accounts at once), `balance` (one account),
`transfer` (src, dst, amount). A transfer that would overdraw its source is refused and changes nothing. The judge does NOT trust the harness's state: it REPLAYS the recorded
tool calls on a fresh copy of the instance and checks the final balances (every account >= minimum, total unchanged, nothing negative). Fewer, better-chosen calls are cheaper;
a wrong or incomplete state fails whatever the agent says in its final message.
"""
import agent_core

NAME = "toolstate"
VERSION = "toolstate-v1"
SIZE_RANGE = (4, 12)
SIZE_STEP = 2
DOC = "Make every account hold at least the minimum balance using transfers, then submit the word done."


def _names(k):
    return ["A%02d" % (i + 1) for i in range(k)]


def derive(seed, size):
    r = agent_core.Rng(seed)
    for _ in range(500):
        bal = [r.randint(0, 1000) for _ in range(size)]
        total = sum(bal)
        minimum = (total * 7) // (size * 10)
        if minimum >= 20 and any(b < minimum for b in bal) and sum(max(0, b - minimum) for b in bal) >= sum(max(0, minimum - b) for b in bal):
            names = _names(size)
            return {"public": {"task": "There are %d accounts named %s. Every account must end with a balance of at least %d. Move money between accounts with the `transfer` tool "
                                       "(the total never changes; a transfer that would overdraw its source is refused). When every account is at or above %d, submit the word done."
                                       % (size, ", ".join(names), minimum, minimum), "accounts": names, "minimum": minimum},
                    "private": {"initial": dict(zip(names, bal))}}
    raise RuntimeError("could not derive a feasible instance")


def prompt(public):
    return public["task"]


def tool_specs(public):
    return [
        {"name": "balances", "description": "All account balances.", "input_schema": {"type": "object", "properties": {}}},
        {"name": "balance", "description": "One account's balance.", "input_schema": {"type": "object", "properties": {"account": {"type": "string"}}, "required": ["account"]}},
        {"name": "transfer", "description": "Move `amount` (a positive integer) from `src` to `dst`.",
         "input_schema": {"type": "object", "properties": {"src": {"type": "string"}, "dst": {"type": "string"}, "amount": {"type": "integer"}}, "required": ["src", "dst", "amount"]}},
    ]


class Env:
    def __init__(self, instance):
        self.bal = dict(instance["private"]["initial"])

    def call(self, name, args):
        if not isinstance(args, dict):
            return "error: arguments must be an object"
        if name == "balances":
            return ", ".join("%s=%d" % (k, self.bal[k]) for k in sorted(self.bal))
        if name == "balance":
            a = args.get("account")
            return ("%s=%d" % (a, self.bal[a])) if isinstance(a, str) and a in self.bal else "error: unknown account"
        if name == "transfer":
            s, d, amt = args.get("src"), args.get("dst"), args.get("amount")
            if not isinstance(s, str) or not isinstance(d, str) or s not in self.bal or d not in self.bal or s == d:
                return "error: unknown or identical accounts"
            if not isinstance(amt, int) or isinstance(amt, bool) or amt < 1:
                return "error: amount must be a positive integer"
            if self.bal[s] < amt:
                return "error: insufficient funds in %s (%d)" % (s, self.bal[s])
            self.bal[s] -= amt
            self.bal[d] += amt
            return "ok: %s=%d, %s=%d" % (s, self.bal[s], d, self.bal[d])
        return "error: unknown tool %r" % name


def make_env(instance):
    return Env(instance)


def reference_answer(instance):
    """A cheap correct plan: the final answer is just 'done'; the plan itself is in reference_calls."""
    return "done"


def reference_calls(instance):
    """A minimal-style plan (greedy): used by the scripted lean agent and by the domain checks. Judge-side knowledge only."""
    bal = dict(instance["private"]["initial"])
    m = instance["public"]["minimum"]
    calls = []
    donors = sorted((k for k in bal if bal[k] > m), key=lambda k: -bal[k])
    for need in sorted((k for k in bal if bal[k] < m), key=lambda k: bal[k]):
        while bal[need] < m:
            src = next(k for k in donors if bal[k] > m)
            amt = min(bal[src] - m, m - bal[need])
            calls.append({"name": "transfer", "args": {"src": src, "dst": need, "amount": amt}})
            bal[src] -= amt
            bal[need] += amt
    return calls


def verify(instance, answer, calls):
    env = Env(instance)
    for c in calls:
        if c.get("name") in ("balances", "balance", "transfer"):
            env.call(c["name"], c.get("args", {}))
    m = instance["public"]["minimum"]
    if sum(env.bal.values()) != sum(instance["private"]["initial"].values()):
        return False, "total changed"
    if any(v < 0 for v in env.bal.values()):
        return False, "negative balance"
    low = [k for k, v in env.bal.items() if v < m]
    if low:
        return False, "below the minimum: %s" % ",".join(sorted(low))
    return True, "ok"
