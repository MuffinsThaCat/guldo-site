"""Counted ladders with BYTES MOVED, PRECISION and PEAK MEMORY as well as operations (tflops.py's sibling; see tensorops_mem.py for the accounting convention).

  python3 tflops_mem.py practice SOLVER --baseline REF --family aitrain --dims 32 40 48 --n 4 --cap 800 [--seed SEEDFILE] [--reuse-baseline]
  python3 tflops_mem.py verify LADDER [LADDER ...] [--rerun K|all] [--seed SEEDFILE] [--solvers DIR]
  python3 tflops_mem.py selfcheck SOLVER --family aitrain --dim 32          does the same instance count the same twice (operations, bytes AND peak)?

A solver is written exactly as for tflops.py (the restricted subset plus `import tensorops as tp`), and may also call `tp.cast(x, "fp32" | "fp16")`. The ladder records, per instance, the
operations (`flops` + `steps`, as before), `bytes` moved and `peak_bytes` of live tensors, all exact: `verify` redoes the arithmetic of every record and, with --rerun, re-executes
records and demands IDENTICAL status, operations, bytes and peak. `cpu` is still operations / 1e7, so a ladder reads like a tflops one; tflops_compare.py compares two solvers on
any of the three costs (--metric ops | bytes | peak).

It is NOT a time, a kernel measurement, a cache model or a hardware counter: an accounting convention over shapes and declared precisions that anyone can recompute exactly.
It needs Python 3.12+ and the same unprivileged-throwaway-user care as tflops.py (the solver runs in the operator's process tree, contained by the restricted subset and a
parent-side memory watchdog, not by a sandbox).
"""
import argparse
import hashlib
import json
import os
import random
import secrets
import sys
import tempfile
import time

import instances
import tflops

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(HERE, "tflops_mem_runner.py")
COST_MODEL = "tflops-mem"
COUNTER_FILES = ("tflops_mem_runner.py", "tensorops_mem.py", "tensorops.py", "count_runner.py")
UNIT_OPS = tflops.UNIT_OPS
MIN_PYTHON = tflops.MIN_PYTHON
NEXT_HINT = "next: compare two solvers on any cost with: python3 tflops_compare.py compare BASELINE A B --metric ops|bytes|peak"   # `python3 NAME.py` is what the installed `guldo` command rewrites
CLAIM_LIMITS = ("A count is not a time. Operations, bytes and peak memory are an accounting convention over shapes and declared precisions (no cache, no fusion, no kernel or hardware "
                "measurement), exactly reproducible by anyone, so they can show 'N times fewer operations / bytes / memory' and cannot show 'faster'. The ladder is the prover's "
                "unless it was fixed in advance.")


def counter_sha256():
    h = hashlib.sha256()
    for name in COUNTER_FILES:
        with open(os.path.join(HERE, name), "rb") as f:
            h.update(name.encode() + b"\0" + hashlib.sha256(f.read()).digest())
    return h.hexdigest()


def count_instance(solver, inst, verify, cap, max_rss_mb=tflops.MAX_RSS_MB):
    """Run `solver` on `inst` under counting. -> a ladder record: id, dim, status, steps, flops, bytes, peak_bytes, cpu, cpu_net, wall."""
    limit = int(cap * UNIT_OPS)
    rec = {"id": inst["id"], "dim": inst["dim"]}
    payload = json.dumps({"args": inst["args"], "limit": limit}).encode()
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "1", "PATH": os.environ.get("PATH", "")}
    t0 = time.time()
    with tempfile.TemporaryDirectory() as empty:
        stdout, stderr, killed = tflops._run_watched([sys.executable, "-B", RUNNER, os.path.abspath(solver)], payload, env, empty, limit / tflops.SLOW_OPS_PER_SECOND + 120, max_rss_mb)
    rec["wall"] = time.time() - t0
    none = {"steps": None, "flops": None, "bytes": None, "peak_bytes": None, "profile": None}
    if killed == "wall":
        rec.update({"status": "timeout", **none, "wall_timeout": True, "cpu": cap, "cpu_net": cap})
        return rec
    if killed == "memory":
        rec.update({"status": "crash", **none, "cpu": cap, "cpu_net": cap, "err": f"killed: resident memory passed {max_rss_mb} MB"})
        return rec
    lines = [ln for ln in stdout.decode(errors="replace").splitlines() if ln.strip()]
    try:
        out = json.loads(lines[-1])
        steps, flops, moved, peak, status = int(out["steps"]), int(out["flops"]), int(out["bytes"]), int(out["peak"]), out["status"]
        profile = [[int(f), int(b), int(n)] for f, b, n in out["profile"]]
    except (IndexError, ValueError, KeyError, TypeError):
        rec.update({"status": "crash", **none, "cpu": cap, "cpu_net": cap, "err": "the counter produced no result: " + stderr.decode(errors="replace")[-300:]})
        return rec
    rec.update({"steps": steps, "flops": flops, "bytes": moved, "peak_bytes": peak, "profile": profile})
    if status == "limit":
        rec.update({"status": "timeout", "cpu": cap, "cpu_net": cap})
    elif status == "error":
        rec.update({"status": "crash", "cpu": cap, "cpu_net": cap, "err": str(out.get("err", ""))[-1500:]})
    else:
        ans = out.get("ans")
        try:
            ok = bool(verify(inst, ans))
        except Exception as e:     # a verifier that RAISES is the operator's bug, not a wrong answer: say so in the record
            ok = False
            rec["verify_error"] = f"{type(e).__name__}: {str(e)[:200]}"
        rec["status"] = "solved" if ok else ("failed" if ans is None else "wrong")
        rec["cpu"] = (steps + flops) / UNIT_OPS
        rec["cpu_net"] = max(rec["cpu"], 1e-3)
        if rec["status"] != "solved":
            rec["cpu"] = rec["cpu_net"] = cap
    return rec


def ladder_header(solver, family, mod, decl_dir, master, cap):
    return {"meta": True, "solver": os.path.basename(solver), "commit": instances.commit(master), "overhead": 0.0, "budget": cap, "family": family,
            "sandbox": COST_MODEL, "instance_version": mod.VERSION, "image": None, "host": "analytic operation, byte and memory counting (no machine timing)",
            "cpu": "none: counts", "ncpu": 1, "jobs": 1, "solver_sha256": tflops.sha256_file(solver),
            "cost_model": COST_MODEL, "unit_ops": UNIT_OPS, "python": tflops.python_version(), "counter_sha256": counter_sha256(),
            "decl_sha256": tflops.sha256_file(os.path.join(decl_dir, "decl.py"))}


def evaluate_ladder(solver, family, master, dims, n, cap, out_path, progress=None):
    if os.path.exists(out_path):
        raise FileExistsError(out_path)
    mod, derive, verify, d = tflops.load_family(family)
    fd = os.open(out_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    recs = []
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps(ladder_header(solver, family, mod, d, master, cap)) + "\n")
        for dim in dims:
            for idx in range(n):
                rec = count_instance(solver, derive(master, dim, idx), verify, cap)
                f.write(json.dumps(rec) + "\n")
                f.flush()
                recs.append(rec)
                if progress:
                    progress(os.path.basename(solver), rec)
    return recs


def baseline_reusable(path, solver, family, master, dims, n, cap):
    """-> (ok, why): an existing baseline ladder may be reused only if its header is exactly the one that would be written now and it holds exactly the expected instances."""
    try:
        meta, recs = tflops.read_ladder(path)
    except (OSError, ValueError) as e:
        return False, f"unreadable ({type(e).__name__})"
    mod, derive, verify, d = tflops.load_family(family)
    if meta != ladder_header(solver, family, mod, d, master, cap):
        return False, "its header differs from the one this run would write (different seed, solver, declaration, budget, interpreter or counter)"
    want = {f"{dim}:{i}" for dim in dims for i in range(n)}
    got = [r.get("id") for r in recs]
    if len(got) != len(set(got)) or set(got) != want:
        return False, f"it holds {len(set(got) & want)} of the {len(want)} expected instances"
    return True, ""


def _profile_ok(r):
    """The operation profile is a decomposition of the recorded totals: its flops and bytes, each times its count, must add up EXACTLY to the record's flops and bytes."""
    p = r.get("profile")
    isint = lambda v: isinstance(v, int) and not isinstance(v, bool) and v >= 0
    return (isinstance(p, list) and all(isinstance(e, list) and len(e) == 3 and all(isint(v) for v in e) for e in p)
            and sum(f * n for f, b, n in p) == r["flops"] and sum(b * n for f, b, n in p) == r["bytes"])


def verify_ladder(path, rerun=0, master=None, solver_path=None, sample_seed=None):
    """-> (ok, [lines]): the cost model of every record; with rerun > 0 also the exact re-execution of that many records (or all of them): status, operations, bytes and peak must be IDENTICAL."""
    lines, ok = [], True
    meta, recs = tflops.read_ladder(path)
    name = os.path.basename(path)
    if meta is None or meta.get("cost_model") != COST_MODEL:
        return False, [f"FAIL {name}: not a {COST_MODEL} ladder"]
    cap, unit = meta.get("budget"), meta.get("unit_ops")
    if isinstance(cap, bool) or not isinstance(cap, (int, float)) or cap <= 0 or "solver_sha256" not in meta or "commit" not in meta:
        return False, [f"FAIL {name}: the header lacks a positive budget, a seed commitment or a solver hash"]
    if not recs:
        return False, [f"FAIL {name}: the ladder holds no records (an empty ladder certifies nothing)"]
    if unit != UNIT_OPS:
        ok = False
        lines.append(f"FAIL unit: the ladder's unit is {unit}, this checkout's is {UNIT_OPS}")
    if meta.get("counter_sha256") != counter_sha256():
        ok = False
        lines.append("FAIL counter: the ladder was counted by a different counting program (hash differs from this checkout's): re-measure with this one")
    bad = 0
    isint = lambda v: isinstance(v, int) and not isinstance(v, bool) and v >= 0
    for r in recs:
        try:
            if r["status"] == "solved":
                if not all(isint(r[k]) for k in ("steps", "flops", "bytes", "peak_bytes")) or not _profile_ok(r):
                    bad += 1
                    continue
                exp = (r["steps"] + r["flops"]) / UNIT_OPS
                if abs(r["cpu"] - exp) > 1e-12 or abs(r["cpu_net"] - max(exp, 1e-3)) > 1e-12:
                    bad += 1
            elif r["cpu_net"] != cap:
                bad += 1
        except (KeyError, TypeError):
            bad += 1
    lines.append(f"{'PASS' if not bad else 'FAIL'} cost model: every solved cost = (flops + steps) / {UNIT_OPS:g} with exact bytes and peak recorded, and every unsolved instance is charged the cap" + (f" ({bad} records disagree)" if bad else ""))
    ok = ok and not bad
    if rerun:
        if meta.get("python") != tflops.python_version():
            lines.append(f"SKIP re-run: ladder counted on {meta.get('python')}, this interpreter is {tflops.python_version()} (counts are only comparable on the same one)")
            return False, lines
        if solver_path is None and (not isinstance(meta["solver"], str) or meta["solver"] != os.path.basename(meta["solver"]) or meta["solver"] in ("", ".", "..")):
            lines.append(f"FAIL re-run: the ladder names its solver {meta['solver']!r}, which is not a plain file name: it will not be looked up on disk")
            return False, lines
        solver = solver_path or os.path.join(HERE, "solvers", meta["solver"])
        if not os.path.exists(solver) or tflops.sha256_file(solver) != meta["solver_sha256"]:
            lines.append(f"FAIL re-run: the solver file {meta['solver']} is missing here or its hash differs from the ladder's")
            return False, lines
        mod, derive, verify, d = tflops.load_family(meta["family"])
        if tflops.sha256_file(os.path.join(d, "decl.py")) != meta.get("decl_sha256"):
            lines.append("FAIL re-run: this checkout's decl.py differs from the one the ladder was made with")
            return False, lines
        if master is None or instances.commit(master) != meta["commit"]:
            lines.append("SKIP re-run: the seed given does not match the ladder's commitment (pass the revealed seed with --seed)")
            return False, lines
        k = len(recs) if rerun == "all" else min(int(rerun), len(recs))
        if k >= len(recs):
            pick = list(recs)
            lines.append(f"FULL AUDIT: all {len(recs)} records are re-executed")
        else:
            seed = secrets.randbits(64) if sample_seed is None else sample_seed
            pick = random.Random(seed).sample(recs, k)
            lines.append(f"sample: {k} of {len(recs)} records drawn at random (sample seed {seed})")
        same = 0
        key = lambda x: (x.get("status"), x.get("steps"), x.get("flops"), x.get("bytes"), x.get("peak_bytes"), json.dumps(x.get("profile")))
        for r in pick:
            dim, idx = r["id"].split(":")
            again = count_instance(solver, derive(master, int(dim), int(idx)), verify, cap)
            if key(again) == key(r):
                same += 1
            else:
                lines.append(f"  differs at {r['id']}: recorded {key(r)}, re-run {key(again)}")
        good = same == len(pick)
        lines.append(f"{'PASS' if good else 'FAIL'} re-run: {same}/{len(pick)} instances re-executed with identical status, operations, bytes and peak")
        ok = ok and good
    return ok, lines


def _master(a):
    if a.seed:
        with open(a.seed, "rb") as f:
            return f.read().strip()
    return instances.PRACTICE_SEED


def cmd_practice(a):
    master = _master(a)
    tag = instances.commit(master)[:8]
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    paths = []
    for role, solver in (("baseline", a.baseline), ("submission", a.solver)):
        p = os.path.join(HERE, "results", f"tflopsmem_{a.family}_{tag}_{role}_{os.path.basename(solver)}.jsonl")
        if os.path.exists(p) and role == "baseline" and a.reuse_baseline:
            ok, why = baseline_reusable(p, solver, a.family, master, a.dims, a.n, a.cap)
            if not ok:
                sys.exit(f"{p} exists but cannot be reused: {why}. Move it aside and run again.")
            paths.append(p)
            continue
        evaluate_ladder(solver, a.family, master, a.dims, a.n, a.cap, p, progress=lambda name, rec: print(f"  {name} {rec['id']}: {rec['status']} {rec.get('steps')}+{rec.get('flops')} ops, {rec.get('bytes')} bytes, peak {rec.get('peak_bytes')}", flush=True))
        paths.append(p)
    print("ladders:\n  " + "\n  ".join(paths))
    print(NEXT_HINT)


def cmd_verify(a):
    master = _master(a)
    allok = True
    for p in a.ladders:
        ok, lines = verify_ladder(p, a.rerun, master, sample_seed=a.sample_seed)
        print(p)
        for ln in lines:
            print("  " + ln)
        allok = allok and ok
    print(("\nVERIFIED (costs consistent and re-executed as requested)" if a.rerun else "\nCONSISTENT ONLY: the cost arithmetic checks out, but nothing was re-executed (use --rerun K or --rerun all)") if allok else "\nNOT VERIFIED")
    print("What this does NOT show: " + CLAIM_LIMITS)
    sys.exit(0 if allok else 1)


def cmd_selfcheck(a):
    mod, derive, verify, d = tflops.load_family(a.family)
    inst = derive(instances.PRACTICE_SEED, a.dim, 0)
    x, y = count_instance(a.solver, inst, verify, a.cap), count_instance(a.solver, inst, verify, a.cap)
    key = lambda r: (r["status"], r.get("steps"), r.get("flops"), r.get("bytes"), r.get("peak_bytes"), json.dumps(r.get("profile")))
    print(f"run 1: {x['status']} steps {x.get('steps')} flops {x.get('flops')} bytes {x.get('bytes')} peak {x.get('peak_bytes')}\n"
          f"run 2: {y['status']} steps {y.get('steps')} flops {y.get('flops')} bytes {y.get('bytes')} peak {y.get('peak_bytes')}\n" + ("IDENTICAL" if key(x) == key(y) else "DIFFERENT: not countable"))
    sys.exit(0 if key(x) == key(y) and x["status"] == "solved" else 1)


def main(argv=None):
    if sys.version_info < MIN_PYTHON:
        sys.exit("tflops_mem needs Python 3.12 or newer")
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        sys.exit("tflops_mem refuses to run as root: the solver is contained by a restricted subset, not a sandbox. Use an unprivileged throwaway user.")
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("practice")
    p.add_argument("solver")
    p.add_argument("--baseline", required=True)
    p.add_argument("--family", required=True)
    p.add_argument("--dims", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, default=8)
    p.add_argument("--cap", type=float, default=2000, help="budget in counted seconds (1 = 1e7 operations)")
    p.add_argument("--seed")
    p.add_argument("--reuse-baseline", action="store_true")
    p = sub.add_parser("verify")
    p.add_argument("ladders", nargs="+")
    p.add_argument("--rerun", type=lambda s: s if s == "all" else int(s), default=0, help="K random records to re-execute, or `all` for a full audit")
    p.add_argument("--sample-seed", type=int)
    p.add_argument("--seed")
    p = sub.add_parser("selfcheck")
    p.add_argument("solver")
    p.add_argument("--family", required=True)
    p.add_argument("--dim", type=int, required=True)
    p.add_argument("--cap", type=float, default=2000)
    a = ap.parse_args(argv)
    return {"practice": cmd_practice, "verify": cmd_verify, "selfcheck": cmd_selfcheck}[a.cmd](a)


if __name__ == "__main__":
    main()
