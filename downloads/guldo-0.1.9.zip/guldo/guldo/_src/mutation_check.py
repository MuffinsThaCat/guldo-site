#!/usr/bin/env python3
"""Mutation check of the challenge-bundle tests: break the code on purpose, in one place at a time, and confirm a test notices.

    python3 mutation_check.py              # all mutations (about 5 minutes)
    python3 mutation_check.py C14 X5       # only those ids
    python3 mutation_check.py --no-baseline

A mutation that SURVIVES is a gap in the tests, not a bug in the code; it means the behaviour is not pinned. A mutation whose pattern no longer matches exactly once
(BAD-MUTATION) means the code it targeted changed: rewrite the pattern, because a stale mutation proves nothing. The exit status is 1 for either.

Why it is built the way it is (each rule is a mistake this check already made once):
  * It works on a PRIVATE SNAPSHOT of the project, patterns and all. Mutating the live files while other people (or sessions) edit them pairs new code with old tests.
  * Exactly one run at a time (a lock file): two runners rewriting one tree restore each other's files under each other's tests and report survivors that are not real.
  * A baseline run of the unmutated snapshot comes first: if its tests fail already, every "killed" below would be meaningless.
  * A survivor is only real if it survives ALONE: rerun it with its id before believing it.
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
T = "test_export."
CHK, SCR, EXP = "bundle_templates/check.py", "bundle_templates/score.py", "export_bundle.py"
M = [  # (id, file, old, new, [test targets]); `old` must occur exactly once in the file
    ("C1 ed25519 verify always true", CHK, "return _peq(_pmul(s, _G), _padd(r_pt, _pmul(h, a_pt)))", "return True", [T + "TestRfc8032", T + "TestAttestations"]),
    ("C2 log: ignore broken prev link", CHK, 'if e.get("prev") != prev:', "if False:", [T + "TestHashChainedLog"]),
    ("C3 sandbox: allow network", CHK, "(deny network*)", "", [T + "TestSandboxedRerun"]),
    ("C4 sandbox: allow writes", CHK, "(deny file-write*)", "", [T + "TestSandboxedRerun"]),
    ("C5 sandbox: allow reading the seed", CHK, "(deny file-read* {denies})", "", [T + "TestSandboxedRerun"]),
    ("C6 sandbox: allow exec", CHK, '(deny process-exec*)(allow process-exec (literal "{exe}") (subpath "{base}"))', "", [T + "TestSandboxedRerun"]),
    ("C7 reuse limit never fails", CHK, "reused / len(pairs) <= 0.5", "reused / len(pairs) <= 1.1", [T + "TestVerifierFuzz"]),
    ("C8 attest-check: every key vouched", CHK, "vouched = pub in trusted", "vouched = True", [T + "TestAttestations"]),
    ("C9 rerun: ignore invalid answers", CHK, "ok = not invalid and not meter_bad", "ok = not meter_bad", [T + "TestRerun"]),
    ("C10 rerun: tolerance 100 bits wider", CHK, "bool(gaps) and statistics.median(gaps) <= a.tolerance\n    if scan_skipped:", "bool(gaps) and statistics.median(gaps) <= a.tolerance + 100\n    if scan_skipped:", [T + "TestRerun"]),
    ("C11 no trivial-answer candidates", CHK, 'return [inst["args"], list(inst["args"])[::-1]] + ints + [v + d for v in ints[:8] for d in (-1, 1)]', "return []", [T + "TestStandaloneChecker"]),
    ("C12 every-part-damaged check off", CHK, "htot == 0 or hacc / htot <= 0.5", "True", [T + "TestToleranceVerifier"]),
    ("C13 pinned-file hash not compared", CHK, "elif sha256_file(p) != want:", "elif False:", [T + "TestStandaloneChecker"]),
    ("C14 checkpoint containment not checked", CHK, 'if n > len(entries) or entries[n - 1].get("hash") != st["head"]:', "if False:", [T + "TestLogCheckpoints"]),
    ("C15 spread: tolerance always 1", CHK, "rec_tol = max(1.0, math.ceil(worst * 4) / 4)", "rec_tol = 1.0", [T + "TestSpread"]),
    ("C16 random-shape fuzz never fails", CHK, "facc / ftot <= 0.5", "True", [T + "TestVerifierFuzz"]),
    ("C17 attestation challenge binding off", CHK, 'about.get("challenge_json_sha256") != chsha', "False", [T + "TestAttestations"]),
    ("C18 dissent does not fail the check", CHK, "ok = not dissent and len(passes) >= a.min", "ok = len(passes) >= a.min", [T + "TestAttestations"]),
    ("C19 log append skips verification", CHK, "        if bad:\n            raise SystemExit(\"refusing to extend", "        if False:\n            raise SystemExit(\"refusing to extend", [T + "TestHashChainedLog"]),
    ("C20 cross-seed check never fails", CHK, "same <= 2", "True", [T + "TestVerifierFuzz"]),
    ("S1 scorer: coverage mismatch accepted", SCR, "if only_b or only_s:", "if False:", [T + "TestScorer"]),
    ("S2 combine: max instead of min over seeds", SCR, '"credit_bits": min(credits)', '"credit_bits": max(credits)', [T + "TestScorer", T + "TestScorerLimits"]),
    ("S3 strict mode ignores ladder problems", SCR, "if strict and notes:", "if False:", [T + "TestScorer"]),
    ("S4 recheck ignores input changes", SCR, 'problems += [f"input changed: {p}" for p in paths if have[p] != bind["inputs"][p]]', "problems += []", [T + "TestScorerLimits"]),
    ("S5 floor-limited never detected", SCR, "return f is not None and f >= 0.5", "return False", [T + "TestScorerLimits", T + "TestScorer"]),
    ("S6 different-seed ladders accepted", SCR, "if cb and cs and cb != cs:", "if False:", [T + "TestScorer"]),
    ("S7 same seed counted twice", SCR, "        if strict:\n            raise Refused(msg)", "        if False:\n            raise Refused(msg)", [T + "TestScorer"]),
    ("S8 noise always reported 0.1", SCR, "return statistics.pstdev(res) if len(res) >= 8 else None", "return 0.1", [T + "TestScorerLimits"]),
    ("S9 result need not bind all inputs", SCR, "if not set(paths) <= set(bind[\"inputs\"]):", "if False:", [T + "TestResultFileValidation"]),
    ("S10 bootstrap count unbounded", SCR, "not 1 <= boot <= MAX_BOOT", "False", [T + "TestResultFileValidation"]),
    ("S11 status values unchecked", SCR, 'if not isinstance(r["status"], str) or r["status"] not in STATUSES:', "if False:", [T + "TestScorer"]),
    ("S12 record limit removed", SCR, "if n > MAX_RECORDS:", "if False:", [T + "TestScorerLimits"]),
    ("S13 solved cost may exceed the cap", SCR, 'if r["status"] == "solved" and r["cpu_net"] > budget * 1.0000001:', "if False:", [T + "TestScorer"]),
    ("S14 compare power line removed", SCR, "line = None if res[\"verdict\"].startswith(\"UNRESOLVABLE\") else compare_power_line(res, a_over_b + b_over_a, ch, a.min_gap)", "line = None", [T + "TestScorerLimits"]),
    ("X1 export: stale compile accepted", EXP, 'if problems:\n        raise ExportError("REFUSED: "', 'if False:\n        raise ExportError("REFUSED: "', [T + "TestBuild"]),
    ("X2 export: run-time imports not vendored", EXP, "            dynamic[name] = path", "            pass", [T + "TestDynamicImports"]),
    ("X3 export: project data files accepted", EXP, 'if probed["foreign"]:', "if False:", [T + "TestDataFiles"]),
    ("X4 export: bundle dir left mode 0700", EXP, "os.chmod(stage, 0o755)", "pass", [T + "TestBuild"]),
    ("X5 export: overwrites existing dir", EXP, "    if os.path.exists(out):\n        raise ExportError", "    if False:\n        raise ExportError", [T + "TestBuild"]),
    ("X6 verify --selftest unsandboxed by default", EXP, '"off" if unsandboxed else "auto", require=not unsandboxed', '"off", require=False', [T + "TestSandboxedDeclaration"]),
    ("X7 manifest: extra files not noticed", EXP, 'out.append(f"not in the manifest: {rel}")', "pass", [T + "TestBuild", T + "TestStandaloneChecker"]),
    ("X8 DRAFT status never set", EXP, 'if st != "pass":\n        reasons.append(f"the compiler\'s own self-test is {st!r}, not \'pass\'")\n    if power["min_certifiable_bits"] is None:',
     'if False:\n        reasons.append(f"the compiler\'s own self-test is {st!r}, not \'pass\'")\n    if power["min_certifiable_bits"] is None:', [T + "TestBuild"]),
    ("X9 export selftest skipped silently", EXP, "        if selftest:   # a fixed fresh seed", "        if False:   # a fixed fresh seed", [T + "TestBuild"]),
    # the rerun defences added after the Linux run (each was found by attacking the previous fix)
    ("D1 hidden CPU never flagged", CHK, "    return cpu < limit * wall", "    return False", [T + "TestMeterSanity"]),
    ("D2 solver judged against a fixed share only", CHK, "limit = RELATIVE_SHARE * min(1.0, ref[1] / ref_wall)", "limit = ABSOLUTE_SHARE", [T + "TestMeterSanity"]),
    ("D3 detached children not killed", CHK, "os.kill(pid, signal.SIGKILL)   # exact pids, never a pattern", "pass", [T + "TestMeterSanity"]),
    ("D4 left-behind process does not fail the claim", CHK, "and not left_behind and bool(gaps)", "and bool(gaps)", [T + "TestMeterSanity"]),
    ("D5 missing ps reads as a clean scan", CHK, "        return None   # NOT", "        return set()   # NOT", [T + "TestMeterSanity"]),
    ("D6 --strict ignored", CHK, 'if weak and st["outcome"] == "PASS" and a.strict:', "if False:", [T + "TestAttestations"]),
    ("D8 numerical-library warning never shown", CHK, "    if numeric:\n        print(f\"note: this challenge's declaration uses", "    if False:\n        print(f\"note: this challenge's declaration uses", [T + "TestMeterSanity"]),
    ("D9 warning for every third-party library", CHK, "or []) & NUMERIC_LIBS)", "or []))", [T + "TestMeterSanity"]),
    ("E1 spread merges different solvers or seeds", CHK, "        elif who != identity:", "        elif False:", [T + "TestSpread"]),
    ("E2 spread keeps instances that failed a check", CHK, 'and str(r["id"]) not in skip}', "}", [T + "TestSpread"]),
    ("E3 saved file omits the solver hash", CHK, '"solver_sha256": solver_sha, "seed_commit"', '"seed_commit"', [T + "TestRerunRepeatAndSave"]),
    ("E4 saved file omits the seed commitment", CHK, '"seed_commit": hashlib.sha256(master).hexdigest(), "rerun_checks"', '"rerun_checks"', [T + "TestRerunRepeatAndSave"]),
    ("E5 saved file omits the flagged instances", CHK, '"untrusted_instances": sorted(set(hidden + left_behind + meter_bad)),', '"untrusted_instances": [],', [T + "TestRerunRepeatAndSave"]),
    ("F1 numerical default same as pure Python", CHK, "a.tolerance = NUMERIC_TOLERANCE if numeric else DEFAULT_TOLERANCE", "a.tolerance = DEFAULT_TOLERANCE", [T + "TestMeterSanity"]),
    ("F2 default overrides an explicit tolerance", CHK, "    if a.tolerance is None:\n        a.tolerance = NUMERIC_TOLERANCE", "    if True:\n        a.tolerance = NUMERIC_TOLERANCE", [T + "TestMeterSanity"]),
    ("F3 command-line default is not None", CHK, 'type=float_arg(0, 1000), default=None, help="bits the median claimed-vs-re-measured gap', 'type=float_arg(0, 1000), default=2.0, help="bits the median claimed-vs-re-measured gap', [T + "TestRerunRepeatAndSave"]),
    ("G1 --max-tolerance ignored", CHK, 'if a.max_tolerance is not None and st["outcome"] == "PASS" and (not tol_ok or tol > a.max_tolerance):', "if False:", [T + "TestAttestations"]),
    ("G2 the cap also drops a valid FAIL", CHK, 'if a.max_tolerance is not None and st["outcome"] == "PASS" and (not tol_ok or tol > a.max_tolerance):', "if a.max_tolerance is not None and (not tol_ok or tol > a.max_tolerance):", [T + "TestAttestations"]),
    ("G3 an unreadable tolerance passes the cap", CHK, "(not tol_ok or tol > a.max_tolerance)", "(tol_ok and tol > a.max_tolerance)", [T + "TestAttestations"]),
    ("G4 a bool is accepted as a tolerance", CHK, "isinstance(tol, (int, float)) and not isinstance(tol, bool) and math.isfinite(tol) and tol >= 0", "isinstance(tol, (int, float)) and math.isfinite(tol) and tol >= 0", [T + "TestAttestations"]),
    ("G5 a negative tolerance is accepted", CHK, "math.isfinite(tol) and tol >= 0", "math.isfinite(tol)", [T + "TestAttestations"]),
    ("G6 a huge integer tolerance crashes attest-check", CHK, "        except OverflowError:   # a signer can write an integer too large", "        except ZeroDivisionError:   # a signer can write an integer too large", [T + "TestAttestations"]),
    ("D7 repeat runs not held to the stray rule", CHK, '                if getattr(rs_, "strays", ()):', "                if False:", [T + "TestMeterSanity"]),
]


def acquire_lock():
    """One run at a time on this machine for this project. A lock whose owner is dead is taken over."""
    path = os.path.join(tempfile.gettempdir(), "guldo-mutation-%08x.lock" % zlib.crc32(HERE.encode()))
    for _ in range(2):
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
            return path
        except FileExistsError:
            try:
                with open(path) as f:
                    pid = int(f.read().strip() or 0)
                os.kill(pid, 0)
            except (OSError, ValueError):
                os.unlink(path)   # stale: its owner is gone
                continue
            raise SystemExit(f"another mutation run (pid {pid}) is in progress: two at once corrupt each other's results. Wait for it, or stop it.")
    raise SystemExit("could not take the lock " + path)


def run_tests(snapshot, targets, timeout=900):
    return subprocess.run([sys.executable, "-m", "unittest"] + targets, cwd=snapshot, capture_output=True, text=True, timeout=timeout)


def main(argv):
    baseline = "--no-baseline" not in argv
    only = [a for a in argv if not a.startswith("--")]
    chosen = [m for m in M if not only or any(m[0].startswith(o + " ") for o in only)]
    if not chosen:
        raise SystemExit("no mutation matches " + " ".join(only))
    lock = acquire_lock()
    snapshot = tempfile.mkdtemp(prefix="guldo-mutation-")
    try:
        shutil.rmtree(snapshot)
        shutil.copytree(HERE, snapshot, ignore=shutil.ignore_patterns("results", ".git", "dist", "__pycache__", ".venv", "*.pyc", "out"))
        if baseline:
            targets = sorted({t for m in chosen for t in m[4]})
            t0 = time.time()
            r = run_tests(snapshot, targets, 1800)
            print(f"baseline (unmutated, {len(targets)} test classes): {'PASS' if r.returncode == 0 else 'FAIL'} [{time.time() - t0:.0f}s]", flush=True)
            if r.returncode:
                print(r.stderr[-1500:])
                raise SystemExit("the unmutated tests already fail, so no mutation result would mean anything: fix them first")
        results = []
        for mid, rel, old, new, targets in chosen:
            path = os.path.join(snapshot, rel)
            with open(path) as f:
                original = f.read()
            if original.count(old) != 1:
                results.append((mid, f"BAD-MUTATION (pattern found {original.count(old)} times)"))
                print(f"{mid:48s} {results[-1][1]}", flush=True)
                continue
            with open(path, "w") as f:
                f.write(original.replace(old, new))
            t0 = time.time()
            try:
                r = run_tests(snapshot, targets)
                verdict, killer = ("KILLED", "") if r.returncode else ("SURVIVED", "")
                if r.returncode:
                    fails = [ln.split(" ")[1] for ln in r.stderr.splitlines() if ln.startswith(("FAIL:", "ERROR:"))]
                    killer = " by " + (fails[0] if fails else "?") + (f" (+{len(fails) - 1})" if len(fails) > 1 else "")
            except subprocess.TimeoutExpired:
                verdict, killer = "KILLED", " (timeout)"
            finally:
                with open(path, "w") as f:
                    f.write(original)   # restore from the snapshot's own text, never from the live tree
            results.append((mid, verdict + killer))
            print(f"{mid:48s} {verdict}{killer}   [{time.time() - t0:.0f}s]", flush=True)
        bad = [m for m, v in results if not v.startswith("KILLED")]
        print(f"\n{len(results) - len(bad)} of {len(results)} killed." + (f" NOT killed: {bad}" if bad else ""))
        if bad:
            print("A survivor is only real if it survives ALONE: rerun it by id (python3 mutation_check.py ID) before acting on it.")
        return 1 if bad else 0
    finally:
        shutil.rmtree(snapshot, ignore_errors=True)
        try:
            os.unlink(lock)
        except OSError:
            pass


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
