"""aisecond in the counted-operations API, TECHNIQUE: Newton-CG ("Hessian-free"). Never form the Hessian: solve H step = gradient approximately with conjugate gradient, where each
iteration needs only a Hessian-vector product H v = X^T (s * (X v)) / N + lambda v (two passes over the features, s = p(1-p)). The inner solve is truncated at a relative residual of 1e-3
(an inexact Newton step). Cheap per iteration; it pays off when d is large enough that forming an N x d x d Hessian costs more than the inner iterations, and it can lose to exact Newton when
d is small (this domain's sizes are small: the comparison file says which wins here)."""
import math

import tensorops as tp

RHO = 0.97
LAM = 1e-4
MAXITER = 40
GRAD2 = 2e-13
INNER = 200
TOL = 1e-3             # relative residual (norm) of the inner solve


def solve(seed, d, n, labels):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    X = (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)
    y = tp.tensor([float(v) for v in labels])
    Xt = tp.transpose(X, (1, 0))
    w = tp.zeros((d,))
    for it in range(MAXITER):
        p = 1.0 / (1.0 + tp.exp(-(X @ w)))
        g = Xt @ (p - y) * (1.0 / n) + w * LAM
        g2 = tp.sum(g * g).item()
        if g2 <= GRAD2:
            break
        s = p * (1.0 - p)
        x = tp.zeros((d,))
        r = g
        q = g
        rs = g2
        for j in range(INNER):
            Hq = Xt @ (s * (X @ q)) * (1.0 / n) + q * LAM
            a = rs / tp.sum(q * Hq).item()
            x = x + q * a
            r = r - Hq * a
            rs2 = tp.sum(r * r).item()
            if rs2 <= TOL * TOL * g2:
                break
            q = r + q * (rs2 / rs)
            rs = rs2
        w = w - x
    return [int(v * 1048576.0) for v in w.tolist()]
