"""Declaration of a REAL-DATA, REAL-MODEL, LOOKUP-RESISTANT inference domain for a small TRANSFORMER: predict the next character of real text, with a real trained decoder-only language model, on queries corrupted by a seed-keyed noise.

Nothing is planted. The text is real (corpus.txt: 600000 characters of the prose and source files of this project, plain ASCII, 96 distinct characters, committed by hash) and the model is a real network that training produced
(train.py rebuilds everything): a decoder-only transformer with learned token and position embeddings, 2 pre-LayerNorm blocks of causal 4-head self-attention and a ReLU MLP (D -> 4D -> D), a final LayerNorm and a
linear head to the 96 characters; D = size = 24, 32 or 40; context length T = 32. The first 540000 characters trained the networks; the last 60000 are the query pool (no network saw them); the networks predict the
next character right 49.9%, 53.6% and 55.2% of the time on them (a character-level model this small on mixed prose and code).

The instance's ARGUMENTS are [D, Q, seed, X, E, P, g1, b1, Wq, Wk, Wv, Wo, g2, b2, W1, c1, W2, c2, gf, bf, Wh, bh]: Q = 128 contexts of T = 32 characters from the pool, drawn by a seed-keyed choice (X, Q x 32
integer character codes 0..95), and the network (E 96 x D, P 32 x D; the per-layer arrays g1 b1 g2 b2 c2 are 2 x D, Wq Wk Wv Wo are 2 x D x D, W1 is 2 x D x 4D, c1 is 2 x 4D, W2 is 2 x 4D x D; gf bf are D, Wh is
D x 96, bh is 96). They are SMALL (under 0.5 MB), so the domain fits the 1 MiB instance limit of the timed protocol and can be compiled.
The network is asked about the contexts' EMBEDDINGS PLUS NOISE the solver regenerates from `seed`: x0 = E[X] + P + s u, u the SplitMix64 stream under `seed` (tensorops.stream(seed, 0, Q * 32 * D), u in [-1, 1),
row-major, reshaped Q x 32 x D), s = 0.025 / 0.029 / 0.032 for D = 24 / 32 / 40 (the embeddings have a standard deviation of about 0.35). Then for each of the 2 blocks: h = LN(x; g1, b1); q = h Wq, k = h Wk, v = h Wv, split into 4 heads of D/4; scores = q k^T / sqrt(D/4) plus
the causal mask (-1e30 above the diagonal), a row-wise softmax, o = (softmax v) merged back and x = x + o Wo; h = LN(x; g2, b2); x = x + relu(h W1 + c1) W2 + c2. LN(x; g, b) = (x - mean) / sqrt(var + 1e-5) * g + b over
the last axis (population variance). The logits are LN(x_last; gf, bf) Wh + bh at the LAST position of each context. The answer is the list of Q character codes (ints 0..95) that agrees with the network's own prediction
(the arg-max logit) on at least 98% of the queries (at most 2 of 128 may differ; a tie counts as agreement). The judge recomputes from the arguments and never looks at the true next characters.

WHY THE NOISE, AND WHY IT DEPENDS ON THE WIDTH. The pool and the networks are public and fixed, so without noise the answers are a fixed table anyone can precompute (a lookup keyed by the context). With it they
depend on a seed the entrants do not have until a committed master seed is revealed, and a table of the network's answers on the CLEAN contexts agrees with its answers on the noisy ones only about 90% of the time at every
width (calibrated per width on 40 instances each, far under the 98% bar). The same lesson as airealm and airealc: a fixed scale does not work across widths, so the scale is per width.

What this is for: the real-data domains so far are an MLP and a CNN. A transformer's cost is dominated by attention and its parameters are spread across the heads and the MLP: this asks whether the techniques that
work on planted models (dropping heads, pruning MLP units, sparsity, low precision, doing less work in the last layer) work on a language model nobody built for the purpose.

The cost is counted operations and bytes (tflops_mem3.py): exactly reproducible, not a time.
"""
import hashlib
import hmac
import math
import os

import numpy as np

NAME = "airealt"
VERSION = "airealt-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (24, 40)
SIZE_STEP = 8
REFERENCE_SOLVER = "reference.py"
HERE = os.path.dirname(os.path.abspath(__file__))
WIDTHS = (24, 32, 40)
Q = 128
T = 32
V = 96
LAYERS = 2
HEADS = 4
NOISE = {24: 0.025, 32: 0.029, 40: 0.032}     # the embedding-noise scale per network width
AGREE = 0.98
CORPUS_SHA256 = "8a83a6835c011f04c025f630876d8d552d47c77a38522387d0d5e95461bd07c4"
KEYS = ("E", "P", "g1", "b1", "Wq", "Wk", "Wv", "Wo", "g2", "b2", "W1", "c1", "W2", "c2", "gf", "bf", "Wh", "bh")
MODEL_SHA256 = {24: "9c37a24d92b79d1b4ef3318d34601e33ab992ff284f10794c634d211de9971fd", 32: "501c1beb46249127e0db796f35ff45b8414ae4ea717f881b199507a93eebbccb",
                40: "f4ec0345323087c226edeb0e4d939cc78f7d24dff98644529a2626d56dc046a9"}
DOC = ("solve(D, Q, seed, X, E, P, g1, b1, Wq, Wk, Wv, Wo, g2, b2, W1, c1, W2, c2, gf, bf, Wh, bh): X is Q x 32 character codes (0..95) of real text. The queries are the embeddings x0 = E[X] + P + s u "
       "with u = tensorops.stream(seed, 0, Q*32*D) (u in [-1, 1), row-major, Q x 32 x D) and s = 0.025 (D=24), 0.029 (D=32), 0.032 (D=40). The network is 2 pre-LayerNorm blocks: h = LN(x; g1[l], b1[l]); q, k, v = h Wq[l], "
       "h Wk[l], h Wv[l] (4 heads of D/4); causal softmax(q k^T / sqrt(D/4)) v merged and x += . Wo[l]; h = LN(x; g2[l], b2[l]); x += relu(h W1[l] + c1[l]) W2[l] + c2[l]; LN(x; g, b) = (x - mean) / sqrt(var + 1e-5) "
       "* g + b over the last axis. logits = LN(x_last; gf, bf) Wh + bh at the LAST position of each context. Return the list of Q character codes that agrees with the network's own prediction (the arg-max logit) "
       "on at least 98% of the queries. Return None for no answer.")
REFERENCE_NOTE = ("The dense network on the noisy batch in float64: every position of every context through both blocks, the logits taken at the last position. Whether dropping heads, pruning MLP units, sparsity, low "
                  "precision or doing less work in the last block pay on a REAL language model, and by how much, is what the domain measures; a lookup table of the clean contexts' answers does not pass it.")


def _content_hash(*arrs):
    m = hashlib.sha256()
    for a in arrs:
        m.update(np.ascontiguousarray(a).tobytes())
    return m.hexdigest()


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


_CACHE = {}


def load():
    """-> (token ids of the whole corpus (np.int64), {D: {name: array}}), each checked against its committed content hash."""
    if "d" not in _CACHE:
        with open(os.path.join(HERE, "corpus.txt"), encoding="ascii") as f:
            s = f.read()
        if hashlib.sha256(s.encode()).hexdigest() != CORPUS_SHA256:
            raise RuntimeError("airealt: corpus.txt does not match its committed content hash")
        chars = sorted(set(s))
        ids = np.array([chars.index(c) for c in s], dtype=np.int64)
        models = {}
        for D in WIDTHS:
            m = np.load(os.path.join(HERE, f"model_{D}.npz"))
            P = {k: np.asarray(m[k]) for k in KEYS}
            if _content_hash(*[P[k] for k in KEYS]) != MODEL_SHA256[D]:
                raise RuntimeError(f"airealt: model_{D}.npz does not match its committed content hash")
            models[D] = P
        _CACHE["d"] = (ids, models)
    return _CACHE["d"]


def _seed(master, tag, size, idx):
    return int.from_bytes(hmac.new(master, f"airealt-v1:{tag}:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def _ln(x, g, b):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + 1e-5) * g + b


def last_logits(P, x):
    """The network from the embeddings x (n, T, D) to the logits at the last position (n, V), float64."""
    n, t, D = x.shape
    dh = D // HEADS
    for l in range(LAYERS):
        h = _ln(x, P["g1"][l], P["b1"][l])
        q, k, v = (h @ P[w][l] for w in ("Wq", "Wk", "Wv"))
        sp = lambda a: a.reshape(n, t, HEADS, dh).transpose(0, 2, 1, 3)
        s = sp(q) @ sp(k).transpose(0, 1, 3, 2) / math.sqrt(dh) + np.triu(np.full((t, t), -1e30), 1)
        e = np.exp(s - s.max(-1, keepdims=True))
        o = ((e / e.sum(-1, keepdims=True)) @ sp(v)).transpose(0, 2, 1, 3).reshape(n, t, D)
        x = x + o @ P["Wo"][l]
        h = _ln(x, P["g2"][l], P["b2"][l])
        x = x + np.maximum(h @ P["W1"][l] + P["c1"][l], 0.0) @ P["W2"][l] + P["c2"][l]
    return _ln(x[:, -1], P["gf"], P["bf"]) @ P["Wh"] + P["bh"]


def embed(P, tok, seed=None, D=None):
    """E[tok] + P_pos, plus the seed's noise when a seed is given."""
    x = P["E"][tok] + P["P"][None, :tok.shape[1]]
    if seed is not None:
        x = x + NOISE[D] * _uniform(seed, 0, tok.shape[0] * tok.shape[1] * D).reshape(tok.shape[0], tok.shape[1], D)
    return x


def logits(args):
    D, q, seed, X = args[:4]
    P = {k: np.asarray(a, dtype=np.float64) for k, a in zip(KEYS, args[4:])}
    return last_logits(P, embed(P, np.asarray(X), seed, D))


def derive(master: bytes, size: int, idx: int) -> dict:
    ids, models = load()
    P = models[size]
    lo, hi = int(len(ids) * 0.9), len(ids) - T - 1
    pos = np.random.RandomState(_seed(master, "pick", size, idx) % (2 ** 32)).choice(np.arange(lo, hi), Q, replace=False)
    tok = np.stack([ids[j:j + T] for j in pos])
    args = [size, Q, _seed(master, "noise", size, idx), tok.tolist()] + [P[k].tolist() for k in KEYS]
    clean = np.argmax(last_logits(P, embed(P, tok)), axis=1)
    return {"args": args, "planted": [int(v) for v in np.argmax(logits(args), axis=1)], "truth": [int(ids[j + T]) for j in pos], "clean": [int(v) for v in clean]}


def verify(inst: dict, ans) -> bool:
    args = inst["args"]
    q = args[1]
    if not isinstance(ans, list) or len(ans) != q:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or not 0 <= v < V for v in ans):
        return False
    L = logits(args)
    agree = int((L[np.arange(q), np.asarray(ans)] >= L.max(axis=1)).sum())
    return bool(agree >= int(np.ceil(AGREE * q)))
