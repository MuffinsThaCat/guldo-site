"""The evaluator-hosted tool service: how a vendor's black-box agent is evaluated.

The vendor's agent runs wherever the vendor likes, with its own model, prompts and loop. It is handed ONE thing: a URL and a token. Everything it can learn or do about the task goes through this
service, which holds the secret seed, derives the instance, serves the tools, enforces the budgets, and records every call in a hash-chained transcript that it signs (agent_blackbox.py explains what that
does and does not prove). The vendor needs no code from us: three HTTP calls, or any MCP-capable agent product pointed at the MCP endpoint.

PROTOCOL (guldo-tsp-v1; JSON over HTTP; `Authorization: Bearer <token>`)
  GET  /v1/info               public: protocol, round, plan hash, seed commitment, the arm's label, the SERVICE PUBLIC KEY, limits, progress. No secrets.
  POST /v1/session            (arm token) start the next task: {session, sid, task, tools, limits, receipt}, or {done: true} when the arm has no tasks left, or 429 while another session is open.
  POST /v1/task               (session token) the same task and tools again (idempotent).
  POST /v1/call               (session token) {name, args} -> {content, ended, remaining, receipt}. `submit` {answer, usage?} ends the trial. A refused call (ended / over a cap) is 409.
  POST /v1/finish             (session token) give up: the trial ends "no submit".
  POST /mcp                   (arm token in the path /mcp/<token> or in the header) MCP over HTTP (JSON-RPC 2.0): initialize starts a task (its text is the server `instructions`, the session id is returned
                              in `Mcp-Session-Id`), tools/list, tools/call, ping. DELETE ends the session.
Every response to a call carries a RECEIPT {sid, seq, h, sig}: the service's signature over the chain hash through that call. Keep them: `check-receipts` shows whether the published transcript is exactly
what you saw. A session is ONE attempt: tasks are handed out once, in an order derived from the seed; a vendor that abandons a task has failed it, and cannot be given it again.

DURABLE. Every accepted input (start, call, finish, expiry) is appended to a journal (fsync'd) BEFORE the answer is sent, and a restarted service replays it, rebuilding the open sessions exactly (the
tools are deterministic), so a crash or a deploy costs no vendor a task.

COMMANDS
  arm-token   --base B --round R --eid E        create the arm's token (printed ONCE; only its hash is stored) for a closed round's black-box arm
  serve-arm   --base B --round R --eid E --seed S --key K [--host H --port P --max-concurrent N --tls-cert C --tls-key K2] [--exec CMD --accept-unsandboxed-exec]
              serve until every task of the arm is finished, then write the ladder and log it (agent_rounds then evaluates the rest of the round and reveals as usual)
  status      --base B --round R --eid E        progress from the journal
  check-receipts LADDER RECEIPTS.jsonl          the vendor's check (the service key is read from the ladder header: PIN it yourself, out of band, with --pubkey)

TRUST. The service is the evaluator's. A vendor trusts it to serve the real tools and to count honestly; the receipts and the revealed seed let the vendor check that afterwards, and the signature plus the
seed let a reader check the vendor's result without trusting either side's word. An INDEPENDENT party running this service (see INDEPENDENT_VERIFIER.md) is what turns "the operator says" into "a party
neither side controls signed". Run it behind TLS (the built-in --tls-cert/--tls-key, or a reverse proxy): tokens are bearer secrets.

`--exec CMD` runs a vendor-supplied command once per task, with only GULDO_TSP_URL and GULDO_TSP_SESSION in its environment, in a fresh directory and its own process group (killed by that exact group
on timeout). It runs on THIS machine, where the seed file is readable: put the service in a container or VM first (--accept-unsandboxed-exec says you have).
"""
import argparse
import hashlib
import json
import os
import secrets
import signal
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

import agent_blackbox as BB
import agent_core
import agent_harness
import agent_rounds as AR
import agent_sig
import rounds as R

MAX_BODY = 1 << 20
SOCKET_TIMEOUT = 30                              # seconds a connection may sit idle between bytes
BODY_DEADLINE = 20                               # seconds a whole request body may take to arrive
MCP_VERSION = "2025-03-26"
EXEC_GRACE = 5                                  # seconds a vendor command may outlive its task's wall-time budget before its process group is killed


class ServiceError(Exception):
    pass


class Busy(Exception):
    pass


class Gone(Exception):
    """The trial is over: HTTP 409. Carries the ending receipt, so a vendor refused at a cap still holds the signed final chain hash."""

    def __init__(self, reason, receipt=None):
        Exception.__init__(self, reason)
        self.receipt = receipt


def _tool_specs_wire(tools):
    return [{"name": s["name"], "description": s.get("description", ""), "input_schema": s.get("input_schema", {"type": "object"})} for s in tools]


# ---- one arm ----------------------------------------------------------------------------------------------------------------------------------------

class _Live(object):
    def __init__(self, session, tok_hash, slot_no):
        self.session, self.tok_hash, self.slot_no, self.lock = session, tok_hash, slot_no, threading.Lock()
        self.last_now = session.start                 # a session's clock never runs backwards, whatever the system clock does (an NTP step would otherwise make a finished record fail its own check)

    def tick(self, now):
        self.last_now = now = max(now, self.last_now)
        return now


class Arm(object):
    """All the state of one black-box arm: its task slots, its live and finished sessions, the journal."""

    def __init__(self, base, rid, eid, master, secret, clock=time.time, max_concurrent=1):
        self.base, self.rid, self.eid, self.clock = base, rid, eid, clock
        self.d = AR._require(base, rid)
        self.r = R._read_json(os.path.join(self.d, "round.json"))
        if self.r["state"] != "closed":
            raise ServiceError("the round must be closed (and not evaluated) to serve an arm: it is %s" % self.r["state"])
        if agent_core.commitment(master) != self.r["commitment"]:
            raise ServiceError("this seed does not match the round's commitment")
        self.plan = R._read_json(os.path.join(self.d, "plan.json"))
        if eid in AR._evaluated_ids(self.d):
            raise ServiceError("arm %s is already evaluated" % eid)
        if eid == "baseline":
            self.cfg, self.handle = self.r["baseline"], None
        else:
            ent = {e["eid"]: e for e in AR._entries(self.d)}
            if eid not in ent:
                raise ServiceError("no such entry: %s" % eid)
            self.cfg, self.handle = ent[eid]["config"], ent[eid]["handle"]
        if not str(self.cfg["agent"]).startswith("blackbox:"):
            raise ServiceError("arm %s is %r, not a blackbox: agent" % (eid, self.cfg["agent"]))
        problems = AR._check_pins(self.d, self.r)
        if problems:
            raise ServiceError("REFUSED: " + "; ".join(problems))
        self.master, self.secret = master, secret
        self.pubkey = agent_sig.public_key(secret).hex()
        self.mod = agent_core.load_domain(self.r["domain"])
        self.label = self.cfg["label"] if eid != "baseline" else self.r["baseline"]["label"]
        self.header = BB.make_blackbox_header(self.plan, self.label, self.cfg["agent"], self.cfg["allow_tools"], self.pubkey, eid)
        self.budget = self.plan["budget"]
        rng = agent_core.Rng(b"bb-order|" + eid.encode("ascii") + b"|" + master)
        self.slots = rng.sample([(s, i, t) for s in self.plan["sizes"] for i in range(self.plan["n_per_size"]) for t in range(self.plan["trials"])],
                                len(self.plan["sizes"]) * self.plan["n_per_size"] * self.plan["trials"])
        self.max_concurrent = max(1, int(max_concurrent))
        self.evidence = None
        self.lock = threading.RLock()
        self.jlock = threading.Lock()
        self.next_slot = 0
        self.live = {}                  # token hash -> _Live
        self.records = {}               # slot number -> finished record
        self.sdir = os.path.join(self.d, "bb", eid)
        os.makedirs(self.sdir, exist_ok=True)
        self.arm_file = os.path.join(self.sdir, "arm.json")
        self.journal_path = os.path.join(self.sdir, "journal.jsonl")
        self.arm_hash = None
        if os.path.exists(self.arm_file):
            self.arm_hash = R._read_json(self.arm_file).get("token_sha256")
        self._replay()
        self.jf = open(self.journal_path, "a", encoding="utf-8")

    # -- journal -------------------------------------------------------------------------------------------------------------------------------------

    def _journal(self, ev):
        with self.jlock:
            self.jf.write(agent_core.canon(ev) + "\n")
            self.jf.flush()
            os.fsync(self.jf.fileno())

    def close(self):
        try:
            self.jf.close()
        except Exception:
            pass

    def _replay(self):
        """Rebuild the state from the journal's INPUTS. The tools are deterministic, so replaying (name, args, time) reproduces each transcript, chain, ending and signature exactly."""
        if not os.path.exists(self.journal_path):
            return
        with open(self.journal_path, "r", encoding="utf-8") as f:
            lines = [ln for ln in f.read().split("\n") if ln.strip()]
        for ln in lines:
            try:
                ev = json.loads(ln)
            except ValueError:
                break                                                       # a torn last line from a crash: the input it described was never answered
            kind = ev.get("ev")
            if kind == "start":
                self._start(ev["sid"], ev["tok"], ev["slot"], ev["t"], journal=False)
            elif kind in ("call", "finish", "reap"):
                lv = next((x for x in self.live.values() if x.session.sid == ev["sid"]), None)
                if lv is None:
                    raise ServiceError("the journal is inconsistent: an input for an unknown session")
                if kind == "call":
                    lv.session.call(ev["name"], ev["args"], ev["t"])
                elif kind == "finish":
                    lv.session.end("no submit", ev["t"])
                else:
                    lv.session.end("over wall-time budget", ev["t"])
                lv.last_now = max(lv.last_now, ev["t"])
                self._maybe_finalize(lv)

    # -- sessions ------------------------------------------------------------------------------------------------------------------------------------

    def set_evidence(self, ev):
        """Publish TEE evidence at GET /v1/attestation. The binding must be THIS service's: its signing key, this round's plan hash and seed commitment (evidence about another service is refused here,
        not left for a reader to notice). Whether the evidence is genuine is for the READER to decide (agent_tee.verify_evidence with the image measurement they trust)."""
        import agent_tee
        b = ev.get("binding") if isinstance(ev, dict) else None
        if not isinstance(b, dict) or (b.get("service_pubkey"), b.get("plan_hash"), b.get("commitment")) != (self.pubkey, self.header["plan_hash"], self.r["commitment"]):
            raise ServiceError("the evidence's binding is not this service's key, plan and seed commitment")
        if ev.get("format") != agent_tee.EVIDENCE_FORMAT:
            raise ServiceError("not TEE evidence")
        self.evidence = ev

    def set_arm_token(self):
        token = secrets.token_urlsafe(24)
        R._write_json(self.arm_file, {"token_sha256": BB.tool_hash(token), "eid": self.eid})
        self.arm_hash = BB.tool_hash(token)
        return token

    def arm_ok(self, token):
        return BB.token_ok(token, self.arm_hash)

    def _start(self, sid, tok_hash, slot_no, now, journal=True):
        s, i, t = self.slots[slot_no]
        inst = agent_core.make_instance(self.mod, self.master, s, i)
        sess = BB.Session(self.mod, inst, self.budget, t, self.cfg["allow_tools"], sid, now)
        lv = _Live(sess, tok_hash, slot_no)
        self.live[tok_hash] = lv
        self.next_slot = max(self.next_slot, slot_no + 1)
        if journal:
            self._journal({"ev": "start", "sid": sid, "tok": tok_hash, "slot": slot_no, "t": now})
        return lv

    def reap(self, now=None):
        """End every open session whose wall-time budget has passed."""
        now = self.clock() if now is None else now
        with self.lock:
            lives = list(self.live.values())
        for lv in lives:
            with lv.lock:
                t = lv.tick(now)
                if lv.session.is_open and t > lv.session.deadline:
                    lv.session.end("over wall-time budget", t)
                    self._journal({"ev": "reap", "sid": lv.session.sid, "t": t})
                    self._maybe_finalize(lv)

    def start_session(self):
        """(token, live) for the next task, or None when every task has been handed out. Raises Busy while max_concurrent sessions are open."""
        now = self.clock()
        self.reap(now)
        with self.lock:
            if self.next_slot >= len(self.slots):
                return None
            if sum(1 for lv in self.live.values() if lv.session.is_open) >= self.max_concurrent:
                raise Busy()
            token = secrets.token_urlsafe(24)
            lv = self._start(secrets.token_hex(8), BB.tool_hash(token), self.next_slot, now)
        return token, lv

    def task(self, lv):
        sess = lv.session
        return {"sid": sess.sid, "task": sess.prompt, "tools": _tool_specs_wire(sess.tools), "limits": self._limits(sess), "receipt": self._receipt(sess, 0)}

    def _limits(self, sess):
        return {"max_tool_calls": sess.max_calls, "max_wall_s": sess.max_wall, "deadline_epoch": sess.deadline}

    def _receipt(self, sess, seq):
        h = sess.turns[seq]["h"]
        return {"sid": sess.sid, "seq": seq, "h": h, "sig": agent_sig.sign(self.secret, BB.receipt_message(sess.sid, seq, h)).hex()}

    def find(self, token):
        lv = self.live.get(BB.tool_hash(token)) if isinstance(token, str) else None
        if lv is None:
            raise PermissionError("unknown session token")
        return lv

    def call(self, token, name, args):
        lv = self.find(token)
        with lv.lock:
            now = lv.tick(self.clock())
            sess = lv.session
            was_open = sess.is_open
            status, content, turn = sess.call(name, args, now)
            if status == "ended":
                if was_open:                                              # this very call discovered the end (a cap or the deadline): the ending is an input too
                    self._journal({"ev": "reap" if content == "over wall-time budget" else "call", "sid": sess.sid, "name": name, "args": args, "t": now})
                    self._maybe_finalize(lv)
                raise Gone(content, self._receipt(sess, len(sess.turns) - 1))
            self._journal({"ev": "call", "sid": sess.sid, "name": name, "args": args, "t": now})
            self._maybe_finalize(lv)
            out = {"ended": status == "submitted", "remaining": {"tool_calls": max(0, sess.max_calls - sess.n_calls), "wall_s": round(max(0.0, sess.deadline - now), 3)},
                   "receipt": self._receipt(sess, len(sess.turns) - 1 if status == "submitted" else turn["seq"])}
            out["content"] = "submitted" if status == "submitted" else content
            return out

    def finish(self, token):
        lv = self.find(token)
        with lv.lock:
            if lv.session.is_open:
                now = lv.tick(self.clock())
                lv.session.end("no submit", now)
                self._journal({"ev": "finish", "sid": lv.session.sid, "t": now})
                self._maybe_finalize(lv)
            return {"ended": True, "reason": lv.session.record["reason"]}

    def _maybe_finalize(self, lv):
        sess = lv.session
        if sess.is_open or lv.slot_no in self.records:
            return
        rec = sess.record
        rec["bb"]["sig"] = agent_sig.sign(self.secret, BB.session_message(self.header["plan_hash"], self.label, rec)).hex()
        sess.turns = rec["turns"]
        with self.lock:
            self.records[lv.slot_no] = rec

    # -- progress and completion ---------------------------------------------------------------------------------------------------------------------

    def info(self):
        with self.lock:
            return {"protocol": BB.PROTOCOL, "round": self.rid, "plan_hash": self.header["plan_hash"], "commitment": self.r["commitment"], "arm": self.label, "service_pubkey": self.pubkey,
                    "limits": {"max_tool_calls": self.budget["max_tool_calls"], "max_wall_s": self.budget["max_wall_s"]}, "tasks": len(self.slots), "handed_out": self.next_slot,
                    "finished": len(self.records)}

    def complete(self):
        with self.lock:
            return len(self.records) == len(self.slots)

    def finish_arm(self):
        """Write the arm's ladder and log it, exactly as agent_rounds.evaluate_round does for a white-box arm. Refuses unless every task is finished and every record re-verifies."""
        import agent_compare
        with self.lock:
            if not self.complete():
                raise ServiceError("not every task is finished (%d of %d)" % (len(self.records), len(self.slots)))
            recs = [self.records[k] for k in sorted(self.records)]
        recs = sorted(recs, key=lambda r: (r["size"], r["idx"], r["trial"]))
        for r in recs:
            problems = BB.check_blackbox_trial(r, self.mod, self.master, self.header, True)
            if problems:
                raise ServiceError("REFUSED: a finished record does not re-verify (%s): not writing the ladder" % problems[0])
        path = os.path.join(self.d, "ladders", self.eid + ".jsonl")
        with AR._lock(self.d):
            r_now = R._read_json(os.path.join(self.d, "round.json"))
            if r_now["state"] != "closed" or self.eid in AR._evaluated_ids(self.d):
                raise ServiceError("the round moved on (%s) or the arm is already logged" % r_now["state"])
            agent_core.write_ladder(path, self.header, recs)
            sm = agent_compare.summarize(self.header, recs)
            R.append_log(self.d, "evaluated", {"eid": self.eid, "handle": self.handle, "label": self.label, "ladder_sha256": AR._file_sha(path),
                                               "digest": agent_compare.ladder_digest(self.header, recs), "solved": sm["solved_instances"], "instances": sm["instances"], "served": {}}, time.time())
        return path


# ---- HTTP -------------------------------------------------------------------------------------------------------------------------------------------

def _bearer(headers):
    v = headers.get("Authorization", "")
    return v[7:].strip() if v[:7].lower() == "bearer " else None


def _loads(raw):
    def bad(x):
        raise ValueError("non-finite number")
    try:
        return json.loads(raw.decode("utf-8"), parse_constant=bad)
    except RecursionError:
        raise ValueError("nesting too deep")
    except UnicodeDecodeError:
        raise ValueError("not UTF-8")


def make_handler(arm):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        timeout = SOCKET_TIMEOUT

        def log_message(self, *a):                       # no access log: URLs of /mcp/<token> and headers carry credentials
            pass

        # -- plumbing --------------------------------------------------------------------------------------------------------------------------------

        def _send(self, status, obj=None, extra=None):
            body = b"" if obj is None else json.dumps(obj).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if body:
                self.wfile.write(body)

        def _read_raw(self):
            """Read the request body ONCE, before any routing or authentication, so an early refusal (401, 404...) never leaves unread bytes on a keep-alive connection to corrupt the next request.
            Returns the bytes, or None after having sent the refusal (and marked the connection to close)."""
            if "chunked" in self.headers.get("Transfer-Encoding", "").lower():
                self.close_connection = True
                self._send(411, {"error": "Content-Length is required (chunked bodies are not accepted)"})
                return None
            try:
                n = int(self.headers.get("Content-Length", "0") or "0")
            except ValueError:
                n = -1
            if n < 0 or n > MAX_BODY:
                self.close_connection = True
                self._send(413 if n > MAX_BODY else 400, {"error": "bad or oversized Content-Length (limit %d bytes)" % MAX_BODY})
                return None
            if not n:
                return b""
            # the whole body must arrive within BODY_DEADLINE seconds: the per-recv socket timeout alone lets a client trickle one byte every few seconds and hold a thread for hours
            deadline, buf = time.monotonic() + BODY_DEADLINE, b""
            try:
                while len(buf) < n:
                    left = deadline - time.monotonic()
                    if left <= 0:
                        raise socket.timeout()
                    self.connection.settimeout(min(left, SOCKET_TIMEOUT))
                    chunk = self.rfile.read1(min(65536, n - len(buf)))
                    if not chunk:
                        self.close_connection = True                      # the client hung up mid-body
                        return None
                    buf += chunk
                self.connection.settimeout(SOCKET_TIMEOUT)
            except (socket.timeout, TimeoutError):
                self.close_connection = True
                self._send(408, {"error": "the request body did not arrive in time"})
                return None
            return buf

        def _body(self):
            raw = self._raw
            if not raw:
                return {}
            try:
                return _loads(raw)
            except ValueError as e:
                self._send(400, {"error": "not valid JSON (%s)" % str(e)[:60]})
                return None

        def _guard(self, fn):
            try:
                fn()
            except PermissionError:
                self._send(401, {"error": "unknown or missing token"})
            except Busy:
                self._send(429, {"error": "busy: another session is open", "retry_after": 1}, {"Retry-After": "1"})
            except Gone as e:
                self._send(409, {"error": "ended", "reason": str(e), "receipt": e.receipt})
            except BB.BlackboxError as e:
                self._send(400, {"error": str(e)})
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception:
                self._send(500, {"error": "internal error"})

        # -- routes ----------------------------------------------------------------------------------------------------------------------------------

        def do_GET(self):
            if self._read_raw() is None:
                return
            if urlparse(self.path).path == "/mcp" or urlparse(self.path).path.startswith("/mcp/"):
                # MCP's streamable HTTP lets a client open a GET event stream; this server does not stream, and the spec says to answer 405 (the SDK client then simply goes without one)
                return self._send(405, {"error": "no server-sent-event stream here: POST JSON-RPC requests"}, {"Allow": "POST, DELETE"})
            def route():
                path = urlparse(self.path).path
                if path == "/v1/info":
                    return self._send(200, arm.info())
                if path == "/v1/attestation":                      # public by design: it is evidence for READERS, who verify it themselves
                    return self._send(200, arm.evidence) if arm.evidence is not None else self._send(404, {"error": "this service publishes no TEE evidence"})
                self._send(404, {"error": "not found"})
            self._guard(route)

        def do_DELETE(self):
            if self._read_raw() is None:
                return

            def go():
                if urlparse(self.path).path.split("/")[1:2] != ["mcp"]:
                    return self._send(404, {"error": "not found"})
                sid = self.headers.get("Mcp-Session-Id")
                if not sid:
                    return self._send(400, {"error": "Mcp-Session-Id is required"})
                arm.finish(sid)
                self._send(200, {})
            self._guard(go)

        def _not_allowed(self):
            """Any other method: drain the body (bounded, with the same deadline) BEFORE answering, so an unread body cannot corrupt the next request on a kept-alive connection, and answer JSON, not the
            stock HTML 501."""
            if self._read_raw() is None:
                return
            self._send(405, {"error": "method not allowed"}, {"Allow": "GET, POST, DELETE"})

        do_PUT = do_PATCH = do_OPTIONS = _not_allowed

        def do_HEAD(self):
            if self._read_raw() is None:
                return
            self.send_response(405)                              # a HEAD response has headers and no body
            self.send_header("Allow", "GET, POST, DELETE")
            self.send_header("Content-Length", "0")
            self.end_headers()

        def do_POST(self):
            self._raw = self._read_raw()
            if self._raw is None:
                return

            def go():
                path = urlparse(self.path).path
                if path == "/v1/session":
                    return self._v1_session()
                if path in ("/v1/task", "/v1/call", "/v1/finish"):
                    return self._v1_session_call(path)
                if path == "/mcp" or path.startswith("/mcp/"):
                    return self._mcp(path)
                self._send(404, {"error": "not found"})
            self._guard(go)

        def _v1_session(self):
            tok = _bearer(self.headers)
            if not arm.arm_ok(tok):
                raise PermissionError()
            started = arm.start_session()
            if started is None:
                return self._send(200, {"done": True})
            token, lv = started
            out = arm.task(lv)
            out["session"] = token
            self._send(200, out)

        def _v1_session_call(self, path):
            tok = _bearer(self.headers)
            lv = arm.find(tok)
            if path == "/v1/finish":
                return self._send(200, arm.finish(tok))
            body = self._body()
            if body is None:
                return
            if path == "/v1/task":
                return self._send(200, arm.task(lv))
            if not isinstance(body, dict) or not isinstance(body.get("name"), str) or not isinstance(body.get("args", {}), dict):
                return self._send(400, {"error": "a call is {\"name\": string, \"args\": object}"})
            self._send(200, arm.call(tok, body["name"], body.get("args", {})))

        # -- MCP -------------------------------------------------------------------------------------------------------------------------------------

        def _mcp(self, path):
            body = self._body()
            if body is None:
                return
            if not isinstance(body, dict) or body.get("jsonrpc") != "2.0" or not isinstance(body.get("method"), str):
                return self._send(400, {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "a single JSON-RPC 2.0 request is required (no batches)"}})
            mid, method, params = body.get("id"), body["method"], body.get("params") or {}

            def ok(result, extra=None):
                self._send(200, {"jsonrpc": "2.0", "id": mid, "result": result}, extra)

            def err(code, msg):
                self._send(200, {"jsonrpc": "2.0", "id": mid, "error": {"code": code, "message": msg}})
            if method.startswith("notifications/"):
                return self._send(202)
            if method == "initialize":
                tok = path[5:] if path.startswith("/mcp/") and len(path) > 5 else _bearer(self.headers)
                if not arm.arm_ok(tok):
                    raise PermissionError()
                started = arm.start_session()
                if started is None:
                    return err(-32001, "no more tasks in this arm")
                token, lv = started
                return ok({"protocolVersion": params.get("protocolVersion") or MCP_VERSION, "capabilities": {"tools": {}}, "serverInfo": {"name": "guldo-tsp", "version": "1"},
                           "instructions": lv.session.prompt}, {"Mcp-Session-Id": token})
            sid = self.headers.get("Mcp-Session-Id")
            if method == "ping":
                return ok({})
            lv = arm.find(sid)
            if method == "tools/list":
                return ok({"tools": [{"name": s["name"], "description": s["description"], "inputSchema": s["input_schema"]} for s in _tool_specs_wire(lv.session.tools)]})
            if method == "tools/call":
                if not isinstance(params.get("name"), str) or not isinstance(params.get("arguments", {}), dict):
                    return err(-32602, "tools/call needs a name and an arguments object")
                try:
                    out = arm.call(sid, params["name"], params.get("arguments", {}))
                except Gone as e:
                    return ok({"content": [{"type": "text", "text": "the task is over (%s)" % e}], "isError": True})
                return ok({"content": [{"type": "text", "text": out["content"]}], "isError": out["content"].startswith("error:")})
            err(-32601, "method not found")
    return Handler


class _Server(ThreadingHTTPServer):
    """A threaded server with a CAP on simultaneous connections (a refused connection is closed at once, costing no thread), a real listen backlog, and daemon threads. Together with the
    per-connection socket timeout and the body deadline this bounds what idle, trickling or flooding clients can hold. (Tokens carry 192 bits of entropy, so no failure rate limiter is needed
    to stop guessing: the resource limits are what matter.)"""
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 128

    def __init__(self, addr, handler, max_connections=256):
        ThreadingHTTPServer.__init__(self, addr, handler)
        self._slots = threading.BoundedSemaphore(max(1, int(max_connections)))
        self.refused = 0
        self.network_errors = 0

    def handle_error(self, request, client_address):
        """Timeouts, resets, failed or plaintext-on-TLS handshakes are routine on a public port: count them, do not print a traceback for each (the default floods the log and hides real faults).
        Anything else is a bug and IS reported, by type only (a traceback could carry a request's contents)."""
        et = sys.exc_info()[0]
        if et is not None and issubclass(et, OSError):
            self.network_errors += 1
            return
        print("tool service: unexpected %s while handling a request" % getattr(et, "__name__", "error"), file=sys.stderr)

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            self.refused += 1
            self.shutdown_request(request)
            return
        try:
            ThreadingHTTPServer.process_request(self, request, client_address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            ThreadingHTTPServer.process_request_thread(self, request, client_address)
        finally:
            self._slots.release()


def make_server(arm, host="127.0.0.1", port=0, tls_cert=None, tls_key=None, max_connections=256):
    srv = _Server((host, port), make_handler(arm), max_connections)
    if tls_cert:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(tls_cert, tls_key)
        # the handshake must happen in the CONNECTION's thread (on its first read, under the socket timeout), not in the single accept loop: otherwise one client that connects and never
        # speaks stalls every other client
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True, do_handshake_on_connect=False)
    srv.tls_cert = tls_cert
    return srv


# ---- running an arm ---------------------------------------------------------------------------------------------------------------------------------

def serve_until_complete(arm, host="127.0.0.1", port=0, tls_cert=None, tls_key=None, poll=0.5, on_ready=None, exec_cmd=None, stop=None, max_connections=256):
    """Serve until every task is finished (or `stop` is set), then write the ladder. Returns the ladder path (or None when stopped early)."""
    srv = make_server(arm, host, port, tls_cert, tls_key, max_connections)
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    if on_ready:
        on_ready(srv)
    runner = None
    if exec_cmd:
        runner = threading.Thread(target=run_exec, args=(arm, srv, exec_cmd, stop), daemon=True)
        runner.start()
    try:
        while not arm.complete():
            if stop is not None and stop.is_set():
                return None
            arm.reap()
            time.sleep(poll)
        return arm.finish_arm()
    finally:
        srv.shutdown()
        srv.server_close()
        th.join(5)
        arm.close()


def run_exec(arm, srv, cmd, stop=None):
    """Run the vendor's command once per task: hand it only the URL and its session token; kill its process group (this exact child's) if it outlives the wall-time budget plus a grace."""
    import shlex
    argv = shlex.split(cmd) if isinstance(cmd, str) else list(cmd)
    scheme = "https" if isinstance(srv.socket, ssl.SSLSocket) else "http"
    url = "%s://127.0.0.1:%d" % (scheme, srv.server_address[1])
    while not arm.complete() and not (stop is not None and stop.is_set()):
        try:
            started = arm.start_session()
        except Busy:
            time.sleep(0.2)
            continue
        if started is None:
            return
        token, lv = started
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GULDO_TSP_URL": url, "GULDO_TSP_SESSION": token, "HOME": tempfile.gettempdir()}
        if getattr(srv, "tls_cert", None):
            env["GULDO_TSP_CAFILE"] = srv.tls_cert                 # the certificate to pin (a public file: never the key)
        with tempfile.TemporaryDirectory() as cwd:
            try:
                p = subprocess.Popen(argv, env=env, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            except OSError:
                with lv.lock:
                    if lv.session.is_open:
                        now = lv.tick(arm.clock())
                        lv.session.end("no submit", now)
                        arm._journal({"ev": "finish", "sid": lv.session.sid, "t": now})
                        arm._maybe_finalize(lv)
                continue
            try:
                p.wait(timeout=lv.session.max_wall + EXEC_GRACE)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(p.pid, signal.SIGKILL)               # this child's own group, by its exact id
                except OSError:
                    pass
                p.wait()
        arm.reap()
        with lv.lock:
            if lv.session.is_open:                                 # the command exited without submitting
                now = lv.tick(arm.clock())
                (lv.session.end("over wall-time budget", now) if now > lv.session.deadline else lv.session.end("no submit", now))
                arm._journal({"ev": "reap" if now > lv.session.deadline else "finish", "sid": lv.session.sid, "t": now})
                arm._maybe_finalize(lv)


def progress(base, rid, eid):
    d = AR._require(base, rid)
    jp = os.path.join(d, "bb", eid, "journal.jsonl")
    starts = ends = 0
    if os.path.exists(jp):
        with open(jp, "r", encoding="utf-8") as f:
            for ln in f:
                if '"ev":"start"' in ln:
                    starts += 1
    return {"journal": os.path.exists(jp), "sessions_started": starts, "ladder": os.path.exists(os.path.join(d, "ladders", eid + ".jsonl"))}


# ---- command line -----------------------------------------------------------------------------------------------------------------------------------

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--base", default=".")
        p.add_argument("--round", required=True)
        p.add_argument("--eid", required=True)
    p = sub.add_parser("arm-token")
    common(p)
    p.add_argument("--seed")
    p.add_argument("--key", required=True)
    p.add_argument("--practice", action="store_true")
    p.add_argument("--rotate", action="store_true")
    p = sub.add_parser("serve-arm")
    common(p)
    p.add_argument("--seed")
    p.add_argument("--practice", action="store_true")
    p.add_argument("--key", required=True)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8790)
    p.add_argument("--max-concurrent", type=int, default=1)
    p.add_argument("--max-connections", type=int, default=256, help="simultaneous TCP connections; more are closed at once")
    p.add_argument("--tee-evidence", help="agent_tee evidence JSON for THIS service, published at GET /v1/attestation")
    p.add_argument("--tls-cert")
    p.add_argument("--tls-key")
    p.add_argument("--exec", dest="exec_cmd")
    p.add_argument("--accept-unsandboxed-exec", action="store_true")
    p = sub.add_parser("status")
    common(p)
    p = sub.add_parser("check-receipts")
    p.add_argument("ladder")
    p.add_argument("receipts")
    p.add_argument("--pubkey", required=True, help="the service's public key as YOU obtained it out of band (hex)")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "status":
            print(json.dumps(progress(args.base, args.round, args.eid), indent=1))
            return 0
        if args.cmd == "check-receipts":
            header, records = agent_core.read_ladder(args.ladder)
            with open(args.receipts, "r", encoding="utf-8") as f:
                receipts = [json.loads(ln) for ln in f if ln.strip()]
            if (header.get("service") or {}).get("pubkey") != args.pubkey:
                print("FAIL  the ladder's service key is not the key you pinned")
                return 1
            probs = BB.check_receipts(records, receipts, args.pubkey)
            for p in probs[:20]:
                print("FAIL  " + p)
            print("RECEIPTS MATCH: every receipt is genuine and is in the published transcript" if not probs else "RECEIPTS DO NOT MATCH")
            return 1 if probs else 0
        master = agent_core.read_master(args.seed, args.practice)
        secret = agent_sig.load_secret(args.key)
        arm = Arm(args.base, args.round, args.eid, master, secret, max_concurrent=getattr(args, "max_concurrent", 1))
        if args.cmd == "arm-token":
            if arm.arm_hash and not args.rotate:
                print("an arm token already exists for %s; --rotate replaces it (the old one stops working)" % args.eid, file=sys.stderr)
                return 1
            print(arm.set_arm_token())
            print("(shown once; only its hash is stored. The service public key is %s)" % arm.pubkey, file=sys.stderr)
            return 0
        if not arm.arm_hash:
            print("no arm token yet: run arm-token first", file=sys.stderr)
            return 1
        if args.exec_cmd and not args.accept_unsandboxed_exec:
            print("--exec runs the vendor's command on this machine, where the seed is readable: containerise the service, then pass --accept-unsandboxed-exec", file=sys.stderr)
            return 1
        if getattr(args, "tee_evidence", None):
            with open(args.tee_evidence, "r", encoding="utf-8") as f:
                arm.set_evidence(json.load(f))
        print("service public key %s; arm %s (%s): %d tasks" % (arm.pubkey, args.eid, arm.label, len(arm.slots)))
        path = serve_until_complete(arm, args.host, args.port, args.tls_cert, args.tls_key, exec_cmd=args.exec_cmd, max_connections=args.max_connections,
                                    on_ready=lambda s: print("listening on %s:%d" % (s.server_address[0], s.server_address[1]), flush=True))
        print("arm finished: wrote %s" % path)
        return 0
    except (ServiceError, AR.Rejected, agent_core.AgentEvalError, OSError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
