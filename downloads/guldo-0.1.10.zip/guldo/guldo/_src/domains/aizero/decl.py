"""Declaration of a SHARDED-OPTIMISER (ZeRO) domain: three Adam steps on a linear model with n parameters, over a batch spread across 8 devices, with as little time and memory as you can.

size = d, n = 128 d parameters. The model is least squares:  L(theta) = 0.5 / B * |X theta - y|^2  with a batch of B = 8 rows (one per device) (X is B x n, y is B). theta_0 (n, scaled by 0.1), X and y are the SplitMix64 stream under `seed`
(tensorops.stream, the same floats as domains/aiinfer), in that order. Run THREE steps of Adam (lr 0.01, beta1 0.9, beta2 0.999, eps 1e-8, bias-corrected: m_hat = m / (1 - beta1^t), v_hat = v / (1 - beta2^t),
theta -= lr * m_hat / (sqrt(v_hat) + eps)) from m = v = 0, on the full-batch gradient g = X^T (X theta - y) / B. The answer is the final theta (n, flat) as INTEGERS in units of 2^-40; the judge recomputes
the three steps in float64 and accepts an answer within 1e-9 in every entry. A gradient that was not summed over the whole batch, a shard of optimiser state applied to the wrong parameters, or a stale parameter fails the check.

What ZeRO changes. Data parallelism (DDP) gives each device one row of the batch and sums the gradients with an all-reduce, but every device then holds the FULL parameters, gradient and both Adam moments and does the whole
(redundant) Adam update: the memory is 4n per device however many devices there are, and so is the update arithmetic. ZeRO shards the optimiser state: stage 1 keeps m and v for only n/8 of the parameters per device and updates
only that shard, then all-gathers the new parameters; stage 2 also reduce-scatters the gradient so each device only ever holds its shard of it; stage 3 also keeps only a shard of the parameters, all-gathering them (briefly)
when the forward needs them. The bytes on the network are the same as DDP's (a reduce-scatter plus an all-gather is an all-reduce); what falls is the redundant arithmetic and, much more, the memory.

The cost compared is the one of tflops_dist.py (tensorops_dist.py defines the machine): critical-path work, message rounds, bytes per device, and the PEAK bytes held on the busiest device (`--metric peak`), from which the
time on ANY interconnect is exact. An accounting convention over identical devices and links, not a measurement of any cluster.
"""
import hashlib
import hmac

import numpy as np

NAME = "aizero"
VERSION = "aizero-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 48)
SIZE_STEP = 16
REFERENCE_SOLVER = "reference.py"
RANKS = 8
BATCH = 8
STEPS = 3
LR, B1, B2, EPS = 0.01, 0.9, 0.999, 1e-8
SCALE = 2 ** 40
LIMIT = 2 ** 62
TOL = 1e-9
DOC = ("solve(seed, d, B, P): n = 128 d. theta_0 (n, times 0.1), X (B x n) and y (B) are the SplitMix64 stream under `seed` (tensorops.stream, u in [-1, 1), in that order; B = 8, P = 8 devices). Run 3 steps of "
       "Adam (lr 0.01, beta1 0.9, beta2 0.999, eps 1e-8, bias-corrected) from m = v = 0 on the gradient g = X^T (X theta - y) / B of 0.5 / B * |X theta - y|^2. Return the final theta (n) as a flat list of "
       "integers in units of 2^-40, each within 1e-9. Return None for no answer.")
REFERENCE_NOTE = ("One device holds the whole batch, the parameters, the gradient and both Adam moments and does everything: no communication. Known to be beaten on memory by sharding the optimiser state (ZeRO "
                  "stages 1 to 3), and, on a machine whose network is fast enough, on time by spreading the batch.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def adam(seed, d):
    n = 128 * d
    theta = _uniform(seed, 0, n) * 0.1
    X = _uniform(seed, n, BATCH * n).reshape(BATCH, n)
    y = _uniform(seed, n + BATCH * n, BATCH)
    m, v = np.zeros(n), np.zeros(n)
    for t in range(1, STEPS + 1):
        g = X.T @ (X @ theta - y) / BATCH
        m = B1 * m + (1 - B1) * g
        v = B2 * v + (1 - B2) * g * g
        theta = theta - LR * (m / (1 - B1 ** t)) / (np.sqrt(v / (1 - B2 ** t)) + EPS)
    return theta


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aizero-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, BATCH, RANKS], "planted": [int(v) for v in np.rint(adam(seed, size) * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, d, B, P = inst["args"]
    if not isinstance(ans, list) or len(ans) != 128 * d:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    return bool(np.max(np.abs(np.array(ans, dtype=np.float64) / SCALE - adam(seed, d))) <= TOL)
