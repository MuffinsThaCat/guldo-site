"""aimixed with bytes counted (tflops_mem3.py), TECHNIQUE: the mixed-precision recipe with BFLOAT16 where fp16 was used. The features and the weights' per-step copies are bf16, the sigmoid, residual and the master weights are fp32, and the residual is cast to bf16 for the gradient product with NO loss scale (bf16 has fp32's range, so nothing underflows or overflows). bf16 has three fewer mantissa bits than fp16: the question is whether the judge's 1e-6 loss tolerance survives that."""
import math

import tensorops as tp

RHO = 0.9
LAM = 1e-3
STEPS = 10000


def features(seed, d, n):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    return (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)


def solve(seed, d, n, labels):
    X = features(seed, d, n)
    lr = 1.0 / (tp.sum(X * X).item() / (4.0 * n) + LAM)
    X16 = tp.cast(X, "bf16")
    X = 0
    y = tp.cast(tp.tensor([float(v) for v in labels]), "fp32")
    Xt = tp.transpose(X16, (1, 0))
    w = tp.cast(tp.zeros((d,)), "fp32")
    for step in range(STEPS):
        z = tp.cast(X16 @ tp.cast(w, "bf16"), "fp32")
        r = 1.0 / (1.0 + tp.exp(-z)) - y
        g = tp.cast(Xt @ tp.cast(r, "bf16"), "fp32") * (1.0 / n) + w * LAM
        w = w - g * lr
    return [int(v * 1048576.0) for v in w.tolist()]
