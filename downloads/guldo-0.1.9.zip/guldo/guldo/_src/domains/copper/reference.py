"""Reference for copper: full search over the 2^b completions of the known high bits of p."""


def solve(N, hi, b):
    base = hi << b
    found = None
    # scans all 2^b completions (no early exit), so the cost depends on b alone and the ladder is predictable
    for c in range(base, base + (1 << b)):
        if N % c == 0 and found is None:
            found = c
    return found
