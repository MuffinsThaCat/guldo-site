#!/usr/bin/env bash
# Back up the competition's state (the data directory with every round's log, submissions and certificates, AND the secret seeds) and VERIFY the archive:
# every round's hash chain must verify and every seed must hash to a commitment published in its round's log. A seed that is lost or wrong cannot be fixed later:
# the round could then never be evaluated or revealed. Run as root; the archive is readable by root only because it contains the seeds.
#
#   bash deploy/ledger-backup.sh            (the systemd timer runs it daily; see deploy/ledger-backup.timer)
# Environment: LEDGER_ROOT (default /srv/ledger), BACKUP_DIR (default /root/backups), KEEP (archives to keep, default 14), CODE_DIR (default /opt/speedup-verification).
# Exit status is non-zero if the archive could not be made or does not verify, so a failing run shows up in `systemctl --failed`.
# This is a copy on the SAME machine: it survives a mistake, not the loss of the disk. Copy BACKUP_DIR off the machine too (EVAL_BOX.md, "Backups").
set -euo pipefail

ROOT="${LEDGER_ROOT:-/srv/ledger}"
OUT="${BACKUP_DIR:-/root/backups}"
KEEP="${KEEP:-14}"
CODE="${CODE_DIR:-/opt/speedup-verification}"
[ -d "$ROOT/data" ] || { echo "no $ROOT/data: nothing to back up" >&2; exit 1; }

umask 077
mkdir -p "$OUT"
name="$(basename "$ROOT")"
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
file="$OUT/ledger-$stamp.tgz"

# tar exits 1 for the harmless "file changed as we read it" (a submission arrived while it ran); the archive is verified below either way, so only a real failure (2+) stops here
rc=0
tar czf "$file" -C "$(dirname "$ROOT")" --exclude="$name/site" --exclude="$name/site.new" --exclude="$name/site.old" --exclude="$name/rehearsal" "$name" || rc=$?
[ "$rc" -le 1 ] || { echo "tar failed with status $rc" >&2; rm -f "$file"; exit 1; }
if command -v sha256sum >/dev/null; then SUM="sha256sum"; else SUM="shasum -a 256"; fi
( cd "$OUT" && $SUM "$(basename "$file")" > "$(basename "$file").sha256" )

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
tar xzf "$file" -C "$tmp"
status=0
CODE_DIR="$CODE" python3 - "$tmp/$name" <<'PY' || status=$?
import hashlib, json, os, sys
sys.path.insert(0, os.environ["CODE_DIR"])
import rounds

root = sys.argv[1]
base, seeds = os.path.join(root, "data"), os.path.join(root, "seeds")
bad = 0
rs = rounds.list_rounds(base)
for r in rs:
    ok, n, head, err = rounds.verify_log(rounds.rdir(base, r["id"]), r["commitments"])
    print(f"round {r['id']}: log {'OK' if ok else 'FAILED: ' + str(err)} ({n} entries)")
    bad += 0 if ok else 1
    sd = os.path.join(seeds, r["id"])
    if os.path.isdir(sd):
        found = 0
        for fn in sorted(os.listdir(sd)):
            if fn.endswith(".seed"):
                with open(os.path.join(sd, fn), "rb") as f:
                    good = hashlib.sha256(f.read()).hexdigest() in r["commitments"]
                found += 1
                if not good:
                    print(f"  seed {fn}: does NOT match any published commitment")
                    bad += 1
        print(f"  {found} seed file(s), each checked against the commitments")
        if found != len(r["commitments"]) and r["state"] != "revealed":
            print(f"  WARNING: {found} seeds for {len(r['commitments'])} commitments")
            bad += 1
sys.exit(1 if bad else 0)
PY

# keep the newest KEEP archives (and their checksums)
ls -1t "$OUT"/ledger-*.tgz 2>/dev/null | tail -n +"$((KEEP + 1))" | while read -r old; do rm -f "$old" "$old.sha256"; done

if [ "$status" -ne 0 ]; then
  echo "BACKUP WRITTEN BUT DOES NOT VERIFY: $file" >&2
  exit 1
fi
echo "backup verified: $file ($(du -h "$file" | cut -f1))"
