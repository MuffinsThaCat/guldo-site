"""Red-team: a detached daemon that keeps the stdout pipe open and sleeps forever, trying to hang the judge.
The meter must kill it at the wall deadline and report an overrun (timeout); it must never block."""
import os
import time


def solve(basis, bound2):
    if os.fork() == 0:
        os.setsid()
        while True:
            time.sleep(1)
    os._exit(0)
