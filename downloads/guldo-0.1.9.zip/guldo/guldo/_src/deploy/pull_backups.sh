#!/usr/bin/env bash
# Copy the server's verified backups to THIS computer and check every archive against its checksum. Run it from the operator's own computer.
#
#   bash deploy/pull_backups.sh root@<server ip>:/root/backups [DEST]        (DEST defaults to ~/guldo-backups)
#
# The source may also be a local directory (the tests use that). Archives are never overwritten or deleted here (--ignore-existing, no --delete), so a
# damaged archive on the server cannot replace a good copy you already have. DEST is made owner-only: the archives contain the SECRET SEEDS of any round
# that has not been revealed yet, so keep them on a disk you control and do not put them in a shared or synced folder.
# Exit status is non-zero if any archive fails its checksum or if there is no archive newer than 36 hours (the server's timer makes one daily).
set -euo pipefail

SRC="${1:-}"
DEST="${2:-$HOME/guldo-backups}"
[ -n "$SRC" ] || { sed -n '2,10p' "$0"; exit 2; }

umask 077
mkdir -p "$DEST"
chmod 700 "$DEST"

if [[ "$SRC" == *:* && "${SRC:0:1}" != "/" ]]; then
  rsync -a --ignore-existing -e "ssh -o BatchMode=yes" "${SRC%/}/" "$DEST/"
else
  rsync -a --ignore-existing "${SRC%/}/" "$DEST/"
fi

chmod 700 "$DEST"   # rsync -a copies the SOURCE directory's mode onto DEST; put it back

if command -v sha256sum >/dev/null; then CHECK="sha256sum -c"; else CHECK="shasum -a 256 -c"; fi
n=0; bad=0
for a in "$DEST"/ledger-*.tgz; do
  [ -e "$a" ] || continue
  n=$((n + 1))
  if [ -f "$a.sha256" ]; then
    if ! ( cd "$DEST" && $CHECK "$(basename "$a").sha256" >/dev/null 2>&1 ); then
      echo "CHECKSUM FAILED: $a (this copy is damaged; if the server's archive is fine, delete this file and run again to fetch a fresh one)" >&2
      bad=$((bad + 1))
    fi
  else
    echo "no checksum file for $a" >&2
    bad=$((bad + 1))
  fi
done

echo "$n archive(s) in $DEST, $bad problem(s)"
if [ "$n" -eq 0 ]; then echo "NO ARCHIVES" >&2; exit 1; fi
if [ -z "$(find "$DEST" -maxdepth 1 -name 'ledger-*.tgz' -mmin -2160 2>/dev/null | head -1)" ]; then
  echo "WARNING: no archive newer than 36 hours: the server's backup timer may have stopped" >&2
  bad=$((bad + 1))
fi
[ "$bad" -eq 0 ]
