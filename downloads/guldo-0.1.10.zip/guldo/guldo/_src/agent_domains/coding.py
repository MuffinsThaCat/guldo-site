"""Coding with derived hidden tests: write `solve(xs)` for a pipeline of list transformations described in words.

size = number of stages in the pipeline (2..6), which is the difficulty. The stages, their constants, three PUBLIC examples and 25 HIDDEN tests are a pure function of the instance
seed; the expected outputs come from a reference implementation of the same stages. The agent sees the numbered description and the public examples, and has a `run_tests` tool
that runs a candidate on the PUBLIC examples only. The answer is Python source defining `solve`. The judge runs it on the hidden inputs in a child process and compares with the
expected outputs, which never enter that process.

SECURITY NOTE. The child process has CPU/memory limits, a cleared environment, a throwaway directory and no stdin beyond the inputs, and the expected outputs are kept in the
parent. It is NOT a security sandbox: hostile code can still use the operating system as that user. Run untrusted agents inside a container or VM you can lose.
"""
import json
import os
import subprocess
import sys
import tempfile

import agent_core

NAME = "coding"
VERSION = "coding-v1"
SIZE_RANGE = (2, 6)
SIZE_STEP = 1
DOC = "Write Python source defining solve(xs) that applies the numbered stages in order. Submit the source."
RUNS_CODE = True      # verifying or running this domain EXECUTES agent-written code (see agent_core.runs_code)
N_HIDDEN = 25
N_EXAMPLES = 3
TIMEOUT_S = 20
MEM_LIMIT = 768 * 1024 * 1024    # peak resident memory of the candidate's process (a watchdog inside the child: RLIMIT_AS is not enforced on macOS)

# stage kinds: (key, text template, params generator, implementation)
STAGES = ("filter_mod", "map_affine", "drop_below", "dedupe", "sort_desc", "prefix_sums", "take_first", "reverse")


def _stage(r, kind):
    if kind == "filter_mod":
        m = r.randint(2, 5)
        return {"kind": kind, "m": m, "r": r.randint(0, m - 1)}
    if kind == "map_affine":
        return {"kind": kind, "a": r.randint(2, 4), "b": r.randint(-5, 9)}
    if kind == "drop_below":
        return {"kind": kind, "t": r.randint(-20, 20)}
    if kind == "take_first":
        return {"kind": kind, "k": r.randint(3, 7)}
    return {"kind": kind}


def stage_text(s):
    k = s["kind"]
    if k == "filter_mod":
        return "keep only the elements x with x %% %d == %d (Python's %% operator)" % (s["m"], s["r"])
    if k == "map_affine":
        return "replace every element x by x * %d + %d" % (s["a"], s["b"])
    if k == "drop_below":
        return "keep only the elements x with x >= %d" % s["t"]
    if k == "dedupe":
        return "remove repeated values, keeping the first occurrence of each"
    if k == "sort_desc":
        return "sort the list in descending order"
    if k == "prefix_sums":
        return "replace the list by its running sums (element i becomes the sum of elements 0..i)"
    if k == "take_first":
        return "keep only the first %d elements (all of them if there are fewer)" % s["k"]
    if k == "reverse":
        return "reverse the list"
    raise ValueError(k)


def apply_stage(s, xs):
    k = s["kind"]
    if k == "filter_mod":
        return [x for x in xs if x % s["m"] == s["r"]]
    if k == "map_affine":
        return [x * s["a"] + s["b"] for x in xs]
    if k == "drop_below":
        return [x for x in xs if x >= s["t"]]
    if k == "dedupe":
        seen, out = set(), []
        for x in xs:
            if x not in seen:
                seen.add(x)
                out.append(x)
        return out
    if k == "sort_desc":
        return sorted(xs, reverse=True)
    if k == "prefix_sums":
        out, acc = [], 0
        for x in xs:
            acc += x
            out.append(acc)
        return out
    if k == "take_first":
        return xs[:s["k"]]
    if k == "reverse":
        return xs[::-1]
    raise ValueError(k)


def run_stages(stages, xs):
    for s in stages:
        xs = apply_stage(s, xs)
    return xs


def derive(seed, size):
    r = agent_core.Rng(seed)
    for _ in range(300):
        stages = [_stage(r, r.choice(STAGES)) for _ in range(size)]
        cases = []
        for _ in range(N_EXAMPLES + N_HIDDEN):
            xs = [r.randint(-30, 60) for _ in range(r.randint(8, 30))]
            cases.append({"input": xs, "output": run_stages(stages, xs)})
        nonempty = sum(1 for c in cases if c["output"])
        distinct = len(set(canon_out(c["output"]) for c in cases))
        if nonempty >= 0.7 * len(cases) and distinct >= 0.8 * len(cases):
            return {"public": {"spec": ["%d. %s" % (i + 1, stage_text(s)) for i, s in enumerate(stages)], "signature": "def solve(xs):  # xs is a list of ints; return a list of ints",
                               "examples": cases[:N_EXAMPLES]},
                    "private": {"stages": stages, "tests": cases[N_EXAMPLES:]}}
    raise RuntimeError("could not derive a non-degenerate instance")


def canon_out(o):
    return json.dumps(o)


def prompt(public):
    ex = "\n".join("  solve(%s) == %s" % (json.dumps(e["input"]), json.dumps(e["output"])) for e in public["examples"])
    return ("Write Python source that defines\n  %s\nand applies these stages, in order, to the list xs:\n%s\nExamples:\n%s\nSubmit the complete source text."
            % (public["signature"], "\n".join(public["spec"]), ex))


def tool_specs(public):
    return [{"name": "run_tests", "description": "Run candidate Python source (defining solve) on the PUBLIC examples; returns which passed and the first difference.",
             "input_schema": {"type": "object", "properties": {"source": {"type": "string"}}, "required": ["source"]}}]


# The child: reads one header line {"source": ...}, defines solve, then answers one JSON line per input line. Expected outputs are never sent to it.
CHILD = r'''
import sys, json, os
real = sys.stdout
try:
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
    try:
        resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
    except (ValueError, OSError):
        pass
except ImportError:
    pass
sys.setrecursionlimit(2000)
head = json.loads(sys.stdin.readline())
import threading, time
def _watch(limit):
    scale = 1 if sys.platform == "darwin" else 1024
    while True:
        time.sleep(0.02)
        try:
            if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * scale > limit:
                os._exit(97)
        except Exception:
            return
threading.Thread(target=_watch, args=(head["mem_bytes"],), daemon=True).start()
ns = {"__name__": "candidate"}
sys.stdout = open(os.devnull, "w")
err = None
try:
    exec(compile(head["source"], "candidate.py", "exec"), ns)
    solve = ns["solve"]
except BaseException as e:
    err = "%s: %s" % (type(e).__name__, str(e)[:200])
for line in sys.stdin:
    if err is not None:
        res = {"error": err}
    else:
        try:
            out = solve(json.loads(line))
            json.dumps(out)
            res = {"out": out}
        except BaseException as e:
            res = {"error": "%s: %s" % (type(e).__name__, str(e)[:200])}
    real.write(json.dumps(res) + "\n")
    real.flush()
'''


def run_source(source, inputs):
    """Run candidate source on each input in a child process. Returns a list of {"out": ...} or {"error": ...}, one per input (all errors if the child died or timed out)."""
    if not isinstance(source, str) or len(source) > 20000:
        return [{"error": "source must be a string of at most 20000 characters"}] * len(inputs)
    payload = json.dumps({"source": source, "mem_bytes": MEM_LIMIT}) + "\n" + "".join(json.dumps(x) + "\n" for x in inputs)
    import agent_sandbox                      # local subprocess by default; a container with GULDO_SANDBOX=docker (SandboxError, never a wrong verdict, if the sandbox itself cannot run)
    with tempfile.TemporaryDirectory(prefix="guldo-agent-") as tmp:
        rc, out = agent_sandbox.run_python(CHILD, payload, tmp if not agent_sandbox.enabled() else None, TIMEOUT_S)
    if rc is None:
        return [{"error": "timeout"}] * len(inputs)

    class p:                                  # the rest of this function reads the child's exit status and output
        returncode, stdout = rc, out
    lines = [ln for ln in p.stdout.split("\n") if ln.strip()]
    res = []
    for ln in lines[:len(inputs)]:
        try:
            v = json.loads(ln)
            res.append(v if isinstance(v, dict) and ("out" in v or "error" in v) else {"error": "malformed reply"})
        except ValueError:
            res.append({"error": "malformed reply"})
    while len(res) < len(inputs):
        res.append({"error": "child ended early" if p.returncode else "no reply"})
    return res


class Env:
    def __init__(self, instance):
        self.examples = instance["public"]["examples"]

    def call(self, name, args):
        if name != "run_tests":
            return "error: unknown tool %r" % name
        if not isinstance(args, dict) or not isinstance(args.get("source"), str):
            return "error: source must be a string"
        res = run_source(args["source"], [e["input"] for e in self.examples])
        passed, first = 0, None
        for e, got in zip(self.examples, res):
            if "out" in got and got["out"] == e["output"]:
                passed += 1
            elif first is None:
                first = "input %s: expected %s, got %s" % (json.dumps(e["input"]), json.dumps(e["output"]), json.dumps(got.get("out", got.get("error"))))
        return "%d of %d public examples pass" % (passed, len(self.examples)) + ("" if first is None else "; first difference: " + first)


def make_env(instance):
    return Env(instance)


def reference_answer(instance):
    """Judge-side reference source: applies the real stages."""
    lines = ["def solve(xs):"]
    for s in instance["private"]["stages"]:
        lines.append("    " + _stage_code(s))
    lines.append("    return xs")
    return "\n".join(lines) + "\n"


def _stage_code(s):
    k = s["kind"]
    if k == "filter_mod":
        return "xs = [x for x in xs if x %% %d == %d]" % (s["m"], s["r"])
    if k == "map_affine":
        return "xs = [x * %d + %d for x in xs]" % (s["a"], s["b"])
    if k == "drop_below":
        return "xs = [x for x in xs if x >= %d]" % s["t"]
    if k == "dedupe":
        return "xs = list(dict.fromkeys(xs))"
    if k == "sort_desc":
        return "xs = sorted(xs, reverse=True)"
    if k == "prefix_sums":
        return "xs = [sum(xs[:i + 1]) for i in range(len(xs))]"
    if k == "take_first":
        return "xs = xs[:%d]" % s["k"]
    if k == "reverse":
        return "xs = xs[::-1]"
    raise ValueError(k)


def verify(instance, answer, calls):
    if not isinstance(answer, str):
        return False, "answer must be Python source text"
    tests = instance["private"]["tests"]
    res = run_source(answer, [t["input"] for t in tests])
    bad = 0
    first = None
    for t, got in zip(tests, res):
        if "out" in got and got["out"] == t["output"]:
            continue
        bad += 1
        if first is None:
            first = got.get("error", "wrong output")
    return (bad == 0), ("ok" if bad == 0 else "%d of %d hidden tests fail (%s)" % (bad, len(tests), first))
