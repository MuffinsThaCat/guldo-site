def ccz(a, b, c):
    # the standard Clifford+T doubly-controlled Z (the Toffoli circuit without its two Hadamards on the target); ops: 0 H, 1 X, 4 T, 5 Tdg, 6 CNOT
    return [(6, b, c), (5, c), (6, a, c), (4, c), (6, b, c), (5, c), (6, a, c), (4, b), (4, c), (6, a, b), (4, a), (5, b), (6, a, b)]


def solve(n):
    g = [(0, q) for q in range(n)]
    for _ in range(2):
        g.append((8,))                                  # the phase oracle
        g += [(0, q) for q in range(n)] + [(1, q) for q in range(n)]
        g += ccz(0, 1, 2)
        g += [(1, q) for q in range(n)] + [(0, q) for q in range(n)]
    flat = []
    for t in g:
        flat += list(t) + [0] * (4 - len(t))
    return flat
