"""aimlp in the counted-operations API, CHEAT: the reference method stopped after 8 steps. It is cheap and (almost always) does not reach the target accuracy, so the judge rejects it."""
import math

import tensorops as tp

K = 3
H = 32
KAPPA = 10.0
STEPS = 8
LR = 0.5


def solve(seed, d, n, labels):
    sc = tp.tensor([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = tp.reshape(tp.stream(seed, 0, n * d), (n, d)) * sc
    Y = tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(n)])
    W1 = tp.stream(seed ^ 20817, 0, d * H, (d, H)) * math.sqrt(3.0 / d)
    W2 = tp.stream(seed ^ 21074, 0, H * K, (H, K)) * math.sqrt(3.0 / H)
    for step in range(STEPS):
        A = tp.relu(X @ W1)
        Z2 = A @ W2
        E = tp.exp(Z2 - tp.max(Z2, 1, True))
        G = (E / tp.sum(E, 1, True) - Y) * (1.0 / n)
        dA = tp.einsum("nk,hk->nh", G, W2)
        dW1 = tp.einsum("ni,nh->ih", X, dA * (A / (A + 1e-30)))
        dW2 = tp.einsum("nh,nk->hk", A, G)
        W1 = W1 - dW1 * LR
        W2 = W2 - dW2 * LR
    return [int(x * 1048576.0) for x in tp.reshape(W1, (d * H,)).tolist()] + [int(x * 1048576.0) for x in tp.reshape(W2, (H * K,)).tolist()]
