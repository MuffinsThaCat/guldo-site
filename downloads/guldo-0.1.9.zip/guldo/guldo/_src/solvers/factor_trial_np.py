"""Factoring submission: the same trial division, vectorized with numpy (candidates in chunks, one modulo per chunk).
The algorithm is unchanged (same candidates, same order); only the implementation is faster. Needs n < 2**64."""
import numpy as np

CHUNK = 1 << 20


def solve(n):
    if n % 2 == 0:
        return 2
    nn = np.uint64(n)
    limit = int(n ** 0.5) + 1
    start = 3
    while start <= limit:
        stop = min(start + 2 * CHUNK, limit + 2)
        cand = np.arange(start, stop, 2, dtype=np.uint64)
        hits = np.flatnonzero(nn % cand == 0)
        if hits.size:
            return int(cand[hits[0]])
        start = stop
    return n
