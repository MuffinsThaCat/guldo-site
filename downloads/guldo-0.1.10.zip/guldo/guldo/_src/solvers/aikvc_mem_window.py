"""aikvc with bytes counted (tflops_mem.py), LOSSY CHEAT: evict all but the last 128 positions from the cache (a sliding window). Far fewer bytes; the attention here reaches the whole context, so the output is wrong and the judge must reject it."""
import math

import tensorops as tp

D, R, S = 32, 4, 64


def solve(seed, n):
    o = 2 * n * R
    Zk = tp.stream(seed, 0, n * R, (n, R))
    Zv = tp.stream(seed, n * R, n * R, (n, R))
    Bk = tp.stream(seed, o, R * D, (R, D)) * (2.0 * 3.0 / math.sqrt(R))
    Bv = tp.stream(seed, o + R * D, R * D, (R, D)) * (3.0 / math.sqrt(R))
    base = tp.stream(seed, o + 2 * R * D, S * D, (S, D)) * 2.0
    K = Zk @ Bk
    V = Zv @ Bv
    K = K[n - 128:n]
    V = V[n - 128:n]
    prev = tp.zeros((D,))
    outs = []
    for t in range(S):
        s = (K @ (base[t] + prev * 4.0)) / math.sqrt(D)
        e = tp.exp(s - tp.max(s))
        prev = (e / tp.sum(e)) @ V
        outs.append(prev)
    return [int(x * 65536.0) for x in tp.concat(outs, 0).tolist()]
