"""Declaration of a REAL-DATA, REAL-MODEL, LOOKUP-RESISTANT inference domain for a CONVOLUTIONAL network (not an MLP): label a batch of real handwritten digits, corrupted by a seed-keyed noise, with a real trained CNN.

Nothing is planted. The images are real (the 10000 MNIST TEST digits, 28 x 28, pixel values 0..255) and the model is a real network that training produced (train.py rebuilds everything; the networks reach 96.7%,
97.3% and 97.6% on the test images, trained on the 60000 training images only). The network (F = size = 16, 32 or 48): conv1 with a 2 x 2 kernel, stride 2 and F/2 channels, ReLU (a 14 x 14 map); conv2 with a
2 x 2 kernel, stride 2 and F channels, ReLU (a 7 x 7 map); a linear classifier from the 7 * 7 * F features to 10 logits. Each convolution is one matrix product on the image cut into non-overlapping 2 x 2 patches
(reshapes and a transpose, no gather), with its weights shared across all positions. The weights are committed in this directory by content hash (a changed byte fails at import), rounded to 6 decimals.

The instance's ARGUMENTS are [F, Q, seed, X, K1, b1, K2, b2, Wf, bf]: Q = 128 test images drawn by a seed-keyed choice (X, Q x 784 integer pixels) and the network (K1 4 x F/2, b1 F/2, K2 2F x F, b2 F, Wf 49F x 10,
bf 10; K2 has 4 * F/2 = 2F rows). They are SMALL (about 0.6 MB at the largest width), so unlike airealm this domain fits the 1 MiB instance limit of the timed protocol and can be compiled. The images the network is
asked about are the clean test images PLUS noise the solver regenerates from `seed`: x' = clip(x + s u, 0, 255) with s = 76 (F = 16), 92 (F = 32) or 108 (F = 48) and u the SplitMix64 stream under `seed`
(tensorops.stream(seed, 0, Q * 784), u in [-1, 1), row-major, the same floats as domains/aiinfer); clip by relu(v) - relu(v - 255). The network is run on x' / 255, the 28 x 28 image row-major with one channel;
a patch is read in the order (row, column, channel) and the patches in the order (patch row, patch column); a layer's output is flattened (position, channel). The answer is the list of Q class labels (ints 0-9) that
agrees with the network's own prediction on at least 98% of the queries (at most 2 of 128 may differ; a tie counts as agreement). The judge recomputes from the arguments and never looks at the true labels.

WHY THE NOISE, AND WHY IT RISES WITH THE WIDTH. The pool and the networks are public and fixed, so without noise the answers are a fixed table anyone can precompute. With it they depend on a seed the entrants do not
have until a committed master seed is revealed, and a table of the network's answers on the CLEAN images agrees with its answers on the noisy ones only about 90% of the time at every width (calibrated per width on
40 instances each: mean 0.895 to 0.907, worst 0.93 to 0.961, far under the 98% bar). A wider network is more noise-robust, so the scale rises with it (the same lesson as airealm, whose first build used one scale for
every width and let a clean-image table pass 30% of the widest network's instances). The queries are heavily corrupted digits; the networks still read them 88 to 90% right.

What this is for: `aireal` and `airealm` ask whether pruning, distillation and low precision pay on a real MLP; this asks it of a convolutional network, whose weights are shared across positions (so there is
little to prune and the arithmetic is mostly in the convolutions, not the weights), at an instance size the timed protocol can carry.

The cost is counted operations and bytes (tflops_mem3.py): exactly reproducible, not a time.
"""
import hashlib
import hmac
import os

import numpy as np

NAME = "airealc"
VERSION = "airealc-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (16, 48)
SIZE_STEP = 16
REFERENCE_SOLVER = "reference.py"
HERE = os.path.dirname(os.path.abspath(__file__))
WIDTHS = (16, 32, 48)
Q = 128
NOISE = {16: 76.0, 32: 92.0, 48: 108.0}   # the noise scale per network width: wider networks are more noise-robust, so a clean-image table would otherwise pass them
AGREE = 0.98
MNIST_SHA256 = "c3f9adf9c66efb572b1f9326c3a511b45910c7173b97be66ceceeeeaef6b802b"
MODEL_SHA256 = {16: "318e57e427a9c402e886b76a1eb8a674fc13c2479a1b3ac8064cfde86fe279e8", 32: "6661c91e6c24ec45f3002aa680a748840981e30cbffc66e4b1f136c62759b008",
                48: "3a176b42a74ea8797818400ede5e673fd988590d1ced10f36b24d20f5965110c"}
DOC = ("solve(F, Q, seed, X, K1, b1, K2, b2, Wf, bf): X is Q x 784 integer pixels (0..255) of real MNIST test digits; the queries are x' = clip(x + s u, 0, 255) with s = 76 (F = 16), 92 (F = 32), 108 (F = 48) and "
       "u = tensorops.stream(seed, 0, Q*784) (u in [-1, 1), row-major, reshaped Q x 784). The network is a CNN on x'/255 as 28 x 28 single-channel images: conv1 = 2 x 2 patches (non-overlapping, read in the order "
       "(row, col, channel), patches in the order (patch row, patch col)) times K1 (4 x F/2) plus b1, ReLU (a 14 x 14 x F/2 map, flattened (position, channel)); conv2 = the same on that map, times K2 (2F x F) plus b2, "
       "ReLU (7 x 7 x F, flattened (position, channel)); logits = that times Wf (49F x 10) plus bf. Return the list of Q class labels (ints 0-9) that agrees with the network's own prediction (the arg-max logit) "
       "on at least 98% of the queries. Return None for no answer.")
REFERENCE_NOTE = ("The dense network on the noisy batch in float64: the images cut into patches, one matrix product per layer. Whether pruning channels, refitting, or lower precision pay on a REAL convolutional "
                  "network, and by how much, is what the domain measures; a lookup table of the clean images' answers does not pass it.")


def _content_hash(*arrs):
    m = hashlib.sha256()
    for a in arrs:
        m.update(np.ascontiguousarray(a).tobytes())
    return m.hexdigest()


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


_CACHE = {}


def load():
    """-> (images (10000 x 784 uint8), labels (10000), {F: (K1, b1, K2, b2, Wf, bf)}), each checked against its committed content hash."""
    if "d" not in _CACHE:
        d = np.load(os.path.join(HERE, "mnist_test.npz"))
        X, y = d["X"], d["y"]
        if _content_hash(X, y) != MNIST_SHA256:
            raise RuntimeError("airealc: mnist_test.npz does not match its committed content hash")
        models = {}
        for F in WIDTHS:
            m = np.load(os.path.join(HERE, f"model_{F}.npz"))
            P = tuple(m[k] for k in ("K1", "b1", "K2", "b2", "Wf", "bf"))
            if _content_hash(*P) != MODEL_SHA256[F]:
                raise RuntimeError(f"airealc: model_{F}.npz does not match its committed content hash")
            models[F] = P
        _CACHE["d"] = (X, y, models)
    return _CACHE["d"]


def _seed(master, tag, size, idx):
    return int.from_bytes(hmac.new(master, f"airealc-v1:{tag}:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def queries(seed, X, F):
    """The noisy queries the width-F network is asked about, float64 Q x 784."""
    u = _uniform(seed, 0, X.shape[0] * 784).reshape(X.shape[0], 784)
    v = X.astype(np.float64) + NOISE[F] * u
    return np.maximum(v, 0.0) - np.maximum(v - 255.0, 0.0)


def patches(x, n, side, c):
    """(n, side*side*c) with the channel LAST per position -> (n * (side/2)^2, 4c): non-overlapping 2 x 2 patches, each read (row, col, channel)."""
    t = x.reshape(n, side // 2, 2, side // 2, 2, c).transpose(0, 1, 3, 2, 4, 5)
    return t.reshape(n * (side // 2) ** 2, 4 * c)


def network(P, Xq, F):
    """The CNN on x' / 255 (Xq: Q x 784 on the 0..255 scale) -> logits Q x 10."""
    K1, b1, K2, b2, Wf, bf = (np.asarray(p, dtype=np.float64) for p in P)
    n = Xq.shape[0]
    a1 = np.maximum(patches(Xq / 255.0, n, 28, 1) @ K1 + b1, 0.0)
    a2 = np.maximum(patches(a1.reshape(n, -1), n, 14, F // 2) @ K2 + b2, 0.0)
    return a2.reshape(n, -1) @ Wf + bf


def logits(args):
    F, q, seed, X = args[:4]
    return network(args[4:], queries(seed, np.asarray(X), F), F)


def derive(master: bytes, size: int, idx: int) -> dict:
    X, y, models = load()
    pick = np.random.RandomState(_seed(master, "pick", size, idx) % (2 ** 32)).choice(len(y), Q, replace=False)
    P = models[size]
    args = [size, Q, _seed(master, "noise", size, idx), X[pick].astype(int).tolist()] + [p.tolist() for p in P]
    return {"args": args, "planted": [int(v) for v in np.argmax(logits(args), axis=1)], "truth": [int(y[i]) for i in pick],
            "clean": [int(v) for v in np.argmax(network(P, X[pick].astype(np.float64), size), axis=1)]}


def verify(inst: dict, ans) -> bool:
    args = inst["args"]
    q = args[1]
    if not isinstance(ans, list) or len(ans) != q:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or not 0 <= v < 10 for v in ans):
        return False
    L = logits(args)
    agree = int((L[np.arange(q), np.asarray(ans)] >= L.max(axis=1)).sum())
    return bool(agree >= int(np.ceil(AGREE * q)))
