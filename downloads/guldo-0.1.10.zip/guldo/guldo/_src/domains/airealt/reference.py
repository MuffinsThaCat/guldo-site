"""Reference for airealt: the dense transformer on the noisy batch in float64, every position of every context through both blocks, the logits taken at the last position."""
import math

import numpy as np

NOISE = {24: 0.025, 32: 0.029, 40: 0.032}     # per width, as in decl.py
KEYS = ("E", "P", "g1", "b1", "Wq", "Wk", "Wv", "Wo", "g2", "b2", "W1", "c1", "W2", "c2", "gf", "bf", "Wh", "bh")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _ln(x, g, b):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + 1e-5) * g + b


def solve(D, Q, seed, X, *weights):
    P = {k: np.asarray(w, dtype=np.float64) for k, w in zip(KEYS, weights)}
    tok = np.asarray(X)
    n, t = tok.shape
    x = P["E"][tok] + P["P"][None, :t] + NOISE[D] * _uniform(seed, 0, n * t * D).reshape(n, t, D)
    dh = D // 4
    for l in range(2):
        h = _ln(x, P["g1"][l], P["b1"][l])
        q, k, v = (h @ P[w][l] for w in ("Wq", "Wk", "Wv"))
        sp = lambda a: a.reshape(n, t, 4, dh).transpose(0, 2, 1, 3)
        s = sp(q) @ sp(k).transpose(0, 1, 3, 2) / math.sqrt(dh) + np.triu(np.full((t, t), -1e30), 1)
        e = np.exp(s - s.max(-1, keepdims=True))
        x = x + ((e / e.sum(-1, keepdims=True)) @ sp(v)).transpose(0, 2, 1, 3).reshape(n, t, D) @ P["Wo"][l]
        h = _ln(x, P["g2"][l], P["b2"][l])
        x = x + np.maximum(h @ P["W1"][l] + P["c1"][l], 0.0) @ P["W2"][l] + P["c2"][l]
    return [int(c) for c in np.argmax(_ln(x[:, -1], P["gf"], P["bf"]) @ P["Wh"] + P["bh"], axis=1)]
