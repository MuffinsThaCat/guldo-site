"""Insurer-facing failure-rate reports from agent certificates: what a verified ladder says about how often an agent fails, with exact bounds and the assumptions kept visibly apart.

From one verified ladder (agent_eval.py verify) it reports, per size and overall:
  * the failure frequency per TASK (an instance is failed unless more than half its trials pass), with an exact one-sided 95% Clopper-Pearson UPPER bound: the failure rate we cannot rule out;
  * the per-TRIAL failure frequency, descriptive only (trials of one instance are not independent, so no bound is claimed for it);
  * unsafe-outcome frequency and its upper bound, for the safety domains (agent_safety.py);
  * expected tokens per SUCCESS (mean tokens on solved trials / per-task solve rate), the cost of getting one right answer;
  * an EXPECTED LOSS table only if the caller supplies loss-per-failure and task volume. Those numbers are the caller's assumptions and are printed as such, never measured here.

What this is not. It is not an actuarial model: no severity distribution, no correlation between failures, no tail, no drift when the model changes under the same name, no adversarial users. The failure
rate is for the TESTED generator at the tested sizes under the ladder's caps; real tasks differ, in a direction nobody can promise is benign. A bound from n tasks is only as tight as n allows:
zero failures in 20 tasks still permits a true failure rate near 14%.
"""
import agent_compare
import agent_core
import agent_safety

LIMITS = ["Failure frequencies are for the tested generator, at the tested sizes, under this ladder's caps; the insured's tasks are different.",
          "The bounds assume the tasks of a size are independent draws (they come from distinct HMAC seeds); trials of one task are not, so no bound is claimed per trial.",
          "A ladder says nothing about severity, correlated failures, a model update behind the same name, or hostile users; none is modelled here.",
          "Tokens are proxy tokens unless the ladder was attested (agent_attest.py); a verified ladder shows its records are consistent and correct, and independent witnesses or attestation are what show a model produced them.",
          "Loss figures appear only if supplied, and are the supplier's assumptions."]


def report(header, records, loss_per_failure=None, tasks_per_year=None, currency="", alpha=agent_core.ALPHA, master=None, verified=False):
    """`verified=True` only if the caller re-verified the ladder from the seed first (agent_tools does, whenever it is given the seed); the report then says so. Otherwise it says in capitals that the
    records were NOT re-checked: a report built on an edited ladder looks exactly like one built on a real one."""
    inst =agent_compare.per_instance(header, records)
    n = len(inst)
    fails = sum(1 for v in inst.values() if not v["solved"])
    trials = sum(v["K"] for v in inst.values())
    trial_fails = trials - sum(v["k"] for v in inst.values())
    rows = []
    for s in header["sizes"]:
        vs = [v for (sz, _), v in inst.items() if sz == s]
        f = sum(1 for v in vs if not v["solved"])
        rows.append({"size": s, "tasks": len(vs), "failed": f, "failure_rate": f / float(len(vs)), "failure_rate_upper95": round(1.0 - agent_core.cp_lower(len(vs) - f, len(vs), alpha), 6)})
    solved_tokens = [r["tokens"] for r in records if r["solved"]]
    solve_rate = (n - fails) / float(n)
    mean_tok = sum(solved_tokens) / float(len(solved_tokens)) if solved_tokens else None
    out = {"agent": header.get("agent", {}).get("label"), "domain": header["domain"], "plan_hash": header["plan_hash"], "practice": header["practice"], "tasks": n, "failed_tasks": fails,
           "failure_rate": fails / float(n), "failure_rate_upper95": round(1.0 - agent_core.cp_lower(n - fails, n, alpha), 6),
           "trials": trials, "failed_trials": trial_fails, "trial_failure_rate_descriptive": trial_fails / float(trials), "by_size": rows,
           "expected_tokens_per_success": (mean_tok / solve_rate) if (mean_tok is not None and solve_rate > 0) else None, "counter": header["counter"], "limits": LIMITS, "ladder_verified_from_seed": bool(verified)}
    if agent_safety.is_safety_domain(header["domain"]):
        out["safety"] = agent_safety.safety_summary(header, records, alpha, master=master)
    if loss_per_failure is not None and tasks_per_year is not None:
        out["expected_loss_ASSUMED"] = {"currency": currency, "loss_per_failure": loss_per_failure, "tasks_per_year": tasks_per_year,
                                        "at_observed_rate": round(out["failure_rate"] * tasks_per_year * loss_per_failure, 2),
                                        "at_upper95_rate": round(out["failure_rate_upper95"] * tasks_per_year * loss_per_failure, 2),
                                        "note": "loss_per_failure and tasks_per_year are inputs supplied by the caller, not measured; the upper figure is the loss if the true failure rate were the bound"}
    return out


def render(rep):
    L = ["FAILURE-RATE REPORT  %s on %s%s" % (rep["agent"], rep["domain"], "   (PRACTICE SEED: a demonstration, not a certified result)" if rep["practice"] else ""),
         "LADDER RE-VERIFIED FROM THE SEED: yes" if rep.get("ladder_verified_from_seed") else "LADDER NOT RE-VERIFIED: these figures are only as good as the file; run `agent_eval.py verify` or give this tool the seed",
         "plan %s" % rep["plan_hash"],
         "tasks: %d, failed: %d  -> failure rate %.3f; cannot rule out up to %.3f (95%% one-sided upper bound)" % (rep["tasks"], rep["failed_tasks"], rep["failure_rate"], rep["failure_rate_upper95"]),
         "trials: %d, failed: %d  -> per-trial failure frequency %.3f (descriptive only)" % (rep["trials"], rep["failed_trials"], rep["trial_failure_rate_descriptive"])]
    for r in rep["by_size"]:
        L.append("  size %-4d failed %d/%d  rate %.3f  upper95 %.3f" % (r["size"], r["failed"], r["tasks"], r["failure_rate"], r["failure_rate_upper95"]))
    if rep["expected_tokens_per_success"] is not None:
        L.append("expected tokens per correct result: %.0f (%s)" % (rep["expected_tokens_per_success"], "proxy tokens" if rep["counter"] == agent_core.COUNTER else rep["counter"]))
    if "safety" in rep:
        s = rep["safety"]
        L.append("UNSAFE outcomes: %d of %d trials (upper95 %.3f)" % (s["unsafe_trials"], s["trials"], s["unsafe_rate_upper95"]))
    if "expected_loss_ASSUMED" in rep:
        e = rep["expected_loss_ASSUMED"]
        L.append("expected annual loss, on the CALLER'S ASSUMPTIONS (%s %s per failure, %s tasks/year): %.2f at the observed rate, %.2f at the upper bound" % (e["loss_per_failure"], e["currency"], e["tasks_per_year"], e["at_observed_rate"], e["at_upper95_rate"]))
    L.append("LIMITS:")
    L += ["  - " + x for x in rep["limits"]]
    return "\n".join(L)
