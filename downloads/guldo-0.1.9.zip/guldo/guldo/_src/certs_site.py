"""The site's Certificates section: every certificate in a directory, re-verified at build time, with the attestations that name it.

A directory holds  NAME.cert.json,  NAME.<anything>.att.json  (attest.py sign output) and optionally  trusted.txt  (public keys, one hex per
line, `# name` allowed) that the site operator pinned from keys obtained out of band. Nothing here is trusted from the files: the certificate is
verified by certificate.verify with this checkout (nothing in it is executed), and each attestation is checked by attest.check.
The section says plainly what an unpinned key is worth: nothing about independence.
"""
import glob
import html
import json
import os
import shutil

import attest
import certificate


def _read(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def collect(certs_dir):
    """-> [{"name", "file", "cert", "result", "atts": [(file, attestation)], "attest": check result}] (a malformed file is shown as a failure, never skipped)."""
    trusted = []
    tpath = os.path.join(certs_dir, "trusted.txt")
    if os.path.exists(tpath):
        trusted = list(attest.read_trusted(tpath))
    out = []
    for cpath in sorted(glob.glob(os.path.join(certs_dir, "*.cert.json"))):
        name = os.path.basename(cpath)[: -len(".cert.json")]
        try:
            cert = _read(cpath)
            result = certificate.verify(cert)
        except Exception as e:  # a certificate is untrusted input: whatever it makes the verifier raise is a failed certificate, never a failed site build
            out.append({"name": name, "file": os.path.basename(cpath), "cert": None,
                        "result": {"ok": False, "checks": [{"check": "format", "status": "fail", "detail": f"unreadable or hostile: {type(e).__name__}"}], "claim": None},
                        "atts": [], "attest": None})
            continue
        atts = []
        for apath in sorted(glob.glob(os.path.join(glob.escape(certs_dir), glob.escape(name) + ".*.att.json"))):
            try:
                atts.append((os.path.basename(apath), _read(apath)))
            except (OSError, ValueError):
                atts.append((os.path.basename(apath), {}))
        try:
            checked = attest.check(cert, [a for _, a in atts], trusted) if atts else None
        except Exception as e:  # attest.check is hardened, but one hostile attestation must never cost the whole page
            checked = {"ok": False, "pinned": 0, "unvouched": 0, "checks": [{"check": "attestations", "status": "fail", "detail": f"could not be checked: {type(e).__name__}"}]}
        out.append({"name": name, "file": os.path.basename(cpath), "cert": cert, "result": result, "atts": atts, "attest": checked})
    return out


def section_html(certs_dir):
    """The Results-page section for `certs_dir`, or "" when it holds no certificate."""
    items = collect(certs_dir) if certs_dir and os.path.isdir(certs_dir) else []
    if not items:
        return ""
    label = {"pass": "Checked", "fail": "Failed", "skip": "Not checked", "warn": "Note"}
    cards = []
    for it in items:
        res = it["result"]
        claim = res["claim"]
        private = isinstance(it["cert"], dict) and it["cert"].get("private") is True
        head = (f'{html.escape(str(claim["credit_bits"]))} bits, {html.escape(str(claim["status"]))}' if claim else "does not verify")
        if private and claim:
            head += " (private solver)"
        counted = isinstance(it["cert"], dict) and isinstance(it["cert"].get("count"), dict)
        if counted and claim:
            head += " (step counting)"
        rlog = it["cert"].get("log") if isinstance(it["cert"], dict) else None
        data0 = rlog[0].get("data") if isinstance(rlog, list) and rlog and isinstance(rlog[0], dict) else None
        round_declared = bool(claim) and isinstance(data0, dict) and data0.get("cost_model") == "count"   # a verified certificate whose round declared the counted ladder in entry 0
        counted_note = ('<p class="fine"><strong>Step counting.</strong> The costs in this certificate are counts of Python instructions, not seconds. Anyone on the same Python '
                        "version can re-execute instances and must get identical counts, which proves those costs without trusting any machine. It cannot see work done inside "
                        "built-in C functions, "
                        + ("and the question sizes, the number of questions and the cap were declared by the round in its first log entry, before any submission, the same for every "
                           "participant.</p>" if round_declared else
                           "and the question sizes were chosen by whoever ran it, so it is not an official round result.</p>")) if counted else ""
        private_note = ('<p class="fine"><strong>Private solver.</strong> Its source is not in this certificate, so it can be neither inspected nor re-run here: '
                        "the timings rest on the operator's sandbox alone. Its hash is recorded in the certificate (for a round, it was also in the round's log before "
                        "the seeds were revealed), so if its owner publishes the file anyone can check it.</p>") if private else ""
        rows = "".join(f'<tr><td>{html.escape(c["check"])}</td><td><strong>{label.get(c["status"], c["status"])}</strong></td><td class="fine">{html.escape(c["detail"])}</td></tr>'
                       for c in res["checks"])
        att_html = '<p class="fine">No one has attested to this certificate yet.</p>'
        if it["attest"]:
            a = it["attest"]
            att_html = ("<h4>Independent re-checks</h4>"
                        f'<p class="fine"><strong>{a["pinned"]}</strong> from keys the operator pinned out of band; <strong>{a["unvouched"]}</strong> from keys nobody has vouched for. '
                        "A signature shows who signed, not that they are unconnected to the operator, so only the first number is counted as independent.</p>"
                        '<ul class="fine">' + "".join(f'<li>{html.escape(c["check"])}: {html.escape(c["detail"])}</li>' for c in a["checks"]) + "</ul>")
        links = " ".join(f'<a href="certs/{html.escape(f)}">{html.escape(f)}</a>' for f in [it["file"]] + [f for f, _ in it["atts"]])
        cards.append(f'<article class="card"><h3>{html.escape(it["name"])}: {head}</h3>'
                     '<p class="fine">Re-verified when this page was built, with nothing from the file executed. Checking proves the arithmetic and the fairness; '
                     f'it does not prove the recorded timings were honest (see the Limits page).</p>{private_note}{counted_note}'
                     f'<div class="scroll"><table class="lb"><thead><tr><th>Check</th><th>Outcome</th><th>What it found</th></tr></thead><tbody>{rows}</tbody></table></div>'
                     f'{att_html}<p class="fine">Files: {links}</p></article>')
    return '<section class="block"><h2>Certificates</h2><div style="display:grid;gap:18px">' + "".join(cards) + "</div></section>"


def copy_files(certs_dir, out_dir):
    """Copy the certificates, attestations and the pinned-key list (all public) into out_dir/certs."""
    if not certs_dir or not os.path.isdir(certs_dir):
        return
    os.makedirs(os.path.join(out_dir, "certs"), exist_ok=True)
    wanted = glob.glob(os.path.join(certs_dir, "*.cert.json")) + glob.glob(os.path.join(certs_dir, "*.att.json")) + glob.glob(os.path.join(certs_dir, "trusted.txt"))
    for p in sorted(wanted):  # exactly these: any other file in the directory (a key, a note, someone's JSON) is never published
        shutil.copy(p, os.path.join(out_dir, "certs", os.path.basename(p)))
