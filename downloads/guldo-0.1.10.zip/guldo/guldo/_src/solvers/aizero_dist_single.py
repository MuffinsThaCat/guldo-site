"""aizero in the cluster-counted API, REFERENCE: one device holds the whole batch, the parameters, the gradient and both Adam moments and does all three steps. No communication."""
import tensorops as tp

LR, B1, B2, EPS = 0.01, 0.9, 0.999, 1e-8
STEPS = 3


def ints(theta):
    return list(map(int, (theta * 1099511627776.0).tolist()))


def adam_update(theta, m, v, g, t):
    """One Adam step on whatever slice the device holds (the whole vector or its shard)."""
    m = m * B1 + g * (1 - B1)
    v = v * B2 + g * g * (1 - B2)
    theta = theta - (m * (1.0 / (1 - B1 ** t))) / (tp.sqrt(v * (1.0 / (1 - B2 ** t))) + EPS) * LR
    return theta, m, v


def local_grad(theta, X, y, B):
    """The gradient contribution of the rows in X: X^T (X theta - y) / B (the loss is averaged over the WHOLE batch B)."""
    r = X @ theta - y
    return tp.transpose(X, (1, 0)) @ r * (1.0 / B)


def solve(seed, d, B, P):
    n = 128 * d
    tp.use(0)
    theta = tp.stream(seed, 0, n) * 0.1
    X = tp.reshape(tp.stream(seed, n, B * n), (B, n))
    y = tp.stream(seed, n + B * n, B)
    m = tp.zeros((n,))
    v = tp.zeros((n,))
    for t in range(1, STEPS + 1):
        theta, m, v = adam_update(theta, m, v, local_grad(theta, X, y, B), t)
    return ints(theta)
