"""Reference for aitrain: plain full-batch gradient descent on the softmax loss. Learning rate 2.0, 12000 steps, no feature scaling, no momentum, float64.

The features are regenerated from the seed with the SplitMix64 stream documented in domains/aitrain/decl.py (the same stream as aiinfer), so the instance stays a few
numbers plus the labels. Regenerating them is shared by the reference and every submission.
"""
import math

import numpy as np

K = 3
KAPPA = 30.0
STEPS = 12000
LR = 2.0


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, n, labels):
    scales = np.array([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = _uniform(seed, 0, n * d).reshape(n, d) * scales
    Y = np.eye(K)[np.asarray(labels)]
    W = np.zeros((d, K))
    for _ in range(STEPS):
        Z = X @ W
        E = np.exp(Z - Z.max(axis=1, keepdims=True))
        W = W - (X.T @ (E / E.sum(axis=1, keepdims=True) - Y)) * (LR / n)
    return [int(v) for v in np.rint(W * 2 ** 20).ravel()]
