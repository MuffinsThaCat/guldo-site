"""Child process: load a solver module, read one instance on stdin, print its answer as one JSON line on stdout.

Payload: {"args": [...]} and the solver is called as solve(*args). The older lattice payload {"basis": ..., "bound2": ...}
is still accepted. Answers: None (no answer), an integer, or a list of integers.

Anything the solver prints goes to STDERR, not stdout: stdout is the answer channel, and a stray print() would otherwise
corrupt it and get a correct solver marked wrong. (The harness also parses only the last line of stdout, so output a C
extension writes straight to file descriptor 1 cannot corrupt the answer either.)"""
import importlib.util
import json
import numbers
import os
import resource
import sys

# CPU cap set HERE (soft == hard, so the solver cannot raise it) rather than via subprocess preexec_fn, which is not
# safe when the harness spawns from several threads. Set before the solver module is even imported.
_lim = os.environ.get("SVP_CPU_LIMIT")
if _lim:
    resource.setrlimit(resource.RLIMIT_CPU, (int(_lim), int(_lim)))


def normalize(out):
    """Turn a solver's return value into something JSON-serializable, or raise TypeError for anything else."""
    if out is None:
        return None
    if isinstance(out, bool):
        raise TypeError("solve() returned a bool; return an int, a list of ints, or None")
    if isinstance(out, numbers.Integral):
        return int(out)
    if isinstance(out, (list, tuple)):
        if any(isinstance(c, bool) or not isinstance(c, numbers.Integral) for c in out):
            raise TypeError("solve() returned a list containing non-integers")
        return [int(c) for c in out]
    raise TypeError(f"solve() returned {type(out).__name__}; return an int, a list of ints, or None")


def main():
    path = sys.argv[1]
    real_out, sys.stdout = sys.stdout, sys.stderr  # solver prints (even at import time) cannot reach the answer channel
    spec = importlib.util.spec_from_file_location("submission", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    req = json.loads(sys.stdin.read())
    args = req["args"] if "args" in req else [req["basis"], req["bound2"]]
    answer = normalize(mod.solve(*args))
    real_out.write("\n" + json.dumps(answer) + "\n")  # leading newline: the answer is always on its own, last line
    real_out.flush()


if __name__ == "__main__":
    main()
