"""Static HTML report of speedup-verification runs: leaderboard, per-run charts, tables, limits.

  python3 report_html.py --out results/report.html [--pair BASELINE.jsonl SUBMISSION.jsonl ...]

With no --pair it finds every (baseline, submission) ladder pair under results/ (judged_<family>_<tag>_...). Everything on
the page is computed from the saved ladders by the same functions the judge uses (extrapolate.py), so each number can be
traced to data. The page is one self-contained file: inline CSS/SVG, a few lines of JS for tooltips, Google Fonts only.
"""
import argparse
import html
import json
import math
import os
import random
import re
import statistics
import time

import extrapolate as E
import judge

HERE = os.path.dirname(os.path.abspath(__file__))
PAIR_RE = re.compile(r"^judged_([a-z]+)_([0-9a-f]{8})_(baseline|submission)_(.+)\.py\.jsonl$")  # any registered family


def esc(x):
    return html.escape(str(x), quote=True)


# ---------------------------------------------------------------- data
def load_pair(base_path, sub_path):
    mb, base = E.load(base_path)
    ms, sub = E.load(sub_path)
    only_b, only_s = E.coverage_mismatch(base, sub)
    if only_b or only_s:  # shown as "Could not read": a page must never chart a truncated run as if it were complete
        raise ValueError(f"the ladders do not cover the same instances ({len(only_b)} only in the baseline, "
                         f"{len(only_s)} only in the submission)")
    budget = mb["budget"]
    (tb, bc), (ts, sc) = E.per_dim_times(base, budget), E.per_dim_times(sub, budget)
    pts = []  # (baseline cost, submission cost, bits, id)
    for d in tb:
        for i, cb in tb[d].items():
            if i in ts.get(d, {}) and not bc[d][i] and cb >= E.FLOOR_ABS:
                pts.append((cb, ts[d][i], math.log2(cb / ts[d][i]), f"{d}:{i}"))
    bins = E._group([(cb, cs) for cb, cs, _, _ in pts])
    info, top = E._usable_top(bins)
    meas, mtop, _ = E.measured_by_difficulty(tb, ts, bc, random.Random(1))
    hp, hp_n, hp_sub = E.hard_pool_claim(tb, ts, bc, random.Random(1))
    n_total = sum(len(v) for v in tb.values())
    n_censored = sum(1 for d in bc for i in bc[d] if bc[d][i])
    return {"meta_b": mb, "meta_s": ms, "budget": budget, "pts": pts, "info": info, "top": mtop, "meas": meas, "hp": hp,
            "hp_n": hp_n, "hp_sub": hp_sub, "n_total": n_total, "n_censored": n_censored, "curve": dim_curve(tb, ts, bc, sc)}


def find_pairs(results_dir):
    files = {}
    for fn in sorted(os.listdir(results_dir)):
        m = PAIR_RE.match(fn)
        if m:
            files.setdefault((m.group(1), m.group(2)), {}).setdefault(m.group(3), []).append((m.group(4), os.path.join(results_dir, fn)))
    out = []
    for (fam, tag), roles in sorted(files.items()):
        for base in roles.get("baseline", [])[:1]:
            for name, path in roles.get("submission", []):
                out.append({"family": fam, "tag": tag, "baseline": base[1], "submission": path, "name": name})
    return out


# ---------------------------------------------------------------- charts (hand-placed SVG, one scale per axis)
W, H = 640, 310
ML, MR, MT, MB = 46, 84, 16, 58  # right margin holds the credit label outside the plot; bottom holds tick, n and axis title


def fmt_tick(t):
    return "0" if t == 0 else f"{t:+g}"


def _nice_ticks(lo, hi):
    step = 1 if hi - lo <= 8 else 2
    t = math.floor(lo / step) * step
    out = [t]
    while out[-1] < hi - 1e-9:  # always end on a tick at or above the data maximum, or the top point leaves the plot
        out.append(out[-1] + step)
    return out


def bin_chart(info, top, credit, budget):
    keys = sorted(info)
    if not keys:
        return '<p class="muted">No instance reached the 0.5 s floor on the baseline, so there are no bins to draw.</p>'
    vals = [info[k]["median_bits"] for k in keys]
    lo, hi = min(-1.0, min(vals) - 0.5, (credit or 0) - 0.5), max(1.0, max(vals) + 0.5)
    ticks = _nice_ticks(lo, hi)
    lo, hi = ticks[0], ticks[-1]

    def y(v):
        return MT + (H - MT - MB) * (hi - v) / (hi - lo)

    pw = (W - ML - MR) / len(keys)
    bw = min(46, pw * 0.62)
    g = []
    for t in ticks:
        g.append(f'<line class="grid" x1="{ML}" x2="{W - MR}" y1="{y(t):.1f}" y2="{y(t):.1f}"/>'
                 f'<text class="tick" x="{ML - 8}" y="{y(t) + 4:.1f}" text-anchor="end">{fmt_tick(t)}</text>')
    g.append(f'<line class="zero" x1="{ML}" x2="{W - MR}" y1="{y(0):.1f}" y2="{y(0):.1f}"/>')
    for j, k in enumerate(keys):
        x = ML + pw * j + pw / 2
        v = info[k]["median_bits"]
        usable, used = info[k]["usable"], k in top
        cls = "bar used" if used else ("bar usable" if usable else "bar unusable")
        top_y, h = (y(v), y(0) - y(v)) if v >= 0 else (y(0), y(v) - y(0))
        tip = (f"baseline cost {info[k]['lo']:g} to {info[k]['hi']:g} s: {info[k]['n']} instances, median speedup {v:+.2f} bits, "
               f"submission median cost {info[k]['median_sub_cost']} s, "
               + ("in the credit" if used else ("usable, not among the 3 hardest" if usable else "not usable (too few instances or below the cost floor)")))
        g.append(f'<rect class="{cls}" x="{x - bw / 2:.1f}" y="{top_y:.1f}" width="{bw:.1f}" height="{max(h, 1.5):.1f}" rx="3" '
                 f'data-tip="{esc(tip)}" tabindex="0"/>')
        g.append(f'<text class="tick" x="{x:.1f}" y="{H - MB + 16}" text-anchor="middle">{info[k]["lo"]:g}–{info[k]["hi"]:g}</text>')
        g.append(f'<text class="n" x="{x:.1f}" y="{H - MB + 31}" text-anchor="middle">n={info[k]["n"]}</text>')
    if credit is not None:
        g.append(f'<line class="credit" x1="{ML}" x2="{W - MR + 4}" y1="{y(credit):.1f}" y2="{y(credit):.1f}"/>'
                 f'<text class="creditlbl" x="{W - MR + 8}" y="{y(credit) + 4:.1f}">credit {credit:.1f}</text>')
    g.append(f'<text class="axis" x="{(ML + W - MR) / 2}" y="{H - 6}" text-anchor="middle">baseline cost of the instance (s, octaves)</text>')
    g.append(f'<text class="axis" transform="translate(12 {(MT + H - MB) / 2}) rotate(-90)" text-anchor="middle">median speedup (bits)</text>')
    return f'<svg class="chart" viewBox="0 0 {W} {H}" role="img" aria-label="Median speedup per baseline-cost bin">{"".join(g)}</svg>'


def scatter_chart(pts, info, top, budget):
    if not pts:
        return ""
    lo_x, hi_x = math.log2(E.FLOOR_ABS), math.log2(max(budget, max(p[0] for p in pts)) * 1.05)
    bits = [p[2] for p in pts]
    ticks = _nice_ticks(min(-1.0, min(bits) - 0.5), max(1.0, max(bits) + 0.5))
    lo, hi = ticks[0], ticks[-1]

    def x(c):
        return ML + (W - ML - MR) * (math.log2(c) - lo_x) / (hi_x - lo_x)

    def y(v):
        return MT + (H - MT - MB) * (hi - v) / (hi - lo)

    g = []
    for t in ticks:
        g.append(f'<line class="grid" x1="{ML}" x2="{W - MR}" y1="{y(t):.1f}" y2="{y(t):.1f}"/>'
                 f'<text class="tick" x="{ML - 8}" y="{y(t) + 4:.1f}" text-anchor="end">{fmt_tick(t)}</text>')
    g.append(f'<line class="zero" x1="{ML}" x2="{W - MR}" y1="{y(0):.1f}" y2="{y(0):.1f}"/>')
    c = E.FLOOR_ABS
    while c <= max(budget, 1):
        g.append(f'<text class="tick" x="{x(c):.1f}" y="{H - MB + 16}" text-anchor="middle">{c:g}</text>')
        c *= 4
    for cb, cs, b, iid in pts:
        k = int(math.floor(math.log2(cb / E.FLOOR_ABS)))
        used = k in top
        tip = f"instance {iid}: baseline {cb:.2f} s, submission {cs:.2f} s, {b:+.2f} bits" + (" (in the credit)" if used else "")
        g.append(f'<circle class="pt {"used" if used else "other"}" cx="{x(cb):.1f}" cy="{y(b):.1f}" r="4" data-tip="{esc(tip)}" tabindex="0"/>')
    g.append(f'<text class="axis" x="{(ML + W - MR) / 2}" y="{H - 6}" text-anchor="middle">baseline cost of the instance (s, log scale)</text>')
    g.append(f'<text class="axis" transform="translate(12 {(MT + H - MB) / 2}) rotate(-90)" text-anchor="middle">speedup (bits)</text>')
    return f'<svg class="chart" viewBox="0 0 {W} {H}" role="img" aria-label="Per-instance speedup against baseline cost">{"".join(g)}</svg>'


MIN_DIM_N = 3  # fewer paired instances than this at a dimension and no median is reported for it


def dim_curve(tb, ts, bc, sc, boot=400):
    """Speedup BY DIMENSION, computed the way the estimator computes it (extrapolate.speedup_table, usable_dims) so the chart cannot disagree
    with the credit. tb/ts: {dim: {instance: cost}} for baseline and submission (a failure is charged the cap); bc/sc: {dim: {instance: failed}}.
      * the median is over ALL paired instances. Where the baseline hit the cap its cost is taken as the cap, so that instance contributes a
        LOWER bound: this is what keeps the hardest instances (where the speedup is largest) from being silently dropped at large dimensions
        (an earlier version averaged only the instances the baseline finished and showed a non-monotone, understated curve)
      * `usable` / `why` are the estimator's own verdict (at most half the baseline runs capped, costs at least the 0.5 s floor)
      * a 90% bootstrap interval of the median, seeded by the dimension so the same data always gives the same interval
    A dimension with fewer than MIN_DIM_N paired instances has no median at all."""
    usable, dropped = E.usable_dims(bc, sc, tb, ts)
    out = {}
    for d in sorted(tb):
        ids = sorted(set(tb[d]) & set(ts.get(d, {})))
        bits = [math.log2(tb[d][i] / ts[d][i]) for i in ids]
        rec = {"n": len(ids), "censored": sum(1 for i in ids if bc[d].get(i)), "sub_failed": sum(1 for i in ids if sc.get(d, {}).get(i)),
               "usable": d in usable, "why": dropped.get(d, ""), "median": None, "lo": None, "hi": None}
        if len(bits) >= MIN_DIM_N:
            rng = random.Random(d)
            rec["median"] = statistics.median(bits)
            meds = sorted(statistics.median([bits[rng.randrange(len(bits))] for _ in bits]) for _ in range(boot))
            rec["lo"], rec["hi"] = meds[int(0.05 * boot)], meds[int(0.95 * boot) - 1]
        out[d] = rec
    return out


def dim_chart(curve, budget):
    """A filled point with its 90% interval at each dimension the estimator uses; a HOLLOW point (no interval) where it does not, with the
    reason in its tooltip. No line is drawn between points: a trend across a gap would be a claim the data does not make."""
    if not curve:
        return '<p class="muted">No dimensions to chart.</p>'
    dims = sorted(curve)
    vals = [v for r in curve.values() if r["usable"] for v in (r["median"], r["lo"], r["hi"]) if v is not None]
    vals += [r["median"] for r in curve.values() if not r["usable"] and r["median"] is not None]
    ticks = _nice_ticks(min(-1.0, min(vals, default=0) - 0.5), max(1.0, max(vals, default=0) + 0.5))
    lo, hi = ticks[0], ticks[-1]

    def y(v):
        return MT + (H - MT - MB) * (hi - v) / (hi - lo)
    pw = (W - ML - MR) / len(dims)
    g = []
    for t in ticks:
        g.append(f'<line class="grid" x1="{ML}" x2="{W - MR}" y1="{y(t):.1f}" y2="{y(t):.1f}"/>'
                 f'<text class="tick" x="{ML - 8}" y="{y(t) + 4:.1f}" text-anchor="end">{fmt_tick(t)}</text>')
    g.append(f'<line class="zero" x1="{ML}" x2="{W - MR}" y1="{y(0):.1f}" y2="{y(0):.1f}"/>')
    for j, d in enumerate(dims):
        r, x = curve[d], ML + pw * j + pw / 2
        g.append(f'<text class="tick" x="{x:.1f}" y="{H - MB + 16}" text-anchor="middle">{d}</text>')
        capped = f"{r['censored']} of {r['n']} baseline runs hit the cap and count as lower bounds" if r["censored"] else "no baseline run hit the cap"
        if r["median"] is None:
            why = f"dimension {d}: only {r['n']} paired instance(s); {MIN_DIM_N} are needed for a median, so nothing is shown"
            g.append(f'<text class="n" x="{x:.1f}" y="{H - MB + 31}" text-anchor="middle">n={r["n"]}</text>'
                     f'<circle class="pt other" cx="{x:.1f}" cy="{y(0):.1f}" r="5" data-tip="{esc(why)}" tabindex="0"/>')
        elif r["usable"]:
            g.append(f'<line class="whisk" x1="{x:.1f}" x2="{x:.1f}" y1="{y(r["lo"]):.1f}" y2="{y(r["hi"]):.1f}"/>'
                     f'<line class="whisk" x1="{x - 5:.1f}" x2="{x + 5:.1f}" y1="{y(r["lo"]):.1f}" y2="{y(r["lo"]):.1f}"/>'
                     f'<line class="whisk" x1="{x - 5:.1f}" x2="{x + 5:.1f}" y1="{y(r["hi"]):.1f}" y2="{y(r["hi"]):.1f}"/>')
            tip = (f"dimension {d}: median speedup {r['median']:+.2f} bits (90% interval {r['lo']:+.2f} to {r['hi']:+.2f}) over {r['n']} paired instances; {capped}")
            g.append(f'<circle class="pt used" cx="{x:.1f}" cy="{y(r["median"]):.1f}" r="5" data-tip="{esc(tip)}" tabindex="0"/>')
            g.append(f'<text class="n" x="{x:.1f}" y="{H - MB + 31}" text-anchor="middle">'
                     f'{(str(r["censored"]) + " capped") if r["censored"] else "n=" + str(r["n"])}</text>')
        else:
            if r["why"].startswith("baseline timeouts"):
                why = (f"dimension {d}: the baseline hit the cap on {r['censored']} of {r['n']} instances (more than half), so the estimator does not use "
                       f"this dimension. The hollow point is the median with capped baselines taken as the cap: a lower bound, {r['median']:+.2f} bits, not a measurement")
                short = "capped"
            else:
                why = (f"dimension {d}: {r['why']}, so the estimator does not use this dimension (a fixed setup cost, not the algorithm, would dominate). "
                       f"Median {r['median']:+.2f} bits shown for reference only")
                short = "< floor"
            g.append(f'<circle class="pt other" cx="{x:.1f}" cy="{y(r["median"]):.1f}" r="5" data-tip="{esc(why)}" tabindex="0"/>')
            g.append(f'<text class="n" x="{x:.1f}" y="{H - MB + 31}" text-anchor="middle">{short}</text>')
    g.append(f'<text class="axis" x="{(ML + W - MR) / 2}" y="{H - 6}" text-anchor="middle">dimension</text>')
    g.append(f'<text class="axis" transform="translate(12 {(MT + H - MB) / 2}) rotate(-90)" text-anchor="middle">median speedup (bits)</text>')
    return f'<svg class="chart" viewBox="0 0 {W} {H}" role="img" aria-label="Median speedup per dimension with 90% intervals">{"".join(g)}</svg>'


# ---------------------------------------------------------------- page parts
ICON = {
    "OFFICIAL": '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><circle cx="8" cy="8" r="7" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4.6 8.4l2.2 2.2 4.6-5" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
    "PROVISIONAL": '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><circle cx="8" cy="8" r="7" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 1.5a6.5 6.5 0 0 1 0 13z" fill="currentColor"/></svg>',
    "INCONCLUSIVE": '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><circle cx="8" cy="8" r="7" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4.5 8h7" stroke="currentColor" stroke-width="1.8"/></svg>',
}


def pill(kind, text):
    return f'<span class="pill {kind.lower()}">{ICON[kind]}<span>{esc(text)}</span></span>'


def status_pill(status):
    return pill("OFFICIAL", "Official") if status == "OFFICIAL" else pill("PROVISIONAL", "Provisional")


def leaderboard(board):
    rows = judge.leaderboard_rows(board)
    if not rows:
        return '<p class="muted">No scored runs yet.</p>'
    out = ['<div class="scroll"><table class="lb"><thead><tr><th>Submission</th><th>Family</th><th class="num">Credit (bits)</th>'
           '<th>Status</th><th>Per seed</th></tr></thead><tbody>']
    for r in rows:
        seeds = ", ".join("inconclusive" if v == "inconclusive" else f"{v:g}" for v in r["per_seed"])
        why = "".join(f'<li>{esc(x)}</li>' for x in r["reasons"])
        out.append(f'<tr><td class="strong">{esc(r["name"])}</td><td>{esc(r["family"])}</td><td class="num mono">{r["credit"]:.1f}</td>'
                   f'<td>{status_pill(r["status"])}<div class="small muted">{esc(r["status"])}</div></td><td class="mono">{esc(seeds)}</td></tr>')
        if why:
            out.append(f'<tr class="why"><td colspan="5"><span class="small muted">Not official because</span><ul>{why}</ul></td></tr>')
    out.append("</tbody></table></div>")
    return "".join(out)


def run_section(spec, d):
    meas = d["meas"]
    credit = None if meas is None else max(0.0, meas[1])
    ms = d["meta_s"]
    head = (f'<h3>{esc(spec["name"])} <span class="muted">on {esc(spec["family"])}, seed {esc(spec["tag"])}</span></h3>')
    if credit is None:
        verdict = pill("INCONCLUSIVE", "Inconclusive") + ('<p>Fewer than two difficulty bins had at least 5 instances and a submission '
                                                          'cost of at least 0.5 s, so no credit can be certified from this run.</p>')
    else:
        verdict = (f'<p class="big"><span class="mono">{credit:.1f}</span> bits certified '
                   f'<span class="muted">(median speedup {meas[0]:.1f}; the credit is the one-sided 95% lower bound)</span></p>')
    hp = d["hp"]
    hp_txt = ("inconclusive (needs 12 instances at 4 s or more and a submission median cost of at least 0.5 s)" if hp is None else
              f"at least {max(0.0, hp[1]):.1f} bits (median {hp[0]:.1f}, {d['hp_n']} instances)")
    facts = [("Instances", f"{d['n_total']} generated, {d['n_censored']} where the baseline hit the {d['budget']:g} s cap (excluded)"),
             ("Run", f"{esc(ms.get('sandbox') or 'bare local process')}, {esc(ms.get('jobs', 1))} concurrent job(s), {esc(ms.get('cpu', 'unknown CPU'))}"),
             ("Hard-pool claim (exploratory)", hp_txt)]
    dl = "".join(f"<div><dt>{a}</dt><dd>{b}</dd></div>" for a, b in facts)
    rows = "".join(
        f'<tr><td class="mono">{x["lo"]:g}–{x["hi"]:g}</td><td class="num mono">{x["n"]}</td><td class="num mono">{x["median_bits"]:+.2f}</td>'
        f'<td class="num mono">{x["median_sub_cost"]}</td><td>{"in the credit" if k in d["top"] else ("usable" if x["usable"] else "not usable")}</td></tr>'
        for k, x in sorted(d["info"].items()))
    table = ('<details class="tv"><summary>Table view</summary><div class="scroll"><table class="lb"><thead><tr><th>Baseline cost (s)</th>'
             '<th class="num">Instances</th><th class="num">Median bits</th><th class="num">Submission median (s)</th><th>Role</th></tr></thead>'
             f'<tbody>{rows}</tbody></table></div></details>')
    curve = d.get("curve")  # absent in dicts built by older callers: then the section simply has no dimension chart
    dimfig = ""
    if curve:
        dimfig = (f'<figure><figcaption>Speedup by dimension</figcaption>{dim_chart(curve, d["budget"])}'
                  '<p class="small muted">Median over all paired instances, with a 90% bootstrap interval; where the baseline hit its cap its cost is '
                  'taken as the cap, so those instances can only understate the speedup. Hollow points are dimensions the estimator does not use '
                  '("capped": more than half the baseline runs hit the cap; "&lt; floor": costs under 0.5 s): they are <strong>not measured</strong>, '
                  'shown only as lower bounds or for reference. Intervals of neighbouring dimensions often overlap, so a rising median is a tendency, '
                  'not a measured rate. Growth beyond the last measured dimension is not measured either: no line is drawn across a gap, and '
                  'nothing here is extrapolated.</p></figure>')
    return (f'<section class="run">{head}{verdict}<dl class="facts">{dl}</dl>'
            f'<figure><figcaption>Speedup by how hard the baseline found each instance</figcaption>{bin_chart(d["info"], d["top"], credit, d["budget"])}'
            f'<p class="legend"><span class="sw used"></span>in the credit <span class="sw usable"></span>usable <span class="sw unusable"></span>not usable'
            f'<span class="sw line"></span>credit (lower bound)</p></figure>{dimfig}'
            f'<figure><figcaption>Every instance the baseline finished</figcaption>{scatter_chart(d["pts"], d["info"], d["top"], d["budget"])}</figure>{table}</section>')


CSS = """
:root{--bg:#EFF1F3;--card:#FCFCFB;--ink:#12161A;--ink2:#464E55;--muted:#66707A;--line:#D8DDE1;--accent:#2A78D6;--accent-soft:#BBD5F3;
--ok:#1D6B3B;--ok-bg:#DCEFE2;--warn:#8A4B00;--warn-bg:#F9E8CC;--idle:#4F5961;--idle-bg:#E3E6E9;
--display:"Bricolage Grotesque","Avenir Next","Segoe UI",system-ui,sans-serif;--body:"Instrument Sans","Segoe UI",system-ui,sans-serif;
--mono:"JetBrains Mono",ui-monospace,SFMono-Regular,Menlo,monospace}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#101214;--card:#1A1A19;--ink:#ECEFF1;--ink2:#BAC2C8;--muted:#8E98A0;--line:#2C3237;
--accent:#3987E5;--accent-soft:#1E3F66;--ok:#79D09A;--ok-bg:#16301F;--warn:#F0B565;--warn-bg:#3A2A10;--idle:#B6BEC5;--idle-bg:#262B2F;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#101214;--card:#1A1A19;--ink:#ECEFF1;--ink2:#BAC2C8;--muted:#8E98A0;--line:#2C3237;
--accent:#3987E5;--accent-soft:#1E3F66;--ok:#79D09A;--ok-bg:#16301F;--warn:#F0B565;--warn-bg:#3A2A10;--idle:#B6BEC5;--idle-bg:#262B2F;color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 var(--body);padding-inline:max(16px,4vw);padding-block:28px 56px}
.wrap{max-width:980px;margin:0 auto;display:grid;gap:22px}
h1{font:600 clamp(26px,5vw,40px)/1.08 var(--display);margin:0 0 6px;letter-spacing:-.02em;text-wrap:balance}
h2{font:600 19px/1.2 var(--display);margin:0 0 12px;letter-spacing:-.01em}
h3{font:600 16px/1.3 var(--display);margin:0 0 8px}
p{margin:0 0 10px;max-width:68ch}
.lede{color:var(--ink2);font-size:16px;max-width:62ch}
.muted{color:var(--muted)} .small{font-size:12.5px} .strong{font-weight:600} .mono{font-family:var(--mono);font-variant-numeric:tabular-nums}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:20px;min-width:0}
.banner{display:flex;gap:12px;align-items:flex-start;background:var(--warn-bg);color:var(--warn);border-radius:10px;padding:14px 16px}
.banner p{margin:0;color:var(--ink)} .banner svg{flex:none;margin-top:3px}
.scroll{overflow-x:auto}
table.lb{border-collapse:collapse;width:100%;font-size:14px}
.lb th{font:600 11.5px/1.2 var(--body);letter-spacing:.06em;text-transform:uppercase;color:var(--muted);text-align:left;padding:8px 12px 8px 0;border-bottom:1px solid var(--line)}
.lb td{padding:10px 12px 10px 0;border-bottom:1px solid var(--line);vertical-align:top}
.lb .num{text-align:right;font-variant-numeric:tabular-nums} .lb tr.why td{padding-top:0;border-bottom:1px solid var(--line)}
.lb ul{margin:4px 0 0;padding-left:18px;color:var(--ink2);font-size:13px}
.pill{display:inline-flex;gap:6px;align-items:center;border-radius:999px;padding:3px 10px 3px 8px;font-size:12.5px;font-weight:600}
.pill.official{background:var(--ok-bg);color:var(--ok)} .pill.provisional{background:var(--warn-bg);color:var(--warn)} .pill.inconclusive{background:var(--idle-bg);color:var(--idle)}
.run{display:grid;gap:12px} .big{font-size:20px;font-family:var(--display);font-weight:600;margin:0} .big .muted{font:400 13px var(--body)}
dl.facts{display:grid;gap:6px;margin:0;font-size:13.5px} dl.facts div{display:grid;grid-template-columns:minmax(120px,190px) 1fr;gap:10px} dt{color:var(--muted)} dd{margin:0;min-width:0}
figure{margin:0;display:grid;gap:6px} figcaption{font-weight:600;font-size:13.5px}
svg.chart{width:100%;height:auto;display:block;overflow:visible}
.grid{stroke:var(--line);stroke-width:1} .zero{stroke:var(--muted);stroke-width:1.2}
.tick,.n,.axis{fill:var(--ink2);font:11.5px var(--body)} .n{fill:var(--muted);font:11px var(--mono)} .axis{fill:var(--muted)}
.bar.used{fill:var(--accent)} .bar.usable{fill:var(--accent-soft);stroke:var(--accent);stroke-width:1.2}
.bar.unusable{fill:none;stroke:var(--muted);stroke-width:1.2;stroke-dasharray:4 3}
.credit{stroke:var(--ink);stroke-width:1.4;stroke-dasharray:6 4} .creditlbl{fill:var(--ink);font:600 12px var(--body)}
.pt.used{fill:var(--accent);stroke:var(--card);stroke-width:1.5} .pt.other{fill:none;stroke:var(--muted);stroke-width:1.5}
.whisk{stroke:var(--accent);stroke-width:1.6}
.bar:focus-visible,.pt:focus-visible{outline:2px solid var(--ink);outline-offset:2px}
.legend{display:flex;flex-wrap:wrap;gap:6px 16px;align-items:center;font-size:12.5px;color:var(--ink2);margin:0}
.sw{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.sw.used{background:var(--accent)} .sw.usable{background:var(--accent-soft);border:1.2px solid var(--accent)} .sw.unusable{border:1.2px dashed var(--muted)}
.sw.line{width:18px;height:0;border-top:2px dashed var(--ink);border-radius:0;margin-left:10px}
details.tv summary{cursor:pointer;font-weight:600;font-size:13.5px;padding:6px 0} details.tv summary:focus-visible{outline:2px solid var(--ink);outline-offset:2px}
.limits ul{margin:0;padding-left:20px;display:grid;gap:7px;color:var(--ink2);max-width:74ch}
#tip{position:fixed;z-index:9;pointer-events:none;background:var(--ink);color:var(--card);font-size:12.5px;line-height:1.4;padding:7px 10px;border-radius:6px;max-width:300px;opacity:0;transition:opacity .08s}
@media (max-width:560px){dl.facts div{grid-template-columns:1fr;gap:0}.card{padding:16px}}
@media (prefers-reduced-motion:reduce){#tip{transition:none}}
"""

JS = """
(function(){var tip=document.getElementById('tip');function show(e){var t=e.target.getAttribute&&e.target.getAttribute('data-tip');
if(!t){tip.style.opacity=0;return}tip.textContent=t;tip.style.opacity=1;var x=(e.clientX||e.target.getBoundingClientRect().left)+14,y=(e.clientY||e.target.getBoundingClientRect().top)+14;
tip.style.left=Math.min(x,window.innerWidth-tip.offsetWidth-8)+'px';tip.style.top=Math.min(y,window.innerHeight-tip.offsetHeight-8)+'px'}
document.addEventListener('mousemove',show);document.addEventListener('focusin',show);document.addEventListener('focusout',function(){tip.style.opacity=0});
document.addEventListener('mouseleave',function(){tip.style.opacity=0})})();
"""

LIMITS = [
    "The Docker sandbox that makes it safe to run other people's code has passed its tests on real Linux machines, but not on a dedicated evaluation machine separate from the web service, and no result on this page was measured in it. Every run on this page used bare local processes and the project's reference solvers, so none of it can be an official result.",
    "Official credit needs three independent seeds, each with a published commitment, the sandbox, and the family's full instance count and CPU cap. No seed on this page meets all of those.",
    "The credit rule was designed while looking at an early design run's data (\"seed A\" in the registrations on the Pre-registrations page), so that run is not an independent test of it. The out-of-sample test is a pre-registered run on a fresh seed, with its pass criterion written down before the data existed.",
    "The certifiable range is limited. At the official ladder (24 instances per size, 120 s cap), a simulation with real per-instance noise certifies a constant speedup of 1.5 to 3 bits with roughly 65 to 100% probability (each figure is good to about 10 points), 1 bit rarely (6.5%) and 4 bits almost never (1%), because too few hard instances remain for the bound to stay stable. A round can ask for more instances per size (48: 68% at 4 bits; 96: 100% at 4 and 98% at 5 bits), but about 5 bits is the ceiling at a 120 s cap whatever the count, since a very fast submission falls under the 0.5 s cost floor wherever the baseline finishes. Results outside the range are reported as inconclusive, never credited, and speedups of tens of bits cannot be certified by this design at all.",
    "The lattice-attack code from the paper that made the original speedup claim cannot yet serve as a baseline: its sieve does not reach the target size past dimension 30.",
]


def prereg_verdict(primary_credit, hard_pool):
    """Apply the UNCONDITIONAL criteria written in a pre-registration file, mechanically.
    primary_credit: None if the primary claim was inconclusive, else the credit in bits.
    hard_pool: None if inconclusive, else (median, lower bound). Returns (primary verdict, exploratory verdict)."""
    if primary_credit is None:
        primary = ("(c) inconclusive", "FAILS for this configuration (insufficient power)")
    elif primary_credit >= 1.0:
        primary = ("(a) credit >= 1.0 bit", "SUPPORTS the claim that this ladder size can certify a speedup of about one bit (twice as fast) or more")
    else:
        primary = ("(b) conclusive but below 1.0 bit", "FAILS")
    if hard_pool is None:
        hp = "NOT promoted (inconclusive)"
    elif hard_pool[1] >= 1.0:
        hp = "first out-of-sample support for promoting it (lower bound >= 1.0 bit)"
    else:
        hp = "NOT promoted (lower bound below 1.0 bit)"
    return primary, hp


def prereg_card(path, data, tag, remeasure_note):
    run = next(((s, d) for s, d in data if s["tag"] == tag and "error" not in d), None)
    if run is None:
        return ""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    d = run[1]
    credit = None if d["meas"] is None else max(0.0, d["meas"][1])
    primary, hp = prereg_verdict(credit, d["hp"])
    # two decimals here: the criterion is a hard threshold at 1.0, so 0.96 must not be displayed as "1.0"
    shown = "inconclusive" if credit is None else f"{credit:.2f} bits"
    hp_shown = "inconclusive" if d["hp"] is None else f"lower bound {max(0.0, d['hp'][1]):.2f} bits"
    return (f'<section class="card"><h2>Pre-registered test, seed {esc(tag)}</h2>'
            f'<p>The pass criteria were written before any data from this seed existed and are applied here without interpretation.</p>'
            f'<dl class="facts"><div><dt>Primary claim</dt><dd>{esc(shown)}: outcome {esc(primary[0])}, which {esc(primary[1])}.</dd></div>'
            f'<div><dt>Exploratory hard-pool claim</dt><dd>{esc(hp_shown)}: {esc(hp)}.</dd></div>'
            f'<div><dt>Concurrency check</dt><dd>{esc(remeasure_note or "not recorded on this page; see the remeasure output")}</dd></div></dl>'
            f'<details class="tv"><summary>The registration, verbatim</summary><pre class="small mono" style="white-space:pre-wrap;overflow-x:auto">{esc(text)}</pre></details></section>')


def page(specs, board, sandbox_verified=False, prereg=None, remeasure_note=""):
    data = []
    for s in specs:
        try:
            data.append((s, load_pair(s["baseline"], s["submission"])))
        except (OSError, KeyError, ValueError) as e:  # a corrupt or incompatible pair is reported, not hidden
            data.append((s, {"error": str(e)}))
    runs = "".join(f'<div class="card">{run_section(s, d)}</div>' if "error" not in d else
                   f'<div class="card"><p>Could not read {esc(s["name"])} ({esc(s["tag"])}): {esc(d["error"])}</p></div>' for s, d in data)
    official = sum(1 for r in judge.leaderboard_rows(board) if r["status"] == "OFFICIAL")
    local = any("error" not in d and not d["meta_s"].get("sandbox") for _, d in data)
    reasons = []
    if not sandbox_verified:
        reasons.append("the sandbox has not passed its tests")
    if local:
        reasons.append("some runs were bare local processes")
    banner = f"{official} official result(s) below." if official else "No result on this page is official."
    banner_rest = (f"Why: {'; '.join(reasons)}. These are measurements of the method, not certified results. Limits are listed at the bottom."
                   if reasons and not official else "Limits are listed at the bottom.")
    limits = list(LIMITS)
    if sandbox_verified:
        limits[0] = ("The sandbox passed its tests on this machine, and the verification is tied to a fingerprint of the sandbox files, "
                     "so it lapses if they change. Runs labelled \"bare local process\" above still cannot count as official.")
    stamp = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())
    prereg_html = prereg_card(prereg[0], data, prereg[1], remeasure_note) if prereg else ""
    return f"""<title>Lattice Speedup Ledger</title>
<style>{CSS}</style>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600&family=Instrument+Sans:wght@400;600&family=JetBrains+Mono:wght@400;600&display=swap">
<main class="wrap">
<header><h1>Lattice Speedup Ledger</h1>
<p class="lede">How many bits faster than a reference solver does a lattice algorithm find short vectors, measured on instances nobody could prepare for. Generated {esc(stamp)} from saved ladders.</p></header>
<div class="banner" role="note">{ICON["PROVISIONAL"]}<p><strong>{esc(banner)}</strong> {esc(banner_rest)}</p></div>
<section class="card"><h2>Leaderboard</h2>{leaderboard(board)}</section>
{prereg_html}
<section><h2>Runs</h2><div style="display:grid;gap:16px">{runs or '<p class="muted">No ladder pairs found.</p>'}</div></section>
<section class="card limits"><h2>What this page does not show</h2><ul>{"".join(f"<li>{esc(x)}</li>" for x in limits)}</ul></section>
</main><div id="tip" role="tooltip"></div>
<script>{JS}</script>"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(HERE, "results", "report.html"))
    ap.add_argument("--pair", nargs=2, action="append", metavar=("BASELINE", "SUBMISSION"))
    ap.add_argument("--no-rescore", action="store_true", help="use the board file as it is (it may predate the current estimator)")
    ap.add_argument("--prereg", nargs=2, metavar=("FILE", "SEED_TAG"), help="add a card applying a pre-registration's criteria to that seed's run")
    ap.add_argument("--remeasure-note", default="", help="one line summarising the remeasure.py concurrency check, shown on the card")
    a = ap.parse_args()
    if not a.no_rescore:
        # SIDE EFFECT: this rewrites results/leaderboard_v2.json (and each ladder's .claim.json) so the leaderboard comes from the
        # same estimator as the charts; without it the page can contradict itself. Do not run it while a ladder is still being written.
        import subprocess
        import sys
        subprocess.run([sys.executable, os.path.join(HERE, "judge.py"), "rescore"], cwd=HERE, capture_output=True)
    if a.pair:
        specs = [{"family": "gm", "tag": "custom", "baseline": b, "submission": s, "name": os.path.basename(s)} for b, s in a.pair]
    else:
        specs = find_pairs(os.path.join(HERE, "results"))
    board = []
    if os.path.exists(judge.BOARD):
        with open(judge.BOARD, encoding="utf-8") as f:
            board = json.load(f)
    import portal_core  # standard-library-only home of the sandbox gate (portal imports this module, so importing portal here would be circular)
    verified = portal_core.sandbox_verified(os.path.join(HERE, "portal_data"))  # read-only: data_dir() would create the directory
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(page(specs, board, sandbox_verified=verified, prereg=tuple(a.prereg) if a.prereg else None,
                     remeasure_note=a.remeasure_note))
    print(f"wrote {a.out} ({len(specs)} run(s))")


if __name__ == "__main__":
    main()
