"""Hardware attestation for the tool service: what a verifier can check that a person's word cannot.

The remaining trust gap in a verifier-hosted round is that the HOST holds the secret seed, so it could leak instances or serve something other than the published code. A trusted execution environment
(TEE) closes that gap if its attestation shows (a) WHICH code is running (a measurement of the image) and (b) that the service's signing key and the round it serves were generated INSIDE it. This module is
the VERIFYING half, for one real platform, plus the binding that ties an attestation to a round:

  verify_nitro(document, ...)      an AWS Nitro Enclaves attestation document (COSE_Sign1 over CBOR): the certificate chain to the PINNED AWS root, every validity window at the document's own
                                   timestamp, the ES384 signature, and the enclave's PCR measurements against the ones YOU expect. Pure Python (agent_cbor / DER / ECDSA P-384 below), validated against
                                   real documents from the wild and against the `cryptography` package as an oracle (test_agent_tee).
  code_manifest / code_measurement the hashes of exactly the files that make up the service, and one digest of them
  binding / binding_digest         {service public key, plan hash, seed commitment, code measurement}: the digest goes into the enclave's `user_data`, so the attested enclave itself vouches for it
  verify_evidence(evidence, ...)   "attested" only when the platform check passes AND the document's user_data is the digest of THIS binding AND the binding matches what you expect;
                                   "claimed" for a binding with no hardware evidence (never reported as attested); otherwise "invalid"

WHAT IS PROVEN. That a genuine Nitro enclave, whose image measurement equals the one you computed from a build you trust, produced a document committing to this service key, this round and this code
manifest. WHAT IS NOT. (1) The GENERATING half (the enclave asking /dev/nsm for a document) is not built here and was never run: no enclave was available. (2) PCR0 proves the image, not that the image is
free of bugs or that you built it reproducibly: you must rebuild the enclave image from the manifest yourself and pin ITS PCR0. (3) Hardware vendors and AWS are trusted roots: a Nitro document proves
what AWS's hypervisor says. (4) Debug-mode enclaves report all-zero PCRs and are refused unless you allow them. (5) Side channels, and the host's control of what the enclave is FED (it serves tasks it is
handed), are out of scope. Only the platform "aws-nitro" is implemented; any other is refused, never guessed at.
"""
import base64
import calendar
import hashlib
import json
import os
import re
import time

import agent_core
from agent_core import canon

HERE = os.path.dirname(os.path.abspath(__file__))
EVIDENCE_FORMAT = "guldo-tee-evidence-v1"
BINDING_FORMAT = "guldo-tee-binding-v1"
MAX_DOC = 64 << 10
MANIFEST_NAME_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.\-]*(/[A-Za-z0-9_][A-Za-z0-9_.\-]*){0,3}$")      # no leading '/', no empty or '..' components
# the files whose hashes are the service's identity: serve it from exactly these
SERVICE_FILES = ("agent_service.py", "agent_blackbox.py", "agent_core.py", "agent_harness.py", "agent_sig.py", "agent_rounds.py", "rounds.py", "agent_eval.py", "agent_compare.py", "agent_strata.py",
                 "agent_providers.py")

# AWS Nitro Enclaves root certificate (G1). Source: https://aws-nitro-enclaves.amazonaws.com/AWS_NitroEnclaves_Root-G1.zip ; sha256 of the DER below was compared with that download on 27 Nov 2026.
NITRO_ROOT_PEM = """-----BEGIN CERTIFICATE-----
MIICETCCAZagAwIBAgIRAPkxdWgbkK/hHUbMtOTn+FYwCgYIKoZIzj0EAwMwSTEL
MAkGA1UEBhMCVVMxDzANBgNVBAoMBkFtYXpvbjEMMAoGA1UECwwDQVdTMRswGQYD
VQQDDBJhd3Mubml0cm8tZW5jbGF2ZXMwHhcNMTkxMDI4MTMyODA1WhcNNDkxMDI4
MTQyODA1WjBJMQswCQYDVQQGEwJVUzEPMA0GA1UECgwGQW1hem9uMQwwCgYDVQQL
DANBV1MxGzAZBgNVBAMMEmF3cy5uaXRyby1lbmNsYXZlczB2MBAGByqGSM49AgEG
BSuBBAAiA2IABPwCVOumCMHzaHDimtqQvkY4MpJzbolL//Zy2YlES1BR5TSksfbb
48C8WBoyt7F2Bw7eEtaaP+ohG2bnUs990d0JX28TcPQXCEPZ3BABIeTPYwEoCWZE
h8l5YoQwTcU/9KNCMEAwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUkCW1DdkF
R+eWw5b6cp3PmanfS5YwDgYDVR0PAQH/BAQDAgGGMAoGCCqGSM49BAMDA2kAMGYC
MQCjfy+Rocm9Xue4YnwWmNJVA44fA0P5W2OpYow9OYCVRaEevL8uO1XYru5xtMPW
rfMCMQCi85sWBbJwKKXdS6BptQFuZbT73o/gBh1qUxl/nNr12UO8Yfwr6wPLb+6N
IwLz3/Y=
-----END CERTIFICATE-----
"""


def _pem_der(pem):
    return base64.b64decode("".join(re.findall(r"^[A-Za-z0-9+/=]+$", pem, re.M)))


NITRO_ROOT_DER = _pem_der(NITRO_ROOT_PEM)
NITRO_ROOT_SHA256 = hashlib.sha256(NITRO_ROOT_DER).hexdigest()
assert NITRO_ROOT_SHA256 == "641a0321a3e244efe456463195d606317ed7cdcc3c1756e09893f3c68f79bb5b"


class TeeError(Exception):
    pass


# ---- CBOR (RFC 8949), decoding only what an attestation document uses, hardened ------------------------------------------------------------------------------

class _Cbor(object):
    MAX_DEPTH = 16
    MAX_ITEMS = 20000

    def __init__(self, data):
        self.b, self.i, self.items = data, 0, 0

    def _need(self, n):
        if self.i + n > len(self.b):
            raise TeeError("truncated CBOR")
        v = self.b[self.i:self.i + n]
        self.i += n
        return v

    def _arg(self, info):
        if info < 24:
            return info
        if info in (24, 25, 26, 27):
            return int.from_bytes(self._need(1 << (info - 24)), "big")
        raise TeeError("unsupported CBOR length (indefinite or reserved)")

    def item(self, depth=0):
        if depth > self.MAX_DEPTH:
            raise TeeError("CBOR nested too deeply")
        self.items += 1
        if self.items > self.MAX_ITEMS:
            raise TeeError("CBOR has too many items")
        ib = self._need(1)[0]
        major, info = ib >> 5, ib & 31
        if major == 7:
            if info == 20:
                return False
            if info == 21:
                return True
            if info == 22:
                return None
            raise TeeError("unsupported CBOR simple value")
        n = self._arg(info)
        if major == 0:
            return n
        if major == 1:
            return -1 - n
        if major in (2, 3):
            if n > len(self.b) - self.i:
                raise TeeError("truncated CBOR string")
            raw = self._need(n)
            if major == 2:
                return raw
            try:
                return raw.decode("utf-8")
            except UnicodeDecodeError:
                raise TeeError("a CBOR text string is not UTF-8")
        if major == 4:
            if n > self.MAX_ITEMS:
                raise TeeError("CBOR array too long")
            return [self.item(depth + 1) for _ in range(n)]
        if major == 5:
            if n > self.MAX_ITEMS:
                raise TeeError("CBOR map too long")
            out = {}
            for _ in range(n):
                k = self.item(depth + 1)
                if isinstance(k, (list, dict)):
                    raise TeeError("a CBOR map key must be a scalar")
                if k in out:
                    raise TeeError("a duplicate CBOR map key")
                out[k] = self.item(depth + 1)
            return out
        if major == 6:                                           # the ONLY tag accepted is COSE_Sign1's (18), around the whole document: a tag anywhere else is encoding malleability
            if depth != 0 or n != 18:
                raise TeeError("an unexpected CBOR tag")
            return self.item(depth + 1)
        raise TeeError("unsupported CBOR item")


def cbor_decode(data):
    if not isinstance(data, (bytes, bytearray)) or len(data) > MAX_DOC:
        raise TeeError("not a document of acceptable size")
    c = _Cbor(bytes(data))
    v = c.item()
    if c.i != len(c.b):
        raise TeeError("trailing bytes after the CBOR item")
    return v


def _cbor_head(major, n):
    if n < 24:
        return bytes([major << 5 | n])
    for info, size in ((24, 1), (25, 2), (26, 4), (27, 8)):
        if n < (1 << (8 * size)):
            return bytes([major << 5 | info]) + n.to_bytes(size, "big")
    raise TeeError("too long")


def cbor_encode(x, _depth=0):
    """Deterministic CBOR for the types a request needs: None, bool, int, bytes, text, list, dict (keys in the order given). Raises TeeError for anything else."""
    if _depth > 8:
        raise TeeError("too deeply nested to encode")
    if x is None:
        return b"\xf6"
    if isinstance(x, bool):
        return b"\xf5" if x else b"\xf4"
    if isinstance(x, int):
        return _cbor_head(0, x) if x >= 0 else _cbor_head(1, -1 - x)
    if isinstance(x, (bytes, bytearray)):
        return _cbor_head(2, len(x)) + bytes(x)
    if isinstance(x, str):
        b = x.encode("utf-8")
        return _cbor_head(3, len(b)) + b
    if isinstance(x, (list, tuple)):
        return _cbor_head(4, len(x)) + b"".join(cbor_encode(i, _depth + 1) for i in x)
    if isinstance(x, dict):
        return _cbor_head(5, len(x)) + b"".join(cbor_encode(k, _depth + 1) + cbor_encode(v, _depth + 1) for k, v in x.items())
    raise TeeError("cannot encode a %s as CBOR" % type(x).__name__)


def cbor_encode_sig_structure(protected, payload):
    """The COSE Sig_structure ["Signature1", protected, h'', payload] (RFC 9052 4.4), the only thing this module ever encodes."""
    return (b"\x84" + _cbor_head(3, 10) + b"Signature1" + _cbor_head(2, len(protected)) + protected + _cbor_head(2, 0) + _cbor_head(2, len(payload)) + payload)


# ---- ASN.1 DER / X.509: only what a Nitro certificate chain needs ---------------------------------------------------------------------------------------------------

def _tlv(b, i, end=None):
    end = len(b) if end is None else end
    if i + 2 > end:
        raise TeeError("truncated DER")
    tag, ln, j = b[i], b[i + 1], i + 2
    if ln & 0x80:
        k = ln & 0x7f
        if k == 0 or k > 3 or j + k > end:
            raise TeeError("unsupported DER length")
        ln = int.from_bytes(b[j:j + k], "big")
        j += k
    if j + ln > end:
        raise TeeError("DER length exceeds its container")
    return tag, j, j + ln


def _children(b, start, end):
    out, i = [], start
    while i < end:
        tag, s, e = _tlv(b, i, end)
        out.append((tag, s, e, i))
        i = e
    return out


def _oid(b, s, e):
    if e <= s:
        raise TeeError("empty OID")
    parts = [b[s] // 40, b[s] % 40]
    v = 0
    for x in b[s + 1:e]:
        v = v << 7 | (x & 0x7f)
        if not x & 0x80:
            parts.append(v)
            v = 0
    return ".".join(str(p) for p in parts)


def _time(tag, raw):
    t = raw.decode("ascii", "replace")
    try:
        if tag == 0x17 and re.fullmatch(r"\d{12}Z", t):
            yy = int(t[:2])
            return calendar.timegm((1900 + yy if yy >= 50 else 2000 + yy, int(t[2:4]), int(t[4:6]), int(t[6:8]), int(t[8:10]), int(t[10:12])))
        if tag == 0x18 and re.fullmatch(r"\d{14}Z", t):
            return calendar.timegm((int(t[:4]), int(t[4:6]), int(t[6:8]), int(t[8:10]), int(t[10:12]), int(t[12:14])))
    except (ValueError, OverflowError):
        pass
    raise TeeError("an unreadable certificate time")


OID_ECDSA_SHA384 = "1.2.840.10045.4.3.3"
OID_EC_PUBKEY = "1.2.840.10045.2.1"
OID_P384 = "1.3.132.0.34"
OID_BASIC_CONSTRAINTS = "2.5.29.19"
OID_KEY_USAGE = "2.5.29.15"


class Cert(object):
    """A parsed X.509 certificate (the fields a chain check needs)."""

    def __init__(self, der):
        self.der = bytes(der)
        b = self.der
        tag, s, e = _tlv(b, 0)
        if tag != 0x30 or e != len(b):
            raise TeeError("a certificate is one DER SEQUENCE")
        top = _children(b, s, e)
        if len(top) != 3 or top[0][0] != 0x30 or top[1][0] != 0x30 or top[2][0] != 0x03:
            raise TeeError("not an X.509 certificate")
        self.tbs = b[top[0][3]:top[0][2]]
        alg = _children(b, top[1][1], top[1][2])
        if not alg or alg[0][0] != 0x06 or _oid(b, alg[0][1], alg[0][2]) != OID_ECDSA_SHA384:
            raise TeeError("unsupported certificate signature algorithm (only ecdsa-with-SHA384)")
        sv = b[top[2][1]:top[2][2]]
        if not sv or sv[0] != 0:
            raise TeeError("a malformed signature bit string")
        self.sig = _ecdsa_der(sv[1:])
        kids = _children(b, top[0][1], top[0][2])
        k = 0
        if kids and kids[0][0] == 0xA0:                                   # explicit version
            k = 1
        if len(kids) < k + 6:
            raise TeeError("a truncated TBSCertificate")
        serial, sigalg, issuer, validity, subject, spki = kids[k:k + 6]
        self.issuer, self.subject = b[issuer[3]:issuer[2]], b[subject[3]:subject[2]]
        vt = _children(b, validity[1], validity[2])
        if len(vt) != 2:
            raise TeeError("a malformed validity")
        self.not_before, self.not_after = _time(vt[0][0], b[vt[0][1]:vt[0][2]]), _time(vt[1][0], b[vt[1][1]:vt[1][2]])
        sp = _children(b, spki[1], spki[2])
        if len(sp) != 2 or sp[0][0] != 0x30 or sp[1][0] != 0x03:
            raise TeeError("a malformed public key")
        al = _children(b, sp[0][1], sp[0][2])
        if len(al) != 2 or _oid(b, al[0][1], al[0][2]) != OID_EC_PUBKEY or _oid(b, al[1][1], al[1][2]) != OID_P384:
            raise TeeError("unsupported public key (only P-384 ECDSA)")
        pt = b[sp[1][1] + 1:sp[1][2]]
        if len(pt) != 97 or pt[0] != 4:
            raise TeeError("an unsupported EC point encoding (only uncompressed)")
        self.pub = (int.from_bytes(pt[1:49], "big"), int.from_bytes(pt[49:], "big"))
        if not _on_curve(self.pub):
            raise TeeError("the public key is not on the curve")
        self.is_ca, self.key_cert_sign = None, None
        for tg, s_, e_, _i in kids[k + 6:]:
            if tg == 0xA3:
                for ext in _children(b, *_tlv(b, s_, e_)[1:3]):
                    parts = _children(b, ext[1], ext[2])
                    oid = _oid(b, parts[0][1], parts[0][2])
                    val = parts[-1]
                    if val[0] != 0x04:
                        continue
                    inner = b[val[1]:val[2]]
                    if oid == OID_BASIC_CONSTRAINTS:
                        t2, s2, e2 = _tlv(inner, 0)
                        ch = _children(inner, s2, e2)
                        self.is_ca = bool(ch and ch[0][0] == 0x01 and inner[ch[0][1]] != 0)
                    elif oid == OID_KEY_USAGE:
                        t2, s2, e2 = _tlv(inner, 0)
                        self.key_cert_sign = bool(e2 - s2 >= 2 and inner[s2 + 1] & 0x04)


def _ecdsa_der(sig):
    tag, s, e = _tlv(sig, 0)
    if tag != 0x30 or e != len(sig):
        raise TeeError("a malformed ECDSA signature")
    ch = _children(sig, s, e)
    if len(ch) != 2 or ch[0][0] != 0x02 or ch[1][0] != 0x02:
        raise TeeError("a malformed ECDSA signature")
    return int.from_bytes(sig[ch[0][1]:ch[0][2]], "big"), int.from_bytes(sig[ch[1][1]:ch[1][2]], "big")


# ---- ECDSA over P-384 (FIPS 186-4), verification only ---------------------------------------------------------------------------------------------------------------

P384_P = 2 ** 384 - 2 ** 128 - 2 ** 96 + 2 ** 32 - 1
P384_N = 0xffffffffffffffffffffffffffffffffffffffffffffffffc7634d81f4372ddf581a0db248b0a77aecec196accc52973
P384_B = 0xb3312fa7e23ee7e4988e056be3f82d19181d9c6efe8141120314088f5013875ac656398d8a2ed19d2a85c8edd3ec2aef
P384_G = (0xaa87ca22be8b05378eb1c71ef320ad746e1d3b628ba79b9859f741e082542a385502f25dbf55296c3a545e3872760ab7,
          0x3617de4a96262c6f5d9e98bf9292dc29f8f41dbd289a147ce9da3113b5f0b8c00a60b1ce1d7e819d7a431d7c90ea0e5f)


def _on_curve(pt):
    x, y = pt
    return 0 <= x < P384_P and 0 <= y < P384_P and (y * y - (x * x * x - 3 * x + P384_B)) % P384_P == 0


def _add(p, q):
    if p is None:
        return q
    if q is None:
        return p
    if p[0] == q[0]:
        if (p[1] + q[1]) % P384_P == 0:
            return None
        lam = (3 * p[0] * p[0] - 3) * pow(2 * p[1], -1, P384_P) % P384_P
    else:
        lam = (q[1] - p[1]) * pow(q[0] - p[0], -1, P384_P) % P384_P
    x = (lam * lam - p[0] - q[0]) % P384_P
    return (x, (lam * (p[0] - x) - p[1]) % P384_P)


def _mul(pt, k):
    r = None
    while k:
        if k & 1:
            r = _add(r, pt)
        pt = _add(pt, pt)
        k >>= 1
    return r


def ecdsa_p384_verify(pub, message, sig):
    """True iff `sig` = (r, s) is a valid ECDSA/SHA-384 signature of `message` under the P-384 point `pub`. Never raises."""
    try:
        r, s = sig
        if not (isinstance(pub, tuple) and _on_curve(pub) and 1 <= r < P384_N and 1 <= s < P384_N):
            return False
        e = int.from_bytes(hashlib.sha384(message).digest(), "big")
        w = pow(s, -1, P384_N)
        pt = _add(_mul(P384_G, e * w % P384_N), _mul(pub, r * w % P384_N))
        return pt is not None and pt[0] % P384_N == r
    except (TypeError, ValueError, ZeroDivisionError):
        return False


# ---- an AWS Nitro Enclaves attestation document ---------------------------------------------------------------------------------------------------------------------

def verify_nitro(document, expect_pcrs=None, user_data=None, nonce=None, roots=(NITRO_ROOT_SHA256,), now=None, max_age_s=None, allow_debug=False):
    """(problems, info). Empty problems = a genuine Nitro document: ES384 signature by the leaf, a certificate chain from the leaf to a root whose SHA-256 is in `roots` (valid at the document's own
    timestamp, every issuer a CA), `expect_pcrs` ({index: hex}) equal to the enclave's measurements, and (if given) `user_data` and `nonce` equal. Never raises on a damaged document.

    NOT checked, deliberately out of scope: path-length and name constraints, extended key usage, and revocation (Nitro's certificates are short-lived: the document's own timestamp bounds them, and
    "the chain was valid at that time" is all that is claimed). A document is also only as fresh as `max_age_s` and a `nonce` of yours make it."""
    probs, info = [], {}
    try:
        doc = cbor_decode(document)
        if not (isinstance(doc, list) and len(doc) == 4 and isinstance(doc[0], bytes) and isinstance(doc[1], dict) and isinstance(doc[2], bytes) and isinstance(doc[3], bytes)):
            return ["not a COSE_Sign1 document"], info
        protected, payload, signature = doc[0], doc[2], doc[3]
        hdr = cbor_decode(protected)
        if not isinstance(hdr, dict) or hdr.get(1) != -35:
            return ["the document is not signed with ES384"], info
        p = cbor_decode(payload)
        if not isinstance(p, dict):
            return ["the payload is not a map"], info
        for key, typ in (("module_id", str), ("digest", str), ("timestamp", int), ("pcrs", dict), ("certificate", bytes), ("cabundle", list)):
            if not isinstance(p.get(key), typ) or isinstance(p.get(key), bool):
                return ["the payload lacks a well-formed %s" % key], info
        if p["digest"] != "SHA384":
            return ["an unsupported document digest %r" % p["digest"]], info
        at = p["timestamp"] // 1000
        pcrs = {}
        for i, v in p["pcrs"].items():
            if not (isinstance(i, int) and 0 <= i < 32 and isinstance(v, bytes) and len(v) in (32, 48, 64)):
                return ["a malformed PCR"], info
            pcrs[i] = v.hex()
        info = {"module_id": p["module_id"], "timestamp": at, "pcrs": pcrs, "user_data": p["user_data"].hex() if isinstance(p.get("user_data"), bytes) else None,
                "nonce": p["nonce"].hex() if isinstance(p.get("nonce"), bytes) else None, "public_key": p["public_key"].hex() if isinstance(p.get("public_key"), bytes) else None,
                "debug": 0 not in pcrs or set(pcrs[0]) == {"0"}}               # a debug-mode enclave reports all-zero PCR0-2: the image measurement is then meaningless
        # 1. the certificate chain, validated at the DOCUMENT's time (a leaf lives for hours: judging it now would reject every old document)
        leaf = Cert(p["certificate"])
        bundle = [Cert(c) for c in p["cabundle"] if isinstance(c, bytes)]
        if len(bundle) != len(p["cabundle"]) or len(bundle) > 10:
            return ["a malformed certificate bundle"], info
        chain, cur, used = [leaf], leaf, set()
        anchored = False
        for _ in range(10):
            if hashlib.sha256(cur.der).hexdigest() in set(roots):
                anchored = True
                break
            nxt = next((c for c in bundle if c.subject == cur.issuer and id(c) not in used), None)
            if nxt is None:
                probs.append("the certificate chain does not reach a root you pinned")
                break
            used.add(id(nxt))
            if not ecdsa_p384_verify(nxt.pub, cur.tbs, cur.sig):
                probs.append("a certificate's signature is not valid under its issuer's key")
                break
            if nxt.is_ca is not True or nxt.key_cert_sign is False:
                probs.append("an issuer in the chain is not a CA")
                break
            chain.append(nxt)
            cur = nxt
        else:
            probs.append("the certificate chain is too long")
        for c in chain:
            if not c.not_before <= at <= c.not_after:
                probs.append("a certificate in the chain was not valid at the document's timestamp")
                break
        info["chain_length"] = len(chain)
        # 2. the document's own signature (COSE Sig_structure) under the leaf
        if len(signature) != 96 or not ecdsa_p384_verify(leaf.pub, cbor_encode_sig_structure(protected, payload), (int.from_bytes(signature[:48], "big"), int.from_bytes(signature[48:], "big"))):
            probs.append("the document's signature is not valid under the leaf certificate")
        # 3. what the document says
        if info["debug"] and not allow_debug:
            probs.append("a DEBUG-MODE enclave (all-zero PCR0): its measurements prove nothing")
        for i, want in (expect_pcrs or {}).items():
            if pcrs.get(int(i)) != str(want).lower():
                probs.append("PCR%d is not the value you expect (the enclave is not running the image you built)" % int(i))
        if user_data is not None and info["user_data"] != user_data.hex():
            probs.append("the document's user_data is not the digest you expect")
        if nonce is not None and info["nonce"] != nonce.hex():
            probs.append("the document's nonce is not the one you supplied (a replayed document)")
        if max_age_s is not None and not (0 <= (time.time() if now is None else now) - at <= max_age_s):
            probs.append("the document is not fresh enough")
    except (TeeError, KeyError, TypeError, ValueError, IndexError, AttributeError, OverflowError, RecursionError) as e:
        probs.append("malformed document (%s: %s)" % (type(e).__name__, str(e)[:80]))
    return probs, info


# ---- what the attestation is bound TO ---------------------------------------------------------------------------------------------------------------------------------

def code_manifest(files=SERVICE_FILES, root=HERE):
    """{file: sha256} of the files that make up the service."""
    out = {}
    for rel in files:
        # file names can come from EVIDENCE (a hostile manifest): only plain relative names inside `root`, so a verifier is never made to hash an arbitrary file on its own machine
        if not isinstance(rel, str) or not MANIFEST_NAME_RE.match(rel) or ".." in rel.split("/"):
            raise TeeError("an unacceptable file name in a code manifest: %r" % (str(rel)[:40],))
        p = os.path.join(root, rel)
        if not os.path.exists(p):
            raise TeeError("%s is missing" % rel)
        out[rel] = agent_core.file_sha256(p)
    return out


def code_measurement(manifest):
    return hashlib.sha256(canon(manifest).encode("utf-8")).hexdigest()


def binding(service_pubkey, plan_hash, commitment, measurement):
    """What the enclave commits to in its attestation: this service key, serving this round (plan and seed commitment), running code with this measurement."""
    for name, v in (("service_pubkey", service_pubkey), ("plan_hash", plan_hash), ("commitment", commitment), ("code_measurement", measurement)):
        if not (isinstance(v, str) and re.fullmatch(r"[0-9a-f]{64}", v)):
            raise TeeError("%s must be 64 hex characters" % name)
    return {"format": BINDING_FORMAT, "service_pubkey": service_pubkey, "plan_hash": plan_hash, "commitment": commitment, "code_measurement": measurement}


def binding_digest(b):
    return hashlib.sha256(canon(b).encode("utf-8")).digest()


def make_evidence(platform, bind, document=None, manifest=None):
    """Package attestation evidence. `document` is the platform's raw attestation document (None for a bare claim)."""
    ev = {"format": EVIDENCE_FORMAT, "platform": platform, "binding": bind}
    if document is not None:
        ev["document_b64"] = base64.b64encode(document).decode("ascii")
    if manifest is not None:
        ev["manifest"] = manifest
    return ev


def verify_evidence(ev, expect_binding=None, expect_pcrs=None, roots=(NITRO_ROOT_SHA256,), source_root=None, allow_debug=False, nonce=None, now=None, max_age_s=None):
    """(status, problems, info). status is "attested", "claimed" or "invalid".

    attested: a genuine platform document whose user_data is the digest of ev['binding'], measurements equal to `expect_pcrs` (REQUIRED: without an expectation nothing can be attested), a binding equal to
              `expect_binding` (any fields you pass: service_pubkey, plan_hash, commitment), and, with `source_root` (your checkout of the code), a code manifest that hashes to the binding's measurement.
    claimed:  a binding with no hardware document: it says what the host CLAIMS to run. It is never reported as attested."""
    probs, info = [], {}
    try:
        if not isinstance(ev, dict) or ev.get("format") != EVIDENCE_FORMAT:
            return "invalid", ["not TEE evidence"], info
        b = ev["binding"]
        if not (isinstance(b, dict) and b.get("format") == BINDING_FORMAT):
            return "invalid", ["the binding is malformed"], info
        binding(b["service_pubkey"], b["plan_hash"], b["commitment"], b["code_measurement"])
        for k, v in (expect_binding or {}).items():
            if b.get(k) != v:
                probs.append("the binding's %s is not the one you expect" % k)
        if ev.get("manifest") is not None and code_measurement(ev["manifest"]) != b["code_measurement"]:
            probs.append("the code manifest does not hash to the binding's measurement")
        if source_root is not None:
            try:
                mine = code_manifest(tuple(ev["manifest"]) if ev.get("manifest") else SERVICE_FILES, source_root)
            except TeeError as e:
                mine = None
                probs.append(str(e))
            if mine is not None and code_measurement(mine) != b["code_measurement"]:
                probs.append("the code you have is NOT the code the binding names (a different build of the service)")
        platform = ev.get("platform")
        if "document_b64" not in ev:
            info = {"platform": platform, "claimed_only": True}
            return ("invalid" if probs else "claimed"), probs, info
        if platform != "aws-nitro":
            return "invalid", probs + ["unsupported platform %r (only aws-nitro)" % platform], info
        if not expect_pcrs:
            probs.append("you gave no expected PCR values: a document that is not compared with the image you built attests nothing")
        try:
            doc = base64.b64decode(ev["document_b64"], validate=True)
        except (ValueError, TypeError):
            return "invalid", probs + ["the document is not base64"], info
        p2, info = verify_nitro(doc, expect_pcrs, binding_digest(b), nonce, roots, now, max_age_s, allow_debug)
        probs += p2
        info["platform"] = platform
    except (KeyError, TypeError, ValueError, AttributeError, TeeError) as e:
        return "invalid", probs + ["malformed evidence (%s)" % type(e).__name__], info
    return ("invalid" if probs else "attested"), probs, info


def main(argv=None):
    import argparse
    import sys
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("manifest", help="print the code manifest and measurement of the service files in a directory")
    p.add_argument("--root", default=HERE)
    p = sub.add_parser("binding", help="the binding (and the digest the enclave must put in user_data) for a service key, a plan hash and a seed commitment")
    p.add_argument("--service-pubkey", required=True)
    p.add_argument("--plan-hash", required=True)
    p.add_argument("--commitment", required=True)
    p.add_argument("--root", default=HERE)
    p.add_argument("--out", help="write the binding JSON here")
    p = sub.add_parser("package", help="wrap an attestation document the enclave produced into evidence JSON")
    p.add_argument("--binding", required=True)
    p.add_argument("--document", help="the raw attestation document (omit for a bare claim)")
    p.add_argument("--root", default=HERE)
    p.add_argument("--out", required=True)
    p = sub.add_parser("verify", help="verify evidence; exit 0 only for 'attested'")
    p.add_argument("evidence")
    p.add_argument("--pcr", action="append", default=[], help="INDEX=HEX, an expected PCR value from YOUR build of the enclave image (repeatable)")
    p.add_argument("--source", help="your checkout of the service code, to recompute the code measurement")
    p.add_argument("--allow-debug", action="store_true")
    p.add_argument("--plan-hash")
    p.add_argument("--commitment")
    p.add_argument("--service-pubkey")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "manifest":
            m = code_manifest(root=a.root)
            print(json.dumps(m, indent=1, sort_keys=True))
            print("measurement", code_measurement(m))
            return 0
        if a.cmd == "binding":
            b = binding(a.service_pubkey, a.plan_hash, a.commitment, code_measurement(code_manifest(root=a.root)))
            if a.out:
                with open(a.out, "w", encoding="utf-8") as f:
                    json.dump(b, f, indent=1, sort_keys=True)
            print(json.dumps(b, indent=1, sort_keys=True))
            print("user_data (put THESE 32 bytes in the enclave's attestation request):", binding_digest(b).hex())
            return 0
        if a.cmd == "package":
            with open(a.binding, "r", encoding="utf-8") as f:
                b = json.load(f)
            doc = None
            if a.document:
                with open(a.document, "rb") as f:
                    doc = f.read()
            with open(a.out, "w", encoding="utf-8") as f:
                json.dump(make_evidence("aws-nitro", b, doc, code_manifest(root=a.root)), f, indent=1, sort_keys=True)
            print("wrote %s" % a.out)
            return 0
        with open(a.evidence, "r", encoding="utf-8") as f:
            ev = json.load(f)
        pcrs = {}
        for item in a.pcr:
            i, _, v = item.partition("=")
            pcrs[int(i)] = v.lower()
        want = {k: v for k, v in (("plan_hash", a.plan_hash), ("commitment", a.commitment), ("service_pubkey", a.service_pubkey)) if v}
        st, probs, info = verify_evidence(ev, want, pcrs or None, source_root=a.source, allow_debug=a.allow_debug)
        for pr in probs:
            print("FAIL  " + pr)
        print("%s%s" % (st.upper(), ": a genuine enclave running the image you built vouches for this binding" if st == "attested" else
                        (": a claim with NO hardware evidence" if st == "claimed" else "")))
        return 0 if st == "attested" else 1
    except (TeeError, OSError, ValueError, KeyError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    import sys as _sys
    _sys.exit(main())
