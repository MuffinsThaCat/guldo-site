"""Judge workflow: new-seed -> (publish commitment) -> evaluate submissions -> reveal -> leaderboard.

  judge.py new-seed   --out judging.seed            writes a 256-bit seed (mode 0600), prints the commitment to publish
  judge.py check      --seed judging.seed --commit HEX     anyone can run this after the reveal
  judge.py evaluate   --seed judging.seed --submission solvers/x.py --baseline solvers/baseline_bkz.py
  judge.py leaderboard
"""
import argparse
import hashlib
import json
import os
import secrets
import subprocess
import sys

import families
import harness

HERE = os.path.dirname(os.path.abspath(__file__))
BOARD = os.environ.get("SVP_BOARD", os.path.join(HERE, "results", "leaderboard_v2.json"))
MIN_SEEDS = 3  # a leaderboard credit needs at least this many independent committed seeds
SCHEMA = 2


def default_baseline(family):
    """The reference solver instances of this family are compared against (families.DEFAULT_BASELINE)."""
    return os.path.join(HERE, families.DEFAULT_BASELINE[family])


def sh(*args):
    r = subprocess.run([sys.executable, *args], cwd=HERE, capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(r.stdout + r.stderr)
    return r.stdout


def ladder_meta(path):
    with open(path) as f:
        return json.loads(f.readline())


def ladder_n(path):
    """Smallest number of instances recorded at any dimension of a ladder file."""
    counts = {}
    with open(path) as f:
        f.readline()
        for line in f:
            r = json.loads(line)
            counts[r["dim"]] = counts.get(r["dim"], 0) + 1
    return min(counts.values()) if counts else 0


def baseline_reusable(path, expect):
    """(ok, reason). True only if the baseline ladder at `path` is PROVABLY the measurement this evaluation would make: the same seed
    commitment, baseline file hash, family, budget, instance version, sandbox, image, CPU and job count, and every instance of the
    ladder present. Anything else, including a file that cannot be read, means "measure it again"."""
    try:
        with open(path) as f:
            meta = json.loads(f.readline())
            recs = [json.loads(line) for line in f if line.strip()]
    except (OSError, ValueError):
        return False, "no readable baseline ladder"
    if not isinstance(meta, dict) or not meta.get("meta"):
        return False, "no readable baseline ladder"
    for key, label in (("commit", "seed commitment"), ("solver_sha256", "baseline file"), ("family", "family"), ("budget", "budget"),
                       ("instance_version", "instance version"), ("sandbox", "sandbox"), ("image", "image"), ("cpu", "cpu"), ("jobs", "jobs")):
        if meta.get(key) != expect[key]:
            return False, f"the {label} differs ({meta.get(key)!r} vs {expect[key]!r})"
    want = {f"{d}:{i}" for d in expect["dims"] for i in range(expect["n"])}
    have = {r.get("id") for r in recs}
    if have != want:
        return False, f"incomplete: {len(want - have)} instance(s) missing, {len(have - want)} unexpected"
    return True, ""


def make_entry(name, family, tag, sub_file, claim, target_dim, commit_checked, base_file=None):
    m = ladder_meta(sub_file)
    mb = ladder_meta(base_file) if base_file else {}
    return {"schema": SCHEMA, "submission": name, "family": family, "seed_tag": tag, "commit": m["commit"],
            "commit_checked": bool(commit_checked), "n": ladder_n(sub_file), "budget": m["budget"],
            "sandbox": m.get("sandbox"), "instance_version": m.get("instance_version"), "image": m.get("image"),
            "cpu": m.get("cpu"), "solver_sha256": m.get("solver_sha256"), "baseline": mb.get("solver"),
            "baseline_sha256": mb.get("solver_sha256"),
            "target_dim": int(target_dim),
            "bits": None if claim["measured"] is None else round(claim["measured"], 1),
            "measured_bins": claim.get("measured_bins"), "measured_dims": claim.get("measured_dims"),
            "dim_pooled": claim.get("measured_by_dim"),
            "extrapolated": None if claim["point"] is None or claim["p5"] is None
            else round(max(0.0, min(claim["point"], claim["p5"])), 1),
            "per_dim": {str(d): round(v, 2) for d, v in claim["s"].items()}}


def official_reasons(e):
    """Why a board entry does NOT count toward an official credit (empty list = it counts)."""
    if e.get("schema") != SCHEMA:
        return ["legacy entry (no run metadata); rescore it"]
    why = []
    need = families.OFFICIAL[e["family"]]
    if e["sandbox"] != "docker":
        why.append("not run in the sandbox")
    if e["n"] < need["n"]:
        why.append(f"n={e['n']} < {need['n']} instances/dim")
    if e["budget"] < need["budget"]:
        why.append(f"budget {e['budget']} < {need['budget']}s")
    if not e["commit_checked"]:
        why.append("seed commitment not checked against a published value")
    if not e.get("instance_version"):
        why.append("no instance version")
    if not e.get("cpu"):
        why.append("no CPU model recorded")
    if not e.get("solver_sha256"):
        why.append("solver file hash not recorded")
    if not e.get("baseline_sha256"):
        why.append("baseline file hash not recorded")
    return why


def leaderboard_rows(board):
    groups = {}
    for e in board:
        groups.setdefault((e["submission"], e["family"]), []).append(e)
    rows = []
    for (name, fam), es in groups.items():
        official = {}
        for e in es:
            if not official_reasons(e):
                official[e["seed_tag"]] = e
        # official seeds must be one machine type, one submission file and one baseline file: a minimum over seeds scored
        # with different code (an edited solver, a different reference) is not a credit for anything
        combine = []
        if len({e["cpu"] for e in official.values()}) > 1:
            combine.append("official seeds ran on different CPUs")
        if len({e["solver_sha256"] for e in official.values()}) > 1:
            combine.append("official seeds used different versions of the submission file")
        if len({e["baseline_sha256"] for e in official.values()}) > 1:
            combine.append("official seeds used different baseline files")
        if combine:
            official = {}
        counted = list(official.values())
        pool = counted if len(counted) >= MIN_SEEDS else es
        vals = [e["bits"] for e in pool]
        credit = 0.0 if any(v is None for v in vals) else min(vals)
        status = "OFFICIAL" if len(counted) >= MIN_SEEDS else f"PROVISIONAL ({len(counted)}/{MIN_SEEDS} official seeds)"
        reasons = (sorted({r for e in es for r in official_reasons(e)}) + combine) if len(counted) < MIN_SEEDS else []
        rows.append({"credit": credit, "name": name, "family": fam, "status": status, "reasons": reasons,
                     "per_seed": ["inconclusive" if v is None else v for v in vals]})
    rows.sort(key=lambda r: -r["credit"])
    return rows


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("new-seed")
    p.add_argument("--out", required=True)
    p.add_argument("--allow-in-tree", action="store_true", help="test seeds only; never for a real competition")
    p = sub.add_parser("check")
    p.add_argument("--seed", required=True)
    p.add_argument("--commit", required=True)
    p = sub.add_parser("evaluate")
    p.add_argument("--seed", required=True)
    p.add_argument("--submission", required=True)
    p.add_argument("--baseline", help="reference solver (default: the family's own, families.DEFAULT_BASELINE)")
    p.add_argument("--n", help="instances per dimension (default: the family's official value)")
    p.add_argument("--budget", help="CPU-second cap per instance (default: the family's official value)")
    p.add_argument("--dims", type=int, nargs="+", help="override the family's default ladder (e.g. for a non-default baseline)")
    p.add_argument("--target-dim", default="512")
    p.add_argument("--jobs", default="1", help="concurrent instances per ladder (local mode only; see drift_check.py)")
    p.add_argument("--family", default="gm", choices=sorted(families.FAMILIES))
    p.add_argument("--sandbox", choices=["docker"])
    p.add_argument("--insecure-local", action="store_true",
                   help="run solvers as bare local processes (only for solvers you wrote; they can read the seed and cheat)")
    p.add_argument("--published-commit", help="the sha256 you published BEFORE the deadline; the run is refused if the "
                   "seed does not hash to it, and without it the run can never be official")
    p.add_argument("--reuse-baseline", action="store_true",
                   help="reuse this seed's baseline ladder if it is provably the same measurement (same seed, baseline file, budget, sandbox, "
                        "image, CPU, jobs, all instances present); otherwise measure it again. A multi-submission round measures it once.")
    sub.add_parser("leaderboard")
    sub.add_parser("rescore", help="rebuild board entries from saved ladder files (after a rule change)")
    a = ap.parse_args()

    if a.cmd == "new-seed":
        if os.path.abspath(a.out).startswith(HERE + os.sep) and not a.allow_in_tree:
            raise SystemExit("REFUSED: a seed inside the project tree is readable by bare-local-mode solvers and other "
                             "tooling. Write it elsewhere (e.g. ~/judge-seeds/), or pass --allow-in-tree for a throwaway test seed.")
        try:
            fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:  # a seed is never overwritten: that would silently change a commitment that may already be published
            raise SystemExit(f"REFUSED: {a.out} already exists. A seed is never overwritten (its commitment may already be published); "
                             "choose another path or remove it yourself.")
        seed = secrets.token_hex(32).encode()
        os.write(fd, seed)
        os.close(fd)
        print("PUBLISH THIS COMMITMENT NOW, keep the seed file secret until the deadline:")
        print(hashlib.sha256(seed).hexdigest())
    elif a.cmd == "check":
        got = hashlib.sha256(open(a.seed, "rb").read().strip()).hexdigest()
        print("OK: seed matches commitment" if got == a.commit else f"MISMATCH: seed hashes to {got}")
        sys.exit(got != a.commit)
    elif a.cmd == "evaluate":
        if not a.sandbox and not a.insecure_local:
            raise SystemExit("REFUSED: pass --sandbox docker (untrusted submissions), or --insecure-local for your own "
                             "solvers. Local mode lets a solver read the seed/judge code and orphan processes to hide CPU.")
        name = os.path.splitext(os.path.basename(a.submission))[0]
        full = hashlib.sha256(open(a.seed, "rb").read().strip()).hexdigest()
        if a.published_commit and a.published_commit != full:
            raise SystemExit(f"REFUSED: seed hashes to {full}, not the published commitment {a.published_commit}")
        tag = full[:8]
        out = {}
        dims = [str(d) for d in (a.dims or families.DEFAULT_DIMS[a.family])]
        n = a.n or str(families.OFFICIAL[a.family]["n"])
        budget = a.budget or str(families.OFFICIAL[a.family]["budget"])
        for role, path in (("baseline", a.baseline or default_baseline(a.family)), ("submission", a.submission)):
            out[role] = os.path.join(HERE, "results", f"judged_{a.family}_{tag}_{role}_{os.path.basename(path)}.jsonl")
            if role == "baseline" and a.reuse_baseline and os.path.exists(out[role]):
                with open(path, "rb") as f:
                    base_sha = hashlib.sha256(f.read()).hexdigest()
                ok, why = baseline_reusable(out[role], {
                    "commit": full, "solver_sha256": base_sha, "family": a.family, "budget": float(budget),
                    "instance_version": families.VERSIONS[a.family], "sandbox": a.sandbox,
                    "image": harness.image_id() if a.sandbox else None, "cpu": harness.cpu_brand(), "jobs": int(a.jobs),
                    "n": int(n), "dims": [int(d) for d in dims]})
                print(f"baseline ladder: {'REUSED (identical measurement, already complete)' if ok else 'not reusable (' + why + '); measuring it again'}",
                      flush=True)
                if ok:
                    continue
            sh("harness.py", "--solver", path, "--family", a.family, "--dims", *dims, "--n", n, "--budget", budget,
               "--seed-file", a.seed, "--out", out[role], "--jobs", a.jobs,
               *(["--sandbox", a.sandbox] if a.sandbox else []))
        report = sh("extrapolate.py", "--baseline", out["baseline"], "--submission", out["submission"],
                    "--target-dim", a.target_dim)
        print(report)
        claim = json.load(open(out["submission"] + ".claim.json"))
        board = json.load(open(BOARD)) if os.path.exists(BOARD) else []
        board = [r for r in board if not (r["submission"] == name and r["family"] == a.family and r["seed_tag"] == tag)]
        board.append(make_entry(name, a.family, tag, out["submission"], claim, a.target_dim, bool(a.published_commit),
                                base_file=out["baseline"]))
        with open(BOARD, "w") as f:
            json.dump(board, f, indent=1)
    elif a.cmd == "rescore":
        import re
        pat = re.compile(r"^judged_([a-z]+)_([0-9a-f]{8})_(baseline|submission)_(.+)\.py\.jsonl$")  # any registered family
        files = {}
        for fn in sorted(os.listdir(os.path.join(HERE, "results"))):
            m = pat.match(fn)
            if m:
                files.setdefault((m.group(1), m.group(2)), {}).setdefault(m.group(3), []).append((m.group(4), fn))
        board = json.load(open(BOARD)) if os.path.exists(BOARD) else []
        old = {(e["submission"], e["family"], e["seed_tag"]): e for e in board}
        for (fam, tag), roles in sorted(files.items()):
            if "baseline" not in roles:
                continue
            base_fn = os.path.join(HERE, "results", roles["baseline"][0][1])
            for name, fn in roles.get("submission", []):
                sub_fn = os.path.join(HERE, "results", fn)
                r = subprocess.run([sys.executable, "extrapolate.py", "--baseline", base_fn, "--submission", sub_fn],
                                   cwd=HERE, capture_output=True, text=True)
                if r.returncode:
                    print(f"skip {fn}: {r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr.strip()[-200:]}")
                    continue
                claim = json.load(open(sub_fn + ".claim.json"))
                keep = old.get((name, fam, tag), {}).get("commit_checked", False)
                old[(name, fam, tag)] = make_entry(name, fam, tag, sub_fn, claim, 512, keep, base_file=base_fn)
                print(f"rescored {name} {fam} seed {tag}: measured credit {old[(name, fam, tag)]['bits']}")
        with open(BOARD, "w") as f:
            json.dump(list(old.values()), f, indent=1)
    elif a.cmd == "leaderboard":
        board = json.load(open(BOARD)) if os.path.exists(BOARD) else []
        print(f"credit = MIN over >= {MIN_SEEDS} OFFICIAL seeds (docker sandbox, per-family n and budget {families.OFFICIAL}, "
              f"commitment checked); an inconclusive seed counts as 0. Otherwise PROVISIONAL.")
        for i, r in enumerate(leaderboard_rows(board), 1):
            print(f"{i:2d}. {r['name']:22s} {r['family']:5s} {r['credit']:5.1f} bits  {r['status']:36s} per-seed {r['per_seed']}")
            for why in r["reasons"]:
                print(f"      not official: {why}")


if __name__ == "__main__":
    main()
