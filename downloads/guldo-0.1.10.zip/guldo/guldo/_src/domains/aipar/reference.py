"""Reference for aipar: the sequential loop over t, one multiply-add per step (float64)."""
import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, T, C):
    a = _uniform(seed, 0, T * C).reshape(T, C) * 0.049 + 0.95
    b = _uniform(seed, T * C, T * C).reshape(T, C)
    h, out = np.zeros(C), np.empty((T, C))
    for t in range(T):
        h = a[t] * h + b[t]
        out[t] = h
    return [int(v) for v in np.rint(out.ravel() * 2 ** 30)]
