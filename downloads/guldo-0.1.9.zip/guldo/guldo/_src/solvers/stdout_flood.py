"""Red-team: floods the answer channel (stdout) without end, trying to exhaust the meter's memory or bury the real answer. The CPU limit and the
memory limit must stop it: a timeout or crash in bounded time, never a solve."""
import sys


def solve(basis, bound2):
    chunk = (b"x" * 1023 + b"\n") * 1024
    while True:
        sys.stdout.buffer.write(chunk)
