"""Red-team: fills the only writable place (/tmp, a memory-backed filesystem) without end. The memory limit or a full-disk error must stop it:
a crash or timeout in bounded time, never a solve."""


def solve(basis, bound2):
    i = 0
    while True:
        with open(f"/tmp/fill{i}", "wb") as f:
            f.write(b"\x01" * (64 * 1024 * 1024))
        i += 1
