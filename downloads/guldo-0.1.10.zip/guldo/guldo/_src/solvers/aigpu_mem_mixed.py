"""aigpu with bytes counted, TECHNIQUE: the usual mixed-precision recipe for attention. The two big matrix products (Q K^T and P V) run on fp16 operands; the softmax, which needs range and a long sum, runs in
fp32 on the scores cast up from fp16, and the probabilities are cast back to fp16 for the product with V. Fewer bytes than fp64 and more than all-fp16; the extra casts cost operations."""
import math

import tensorops as tp

CLASSES = 16


def inputs(seed, n, H, dk):
    m = H * n * dk
    d = H * dk
    Q = tp.reshape(tp.stream(seed, 0, m), (H, n, dk)) * 3.0
    K = tp.reshape(tp.stream(seed, m, m), (H, n, dk))
    V = tp.reshape(tp.stream(seed, 2 * m, m), (H, n, dk))
    Wout = tp.reshape(tp.stream(seed, 3 * m, d * CLASSES), (d, CLASSES)) * math.sqrt(3.0 / d)
    return Q, K, V, Wout


def labels(O, Wout, n, H, dk):
    rows = (tp.reshape(tp.transpose(O, (1, 0, 2)), (n, H * dk)) @ Wout).tolist()
    return [row.index(max(row)) for row in rows]


def solve(seed, n, H, dk):
    Q, K, V, Wout = inputs(seed, n, H, dk)
    Q = tp.cast(Q, "fp16")
    K = tp.cast(K, "fp16")
    V = tp.cast(V, "fp16")
    S = tp.cast((Q @ tp.transpose(K, (0, 2, 1))) * (1.0 / math.sqrt(dk)), "fp32")
    E = tp.exp(S - tp.max(S, 2, True))
    P = tp.cast(E / tp.sum(E, 2, True), "fp16")
    return labels(tp.cast(P @ V, "fp32"), tp.cast(Wout, "fp32"), n, H, dk)
