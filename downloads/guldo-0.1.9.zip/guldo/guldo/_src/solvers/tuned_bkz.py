"""Honest speedup: same progressive BKZ, but with extreme-pruned enumeration (fplll default strategies)."""
import os

from fpylll import BKZ, LLL, IntegerMatrix
from fpylll.fplll.bkz_param import load_strategies_json

STRATEGIES = next(p for p in (BKZ.DEFAULT_STRATEGY.decode() if isinstance(BKZ.DEFAULT_STRATEGY, bytes) else BKZ.DEFAULT_STRATEGY,
                              "/opt/fplll/strategies/default.json",
                              "/opt/homebrew/share/fplll/strategies/default.json",
                              "/opt/homebrew/Cellar/fplll/5.5.0/share/fplll/strategies/default.json")
                  if os.path.exists(p))
_LOADED = load_strategies_json(STRATEGIES.encode())  # parse the 8.6 MB file once, not once per block size


def solve(basis, bound2):
    n = len(basis)
    A = IntegerMatrix.from_matrix(basis)
    LLL.reduction(A)
    for beta in list(range(10, n + 1, 4)):
        if sum(x * x for x in A[0]) <= bound2:
            break
        BKZ.reduction(A, BKZ.Param(block_size=beta, strategies=_LOADED,
                                   flags=BKZ.AUTO_ABORT | BKZ.MAX_LOOPS, max_loops=8))
    v = [int(x) for x in A[0]]
    return v if sum(x * x for x in v) <= bound2 else None
