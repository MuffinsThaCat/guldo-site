# Running the public competition

This is the runbook for putting the submission path on the internet. It assumes you have read PROTOCOL.md. Everything here is
written and unit-tested, and it has now run on one real server (a Hetzner VPS, November 2026): the portal behind Caddy with TLS, a counted test
round taken through submit, close, evaluate, reveal and a certificate verified from another computer, and a real counted round open for submissions. The
sandbox passed its full test suite (including resource-exhaustion and meter-tampering attacks) on GitHub's Linux runners and on that server.
**Not yet done:** a full timed round end to end on an evaluation machine that is separate from the web service (EVAL_BOX.md), a public timed round, and a
timed evaluation at the official size (one is running as a private rehearsal). Read the sections below with that in mind: the parts marked untested
are still untested.

These files go with this one: COUNTED_ROUND_RUNBOOK.md (the exact steps to close out a counted round on this server; `round_preflight.py`, a read-only check that a
round can still be evaluated here; and `operator_check.py`, one command from your own computer that checks the whole system), EVAL_BOX.md (the second machine, backups, CPU pinning, running the sandbox on the web machine for a trusted rehearsal),
LATTICE_ROUND.md (what a lattice round would certify, what it costs, and the decisions and gate for opening one), COUNTED_ROUNDS_CI.md (running a counted round on a free
GitHub runner instead of a server) and ROUND1_INSTRUCTIONS.tex (what to send participants of the first round).

## 1. The three trust zones

| zone | process | user | can | cannot |
|---|---|---|---|---|
| web tier | `public_portal.py serve` | `ledger-web` | list rounds, accept an upload, `ast`-parse it, append to the round's log | execute an upload, read a seed, reach Docker |
| operator | `ops.py` | `ledger-ops` | create rounds (makes the seeds), close, evaluate, reveal, export | (trusted) |
| sandbox | docker container per solver run | uid 10001 inside it | run one solver on one instance with a CPU cap | network, filesystem outside `/work`, seeds |

Why this split: the web tier handles hostile input all day, so it must not hold anything worth stealing. The seeds are the only
secret the protocol has, and they live under `ledger-ops` only (`/srv/ledger/seeds`, mode 0700). If the web tier is fully
compromised, an attacker can read submissions (public after the reveal anyway), flood the queue (bounded, see below), or take
the site down. They cannot learn a seed, so they cannot pre-solve a round.

## 2. What keeps the operator honest

Each round has an append-only **hash-chained log**. Entry 0 holds the seed commitments **and the rules**: the ladder sizes, the
instance version, the baseline solver's hash and the hashes of the code that generates, runs, meters and scores instances. It is
written when the round is created, so all of it is public before any submission exists. The worker refuses to evaluate if any of
that has changed since (so a bug fix mid-round means a new round); `ops.py worker --accept-code-change` overrides, and writes a
public `code_changed` entry with the old and new hashes, so a competitor can see exactly what changed and when. Every accepted file's SHA-256 is an entry. Anyone can
download `/api/log/<round>.jsonl` and check the chain (`ops.py verify-log`, or `rounds.verify_log`): a dropped, reordered,
altered or back-dated entry breaks it. **Publish the head hash somewhere you cannot edit it** after each round closes (a signed
post, a git tag in another repository): that anchors the log, so even you cannot rewrite history. The software refuses to
append to a log that does not verify.

## 3. Setup, in order

1. **Host.** A small Linux VPS for the web tier and site. For stronger isolation, evaluate on a *separate* VM (step 6).
2. **Users and directories.**
   ```
   useradd --system ledger-web;  useradd -m ledger-ops;  groupadd ledger
   usermod -aG ledger ledger-web;  usermod -aG ledger ledger-ops
   install -d -o ledger-ops -g ledger-ops -m 0755 /srv/ledger                # the operator builds site.new / site.old inside it
   install -d -o ledger-ops -g ledger -m 2770 /srv/ledger/data
   install -d -o ledger-ops -g ledger-ops -m 0700 /srv/ledger/seeds      # web tier has no access
   install -d -o ledger-ops -m 0755 /srv/ledger/site
   ```
   Both the web tier (systemd `UMask=0007`) and `ops.py` (it sets umask 007 itself) create group-writable files, so the two users
   can share the data directory. If you create anything under `data/` by hand, make it group-writable too.
3. **Code.** Copy this directory to `/opt/speedup-verification`, owned by root and read-only to `ledger-web`.
4. **Edit** `deploy/Caddyfile`, `deploy/ledger-web.service` and `deploy/ledger-export.service`: replace `ledger.example.org`.
5. **Web tier.** `cp deploy/ledger-web.service /etc/systemd/system/ && systemctl enable --now ledger-web`; install Caddy and
   use `deploy/Caddyfile` (it terminates TLS and overwrites `X-Forwarded-For`). Test: `curl -s https://<host>/healthz`.
6. **Sandbox (the gate).** On the machine that will evaluate: install Docker, build the image
   (`sandbox/README.md`), then `python3 portal.py verify-sandbox --data /srv/ledger/data`. It writes a marker **only if the
   sandbox tests all run and pass with none skipped**, and the marker is tied to a fingerprint of the sandbox files, so it lapses
   if they change. Also run `sandbox/linux_selftest.py` as root on a Linux box. **Do not open a round for evaluation before this
   passes.** The worker refuses to run without the marker, and there is no flag to override that.
7. **Create a round** (as `ledger-ops`):
   ```
   python3 ops.py round-new --data /srv/ledger/data --seed-dir /srv/ledger/seeds --id winter-1 \
       --title "Winter round: lattice SVP" --family gm --closes 2026-12-31T23:59:00Z
   ```
   It creates the seeds (mode 0600), writes the commitments into the log, and opens the round. Announce the commitments.
   **Decide about private solvers now**, because it becomes a public rule in the log's first entry. By default a submitter may keep their solver private:
   the public certificate then carries only its hash, nobody but you can run it, and its timings rest on your sandbox alone. Add `--require-source` to
   require every submission to publish its source after the reveal (the server refuses a submission without it, `svp.py` refuses before uploading, and the
   web form marks the box required). Which to choose is your call: private solvers invite more entrants, published ones make every result re-checkable.
   **Then check the host and the running service, before you announce anything:**
   ```
   python3 ops.py preflight --data /srv/ledger/data --seed-dir /srv/ledger/seeds      # on the host, as ledger-ops: permissions, no seed in data/, sandbox marker, logs
   python3 deploy_smoke.py https://<host>                                              # from anywhere: headers, Host/Origin refusals, every round's log, no early seed
   ```
   `preflight` is read-only and fails if the seed directory can be entered by the group (the web tier's group), if any seed file sits under the data
   directory, or if a round's log does not verify; it warns when no sandbox is verified. `deploy_smoke.py` tests the **running** service over
   the network (a stripped header, a proxy that forwards a foreign Host, a log that does not verify, a seed shown early are all findings). Both
   are tested against deliberately broken setups. `deploy_smoke.py URL --submit FILE --round ID --handle NAME` adds one real, permanent submission.
8. **Build the site** with the round listed: `python3 build_site.py --out /srv/ledger/site.new --ledger-data /srv/ledger/data --portal-url https://<host>`
   (or enable `ledger-export.timer`, which does this every 5 minutes).

## 4. Round lifecycle

`open` (submissions accepted; files only read) -> `closed` (deadline passed, nothing more accepted) -> `evaluating` -> `evaluated`
-> `revealed` (seeds published, each checked against its commitment).

```
python3 ops.py close  --data D --id winter-1                       # automatic at the deadline on the next request; --force closes early (logged)
python3 portal.py verify-sandbox --data D                          # must pass on the evaluating host
python3 ops.py worker --data D --id winter-1 --seed-dir /srv/ledger/seeds/winter-1
python3 ops.py reveal --data D --id winter-1 --seed-dir /srv/ledger/seeds/winter-1
python3 ops.py certs  --data D --id winter-1 --seed-dir /srv/ledger/seeds/winter-1   # one verified certificate per evaluated submission
python3 ops.py verify-log --data D --id winter-1                   # then publish the head hash
```
`ops.py certs` runs after the reveal (a certificate carries the seeds) and stores a certificate only if it verifies. Submitters then fetch it
with `svp.py` (SUBMIT.md). `GET /api/cert/<round>/<id>.json` is open to everyone: it carries the solver's source only when the owner chose "publish
source", and is otherwise a private-solver copy (hash, no source, no failure text); `GET /api/cert-full/<round>/<id>.json` is the full certificate and needs the
handle's token in an `Authorization: Bearer` header, because the certificate contains the solver. `ops.py export` copies the public ones next to
the round's log. **Fails closed:** on every release the portal re-checks that the public certificate of a submission whose owner did NOT publish their
source really is a private-solver certificate (marked so, no source). A file that is not (a stale one from an older version, a mistake) is refused with
403, not advertised in the round's description and not exported; `ops.py certs` rebuilds it in place.
Evaluation of one submission is 3 seeds x 2 ladders at the family's official size, up to several CPU-hours (`official.py plan`).
Run it deliberately, not from a timer. Results appear on the round page only after the round is `evaluated`.

**A counted round** (`round-new --count --count-dims ...`, COMPILER.md "Counted rounds") is evaluated without Docker:
`python3 ops.py worker --data D --id r --seed-dir S/r --unsandboxed [--results-dir R]`. Submitted code runs in the counter's restricted subset of Python (an in-process sandbox that protects the counter's integrity: no `sys`, files, frames, `getattr`/`eval`;
COMPILER.md "The restricted subset"), but there is no operating-system isolation, hence the flag: it still runs as the operator's user, so do it as a
throwaway user or VM that holds nothing of value (and, ideally, no seeds you still need secret: the seeds are revealed right after anyway). It needs the same
Python the round committed to, to the patch level (check `svp.py round ID` for the version). On a machine with automatic updates, an interpreter update in the middle of
a round would make the evaluation refuse to run, so hold the interpreter for the life of the round: `apt-mark hold python3.14 python3.14-minimal` plus the
`libpython3.14*` packages (`dpkg -l | grep libpython`), and release it with `apt-mark unhold` once the round is evaluated and revealed. `reveal` and `certs` are unchanged.
This path has run end to end on a real server for a test round; see the top of this file for what has and has not been tried.

**Evaluating on a separate VM.** After `close` the web tier no longer writes the round, so you can `rsync -a D/rounds/winter-1/`
to the evaluation VM, run the worker there against its own copy, and rsync the directory back before `reveal`. Keep the seeds on
the evaluation VM only.

## 4b. What evaluation costs (read before you set a limit)

A solver that works is cheap. A solver that FAILS is not: every failed, wrong, crashed or timed-out instance is charged the whole CPU
cap, and the judge really spends that time (the sandbox runs it until the cap or the wall deadline). For `gm` that is 120 instances x
3 seeds x 120 s = **12 CPU-hours per submission that fails everything**, plus the baseline ladders once (about the same again, shared
by all). A round that accepts 200 junk submissions could take months of machine time. Consequences, and what to do:
* `ops.py round-new --max-submissions N` (default 50, logged in the round's first entry so it is a public rule) bounds the count, and
  prints this worst case when you create the round. Pick N from the machine time you actually have.
* `ops.py round-new --n N` sets the instances per size for the round (default: the family's official 24 for `gm`; at most 200; also logged
  in the round's first entry). More instances is how a round certifies larger speedups: measured with `power.py --copies K --resample`, a
  4-bit constant speedup is certified 1% of the time at n=24, 68% at n=48 and 100% at n=96, and 5 bits 50% at n=48 and 98% at n=96
  (PROTOCOL.md, "Power at the OFFICIAL configuration"): for 4 to 5 bits use about 96. The price is linear: n=48 doubles the worst-case
  evaluation time per submission (24 CPU-hours for `gm` at 3 seeds) and n=96 quadruples it (48), so lower `--max-submissions` accordingly. No n lifts the ceiling of about 5 bits at a 120 s cap: at 6 bits the result is
  inconclusive whatever the count.
* Evaluation is one worker at a time. Several machines means several data directories, not one shared one (the board file is global).
* A hostile solver that sleeps or hides orphan processes is charged the cap too, and the meter holds each such instance until its wall
  deadline (3x the cap + 10 s), so it costs the judge wall time without costing its owner anything. The cap on submissions is the defence.
* Not implemented, a design choice for you: a cheap screen that runs each submission on a few small public instances in the sandbox and
  skips the official run if it cannot solve even those. It would save hours per junk file, but it excludes solvers that only work at
  large sizes, so it would have to be a published rule in the round's first entry. The code to add it is small; the rule is the decision.

## 5. Abuse and failure controls (each has a test)

* **Kill switch:** `ops.py kill-switch --data D on` pauses submissions instantly (reads keep working); `off` resumes.
* **Graceful stop:** on SIGTERM/SIGINT (`systemctl stop` or `restart`) the web tier stops accepting connections, finishes the requests
  already in flight (at most about 10 s, the socket timeout), then exits 0. A restart during a submission therefore cannot cut it between
  the log append and the metadata write (tested with a real subprocess and a half-sent upload). A hard kill (SIGKILL, power loss) still can:
  that leaves a log entry with nothing stored, which `ops.py verify-log` reports and the section below explains. The worker is different:
  stopping it mid-evaluation leaves that submission `evaluating`, and the next run retries it.
* **Limits:** 200 KB per file; 3 submissions per handle per round; `--max-submissions` per round (default 50, at most 200); 6 per hour per address (burst 3) and 300 per hour overall;
  120 requests/min per address; 64 concurrent connections (the rest get a 503); a 10 s stall timeout. Rejections store nothing.
* **No accounts.** A handle is bound to a secret token issued with its first submission; only the token's hash is stored.
* **Privacy:** the service stores the handle, the file and its hash. No IP address, no contact detail. Rate limiting uses a
  per-process salted hash of the address held in memory only.
* **Logs:** no access log. Add one at the proxy if you need it and decide your retention.

## 6. Things only you can decide (RULES.md is a draft)

* the rules text, licence terms for submitted code, and any prize or eligibility limits (get legal review before publishing);
* the domain, the host and who is on call; whether to publish sources by default (it is opt-in per submission here);
* what happens to a handle someone claims is theirs (the answer today: nothing, the token is the only proof);
* retention: log entries are permanent by design; sources can be deleted on request after the reveal, but their hash stays in the log.

## 7. Known limits

* The sandbox is unverified (above). Official credit also needs 3 seeds per round, which `ops.py round-new` enforces.
* The round page shows a submission's result only once the round is `evaluated`, but the main site's Results leaderboard reads the
  global board file as the judge writes it, so a credit can appear there a little earlier (never a seed; submissions are already
  closed by then, so it cannot be used to adapt). If you need the two to agree, rebuild the site only after `ops.py worker` finishes
  (disable `ledger-export.timer` during an evaluation).
* A failed evaluation's raw output is written to `rounds/<id>/submissions/<sid>/eval_error.log` (group-readable only, never
  exported); the public page says only "evaluation failed; the operator has the details", because tracebacks can contain seed paths.
* One worker at a time for the whole data directory (every evaluation writes the one board file).
* **The baseline is measured once per seed and reused** by every later submission in the round (`--reuse-baseline`, accepted only when the
  seed commitment, baseline file hash, family, budget, instance version, sandbox, image, CPU and job count all match and the ladder is
  complete; otherwise it is measured again). That keeps a round's cost near one baseline ladder per seed, and every submission is
  compared with the same measurement. The trade-off: a submission evaluated hours after the baseline is compared with a baseline timed
  earlier, so keep the evaluation machine otherwise idle and thermally steady, and spot-check with `remeasure.py`.
* **The worker runs a file only if it still matches the hash in the log**, and `ops.py verify-log` also cross-checks every stored file
  against the log (a swapped file, a stored submission with no log entry, or a log entry with nothing stored). The last one is what a
  crash between the log append and the metadata write looks like: that submission was never acknowledged to its sender, so do NOT edit
  the log; leave it, and say in the announcement that entry #N is an unacknowledged crash artifact.
* **Python 3.9 or newer** (both entry points refuse older ones with a clear message). The web tier (`public_portal.py`) and the operator
  tool (`ops.py`) need only the standard library: `test_python_compat.py` blocks numpy and fpylll outright and has them create a round,
  accept and lint a submission and render a page. numpy IS needed by `build_site.py` and by evaluation (the estimator computes the
  credits), which run on the operator/evaluating machine; fpylll only inside the sandbox image. Verified on Python 3.9.6 and 3.14 (macOS),
  where `test_python_compat.py` also re-checks every module on the oldest interpreter it can find. NOT run on 3.10 to 3.13 or on Linux.
  (Found by audit: the service could not even be imported before 3.12 because of an f-string, and the web tier needlessly imported
  numpy through the local portal; both fixed.)
* Linux/macOS only (`fcntl` file locks).
* **The server clock is the authority for deadlines.** Keep NTP running. A clock that steps BACKWARD is tolerated (log timestamps are
  clamped so they never go backwards). A clock that jumps FORWARD past a deadline closes the round, and closing is permanent: there
  is no reopen, by design, because the log records it. If that happens, create a new round and say why in the announcement.
* Serve the static site and the service on one domain only with the Caddyfile's split: the static site owns `/assets/*`, the service
  owns `/round`, `/s`, `/api` and `/portal-assets` (its stylesheet has a different path on purpose).
* A hostile solver that escapes the sandbox is the one threat the whole design leans on the container for: keep the evaluating
  host disposable, with no credentials on it, and the seeds only for the duration of a round.
* The static site is a snapshot; it shows what was exported at build time.
* There is no spam protection beyond rate limits and the token: an attacker with many addresses can fill a round's slots
  (`--max-submissions`, 50 by default) with junk, which also costs you evaluation time (section 4b). The response is the kill switch,
  and creating the next round with a lower limit; a filled round cannot be reopened or have entries removed, by design.
