#!/usr/bin/env python3
"""Standalone checker for one challenge bundle (made by `compile_domain.py export`). Python standard library only, plus whatever the
declaration itself imports (challenge.json, "requires").

    python3 check.py info                                      what this challenge is
    python3 check.py selftest                                  does this bundle work, here, as shipped? (exit 1 if not)
    python3 check.py commit --seed-file F                      sha256 of a seed file: the value to publish BEFORE the deadline
    python3 check.py derive --seed-file F --size N --idx I     the instance a solver receives (never the planted answer)
    python3 check.py derive --practice --size N --idx I        the same on the public practice seed
    python3 check.py verify --seed-file F --size N --idx I --answer JSON    exit 0 if the answer is valid, 1 if not
    python3 check.py rerun --seed-file F --solver S.py --claimed SUB.jsonl --baseline REF.jsonl [-k 5] [--sign KEY --attest-out FILE]
                                                               re-measure a random sample of a CLAIMED result on this machine, sandboxed: do the claims reproduce?
    python3 check.py keygen --out KEY                          a signing key for attestations; publish the public key it prints
    python3 check.py attest-check A1.json A2.json --trusted KEYS --min 2     do independent verifiers (keys YOU pinned) attest the claim reproduces?
    python3 check.py log append LOG --file F [--kind K]        append-only hash-chained log;  log verify LOG [--head H] [--checkpoint C]
    python3 check.py log checkpoint LOG --key K --out C        a SIGNED (head, count): a log that no longer contains it was truncated or forked

An answer is JSON: `7`, `[3, 5]`, `null`. `--answer @file` reads a file, `--answer -` reads stdin.
`derive` and `verify` need the seed, so only the operator runs them with a real seed; competitors use --practice.

WARNING: every command except `info` and `commit` IMPORTS AND RUNS checker/decl.py (and `selftest` runs checker/reference.py), unsandboxed, as you.
That is the author's code. Read it, or run this in a throwaway VM or container, before running a bundle you did not make. The pinned-file hash
check in `selftest` proves the files are the ones the manifest names, not that they are safe. `rerun` additionally EXECUTES the competitor's solver
file (and the reference) in child processes with a CPU limit, inside an OS sandbox by default (macOS sandbox-exec; Linux bubblewrap if present): no network, no
writes outside a scratch directory, the seed and your keys unreadable. That stops the practical cheats and the obvious damage; it is not a proof of isolation.
"""
import argparse
import hashlib
import importlib.util
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.append(os.path.join(HERE, "vendor"))   # after the standard library: a vendored file can never shadow it

PRACTICE_SEED = b"practice-seed-public"
MAX_ARGS_BYTES = 1 << 20
JUNK = [None, 0, 1, -1, True, False, "", "0", "x", [], [0], [1], [None], {}, 1.5, -0.0, 10 ** 40, [[]], ["0"]]


def int_arg(lo, hi):
    """argparse type: an integer in [lo, hi], else a one-line usage error (never a traceback, never an unbounded computation)."""
    def parse(text):
        try:
            v = int(text)
        except ValueError:
            raise argparse.ArgumentTypeError(f"{text!r} is not an integer")
        if not lo <= v <= hi:
            raise argparse.ArgumentTypeError(f"{v} is outside the allowed range {lo}..{hi}")
        return v
    return parse


def float_arg(lo, hi):
    def parse(text):
        import math
        try:
            v = float(text)
        except ValueError:
            raise argparse.ArgumentTypeError(f"{text!r} is not a number")
        if not math.isfinite(v) or not lo <= v <= hi:
            raise argparse.ArgumentTypeError(f"{text} is not a finite number in {lo}..{hi}")
        return v
    return parse


def hex_arg(text):
    try:
        raw = bytes.fromhex(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"{text!r} is not hexadecimal")
    if not 1 <= len(raw) <= 64:
        raise argparse.ArgumentTypeError("the seed must be 1 to 64 bytes (2 to 128 hex digits)")
    return text


def size_idx_problem(ch, size, idx):
    """A size outside the challenge's declared range (or a huge index) is handed to the author's derive(), which may hang, allocate gigabytes or crash."""
    lad = ch["ladder"]
    sizes = list(lad["dims"]) + list(lad["practice_dims"])
    rng = lad.get("size_range") or [min(sizes), max(sizes)]
    if not rng[0] <= size <= rng[1]:
        return f"size {size} is outside this challenge's declared range {rng[0]}..{rng[1]}"
    if not 0 <= idx < 1_000_000:
        return f"index {idx} is outside 0..999999"
    return None


def manifest():
    with open(os.path.join(ROOT, "challenge.json"), encoding="utf-8") as f:
        return json.load(f)


class FileRefused(ValueError):
    """A path that is not a regular file within the size limit. Opening or reading a FIFO blocks for ever and /dev/zero never ends (found by probing: every reader
    hung on a FIFO, and a 300 MB single-line file took 626 MB); a symlink in an uploaded tree can point at either."""


LIMIT_SMALL = 1 << 20     # seeds, key lists, keys
LIMIT_JSON = 16 << 20     # results, attestations, checkpoints, measurements
LIMIT_LADDER = 32 << 20   # 20,000 records of ~150 bytes is 3 MB
LIMIT_LOG = 64 << 20
LIMIT_ANSWER = 64 << 20


def _flock(fd, exclusive, required):
    """flock. Appending MUST hold the exclusive lock across read, verify and write (eight concurrent appends without it wrote 4 entries, broke the chain and lost 4
    submissions); reading takes a shared lock so it never sees a half-written line. Needs POSIX; where there is none a read goes unlocked, an append refuses."""
    try:
        import fcntl
    except ImportError:
        if required:
            raise SystemExit("appending to a log needs POSIX file locking (fcntl), which this system does not have")
        return
    fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)


def _open_regular(path, limit):
    """-> (fd, size) of a regular file no bigger than `limit`, opened WITHOUT blocking (a FIFO opens at once and is then refused), else FileRefused."""
    import stat
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_BINARY", 0))   # no O_NONBLOCK on Windows (there are no FIFOs to block on); O_BINARY avoids text-mode newline mangling there
    except OSError as e:
        raise FileRefused(f"cannot read {path}: {e.strerror}")
    st = os.fstat(fd)
    if not stat.S_ISREG(st.st_mode):
        os.close(fd)
        raise FileRefused(f"{path} is not a regular file (a FIFO, device, socket or directory is refused: reading it could block or never end)")
    if limit is not None and st.st_size > limit:
        os.close(fd)
        raise FileRefused(f"{path} is {st.st_size} bytes, over the {limit} byte limit for this kind of file")
    return fd


def read_bytes(path, limit, shared_lock=False):
    fd = _open_regular(path, limit)
    try:
        if shared_lock:
            _flock(fd, False, False)
        chunks, total = [], 0
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                break
            total += len(chunk)
            if total > limit:   # it grew while we read it
                raise FileRefused(f"{path} grew past {limit} bytes while being read")
            chunks.append(chunk)
        return b"".join(chunks)
    finally:
        os.close(fd)


def read_text(path, limit, shared_lock=False):
    data = read_bytes(path, limit, shared_lock)
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        raise FileRefused(f"{path} is not UTF-8 text")


def sha256_file(path):
    """Streamed, and only for a regular file (hashing /dev/zero would never finish)."""
    fd = _open_regular(path, None)
    try:
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                return h.hexdigest()
            h.update(chunk)
    finally:
        os.close(fd)


def file_problems(ch):
    """Every file the challenge pins must hash as recorded. [] = the bundle is intact."""
    out = []
    for rel, want in sorted(ch["files"].items()):
        p = os.path.join(ROOT, rel)
        if not os.path.isfile(p):
            out.append(f"missing: {rel}")
        elif sha256_file(p) != want:
            out.append(f"changed: {rel}")
    return out


def load_decl():
    import decl
    return decl


def load_reference(ch):
    path = os.path.join(ROOT, ch["reference"]["file"])
    spec = importlib.util.spec_from_file_location("bundle_reference", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def master_from(a):
    if a.practice:
        return PRACTICE_SEED
    if a.seed_file:
        return read_bytes(a.seed_file, LIMIT_SMALL).strip()
    raise SystemExit("give --seed-file F (the operator's seed) or --practice")


def instance(decl, master, size, idx):
    inst = dict(decl.derive(master, size, idx))
    inst.setdefault("id", f"{size}:{idx}")
    inst.setdefault("dim", size)
    inst.setdefault("idx", idx)
    return inst


def args_problem(inst):
    try:
        text = json.dumps(inst["args"])
    except (TypeError, ValueError) as e:
        return f"args are not JSON-serializable ({e})"
    if not isinstance(inst["args"], list):
        return "args is not a list"
    if len(text) > MAX_ARGS_BYTES:
        return f"args are {len(text)} bytes (limit {MAX_ARGS_BYTES})"
    return None


def read_answer(text):
    if text == "-":
        text = sys.stdin.read()
    elif text.startswith("@"):
        text = read_text(text[1:], LIMIT_ANSWER)
    try:
        return json.loads(text)
    except (ValueError, RecursionError) as e:
        raise SystemExit(f"--answer is not usable JSON: {type(e).__name__}: {str(e)[:100]}")


def safe_verify(decl, inst, ans, report=False):
    """A verifier that raises on junk rejects it: a crash must never count as a valid answer. `report` says so on stderr (a real answer that
    crashes the verifier is a bug in the declaration the operator should see, not a quiet 'invalid')."""
    try:
        return bool(decl.verify(inst, ans))
    except Exception as e:
        if report:
            print(f"note: verify() raised {type(e).__name__}: {e}; counted as invalid", file=sys.stderr)
        return False


def cmd_info(a):
    ch = manifest()
    print(f"{ch['name']} ({ch['version']}), bundle status {ch['status']}")
    print(ch["problem"]["doc"])
    if ch.get("metric") == "quality":   # answers are scored, not the clock: the fields below are the speed ones
        pw = ch["power"]
        print(f"solver contract: {ch['solver_contract']}")
        print(f"QUALITY challenge: sizes {ch['ladder']['dims']}, {ch['ladder']['n']} instances per size, {ch['ladder']['budget_seconds']} CPU s per instance for everyone, "
              f"{ch['protocol']['seeds_required']} committed seeds; tools: qcheck.py, qscore.py")
        print(f"certifiable mean gain: {pw['min_certifiable']} to {pw['max_certifiable']} quality points (None = this ladder cannot certify)")
        print(f"reference: {ch['reference']['note'] or 'NOT STATED'}")
        return 0
    print(f"solver contract: {ch['solver_contract']}")
    print(f"sizes {ch['ladder']['dims']}, {ch['ladder']['n']} instances per size, CPU cap {ch['ladder']['budget_seconds']} s, "
          f"{ch['protocol']['seeds_required']} committed seeds")
    pw = ch["power"]
    print(f"certifiable speedup range: {pw['min_certifiable_bits']} to {pw['max_certifiable_bits']} bits (None = this ladder cannot certify)")
    print(f"reference: {ch['reference']['note'] or 'NOT STATED'}")
    return 0


def cmd_commit(a):
    print(hashlib.sha256(master_from(a)).hexdigest())
    return 0


def cmd_derive(a):
    bad = size_idx_problem(manifest(), a.size, a.idx)
    if bad:
        raise SystemExit(bad)
    decl = load_decl()
    master = master_from(a)
    inst = instance(decl, master, a.size, a.idx)
    bad = args_problem(inst)
    if bad:
        raise SystemExit(bad)
    print(json.dumps({"commit": hashlib.sha256(master).hexdigest(), "id": inst["id"], "size": a.size, "idx": a.idx, "args": inst["args"]}))
    return 0


def cmd_verify(a):
    bad = size_idx_problem(manifest(), a.size, a.idx)
    if bad:
        raise SystemExit(bad)
    decl = load_decl()
    inst = instance(decl, master_from(a), a.size, a.idx)
    ok = safe_verify(decl, inst, read_answer(a.answer), report=True)
    print(json.dumps({"valid": ok}))
    return 0 if ok else 1


RUNNER = r'''
import importlib.util, json, sys
path = sys.argv[1]
args = json.loads(sys.stdin.read())
real_out, sys.stdout = sys.stdout, sys.stderr
spec = importlib.util.spec_from_file_location("rerun_solver", path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
ans = mod.solve(*args)
real_out.write("\n" + json.dumps(ans) + "\n")
'''


def sandbox_prefix(mode, deny_read, scratch):
    """argv prefix that runs a solver with no network, no writes outside `scratch`, and no reads of `deny_read` (the seed, signing keys) or of ~/.ssh, ~/.aws, ~/.gnupg,
    the keychain. macOS: sandbox-exec (deprecated by Apple but present; TESTED here). Linux: bubblewrap if installed (WRITTEN, NOT RUN by its author on a real Linux
    kernel; run `make test` there to find out: the sandbox tests run wherever a sandbox actually works). None = nothing available.
    It stops the practical cheats (read the seed, phone home, write a lookup table). It is not a proof of isolation: CPU time, memory and the kernel are shared."""
    if mode == "off":
        return []
    import shutil
    real = lambda p: os.path.realpath(p)   # noqa: E731  (/tmp and /var are symlinks on macOS; the sandbox matches real paths)
    exe, base = real(sys.executable), real(sys.base_prefix)   # macOS framework Python re-executes itself via Python.app: allow its whole installation, nothing else
    paths = [real(p) for p in deny_read if p] + [real(scratch)]
    if any(c in p for p in paths + [exe, base] for c in '"\\\n'):
        raise SystemExit("a path contains a quote, backslash or newline: refusing to build a sandbox profile from it")
    home = real(os.path.expanduser("~"))
    sb = shutil.which("sandbox-exec") if sys.platform == "darwin" else None
    if sb:
        denies = " ".join([f'(literal "{p}")' for p in paths[:-1]] + [f'(subpath "{home}/{d}")' for d in CREDENTIAL_DIRS])
        # No exec outside the interpreter: with it, a solver could run `open` (hand a URL to LaunchServices, i.e. network egress through ANOTHER process) or `sh`.
        # Found by trying: /bin/sh and open(1) both ran under the first version of this profile. Solvers are pure Python; they have no use for exec.
        profile = (f'(version 1)(allow default)(deny network*)(deny file-write*)(allow file-write* (subpath "{paths[-1]}") (literal "/dev/null"))'
                   f'(deny file-read* {denies})(deny process-exec*)(allow process-exec (literal "{exe}") (subpath "{base}"))'
                   # No Mach service lookups: a solver using ctypes could otherwise talk to LaunchServices, the pasteboard or preferences daemons directly (measured: all
                   # reachable under the earlier profile, all denied under this one). Only user-NAME lookups stay (pwd.getpwuid / getpass.getuser fail without it).
                   '(deny mach-lookup)(allow mach-lookup (global-name "com.apple.system.opendirectoryd.libinfo"))')
        return [sb, "-p", profile]
    bwrap = shutil.which("bwrap") if sys.platform.startswith("linux") else None
    if bwrap:
        # Everything read-only, scratch writable, no network, own pid/ipc namespaces, its own session (without --new-session a sandboxed process can push keystrokes
        # into your terminal with TIOCSTI). NOT `--tmpfs /tmp`: an earlier draft had it, which hides every solver and bundle that lives under /tmp from the sandbox
        # (all of the tests', and any CI checkout in a temp dir). Credential directories are masked with an empty tmpfs; the seed and keys with /dev/null.
        # --as-pid-1 is not optional: with --unshare-pid alone bubblewrap puts a reaper between us and the program, and the kernel's CPU accounting for the program
        # VANISHES (measured on a real Linux 7.0 kernel: a 2 s burn read as 0.00 s, so every `rerun` "measured" 0 and could pass or fail by accident). Running the program
        # itself as the namespace's init keeps the accounting (2.03 s) AND the PID namespace (a solver cannot see or signal your other processes).
        argv = [bwrap, "--ro-bind", "/", "/", "--dev", "/dev", "--proc", "/proc", "--bind", paths[-1], paths[-1], "--unshare-net", "--unshare-pid", "--as-pid-1",
                "--unshare-ipc", "--new-session", "--die-with-parent"]
        for d in CREDENTIAL_DIRS:
            if os.path.isdir(os.path.join(home, d)):
                argv += ["--tmpfs", os.path.join(home, d)]
        for p in paths[:-1]:
            argv += ["--ro-bind", "/dev/null", p]
        return argv
    return None


def working_sandbox(mode, deny_read, scratch):
    """-> (prefix, why_not). prefix is [] for mode "off", None when no sandbox can be used, else an argv prefix that was VERIFIED by running Python under it once.
    A sandbox tool that is installed but cannot run (Ubuntu 24.04 restricts unprivileged user namespaces, so bubblewrap fails there; sandbox-exec cannot nest inside
    another sandbox) must read as 'unavailable, and why', not as a mysterious failure of every command."""
    prefix = sandbox_prefix(mode, deny_read, scratch)
    if not prefix:
        return prefix, None
    import subprocess
    try:
        r = subprocess.run(prefix + [sys.executable, "-I", "-B", "-c", "pass"], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as e:
        return None, f"{type(e).__name__}: {e}"
    if r.returncode != 0:
        lines = [ln for ln in (r.stderr or r.stdout).splitlines() if ln.strip()]
        return None, (lines[-1][:200] if lines else f"exit {r.returncode}")
    return prefix, None


CREDENTIAL_DIRS = (".ssh", ".aws", ".gnupg", ".config/gcloud", "Library/Keychains")
DENIAL_WORDS = ("Permission", "Operation not permitted", "Read-only file system")
TOOL_ERRORS = ("bwrap:", "sandbox-exec:")   # a sandbox tool that could not start prints its own error first; the command it wraps never ran


class RunResult(tuple):
    """(status, answer, cpu seconds, stderr tail), still unpackable as 4 values, that also carries `.wall`: the wall-clock seconds of the run."""
    wall = None
    strays = ()   # pids of processes the run left behind (they were killed)
    scan_ran = True   # False when `ps` was unavailable, so "no strays" means "not checked"


DEFAULT_TOLERANCE = 2.0    # bits; pure Python measured 0.03 bit worst between a Mac and a Linux server
NUMERIC_TOLERANCE = 3.5    # bits; numpy: 3.42 worst (large matmul, solver +3.3 bits on the Mac and +0.03 on the server) and 2.18 (small kernels, the other way round) on the same two machines
NUMERIC_LIBS = {"numpy", "scipy", "torch", "jax", "tensorflow", "numba", "cupy"}   # third-party libraries whose speed depends on the machine's BLAS / vector hardware
ABSOLUTE_SHARE = 0.3   # with no honest run to compare against: the least CPU/wall share a CPU-bound solver can have
RELATIVE_SHARE = 0.6    # against the reference, which ran under the same load a moment earlier: the least fraction of ITS share the solver may have
REFERENCE_SHARE = 0.15  # the reference is the author's own code; only an absurdly low share suggests its meter is blind


def hides_cpu(run, cpu, ref=None, limit=None):
    """`ref` = (the reference's run, its CPU), measured on the same instance under the same load. When it ran long enough to have a meaningful share (over 0.5 s), the solver
    is flagged against RELATIVE_SHARE of that share instead of the fixed ABSOLUTE_SHARE: a loaded machine starves both alike (no false failure), and a solver that pads its CPU
    to just over 30% to hide the rest (up to 1.7 bits of fake speedup) is caught once it falls under ~60% of what the reference got (under ~0.8 bit). `limit` overrides all of it.
    The rule: """
    """True when a run took over half a second of wall time (the estimator ignores costs below FLOOR_ABS = 0.5 s, so shorter hidden work cannot move a score; an empty solver takes ~0.03 s, a sandboxed one ~0.1 s) but its CPU is under 30% of that. A CPU-bound solver cannot do that honestly; one that WAITS (sleeps, polls) or whose
    work runs in a process the parent never reaps can. Linux credits a child's CPU to its parent only when the parent waits for it, so a solver that forks the work and returns
    the answer through a pipe without waiting escapes `RUSAGE_CHILDREN` entirely (macOS credits it at the child's exit, so the attack fails there: the accounting differs by OS,
    the wall clock does not)."""
    wall = getattr(run, "wall", None)
    if wall is None or wall <= 0.5:
        return False
    if limit is None:
        limit = ABSOLUTE_SHARE
        ref_wall = getattr(ref[0], "wall", None) if ref else None
        if ref_wall is not None and ref_wall > 0.5:
            limit = RELATIVE_SHARE * min(1.0, ref[1] / ref_wall)
    return cpu < limit * wall


def _orphans_of(path):
    """pids of orphaned (parent = init) interpreters running this exact solver file through our runner. A solver that detaches a child (setsid, stdio closed) leaves one behind; it
    keeps burning CPU through the reference's next run, or serves later instances as a hidden helper. Only orphans are listed, so another session's live solver (whose parent is
    its own harness) is never matched. Linux with a subreaper (a user systemd) re-parents elsewhere: the bubblewrap sandbox is what covers Linux."""
    import subprocess
    try:
        done = subprocess.run(["ps", "-axo", "pid=,ppid=,command="], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None   # NOT "none found": slim containers have no `ps`, and a scan that could not run must not read as a clean one
    if done.returncode != 0:
        return None
    out = done.stdout
    found = set()
    for line in out.splitlines():
        parts = line.split(None, 2)
        if len(parts) == 3 and parts[1] == "1" and "rerun_solver" in parts[2] and os.path.abspath(path) in parts[2]:
            found.add(int(parts[0]))
    return found


def run_solver(path, args, cap, prefix=(), cwd=None):
    """One solve() in a fresh process: -> (status, answer, cpu seconds of the process tree). The CPU cap is enforced with RLIMIT_CPU and a wall backstop.
    `prefix` is a sandbox_prefix(); without one the solver runs as you and can do anything you can."""
    import resource
    import subprocess

    def limit():
        resource.setrlimit(resource.RLIMIT_CPU, (int(cap) + 1, int(cap) + 1))
    env = {"PATH": os.environ.get("PATH", ""), "HOME": os.environ.get("HOME", ""), "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
           "VECLIB_MAXIMUM_THREADS": "1", "PYTHONHASHSEED": "0"}
    import signal
    import time
    already = _orphans_of(path)   # the ps calls stay outside the CPU measurement window
    t_wall = time.monotonic()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    status, answer, tail = "crash", None, ""
    try:
        proc = subprocess.Popen(list(prefix) + [sys.executable, "-I", "-B", "-c", RUNNER, os.path.abspath(path)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, env=env, preexec_fn=limit, cwd=cwd, start_new_session=True)
        try:
            stdout, stderr = proc.communicate(json.dumps(args), timeout=cap * 3 + 10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            raise
        finally:
            try:
                os.killpg(proc.pid, signal.SIGKILL)   # children that stayed in the solver's process group die with the run
            except (ProcessLookupError, PermissionError):
                pass
        r = subprocess.CompletedProcess(proc.args, proc.returncode, stdout, stderr)
        err_lines = [ln for ln in r.stderr.splitlines() if ln.strip()]
        tail = err_lines[-1][:200] if err_lines else ""
        lines = [ln for ln in r.stdout.splitlines() if ln.strip()]
        if r.returncode == 0 and lines:
            answer, status = json.loads(lines[-1]), "ran"
        elif r.returncode in (-24, -9, 128 + 24, 128 + 9):   # SIGXCPU / SIGKILL, directly or reported by a wrapper (bubblewrap exits 137 when its program is killed)
            status = "timeout"
    except subprocess.TimeoutExpired:
        status = "timeout"
    except ValueError:
        status = "crash"
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    result = RunResult((status, answer, (after.ru_utime - before.ru_utime) + (after.ru_stime - before.ru_stime), tail))
    result.wall = time.monotonic() - t_wall
    now = _orphans_of(path)
    result.scan_ran = already is not None and now is not None
    result.strays = sorted(now - already) if result.scan_ran else []
    for pid in result.strays:
        try:
            os.kill(pid, signal.SIGKILL)   # exact pids, never a pattern
        except (ProcessLookupError, PermissionError):
            pass
    return result


def solver_overhead(tmp_path, prefix=(), cwd=None):
    with open(tmp_path, "w") as f:
        f.write("def solve(*a):\n    return None\n")
    runs = [run_solver(tmp_path, [], 30, prefix, cwd) for _ in range(5)]
    if any(r[0] != "ran" for r in runs):
        raise SystemExit("the sandbox or the interpreter cannot run even an empty solver here: " + (runs[0][3] or runs[0][0]))
    overhead = sorted(r[2] for r in runs)[2]
    if overhead < 0.002:   # starting Python costs ~10-50 ms of CPU anywhere; ~0 means the meter is not seeing the process (found on Linux under bwrap --unshare-pid)
        raise SystemExit(f"CPU accounting does not work here: an empty Python start measured {overhead * 1000:.2f} ms of CPU (it costs 10 ms or more). Every re-measurement would read ~0 "
                         "and 'pass' or 'fail' by accident, so rerun refuses. This sandbox configuration hides the program's CPU time from the parent.")
    return overhead


def load_costs(path, master):
    """{id: cost} of the SOLVED records of a ladder; refuses a ladder whose commitment is not this seed's."""
    costs, commit = {}, None
    for n, line in enumerate(read_text(path, LIMIT_LADDER).splitlines(), 1):
        if not line.strip():
            continue
        try:
            r = json.loads(line)
            if r.get("meta"):
                commit = r.get("commit")
            elif r.get("status") == "solved":
                costs[str(r["id"])] = float(r.get("cpu_net", r.get("cost")))
        except (ValueError, TypeError, AttributeError, OverflowError, RecursionError):
            raise SystemExit(f"{path}:{n}: not a ladder record")
    if commit is not None and commit != hashlib.sha256(master).hexdigest():
        raise SystemExit(f"{path} was run on a different seed (its commitment is not this seed's sha256)")
    return costs


# ---- Ed25519 (RFC 8032 section 6), pure Python, so signing needs no package. Slow and not constant-time: fine for signing one short statement on your own
# machine, and for checking signatures; do not use it for anything else.
_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493


def _inv(x):
    return pow(x, _P - 2, _P)


_D = -121665 * _inv(121666) % _P
_SQRT_M1 = pow(2, (_P - 1) // 4, _P)


def _padd(p, q):
    a, b = (p[1] - p[0]) * (q[1] - q[0]) % _P, (p[1] + p[0]) * (q[1] + q[0]) % _P
    c, d = 2 * p[3] * q[3] * _D % _P, 2 * p[2] * q[2] % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _P, g * h % _P, f * g % _P, e * h % _P)


def _pmul(s, p):
    q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            q = _padd(q, p)
        p = _padd(p, p)
        s >>= 1
    return q


def _peq(p, q):
    return (p[0] * q[2] - q[0] * p[2]) % _P == 0 and (p[1] * q[2] - q[1] * p[2]) % _P == 0


def _recover_x(y, sign):
    if y >= _P:
        return None
    x2 = (y * y - 1) * _inv(_D * y * y + 1) % _P
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _SQRT_M1 % _P
    if (x * x - x2) % _P != 0:
        return None
    return _P - x if (x & 1) != sign else x


_GY = 4 * _inv(5) % _P
_GX = _recover_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)


def _compress(p):
    zi = _inv(p[2])
    x, y = p[0] * zi % _P, p[1] * zi % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _P)


def _h512(m):
    return hashlib.sha512(m).digest()


def _expand(secret):
    h = _h512(secret)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def ed25519_public(secret):
    return _compress(_pmul(_expand(secret)[0], _G))


def ed25519_sign(secret, msg):
    a, prefix = _expand(secret)
    pub = _compress(_pmul(a, _G))
    r = int.from_bytes(_h512(prefix + msg), "little") % _Q
    rs = _compress(_pmul(r, _G))
    h = int.from_bytes(_h512(rs + pub + msg), "little") % _Q
    return rs + int.to_bytes((r + h * a) % _Q, 32, "little")


def ed25519_verify(public, msg, sig):
    if len(public) != 32 or len(sig) != 64:
        return False
    a_pt, r_pt = _decompress(public), _decompress(sig[:32])
    s = int.from_bytes(sig[32:], "little")
    if a_pt is None or r_pt is None or s >= _Q:
        return False
    h = int.from_bytes(_h512(sig[:32] + public + msg), "little") % _Q
    return _peq(_pmul(s, _G), _padd(r_pt, _pmul(h, a_pt)))


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()


ATTEST_FORMAT = "guldo-bundle-attestation-v1"
# Which defences a `rerun` attestation was made with, so a reader can tell a strong PASS from one made by an older tool: 1 = tolerance only (no field recorded),
# 2 = also fails a solver whose CPU is far below its wall time, leaves a detached process, or is measured by a dead CPU meter.
RERUN_CHECKS = 2


def cmd_keygen(a):
    if os.path.exists(a.out):
        raise SystemExit(f"{a.out} exists: this tool never overwrites a key")
    secret = os.urandom(32)
    fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(secret.hex() + "\n")
    print(f"wrote {a.out} (keep it private; mode 600)")
    print("public key (publish it, out of band, wherever people look for who you are):")
    print(ed25519_public(secret).hex())
    return 0


def read_key(path):
    try:
        secret = bytes.fromhex(read_text(path, LIMIT_SMALL).strip())
    except (OSError, ValueError) as e:
        raise SystemExit(f"cannot read a key from {path}: {e}")
    if len(secret) != 32:
        raise SystemExit(f"{path} does not hold a 32-byte hex key")
    return secret


def write_attestation(path, statement, secret):
    sig = ed25519_sign(secret, canonical(statement))
    try:
        f = open(path, "x", encoding="utf-8")   # exclusive create: never overwrites, with no race
    except FileExistsError:
        raise SystemExit(f"{path} exists: this tool never overwrites")
    except OSError as e:
        raise SystemExit(f"cannot write {path}: {e.strerror}")
    with f:
        json.dump({"statement": statement, "public_key": ed25519_public(secret).hex(), "signature": sig.hex()}, f, indent=1, sort_keys=True)
    print(f"wrote {path}; signed by {ed25519_public(secret).hex()[:16]}...")


def cmd_attest_check(a):
    """Verify signed rerun attestations. A signature proves WHO signed, not that they are independent of the operator: only keys you pinned in --trusted
    (obtained out of band) count as vouched. A valid dissent (outcome FAIL) from ANY key makes this fail."""
    import math
    ch = manifest()
    chsha = sha256_file(os.path.join(ROOT, "challenge.json"))
    trusted = read_trusted(a.trusted)
    seen, passes, dissent, problems = set(), set(), [], []
    for path in a.files:
        try:
            rec = json.loads(read_text(path, LIMIT_JSON))
            st, pub, sig = rec["statement"], rec["public_key"].lower(), bytes.fromhex(rec["signature"])
            assert isinstance(st, dict) and st.get("format") == ATTEST_FORMAT and st.get("outcome") in ("PASS", "FAIL")
        except (OSError, ValueError, KeyError, AssertionError, TypeError, AttributeError, RecursionError, OverflowError):
            problems.append(f"{path}: not an attestation this tool writes (ignored)")
            continue
        try:
            good = ed25519_verify(bytes.fromhex(pub), canonical(st), sig)
        except ValueError:
            good = False
        if not good:
            problems.append(f"{path}: the signature does not verify (ignored)")
            continue
        about = st.get("challenge")
        if not isinstance(about, dict) or about.get("challenge_json_sha256") != chsha:
            problems.append(f"{path}: signed for a different challenge bundle than this one (ignored)")
            continue
        bound = []
        for key, given in (("claimed_sha256", a.claimed), ("baseline_sha256", a.baseline)):
            if given:
                try:
                    want = sha256_file(given)
                except OSError as e:
                    raise SystemExit(f"cannot read {given}: {e.strerror}")
                if st.get(key) != want:
                    bound.append(key.split("_")[0])
        if bound:
            problems.append(f"{path}: refers to different {'/'.join(bound)} ladder(s) than the ones you gave (ignored)")
            continue
        vouched = pub in trusted
        machine = st.get("machine") if isinstance(st.get("machine"), dict) else {}
        show = lambda v: str(v)[:60].replace("\n", " ")   # noqa: E731  (a signer controls these fields: bound what is printed)
        print(f"{path}: valid signature by {pub[:16]}... ({'PINNED' if vouched else 'unvouched'}), outcome {st['outcome']}, sample {show(st.get('sample_seed', '?'))}, "
              + (f"median gap {show(st.get('median_gap_quality', '?'))} quality points" if "median_gap_quality" in st else f"median gap {show(st.get('median_gap_bits', '?'))} bits")
              + f" on {show(machine.get('platform', '?'))}")
        weak = []
        if st.get("kind") == "rerun":
            if st.get("sandboxed") is not True:
                weak.append("the solver ran UNSANDBOXED")
            if not isinstance(st.get("rerun_checks"), int) or st["rerun_checks"] < RERUN_CHECKS:   # (True counts as 1, so a bool is below 2 as well)
                weak.append("made by a tool version without the CPU-hiding and detached-process checks")
            elif st.get("process_scan") is False:
                weak.append("detached processes could not be checked (no `ps`)")
        tol = st.get("tolerance_bits")
        try:
            tol_ok = isinstance(tol, (int, float)) and not isinstance(tol, bool) and math.isfinite(tol) and tol >= 0
        except OverflowError:   # a signer can write an integer too large to convert to a float (found by the fuzz test)
            tol_ok = False
        if st.get("kind") == "rerun":
            print(f"    tolerance used: {format(tol, 'g') if tol_ok else 'not recorded or unreadable'}"
                  + (f" bits (a PASS at {tol:g} bits accepts any false claim within {tol:g} bits of the truth)" if tol_ok else ""))
            if a.max_tolerance is not None and st["outcome"] == "PASS" and (not tol_ok or tol > a.max_tolerance):
                problems.append(f"{path}: a PASS at tolerance {format(tol, 'g') if tol_ok else '?'} bits is looser than --max-tolerance {a.max_tolerance:g} (ignored)")
                continue
        if weak:
            print("    weaker evidence: " + "; ".join(weak))
        if weak and st["outcome"] == "PASS" and a.strict:
            problems.append(f"{path}: a PASS with weaker evidence ({'; '.join(weak)}) does not count under --strict (ignored)")
            continue
        if st["outcome"] == "FAIL":
            dissent.append(path)
        elif vouched and pub not in seen:
            passes.add(pub)
        seen.add(pub)
    for p in problems:
        print("note: " + p)
    ok = not dissent and len(passes) >= a.min
    print(f"{len(passes)} distinct PINNED key(s) attest the claim reproduces (need {a.min}); {len(dissent)} valid dissent(s)")
    if dissent:
        print("FAIL: a valid signed attestation says the claim does NOT reproduce: " + ", ".join(dissent))
    print("ATTESTATION " + ("OK" if ok else "NOT ESTABLISHED"))
    return 0 if ok else 1


# ---- an append-only, hash-chained log: tamper-evidence for a list of submissions, results or attestations. Without a head hash published somewhere the
# operator cannot edit, a truncated copy still verifies; the time in an entry is the logger's clock, not evidence.
def entry_hash(entry):
    return hashlib.sha256(canonical({k: v for k, v in entry.items() if k != "hash"})).hexdigest()


def lock_file(f, exclusive, required):
    _flock(f.fileno(), exclusive, required)


def parse_log(text, path):
    entries = []
    for n, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        try:
            entries.append(json.loads(line))
        except (ValueError, RecursionError):
            raise SystemExit(f"{path}:{n}: not JSON")
    return entries


def read_log(path):
    return parse_log(read_text(path, LIMIT_LOG, shared_lock=True), path)


def log_problems(entries):
    prev, out = "0" * 64, []
    for i, e in enumerate(entries):
        if not isinstance(e, dict) or e.get("seq") != i:
            out.append(f"entry {i}: out of order, missing or reordered")
            break
        if e.get("prev") != prev:
            out.append(f"entry {i}: does not follow entry {i - 1} (an entry was removed, reordered or altered)")
            break
        if e.get("hash") != entry_hash(e):
            out.append(f"entry {i}: its content does not match its hash (altered)")
            break
        prev = e["hash"]
    return out


CHECKPOINT_FORMAT = "guldo-log-checkpoint-v1"


def read_trusted(path):
    """Public keys (hex, one per line, # comments) the reader obtained out of band."""
    if not path:
        return set()
    return {ln.split("#")[0].strip().lower() for ln in read_text(path, LIMIT_SMALL).splitlines() if ln.split("#")[0].strip()}


def load_signed(path):
    """A file {statement, public_key, signature} with a VALID signature -> (statement, public key hex). Raises ValueError otherwise."""
    try:
        rec = json.loads(read_text(path, LIMIT_JSON))
        st, pub, sig = rec["statement"], rec["public_key"].lower(), bytes.fromhex(rec["signature"])
        if not isinstance(st, dict) or not ed25519_verify(bytes.fromhex(pub), canonical(st), sig):
            raise ValueError("signature does not verify")
    except (OSError, KeyError, TypeError, AttributeError, RecursionError) as e:
        raise ValueError(type(e).__name__)
    return st, pub


def cmd_log(a):
    import time
    if a.action == "verify":
        entries = read_log(a.log)
        bad = log_problems(entries)
        head = entries[-1]["hash"] if entries and not bad else None
        print(f"{len(entries)} entries; head {head}")
        if a.head and head != a.head.lower():
            bad.append(f"the head is not the published one ({a.head}): the log was truncated, extended or replaced since")
        trusted = read_trusted(a.trusted)
        for cp in a.checkpoint or []:
            try:
                st, pub = load_signed(cp)
                n = st["count"]
                if st.get("format") != CHECKPOINT_FORMAT or isinstance(n, bool) or not isinstance(n, int) or n < 1 or not isinstance(st.get("head"), str):
                    raise ValueError("not a checkpoint")
            except (ValueError, KeyError):
                bad.append(f"{cp}: not a validly signed checkpoint (ignored)")
                continue
            if not entries or bad and head is None:
                continue
            if n > len(entries) or entries[n - 1].get("hash") != st["head"]:
                bad.append(f"{cp}: this log does NOT contain the checkpoint signed by {pub[:16]}... (its entry {n - 1} is not {st['head'][:16]}...): it was truncated, forked or replaced")
            else:
                print(f"checkpoint {cp}: consistent, signed by {pub[:16]}... ({'PINNED' if pub in trusted else 'unvouched'}) at {n} entries")
        print("LOG OK" if not bad else "LOG PROBLEMS:\n  " + "\n  ".join(bad))
        return 1 if bad else 0
    if a.action == "checkpoint":
        if not (a.key and a.out):
            raise SystemExit("log checkpoint needs --key KEYFILE and --out FILE")
        entries = read_log(a.log)
        bad = log_problems(entries)
        if bad or not entries:
            raise SystemExit("refusing to checkpoint a log that is empty or does not verify: " + "; ".join(bad))
        write_attestation(a.out, {"format": CHECKPOINT_FORMAT, "head": entries[-1]["hash"], "count": len(entries), "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
                          read_key(a.key))
        print(f"checkpoint at {len(entries)} entries, head {entries[-1]['hash']}")
        return 0
    try:
        file_sha = sha256_file(a.file)
    except OSError as e:
        raise SystemExit(f"cannot read {a.file}: {e.strerror}")
    import stat
    try:
        st = os.stat(a.log)
    except FileNotFoundError:
        st = None
    except OSError as e:
        raise SystemExit(f"cannot open {a.log}: {e.strerror}")
    if st is not None and not stat.S_ISREG(st.st_mode):
        raise FileRefused(f"{a.log} is not a regular file (a FIFO, device or directory cannot be a log)")
    try:
        f = open(a.log, "a+", encoding="utf-8")
    except OSError as e:
        raise SystemExit(f"cannot open {a.log}: {e.strerror}")
    with f:
        lock_file(f, True, True)   # held until the entry is on disk: read, verify and write are one step
        f.seek(0)
        text = f.read(LIMIT_LOG + 1)
        if len(text) > LIMIT_LOG:
            raise FileRefused(f"{a.log} is over the {LIMIT_LOG} byte limit for a log")
        entries = parse_log(text, a.log)
        bad = log_problems(entries)
        if bad:
            raise SystemExit("refusing to extend a log that does not verify: " + "; ".join(bad))
        entry = {"seq": len(entries), "prev": entries[-1]["hash"] if entries else "0" * 64, "kind": a.kind, "file_name": os.path.basename(a.file),
                 "file_sha256": file_sha, "note": a.note or "", "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        entry["hash"] = entry_hash(entry)
        f.seek(0, 2)
        f.write(json.dumps(entry, sort_keys=True) + "\n")
        f.flush()
        os.fsync(f.fileno())
    print(f"appended entry {entry['seq']}; head {entry['hash']} (publish it somewhere the operator cannot edit)")
    return 0


MEASURE_FORMAT = "guldo-bundle-measurement-v1"


def cmd_spread(a):
    """Merge `rerun --save` files made on DIFFERENT machines for the SAME instances and recommend a tolerance from the measured machine-to-machine spread of the
    re-measured speedup, instead of a loose guess. Needs >= 2 distinct machines and >= 3 instances measured on at least two of them (use the same --sample-seed
    everywhere). The recommendation is an estimate from the machines and instances you give it, not a bound."""
    import math
    by_machine, problems, chash, identity = {}, [], None, None
    for path in a.files:
        try:
            rec = json.loads(read_text(path, LIMIT_JSON))
            assert rec["format"] == MEASURE_FORMAT and isinstance(rec["machine_id"], str) and isinstance(rec["instances"], list)
            untrusted = rec.get("untrusted_instances") if isinstance(rec.get("untrusted_instances"), list) else []
            skip = {str(u) for u in untrusted}
            rows = {str(r["id"]): r["remeasured_bits"] for r in rec["instances"] if isinstance(r, dict) and isinstance(r.get("remeasured_bits"), (int, float))
                    and not isinstance(r["remeasured_bits"], bool) and math.isfinite(r["remeasured_bits"]) and str(r["id"]) not in skip}
            ch_sha = rec["challenge_json_sha256"]
            assert isinstance(ch_sha, str)
            who = (rec.get("solver_sha256"), rec.get("seed_commit"))
            assert all(x is None or isinstance(x, str) for x in who)
        except (OSError, ValueError, KeyError, TypeError, AssertionError, AttributeError, RecursionError, OverflowError):
            problems.append(f"{path}: not a measurement file this tool writes (ignored)")
            continue
        if chash is not None and ch_sha != chash:
            problems.append(f"{path}: measured a different challenge bundle (ignored)")
            continue
        if None in who:
            problems.append(f"{path}: does not record which solver and seed it measured (an older tool), so it cannot be confirmed comparable; used anyway")
        elif identity is None:
            identity = who
        elif who != identity:
            problems.append(f"{path}: measured {'a different solver' if who[0] != identity[0] else 'under a different seed (the same instance id is a different instance)'} "
                            "than the files before it (ignored: a spread between different programs or instances is not machine-to-machine spread)")
            continue
        if skip:
            problems.append(f"{path}: {len(skip & {str(r.get('id')) for r in rec['instances'] if isinstance(r, dict)})} instance(s) failed an integrity check there (hidden CPU, a detached "
                            "process or a dead meter) and are left out")
        chash = ch_sha
        by_machine.setdefault(rec["machine_id"], {}).update(rows)
    for p in problems:
        print("note: " + p)
    if len(by_machine) < 2:
        print(f"{len(by_machine)} distinct machine(s): the spread of a machine against itself is not machine-to-machine spread. Run `rerun --sample-seed S --save F` "
              "with the SAME sample seed on at least two different machines and merge the files. The default tolerance stays as it is.")
        return 1
    shared = {}
    for rows in by_machine.values():
        for iid, v in rows.items():
            shared.setdefault(iid, []).append(v)
    shared = {i: v for i, v in shared.items() if len(v) >= 2}
    if len(shared) < 3:
        print(f"only {len(shared)} instance(s) measured on two or more machines (need 3): use the same --sample-seed and a larger -k")
        return 1
    ranges = sorted(max(v) - min(v) for v in shared.values())
    worst = ranges[-1]
    rec_tol = max(1.0, math.ceil(worst * 4) / 4)
    print(f"{len(by_machine)} machines, {len(shared)} shared instances: the re-measured speedup differs between machines by a median {ranges[len(ranges) // 2]:.2f} bit, "
          f"at worst {worst:.2f} bit")
    print(f"recommended --tolerance: {rec_tol} bits (the worst observed range rounded up to a quarter bit, never below 1: single-instance timing noise is not in this number). "
          "An estimate from these machines and instances, not a bound.")
    return 0


def cmd_rerun(a):
    """Re-measure a sample of a claimed result on THIS machine with THIS verifier's own choice of instances. Costs typed into a ladder, or taken from
    another machine's different hardware class, show up as a spread between claimed and re-measured speedup."""
    import math
    import random
    import statistics
    import tempfile
    try:
        import resource  # noqa: F401
    except ImportError:
        raise SystemExit("rerun needs a POSIX system (resource limits)")
    ch = manifest()
    decl = load_decl()
    master = master_from(a)
    cap = ch["ladder"]["budget_seconds"]
    base, claimed = load_costs(a.baseline, master), load_costs(a.claimed, master)
    ids = sorted(set(base) & set(claimed))
    if not ids:
        raise SystemExit("no instance is solved in both ladders: nothing to re-run")
    sample_seed = a.sample_seed or os.urandom(8).hex()
    chosen = random.Random(sample_seed).sample(ids, min(a.k, len(ids)))
    print(f"sample seed {sample_seed} (an independent verifier picks their own; the operator must not know it in advance): {len(chosen)} of {len(ids)} instances")
    ref_path = os.path.join(ROOT, ch["reference"]["file"])
    secret = read_key(a.sign) if a.sign else None
    if a.sign and not a.attest_out:
        raise SystemExit("--sign needs --attest-out FILE")
    for out in (a.attest_out, a.save):   # fail BEFORE minutes of measurement, not after
        if out and os.path.exists(out):
            raise SystemExit(f"{out} exists: this tool never overwrites")
    if a.repeat < 1:
        raise SystemExit("--repeat must be at least 1")
    solver_sha = sha256_file(a.solver)
    scratch = os.path.realpath(tempfile.mkdtemp(prefix="rerun-"))
    import atexit
    import shutil
    atexit.register(shutil.rmtree, scratch, True)
    prefix, why_not = working_sandbox(a.sandbox, [a.seed_file, a.sign], scratch)
    if prefix is None:
        raise SystemExit("no sandbox is available here (needs macOS sandbox-exec or Linux bwrap" + (f"; the tool exists but cannot run: {why_not}" if why_not else "")
                         + "). To run the solver anyway, unsandboxed, as you, pass --sandbox off (only for a solver you have read).")
    print(f"solver {os.path.basename(a.solver)} sha256 {solver_sha[:16]}...; " + ("sandboxed: no network, no writes outside a scratch directory, seed and keys unreadable"
          if prefix else "UNSANDBOXED: the solver runs as you"))
    numeric = sorted(set(((ch.get("requires") or {}).get("third_party")) or []) & NUMERIC_LIBS)
    if a.tolerance is None:
        a.tolerance = NUMERIC_TOLERANCE if numeric else DEFAULT_TOLERANCE
        print(f"tolerance {a.tolerance} bits (the default for " + ("a challenge using a numerical library: the worst Mac-vs-Linux disagreement measured over two numpy domains was 3.4 bits, "
              "so 2 would fail honest claims" if numeric else "pure Python: the worst measured was 0.03 bit") + "; pass --tolerance to change it, or run `spread` on your own machines). "
              "A looser tolerance also lets a larger false claim pass: the attestation records the tolerance used.")
    if numeric:
        print(f"note: this challenge's declaration uses {', '.join(numeric)}. A speedup is a ratio of two costs and for numerical-library work the ratio depends on the machine class "
              "(measured: the same solver was +3.3 bits on an Apple Mac and +0.03 bit on an x86 Linux server, because the matrix multiply ran 46x faster on the Mac; a pure-Python domain agreed to "
              "0.03 bit). The default tolerance suits pure Python. Re-measure on a machine like the claimant's, or run `spread` on both machines and pass its recommended --tolerance.")
    overhead = solver_overhead(os.path.join(scratch, "noop.py"), prefix, scratch)
    rows, invalid, repeat_sd, meter_bad, hidden, left_behind = [], [], [], [], [], []
    scan_skipped = False
    for iid in chosen:
        size, idx = (int(x) for x in iid.split(":"))
        inst = instance(decl, master, size, idx)
        ref_run = run_solver(ref_path, inst["args"], cap, prefix, scratch)
        sol_run = run_solver(a.solver, inst["args"], cap, prefix, scratch)
        rs, ra, rc, rerr = ref_run
        ss, sa, sc, serr = sol_run
        ref_ok = rs == "ran" and safe_verify(decl, inst, ra)
        sol_ok = ss == "ran" and safe_verify(decl, inst, sa)
        if not sol_ok:
            invalid.append(iid)
        if ref_ok and rc < 0.005 and base[iid] >= 0.5:   # the claim says this instance costs seconds; a meter reading ~0 for the reference means it is not seeing the process
            meter_bad.append(iid)
        if ref_ok and hides_cpu(ref_run, rc, limit=REFERENCE_SHARE):
            meter_bad.append(iid)
        if sol_ok and hides_cpu(sol_run, sc, ref=(ref_run, rc) if ref_ok else None):
            hidden.append(iid)
        if getattr(sol_run, "strays", ()):
            left_behind.append(iid)
        if not getattr(sol_run, "scan_ran", True):
            scan_skipped = True
        rc, sc = max(rc - overhead, 1e-3), max(sc - overhead, 1e-3)
        now = math.log2(rc / sc) if ref_ok and sol_ok else None
        was = math.log2(base[iid] / claimed[iid])
        rows.append((iid, was, now, math.log2(rc / base[iid]) if ref_ok else None, rc, sc, ss))
        print(f"  {iid:>8}: claimed {was:+.2f} bits, re-measured {('%+.2f' % now) if now is not None else 'n/a'} "
              f"(reference now {rc:.2f} s, solver now {sc:.2f} s, solver {'valid' if sol_ok else 'INVALID/' + ss})")
        if a.repeat > 1 and ref_ok and sol_ok:   # the same instance again, to measure THIS machine's timing noise instead of guessing it
            reps_r, reps_s = [rc], [sc]
            for _ in range(a.repeat - 1):
                rr = run_solver(ref_path, inst["args"], cap, prefix, scratch)
                rs_ = run_solver(a.solver, inst["args"], cap, prefix, scratch)
                if getattr(rs_, "strays", ()):   # the repeats are held to the same rules as the scored run: a solver must not behave only when it is counted
                    left_behind.append(iid)
                if hides_cpu(rs_, rs_[2], ref=(rr, rr[2])):
                    hidden.append(iid)
                reps_r.append(max(rr[2] - overhead, 1e-3))
                reps_s.append(max(rs_[2] - overhead, 1e-3))
            repeat_sd.append((statistics.pstdev(math.log2(x) for x in reps_r), statistics.pstdev(math.log2(x) for x in reps_s)))
        if ss != "ran" and serr:
            print(f"            solver stderr: {serr}" + ("   <- the sandbox probably blocked something the solver tried to do" if any(w in serr for w in DENIAL_WORDS) else ""))
        if rs != "ran" and rerr:
            print(f"            reference stderr: {rerr}")
    gaps = [abs(was - now) for _, was, now, _, _, _, _ in rows if now is not None]
    machine = [m for _, _, _, m, _, _, _ in rows if m is not None]
    ok = not invalid and not meter_bad and not hidden and not left_behind and bool(gaps) and statistics.median(gaps) <= a.tolerance
    if scan_skipped:
        print("WARNING: `ps` is not available here, so a solver that detaches a process (setsid, stdio closed) could not be detected afterwards. Each run's process group is still killed, "
              "and the Linux bubblewrap sandbox kills everything in its namespace; without a sandbox, install `ps` (procps) or only run solvers you have read.")
    if left_behind:
        print(f"FAIL: on {sorted(set(left_behind))} the solver left a detached process running after it returned (killed). Work done there is not in the measured cost, and it can compete "
              "with later runs or serve them as a hidden helper, so the speedup is not confirmed")
    if hidden:
        try:
            load = os.getloadavg()[0]
            busy = f" This machine's load average is {load:.1f} on {os.cpu_count()} cores: a heavily loaded machine also starves an honest solver of CPU, so if it is busy, re-run when it is idle."
        except (OSError, AttributeError):
            busy = ""
        print(f"FAIL: on {sorted(set(hidden))} the solver ran for over half a second of wall time but its CPU time is far below it (under 60% of the share the reference got on the same instance, or under 30% with no reference to compare): it waits, or its work runs where the CPU meter cannot see it "
              "(on Linux a child the solver forks and never waits for escapes the accounting entirely). The measured cost is not trustworthy, so the speedup is not confirmed." + busy)
    if meter_bad:
        print(f"FAIL: the CPU meter read ~0 for the REFERENCE on {meter_bad}, whose published cost is seconds: the measurement is not valid on this machine/sandbox, so no "
              "claim is confirmed or refuted by it")
    print(f"median |claimed - re-measured| = {statistics.median(gaps):.2f} bits (tolerance {a.tolerance})" if gaps else "no instance could be compared")
    if machine:
        spread = max(machine) - min(machine)
        print(f"this machine vs the baseline ladder's: median {statistics.median(machine):+.2f} bits (hardware), spread {spread:.2f} bits"
              + ("  <- a large spread means the baseline costs are not from one machine's measurements" if spread > a.tolerance else ""))
        if abs(statistics.median(machine)) >= 1.0:
            print(f"NOTE: this machine runs the reference {abs(statistics.median(machine)):.1f} bits {'slower' if statistics.median(machine) > 0 else 'faster'} than the machine the claim was measured on. A speedup is a RATIO "
                  "of two costs, and the ratio only travels between machines of the same kind: measured on a numpy/BLAS domain, a Mac (Apple Accelerate) and an x86 Linux server disagreed by "
                  "3.3 bits on the same solver (the matmul was 46x slower on the server), while a pure-Python domain agreed to 0.03 bit. If this run FAILS on the gap, suspect the machine class "
                  "before the claim: repeat on a machine like the claimant's, or measure the real spread with `rerun --save` on both machines and `spread`.")
    short = [r[0] for r in rows if r[4] < 0.05 or r[5] < 0.05]
    if short:
        print(f"note: {len(short)} instance(s) cost under 50 ms here; timer noise dominates those ratios")
    rep = None
    if repeat_sd:
        rep = {"reference_sd_bits": round(statistics.median(x[0] for x in repeat_sd), 4), "solver_sd_bits": round(statistics.median(x[1] for x in repeat_sd), 4),
               "repeats": a.repeat, "instances": len(repeat_sd)}
        noise = (rep["reference_sd_bits"] ** 2 + rep["solver_sd_bits"] ** 2) ** 0.5
        print(f"timing repeatability on THIS machine over {a.repeat} runs (median sd of log2 cost): reference {rep['reference_sd_bits']} bit, solver {rep['solver_sd_bits']} bit; "
              f"a re-measured speedup then has noise of about {noise:.2f} bit on its own (this is within-machine only: machine-to-machine spread needs `spread`)")
    if invalid:
        print(f"FAIL: the solver's answer is wrong or missing on {invalid}")
    print("RERUN " + ("PASS: the sampled claims reproduce" if ok else "FAIL"))
    if a.save:
        import platform
        mid = hashlib.sha256(f"{platform.platform()}|{platform.processor()}|{platform.node()}".encode()).hexdigest()[:16]   # a hash, never the host name
        saved = {"format": MEASURE_FORMAT, "challenge_json_sha256": sha256_file(os.path.join(ROOT, "challenge.json")), "claimed_sha256": sha256_file(a.claimed),
                 "baseline_sha256": sha256_file(a.baseline), "machine_id": mid, "platform": platform.platform(), "sample_seed": sample_seed, "repeatability": rep,
                 # what `spread` needs to know the files are comparable: the same solver on the same instances (an id like 28:23 names a different instance under another seed),
                 # and which instances failed an integrity check on this machine (their numbers are not measurements of the solver's cost)
                 "solver_sha256": solver_sha, "seed_commit": hashlib.sha256(master).hexdigest(), "rerun_checks": RERUN_CHECKS,
                 "untrusted_instances": sorted(set(hidden + left_behind + meter_bad)),
                 "instances": [{"id": r[0], "claimed_bits": round(r[1], 4), "remeasured_bits": None if r[2] is None else round(r[2], 4),
                                "machine_bits": None if r[3] is None else round(r[3], 4)} for r in rows]}
        with open(a.save, "x", encoding="utf-8") as f:
            json.dump(saved, f, indent=1, sort_keys=True)
        print(f"saved the measurements to {a.save} (merge several machines' files with `spread`)")
    if secret:
        import platform
        import time
        statement = {
            "format": ATTEST_FORMAT, "kind": "rerun",
            "challenge": {"name": ch["name"], "version": ch["version"], "challenge_json_sha256": sha256_file(os.path.join(ROOT, "challenge.json"))},
            "solver_sha256": solver_sha, "claimed_sha256": sha256_file(a.claimed), "baseline_sha256": sha256_file(a.baseline),
            "seed_commit": hashlib.sha256(master).hexdigest(), "sample_seed": sample_seed, "k": len(chosen), "tolerance_bits": a.tolerance,
            "sandboxed": bool(prefix), "rerun_checks": RERUN_CHECKS, "process_scan": not scan_skipped, "outcome": "PASS" if ok else "FAIL",
            "median_gap_bits": round(statistics.median(gaps), 3) if gaps else None, "repeatability": rep,
            "instances": [{"id": r[0], "claimed_bits": round(r[1], 3), "remeasured_bits": None if r[2] is None else round(r[2], 3), "solver_status": r[6]} for r in rows],
            "machine": {"platform": platform.platform(), "python": platform.python_version(), "processor": platform.processor() or platform.machine()},
            "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        write_attestation(a.attest_out, statement, secret)
    return 0 if ok else 1


def reexec_sandboxed(argv, script=None):
    """Run this same command again inside the OS sandbox (no network, no writes outside a scratch directory, ~/.ssh and friends unreadable). The declaration and
    the reference are the bundle AUTHOR's code and `selftest`/`derive`/`verify` import and run them. -> the child's exit code, or None to run here."""
    if os.environ.get("GULDO_BUNDLE_SANDBOXED") == "1":
        return None
    import shutil
    import subprocess
    import tempfile
    scratch = os.path.realpath(tempfile.mkdtemp(prefix="check-"))
    try:
        prefix, reason = sandbox_prefix("auto", [], scratch), ""
        if prefix is not None:
            # No separate probe on the hot path (a verification spawn added 50 ms to EVERY call, measured): run the real command, and only if the SANDBOX TOOL itself
            # failed to start (its own error line: `bwrap: ...`, `sandbox-exec: ...`) diagnose it as unavailable. stdout streams; stderr is held to inspect and re-emitted.
            env = dict(os.environ, GULDO_BUNDLE_SANDBOXED="1", TMPDIR=scratch)
            r = subprocess.run(prefix + [sys.executable, "-I", "-B", script or os.path.abspath(__file__)] + list(argv), env=env, stderr=subprocess.PIPE, text=True)
            err = r.stderr or ""
            first = next((ln for ln in err.splitlines() if ln.strip()), "")
            if r.returncode != 0 and (first.startswith(TOOL_ERRORS) or "sandbox_apply" in err):
                prefix, reason = None, f" (the tool exists but cannot run: {first[:200]})"
            else:
                if err:
                    sys.stderr.write(err)
                return r.returncode
        if os.environ.get("GULDO_REQUIRE_SANDBOX") == "1":
            raise SystemExit("no OS sandbox is available here (macOS sandbox-exec or Linux bwrap)" + reason + " and one was required")
        print("warning: no OS sandbox is available here" + reason + ": the declaration and reference run unsandboxed, as you (pass --sandbox off to silence this)", file=sys.stderr)
        return None
    finally:
        shutil.rmtree(scratch, ignore_errors=True)


def cmd_selftest(a):
    ch = manifest()
    results = []

    def check(name, ok, detail=""):
        results.append((name, ok, detail))
        print(("PASS  " if ok else "FAIL  ") + name + (f": {detail}" if detail else ""))

    problems = file_problems(ch)
    check("pinned files intact", not problems, "; ".join(problems))
    if problems:
        return 1
    try:
        decl = load_decl()
    except Exception as e:   # the author's code, run on import: whatever it does, say so instead of a traceback
        denied = isinstance(e, OSError) and e.errno in (1, 13, 30)   # EPERM, EACCES, EROFS: macOS sandbox-exec says EPERM, bubblewrap's read-only root says EROFS
        check("the declaration imports", False, f"{type(e).__name__}: {str(e)[:150]}" + ("  <- blocked by the sandbox?" if denied else ""))
        return 1
    check("declaration matches the manifest", decl.NAME == ch["name"] and decl.VERSION == ch["version"], f"{decl.NAME} {decl.VERSION}")
    try:
        ref = load_reference(ch)
    except Exception as e:
        check("the reference imports", False, f"{type(e).__name__}: {str(e)[:150]}")
        return 1
    check("reference has solve()", callable(getattr(ref, "solve", None)))
    sizes = ch["ladder"]["practice_dims"]
    fresh = bytes.fromhex(a.fresh_seed) if a.fresh_seed else os.urandom(16)
    print(f"fresh seed for this run (reproduce with --fresh-seed): {fresh.hex()}")
    for label, master in (("practice", PRACTICE_SEED), ("fresh", fresh)):
        for size in sizes:
            instance_checks(decl, ref, master, label, size, check)
            if ch.get("metric") == "quality":
                quality_checks(decl, ref, master, label, size, check)
            else:
                answer_space_checks(decl, master, label, size, check)
    cross_seed_checks(decl, fresh, sizes, check)
    other = instance(decl, b"another-seed", sizes[0], 0)
    base = instance(decl, PRACTICE_SEED, sizes[0], 0)
    check("a different seed gives a different instance", json.dumps(other["args"]) != json.dumps(base["args"]))
    failed = [n for n, ok, _ in results if not ok]
    print(f"{len(results) - len(failed)} passed, {len(failed)} failed")
    return 1 if failed else 0


def witness_of(decl, inst):
    return decl.witness(inst) if hasattr(decl, "witness") else inst["planted"]


def cross_seed_checks(decl, fresh, sizes, check):
    """Instances must DEPEND ON THE SEED at every size and index, or the commitment commits to nothing and a table of old answers works for ever. Compared at
    the SAME index: that is where a seed-ignoring derive() shows (6 of 6 identical), whereas a witness-acceptance rate over all pairs diluted it to 6 of 36
    (found by mutation testing). Different-index pairs carry no extra information: statistically they are the within-seed reuse check."""
    for size in sizes:
        same = sum(json.dumps(instance(decl, PRACTICE_SEED, size, i)["args"], sort_keys=True) == json.dumps(instance(decl, fresh, size, i)["args"], sort_keys=True)
                   for i in range(6))
        check(f"size {size}: instances differ between seeds", same <= 2, f"{same} of 6 identical across two seeds")
        if same:
            print(f"WARN  size {size}: {same} of 6 instances are identical across two different seeds (a small instance space at this size; fine if few)")


def instance_checks(decl, ref, master, label, size, check):
    for idx in (0, 1):
        tag = f"{label} size {size} idx {idx}"
        inst = instance(decl, master, size, idx)
        again = instance(decl, master, size, idx)
        check(f"{tag}: deterministic", json.dumps(inst["args"], sort_keys=True) == json.dumps(again["args"], sort_keys=True))
        bad = args_problem(inst)
        check(f"{tag}: args are a JSON list under 1 MiB", bad is None, bad or "")
        if bad:
            continue
        check(f"{tag}: the planted witness verifies", safe_verify(decl, inst, witness_of(decl, inst)))
        accepted = [repr(j)[:20] for j in JUNK if safe_verify(decl, inst, j)]
        check(f"{tag}: junk answers rejected", not accepted, ("accepted: " + ", ".join(accepted)) if accepted else "")
        try:
            got = ref.solve(*json.loads(json.dumps(inst["args"])))
        except Exception as e:
            check(f"{tag}: reference solves", False, f"{type(e).__name__}: {e}")
            continue
        check(f"{tag}: reference solves", safe_verify(decl, inst, got))


def leaves(x, depth=0):
    if depth > 6:
        return
    if isinstance(x, dict):
        for v in x.values():
            yield from leaves(v, depth + 1)
    elif isinstance(x, (list, tuple)):
        for v in x:
            yield from leaves(v, depth + 1)
    else:
        yield x


def trivial_candidates(inst):
    """Answers a solver could write down without searching: the arguments, their reverse, every integer in them and its neighbours."""
    ints = [v for v in leaves(inst["args"]) if isinstance(v, int) and not isinstance(v, bool)][:64]
    return [inst["args"], list(inst["args"])[::-1]] + ints + [v + d for v in ints[:8] for d in (-1, 1)]


def mutants(w):
    """Near-misses of a witness. Not all are wrong (a factor's cofactor may be valid), so these are evidence about the answer space, not a verdict each."""
    out = []
    if isinstance(w, bool):
        return out
    if isinstance(w, int):
        out = [w + 1, w - 1, w + 2, w - 2, -w, w * 2, w // 2, w ^ 1, 0, 1]
    elif isinstance(w, str):
        out = [w[:-1], w + "0", w[::-1]]
    elif isinstance(w, (list, tuple)):
        items = list(w)
        out = [items[:-1], items[1:], items + [0], items[::-1], [0] * len(items)]
        for k in range(min(len(items), 16)):
            out += [items[:k] + [m] + items[k + 1:] for m in mutants(items[k])[:4]]
    seen, uniq = set(), []
    for m in out:
        key = json.dumps(m, sort_keys=True)
        if m != w and key not in seen:
            seen.add(key)
            uniq.append(m)
    return uniq


def map_ints(w, f):
    if isinstance(w, bool):
        return w
    if isinstance(w, int):
        return f(w)
    if isinstance(w, (list, tuple)):
        return [map_ints(x, f) for x in w]
    return w


def heavy_mutants(w):
    """The witness with EVERY integer in it damaged at once. A verifier with a tolerance may accept one wrong part; it must not accept all parts wrong: if
    it does, anything of the right shape verifies."""
    if isinstance(w, bool) or not isinstance(w, (int, list, tuple)):
        return []
    out = [map_ints(w, f) for f in (lambda x: x + 1, lambda x: x - 1, lambda x: -x - 1, lambda x: x ^ 1, lambda x: 0, lambda x: x + 7)]
    seen, uniq = set(), []
    for m in out:
        key = json.dumps(m, sort_keys=True)
        if m != w and key not in seen:
            seen.add(key)
            uniq.append(m)
    return uniq


def random_like(w, rng):
    """A random answer with the witness's type, length and magnitude. Whatever the verifier accepts of these, it accepts without anyone solving anything."""
    if isinstance(w, bool):
        return rng.random() < 0.5
    if isinstance(w, int):
        b = max(1, abs(w).bit_length())
        return rng.randrange(-(1 << b), (1 << b) + 1)
    if isinstance(w, float):
        return rng.uniform(-abs(w) - 1, abs(w) + 1)
    if isinstance(w, (list, tuple)):
        return [random_like(x, rng) for x in w]
    if isinstance(w, str):
        return "".join(chr(rng.randrange(32, 127)) for _ in w)
    return w


def answer_space_checks(decl, master, label, size, check):
    """What the fixed junk list cannot show: answers DERIVED FROM THE INSTANCE ITSELF. If the arguments, another instance's witness (a lookup table
    of past answers), or a slightly damaged witness verifies, the answer space is small or leaks, whatever the junk list says. Run on a seed the
    declaration's author has never seen (the fresh one), so a verifier cannot be tuned to the public practice seed."""
    insts = [instance(decl, master, size, i) for i in range(6)]   # 30 ordered pairs for the reuse rate: few enough pairs and a tiny answer space makes chance hits common
    tag = f"{label} size {size}"
    hit = next((str(c)[:50] for x in insts[:3] for c in trivial_candidates(x) if safe_verify(decl, x, c)), None)
    check(f"{tag}: no answer can be read off the arguments", hit is None, f"verify() accepts {hit!r} without any search" if hit else "")
    ws = [witness_of(decl, x) for x in insts]
    pairs = [(j, i) for i in range(len(insts)) for j in range(len(insts)) if i != j]
    reused = sum(bool(safe_verify(decl, insts[i], ws[j])) for j, i in pairs)
    # FAIL above 50%, warn above 25%: measured on a sound toy domain at size 20 (10-bit primes, so instances often share a factor and hits CLUSTER), 2 seeds in
    # 3000 reach 8 of 30 pairs, so a 25% hard limit failed ~0.07% of random seeds. A real lookup table accepts nearly everything.
    check(f"{tag}: another instance's witness is not accepted (no lookup table)", reused / len(pairs) <= 0.5, f"{reused} of {len(pairs)} accepted")
    if reused / len(pairs) > 0.25:
        print(f"WARN  {tag}: {reused} of {len(pairs)} other instances' witnesses accepted: a small answer space at this size")
    htot = hacc = tot = acc = 0
    for x, w in zip(insts, ws):
        for m in heavy_mutants(w):
            htot += 1
            hacc += bool(safe_verify(decl, x, m))
        for m in mutants(w):
            tot += 1
            acc += bool(safe_verify(decl, x, m))
    check(f"{tag}: a witness with EVERY part damaged is mostly rejected", htot == 0 or hacc / htot <= 0.5, f"{hacc} of {htot} accepted")
    rng = random.Random(int.from_bytes(hashlib.sha256(master + b":fuzz:%d" % size).digest()[:8], "big"))
    ftot = facc = 0
    for x, w in zip(insts, ws):
        for _ in range(100):
            ftot += 1
            facc += bool(safe_verify(decl, x, random_like(w, rng)))
    check(f"{tag}: random answers of the witness's shape are mostly rejected", facc / ftot <= 0.5, f"{facc} of {ftot} accepted")
    if facc:
        print(f"WARN  {tag}: {facc} of {ftot} random answers of the witness's shape verified: the answer space is dense, so little work separates a solver from a guess")
    if reused or acc:
        print(f"WARN  {tag}: {reused} reused witnesses and {acc} of {tot} single-part damaged witnesses accepted; expected when the verifier has a tolerance "
              "or the problem has many valid answers, a smell if it should not")


QUALITY_TRIVIAL = 0.9   # QUALITY challenges: an answer that needs no search (derived from the arguments, another instance's witness, a random guess) must not score above this


def value_like(w, rng):
    """A random answer built from the witness's own scalar values: a list of bits becomes a random list of bits. (random_like draws from a symmetric range of the witness's magnitude,
    which is almost never a valid bit vector, so on its own it would let a constant-top-score quality() pass.)"""
    if isinstance(w, (list, tuple)):
        pool = [v for v in leaves(w)]
        return [value_like(x, rng) if isinstance(x, (list, tuple)) else rng.choice(pool) for x in w] if pool else list(w)
    return random_like(w, rng)


def shuffled(w, rng):
    """A random rearrangement of the witness (a random permutation, for a problem whose answers are permutations)."""
    if isinstance(w, (list, tuple)):
        out = list(w)
        rng.shuffle(out)
        return out
    return random_like(w, rng)


def quality_of(decl, inst, ans):
    """-> (valid, quality): quality is None unless verify() accepted the answer. A quality() that raises, or returns anything but a finite number in [0, 1], on a VERIFIED
    answer is the declaration's bug: ValueError, never a score."""
    import math
    if not safe_verify(decl, inst, ans):
        return False, None
    try:
        q = decl.quality(inst, ans)
    except Exception as e:
        raise ValueError(f"quality() raised {type(e).__name__}: {str(e)[:100]} on an answer verify() accepted")
    if isinstance(q, bool) or not isinstance(q, (int, float)) or not math.isfinite(q) or not 0.0 <= q <= 1.0:
        raise ValueError(f"quality() returned {str(q)[:30]!r}, not a finite number in [0, 1]")
    return True, float(q)


def quality_checks(decl, ref, master, label, size, check):
    """The quality challenge's counterpart of answer_space_checks. The valid answer space is LARGE here (any feasible solution is valid), so what must hold is not
    'junk is rejected' but 'quality() is well-defined, and no answer that needs no search scores high'. Answers derived from the planted witness (a damaged
    witness, its complement) are not no-search answers: a solver is never handed the witness, so those only have to score in range."""
    insts = [instance(decl, master, size, i) for i in range(6)]
    tag = f"{label} size {size}"
    problems = []

    def q(x, ans, what):
        try:
            return quality_of(decl, x, ans)[1]
        except ValueError as e:
            problems.append(f"{what}: {e}")
            return None
    ws = [witness_of(decl, x) for x in insts]
    first = [q(x, w, "planted witness") for x, w in zip(insts, ws)]
    check(f"{tag}: the planted witness scores a number in [0, 1]", not problems and all(v is not None for v in first), "; ".join(problems[:2]))
    again = [q(x, w, "planted witness") for x, w in zip(insts, ws)]
    check(f"{tag}: quality() is deterministic", first == again, f"{first[:3]} then {again[:3]}")
    got = []
    for x in insts[:3]:
        try:
            got.append(q(x, ref.solve(*json.loads(json.dumps(x["args"]))), "reference answer"))
        except Exception as e:
            problems.append(f"reference raised {type(e).__name__}: {e}")
    check(f"{tag}: the reference's answers score a number in [0, 1]", len(got) == 3 and all(v is not None for v in got), "; ".join(problems[:2]))
    nosearch = [(x, c) for x in insts[:3] for c in trivial_candidates(x)] + [(insts[i], ws[j]) for i in range(len(insts)) for j in range(len(insts)) if i != j]
    high = [str(c)[:40] for x, c in nosearch if (q(x, c, "no-search answer") or 0.0) > QUALITY_TRIVIAL]
    check(f"{tag}: no answer that needs no search scores above {QUALITY_TRIVIAL}", not high, f"{len(high)} did, e.g. {high[0]!r}" if high else "")
    rng = random.Random(int.from_bytes(hashlib.sha256(master + b":qfuzz:%d" % size).digest()[:8], "big"))
    tot = top = 0
    for x, w in zip(insts, ws):
        for k in range(100):
            tot += 1
            # three kinds of guess: random_like (random numbers of the witness's magnitude: almost never valid for a bit vector or a permutation, so it only tests dense answer spaces),
            # a random answer built from the witness's OWN values (a random bit vector), and a shuffle of the witness (a random permutation)
            guess = (random_like, value_like, shuffled)[k % 3](w, rng)
            top += (q(x, guess, "random answer") or 0.0) > QUALITY_TRIVIAL
    check(f"{tag}: random answers of the witness's shape rarely score above {QUALITY_TRIVIAL}", top / tot <= 0.05, f"{top} of {tot}")
    for x, w in zip(insts, ws):
        for m in mutants(w) + heavy_mutants(w):
            q(x, m, "damaged witness")
    check(f"{tag}: quality() is defined on every accepted damaged witness", not problems, "; ".join(problems[:2]))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("info")
    sandbox_help = ("auto (default): run inside an OS sandbox (no network, no writes outside a scratch directory) because this imports and runs the bundle's decl.py and "
                    "reference, which are its author's code; off: run as you")
    p = sub.add_parser("selftest")
    p.add_argument("--fresh-seed", metavar="HEX", type=hex_arg, help="hex of the fresh seed to use (default: random each run, printed so a failure can be reproduced)")
    p.add_argument("--sandbox", choices=["auto", "off"], default="auto", help=sandbox_help)
    p = sub.add_parser("rerun")
    p.add_argument("--seed-file")
    p.add_argument("--practice", action="store_true")
    p.add_argument("--solver", required=True, help="the solver file whose claimed ladder is being checked (it is EXECUTED here, in an OS sandbox unless --sandbox off)")
    p.add_argument("--claimed", required=True, help="the claimed ladder of that solver")
    p.add_argument("--baseline", required=True, help="the claimed ladder of the reference on the same seed")
    p.add_argument("-k", type=int_arg(1, 1000), default=5, help="instances to re-run (1..1000, default 5)")
    p.add_argument("--sample-seed", help="fix the sample (default: random, printed)")
    p.add_argument("--tolerance", type=float_arg(0, 1000), default=None, help="bits the median claimed-vs-re-measured gap may reach (default 2 for pure Python, 3.5 when the challenge uses a "
                   "numerical library: measured Mac-vs-Linux spread was 0.03 bit for pure Python and up to 3.4 bits for numpy; `spread` measures it for your machines)")
    p.add_argument("--sandbox", choices=["auto", "off"], default="auto", help="auto (default): run solver and reference without network, without writes outside a scratch "
                   "directory and without reading the seed or keys, or refuse if the system has no sandbox; off: run them as you")
    p.add_argument("--sign", metavar="KEYFILE", help="sign the outcome as an attestation (see keygen); needs --attest-out")
    p.add_argument("--attest-out", metavar="FILE")
    p.add_argument("--repeat", type=int_arg(1, 50), default=1, help="run each sampled instance N times (1..50) and report this machine's own timing repeatability (default 1: not measured)")
    p.add_argument("--save", metavar="FILE", help="write the per-instance measurements (machine id is a hash) so several machines' runs can be merged with `spread`")
    p = sub.add_parser("spread", help="merge `rerun --save` files from different machines and recommend a tolerance from their measured spread")
    p.add_argument("files", nargs="+")
    p = sub.add_parser("keygen", help="make an Ed25519 signing key for attestations (never overwrites)")
    p.add_argument("--out", required=True)
    p = sub.add_parser("attest-check", help="verify signed rerun attestations; only keys listed in --trusted count as vouched")
    p.add_argument("files", nargs="+")
    p.add_argument("--trusted", help="file of public keys (hex, one per line) you obtained out of band")
    p.add_argument("--min", type=int, default=1, help="distinct pinned keys that must attest PASS (default 1)")
    p.add_argument("--claimed", help="also require the attestations to name THIS claimed ladder")
    p.add_argument("--baseline", help="also require the attestations to name THIS baseline ladder")
    p.add_argument("--max-tolerance", type=float_arg(0, 1000), default=None, help="a rerun PASS made at a looser tolerance than this many bits (or with none recorded) does not count; "
                   "numerical-library challenges default to 3.5 bits, pure Python to 2 (a valid FAIL still counts)")
    p.add_argument("--strict", action="store_true", help="a PASS made unsandboxed, by an older tool without the CPU-hiding checks, or without the detached-process scan does not count "
                   "(a valid FAIL still does: dissent is never ignored)")
    p = sub.add_parser("log", help="an append-only, hash-chained log of files (submissions, results, attestations); signed checkpoints catch truncation")
    p.add_argument("action", choices=["append", "verify", "checkpoint"])
    p.add_argument("log")
    p.add_argument("--file", help="append: the file to record")
    p.add_argument("--kind", default="submission", help="append: what it is")
    p.add_argument("--note")
    p.add_argument("--head", help="verify: the head hash you were told, so a truncated log is caught")
    p.add_argument("--key", help="checkpoint: your signing key (see keygen)")
    p.add_argument("--out", help="checkpoint: where to write the signed (head, count) statement")
    p.add_argument("--checkpoint", action="append", help="verify: a signed checkpoint the log must contain (repeatable)")
    p.add_argument("--trusted", help="verify: file of public keys you pinned; says which checkpoint signers are vouched")
    for name in ("commit", "derive", "verify"):
        p = sub.add_parser(name)
        p.add_argument("--seed-file")
        p.add_argument("--practice", action="store_true")
        if name != "commit":
            p.add_argument("--size", type=int_arg(-10 ** 12, 10 ** 12), required=True)   # parsed here, checked against the challenge's declared range in the command
            p.add_argument("--idx", type=int_arg(-10 ** 12, 10 ** 12), required=True)
            p.add_argument("--sandbox", choices=["auto", "off"], default="auto", help=sandbox_help)
        if name == "verify":
            p.add_argument("--answer", required=True)
    a = ap.parse_args(argv)
    if a.cmd in ("selftest", "derive", "verify") and a.sandbox == "auto":
        code = reexec_sandboxed(argv if argv is not None else sys.argv[1:])
        if code is not None:
            return code
    if a.cmd == "log" and a.action == "append" and not a.file:
        raise SystemExit("log append needs --file")
    if a.cmd in ("rerun", "spread") and manifest().get("metric") == "quality":
        raise SystemExit(f"this bundle is a QUALITY challenge: `{a.cmd}` re-measures speed. Use qcheck.py qrerun")
    try:
        return {"info": cmd_info, "selftest": cmd_selftest, "commit": cmd_commit, "derive": cmd_derive, "verify": cmd_verify, "rerun": cmd_rerun,
                "keygen": cmd_keygen, "attest-check": cmd_attest_check, "log": cmd_log, "spread": cmd_spread}[a.cmd](a)
    except FileRefused as e:   # a path that is not a regular file of sane size: one line, exit 1
        print(f"REFUSED: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
