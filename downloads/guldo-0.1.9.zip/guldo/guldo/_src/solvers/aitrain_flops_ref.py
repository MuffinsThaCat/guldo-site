"""aitrain in the counted-operations API, REFERENCE: plain full-batch gradient descent, learning rate 2.0, 12000 steps, no feature scaling, no momentum."""
import math

import tensorops as tp

K = 3
KAPPA = 30.0
STEPS = 12000
LR = 2.0


def solve(seed, d, n, labels):
    sc = tp.tensor([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = tp.reshape(tp.stream(seed, 0, n * d), (n, d)) * sc
    Y = tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(n)])
    Xt = tp.transpose(X, (1, 0))
    W = tp.zeros((d, K))
    for step in range(STEPS):
        Z = X @ W
        E = tp.exp(Z - tp.max(Z, 1, True))
        W = W - (Xt @ (E / tp.sum(E, 1, True) - Y)) * (LR / n)
    return [int(x * 1048576.0) for x in tp.reshape(W, (d * K,)).tolist()]
