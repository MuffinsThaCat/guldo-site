"""Declaration of a distillation domain: answer a LARGE batch of queries with a committed teacher ensemble's outputs, as cheaply as you can, at equivalent output, by learning a cheaper student from the teacher.

size = d, the input dimension. The teacher is an ENSEMBLE of E = 4 two-layer ReLU networks with H = 4 d hidden units each and 10 classes: member e has W1 (H x d, scaled by sqrt(3/d)), a bias b = 1 + u per hidden
unit and W2 (10 x H, scaled by sqrt(3/H) / E); the teacher's logits are the SUM over the members of W2 relu(W1 x + b). The batch holds Q = 48 d inputs. All of it is a pure function of one 63-bit seed through the pinned
SplitMix64 stream that `aiinfer` and `aitrain` use (u in [-1, 1)): for e = 0 .. 3 in turn, W1 = the next H d floats (H x d), b = the next H floats plus one, W2 = the next 10 H floats (10 x H); then X = the next Q d floats
(Q x d, row-major). The biases are positive, so most units are active and the ensemble is close to, but not exactly, linear in its input: a much smaller model can reproduce its decisions.

The answer is the list of Q class labels (ints 0-9). The judge recomputes the teacher's float64 logits and accepts an answer in which every label is within 0.2 standard deviations (of all the instance's logits) of the
teacher's best logit for that sample, for at least 96% of the samples. That is the "equivalent result" the saving is conditional on: a student trained on too few teacher outputs, or a constant answer, fails the check.

DISTILLATION. Running the whole teacher on all Q queries is the reference. A student (here free to be any cheaper model: a linear map fitted by least squares to the teacher's logits, the textbook small case) is
trained on the teacher's outputs for a SMALL subset of the queries, then answers every query. The saving is the amortisation of the teacher's cost: it is paid on a few queries instead of on all of them, so it
grows with Q / (the training subset), and it can be negative when the batch is small. The solver pays for everything it does: running the teacher on the subset, fitting the student, running the student.
A cheaper way of reproducing the teacher that does not learn from it (merging the layers by algebra) is also allowed: it works on average and is not guaranteed to pass (solvers/aidistill_flops_merge.py).

The cost is counted operations (tflops.py): the arithmetic asked for, exactly reproducible, not a time; it cannot see memory traffic, kernel quality or device speed.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aidistill"
VERSION = "aidistill-v1"      # bump whenever derive() or the model definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (32, 80)
SIZE_STEP = 16
REFERENCE_SOLVER = "reference.py"
CLASSES = 10
MEMBERS = 4
TOL_SIGMA = 0.2               # a label is acceptable if the teacher's logit for it >= its max logit - TOL_SIGMA * std(all teacher logits of the instance)
MAX_BAD_FRACTION = 0.04       # at most floor(0.04 * Q) labels may be unacceptable
DOC = ("solve(seed, d, Q): regenerate the teacher and the batch from `seed` with the SplitMix64 stream (tensorops.stream; u in [-1, 1)): H = 4d; for each of 4 members in turn, W1 = the next H*d floats as H x d "
       "times sqrt(3/d), b = the next H floats plus 1, W2 = the next 10*H floats as 10 x H times sqrt(3/H)/4; then X = the next Q*d floats as Q x d, Q = 48d. The teacher's logits are the sum over members of "
       "W2 relu(W1 x + b). Return the list of Q class labels (ints 0-9). A label counts if the teacher's logit for it is within 0.2 standard deviations of the teacher's best logit for that sample; "
       "at least 96% of labels must count. Return None for no answer.")
REFERENCE_NOTE = ("The whole teacher on the whole batch: for each of the 4 members, one batched product per layer on all Q inputs (float64). Known to be beaten by distillation: run the teacher on only "
                  "a few queries and fit a cheaper student to its outputs.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def teacher(seed, d):
    H, Q, o, members = 4 * d, 48 * d, 0, []
    for _ in range(MEMBERS):
        W1 = _uniform(seed, o, H * d).reshape(H, d) * math.sqrt(3.0 / d)
        o += H * d
        b = _uniform(seed, o, H) + 1.0
        o += H
        W2 = _uniform(seed, o, CLASSES * H).reshape(CLASSES, H) * math.sqrt(3.0 / H) / MEMBERS
        o += CLASSES * H
        members.append((W1, b, W2))
    return members, _uniform(seed, o, Q * d).reshape(Q, d)


def logits(seed, d):
    members, X = teacher(seed, d)
    return sum(np.maximum(X @ W1.T + b, 0.0) @ W2.T for W1, b, W2 in members)


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aidistill-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, 48 * size], "planted": [int(v) for v in np.argmax(logits(seed, size), axis=1)]}


def verify(inst: dict, ans) -> bool:
    seed, d, Q = inst["args"]
    if not isinstance(ans, list) or len(ans) != Q:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or not 0 <= v < CLASSES for v in ans):
        return False
    L = logits(seed, d)
    ok = L[np.arange(Q), np.asarray(ans)] >= L.max(axis=1) - TOL_SIGMA * L.std()
    return bool(int((~ok).sum()) <= int(MAX_BAD_FRACTION * Q))
