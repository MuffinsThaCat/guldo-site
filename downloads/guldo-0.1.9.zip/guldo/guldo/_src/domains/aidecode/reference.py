"""Reference for aidecode: recompute the whole sequence for every generated token (no KV cache), float64.

The model definition (the contract a submission must reproduce): SplitMix64 counter stream under `seed` (element k = finalise((k+1)*GOLD + seed), mapped to
[-1, 1) as (z >> 11) * 2^-52 - 1). Stream layout, in order: tok (64x128, scale sqrt(3)); for each of 2 layers Wq, Wk, Wv, Wo (128x128), W1 (128x512), W2 (512x128)
(scale W_SCALE*sqrt(3/fan_in), W_SCALE = 4); pos ((8+T)x128, scale POS_SCALE*sqrt(3), POS_SCALE = 3); then 8 prompt tokens floor((u+1)/2*64). Network on a
sequence: x = tok[t] + pos[i]; per layer: h = rms(x); causal 4-head attention softmax(q.k/sqrt(32)) v, x += o Wo; x += relu(rms(x) W1) W2; logits =
rms(x) tok^T with rms(x) = x / sqrt(mean(x^2) + 1e-6). Generation is greedy (lowest index on exact ties).
"""
import math

import numpy as np

V, D, H, DH, FF, L, PROMPT = 64, 128, 4, 32, 512, 2, 8
W_SCALE, POS_SCALE = 4.0, 3.0
_GOLD = 0x9E3779B97F4A7C15
_C1 = 0xBF58476D1CE4E5B9
_C2 = 0x94D049BB133111EB


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _params(seed, T):
    o = [0]

    def take(shape, scale):
        n = int(np.prod(shape))
        a = (_uniform(seed, o[0], n) * scale).reshape(shape)
        o[0] += n
        return a
    sd, sf = W_SCALE * math.sqrt(3.0 / D), W_SCALE * math.sqrt(3.0 / FF)
    P = {"tok": take((V, D), math.sqrt(3.0)), "layers": []}
    for _ in range(L):
        P["layers"].append({"Wq": take((D, D), sd), "Wk": take((D, D), sd), "Wv": take((D, D), sd), "Wo": take((D, D), sd),
                            "W1": take((D, FF), sd), "W2": take((FF, D), sf)})
    P["pos"] = take((PROMPT + T, D), POS_SCALE * math.sqrt(3.0))
    P["prompt"] = np.minimum(((_uniform(seed, o[0], PROMPT) + 1.0) * 0.5 * V).astype(np.int64), V - 1)
    return P


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def _forward_last(P, toks):
    n = len(toks)
    x = P["tok"][toks] + P["pos"][:n]
    mask = np.triu(np.full((n, n), -1e30), 1)
    for l in P["layers"]:
        h = _rms(x)
        q, k, v = [(h @ l[w]).reshape(n, H, DH).transpose(1, 0, 2) for w in ("Wq", "Wk", "Wv")]
        s = q @ k.transpose(0, 2, 1) / math.sqrt(DH) + mask
        s -= s.max(-1, keepdims=True)
        a = np.exp(s)
        a /= a.sum(-1, keepdims=True)
        x = x + (a @ v).transpose(1, 0, 2).reshape(n, D) @ l["Wo"]
        x = x + np.maximum(_rms(x) @ l["W1"], 0.0) @ l["W2"]
    return _rms(x[-1]) @ P["tok"].T


def solve(seed, prompt_len, T):
    P = _params(seed, T)
    seq = [int(t) for t in P["prompt"]]
    for _ in range(T):
        seq.append(int(np.argmax(_forward_last(P, np.asarray(seq)))))
    return seq[PROMPT:]
