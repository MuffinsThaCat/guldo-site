"""The `guldo` command: the client, and `guldo <tool>` for the other tools. See `guldo tools`."""
import importlib
import inspect
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "_src")
TOOLS = {
    "claims": ("claims", "benchmark score, worst case, verified negative result from a verified certificate; `claims check` recomputes a claim file"),
    "counted": ("counted", "step counting: `counted check SOLVER --family F --dim D` (is it deterministic and inside the restricted subset?), `counted evaluate`"),
    "attest": ("attest", "sign and check independent attestations of a certificate"),
    "cert": ("certificate", "build and verify certificates (the standalone verifier). Not `guldo certificate`: that is the client's own command, which downloads one"),
    "compile": ("compile_domain", "declare a new problem and compile it into a challenge"),
    "ops": ("ops", "operator tools: create, close, evaluate, reveal, export rounds"),
    "lint": ("submit_check", "pre-flight check of a solver file"),
    "judge": ("judge", "the judge (seeds, evaluate, leaderboard)"),
}


def _version():
    try:
        from importlib.metadata import version
        return version("guldo")
    except Exception:
        return "unknown"


def _call(module, rest, prog):
    fn = importlib.import_module(module).main
    sys.argv = [prog] + rest
    try:
        takes_argv = bool(inspect.signature(fn).parameters)
    except (TypeError, ValueError):
        takes_argv = False
    return fn(rest) if takes_argv else fn()


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if SRC not in sys.path:
        sys.path.insert(0, SRC)   # our modules first: a flat name like `judge` or `harness` must never resolve to something else installed
    if argv[:1] in (["--version"], ["-V"]):
        print(f"guldo {_version()}")
        return 0
    if argv[:1] == ["tools"]:
        print("guldo <tool> ...   (guldo --help shows the client's own commands)\n")
        for name, (_, what) in sorted(TOOLS.items()):
            print(f"  guldo {name:12s} {what}")
        return 0
    if argv and argv[0] in TOOLS:
        return _call(TOOLS[argv[0]][0], argv[1:], f"guldo {argv[0]}")
    import svp   # the client module keeps its file name; only the command a person types is `guldo`
    svp.PROG = "guldo"
    return svp.main(argv)


if __name__ == "__main__":
    sys.exit(main())
