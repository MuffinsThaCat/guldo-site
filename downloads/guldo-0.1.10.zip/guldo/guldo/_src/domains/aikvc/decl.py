"""Declaration of an AI KV-cache-compression domain: decode 64 steps of single-head attention over a long cached context, to the same outputs, with as few BYTES moved as you can.

size = n, the context length (the number of cached positions). The cache is the keys K and values V of those positions, n x 32 each, and they have LOW-RANK STRUCTURE by definition: K = Zk Bk and V = Zv Bv
with Zk, Zv of shape n x 4 (a 4-number latent per position) and Bk, Bv of shape 4 x 32, all from the pinned SplitMix64 stream the other AI domains use (layout in reference.py). That is the setting of
latent-attention caches (the cache stores the small latent, not the expanded keys and values) and of any cache that is really lower-rank than it looks.

Decoding runs S = 64 steps. Step t's query is q_t = 2 base_t + 4 o_(t-1), where base_t is a fixed vector from the stream and o_(t-1) is the PREVIOUS step's output (o_(-1) = 0), so the steps are sequential
and every step reads the whole cache. The output of step t is o_t = softmax(K q_t / sqrt(32)) V. The reference materialises the full 32-wide K and V in float64 and reads both for every step.

Three ways to move fewer bytes, all of which this domain lets you compare: (1) hold the cache in fp16 (a quarter of the bytes); (2) never expand it: keep the 4-wide latents and score with (Bk q) . z, which is
an exact identity, 8 times fewer values per position; (3) both. Evicting old positions (a "window" or "sink" cache) moves fewer bytes still, but this context was built so that the attention reaches the
whole of it, and the output changes: the judge rejects it. That is the "equivalent output" the saving is conditional on.

The answer is the S x 32 outputs as a flat list of 2048 INTEGERS in units of 2^-16. Verification is TEACHER-FORCED: the judge recomputes each step from the SUBMITTED previous output (so a small rounding
difference cannot snowball) and accepts iff every entry is within TOL (0.01) of the exact float64 value. fp16 passes with a wide margin.

Measured with tflops_mem.py (operations, bytes moved and peak memory under declared precisions; `tp.cast(x, "fp16")`), compared with tflops_compare.py --metric bytes|peak|ops. Bytes and peak are an accounting
convention over shapes and declared widths: no cache, no fusion, no real memory system; integer (int8) caches are not in the accounting. It certifies "N times fewer bytes under these rules", not "N times faster".
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aikvc"
VERSION = "aikvc-v1"          # bump whenever derive() or the cache definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (1024, 4096)     # below ~1024 the reference costs under the estimator's 0.5 s floor (5e6 operations)
SIZE_STEP = 512
REFERENCE_SOLVER = "reference.py"
D, R, S = 32, 4, 64
K_SCALE, Q_SCALE, GAMMA = 2.0, 2.0, 4.0
SCALE = 2 ** 16
TOL = 0.01
LIMIT = 2 ** 40
DOC = ("solve(seed, n): from the SplitMix64 stream under `seed` (tensorops.stream, layout in domains/aikvc/reference.py) take the latents Zk, Zv (n x 4, scale 1), Bk (4 x 32, scale 2 * 3/sqrt(4)), "
       "Bv (4 x 32, scale 3/sqrt(4)) and base (64 x 32, scale 2); K = Zk Bk, V = Zv Bv. For t = 0..63: q = base[t] + 4 o[t-1] (o[-1] = 0); s = K q / sqrt(32); o[t] = softmax(s) V. Return the 64 outputs "
       "as a flat list of 64*32 integers in units of 2^-16; each must be within 0.01 of the exact value given your own previous output. Return None for no answer.")
REFERENCE_NOTE = ("float64, the full K and V (n x 32 each) built once and read in full at every one of the 64 steps. Known to be beaten, on bytes, by an fp16 cache (a quarter) and by scoring "
                  "against the 4-wide latents without ever expanding the cache (about 8 times fewer values per position); both together, more.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _cache(seed, n):
    o = [0]

    def take(shape, scale):
        m = int(np.prod(shape))
        a = (_uniform(seed, o[0], m) * scale).reshape(shape)
        o[0] += m
        return a
    Zk, Zv = take((n, R), 1.0), take((n, R), 1.0)
    Bk, Bv = take((R, D), K_SCALE * 3.0 / math.sqrt(R)), take((R, D), 3.0 / math.sqrt(R))
    base = take((S, D), Q_SCALE)
    return Zk @ Bk, Zv @ Bv, base


def _step(K, V, base_t, prev):
    s = K @ (base_t + GAMMA * prev) / math.sqrt(D)
    a = np.exp(s - s.max())
    return (a / a.sum()) @ V


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aikvc-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    K, V, base = _cache(seed, size)
    prev, out = np.zeros(D), []
    for t in range(S):
        prev = _step(K, V, base[t], prev)
        out.append(prev)
    return {"args": [seed, size], "planted": [int(v) for v in np.rint(np.array(out) * SCALE).ravel()]}


def verify(inst: dict, ans) -> bool:
    seed, n = inst["args"]
    if not isinstance(ans, list) or len(ans) != S * D:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    got = np.array(ans, dtype=np.float64).reshape(S, D) / SCALE
    K, V, base = _cache(seed, n)
    prev = np.zeros(D)
    for t in range(S):
        if np.max(np.abs(got[t] - _step(K, V, base[t], prev))) > TOL:
            return False
        prev = got[t]
    return True
