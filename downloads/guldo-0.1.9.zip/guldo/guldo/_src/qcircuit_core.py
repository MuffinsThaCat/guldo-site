"""QUANTUM challenges as RESOURCE claims at toy size (standard library only). New file: nothing in rounds.CODE_FILES or COUNT_FILES changes.

A wall-clock timer on a classical machine cannot measure a quantum algorithm, and Guldo does not pretend to. What it CAN certify exactly is a statement about a CIRCUIT: the solver returns a
circuit (a flat list of integers, the runner's normal answer type); the judge simulates it EXACTLY (a statevector, no sampling noise) on the instance and the claim is

    "this circuit on <= QUBITS qubits succeeds with probability >= SUCCESS on the committed instances, and costs G gates / C oracle calls"

Gate = 4 integers [op, a, b, c]. Ops: 0 H(a)  1 X(a)  2 Z(a)  3 S(a)  4 T(a)  5 Tdg(a)  6 CNOT(control a, target b)  7 CZ(a, b)  8 ORACLE (phase -1 on every basis state whose low `n` qubits equal
the instance's marked value; one oracle call, operands ignored: write 0 0 0). Everything else (Toffoli, multi-controlled Z) the solver must BUILD from these and pay for. Qubit i is bit i of the index.
Cost: every non-oracle gate counts 1 (T-count is reported separately); an oracle call counts ORACLE_GATE_COST gates (default 1) and is also reported alone.

Declaration extras (operator code): QUBITS (total, <= 12), SUCCESS (default 2/3), `marked(inst) -> int`, and `verify(inst, ans)` may simply call check().

What this is NOT: a quantum speedup. It is the exact resource count of one circuit at a size a laptop can simulate, so it supports "this construction needs N gates / T gates / oracle calls" and nothing about
asymptotics, noise, error correction or any real device. A circuit that is correct only because the simulator is exact (it needs 10^-9 phase precision) is flagged: `max_angle_error` is zero by construction, because the
gate set is discrete (Clifford+T), which is why rotations by arbitrary angles are not offered.
"""
import cmath
import hashlib
import json
import math

OPS = {0: "H", 1: "X", 2: "Z", 3: "S", 4: "T", 5: "Tdg", 6: "CNOT", 7: "CZ", 8: "ORACLE"}
MAX_GATES = 20000
MAX_QUBITS = 12
MAX_WORK = 20_000_000   # basic amplitude updates the judge will spend verifying ONE circuit (about 2 s in pure Python): the verifier must not be a denial-of-service target
_R = 1 / math.sqrt(2)
_P = {2: -1, 3: 1j, 4: cmath.exp(1j * math.pi / 4), 5: cmath.exp(-1j * math.pi / 4)}   # diagonal single-qubit phases applied to |1>


class CircuitError(ValueError):
    """A malformed circuit: the message is safe to show to its author."""


def decode(flat, qubits):
    """-> [(op, a, b)] or raises CircuitError. Strict: a list of plain ints, length a multiple of 4, ops known, qubit indices in range and distinct where two are used."""
    if not isinstance(flat, list) or any(isinstance(v, bool) or not isinstance(v, int) for v in flat):
        raise CircuitError("a circuit is a list of integers")
    if len(flat) % 4:
        raise CircuitError("the list length must be a multiple of 4 (op, a, b, c per gate)")
    if len(flat) // 4 > MAX_GATES:
        raise CircuitError(f"more than {MAX_GATES} gates")
    gates = []
    for i in range(0, len(flat), 4):
        op, a, b, c = flat[i:i + 4]
        if op not in OPS:
            raise CircuitError(f"gate {i // 4}: unknown op {op}")
        if op == 8:
            if (a, b, c) != (0, 0, 0):
                raise CircuitError(f"gate {i // 4}: the oracle's operands must be 0 0 0")
            gates.append((8, 0, 0))
            continue
        if not 0 <= a < qubits:
            raise CircuitError(f"gate {i // 4}: qubit {a} is outside 0..{qubits - 1}")
        if op in (6, 7):
            if not 0 <= b < qubits or a == b:
                raise CircuitError(f"gate {i // 4}: two distinct qubits in range are needed")
            if c != 0:
                raise CircuitError(f"gate {i // 4}: the unused operand must be 0")
        elif b != 0 or c != 0:
            raise CircuitError(f"gate {i // 4}: the unused operands must be 0 (one circuit, one encoding)")
        gates.append((op, a, b))
    return gates


def simulate(gates, qubits, n_data, marked):
    """-> the exact final amplitudes (list of complex, index = basis state)."""
    if not 1 <= qubits <= MAX_QUBITS or not 1 <= n_data <= qubits:
        raise CircuitError(f"qubits must be 1..{MAX_QUBITS}")
    dim = 1 << qubits
    amp = [0j] * dim
    amp[0] = 1 + 0j
    lowmask = (1 << n_data) - 1
    for op, a, b in gates:
        if op == 0:
            m = 1 << a
            for i in range(dim):
                if not i & m:
                    x, y = amp[i], amp[i | m]
                    amp[i], amp[i | m] = (x + y) * _R, (x - y) * _R
        elif op == 1:
            m = 1 << a
            for i in range(dim):
                if not i & m:
                    amp[i], amp[i | m] = amp[i | m], amp[i]
        elif op in _P:
            m, ph = 1 << a, _P[op]
            for i in range(dim):
                if i & m:
                    amp[i] *= ph
        elif op == 6:
            ma, mb = 1 << a, 1 << b
            for i in range(dim):
                if i & ma and not i & mb:
                    amp[i], amp[i | mb] = amp[i | mb], amp[i]
        elif op == 7:
            both = (1 << a) | (1 << b)
            for i in range(dim):
                if i & both == both:
                    amp[i] = -amp[i]
        else:   # ORACLE
            for i in range(dim):
                if i & lowmask == marked:
                    amp[i] = -amp[i]
    return amp


def success_probability(amp, n_data, marked):
    """P(measuring the data qubits gives `marked`), ancillas traced out."""
    lowmask = (1 << n_data) - 1
    return sum(abs(v) ** 2 for i, v in enumerate(amp) if i & lowmask == marked)


def costs(gates, oracle_gate_cost=1):
    n_or = sum(g[0] == 8 for g in gates)
    return {"gates": sum(1 if g[0] != 8 else oracle_gate_cost for g in gates), "t_count": sum(g[0] in (4, 5) for g in gates), "oracle_calls": n_or, "depth_bound": len(gates)}


def evaluate_circuit(flat, qubits, n_data, marked_values, success=2 / 3, oracle_gate_cost=1):
    """-> {"ok", "min_probability", "costs", "circuit_sha256"} over every marked value in `marked_values` (the circuit must work for each: it may not depend on the instance)."""
    gates = decode(flat, qubits)
    marked_values = list(marked_values)   # once: a generator would otherwise be spent by the work estimate and leave nothing to simulate
    if not marked_values or any(isinstance(m, bool) or not isinstance(m, int) or not 0 <= m < (1 << n_data) for m in marked_values):
        raise CircuitError("marked values must be a non-empty collection of integers in 0..2^n_data - 1")
    work = len(gates) * (1 << qubits) * len(marked_values)
    if work > MAX_WORK:
        raise CircuitError(f"gates x 2^qubits x marked values = {work} exceeds the verifier's work limit {MAX_WORK}: use fewer gates or qubits")
    ps = [success_probability(simulate(gates, qubits, n_data, m), n_data, m) for m in marked_values]
    lo = min(ps)
    return {"ok": lo >= success - 1e-9, "min_probability": lo, "costs": costs(gates, oracle_gate_cost),
            "circuit_sha256": hashlib.sha256(json.dumps(flat, separators=(",", ":")).encode()).hexdigest()}
