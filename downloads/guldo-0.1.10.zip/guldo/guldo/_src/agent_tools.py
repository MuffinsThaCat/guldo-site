"""Command line for the agent-evaluation extras: stratified bounds, attestation, witnesses, GPU tiers, bounties, the certificate index, safety register, insurer and regulatory reports.

  strata LADDER                                                  difficulty-stratified solve-rate bounds
  keygen --out FILE                                              a new Ed25519 key (pure Python; never overwritten); prints the public key
  attest-verify LADDER RECEIPTS --trusted KEYS (--seed F | --practice) [--registry F [--allow-multiple-sessions] [--registry-head H] [--signed-head F ...]]
                                                                 every model call covered by a signed, matching receipt from a pinned key? With the shim's session registry it also refuses the best of several
                                                                 sessions (or prints the attempt count), a truncated chain, and a registry shorter than or different from a signed head you hold
  registry-head REGISTRY --key FILE [--out FILE]                 sign the registry's current head with the shim's key: keep or publish it at every session close
  attest-convert LADDER RECEIPTS --out FILE --trusted KEYS (--seed F | --practice) [--registry ...]   the ladder with ATTESTED provider token counts (verifies the receipts first; refuses if any trial lacks signed usage)
  preflight --plan P --agent SPEC (--seed F | --practice) --out L [--price-in X --price-out Y] [--pilot-ladder LADDER ...] [--pilot-done]   every check for a real run that needs no model call; prints the run command, never runs it
  witness-sign LADDER (--seed F | --practice) --key FILE [--plan P --plan-hash H] [--out FILE]       verify the ladder yourself and sign the outcome
  witness-rerun LADDER --sample M --key FILE (--seed F | --practice) [--agent SPEC] [--confirm-api-spend]   verify, then DRAW your own secret sample of M instances, run the agent on it yourself,
                                                                 test your pass count against the operator's recorded rate, and sign the lot (a real model needs --confirm-api-spend)
  witness-check LADDER STATEMENT... --trusted KEYS [--min N] [--seed F | --practice]     count independent witnesses (with a seed, a "does not verify" dissent from an unpinned key is settled by re-verifying)
  gpu-t2-sign OPERATOR_LADDER MY_LADDER --key FILE [--out FILE] / gpu-t2-check OPERATOR_LADDER STATEMENT... --trusted KEYS [--min 2]
  gpu-t3-parse NCU_CSV                                           flops and DRAM bytes from Nsight Compute CSV output
  gpu-t4-check TOKEN --pubkey PEM --ladder-digest HEX [--policy JSON]
  bounty post|fund|claim|verdict|challenge|resolve|settle|refund|status ...   (see agent_bounty.py; time is --now UNIX or the clock; `challenge --ground verification|other [--key F]`,
                                                                 --key signs a blocking challenge when the bounty pins challenger_pubkeys)
  index add|query|route ...                                      certificate index (agent_index.py)
  safety LADDER [--seed F | --practice] [--register FILE]        unsafe-outcome summary (with the seed, recomputed from the trajectories); --register also appends a hash-chained dated entry (needs the seed)
  insurer LADDER [--seed F | --practice] [--loss-per-failure X --tasks-per-year N --currency C]
  regulatory LADDER [--seed F | --practice] [--receipts R --trusted K] [--witness STMT...]   evidence index; attestation and witnesses are CHECKED from files, never typed in (NOT a compliance assessment)
  Every report command re-verifies the ladder from the seed when given one and refuses a ladder that does not verify; without a seed its output says in capitals that the ladder was NOT re-checked.
"""
import argparse
import json
import sys
import time

import agent_attest
import agent_bounty
import agent_compare
import agent_core
import agent_eval
import agent_index
import agent_insurer
import agent_regulatory
import agent_safety
import agent_sig
import agent_strata
import agent_preflight
import agent_providers
import agent_witness
import gpu_tiers


def _die(msg, code=1):
    print("error: " + msg, file=sys.stderr)
    sys.exit(code)


def _master(a):
    return agent_core.read_master(getattr(a, "seed", None), getattr(a, "practice", False))


def _seedargs(p):
    p.add_argument("--seed")
    p.add_argument("--practice", action="store_true")


def _registryargs(p):
    p.add_argument("--registry", help="the shim's signed session registry: checks the receipts are ONE registered session's complete closed chain and that no other session was opened for this plan")
    p.add_argument("--allow-multiple-sessions", action="store_true", help="accept a plan with several sessions (the attempt count is then printed, not forbidden)")
    p.add_argument("--registry-head", help="the registry head you were given earlier: without it a registry with its last events removed looks shorter, not wrong")
    p.add_argument("--signed-head", action="append", default=[], help="a signed head file (`registry-head`): refuses a registry shorter than, or different from, what it recorded. Repeatable")


def _registry_kwargs(a):
    if not getattr(a, "registry", None):
        return {}
    try:
        events = agent_attest.SessionRegistry(a.registry).read_events()
    except (ValueError, OSError) as e:
        sys.exit("REFUSED: " + str(e))
    return {"registry": events, "allow_multiple_sessions": a.allow_multiple_sessions, "expected_registry_head": a.registry_head,
            "registry_signed_heads": [json.load(open(p)) for p in a.signed_head] or None}


def _dump(obj, path=None):
    text = json.dumps(obj, indent=1, sort_keys=True) + "\n"
    if path:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
    return text


def build_parser():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("strata"); p.add_argument("ladder")
    p = sub.add_parser("keygen"); p.add_argument("--out", required=True)
    p = sub.add_parser("attest-verify"); p.add_argument("ladder"); p.add_argument("receipts"); p.add_argument("--trusted", required=True); _seedargs(p); _registryargs(p)
    p = sub.add_parser("attest-convert"); p.add_argument("ladder"); p.add_argument("receipts"); p.add_argument("--out", required=True); p.add_argument("--trusted", required=True); _seedargs(p); _registryargs(p)
    p = sub.add_parser("witness-sign"); p.add_argument("ladder"); p.add_argument("--key", required=True); p.add_argument("--plan"); p.add_argument("--plan-hash"); p.add_argument("--out"); p.add_argument("--note", default=""); _seedargs(p)
    p = sub.add_parser("witness-rerun"); p.add_argument("ladder"); p.add_argument("--key", required=True); p.add_argument("--sample", type=int, required=True, help="how many planned instances YOU draw and rerun")
    p.add_argument("--agent", help="agent spec to run (default: the ladder's own, e.g. anthropic:MODEL)"); p.add_argument("--plan"); p.add_argument("--plan-hash"); p.add_argument("--out"); p.add_argument("--records-out")
    p.add_argument("--note", default=""); p.add_argument("--material", help="bytes only you know, to fix your draw (default: fresh randomness)"); p.add_argument("--confirm-api-spend", action="store_true")
    p.add_argument("--accept-unsandboxed-code", action="store_true"); _seedargs(p)
    p = sub.add_parser("witness-check"); p.add_argument("ladder"); p.add_argument("statements", nargs="+"); p.add_argument("--trusted", required=True); p.add_argument("--min", type=int, default=1)
    p.add_argument("--plan"); p.add_argument("--plan-hash"); _seedargs(p)     # with a seed (or --practice) the ladder is re-verified HERE, which settles a "does not verify" dissent from a key you did not pin
    p = sub.add_parser("registry-head", help="sign the session registry's current head with the shim's key: keep or publish the output, and give it to `attest-verify --signed-head`")
    p.add_argument("registry"); p.add_argument("--key", required=True); p.add_argument("--out")
    p = sub.add_parser("preflight", help="every check for a real agent run that needs no model call: seed location, SDK and credentials, attestation, cost ceiling, pilot, sandbox, output path")
    p.add_argument("--plan", required=True); p.add_argument("--agent", required=True); p.add_argument("--out"); p.add_argument("--label"); p.add_argument("--price-in", type=float, help="your price per million input tokens")
    p.add_argument("--price-out", type=float, help="your price per million output tokens"); p.add_argument("--pilot-done", action="store_true"); p.add_argument("--resume", action="store_true")
    p.add_argument("--accept-unsandboxed-code", action="store_true"); _seedargs(p)
    p.add_argument("--pilot-ladder", action="append", default=[], help="a pilot ladder from a real run (repeatable): the expected cost is computed from its provider usage numbers, which is what to decide on")
    p = sub.add_parser("gpu-t2-sign"); p.add_argument("operator_ladder"); p.add_argument("my_ladder"); p.add_argument("--key", required=True); p.add_argument("--out")
    p = sub.add_parser("gpu-t2-check"); p.add_argument("operator_ladder"); p.add_argument("statements", nargs="+"); p.add_argument("--trusted", required=True); p.add_argument("--min", type=int, default=2)
    p = sub.add_parser("gpu-t3-parse"); p.add_argument("ncu_csv")
    p = sub.add_parser("gpu-t4-check"); p.add_argument("token"); p.add_argument("--pubkey", required=True); p.add_argument("--ladder-digest", required=True); p.add_argument("--policy")
    p = sub.add_parser("bounty"); p.add_argument("action", choices=["post", "fund", "claim", "verdict", "challenge", "resolve", "settle", "refund", "status"]); p.add_argument("ledger"); p.add_argument("bounty_id")
    p.add_argument("--key", help="Ed25519 key file: signs a claim (required by bounties with require_signed_claims) or a blocking challenge (required by bounties that pin challenger_pubkeys)")
    p.add_argument("--spec"); p.add_argument("--escrow-ref"); p.add_argument("--claimant"); p.add_argument("--claim"); p.add_argument("--base"); p.add_argument("--cand"); p.add_argument("--claim-index", type=int)
    p.add_argument("--ground", choices=["verification", "other"], default="other", help="challenge: what is wrong. `verification` (the claim does not verify) is recorded but never blocks, because settlement re-runs the check; `other` blocks until resolved")
    p.add_argument("--who"); p.add_argument("--reason"); p.add_argument("--evidence-sha", default=""); p.add_argument("--outcome"); p.add_argument("--overturn", type=int); p.add_argument("--now", type=int)
    p.add_argument("--round-base", help="directory holding the agent round the bounty names (round_id): required to evaluate a claim on such a bounty"); _seedargs(p)
    p = sub.add_parser("index"); p.add_argument("action", choices=["add", "query", "route"]); p.add_argument("index_file")
    p.add_argument("--ladder"); p.add_argument("--domain"); p.add_argument("--size", type=int); p.add_argument("--min-lower", type=float); p.add_argument("--max-unsafe-upper", type=float)
    p.add_argument("--max-age-days", type=float); p.add_argument("--include-practice", action="store_true"); p.add_argument("--include-scripted", action="store_true"); _seedargs(p)
    p = sub.add_parser("head-sign"); p.add_argument("kind", choices=["bounty", "register"]); p.add_argument("file"); p.add_argument("--key", required=True); p.add_argument("--out")
    p = sub.add_parser("head-check"); p.add_argument("kind", choices=["bounty", "register"]); p.add_argument("file"); p.add_argument("signed"); p.add_argument("--trusted", required=True)
    p = sub.add_parser("safety"); p.add_argument("ladder"); p.add_argument("--register"); _seedargs(p)
    p = sub.add_parser("insurer"); p.add_argument("ladder"); p.add_argument("--loss-per-failure", type=float); p.add_argument("--tasks-per-year", type=float); p.add_argument("--currency", default=""); p.add_argument("--json", action="store_true"); _seedargs(p)
    p = sub.add_parser("regulatory"); p.add_argument("ladder"); p.add_argument("--receipts"); p.add_argument("--trusted"); p.add_argument("--witness", nargs="*", default=[]); p.add_argument("--json", action="store_true"); _seedargs(p)
    return ap


def run(a):
    c = a.cmd
    if c == "keygen":
        print("public key (publish it): " + agent_sig.keygen(a.out))
        print("signing backend: %s%s" % (agent_sig.backend(), "" if agent_sig.backend() == "openssl" else " (pure Python, NOT constant-time: install `cryptography` if a local timing side channel matters)"))
    elif c == "strata":
        h, r = agent_core.read_ladder(a.ladder)
        sm = agent_compare.summarize(h, r)
        print(_dump(agent_strata.report(agent_strata.strata_from_summary(sm["by_size"])))[:-1])
    elif c == "attest-verify":
        h, r = agent_core.read_ladder(a.ladder)
        probs = agent_attest.verify_attested(h, r, agent_attest.read_receipts(a.receipts), agent_sig.read_trusted(a.trusted), _master(a),
                                             **_registry_kwargs(a))
        for p in probs[:20]:
            print("FAIL: " + p)
        if not getattr(a, "registry", None):
            print("NOTE: no --registry given: whether the operator ran other sessions and presented only the best CANNOT be ruled out")
        else:
            _, info = agent_attest.check_sessions(agent_attest.SessionRegistry(a.registry).read_events(), agent_attest.read_receipts(a.receipts), h.get("plan_hash"),
                                                  agent_sig.read_trusted(a.trusted), True)
            if info["sessions_opened"]:
                print("SESSIONS: %d opened for this plan, this ladder is session %s%s: quote this count with any result" % (
                    info["sessions_opened"], info["presented"], (" (%s abandoned)" % ", ".join(info["abandoned"])) if info["abandoned"] else ""))
        print("ATTESTED: every model call is covered by a signed receipt from a pinned key" if not probs else "NOT ATTESTED (%d problems)" % len(probs))
        return 0 if not probs else 1
    elif c == "attest-convert":
        h, r = agent_core.read_ladder(a.ladder)
        h2, r2 = agent_attest.convert(h, r, agent_attest.read_receipts(a.receipts), agent_sig.read_trusted(a.trusted), _master(a), **_registry_kwargs(a))
        agent_core.write_ladder(a.out, h2, r2)
        print("wrote %s with counter %s (every model call was covered by a receipt from a key you pinned)" % (a.out, agent_attest.ATTESTED_COUNTER))
    elif c == "witness-sign":
        master = _master(a)
        plan = json.load(open(a.plan)) if a.plan else None
        probs, _ = agent_eval.verify_ladder(a.ladder, master, plan, a.plan_hash, True)
        h, r = agent_core.read_ladder(a.ladder)
        st = agent_witness.make_statement(h, r, probs, agent_sig.load_secret(a.key), note=a.note)
        text = _dump(st, a.out)
        print(("VERIFIED" if not probs else "NOT VERIFIED (%d problems; first: %s)" % (len(probs), probs[0])) + (" -> wrote %s" % a.out if a.out else "\n" + text))
        return 0 if not probs else 1
    elif c == "witness-rerun":
        import os
        master = _master(a)
        plan = json.load(open(a.plan)) if a.plan else None
        probs, _ = agent_eval.verify_ladder(a.ladder, master, plan, a.plan_hash, True)
        h, r = agent_core.read_ladder(a.ladder)
        spec = a.agent or h["agent"].get("spec")
        if not spec:
            _die("the ladder names no agent spec; give --agent")
        if agent_providers.is_real_model(spec) and not a.confirm_api_spend:
            _die("this makes up to %d real API trials at YOUR expense (%d sampled instances x %d trials); rerun with --confirm-api-spend to go ahead" % (a.sample * h["trials"], a.sample, h["trials"]), 2)
        import agent_sandbox
        try:
            container = agent_sandbox.isolated(h["domain"])
        except agent_sandbox.SandboxError as e:
            _die("GULDO_SANDBOX=docker is set but the sandbox does not work (%s)" % e)
        if agent_core.runs_code(h["domain"]) and not h["practice"] and not a.accept_unsandboxed_code and not container:
            _die("the %s domain runs the agent's code on this machine, where your seed file is readable; run in a throwaway VM or container, then pass --accept-unsandboxed-code" % h["domain"], 2)
        material = a.material.encode("utf-8") if a.material else os.urandom(32)
        agent = agent_providers.make_agent(spec, h["domain"])
        agent.label = h["agent"].get("label", spec) if hasattr(agent, "label") else None
        st, wrecs, block = agent_witness.witness_rerun(h, r, master, a.sample, material, agent, agent_sig.load_secret(a.key), probs, a.note,
                                                       progress=lambda rec: print("[witness] %s trial %d: %s" % (rec["instance"], rec["trial"], "solved" if rec["solved"] else "FAILED"), file=sys.stderr))
        if a.records_out:
            agent_core.write_ladder(a.records_out, h, wrecs)
        text = _dump(st, a.out)
        print("ladder %s; rerun: %d of %d trials passed on %d instances you drew (operator's pass-rate lower bound %.3f, p of a count this low %.3g): %s%s"
              % ("VERIFIED" if not probs else "NOT VERIFIED (%d problems)" % len(probs), block["witness_passed"], block["witness_trials"], len(block["sample"]), block["operator_pass_rate_lower95"],
                 block["p_witness_this_low"], "CONSISTENT" if block["consistent"] else "INCONSISTENT (a flag means ask, not fraud)", (" -> wrote %s" % a.out) if a.out else "\n" + text))
        return 0 if (not probs and block["consistent"]) else 1
    elif c == "witness-check":
        h, r = agent_core.read_ladder(a.ladder)
        own = None
        if getattr(a, "seed", None) or getattr(a, "practice", False):
            plan = json.load(open(a.plan)) if a.plan else None
            own, _ = agent_eval.verify_ladder(a.ladder, _master(a), plan, a.plan_hash, True)
        res = agent_witness.check_witnesses(agent_compare.ladder_digest(h, r), [json.load(open(p)) for p in a.statements], agent_sig.read_trusted(a.trusted), a.min, own_problems=own)
        print("\n".join(res["lines"]))
        return 0 if res["ok"] else 1
    elif c == "registry-head":
        st = agent_attest.SessionRegistry(a.registry, agent_sig.load_secret(a.key)).signed_head()
        text = _dump(st, a.out)
        print(("wrote %s: " % a.out if a.out else text + "\n") + "registry length %d, head %s... (keep or publish this; a later `attest-verify --signed-head` can then detect removed or rewritten events)" % (
            st["statement"]["length"], st["statement"]["head"][:12]))
    elif c == "preflight":
        res = agent_preflight.preflight(a.plan, a.agent, getattr(a, "seed", None), getattr(a, "practice", False), a.out, a.price_in, a.price_out, a.pilot_done, a.resume,
                                        a.accept_unsandboxed_code, a.label, pilot_ladders=a.pilot_ladder or None)
        print(agent_preflight.render(res, agent_preflight.next_command(a.plan, a.agent, getattr(a, "seed", None), getattr(a, "practice", False), a.out, a.label), spends=agent_providers.is_real_model(a.agent)))
        return 1 if any(lvl == agent_preflight.FAIL for lvl, _ in res) else 0
    elif c == "gpu-t2-sign":
        om, orr = gpu_tiers.read_gpu_ladder(a.operator_ladder)
        mm, mr = gpu_tiers.read_gpu_ladder(a.my_ladder)
        st = gpu_tiers.make_t2_statement(om, orr, mm, mr, agent_sig.load_secret(a.key))
        print(("AGREE" if st["statement"]["agree"] else "DISAGREE: " + "; ".join(st["statement"]["problems"])) + (" -> wrote %s" % a.out if a.out else ""))
        _dump(st, a.out)
        return 0 if st["statement"]["agree"] else 1
    elif c == "gpu-t2-check":
        om, orr = gpu_tiers.read_gpu_ladder(a.operator_ladder)
        res = gpu_tiers.check_t2(om, orr, [json.load(open(p)) for p in a.statements], agent_sig.read_trusted(a.trusted), a.min)
        print("\n".join(res["lines"]))
        return 0 if res["ok"] else 1
    elif c == "gpu-t3-parse":
        w = gpu_tiers.counters_to_work(gpu_tiers.parse_ncu_csv(open(a.ncu_csv).read()))
        print(_dump(w)[:-1])
    elif c == "gpu-t4-check":
        res = gpu_tiers.check_t4(open(a.token).read(), open(a.pubkey).read(), json.load(open(a.policy)) if a.policy else {}, a.ladder_digest)
        print("\n".join(res["lines"]))
        return 0 if res["ok"] else 1
    elif c == "bounty":
        return _bounty(a)
    elif c == "index":
        return _index(a)
    elif c == "head-sign":
        secret = agent_sig.load_secret(a.key)
        st = agent_bounty.sign_head(a.file, secret) if a.kind == "bounty" else agent_safety.register_sign_head(a.file, secret)
        text = _dump(st, a.out)
        print("signed head of %s (length %d)%s" % (a.file, st["statement"]["n"], (" -> wrote " + a.out) if a.out else "\n" + text))
    elif c == "head-check":
        signed, trusted = json.load(open(a.signed)), agent_sig.read_trusted(a.trusted)
        ok, msg = agent_bounty.check_head(a.file, signed, trusted) if a.kind == "bounty" else agent_safety.register_check_head(a.file, signed, trusted)
        print(("OK: " if ok else "FAIL: ") + msg)
        return 0 if ok else 1
    elif c == "safety":
        h, r, master = _verified_ladder(a, need=bool(a.register))
        print(_dump(agent_safety.safety_summary(h, r, master=master))[:-1])
        if a.register:
            print("register head: " + agent_safety.register_append(a.register, h, r, master=master))
    elif c == "insurer":
        h, r, master = _verified_ladder(a)
        rep = agent_insurer.report(h, r, a.loss_per_failure, a.tasks_per_year, a.currency, master=master, verified=master is not None)
        print(_dump(rep)[:-1] if a.json else agent_insurer.render(rep))
    elif c == "regulatory":
        h, r, master = _verified_ladder(a)
        attested, witnesses = False, 0
        if a.receipts:
            if master is None or not a.trusted:
                _die("--receipts needs the seed and --trusted (the keys you pinned): attestation is not taken on the caller's word", 2)
            attested = not agent_attest.verify_attested(h, r, agent_attest.read_receipts(a.receipts), agent_sig.read_trusted(a.trusted), master)
        if a.witness:
            if not a.trusted:
                _die("--witness needs --trusted", 2)
            witnesses = len(agent_witness.check_witnesses(agent_compare.ladder_digest(h, r), [json.load(open(p)) for p in a.witness], agent_sig.read_trusted(a.trusted), 1)["independent"])
        rep = agent_regulatory.package_report(h, r, attested, witnesses, verified=master is not None)
        print(_dump(rep)[:-1] if a.json else agent_regulatory.render(rep))
    return 0


def _verified_ladder(a, need=False):
    """(header, records, master). If a seed (or --practice) is given, the ladder is re-verified from it first and a ladder that does not verify is refused; otherwise master is None and the output
    says the ladder was NOT re-checked. `need=True` makes the seed mandatory (anything that writes a record)."""
    h, r = agent_core.read_ladder(a.ladder)
    if not (getattr(a, "seed", None) or getattr(a, "practice", False)):
        if need:
            _die("this command writes a record: give --seed (or --practice) so the ladder is re-verified first", 2)
        return h, r, None
    master = _master(a)
    probs, _ = agent_eval.verify_ladder(a.ladder, master, None, None, True)
    if probs:
        _die("the ladder does not verify (%d problems, first: %s): refusing to report on it" % (len(probs), probs[0]))
    return h, r, master


def _bounty(a):
    now = a.now if a.now is not None else int(time.time())
    B = agent_bounty
    if a.action == "post":
        B.post(a.ledger, a.bounty_id, json.load(open(a.spec)), now)
    elif a.action == "fund":
        B.fund(a.ledger, a.bounty_id, a.escrow_ref, now)
    elif a.action == "claim":
        B.claim(a.ledger, a.bounty_id, a.claimant, a.claim, a.base, a.cand, now, secret=agent_sig.load_secret(a.key) if a.key else None)
    elif a.action == "verdict":
        s = B.state(a.ledger, a.bounty_id)
        row = s["claims"][a.claim_index]
        if s["spec"].get("round_id") and not a.round_base:
            # a verdict is PERMANENT (never overwritten): a forgotten flag must not be recorded as a substantive FAIL, which would end a legitimate claim and unlock the sponsor's refund
            _die("this bounty names round %r: give --round-base DIR. Nothing was recorded (a verdict is permanent)." % s["spec"]["round_id"], 2)
        ok, lines = B.evaluate_claim(s["spec"], a.claim, a.base, a.cand, _master(a), row, a.round_base)
        if any(x.startswith("FAIL: the claim could not be evaluated") for x in lines):
            print("\n".join(lines))
            _die("the claim could not be evaluated here (unreadable or malformed files?): an environment problem, not a verdict. Nothing was recorded.", 2)
        B.record_verdict(a.ledger, a.bounty_id, a.claim_index, ok, lines, now)
        print("\n".join(lines))
        print("VERDICT: " + ("PASS" if ok else "FAIL"))
        return 0 if ok else 1
    elif a.action == "challenge":
        B.challenge(a.ledger, a.bounty_id, a.who, a.reason, a.evidence_sha, now, a.ground, agent_sig.load_secret(a.key) if a.key else None)
    elif a.action == "resolve":
        B.resolve(a.ledger, a.bounty_id, a.who, a.outcome, now, a.overturn)
    elif a.action == "settle":
        if not (a.claim and a.base and a.cand and (a.seed or a.practice)):
            _die("settle re-runs the whole check at settlement time: give --claim, --base, --cand and --seed (a verdict line alone releases nothing)", 2)
        master, spec = _master(a), B.state(a.ledger, a.bounty_id)["spec"]
        row = B.settle(a.ledger, a.bounty_id, now, recheck=lambda c: B.evaluate_claim(spec, a.claim, a.base, a.cand, master, c, a.round_base))
        print(B.ManualRail.instructions(row))
    elif a.action == "refund":
        row = B.refund(a.ledger, a.bounty_id, now)
        print(B.ManualRail.instructions(row))
    elif a.action == "status":
        ok, head, probs = B.verify_ledger(a.ledger)
        if not ok:
            print("ledger BROKEN: " + "; ".join(probs))
            return 1
        s = B.state(a.ledger, a.bounty_id)
        print("ledger verifies, head %s (keep or publish it: a chain is not a signature); bounty %s: %s, funded=%s, claims=%d, open challenges=%d" % (head, a.bounty_id, s["status"], s["funded"], len(s["claims"]), s["open_challenges"]))
        i, why = B.settlement_ready(a.ledger, a.bounty_id, now)
        print("settlement: " + ("ready (claim %d)" % i if i is not None else "not ready: " + why))
    return 0


def _index(a):
    import os
    idx = agent_index.Index.load(a.index_file) if os.path.exists(a.index_file) else agent_index.Index()
    if a.action == "add":
        idx.add(agent_index.build_entry(a.ladder, _master(a)))
        idx.save(a.index_file)
        print("indexed; %d entries; index sha256 %s" % (len(idx.entries), idx.digest()))
    elif a.action == "query":
        rows = idx.query(a.domain, a.size, None, a.min_lower, a.max_unsafe_upper, a.include_practice, a.include_scripted, a.max_age_days)
        for e in rows:
            print("%-28s %-10s stratified>=%.3f worst>=%.3f tokens %s plan %s..." % (e["agent"].get("label"), e["domain"], e["solve_rate_stratified_lower95"], e["worst_size_lower95"], e["median_tokens_on_solved"], e["plan_hash"][:12]))
        print("%d entr%s" % (len(rows), "y" if len(rows) == 1 else "ies"))
    elif a.action == "route":
        if not a.domain or a.size is None:
            _die("route needs --domain and --size", 2)
        rows = idx.route(a.domain, a.size, a.min_lower if a.min_lower is not None else 0.8, a.max_unsafe_upper, include_practice=a.include_practice, include_scripted=a.include_scripted, max_age_days=a.max_age_days)
        for n, (e, why) in enumerate(rows, 1):
            print("%d. %s: %s" % (n, e["agent"].get("label"), why))
        print(("route: %s" % rows[0][0]["agent"].get("label")) if rows else "route: nobody clears the bar at this size")
        print(agent_index.NOTE)
        return 0 if rows else 1
    return 0


def main(argv=None):
    a = build_parser().parse_args(argv)
    try:
        code = run(a)
    except (agent_core.AgentEvalError, agent_compare.CompareError, agent_bounty.BountyError) as e:
        _die(str(e))
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, OverflowError, OSError) as e:      # a damaged or missing input file: a refusal, not a traceback
        _die("could not use the input (%s: %s)" % (type(e).__name__, str(e)[:160]))
    sys.exit(code or 0)


if __name__ == "__main__":
    main()
