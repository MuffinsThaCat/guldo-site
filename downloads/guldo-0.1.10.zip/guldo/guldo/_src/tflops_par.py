"""Counted ladders with the DEPTH (critical path) of the tensor operations as well as their number (tflops.py's sibling; see tensorops_par.py for the accounting convention).

  python3 tflops_par.py practice SOLVER --baseline REF --family aipar --dims 64 128 256 --n 4 --cap 800 [--seed SEEDFILE] [--reuse-baseline]
  python3 tflops_par.py verify LADDER [LADDER ...] [--rerun K|all] [--seed SEEDFILE] [--solvers DIR]
  python3 tflops_par.py selfcheck SOLVER --family aipar --dim 128          does the same instance count the same twice (operations AND depth)?

A solver is written exactly as for tflops.py (the restricted subset plus `import tensorops as tp`). The ladder records, per instance, the operations (`flops` + `steps`, as before), the DEPTH of the
tensor operations (`depth`) and `span` = depth + steps, all exact: `verify` redoes the arithmetic of every record and, with --rerun, re-executes records and demands IDENTICAL status, operations
and depth. `cpu` is still operations / 1e7, so a ladder reads like a tflops one; tflops_compare.py compares two solvers on any cost (--metric ops | span).

WHAT WORK AND SPAN BOUND. Let F be a run's tensor operations (`flops`), D its depth, S its Python instructions (`steps`), one unit each, and P processors that each do one unit per time step. A greedy scheduler
(Brent 1974) finishes the tensor work in at most F/P + D steps, and the solver's own Python, which runs one instruction after another, adds S; no scheduler beats max(F/P, D) on the tensor work,
and nothing beats the Python's S being sequential, so  max(F/P, D, S)  <=  time  <=  F/P + D + S.  `bounds()` computes both ends in exact rational arithmetic and `certainly_faster(A, B, P)` says
whether A's upper bound is below B's lower bound: then A is faster than B on EVERY such machine with P processors, with no machine in the loop. Work-efficiency is the other half: a parallel algorithm that
does 10x the work is slower at P = 1 and faster only once P is large enough, and the crossover P is exactly computable from the counts (`crossover_p`).

It is NOT a time, a thread count, or a model of communication, synchronisation, load imbalance or memory contention: an idealised machine, so it can show 'A can be made faster than B given enough
processors' and cannot show how fast either runs on a real device. It needs Python 3.12+ and the same unprivileged-throwaway-user care as tflops.py (the solver runs in the operator's process tree,
contained by the restricted subset and a parent-side memory watchdog, not by a sandbox).
"""
import argparse
import hashlib
import json
import os
import random
import secrets
import sys
import tempfile
import time
from fractions import Fraction

import instances
import runwatch
import tflops

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(HERE, "tflops_par_runner.py")
COST_MODEL = "tflops-par"
COUNTER_FILES = ("tflops_par_runner.py", "tensorops_par.py", "tensorops.py", "count_runner.py")
UNIT_OPS = tflops.UNIT_OPS
MIN_PYTHON = tflops.MIN_PYTHON
NEXT_HINT = "next: compare two solvers on any cost with: python3 tflops_compare.py compare BASELINE A B --metric ops|span"
PROCESSORS = (1, 4, 16, 64, 256, 1024, 4096, 16384, 65536, 1 << 20)
CLAIM_LIMITS = ("A count is not a time. Operations and depth are an accounting convention over shapes and data dependencies on an idealised machine of P identical processors (no communication, "
                "synchronisation, load imbalance or memory contention), exactly reproducible by anyone, so they can show 'A can be made faster than B once there are enough processors' and cannot show "
                "how fast either runs on any real device. Depth is a conservative bound: per-tensor granularity and the host rule can only overstate it. The ladder is the prover's unless it was fixed in advance.")


def counter_sha256():
    h = hashlib.sha256()
    for name in COUNTER_FILES:
        with open(os.path.join(HERE, name), "rb") as f:
            h.update(name.encode() + b"\0" + hashlib.sha256(f.read()).digest())
    return h.hexdigest()


def bounds(flops, depth, steps, p):
    """-> (lower, upper) bounds on the time of a run on P processors, exact fractions: max(F/P, D, S) <= T <= F/P + D + S."""
    f = Fraction(flops, p)
    return max(f, depth, steps), f + depth + steps


def certainly_faster(a, b, p):
    """a, b: (flops, depth, steps). True iff A's upper bound is below B's lower bound on p processors: A is faster on every machine the model covers."""
    return bounds(*a, p)[1] < bounds(*b, p)[0]


def crossover_p(a, b, limit=1 << 40):
    """The smallest power of two P from which A is certainly faster than B at EVERY larger power of two up to `limit` too, or None. (Both sides' bounds fall as P grows, so certainty could in
    principle be lost again; requiring it to hold from P on avoids reporting a P that does not last.)"""
    ps = []
    p = 1
    while p <= limit:
        ps.append(p)
        p *= 2
    first = None
    for p in reversed(ps):
        if not certainly_faster(a, b, p):
            break
        first = p
    return first


def summarise(a, b):
    """a, b: (flops, depth, steps) medians. -> {"p": {P: "A"|"B"|"undecided"}, "a_first_certain_p", "b_first_certain_p"}: who is certainly faster at each processor count in PROCESSORS."""
    out = {}
    for p in PROCESSORS:
        out[str(p)] = "A" if certainly_faster(a, b, p) else "B" if certainly_faster(b, a, p) else "undecided"
    return {"processors": out, "a_first_certain_p": crossover_p(a, b), "b_first_certain_p": crossover_p(b, a)}


def count_instance(solver, inst, verify, cap, max_rss_mb=tflops.MAX_RSS_MB):
    """Run `solver` on `inst` under counting. -> a ladder record: id, dim, status, steps, flops, depth, span, cpu, cpu_net, wall."""
    limit = int(cap * UNIT_OPS)
    rec = {"id": inst["id"], "dim": inst["dim"]}
    payload = json.dumps({"args": inst["args"], "limit": limit}).encode()
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "1", "PATH": os.environ.get("PATH", "")}
    t0 = time.time()
    with tempfile.TemporaryDirectory() as empty:
        stdout, stderr, killed = runwatch.run_watched([sys.executable, "-B", RUNNER, os.path.abspath(solver)], payload, env, empty, limit / tflops.SLOW_OPS_PER_SECOND + 120, max_rss_mb)
    rec["wall"] = time.time() - t0
    none = {"steps": None, "flops": None, "depth": None, "span": None}
    if killed == "wall":
        rec.update({"status": "timeout", **none, "wall_timeout": True, "cpu": cap, "cpu_net": cap})
        return rec
    if killed == "memory":
        rec.update({"status": "crash", **none, "cpu": cap, "cpu_net": cap, "err": f"killed: resident memory passed {max_rss_mb} MB"})
        return rec
    lines = [ln for ln in stdout.decode(errors="replace").splitlines() if ln.strip()]
    try:
        out = json.loads(lines[-1])
        steps, flops, depth, status = int(out["steps"]), int(out["flops"]), int(out["depth"]), out["status"]
    except (IndexError, ValueError, KeyError, TypeError):
        rec.update({"status": "crash", **none, "cpu": cap, "cpu_net": cap, "err": "the counter produced no result: " + stderr.decode(errors="replace")[-300:]})
        return rec
    rec.update({"steps": steps, "flops": flops, "depth": depth, "span": depth + steps})
    if status == "limit":
        rec.update({"status": "timeout", "cpu": cap, "cpu_net": cap})
    elif status == "error":
        rec.update({"status": "crash", "cpu": cap, "cpu_net": cap, "err": str(out.get("err", ""))[-1500:]})
    else:
        ans = out.get("ans")
        try:
            ok = bool(verify(inst, ans))
        except Exception as e:     # a verifier that RAISES is the operator's bug, not a wrong answer: say so in the record
            ok = False
            rec["verify_error"] = f"{type(e).__name__}: {str(e)[:200]}"
        rec["status"] = "solved" if ok else ("failed" if ans is None else "wrong")
        rec["cpu"] = (steps + flops) / UNIT_OPS
        rec["cpu_net"] = max(rec["cpu"], 1e-3)
        if rec["status"] != "solved":
            rec["cpu"] = rec["cpu_net"] = cap
    return rec


def ladder_header(solver, family, mod, decl_dir, master, cap):
    return {"meta": True, "solver": os.path.basename(solver), "commit": instances.commit(master), "overhead": 0.0, "budget": cap, "family": family,
            "sandbox": COST_MODEL, "instance_version": mod.VERSION, "image": None, "host": "analytic operation and depth counting (no machine timing)",
            "cpu": "none: counts", "ncpu": 1, "jobs": 1, "solver_sha256": tflops.sha256_file(solver),
            "cost_model": COST_MODEL, "unit_ops": UNIT_OPS, "python": tflops.python_version(), "counter_sha256": counter_sha256(),
            "decl_sha256": tflops.sha256_file(os.path.join(decl_dir, "decl.py"))}


def evaluate_ladder(solver, family, master, dims, n, cap, out_path, progress=None):
    if os.path.exists(out_path):
        raise FileExistsError(out_path)
    mod, derive, verify, d = tflops.load_family(family)
    fd = os.open(out_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    recs = []
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps(ladder_header(solver, family, mod, d, master, cap)) + "\n")
        for dim in dims:
            for idx in range(n):
                rec = count_instance(solver, derive(master, dim, idx), verify, cap)
                f.write(json.dumps(rec) + "\n")
                f.flush()
                recs.append(rec)
                if progress:
                    progress(os.path.basename(solver), rec)
    return recs


def baseline_reusable(path, solver, family, master, dims, n, cap):
    """-> (ok, why): an existing baseline ladder may be reused only if its header is exactly the one that would be written now and it holds exactly the expected instances."""
    try:
        meta, recs = tflops.read_ladder(path)
    except (OSError, ValueError) as e:
        return False, f"unreadable ({type(e).__name__})"
    mod, derive, verify, d = tflops.load_family(family)
    if meta != ladder_header(solver, family, mod, d, master, cap):
        return False, "its header differs from the one this run would write (different seed, solver, declaration, budget, interpreter or counter)"
    want = {f"{dim}:{i}" for dim in dims for i in range(n)}
    got = [r.get("id") for r in recs]
    if len(got) != len(set(got)) or set(got) != want:
        return False, f"it holds {len(set(got) & want)} of the {len(want)} expected instances"
    return True, ""


def verify_ladder(path, rerun=0, master=None, solver_path=None, sample_seed=None):
    """-> (ok, [lines]): the cost model of every record; with rerun > 0 also the exact re-execution of that many records (or all of them): status, operations and depth must be IDENTICAL."""
    lines, ok = [], True
    meta, recs = tflops.read_ladder(path)
    name = os.path.basename(path)
    if meta is None or meta.get("cost_model") != COST_MODEL:
        return False, [f"FAIL {name}: not a {COST_MODEL} ladder"]
    cap, unit = meta.get("budget"), meta.get("unit_ops")
    if isinstance(cap, bool) or not isinstance(cap, (int, float)) or cap <= 0 or "solver_sha256" not in meta or "commit" not in meta:
        return False, [f"FAIL {name}: the header lacks a positive budget, a seed commitment or a solver hash"]
    if not recs:
        return False, [f"FAIL {name}: the ladder holds no records (an empty ladder certifies nothing)"]
    if unit != UNIT_OPS:
        ok = False
        lines.append(f"FAIL unit: the ladder's unit is {unit}, this checkout's is {UNIT_OPS}")
    if meta.get("counter_sha256") != counter_sha256():
        ok = False
        lines.append("FAIL counter: the ladder was counted by a different counting program (hash differs from this checkout's): re-measure with this one")
    bad = 0
    isint = lambda v: isinstance(v, int) and not isinstance(v, bool) and v >= 0
    for r in recs:
        try:
            if r["status"] == "solved":
                if not all(isint(r[k]) for k in ("steps", "flops", "depth", "span")) or r["span"] != r["depth"] + r["steps"]:
                    bad += 1
                    continue
                exp = (r["steps"] + r["flops"]) / UNIT_OPS
                if abs(r["cpu"] - exp) > 1e-12 or abs(r["cpu_net"] - max(exp, 1e-3)) > 1e-12:
                    bad += 1
            elif r["cpu_net"] != cap:
                bad += 1
        except (KeyError, TypeError):
            bad += 1
    lines.append(f"{'PASS' if not bad else 'FAIL'} cost model: every solved cost = (flops + steps) / {UNIT_OPS:g} with exact depth recorded and span = depth + steps, and every unsolved instance is charged the cap" + (f" ({bad} records disagree)" if bad else ""))
    ok = ok and not bad
    if rerun:
        if meta.get("python") != tflops.python_version():
            lines.append(f"SKIP re-run: ladder counted on {meta.get('python')}, this interpreter is {tflops.python_version()} (counts are only comparable on the same one)")
            return False, lines
        if solver_path is None and (not isinstance(meta["solver"], str) or meta["solver"] != os.path.basename(meta["solver"]) or meta["solver"] in ("", ".", "..")):
            lines.append(f"FAIL re-run: the ladder names its solver {meta['solver']!r}, which is not a plain file name: it will not be looked up on disk")
            return False, lines
        solver = solver_path or os.path.join(HERE, "solvers", meta["solver"])
        if not os.path.exists(solver) or tflops.sha256_file(solver) != meta["solver_sha256"]:
            lines.append(f"FAIL re-run: the solver file {meta['solver']} is missing here or its hash differs from the ladder's")
            return False, lines
        mod, derive, verify, d = tflops.load_family(meta["family"])
        if tflops.sha256_file(os.path.join(d, "decl.py")) != meta.get("decl_sha256"):
            lines.append("FAIL re-run: this checkout's decl.py differs from the one the ladder was made with")
            return False, lines
        if master is None or instances.commit(master) != meta["commit"]:
            lines.append("SKIP re-run: the seed given does not match the ladder's commitment (pass the revealed seed with --seed)")
            return False, lines
        k = len(recs) if rerun == "all" else min(int(rerun), len(recs))
        if k >= len(recs):
            pick = list(recs)
            lines.append(f"FULL AUDIT: all {len(recs)} records are re-executed")
        else:
            seed = secrets.randbits(64) if sample_seed is None else sample_seed
            pick = random.Random(seed).sample(recs, k)
            lines.append(f"sample: {k} of {len(recs)} records drawn at random (sample seed {seed})")
        same = 0
        key = lambda x: (x.get("status"), x.get("steps"), x.get("flops"), x.get("depth"))
        for r in pick:
            dim, idx = r["id"].split(":")
            again = count_instance(solver, derive(master, int(dim), int(idx)), verify, cap)
            if key(again) == key(r):
                same += 1
            else:
                lines.append(f"  differs at {r['id']}: recorded {key(r)}, re-run {key(again)}")
        good = same == len(pick)
        lines.append(f"{'PASS' if good else 'FAIL'} re-run: {same}/{len(pick)} instances re-executed with identical status, operations and depth")
        ok = ok and good
    return ok, lines


def _master(a):
    if a.seed:
        with open(a.seed, "rb") as f:
            return f.read().strip()
    return instances.PRACTICE_SEED


def cmd_practice(a):
    master = _master(a)
    tag = instances.commit(master)[:8]
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    paths = []
    for role, solver in (("baseline", a.baseline), ("submission", a.solver)):
        p = os.path.join(HERE, "results", f"tflopspar_{a.family}_{tag}_{role}_{os.path.basename(solver)}.jsonl")
        if os.path.exists(p) and role == "baseline" and a.reuse_baseline:
            ok, why = baseline_reusable(p, solver, a.family, master, a.dims, a.n, a.cap)
            if not ok:
                sys.exit(f"{p} exists but cannot be reused: {why}. Move it aside and run again.")
            paths.append(p)
            continue
        evaluate_ladder(solver, a.family, master, a.dims, a.n, a.cap, p, progress=lambda name, rec: print(f"  {name} {rec['id']}: {rec['status']} {rec.get('steps')}+{rec.get('flops')} ops, depth {rec.get('depth')}", flush=True))
        paths.append(p)
    print("ladders:\n  " + "\n  ".join(paths))
    print(NEXT_HINT)


def cmd_verify(a):
    master = _master(a)
    allok = True
    for p in a.ladders:
        ok, lines = verify_ladder(p, a.rerun, master, sample_seed=a.sample_seed)
        print(p)
        for ln in lines:
            print("  " + ln)
        allok = allok and ok
    print(("\nVERIFIED (costs consistent and re-executed as requested)" if a.rerun else "\nCONSISTENT ONLY: the cost arithmetic checks out, but nothing was re-executed (use --rerun K or --rerun all)") if allok else "\nNOT VERIFIED")
    print("What this does NOT show: " + CLAIM_LIMITS)
    sys.exit(0 if allok else 1)


def cmd_selfcheck(a):
    mod, derive, verify, d = tflops.load_family(a.family)
    inst = derive(instances.PRACTICE_SEED, a.dim, 0)
    x, y = count_instance(a.solver, inst, verify, a.cap), count_instance(a.solver, inst, verify, a.cap)
    key = lambda r: (r["status"], r.get("steps"), r.get("flops"), r.get("depth"))
    print(f"run 1: {x['status']} steps {x.get('steps')} flops {x.get('flops')} depth {x.get('depth')}\n"
          f"run 2: {y['status']} steps {y.get('steps')} flops {y.get('flops')} depth {y.get('depth')}\n" + ("IDENTICAL" if key(x) == key(y) else "DIFFERENT: not countable"))
    sys.exit(0 if key(x) == key(y) and x["status"] == "solved" else 1)


def main(argv=None):
    if sys.version_info < MIN_PYTHON:
        sys.exit("tflops_par needs Python 3.12 or newer")
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        sys.exit("tflops_par refuses to run as root: the solver is contained by a restricted subset, not a sandbox. Use an unprivileged throwaway user.")
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("practice")
    p.add_argument("solver")
    p.add_argument("--baseline", required=True)
    p.add_argument("--family", required=True)
    p.add_argument("--dims", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, default=8)
    p.add_argument("--cap", type=float, default=2000, help="budget in counted seconds (1 = 1e7 operations)")
    p.add_argument("--seed")
    p.add_argument("--reuse-baseline", action="store_true")
    p = sub.add_parser("verify")
    p.add_argument("ladders", nargs="+")
    p.add_argument("--rerun", type=lambda s: s if s == "all" else int(s), default=0, help="K random records to re-execute, or `all` for a full audit")
    p.add_argument("--sample-seed", type=int)
    p.add_argument("--seed")
    p = sub.add_parser("selfcheck")
    p.add_argument("solver")
    p.add_argument("--family", required=True)
    p.add_argument("--dim", type=int, required=True)
    p.add_argument("--cap", type=float, default=2000)
    a = ap.parse_args(argv)
    return {"practice": cmd_practice, "verify": cmd_verify, "selfcheck": cmd_selfcheck}[a.cmd](a)


if __name__ == "__main__":
    main()
