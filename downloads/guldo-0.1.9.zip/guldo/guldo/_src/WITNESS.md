# Running an independent witness for the Guldo certificate log

A witness is someone **other than the log operator** who checks that the log only ever grows and co-signs each head they have seen. One witness you do not control is worth more than ten you do: the operator's own witness proves nothing about independence, and a reader only counts a witness whose key **they** pinned.

If you cannot be a witness but still want to check the log, you do not have to be one: `guldo log check --log https://guldo.org/log --log-key LOGKEY --remember witness-seen.json` keeps your own memory of the last head you saw and catches a rollback or a rewritten history the next time you look. The log is also timestamped in Bitcoin and copied to the Internet Archive; `LOG.md` ("Without witnesses") says what each does and does not show.

## What you are vouching for

* **Always:** the log is append-only from the first head you saw. If the operator ever shows you a head that is not an extension of the last one you signed, you keep both signed heads. Together they are transferable proof of equivocation, and the log is finished.
* **With `--recheck`:** each entry's recorded fields are recomputed from its certificate under your checkout of the protocol code. That catches an operator who signs an entry claiming more than its certificate says. It needs a checkout of the same protocol code the certificates were built under.
* **Never:** that a certificate's claimed speed-up is true in the world. The log records that a certificate verified; it does not re-run anyone's solver.

## Set up (once, about five minutes)

```
pip install "guldo-cli[attest]"
guldo attest keygen --out witness.key
```

The `[attest]` extra installs the `cryptography` package. Without it the tool cannot check or make signatures, and it says so (a check without it ends in `PROBLEMS FOUND`, never in a false `OK`).

`witness.key` is yours; keep it private and back it up. Send the operator the **public key** it prints, and publish it yourself (your site, a signed message) so readers can pin it from a source other than the operator.

## Every day (or whenever a head changes)

```
guldo log witness --log https://guldo.org/log --state witness-state.json --key witness.key --log-key LOGKEY --recheck --out cosig.json
```

`LOGKEY` is the log's public key, which you must obtain **out of band** from the operator (not from the log's own page, which a hostile mirror could rewrite). Keep `witness-state.json`: it is your memory of the last head you saw, and it is what makes equivocation provable. Send `cosig.json` to the operator, or post it somewhere public; the operator merges it with `guldo log add-cosig LOGDIR cosig.json`.

## If the command says something is wrong

* `append-only` FAIL: the log is not an extension of what you saw. Do not co-sign. Keep `witness-state.json` and write the evidence by adding `--evidence equivocation.json` to the same witness command; anyone can then confirm it with `guldo log check-evidence equivocation.json --log-key LOGKEY`.
* `recheck` FAIL or SKIP: your checkout differs from the operator's. Check out the version the certificates name before concluding anything. `--allow-unknown` co-signs anyway, and records that you did.

## What readers can then do

```
guldo log check --log https://guldo.org/log --log-key LOGKEY --trusted witness-keys.txt --recheck
```

`witness-keys.txt` is a file of public keys (hex, one per line) the reader obtained out of band. Only those keys count as independent.
