"""Deterministic step counting: a cost that EVERYONE re-running gets exactly, instead of seconds that depend on a machine and a sandbox.

  counted.py evaluate --family F --seed-file S --submission X.py --dims 38 40 42 [--n 12] [--cap 20] [--baseline B.py] [--results-dir R]
  counted.py check    SOLVER.py --family F --dim 16        run one instance twice: are the two counts identical on this interpreter?

The cost of an instance is the number of Python bytecode instructions the solver executes (count_runner.py: sys.monitoring, Python 3.12+), divided by
STEPS_PER_SECOND to give "counted seconds", so the existing estimator, certificates and site read these ladders unchanged. Two programs that execute
the same instructions on the same input get the same number on any machine, so a verifier does not have to trust the operator's hardware, sandbox or
clock: it re-executes and compares, and equality is the proof (certificate.py verify --rerun K --execute).

WHAT THIS PROVES, AND WHAT IT DOES NOT. It proves the recorded cost of each re-run instance is exactly what that program executes, for this Python
version. It does NOT measure time, and it is blind to work done inside a C function: `pow(a, b, m)` on huge integers, `sorted`, `sum`, numpy and
fpylll each count as ONE instruction however long they run. A solver can therefore move its work into a C call and look free, so a counted result is
meaningful only when the work is in Python code on both sides, and it is not a comparison of an algorithm that leans on C builtins against one that
does not. The ladder (the sizes, how many instances, the cap) is chosen by whoever ran it: a counted certificate is not an official round result.
Counting is also slow (a callback per instruction, roughly 100x), so counted ladders use small sizes and a small cap. The solver runs in a restricted subset of Python
that count_runner.py enforces (pure computation; see its docstring and COMPILER.md), which protects the counter's integrity but is an in-process sandbox, not operating-system
isolation: for code you did not write, still use a throwaway user or VM.
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time

import count_runner   # (its check_source is the restricted-subset rule; importing it defines functions only, main() runs only as a script)
import families
import instances

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(HERE, "count_runner.py")
STEPS_PER_SECOND = 1_000_000        # 1 "counted second" = one million bytecode instructions. It is only a UNIT, not a duration: it is chosen so that the estimator's
#                                     0.5 s cost floor (a size counts only if its typical cost reaches it) is 500,000 instructions, which counting can reach. With
#                                     5e7 the floor would be 25 million instructions per solver and no counted ladder could ever be conclusive.
SLOW_STEPS_PER_SECOND = 300_000     # a PESSIMISTIC counting throughput: used only for the wall-clock backstop and for cost estimates
MIN_PYTHON = (3, 12)


def supported():
    return sys.version_info >= MIN_PYTHON


def python_version():
    """Identifies the interpreter whose counts a certificate records: instruction counts are only comparable on the same one."""
    v = sys.version_info
    return f"{sys.implementation.name} {v.major}.{v.minor}.{v.micro}"


def count_instance(solver, inst, cap_seconds):
    """Run `solver` on `inst` under exact counting. -> a ladder record: id, dim, status (solved / failed / wrong / crash / timeout), steps, cpu, cpu_net, wall.
    A timeout is a solver that used more than cap_seconds * STEPS_PER_SECOND instructions (deterministic), or, rarely, hit the wall-clock backstop."""
    limit = int(cap_seconds * STEPS_PER_SECOND)
    rec = {"id": inst["id"], "dim": inst["dim"]}
    payload = json.dumps({"args": inst["args"], "limit": limit})
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "PATH": os.environ.get("PATH", "")}   # no environment variable of this machine reaches the solver (the count still depends on the Python version and on the solver being deterministic)
    t0 = time.time()
    with tempfile.TemporaryDirectory() as empty:
        try:
            r = subprocess.run([sys.executable, "-B", RUNNER, os.path.abspath(solver)], input=payload.encode(), capture_output=True, env=env, cwd=empty,
                               timeout=limit / SLOW_STEPS_PER_SECOND + 60)
        except subprocess.TimeoutExpired:
            rec.update({"status": "timeout", "steps": None, "wall_timeout": True, "cpu": cap_seconds, "cpu_net": cap_seconds, "wall": time.time() - t0})
            return rec
    rec["wall"] = time.time() - t0
    lines = [ln for ln in r.stdout.decode(errors="replace").splitlines() if ln.strip()]
    try:
        out = json.loads(lines[-1])
        steps = int(out["steps"])
        status = out["status"]
    except (IndexError, ValueError, KeyError, TypeError):
        rec.update({"status": "crash", "steps": None, "cpu": cap_seconds, "cpu_net": cap_seconds,
                    "err": ("the counter produced no result: " + r.stderr.decode(errors="replace")[-300:])})
        return rec
    rec["steps"] = steps
    if status == "limit":
        rec.update({"status": "timeout", "cpu": cap_seconds, "cpu_net": cap_seconds})
    elif status == "error":
        rec.update({"status": "crash", "cpu": cap_seconds, "cpu_net": cap_seconds, "err": str(out.get("err", ""))[-1500:]})
    else:
        ans = out.get("ans")
        try:
            ok = families.verify(inst, ans)
        except Exception:
            ok = False
        rec["status"] = "solved" if ok else ("failed" if ans is None else "wrong")
        rec["cpu"] = steps / STEPS_PER_SECOND
        rec["cpu_net"] = max(rec["cpu"], 1e-3)       # the same floor the harness applies; a unit conversion, not a measurement
    return rec


def counter_sha256():
    """Hash of the counting program. It is not one of the round protocol's hashed files, so every counted ladder and certificate records it: counts made by a
    different (or doctored) counter are then named as such, and a later fix to the counter cannot silently change what an old certificate means."""
    with open(RUNNER, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def ladder_header(solver, family, master, cap):
    with open(solver, "rb") as f:
        sha = hashlib.sha256(f.read()).hexdigest()
    return {"meta": True, "solver": os.path.basename(solver), "commit": instances.commit(master), "overhead": 0.0, "budget": cap, "family": family,
            "sandbox": "count", "instance_version": families.VERSIONS[family], "image": None, "host": "deterministic step counting (no machine timing)",
            "cpu": "none: instruction counts", "ncpu": 1, "jobs": 1, "solver_sha256": sha,
            "cost_model": "count", "steps_per_second": STEPS_PER_SECOND, "python": python_version(), "counter_sha256": counter_sha256()}


def evaluate_ladder(solver, family, master, dims, n, cap, out_path, progress=None):
    """One ladder file: a header, then the counted record of every (dim, idx). Never overwrites an existing file."""
    if os.path.exists(out_path):
        raise FileExistsError(out_path)
    recs = []
    fd = os.open(out_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps(ladder_header(solver, family, master, cap)) + "\n")
        for dim in dims:
            for idx in range(n):
                rec = count_instance(solver, families.derive(family, master, dim, idx), cap)
                f.write(json.dumps(rec) + "\n")
                f.flush()
                recs.append(rec)
                if progress:
                    progress(os.path.basename(solver), rec)
    return recs


def c_extension_imports(path):
    """Libraries whose work happens inside C and so counts as ONE instruction however long it runs: a counted run that leans on them says almost nothing."""
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError:
        return []
    return sorted(set(re.findall(r"^\s*(?:import|from)\s+(numpy|scipy|fpylll|gmpy2|sympy|cython|cysignals)\b", text, re.M)))


def source_problems(text):
    """-> [problems]: why this source cannot be run by the counter, or [] if it is inside the restricted subset a counted solver is written in (count_runner.check_source:
    an AST whitelist, no dunder/private/frame attributes, no getattr/type/open/eval/exec, imports only from a few pure modules). The counter enforces the same rules when it
    loads the solver, so this is the SAME check, made early: a counted round refuses such a source at submission, and `practice --count` before it spends any time. Because the
    rules live in count_runner.py they are pinned by the counter hash."""
    return count_runner.check_source(text)


def family_problem(family):
    """None if `family` can be counted, otherwise why not. Its baseline must be pure Python: a credit is a ratio against the baseline, and work hidden in C is free."""
    import judge   # (lazily: judge imports the harness)
    if family not in families.FAMILIES:
        return f"unknown family {family!r}"
    base = judge.default_baseline(family)
    ext = c_extension_imports(base)
    if ext:
        return (f"the default baseline for {family} imports {', '.join(ext)}, so its work happens inside C and counts as almost nothing: a counted credit against it would be "
                "meaningless (step counting needs a pure-Python baseline)")
    try:
        with open(base, encoding="utf-8") as f:
            problems = source_problems(f.read())
    except (OSError, UnicodeDecodeError) as e:
        return f"the default baseline for {family} cannot be read ({type(e).__name__})"
    if problems:   # the counter runs the baseline in the same restricted subset as every submission
        return f"the default baseline for {family} is outside the restricted subset the counter runs solvers in: " + "; ".join(problems[:3])
    return None


def baseline_reusable(path, solver, family, master, dims, n, cap):
    """(ok, why). A baseline ladder already on disk may be reused only if it is exactly what this evaluation would write: the same header (seed commitment, baseline
    file hash, family, cap, instance version, unit, interpreter and counter) and a record for every (size, index). Counting is deterministic, so a complete
    identical ladder is the same measurement."""
    try:
        with open(path, encoding="utf-8") as f:
            lines = [ln for ln in f.read().splitlines() if ln.strip()]
        meta = json.loads(lines[0])
        recs = [json.loads(ln) for ln in lines[1:]]
    except (OSError, ValueError, IndexError):
        return False, "no readable ladder"
    if meta != ladder_header(solver, family, master, cap):
        return False, "its header differs (another seed, baseline file, cap, unit, Python or counter)"
    want = {f"{d}:{i}" for d in dims for i in range(n)}
    have = [r.get("id") for r in recs]
    if len(have) != len(set(have)) or set(have) != want:
        return False, "incomplete or with unexpected instances"
    return True, ""


def evaluate_seed(family, seed_file, submission, baseline, dims, n, cap, results_dir, progress=None, reuse_baseline=False):
    """The baseline ladder and the submission's ladder for ONE seed, written where judge.py writes its own (so certificate.py finds them).
    reuse_baseline: a round counts many submissions against ONE baseline, so an identical complete baseline ladder already on disk is kept (anything else that
    is already there is refused, never overwritten). -> (seed tag, baseline ladder path, submission ladder path)."""
    with open(seed_file, "rb") as f:
        master = f.read().strip()
    tag = hashlib.sha256(master).hexdigest()[:8]
    paths = []
    for role, solver in (("baseline", baseline), ("submission", submission)):
        p = os.path.join(results_dir, f"judged_{family}_{tag}_{role}_{os.path.basename(solver)}.jsonl")
        if role == "baseline" and reuse_baseline and os.path.exists(p):
            ok, why = baseline_reusable(p, solver, family, master, dims, n, cap)
            if not ok:
                raise FileExistsError(f"{p} exists but is not the complete, identical baseline ladder ({why}): move it aside and run again")
            paths.append(p)
            continue
        evaluate_ladder(solver, family, master, dims, n, cap, p, progress)
        paths.append(p)
    return tag, paths[0], paths[1]


def selfcheck(solver, family, dim, cap, master=instances.PRACTICE_SEED, idx=0):
    """Run one instance twice. -> (identical?, first record, second record). A solver or interpreter that is not deterministic cannot be certified."""
    inst = families.derive(family, master, dim, idx)
    a, b = count_instance(solver, inst, cap), count_instance(solver, inst, cap)
    return (a.get("steps") == b.get("steps") and a.get("status") == b.get("status")), a, b


def selfcheck_problem(label, same, a, b):
    """None when the two runs agree AND solved the question; otherwise the reason this solver cannot be counted. Two identical crashes or timeouts are
    'deterministic' but useless: a whole run of them would be charged the cap on every question and certify nothing."""
    if not same:
        return f"{label} is not deterministic under step counting ({a.get('steps')} vs {b.get('steps')} steps on the same input): it cannot be certified this way"
    if a.get("status") != "solved":
        why = {"timeout": "it used more than the whole budget (raise --cap or choose a smaller size)", "crash": "it crashed: " + str(a.get("err", ""))[-200:],
               "failed": "it returned no answer", "wrong": "it returned a wrong answer"}.get(a.get("status"), a.get("status"))
        return f"{label} did not solve the smallest question: {why}"
    return None


def worst_case_seconds(dims, n, cap, seeds=3):
    """A pessimistic wall-clock bound for counting a whole practice run (every instance spending its whole cap at the slow throughput)."""
    return len(dims) * n * 2 * seeds * cap * STEPS_PER_SECOND / SLOW_STEPS_PER_SECOND


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("evaluate")
    p.add_argument("--family", required=True)
    p.add_argument("--seed-file", required=True)
    p.add_argument("--submission", required=True)
    p.add_argument("--baseline")
    p.add_argument("--dims", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, default=12)
    p.add_argument("--cap", type=float, default=20.0, help="the most counted seconds (x 1e6 instructions) one instance may use; to be usable at all a size must "
                   "cost the solver at least 0.5 (the estimator's floor), so the baseline needs a few counted seconds")
    p.add_argument("--results-dir", default=os.path.join(HERE, "results"))
    p = sub.add_parser("check")
    p.add_argument("solver")
    p.add_argument("--family", required=True)
    p.add_argument("--dim", type=int, required=True)
    p.add_argument("--cap", type=float, default=20.0)
    a = ap.parse_args(argv)
    if not supported():
        raise SystemExit(f"REFUSED: step counting needs Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer (this is {python_version()})")
    if a.family not in families.FAMILIES:
        raise SystemExit(f"REFUSED: unknown family {a.family!r}")
    if a.cmd == "check":
        same, x, y = selfcheck(a.solver, a.family, a.dim, a.cap)
        problem = selfcheck_problem("this solver", same, x, y)
        print(f"run 1: {x['status']} {x.get('steps')} steps\nrun 2: {y['status']} {y.get('steps')} steps\n"
              + ("DETERMINISTIC, and it solved the question" if problem is None else "NOT USABLE: " + problem))
        return 0 if problem is None else 1
    import certificate   # (lazily: certificate imports this module)
    if a.n < 1 or not (0 < a.cap <= certificate.MAX_COUNTED_CAP) or not a.dims or min(a.dims) < 1:
        raise SystemExit(f"REFUSED: --n and --dims must be positive and --cap a number between 0 and {certificate.MAX_COUNTED_CAP:g}")
    import judge
    baseline = a.baseline or judge.default_baseline(a.family)
    tag, bp, sp = evaluate_seed(a.family, a.seed_file, a.submission, baseline, a.dims, a.n, a.cap, a.results_dir,
                                lambda name, rec: print(f"{name:22s} {rec['id']:>7s} {rec['status']:8s} {rec.get('steps')}", flush=True))
    print(f"wrote {bp}\nwrote {sp}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
