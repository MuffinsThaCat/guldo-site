"""Declaration of a recovery domain: Ring-LWE secret recovery in R_q = Z_q[x]/(x^n - x - 1), q a prime near 3329 chosen per n so that
x^n - x - 1 is irreducible mod q (R_q is a field; the NTRU Prime / NTRU LPRime ring).

A solver receives (q, a, b, W) with b = a*s + e in R_q, a uniform, s a ternary secret (coefficients in {-1, 0, 1}) and e noise with
coefficients in [-W, W]. It returns the secret s as a list of n ints. Any s that the verifier accepts counts: ternary, and every
coefficient of b - a*s (centred mod q) within [-W, W]. At these parameters (q about 3329, W = 2, n >= 6) the planted s is the only such vector
with overwhelming probability, so "any accepted answer" and "the planted secret" coincide, but the judge never relies on that.

size = the ring dimension n. The reference is a meet-in-the-middle search over the 3^n ternary secrets (about 3^(n/2) work), so every extra
dimension multiplies its cost by ~1.7. The field ring replaces x^n + 1, whose zero-divisors (for n not a power of two) are a leak. This is a RECOVERY problem, not an SVP problem: the solver is not handed a basis or a target norm, only the ring-LWE sample, so
a submission may use any route (primal lattice attack, the algebraic/SAT encoding, a meet-in-the-middle, ring-aware sieving). Guldo
measures end-to-end time to a verified secret; it does not say where a speedup comes from.
"""
import hashlib
import hmac
import random

NAME = "rlwe"
VERSION = "rlwe-v3"           # bump whenever derive() changes
SIZE_RANGE = (22, 27)       # ring dimensions n the compiler may use
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
W = 2
DOC = ("solve(q, a, b, W): a, b are length-n coefficient lists of ring elements of Z_q[x]/(x^n - x - 1), q prime, lowest degree first, with b = a*s + e. "
       "Return the secret s as a list of n ints in {-1, 0, 1} such that every coefficient of b - a*s (reduced mod q, centred) has absolute value <= W. "
       "Return None for no answer.")
REFERENCE_NOTE = ("The reference is a meet-in-the-middle search over ternary secrets (about 3^(n/2) work, a two-coefficient bucket key and 25 noise offsets). Lattice reduction (LLL/BKZ on the "
                  "q-ary embedding), the Smart algebraic/SAT encoding are known to beat it by a wide margin as n grows; "
                  "no claim is made here about which is fastest. Scope: this measures speedup over a meet-in-the-middle baseline on toy rings (n <= 27, ternary secret, noise <= 2), "
                  "where lattice reduction wins by a very large margin; it is NOT evidence about attacks on cryptographic parameters (n = 256 and up), "
                  "and a certificate here must not be read as one.")


def _centre(x, q):
    x %= q
    return x - q if x > q // 2 else x


def mulmod(a, s, q):
    """a * s in Z_q[x]/(x^n - x - 1), coefficient lists of equal length n."""
    n = len(a)
    out = [0] * (2 * n - 1)
    for i in range(n):
        if a[i]:
            for j in range(n):
                out[i + j] += a[i] * s[j]
    for k in range(2 * n - 2, n - 1, -1):  # x^k = x^(k-n) * (x + 1); k - n + 1 <= n - 1, so one pass suffices
        c = out[k]
        out[k - n] += c
        out[k - n + 1] += c
    return [c % q for c in out[:n]]


def _is_prime(q):
    return q > 1 and all(q % d for d in range(2, int(q ** 0.5) + 1))


def _trim(p):
    while p and p[-1] == 0:
        p.pop()
    return p


def _gcd_is_one(a, b, q):
    """gcd of two polynomials over F_q (lowest degree first) is a nonzero constant."""
    a, b = _trim([c % q for c in a]), _trim([c % q for c in b])
    while b:
        inv = pow(b[-1], -1, q)
        while len(a) >= len(b):
            c = a[-1] * inv % q
            sh = len(a) - len(b)
            for i, bi in enumerate(b):
                a[sh + i] = (a[sh + i] - c * bi) % q
            _trim(a)
            if not a:
                break
        a, b = b, a
    return len(a) == 1


def _powmod(base, e, q, n):
    result = [1] + [0] * (n - 1)
    while e:
        if e & 1:
            result = mulmod(result, base, q)
        base = mulmod(base, base, q)
        e >>= 1
    return result


def _irreducible(n, q):
    """Rabin's test for x^n - x - 1 over F_q."""
    f = [-1, -1] + [0] * (n - 2) + [1]
    X = [0, 1] + [0] * (n - 2)
    frob = [X]                       # frob[k] = x^(q^k) mod f
    for _ in range(n):
        frob.append(_powmod(frob[-1], q, q, n))
    if frob[n] != X:
        return False
    for r in range(2, n + 1):
        if n % r == 0 and _is_prime(r):
            d = [(a - b) % q for a, b in zip(frob[n // r], X)]
            if not _gcd_is_one(f, d, q):
                return False
    return True


_Q_CACHE = {}


def modulus(n):
    """The first prime q >= 3329 for which x^n - x - 1 is irreducible mod q (so R_q is a field); a pure function of n."""
    if n not in _Q_CACHE:
        q = 3329
        while not (_is_prime(q) and _irreducible(n, q)):
            q += 1
        _Q_CACHE[n] = q
    return _Q_CACHE[n]


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"rlwe-v3:{size}:{idx}".encode(), hashlib.sha256).digest())
    n = size
    q = modulus(n)
    a = [rng.randrange(q) for _ in range(n)]
    while True:
        s = [rng.choice((-1, 0, 1)) for _ in range(n)]
        if sum(map(bool, s)) >= n // 2:  # not the zero or a near-zero secret
            break
    e = [rng.randint(-W, W) for _ in range(n)]
    b = [(x + y) % q for x, y in zip(mulmod(a, s, q), e)]
    return {"args": [q, a, b, W], "planted": s}


def verify(inst: dict, ans) -> bool:
    q, a, b, w = inst["args"]
    n = len(a)
    if not isinstance(ans, list) or len(ans) != n:
        return False
    for c in ans:
        if isinstance(c, bool) or not isinstance(c, int) or c not in (-1, 0, 1):
            return False
    prod = mulmod(a, ans, q)
    return all(abs(_centre(bi - pi, q)) <= w for bi, pi in zip(b, prod))
