"""aisecond in the counted-operations API, TECHNIQUE: Newton's method. Form the Hessian H = X^T diag(p(1-p)) X / N + lambda I, solve H step = gradient exactly by Gauss-Jordan elimination
(no pivoting: H is symmetric positive definite), step, repeat until the gradient is small enough that the loss is within the target of the minimum (|g|^2/(2 lambda) bounds the gap). Newton converges
quadratically near the minimum and ignores the conditioning that makes gradient descent crawl; it costs one N x d x d product per iteration."""
import math

import tensorops as tp

RHO = 0.97
LAM = 1e-4
MAXITER = 30
GRAD2 = 2e-13          # gap <= |g|^2 / (2 lambda) <= 1e-9 (a margin of 10 under the judge's 1e-8)


def solve_spd(H, g, d):
    """Solve H x = g by Gauss-Jordan on the augmented matrix [H | g]."""
    A = tp.concat([H, tp.reshape(g, (d, 1))], 1)
    for k in range(d):
        row = A[k:k + 1] / A[k:k + 1, k:k + 1]
        M = A - A[:, k:k + 1] * row
        A = tp.concat([M[0:k], row, M[k + 1:d]], 0)
    return tp.reshape(A[:, d:d + 1], (d,))


def solve(seed, d, n, labels):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    X = (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)
    y = tp.tensor([float(v) for v in labels])
    Xt = tp.transpose(X, (1, 0))
    eye = tp.tensor([[LAM if i == j else 0.0 for j in range(d)] for i in range(d)])
    w = tp.zeros((d,))
    for it in range(MAXITER):
        p = 1.0 / (1.0 + tp.exp(-(X @ w)))
        g = Xt @ (p - y) * (1.0 / n) + w * LAM
        if tp.sum(g * g).item() <= GRAD2:
            break
        H = (Xt * tp.reshape(p * (1.0 - p), (1, n))) @ X * (1.0 / n) + eye
        w = w - solve_spd(H, g, d)
    return [int(v * 1048576.0) for v in w.tolist()]
