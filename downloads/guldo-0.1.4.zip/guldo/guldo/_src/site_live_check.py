"""Check the PUBLISHED static site: read-only GETs, nothing is sent or changed.

  python3 site_live_check.py https://guldo.org

It checks that every page answers over HTTPS, that the page links resolve, and that the download on the Install page is exactly the file whose SHA-256 the page shows
(the check that tells you a visitor really gets what the page says). Exit 0: all passed, 1: something failed, 2: the site could not be reached. For the dynamic
submission service use deploy_smoke.py instead; this is only for the static site.
"""
import hashlib
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

PAGES = ["index.html", "install.html", "domains.html", "guide.html", "method.html", "results.html", "preregistrations.html", "compete.html", "certify.html", "log.html", "claims.html", "limits.html", "audit.html"]


def get(url, binary=False):
    req = urllib.request.Request(url, headers={"User-Agent": "guldo-site-check"})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read(64 * 1024 * 1024)
        return r.status, (data if binary else data.decode("utf-8", "replace")), r.geturl()


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1 or not argv[0].startswith(("http://", "https://")):
        print("usage: site_live_check.py https://your.domain", file=sys.stderr)
        return 2
    base = argv[0].rstrip("/") + "/"
    results = []

    def check(name, ok, detail=""):
        results.append(ok)
        print(f"  {'PASS' if ok else 'FAIL'} {name}{': ' + detail if detail else ''}")
    try:
        status, text, final = get(base)
    except (urllib.error.URLError, OSError, ValueError) as e:
        print(f"could not reach {base}: {e}", file=sys.stderr)
        return 2
    check("home page answers", status == 200, final)
    check("served over HTTPS", final.startswith("https://"), "the address you gave redirects to " + final if not final.startswith("https://") else "")
    bodies = {}
    for page in PAGES:
        try:
            s, t, _ = get(urllib.parse.urljoin(base, page))
            bodies[page] = t
            check(f"{page}", s == 200 and "<h1" in t)
        except (urllib.error.URLError, OSError) as e:
            check(f"{page}", False, str(e)[:100])
    missing = []
    for page, t in bodies.items():
        for href in re.findall(r'href="([^"#?]+)"', t):
            if re.match(r"^(https?:|mailto:|data:)", href):
                continue
            try:
                get(urllib.parse.urljoin(urllib.parse.urljoin(base, page), href))
            except (urllib.error.URLError, OSError):
                missing.append(f"{page} -> {href}")
    check("every internal link resolves", not missing, "; ".join(sorted(set(missing))[:5]))
    install = bodies.get("install.html", "")
    m = re.search(r'href="(downloads/([A-Za-z0-9._-]+\.zip))"', install)
    h = re.search(r"\b([0-9a-f]{64})\b", install)
    if not (m and h):
        check("the Install page shows a download and its SHA-256", False, "not found")
    else:
        try:
            _, data, _ = get(urllib.parse.urljoin(base, m.group(1)), binary=True)
            got = hashlib.sha256(data).hexdigest()
            check("the download matches the hash on the page", got == h.group(1), f"{m.group(2)}: page says {h.group(1)[:16]}..., file is {got[:16]}...")
        except (urllib.error.URLError, OSError) as e:
            check("the download can be fetched", False, str(e)[:100])
    print("ALL PASSED" if all(results) else "SOMETHING FAILED")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
