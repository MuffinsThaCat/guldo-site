"""aitrain in the counted-operations API, TECHNIQUE: heavy-ball momentum (0.9) on the raw features, learning rate 2.0, 1500 steps."""
import math

import tensorops as tp

K = 3
KAPPA = 30.0
STEPS = 1500
LR = 2.0
MU = 0.9


def solve(seed, d, n, labels):
    sc = tp.tensor([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = tp.reshape(tp.stream(seed, 0, n * d), (n, d)) * sc
    Y = tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(n)])
    Xt = tp.transpose(X, (1, 0))
    W = tp.zeros((d, K))
    V = tp.zeros((d, K))
    for step in range(STEPS):
        Z = X @ W
        E = tp.exp(Z - tp.max(Z, 1, True))
        V = V * MU - (Xt @ (E / tp.sum(E, 1, True) - Y)) * (LR / n)
        W = W + V
    return [int(x * 1048576.0) for x in tp.reshape(W, (d * K,)).tolist()]
