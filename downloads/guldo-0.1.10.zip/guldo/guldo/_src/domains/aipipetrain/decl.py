"""Declaration of a PIPELINE-PARALLEL TRAINING domain with a per-device MEMORY CAP: the exact gradient of an 8-layer network over a batch, on 4 devices, where what fits in a device's memory decides what is allowed.

size = d. An 8-layer network of width d: h_0 = x (B x d, B = 8 d), a_l = h_{l-1} W_l and h_l = relu(a_l) for l = 1..7, output y = a_8 = h_7 W_8; loss L = 0.5 * mean over the B*d entries of (y - T)^2. x, T (B x d) and
W_1 .. W_8 (d x d, scaled by sqrt(3/d)) are the SplitMix64 stream under `seed` (tensorops.stream, the same floats as domains/aiinfer), in that order, row-major. The answer is the gradient [dL/dW_1, ..., dL/dW_8] as ONE
flat list of 8 d^2 INTEGERS in units of 2^-40, accepted within 1e-6 of its norm. A gradient taken from a stale activation, a microbatch left out, or a stage whose gradient was not gathered fails the check.

THE MACHINE. 4 devices on one node (tensorops_dist3.py, version 3 of the cluster counter), each able to hold at most device_cap(d) = 160 d^2 BYTES (20 d^2 numbers; one microbatch row is d numbers). That is what makes the strategies differ:
  - one device cannot do it (the 8 weight matrices, their gradients and the activations of the whole batch do not fit);
  - a pipeline of 4 stages, 2 layers each, can, if it does not keep too much: GPIPE (all forward passes of all microbatches, then all backward passes) must keep the activations of the WHOLE batch until the
    backward pass reaches them, however many microbatches it cuts it into; 1F1B (one forward, one backward, in turn) keeps at most as many microbatches in flight as there are stages from its own to the last,
    so its memory falls as the microbatches get smaller; RECOMPUTATION keeps only the input of each stage per microbatch and redoes the stage's first layer in the backward pass: less memory for more arithmetic.
A pipeline is also slower than it looks: its bubble (stages waiting for the first and last microbatches) shrinks with more microbatches, which send more, smaller messages. Which schedule is fastest on which machine, and which
do not fit at all, is computed (work, rounds, bytes, peak bytes per device: tflops_dist3.py), not argued. It is an accounting convention over identical devices (see tensorops_dist3.py), not a measurement.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aipipetrain"
VERSION = "aipipetrain-v1"    # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 48)
SIZE_STEP = 8
REFERENCE_SOLVER = "reference.py"
RANKS = 4                     # devices the instance has, one node
LAYERS = 8
SCALE = 2 ** 40
LIMIT = 2 ** 62
REL_TOL = 1e-6
CAP_PER_D2 = 160              # bytes one device may hold, per d^2


def device_cap(size):
    """The most bytes one device may hold on instances of this size."""
    return int(CAP_PER_D2 * size * size)


DOC = ("solve(seed, d, B, P): an 8-layer network of width d on a batch of B = 8d rows: h_0 = x (B x d), a_l = h_{l-1} W_l, h_l = relu(a_l) for l = 1..7, y = a_8; loss = 0.5 * mean over the B*d entries of "
       "(y - T)^2; x, T (B x d) and W_1..W_8 (d x d, times sqrt(3/d)) are the SplitMix64 stream under `seed` (tensorops.stream, u in [-1, 1), row-major, in that order). P = 4 devices (tp.use(k), tp.exchange, "
       "tp.all_gather, ...), each able to hold at most 160 d^2 bytes (a run that exceeds it ends with an error). Return the gradient [dL/dW_1, ..., dL/dW_8] (each d x d row-major) as one flat list of 8 d^2 "
       "integers in units of 2^-40, within 1e-6 of its norm. Return None for no answer.")
REFERENCE_NOTE = ("The dense gradient on one device in float64 (the judge's own computation). On the counted cluster one device cannot hold it: a pipeline of the four devices is the way, and the schedule decides "
                  "how many microbatches it can afford.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def parts(seed, d):
    B = 8 * d
    x = _uniform(seed, 0, B * d).reshape(B, d)
    T = _uniform(seed, B * d, B * d).reshape(B, d)
    Ws = [_uniform(seed, 2 * B * d + l * d * d, d * d).reshape(d, d) * math.sqrt(3.0 / d) for l in range(LAYERS)]
    return x, T, Ws


def gradient(seed, d):
    x, T, Ws = parts(seed, d)
    B = len(x)
    hs, masks = [x], []
    for l in range(LAYERS - 1):
        a = hs[-1] @ Ws[l]
        hs.append(np.maximum(a, 0.0))
        masks.append(a > 0)
    y = hs[-1] @ Ws[-1]
    g = (y - T) / (B * d)
    grads = [None] * LAYERS
    for l in range(LAYERS - 1, -1, -1):
        grads[l] = hs[l].T @ g
        if l:
            g = (g @ Ws[l].T) * masks[l - 1]
    return np.concatenate([w.ravel() for w in grads])


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aipipetrain-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, 8 * size, RANKS], "planted": [int(v) for v in np.rint(gradient(seed, size) * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, d, B, P = inst["args"]
    n = LAYERS * d * d
    if not isinstance(ans, list) or len(ans) != n:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    true = gradient(seed, d)
    got = np.array(ans, dtype=np.float64) / SCALE
    return bool(np.linalg.norm(got - true) <= REL_TOL * np.linalg.norm(true) + n * 2.0 ** -40)
