"""aikfac in the counted-operations API, REFERENCE: plain full-batch gradient descent on the L2-regularised softmax loss, step 1/L with L = |X|_F^2/(2N) + lambda, 20000 steps."""
import math

import tensorops as tp

K = 8
RHO = 0.9
LAM = 1e-3
GRAD2 = 2e-13          # gap <= |g|^2 / (2 lambda) <= 1e-10 (a margin of 100 under the judge's 1e-8)


def features(seed, n, N):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(n)] for k in range(n)])
    return (tp.reshape(tp.stream(seed, 0, N * n), (N, n)) @ U) * math.sqrt(1.0 - RHO * RHO)


def onehot(labels, N):
    return tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(N)])


def softmax(S):
    E = tp.exp(S - tp.max(S, 1, True))
    return E / tp.sum(E, 1, True)


def answer(W, n):
    return [int(v * 1048576.0) for v in tp.reshape(W, (n * K,)).tolist()]
STEPS = 20000


def solve(seed, n, N, labels):
    X = features(seed, n, N)
    Y = onehot(labels, N)
    Xt = tp.transpose(X, (1, 0))
    lr = 1.0 / (tp.sum(X * X).item() / (2.0 * N) + LAM)
    W = tp.zeros((n, K))
    for step in range(STEPS):
        W = W - (Xt @ (softmax(X @ W) - Y) * (1.0 / N) + W * LAM) * lr
    return answer(W, n)
