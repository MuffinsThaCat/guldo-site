"""A joint seed: no single party chooses, or can foresee, the instances a round is judged on.

A round's instances come from one secret seed, committed before the run. With ONE seed holder, that holder can (a) choose a seed that flatters a favourite, or tune one after seeing earlier runs, and (b)
leak the instances. A joint seed removes (a): the master seed is a hash of EVERY party's secret share, each party SIGNS a commitment to its share before any share is revealed to anyone, and the
combined seed is only computable once all shares are in. Whoever commits last still does not know the others' shares, so nobody can steer the result; an honest party's share alone makes the seed
unpredictable to everyone else. It does NOT remove (b): whoever holds the combined seed during the run (the party hosting the tool service) could leak instances. That is the trust you place in the
host, which is why the host is the independent verifier, and why more than one verifier can be asked to run the same plan with their own seeds (agent_verifier.quorum).

THE CEREMONY (a ceremony id, usually the round id, is mixed into everything: shares and commitments cannot be replayed into another round)
  1. Each party makes a share and a SIGNED COMMITMENT  C = sha256("guldo-joint-commit-v1|" ceremony "|" party "|" share), signed with its own identity key, and publishes the commitment ONLY.
  2. When every commitment is published, each party hands its share to the seed host (privately).
  3. The host checks each share against its signed commitment, combines:  master = sha256("guldo-joint-seed-v1|" ceremony "|" party=share ... sorted by party)  (hex), and uses it as the round's
     seed (the round commits to `commitment(master)` as always).
  4. At the reveal the host publishes the shares; anyone recomputes the master, every commitment and every signature (`verify`).
A party that withholds its share stops the ceremony BEFORE any instance exists: nothing was run, nothing is lost but time.

LIMITS. The signatures show that the same key committed and that the revealed share matches; they do not show WHO holds a key (pin the keys you recognise: `verify(..., trusted=)`), nor WHEN a commitment
was made: a commitment is only as early as the place it was published (a public, append-only place: a transparency log, a post with a timestamp). If the host is also every other party, the joint seed is
one party's seed with extra steps.

  python3 agent_joint.py commit  --ceremony R --party NAME --key KEYFILE --share-out FILE --out COMMIT.json
  python3 agent_joint.py combine --ceremony R --commits C1.json C2.json ... --shares S1 S2 ... --seed-out SEED --joint-out joint.json --revealed-out joint.revealed.json
  python3 agent_joint.py verify  --joint joint.json --revealed joint.revealed.json [--round-commitment X] [--trusted KEYS]
"""
import argparse
import json
import os
import re
import secrets
import sys

import agent_beacon
import agent_core
import agent_sig
from agent_core import canon, sha256_hex

COMMIT_FORMAT = "guldo-joint-commit-v1"
JOINT_FORMAT = "guldo-joint-seed-v1"
PARTY_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{1,39}$")
CEREMONY_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}$")
SHARE_RE = re.compile(r"^[0-9a-f]{64}$")


class JointError(Exception):
    pass


def new_share():
    return secrets.token_hex(32)


def commitment_of(ceremony, party, share):
    return sha256_hex("guldo-joint-commit-v1|%s|%s|%s" % (ceremony, party, share))


def _check_names(ceremony, party=None):
    if not isinstance(ceremony, str) or not CEREMONY_RE.match(ceremony):
        raise JointError("a ceremony id is 1-64 letters, digits and _ . : -")
    if party is not None and (not isinstance(party, str) or not PARTY_RE.match(party)):
        raise JointError("a party name is 2-40 letters, digits and _ . : -")


def _plan_of(st):
    """The beacon round a commitment statement names, as (chain id, round), or None. The statement is signed, so a party cannot later claim a different round."""
    b = st.get("beacon")
    if b is None:
        return None
    if not isinstance(b, dict) or set(b) != {"chain", "round"} or not isinstance(b["round"], int) or isinstance(b["round"], bool):
        raise JointError("a commitment's beacon plan is {chain, round}")
    try:
        agent_beacon.chain_for(b["chain"])
        agent_beacon.round_time(agent_beacon.chain_for(b["chain"]), b["round"])
    except agent_beacon.BeaconError as e:
        raise JointError(str(e))
    return (b["chain"], b["round"])


def make_commit(ceremony, party, share, secret, beacon=None):
    """The signed commitment a party publishes (and only this: never the share). `beacon` = {"chain": id, "round": R} adds the agreed FUTURE beacon round to what the party signs: the seed will then
    include that round's randomness, which nobody can know before it is released."""
    _check_names(ceremony, party)
    if not isinstance(share, str) or not SHARE_RE.match(share):
        raise JointError("a share is 64 hex characters (use new_share())")
    st = {"format": COMMIT_FORMAT, "ceremony": ceremony, "party": party, "commitment": commitment_of(ceremony, party, share)}
    if beacon is not None:
        st["beacon"] = dict(beacon)
        _plan_of(st)
    return agent_sig.sign_statement(st, secret)


def _commit_problems(c, ceremony):
    st = c.get("statement") if isinstance(c, dict) else None
    if not isinstance(st, dict) or st.get("format") != COMMIT_FORMAT:
        return ["not a joint-seed commitment"]
    probs = []
    if not agent_sig.statement_ok(c):
        probs.append("the commitment's signature is not valid")
    if st.get("ceremony") != ceremony:
        probs.append("the commitment is for ceremony %r, not %r" % (st.get("ceremony"), ceremony))
    try:
        _check_names(st.get("ceremony"), st.get("party"))
        _plan_of(st)
    except JointError as e:
        probs.append(str(e))
    return probs


def master_of(ceremony, shares, beacon_randomness=None):
    """The combined seed (hex text, as a seed file holds it). `shares` is {party: share}; at least two parties, so that no one party is the seed. With `beacon_randomness` (hex) the beacon's value is
    part of the hash; without it the formula is exactly the original one."""
    _check_names(ceremony)
    if not isinstance(shares, dict) or len(shares) < 2:
        raise JointError("a joint seed needs at least two parties")
    for p, s in shares.items():
        _check_names(ceremony, p)
        if not isinstance(s, str) or not SHARE_RE.match(s):
            raise JointError("share of %s is not 64 hex characters" % p)
    if beacon_randomness is not None and not (isinstance(beacon_randomness, str) and SHARE_RE.match(beacon_randomness)):
        raise JointError("the beacon randomness is 64 hex characters")
    text = "guldo-joint-seed-v1|%s|%s" % (ceremony, "|".join("%s=%s" % (p, shares[p]) for p in sorted(shares)))
    return sha256_hex(text + ("|beacon=" + beacon_randomness if beacon_randomness is not None else ""))


def _agreed_plan(statements):
    plans = set(_plan_of(st) for st in statements)
    if len(plans) != 1:
        raise JointError("the parties do not agree about the beacon round (every party must sign the same round, or none)")
    return next(iter(plans))


def _beacon_randomness(plan, rec):
    """The randomness of a beacon record that must be exactly the planned round of the planned chain, verified here (BLS, pinned key)."""
    if plan is None:
        if rec is not None:
            raise JointError("a beacon was supplied but no party planned one")
        return None
    if rec is None:
        raise JointError("the parties planned beacon round %d: supply its record (it can only exist once that round has been released)" % plan[1])
    try:
        rand = agent_beacon.check_record(rec)
    except agent_beacon.BeaconError as e:
        raise JointError("the beacon record does not verify: %s" % e)
    if (rec["chain"], rec["round"]) != plan:
        raise JointError("the beacon record is not for the planned round")
    return rand


def beacon_time(joint):
    """Unix time at which the planned beacon round was released (None if the ceremony used no beacon): before it, nobody could know the seed."""
    plan = _agreed_plan([c["statement"] for c in joint["parties"]])
    return None if plan is None else agent_beacon.round_time(agent_beacon.chain_for(plan[0]), plan[1])


def combine(ceremony, commits, shares, beacon_record=None):
    """(master hex, joint doc, revealed doc). Every share must match its party's signed commitment, every party that committed must have revealed, nobody may reveal without having committed. If the
    parties signed a beacon round, `beacon_record` (a record of exactly that round, verified here) is required and its randomness goes into the seed."""
    parties = {}
    for c in commits:
        probs = _commit_problems(c, ceremony)
        if probs:
            raise JointError("a commitment is bad: " + "; ".join(probs))
        p = c["statement"]["party"]
        if p in parties:
            raise JointError("party %s committed twice" % p)
        parties[p] = c
    if set(shares) != set(parties):
        raise JointError("the parties that committed (%s) are not the parties that revealed (%s)" % (", ".join(sorted(parties)), ", ".join(sorted(shares))))
    for p, s in shares.items():
        if commitment_of(ceremony, p, s) != parties[p]["statement"]["commitment"]:
            raise JointError("party %s's share does not match its signed commitment" % p)
    plan = _agreed_plan([parties[p]["statement"] for p in parties])
    master = master_of(ceremony, shares, _beacon_randomness(plan, beacon_record))
    joint = {"format": JOINT_FORMAT, "ceremony": ceremony, "parties": [parties[p] for p in sorted(parties)], "master_sha256": sha256_hex(master)}
    revealed = {"format": JOINT_FORMAT + "-revealed", "ceremony": ceremony, "shares": {p: shares[p] for p in sorted(shares)}}
    if plan is not None:
        joint["beacon_plan"] = {"chain": plan[0], "round": plan[1]}
        revealed["beacon"] = beacon_record
    return master, joint, revealed


def verify(joint, revealed, round_commitment=None, trusted=None, min_parties=2):
    """A list of problems (empty = the master seed really is the hash of every party's committed share). `round_commitment` is the round's seed commitment: the combined master must produce it.
    `trusted` is the set of public keys YOU recognise; with it, every party's key must be one of them (without it the keys are only known to be self-consistent)."""
    probs = []
    try:
        if joint.get("format") != JOINT_FORMAT or revealed.get("format") != JOINT_FORMAT + "-revealed":
            return ["not a joint-seed record"]
        ceremony = joint["ceremony"]
        if revealed.get("ceremony") != ceremony:
            return ["the revealed shares are for another ceremony"]
        parties = {}
        for c in joint["parties"]:
            probs += _commit_problems(c, ceremony)
            parties[c["statement"]["party"]] = c
        shares = revealed["shares"]
        if len(parties) < min_parties:
            probs.append("fewer than %d parties" % min_parties)
        if set(shares) != set(parties):
            probs.append("the parties that committed are not the parties that revealed")
            return probs
        keys = {}
        for p, s in shares.items():
            if commitment_of(ceremony, p, s) != parties[p]["statement"]["commitment"]:
                probs.append("party %s's revealed share does not match its signed commitment" % p)
            keys[p] = parties[p]["statement"]["pubkey"]
        if len(set(keys.values())) != len(keys):
            probs.append("two parties signed with the SAME key: that is one party, not two")
        if trusted is not None:
            for p, k in sorted(keys.items()):
                if k not in set(trusted):
                    probs.append("party %s's key is not one you pinned" % p)
        plan = None
        try:
            plan = _agreed_plan([c["statement"] for c in parties.values()])
            if (joint.get("beacon_plan") is not None) != (plan is not None) or (plan is not None and (joint["beacon_plan"].get("chain"), joint["beacon_plan"].get("round")) != plan):
                probs.append("the joint record's beacon plan is not what the parties signed")
            rand = _beacon_randomness(plan, revealed.get("beacon"))
        except JointError as e:
            probs.append(str(e))
            rand = None
        if not probs:
            master = master_of(ceremony, shares, rand)
            if sha256_hex(master) != joint.get("master_sha256"):
                probs.append("the combined seed is not the one the joint record names")
            if round_commitment is not None and agent_core.commitment(master.encode("ascii")) != round_commitment:
                probs.append("the combined seed does not produce the round's seed commitment: the round was not run on this joint seed")
    except (KeyError, TypeError, AttributeError, JointError) as e:
        probs.append("malformed joint record (%s: %s)" % (type(e).__name__, str(e)[:80]))
    return probs


def party_keys(joint):
    return {c["statement"]["party"]: c["statement"]["pubkey"] for c in joint.get("parties", [])}


def _write(path, doc, secret=False):
    mode = 0o600 if secret else 0o644
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(doc if isinstance(doc, str) else json.dumps(doc, indent=1, sort_keys=True) + "\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("commit")
    p.add_argument("--ceremony", required=True)
    p.add_argument("--party", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--share-out", required=True, help="where to write the SECRET share (mode 600, never overwritten)")
    p.add_argument("--out", required=True)
    p.add_argument("--beacon-round", type=int, help="sign the agreed FUTURE drand quicknet round into the commitment (every party must sign the same round; see `beacon-plan`)")
    p = sub.add_parser("beacon-plan")
    p.add_argument("--in-seconds", type=int, default=900, help="pick the first quicknet round released at least this many seconds from now")
    p = sub.add_parser("combine")
    p.add_argument("--ceremony", required=True)
    p.add_argument("--commits", nargs="+", required=True)
    p.add_argument("--shares", nargs="+", required=True, help="share files, in the SAME order as --commits")
    p.add_argument("--seed-out", required=True)
    p.add_argument("--joint-out", required=True)
    p.add_argument("--revealed-out", required=True)
    p.add_argument("--beacon-record", help="a verified beacon record for the planned round (JSON file)")
    p.add_argument("--fetch-beacon", action="store_true", help="fetch the planned round from the public relays and verify it here (it must already have been released)")
    p = sub.add_parser("verify")
    p.add_argument("--joint", required=True)
    p.add_argument("--revealed", required=True)
    p.add_argument("--round-commitment")
    p.add_argument("--trusted")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "beacon-plan":
            import time
            q = agent_beacon.QUICKNET
            r = agent_beacon.round_at(q, time.time() + a.in_seconds) + 1
            print("quicknet round %d, released at %s UTC (chain %s)" % (r, time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(agent_beacon.round_time(q, r))), q["hash"][:16] + "..."))
            print("every party signs it:  --beacon-round %d" % r)
            return 0
        if a.cmd == "commit":
            share = new_share()
            beacon = {"chain": agent_beacon.QUICKNET["hash"], "round": a.beacon_round} if a.beacon_round else None
            doc = make_commit(a.ceremony, a.party, share, agent_sig.load_secret(a.key), beacon)
            _write(a.share_out, share + "\n", secret=True)
            _write(a.out, doc)
            print("committed %s as %s; the share is in %s (hand it to the seed host only after EVERY commitment is published)" % (doc["statement"]["commitment"][:16], a.party, a.share_out))
            return 0
        if a.cmd == "combine":
            if len(a.commits) != len(a.shares):
                print("--commits and --shares must pair up", file=sys.stderr)
                return 1
            commits, shares = [], {}
            for cp, sp in zip(a.commits, a.shares):
                with open(cp, "r", encoding="utf-8") as f:
                    c = json.load(f)
                with open(sp, "r", encoding="utf-8") as f:
                    shares[c["statement"]["party"]] = f.read().strip()
                commits.append(c)
            rec = None
            if a.beacon_record:
                with open(a.beacon_record, "r", encoding="utf-8") as f:
                    rec = json.load(f)
            elif a.fetch_beacon:
                plan = _agreed_plan([c["statement"] for c in commits])
                if plan is None:
                    print("the parties signed no beacon round", file=sys.stderr)
                    return 1
                ch = agent_beacon.chain_for(plan[0])
                import time
                if agent_beacon.round_time(ch, plan[1]) > time.time():
                    print("beacon round %d is not released yet (due %s UTC): wait, then combine" % (plan[1], time.strftime("%H:%M:%S", time.gmtime(agent_beacon.round_time(ch, plan[1])))), file=sys.stderr)
                    return 1
                rec = agent_beacon.fetch(ch, plan[1])
            master, joint, revealed = combine(a.ceremony, commits, shares, rec)
            _write(a.seed_out, master + "\n", secret=True)
            _write(a.joint_out, joint)
            _write(a.revealed_out, revealed, secret=True)
            print("combined %d parties; master commitment %s (publish %s now; keep %s and %s until the reveal)" % (len(shares), agent_core.commitment(master.encode("ascii")), a.joint_out, a.revealed_out, a.seed_out))
            return 0
        with open(a.joint, "r", encoding="utf-8") as f:
            joint = json.load(f)
        with open(a.revealed, "r", encoding="utf-8") as f:
            revealed = json.load(f)
        trusted = agent_sig.read_trusted(a.trusted) if a.trusted else None
        probs = verify(joint, revealed, a.round_commitment, trusted)
        for pr in probs:
            print("FAIL  " + pr)
        print("JOINT SEED VERIFIED: the master is the hash of every party's committed share" if not probs else "JOINT SEED NOT VERIFIED")
        return 1 if probs else 0
    except (JointError, OSError, ValueError, KeyError, agent_core.AgentEvalError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
