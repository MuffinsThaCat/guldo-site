"""Reference for rlwe: meet in the middle over the ternary secret on the first two coefficients of a*s (about 3^(n/2) work), then a full check.

The ring is Z_q[x]/(x^n - x - 1); column j of the multiplication-by-a map is a * x^j, built by repeated multiplication by x.
The candidate generator scans the whole space (no early exit), so the cost depends on n alone and the ladder is predictable.
"""


def _expand(cs):
    """Raw sums of c_j * s_j over every ternary s on these columns; list index = base-3 digits of s, first column most significant."""
    v = [0]
    for c in cs:
        v = [x + s * c for x in v for s in (-1, 0, 1)]
    return v


def _digits(idx, length):
    d = [0] * length
    for p in range(length - 1, -1, -1):
        idx, r = divmod(idx, 3)
        d[p] = r - 1
    return d


def _candidates(q, R0, R1, R2, t0, t1, t2, W):
    """Yield every ternary s with |t_r - R_r.s| <= W (mod q, centred) for the first three rows r: meet in the middle on rows 0 and 1, then a
    cheap row-2 filter from precomputed sums so that the (many) two-row survivors cost O(1) each."""
    n = len(R0)
    k = n // 2
    # the table holds the larger half (columns k..n-1), the 25 noise lookups run over the smaller one (columns 0..k-1)
    L0, L1, L2 = _expand(R0[k:]), _expand(R1[k:]), _expand(R2[k:])
    U0, U1, U2 = _expand(R0[:k]), _expand(R1[:k]), _expand(R2[:k])
    table = {}
    for i, (x, y) in enumerate(zip(L0, L1)):
        table.setdefault((x % q) * q + y % q, []).append(i)
    offs = [(e0, e1) for e0 in range(-W, W + 1) for e1 in range(-W, W + 1)]
    get = table.get
    half = q // 2
    for j, (x, y, z) in enumerate(zip(U0, U1, U2)):
        y0, y1 = t0 - x, t1 - y
        for e0, e1 in offs:
            hit = get(((y0 - e0) % q) * q + (y1 - e1) % q)
            if hit:
                for i in hit:
                    r = (t2 - z - L2[i]) % q
                    if r > half:
                        r -= q
                    if -W <= r <= W:
                        yield _digits(j, k) + _digits(i, n - k)


def _times_x(v, q):
    t = v[-1]
    w = [0] + v[:-1]
    w[0] += t          # x^n = x + 1
    w[1] += t
    return [c % q for c in w]


def solve(q, a, b, W):
    n = len(a)
    cols, col = [], [c % q for c in a]
    for _ in range(n):
        cols.append(col)
        col = _times_x(col, q)
    R0 = [cols[j][0] for j in range(n)]
    R1 = [cols[j][1] for j in range(n)]
    R2 = [cols[j][2] for j in range(n)]
    found = None
    for s in _candidates(q, R0, R1, R2, b[0], b[1], b[2], W):
        if found is None and _ok(q, cols, b, W, s):
            found = s
    return found


def _ok(q, cols, b, W, s):
    n = len(b)
    for i in range(n):
        r = (b[i] - sum(s[j] * cols[j][i] for j in range(n))) % q
        if r > q // 2:
            r -= q
        if abs(r) > W:
            return False
    return True
