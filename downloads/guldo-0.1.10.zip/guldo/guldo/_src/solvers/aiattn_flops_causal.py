"""aiattn in the counted-operations API, TECHNIQUE: causal skipping only. Each block of 32 queries is scored against every key up to itself (the upper triangle is never computed) but not narrowed to the window."""
import math

import tensorops as tp

D = 16
WINDOW = 32
QK = 3.0


def solve(seed, n):
    m = n * D
    W = WINDOW
    Q = tp.stream(seed, 0, m, (n, D)) * QK
    K = tp.stream(seed, m, m, (n, D)) * QK
    V = tp.stream(seed, 2 * m, m, (n, D))
    M = tp.causal_mask(n) + tp.transpose(tp.causal_mask(n + W), (1, 0))[0:n, W - 1:W - 1 + n]
    parts = []
    for b in range(n // W):
        hi = (b + 1) * W
        S = tp.einsum("id,jd->ij", Q[b * W:hi], K[0:hi]) / math.sqrt(D) + M[b * W:hi, 0:hi]
        E = tp.exp(S - tp.max(S, 1, True))
        parts.append((E / tp.sum(E, 1, True)) @ V[0:hi])
    return [int(x * 65536.0) for x in tp.reshape(tp.concat(parts, 0), (n * D,)).tolist()]
