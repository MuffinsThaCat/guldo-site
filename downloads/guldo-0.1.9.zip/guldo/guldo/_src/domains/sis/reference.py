"""Reference for sis: meet in the middle over the ternary vector on all three rows (about 3^(m/2) work).

x = (x1, x2); A1 x1 + A2 x2 = 0 mod q is looked up as key(x1) == -key(x2). The whole space is scanned (no early exit), so the cost depends on
m alone and the ladder is predictable.
"""


def _expand(cs):
    v = [0]
    for c in cs:
        v = [x + s * c for x in v for s in (-1, 0, 1)]
    return v


def _digits(idx, length):
    d = [0] * length
    for p in range(length - 1, -1, -1):
        idx, r = divmod(idx, 3)
        d[p] = r - 1
    return d


def solve(q, A):
    m = len(A[0])
    k = m // 2
    L = [_expand(row[:k]) for row in A]
    U = [_expand(row[k:]) for row in A]
    table = {}
    for i, (x, y, z) in enumerate(zip(*L)):
        table.setdefault(((x % q) * q + y % q) * q + z % q, []).append(i)
    found = None
    for j, (x, y, z) in enumerate(zip(*U)):
        hit = table.get(((-x % q) * q + (-y) % q) * q + (-z) % q)
        if hit:
            for i in hit:
                if found is None:
                    cand = _digits(i, k) + _digits(j, m - k)
                    if any(cand):
                        found = cand
    return found
