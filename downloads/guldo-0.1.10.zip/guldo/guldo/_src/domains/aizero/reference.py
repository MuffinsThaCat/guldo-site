"""Reference for aizero: one device runs the three Adam steps on the whole batch (float64)."""
import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, B, P):
    n = 128 * d
    theta = _uniform(seed, 0, n) * 0.1
    X = _uniform(seed, n, B * n).reshape(B, n)
    y = _uniform(seed, n + B * n, B)
    m, v = np.zeros(n), np.zeros(n)
    for t in range(1, 4):
        g = X.T @ (X @ theta - y) / B
        m = 0.9 * m + 0.1 * g
        v = 0.999 * v + 0.001 * g * g
        theta = theta - 0.01 * (m / (1 - 0.9 ** t)) / (np.sqrt(v / (1 - 0.999 ** t)) + 1e-8)
    return [int(x) for x in np.rint(theta * 2 ** 40)]
