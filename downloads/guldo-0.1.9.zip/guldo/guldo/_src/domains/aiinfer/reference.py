"""Reference for aiinfer: float64, one sample at a time.

The model definition (the contract a submission must reproduce): SplitMix64 counter stream under `seed`, element k = finalise((k+1)*GOLD + seed),
mapped to [-1, 1) as (z >> 11) * 2^-52 - 1. Stream layout: W1 (d*d), W2 (d*d), W3 (10*d), then the batch X (batch*d); weights are scaled by
sqrt(3/d). Network: relu(W1 x) -> relu(W2 h) -> W3 h; the label is the argmax.
"""
import math

import numpy as np

_GOLD = 0x9E3779B97F4A7C15
_C1 = 0xBF58476D1CE4E5B9
_C2 = 0x94D049BB133111EB
_CLASSES = 10


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, batch):
    s = math.sqrt(3.0 / d)
    o = 0
    W1 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W2 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W3 = (_uniform(seed, o, _CLASSES * d) * s).reshape(_CLASSES, d)
    o += _CLASSES * d
    X = _uniform(seed, o, batch * d).reshape(batch, d)
    out = []
    for i in range(batch):
        h = np.maximum(W1 @ X[i], 0.0)
        h = np.maximum(W2 @ h, 0.0)
        out.append(int(np.argmax(W3 @ h)))
    return out
