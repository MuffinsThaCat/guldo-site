"""Declaration of an int8-QUANTISATION domain: greedy generation from a small residual-MLP language model whose hidden channels have very different magnitudes, token for token correct, with as few BYTES moved as you can.

The model is `aiquant`'s (vocabulary 64, width 128, hidden 512, tied embeddings, learned positions, one residual ReLU block, every token depends on the previous one, so every step reads all the weights) with one
change: hidden channel j of W1 is multiplied by g_j and row j of W2 divided by g_j, with g_j = 30^((u_j + 1) / 2) from the same SplitMix64 stream (layout in reference.py). The function is unchanged; the WEIGHTS now span
a 30-fold range from channel to channel, as real networks' channels do. That is what makes int8 quantisation a real choice. One scale for a whole tensor is set by its largest channel and leaves the small ones with a
handful of levels; one scale per channel (W1 per column, W2 per row, the embeddings per row) fits each. Measured on the judge's rule over 6 instances: one scale per tensor misses by 0.10 to 0.17 standard deviations
of the logits (the judge allows 0.05), per-channel misses by at most 0.006.

Measured with tflops_mem2.py (version 2 of the byte counter: it adds `tp.cast(x, "int8")` and `tp.cast(x, "int8", axis)`; see tensorops_mem2.py for the exact rules), compared with tflops_compare.py --metric bytes. int8
weights are 1 byte per value plus an fp32 per scale, against 8 (fp64), 4 (fp32) or 2 (fp16): the bytes saved are the weights read at every step. Operations do NOT fall (quantising adds some), so only the byte count can show it.

Verification is TEACHER-FORCED, as in aiquant: the judge runs the float64 model once, in parallel, over the prompt and the submitted tokens and accepts iff every submitted token's logit is within TOL_SIGMA (0.05)
standard deviations of the best logit at its position. Per-channel int8 (and fp16) pass; per-tensor int8, a skipped block, pruning and repeating a token fail.

What this cannot show: a real integer kernel or memory system (bytes are an accounting convention; no zero-points, asymmetric or sub-8-bit formats, no calibration beyond the absolute maximum), or that any
real device has a fast int8 path. It certifies "N times fewer bytes under these rules", not "N times faster".
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aiintquant"
VERSION = "aiintquant-v1"        # bump whenever derive() or the model definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (64, 384)
SIZE_STEP = 64
REFERENCE_SOLVER = "reference.py"
V, D, H = 64, 128, 512
W_SCALE, POS_SCALE = 4.0, 3.0
CHAN_SPREAD = 30.0            # hidden channel j has its weights scaled by g_j in [1, 30] (W1 column j up, W2 row j down): the layer computes the same function, but one scale cannot fit all channels
TOL_SIGMA = 0.05
DOC = ("solve(seed, T): rebuild the model from `seed` (SplitMix64 stream via tensorops.stream, layout in domains/aiintquant/reference.py; W1 column j is multiplied by g_j = 30^((u_j+1)/2) and W2 row j divided by it, u_j from the stream after the positions), start from the 1-token prompt and generate T tokens "
       "greedily, each from the previous token and its position: x = E[prev] + pos[t]; y = x + relu(rms(x) W1) W2; logits = rms(y) E^T; the token is the argmax. Return the list of T "
       "token ids. Every returned token must be, at its position, within 0.05 standard deviations of the best logit given your own earlier tokens (fp16 weights and per-channel int8 pass; per-tensor int8, a "
       "skipped block, heavy pruning or a repeated token do not). Return None for no answer.")
REFERENCE_NOTE = ("float64 throughout: every step reads the full weight matrices at 8 bytes per value. Known to be beaten, on bytes moved, by fp16 (a quarter) and by per-channel int8 "
                  "(about an eighth, plus the scales) with no change in the tokens; the saving approaches the width ratio as T grows. One int8 scale per tensor is NOT equivalent here and the judge rejects it.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _params(seed, T):
    o = [0]

    def take(shape, scale):
        n = int(np.prod(shape))
        a = (_uniform(seed, o[0], n) * scale).reshape(shape)
        o[0] += n
        return a
    sd, sf = W_SCALE * math.sqrt(3.0 / D), W_SCALE * math.sqrt(3.0 / H)
    P = {"E": take((V, D), math.sqrt(3.0)), "W1": take((D, H), sd), "W2": take((H, D), sf), "pos": take((T, D), POS_SCALE * math.sqrt(3.0))}
    g = CHAN_SPREAD ** ((_uniform(seed, o[0], H) + 1.0) * 0.5)
    o[0] += H
    P["W1"], P["W2"] = P["W1"] * g[None, :], P["W2"] / g[:, None]
    P["first"] = min(int((_uniform(seed, o[0], 1)[0] + 1.0) * 0.5 * V), V - 1)
    return P


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def _logits(P, toks):
    """Logits at every position at once: toks[t] is the INPUT token of position t. The judge's definition of the model."""
    x = P["E"][toks] + P["pos"][:len(toks)]
    y = x + np.maximum(_rms(x) @ P["W1"], 0.0) @ P["W2"]
    return _rms(y) @ P["E"].T


def _greedy(P, T):
    tok, out = P["first"], []
    for t in range(T):
        tok = int(np.argmax(_logits(P, [tok] * (t + 1))[t]))      # position t only needs its own input; the others are ignored
        out.append(tok)
    return out


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aiintquant-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    return {"args": [seed, size], "planted": _greedy(_params(seed, size), size)}


def verify(inst: dict, ans) -> bool:
    seed, T = inst["args"]
    if not isinstance(ans, list) or len(ans) != T:
        return False
    if any(isinstance(c, bool) or not isinstance(c, int) or not 0 <= c < V for c in ans):
        return False
    P = _params(seed, T)
    L = _logits(P, [P["first"]] + [int(c) for c in ans[:-1]])
    tol = TOL_SIGMA * float(L.std())
    return bool(np.all(L[np.arange(T), np.asarray(ans)] >= L.max(axis=1) - tol))
