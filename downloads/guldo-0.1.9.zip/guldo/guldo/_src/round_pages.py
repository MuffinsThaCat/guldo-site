"""One page per competition in the schedule (build_site.py calls `pages`).

The Compete page lists the competitions and links each one's Details to a page of its own, `round-<id>.html`. Every number a page states comes from the code or the public
record, not from retyped text: the lattice round's settings from `lattice_round.py`, `families.py` and `rounds.py`; the counted factoring round's settings and seed
commitments from the ledger record the build already copied into the site (`ledger/round_<id>.json`). A competition the schedule lists but this module has no text for still
gets a plain page from its schedule entry, so no Details link ever leads to the shared page.

Nothing here claims a round can be entered unless the round says so: the status comes from `schedule_status` (the ledger's own state wins over the listed times), and the
how-to-enter text switches with the live status in the browser the same way the Compete page's schedule does (assets/schedule.js)."""
import calendar
import json
import os
import re
import time

ID_RE = re.compile(r"[a-z0-9][a-z0-9-]{0,40}")
LABEL = {"upcoming": "Opens soon", "open": "Open now", "closed": "Closed"}

# The lattice round's review trigger, fixed before it opens. 3 bits is the smallest speedup the round certifies reliably (about 99% of the time, LATTICE_ROUND_INSTRUCTIONS section 3).
# NOTICE_DAYS is how long publication may wait, after the deadline, before publishing the source of an entry that meets the trigger, so the designers of the affected schemes hear first.
TRIGGER_BITS = 3
NOTICE_DAYS = 30

# Anthropic's published schedule (checked 23 Nov 2026): claude-opus-4-6 is Active, "Not sooner than February 5, 2027", with at least 60 days' notice before retirement.
DEPRECATIONS_URL = "https://platform.claude.com/docs/en/about-claude/model-deprecations"

# The companion paper, pinned to the version the 48 to 130 bit figures come from (checked against the Zenodo record: v3, 30 October 2026, open access, CC BY 4.0).
PAPER_URL = "https://zenodo.org/records/23786532"
PAPER_LINK = ('<a href="' + PAPER_URL + '" rel="noopener">&ldquo;The Egg, Not the Sphere&rdquo; (Zenodo, version 3, 30 October 2026, open access)</a>')


def filename(round_id):
    """round-<id>.html, or None when the id is not a plain slug (such a round keeps whatever link the schedule gives it)."""
    return f"round-{round_id}.html" if ID_RE.fullmatch(round_id or "") else None


def when(ts):
    t = time.gmtime(ts)
    return f"{t.tm_mday} {calendar.month_name[t.tm_mon]} {t.tm_year}, {t.tm_hour:02d}:{t.tm_min:02d} UTC"


class _Page:
    """Small helpers bound to the builder's own escape / command-box / banner functions."""

    def __init__(self, H, portal_url):
        self.H, self.portal_url = H, (portal_url or "").rstrip("/")

    def esc(self, s):
        return self.H.esc(s)

    def md(self, s):
        """Plain text with `code` spans; everything is escaped first, so nothing in a string can inject markup."""
        out = []
        for part in re.split(r"(`[^`]+`)", self.H.esc(s)):
            out.append('<span class="mono">' + part[1:-1] + "</span>" if len(part) > 1 and part.startswith("`") and part.endswith("`") else part)
        return "".join(out)

    def table(self, head, rows, cls="lb"):
        th = "".join(f"<th>{self.esc(h)}</th>" for h in head)
        body = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>" for row in rows)
        return f'<div class="scroll"><table class="{cls}"><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>'

    def facts(self, rows):
        return self.table(["Setting", "Value"], [(f'<strong>{self.esc(k)}</strong>', v) for k, v in rows])

    def portal_link(self, round_id, text):
        if not self.portal_url or getattr(self, "status", "") == "upcoming":   # the portal has no page for a round that has not been created yet
            return ""
        return f'<a class="btn" href="{self.esc(self.portal_url)}/round/{self.esc(round_id)}">{self.esc(text)}</a>'


def _status_card(P, r, st, now, messages):
    """The status and the dates, as rows the schedule script keeps current (data-opens, data-closes, data-show). `messages` maps upcoming / open / closed to HTML."""
    blocks = "".join(f'<span data-show="{k}"{"" if k == st else " hidden"}>{messages[k]}</span>' for k in ("upcoming", "open", "closed"))
    ledger = f' data-ledger="{P.esc(r["ledger"])}"' if r.get("ledger") else ""
    attrs = f'data-opens="{r["o"] * 1000}" data-closes="{r["c"] * 1000}" data-id="{P.esc(r["id"])}"{ledger}'
    return ('<section class="card" id="status"><h2>Status</h2><div class="scroll"><table class="lb"><thead><tr><th>Status</th><th>Opens (UTC)</th><th>Closes (UTC)</th></tr></thead><tbody>'
            f'<tr {attrs}><td class="sched-status">{LABEL[st]}</td><td>{P.esc(when(r["o"]))}</td><td>{P.esc(when(r["c"]))}</td></tr>'
            f'<tr {attrs}><td colspan="3" class="fine">{blocks}</td></tr></tbody></table></div>'
            '<p class="fine">This status updates from the public ledger when your browser can reach it, and otherwise shows what was true when the page was built. '
            'The listed times are the plan: each round is opened by hand once its seed commitments are public, so a round may open a little after its listed time.</p>'
            '<script src="assets/schedule.js"></script></section>')


def _layout(P, r, st, now, body_bands, title_suffix=""):
    fn = filename(r["id"])
    desc = (r.get("summary") or r["title"])[:200]
    return P.H.layout(fn, f"{r['title']} - Guldo", desc, body_bands, bands=True)


def _hero(P, r, st, buttons, kicker="Competition", extra=""):
    summary = f'<p class="lede">{P.esc(r["summary"])}</p>' if r.get("summary") else ""
    return (f'<div class="band dark"><div class="wrap band-in"><section class="block"><p class="kicker">{P.esc(kicker)}</p><h1>{P.esc(r["title"])}</h1>{summary}'
            f'<p class="fine">{P.esc(LABEL[st])} &middot; {P.esc(when(r["o"]))} to {P.esc(when(r["c"]))}</p>{extra}'
            f'<div class="btnrow">{buttons}<a class="btn" href="compete.html#schedule">All competitions</a></div></section></div></div>')


def _messages(r, upcoming, open_, closed):
    return {"upcoming": upcoming, "open": open_, "closed": closed}


# ----------------------------------------------------------------------------------------------------------- factor-1
def _ledger_record(ledger_dir, round_id):
    try:
        with open(os.path.join(ledger_dir, f"round_{round_id}.json"), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else None
    except (OSError, ValueError, TypeError):
        return None


def _factor_settings(P, rec):
    """The counted round's published settings, read from its own ledger record (None parts when the record is missing)."""
    if not rec:
        return [("Settings", "Published with the round: they appear here when the round's record is in the public ledger.")]
    count = rec.get("count") or {}
    dims = ", ".join(str(d) for d in (count.get("dims") or rec.get("fingerprint", {}).get("dims") or []))
    cap = count.get("cap") or rec.get("budget")
    sps = count.get("steps_per_second") or 0
    steps = f"{int(float(cap) * int(sps)):,}" if cap and sps else "see the round page"
    rows = [("Problem sizes (bits of n)", P.esc(dims) or "see the round page"),
            ("Questions per size", P.esc(str(rec.get("n", count.get("n", "?"))))),
            ("Cap per question", f"{P.esc(steps)} counted steps"),
            ("Secret seeds", f"{len(rec.get('commitments') or [])}, their hashes published before the round opened (listed below)"),
            ("Submissions", f"at most {P.esc(str(rec.get('max_submissions', '?')))} in total and 3 per handle"),
            ("Source", "published after the deadline" if rec.get("allow_private") is False else "private solvers allowed"),
            ("Python used for the official counts", P.esc(str(count.get("python", "?")))),
            ("Baseline", f"{P.esc(str(rec.get('fingerprint', {}).get('baseline', '?')))} (trial division)")]
    return rows


def _factor_page(P, r, st, now, ctx):
    rec = _ledger_record(ctx["ledger_dir"], r["id"])
    commits = "".join(f'<li class="mono fine" style="word-break:break-all">{P.esc(c)}</li>' for c in (rec or {}).get("commitments") or [])
    head = (rec or {}).get("log_head", "")
    msgs = _messages(r, "Not open yet. Entries are accepted from the opening time above.",
                     "Open now. Follow the steps below, or use the form on the round page.",
                     "Closed to new entries. Every submission is evaluated, the seeds are revealed and a certificate is published for each; results appear on the round page.")
    cmds = (P.H.cmd("python3 -m venv guldo-env && source guldo-env/bin/activate && pip install guldo-cli") + P.H.cmd("guldo lint my_solver.py --family factor")
            + P.H.cmd("guldo counted check my_solver.py --family factor --dim 38") + P.H.cmd(
                f"guldo submit my_solver.py --server {P.portal_url or 'https://submit.guldo.org'} --round {r['id']} --handle YOURHANDLE --accept-rules --publish-source"))
    approaches = P.table(["Approach", "Notes in this round"], [
        ("Trial division and its refinements", P.md("The baseline is the plain loop. Skipping multiples of small primes (a wheel) is a small, safe gain.")),
        ("Pollard's rho (Floyd, Brent)", P.md("The usual first improvement. Your solver must be deterministic, so derive the starting value from `n` by a fixed rule, never from `random` or the clock.")),
        ("Pollard's p-1", P.md("Works when one prime factor minus one has only small prime factors. Each prime here is about 19 to 22 bits, so it is cheap to try.")),
        ("Fermat and Lehman", "Suited to factors that are close together."),
        ("One-line factoring and SQUFOF", "Methods designed for numbers of roughly this size."),
        ("Elliptic-curve and sieve methods", "Allowed. Whether they pay off at 38 to 44 bits in pure Python is for entrants to find out."),
        ("Anything else that returns a nontrivial divisor", "The round only checks the answer and counts the steps.")])
    body = (_hero(P, r, st, '<a class="btn primary" href="#enter">How to enter</a>' + P.portal_link(r["id"], "Round page on the portal"))
            + '<div class="band light"><div class="wrap band-in">' + _status_card(P, r, st, now, msgs)
            + '<section class="card"><h2>The task</h2><p class="fine">You write one Python function, <span class="mono">solve(n)</span>, that returns a nontrivial divisor of a number <span class="mono">n</span> '
              'that is the product of two primes. Nothing is timed. Instead, the judge counts the exact number of Python bytecode instructions your function executes (&ldquo;steps&rdquo;), '
              'so anyone can re-run an entry and get the same number. A baseline that uses trial division is counted on the same questions, and your result is your speedup over it, in '
              '<strong>bits</strong>: 1 bit means half the steps, 3 bits means one eighth. The credit is a cautious lower bound, so a small gain may come back &ldquo;inconclusive&rdquo;. That is a statement about statistics, not about your code.</p></section>'
            + '<section class="card"><h2>Settings, from the public record</h2>' + P.facts(_factor_settings(P, rec))
            + (f'<h3>The three seed commitments</h3><p class="fine">These hashes were published when the round opened. The seeds they commit to are revealed after the evaluation, so nobody can tune a solver to the questions.</p><ul>{commits}</ul>' if commits else "")
            + (f'<p class="fine">Head of the public log when this page was built:<span class="mono" style="word-break:break-all">{P.esc(head)}</span></p>' if head else "") + '</section>'
            + '</div></div><div class="band dark"><div class="wrap band-in">'
            + '<section class="block"><p class="kicker">What is accepted</p><h2>Approaches</h2><p class="fine">Any algorithm in pure Python. These are the usual candidates:</p>' + approaches
            + '<div class="two" style="margin-top:12px"><div class="card"><h3>Rules for your solver</h3><ul class="fine">'
              '<li>One file, pure Python. The only imports allowed are <span class="mono">math</span>, <span class="mono">itertools</span>, <span class="mono">heapq</span>, <span class="mono">bisect</span>, <span class="mono">functools</span>, <span class="mono">collections</span>, <span class="mono">fractions</span>. No numpy, gmpy2, sympy or other C libraries.</li>'
              '<li>No files, no <span class="mono">sys</span> or <span class="mono">os</span>, no <span class="mono">eval</span> or <span class="mono">exec</span>, and no attempt to reach the counter or the questions.</li>'
              '<li>Deterministic: the same <span class="mono">n</span> must always cost the same number of steps.</li>'
              '<li>The step counter accepts only a restricted subset of Python. If <span class="mono">guldo counted check</span> rejects something, rewrite it: that command is the ground truth.</li></ul></div>'
              '<div class="card"><h3>Play fair with the counter</h3><p class="fine">Steps are Python bytecode instructions, so work done inside a single built-in call, such as <span class="mono">pow(a, b, n)</span> or <span class="mono">math.gcd</span>, is cheap in steps. '
              'That is part of the stated rules, but the goal is a real algorithmic improvement, not a loophole in the counter.</p></div></div></section>'
            + '</div></div><div class="band light"><div class="wrap band-in"><section class="card" id="enter"><h2>How to enter</h2>'
              '<p class="fine">You need a Mac or Linux computer, Python 3.12 or newer for the step-counting check, and about twenty minutes for a first submission. No account is needed. Choose a handle of 2 to 32 letters, digits, dots, underscores or hyphens. '
              '<strong>Submitting publishes your source after the deadline.</strong> The command prints a token once; keep it, because it is the only way to submit again under your handle.</p>'
            + cmds + '<p class="fine">You can also submit with the form at the bottom of the round page. After the deadline, this command checks your own result against the public log and the revealed seeds:</p>'
            + P.H.cmd(f"guldo verify --server {P.portal_url or 'https://submit.guldo.org'} --round {r['id']} --id YOUR_SUBMISSION_ID") + '</section>'
            + '<section class="card"><h2>What this does and does not show</h2><p class="fine">A certificate shows that, on questions fixed before the round and with costs anyone can recompute, your solver needed fewer steps than the baseline. '
              'It measures Python bytecode steps, not seconds on a real machine, and it cannot see work done inside built-in C functions. '
              'This is the first public round of a young system. The submission service and the step-counting sandbox have been tested, but not yet in a real competition, '
              'and the counted evaluation runs on the competition\'s own server without operating-system isolation. '
              'The <a href="limits.html">Limits</a> page has the full list.</p></section></div></div>')
    return _layout(P, r, st, now, body)


# ----------------------------------------------------------------------------------------------------------- lattice-1
def _lattice_settings(P):
    """The lattice round's numbers, read from the code that fixes them (None parts become words, never guesses)."""
    try:
        import families
        dims = ", ".join(str(d) for d in families.DEFAULT_DIMS["gm"])
        cap = int(families.OFFICIAL["gm"]["budget"])
    except Exception:
        dims, cap = "", 0
    try:
        import lattice_round as LR
        n, seeds, places = LR.N, LR.SEEDS, LR.MAX_SUBMISSIONS
    except Exception:
        n = seeds = places = None
    try:
        import rounds
        per_handle = rounds.MAX_PER_HANDLE
    except Exception:
        per_handle = None
    g = lambda v, fmt="{}": fmt.format(v) if v else "published with the round"
    return [("The problem", P.md("Short vectors in Goldstein-Mayer lattices (the kind used in the SVP challenge)")),
            ("What you return", P.md("A nonzero lattice vector whose squared length is at most `bound2`, which is the square of 1.05 times the Gaussian heuristic")),
            ("Dimensions", P.esc(g(dims))), ("Questions per dimension", P.esc(g(n))), ("Secret seeds", P.esc(g(seeds)) + ", hashes published before the round opens"),
            ("Time limit per question", P.esc(g(cap, "{} seconds of CPU time"))),
            ("Places", f"{P.esc(g(places))} in total, first come first served; one handle may take at most {P.esc(g(per_handle))}"),
            ("Source", "required: published after the deadline"),
            ("Baseline", "progressive BKZ with exact (unpruned) enumeration, using fpylll"),
            ("Score", "certified speedup over that baseline, in bits, and nothing else")]


TECHNIQUES = [
    ("LLL and its variants", "`LLL.reduction` in fpylll, deep insertion, other reduction parameters. Usually the first step that prepares a basis for BKZ.", "Independent"),
    ("BKZ and schedules of block sizes", "`BKZ.Param` with your own block-size schedule, loop limits, auto-abort, progressive and self-dual variants. The baseline is progressive BKZ with exact enumeration, so gains from tuning this are what the round measures.", "Independent"),
    ("Enumeration with pruning", "fplll's strategies file (`/opt/fplll/strategies/default.json` in the box; a pip-installed fpylll does not ship it, so try a list of paths and fall back to no strategies when none exists), extreme pruning (many cheap randomised runs), and discrete pruning, which you would write yourself.", "Independent"),
    ("Preprocessing, re-randomisation, early exit", "Randomise the basis and restart, reduce a sublattice first, stop as soon as a vector fits the bound. There is only one core, so restarts run one after another.", "Independent"),
    ("Sieving", "Allowed. The box holds only the standard library, numpy and fpylll, so a dedicated sieving library such as G6K is not available. Use what fpylll offers, or write your own in Python and numpy (GaussSieve, Nguyen-Vidick, bucketed variants). It must run on one core inside the time limit.", "Independent or angular"),
    ("Techniques that use the shape of the search region", "The distribution of the Gram-Schmidt norms, the angles between pairs of vectors, or a nearest-neighbour search that adapts to the data.", "Angular"),
    ("Anything else that returns a valid short vector", "New reduction heuristics, hybrids of the above, better parameter choices. If it runs in the box and the vector passes the check, it counts.", "Independent, unless it is one of the angular techniques above")]

NOT_ACCEPTED = [
    "Anything outside the standard library, numpy and fpylll: it fails to import in the box.",
    "More than one core, a GPU, the network or files you did not include. The box has one CPU, 4 GB of memory, no network, a read-only file system and at most 64 processes.",
    "Looking up answers. Every question is derived from a seed whose hash was committed in the public log before the round opened, so there is nothing to look up and nothing to tune to.",
    "Tampering with the timing, reading the questions or seeds, or attacking the service. This means disqualification, and it may be reported.",
    "A wrong answer, a crash or a timeout is a failed question, charged the full time limit. A solver that gives up quickly is penalised as heavily as one that runs out the clock."]

# What Guldo can measure about lattice cryptanalysis elsewhere: (problem or claim type, what exists, honest status)
ELSEWHERE = [
    ("Shortest vector problem", "Find a short vector in a random lattice (Goldstein-Mayer, the SVP challenge kind). Techniques: LLL, BKZ, enumeration with pruning, sieving, and anything else that returns a short vector.", "This round. It is the only lattice problem that can host an official round today."),
    ("Module-LWE-shaped lattices", "The family `mlwe`: the same call, `solve(basis, bound2)`, on lattices with Kyber's ring structure. Techniques: the same as above, on structured lattices.", "Built, but not part of this round: a round runs one family, and this one uses `gm`."),
    ("LWE", "Recover a ternary secret from noisy linear equations (a small secret, with a fixed 2n samples). Techniques: primal attack (lattice reduction), dual attack combined with guessing, hybrid attacks on the small secret. The baseline is meet-in-the-middle.", "Toy size, declared but not compiled. The fixed number of samples is too few for sample-hungry attacks such as BKW and Arora-Ge: see “LWE with a sample oracle” below."),
    ("Ring-LWE", "The same problem over the ring Z_q[x]/(x^n - x - 1), which is a field. It is graded by time to a verified secret, so any route counts. Techniques: primal lattice attack, algebraic or SAT encodings, ring-aware sieving.", "Toy size, declared but not compiled. The ring excludes subfield and overstretched-modulus attacks."),
    ("NTRU", "Recover the short pair (f, g) from a public key h = g/f, in the same field ring. Technique: lattice reduction on the NTRU lattice.", "Toy size, declared but not compiled. The ring excludes subfield and overstretched-modulus attacks."),
    ("Short integer solution (SIS)", "Find a nonzero vector with entries in {-1, 0, 1} that a random matrix mod q sends to zero. It is a short vector in a q-ary lattice. Technique: lattice reduction.", "Toy size, declared but not compiled."),
    ("Hidden number problem", "Recover a hidden number from the top bits of many of its multiples mod p, the lattice attack on ECDSA with biased nonces. Technique: Boneh-Venkatesan lattices.", "Toy size, declared but not compiled."),
    ("Low-density subset sum", "Recover a hidden subset from its sum, at density about 1/2. Technique: lattice reduction on a knapsack lattice (Lagarias-Odlyzko, Coster et al.).", "Toy size, declared but not compiled."),
    ("Coppersmith small roots", "Factor N = pq when the high bits of p are known. Technique: Coppersmith's small-root method, which is lattice reduction (the univariate case only).", "Toy size, declared but not compiled."),
    ("Distinguishing attacks (the dual attack)", "The claim is an advantage (how much better than a coin flip the distinguisher is), scored by an exact statistical bound rather than a run time.", "The method is built; the only worked example is a toy LWE-versus-random one."),
    ("Interactive attacks (decryption failures, chosen ciphertexts, side-channel models)", "The solver queries an oracle that the judge runs. The cost is the number of queries, and the transcript can be replayed.", "The method is built; the only worked example is not about lattices."),
    ("Attacks with heavy precomputation (closest-vector with preprocessing, amortised sieving)", "A preprocessing phase whose cost is shared across many instances, with the number of instances needed to break even reported.", "The method is built; the worked example is a discrete logarithm."),
    ("Quantum", "The exact gate count and T-count of a small circuit, checked by exact simulation. It is never used to claim a speedup.", "Built; the worked example is Grover search.")]

# The next lattice attack categories, listed after the toy domains in the table, in the order they are meant to be built. NOT BUILT as of 23 Nov 2026: build them, or edit this list, before the lattice round opens.
NOT_YET = [
    ("LWE with a sample oracle", "The solver asks for samples and is charged for each one, using the same counted-queries method as the interactive attacks above. This is the honest home for BKW, coded-BKW, Arora-Ge and statistical attacks, which need more samples than the fixed set Guldo's LWE problem gives."),
    ("LWE with leaked hints", "Perfect, modular and approximate hints about the secret. This is the active practical area for side-channel attacks on Kyber, Dilithium and Falcon."),
    ("Subset sum at density 1", "The regime where lattice reduction stops working well and representation-based methods (Howgrave-Graham-Joux, Becker-Coron-Joux) are the known approach. It suits pure Python and exact step counting."),
    ("The rest of Coppersmith's family", "Small private exponent RSA (Boneh-Durfee), partial key exposure, bivariate versions and approximate GCD."),
    ("LWE in the standard regime", "Uniform or centred-binomial secrets with Gaussian errors, which removes the bias towards guessing that small secrets give. A power-of-two cyclotomic variant (x^n + 1) covers what Guldo's NTRU and ring-LWE problems deliberately exclude: subfield and overstretched-modulus attacks. That ring is the hard case, because modulo q it has zero-divisors, which can make an instance's answer ambiguous."),
    ("Sieving, counted in vector operations", "Sieve papers count inner products as their cost, and Guldo already counts tensor operations for AI workloads. Counting them lets sieving ideas be compared by the cost model the literature uses, and needs no sieve library in the sandbox.")]

# Guldo has no way to certify these.
NOT_PLANNED = [
    ("A scaling exponent or cost model", "How a technique's cost grows with dimension, rather than how much faster it is at one size."),
    ("The prediction of a security estimator", "Whether an estimator's predicted cost matches what an attack really needs."),
    ("Memory or parallel cost", "Memory traffic and parallel depth are not captured by counting operations or by timing one core."),
    ("Quantum lattice algorithms at real size", "Guldo's quantum method works only on small circuits that can be simulated exactly.")]


def _lattice_page(P, r, st, now, ctx):
    msgs = _messages(r, "Not open yet. Submissions are accepted from the opening time above, once the round's seed commitments are public.",
                     "Open now. Follow the steps below. Six places in total are first come first served, so do not wait for the last day.",
                     "Closed to new entries. Every submission is now being evaluated; the seeds are revealed and the certificates published afterwards. Evaluation can take days.")
    tech_rows = [(f'<strong>{P.esc(n)}</strong>', P.md(t), P.esc(rep)) for n, t, rep in TECHNIQUES]
    cmds = (P.H.cmd("python3 -m venv guldo-env && source guldo-env/bin/activate && pip install guldo-cli fpylll cysignals numpy") + P.H.cmd("guldo lint my_solver.py --family gm")
            + P.H.cmd("guldo practice my_solver.py --family gm --n 1 --budget 60 --yes")
            + P.H.cmd(f"guldo submit my_solver.py --server {P.portal_url or 'https://submit.guldo.org'} --round {r['id']} --handle YOURHANDLE --accept-rules --publish-source"))
    body = (_hero(P, r, st, '<a class="btn primary" href="#techniques">Accepted techniques</a><a class="btn" href="#elsewhere">All lattice attack categories</a><a class="btn" href="#enter">How to enter</a>' + P.portal_link(r["id"], "Round page on the portal"))
            + '<div class="band light"><div class="wrap band-in">' + banner_for(P, st) + _status_card(P, r, st, now, msgs)
            + '<section class="card"><h2>The task</h2><p class="fine">You write one Python function, <span class="mono">solve(basis, bound2)</span>. <span class="mono">basis</span> is a list of integer vectors, '
              'and you return one nonzero vector of the lattice they span whose squared length is at most <span class="mono">bound2</span>, as a list of Python integers. '
              'Your solver and the baseline are run on questions fixed before the round, and the CPU time each one uses is measured. The result is a certificate: a lower bound, in bits, '
              'on how much faster your solver is (1 bit is about twice as fast). Anyone can recompute it from the public log and the revealed seeds, without taking anyone\'s word for it.</p></section>'
            + '<section class="card" id="why"><h2>Why this round exists</h2>'
              '<p class="fine">Lattice problems underlie the encryption and signature schemes now being standardised and deployed, such as Kyber, Dilithium and Falcon. '
              'The companion paper, ' + PAPER_LINK + ', argues that the searches used against lattices cover an egg-shaped region rather than a sphere, which it says could mean a very large saving at the sizes those schemes use. '
              'It puts the gap at 48 bits for Kyber-512 and 130 bits for Falcon-1024. Those are the paper\'s own estimates. This round does not test them, neither confirms nor refutes them, and never adds them to a result: the baseline here is plain block reduction by enumeration at dimensions 64 to 72, while the estimate is about sieving at cryptographic sizes, so the two cannot be compared or summed. '
              'You can read the paper and decide for yourself what it supports.</p>'
              '<p class="fine"><strong>Why the round counts only what lies beyond the egg.</strong> The egg\'s gap is <strong>already claimed</strong> in that paper, so counting it again here would count it twice. '
              'The round asks a different question: is there any further saving that has nothing to do with the egg? That is the gain it looks for, a separate saving on top of the egg and not a repeat of it. '
              'A technique that does use the egg is still welcome. It is measured and published like any other, but reported as &ldquo;inside the egg&rdquo;, not as new. '
              'You <a href="#egg">declare</a> which kind yours is.</p>'
              '<p class="fine"><strong>What it is for.</strong> The position is this: if a sizable gain turns up beyond the egg, confirmed independent of it, the recommendation will be that lattice cryptography be pulled from use and replaced. '
              'If no sizable gain turns up, that does not show that lattice cryptography is safe; the question stays where it was. '
              '</p>'
              '<p class="fine"><strong>What counts as sizable.</strong> This is fixed before the round opens. An entry meets it when it is confirmed independent of the egg, '
              'its certified credit is at least ' + str(TRIGGER_BITS) + ' bits, and its speedup does not shrink as the dimension grows from 64 to 72, as recomputed from the ladders published in its certificate. '
              + str(TRIGGER_BITS) + ' bits is the smallest gain this round certifies reliably, and a gain that holds as the dimension grows is the signal that matters at cryptographic sizes: a gain that shrinks is not. '
              'Meeting it opens a public review. A recommendation follows only if the review concludes that the gain carries up to cryptographic sizes. Missing the bar settles nothing either way.</p>'
              '<p class="fine"><strong>If an entry meets it.</strong> Every certificate and its credit is published as usual. The designers of the affected schemes are told first, '
              'and that entry\'s source may be held for up to ' + str(NOTICE_DAYS) + ' days after the deadline before it is published, so the designers can respond. Every other entry\'s source is published as stated in the rules.</p>'
              '<p class="fine"><strong>What a result can and cannot do.</strong> The lattices here have dimensions 64 to 72, and real schemes use dimensions in the hundreds. A certificate shows a measured speedup at small sizes. It does not show a break. '
              'A recommendation would rest on that measurement together with an argument that the gain carries up to cryptographic sizes, and it would be a published judgement, not an automatic result of the competition.</p>'
              '<p class="fine"><strong>Why now.</strong> The lattice analysis behind this round relies on Claude Opus 4.6. It has proved by far the best model available for lattice security work, and the only one usable for it. '
              'Anthropic lists it as available <a href="' + DEPRECATIONS_URL + '" rel="noopener">not sooner than 5 February 2027</a>, with at least 60 days\' notice before retirement, and gives no guarantee beyond that. '
              'Once it is retired, it can no longer be used for this work. The lattice round closes on 10 January 2027, which leaves under four weeks before that date to evaluate the entries and review any that meet the bar above.</p></section>'
            + '<section class="card"><h2>Settings</h2>' + P.facts(_lattice_settings(P)) + '</section></div></div>'
            + '<div class="band dark"><div class="wrap band-in"><section class="block" id="techniques"><p class="kicker">Techniques</p><h2>What you can use</h2>'
              '<p class="lede">The round accepts any method that returns a valid short vector inside &ldquo;the box&rdquo;, the locked environment your solver runs in. It does not care how you find the vector.</p>'
            + P.table(["Technique", "In this round", "Declare as"], tech_rows)
            + '<div class="two" style="margin-top:12px"><div class="card"><h3>What does not work</h3><ul class="fine">' + "".join(f"<li>{P.esc(x)}</li>" for x in NOT_ACCEPTED) + '</ul></div>'
              '<div class="card"><h3>What this round cannot test</h3><ul class="fine">'
              '<li>Methods that need ring structure. These are random lattices with none, so subfield, automorphism and other ring-algebraic techniques cannot show up here at all.</li>'
              '<li>How a speedup at dimensions 64 to 72 scales to real cryptographic sizes, which are in the hundreds.</li>'
              '<li>Worst-case lattices, other lattice problems, or run time on other hardware.</li></ul></div></div></section></div></div>'
            + '<div class="band light"><div class="wrap band-in"><section class="card" id="egg"><h2>Declare what your solver exploits</h2>'
              '<p class="fine">Put two comment lines within the first 40 lines of your file, so the results can keep the two kinds of gain apart (<a href="#why">why</a>):</p>' + P.H.cmd("# GULDO-MECHANISM: independent | angular | both") + P.H.cmd("# GULDO-ABLATION: none | <handle and id of your own submission with the mechanism switched off>")
            + P.table(["Declaration", "Meaning", "Reported as"], [
                (P.md("`independent`"), "The gain does not use the egg: a block-size schedule, pruning, early exit, batching, memory layout, preprocessing, or any other new idea.", "<strong>Beyond the egg</strong>, once your source has been read and the declaration confirmed: &ldquo;does not rely on that structure, and is measurably faster than the stock baseline&rdquo;."),
                (P.md("`angular`"), "The solver deliberately uses the egg: the shape of the Gram-Schmidt norms or of the angles between pairs of vectors.", "As measured, but <strong>inside the egg</strong>, not counted as new. A second version with the mechanism switched off allows your credit over your own switched-off version to be published too, as a secondary number that is never added to your certificate."),
                (P.md("`both`"), "Say in a comment which part is which.", "The whole entry as inside the egg, unless you submit the switched-off version too, which is judged on its own declaration.")])
            + '<p class="fine" style="margin-top:12px"><strong>Your credit is the measured credit whatever you declare.</strong> The declaration only decides what may be said about it afterwards. It is a comment and cannot be enforced by software: '
              'every published source is read, and a declaration may be corrected, with the correction published along with the reason. For a pair, submit the switched-off version first, copy its id from the receipt, and name it in the second version; both must be under the same handle.</p></section>'
            + '<section class="card" id="elsewhere"><h2>Every lattice attack category on Guldo</h2>'
              '<p class="fine">This round tests one problem. Methods for the other kinds of lattice attack below have been built or declared, and each would run as a round of its own. This is where each stands today.</p>'
            + P.table(["Problem or claim", "What exists", "Status"], [(f'<strong>{P.esc(a)}</strong>', P.md(b), P.md(c)) for a, b, c in ELSEWHERE + [(a, b, "A round of its own.") for a, b in NOT_YET]])
            + '<p class="fine" style="margin-top:12px">The seven recovery problems in the table are toy sizes, so a result on them says nothing about real parameters. They also compare a lattice attack with brute force, so they would probably not tell one lattice technique from another. '
              'Only the shortest vector problem does that today.</p>'
              '<h3>What cannot be certified</h3><ul class="fine">' + "".join(f"<li><strong>{P.esc(a)}.</strong> {P.esc(b)}</li>" for a, b in NOT_PLANNED) + '</ul>'
              '<p class="fine">If you can state a problem that is missing, with a way to check an answer and a plain baseline, <a href="propose.html">propose it</a>. '
              '<a href="domains.html">The Domains page</a> lists every problem that is declared, and what each one can and cannot show.</p></section></div></div>'
            + '<div class="band dark"><div class="wrap band-in"><section class="card" id="enter"><h2>How to enter</h2>'
              '<p class="fine">Install the tools in a virtual environment. <span class="mono">fpylll</span> alone installs but fails to import; it also needs <span class="mono">cysignals</span>, so the first command below installs all four packages together. '
              'Put the two declaration lines above at the top of your file. Then try it with <span class="mono">guldo practice</span>: without <span class="mono">--yes</span> it only prints its plan and its worst-case cost and runs nothing. '
              'A practice certificate is provisional, because you know the questions. When you are ready, submit. '
              '<strong>Submitting publishes your source after the deadline.</strong> The command prints a token once; keep it, because it is the only way to submit again under your handle.</p>' + cmds
            + '<p class="fine">Your solver runs in a locked box: no network, one CPU, 4 GB of memory, the standard library, numpy and fpylll only.</p></section>'
            + '<section class="card"><h2>What a result means</h2><p class="fine">Credit is a statistical lower bound on the speedup, in bits, over 48 questions per dimension and three seeds. The three seeds are independent repetitions, and your credit is the <em>minimum</em> over them, with an inconclusive seed counting as zero, so one lucky seed does not help. '
              'Zero means &ldquo;not shown to be faster&rdquo;, not &ldquo;slower&rdquo;. Small gains usually come back inconclusive because timing noise hides them (half a bit to one bit almost always does). Very large gains do too: above about 5 bits the baseline hits its own time limit. '
              'At this round\'s settings, a true constant speedup of 3 bits is certified about 99% of the time, 4 bits about 68% and 5 bits about 50%. Time is CPU time on the evaluation machine, so a solver tuned for your own hardware may not carry over. '
              'See <a href="limits.html">Limits</a> and the <a href="method.html">Method page</a>.</p></section></div></div>')
    return _layout(P, r, st, now, body)


def banner_for(P, st):
    if st == "closed":
        return ""
    return P.H.banner("<strong>Status: planned, not yet run.</strong> No outside entrant has used this system yet. The counted factoring round runs first, and this round opens the day after it closes. "
                      "Read these dates as the plan, and see the Limits page for what has and has not been tested.")


# ----------------------------------------------------------------------------------------------------------- golf-1
def _golf_page(P, r, st, now, ctx):
    msgs = _messages(r, "Not open yet. How to submit an entry is announced, with the plan hash and the seed commitment, before it opens.",
                     "Open now. Submit through the channel announced with the plan.",
                     "Closed to new entries. Every entry is scored, then the plan, the revealed seed, every entry and every saved ladder are published.")
    ops = P.table(["Operation", "Cost"], [
        (P.md("`+ - * /`, `exp`, `sqrt`, `relu`, negation"), "the size of the result"), (P.md("`a @ b`, a matrix product"), "2 x the size of the result x the shared dimension"),
        (P.md("`tp.einsum` with two operands"), "2 x the product of every index's extent"), (P.md("`sum`, `max`, `mean`, `argmax`"), "the size of the input"),
        (P.md("`tp.stream(seed, start, n)`, the random stream"), "10 per element"), (P.md("`tolist`"), "the size of the tensor"),
        (P.md("`reshape`, `transpose`, `take`, `concat`, slicing, `zeros`, constants"), "free: data movement"),
        ("Every Python bytecode instruction in your own code", "1, so work cannot be hidden in plain-float loops")])
    body = (_hero(P, r, st, '<a class="btn primary" href="#how">How it is scored</a><a class="btn" href="#enter">How to enter</a>', kicker="AI workloads")
            + '<div class="band light"><div class="wrap band-in">' + P.H.banner("<strong>Status: built and rehearsed, not launched.</strong> The entry channel and the exact plan will be announced before it opens. There is no prize.")
            + _status_card(P, r, st, now, msgs)
            + '<section class="card"><h2>The task</h2><p class="fine">A small transformer is generated from a seed: 2 layers, width 128, 4 attention heads, a vocabulary of 64 tokens, and greedy decoding. Your program rebuilds the whole model from the seed and decodes from it, '
              'through a function <span class="mono">solve(seed, prompt_len, T)</span> that returns the <span class="mono">T</span> generated token ids. The feed-forward matrices are products of thin factors, and a program can exploit that. '
              'A token is accepted if, given the prompt and your own earlier tokens, its logit is within a tiny tolerance of the model\'s best. Any exact or equivalent way of computing the same tokens is fine; a shortcut that changes the tokens is not.</p>'
              '<p class="fine">The baseline is a key-value cache that multiplies the factors out into dense matrices once. To score, you must need fewer operations than that. '
              'A solution that needs about 2.4 times fewer is held back, and published after the close. Whether anyone finds more is what the leaderboard will show.</p></section></div></div>'
            + '<div class="band dark"><div class="wrap band-in"><section class="block" id="how"><p class="kicker">Scoring</p><h2>An operation is counted, not timed</h2>'
              '<p class="fine">The score is how many arithmetic operations your program asked for, counted exactly and identically on every machine, so there is no clock to argue about and anyone can re-run any entry and get the same number. The fewest total operations over the whole ladder wins; '
              'the leaderboard also shows the ratio against the baseline at each size. Ties go to the earlier submission.</p>' + ops
            + '<div class="two" style="margin-top:12px"><div class="card"><h3>Rules for your program</h3><ul class="fine"><li>One file, up to 200 KB, in a restricted subset of Python that allows <span class="mono">math</span>, <span class="mono">itertools</span> and <span class="mono">tensorops</span> only. No files, no numpy, no <span class="mono">eval</span>.</li>'
              '<li>Official counts need <strong>Python 3.14.0</strong> exactly, because bytecode counts depend on the interpreter.</li><li>At most 100 counted seconds per instance (one counted second is 10 million operations).</li>'
              '<li>An entry is disqualified, with the reason published, if it breaks the subset or the size limit, returns a wrong token or no answer on any instance, goes over the budget, is not deterministic, or has an invalid handle.</li></ul></div>'
              '<div class="card"><h3>Fairness</h3><p class="fine">Every entry is run on a committed &ldquo;ladder&rdquo; of questions: the task, sizes, number of instances and budget are fixed in a plan whose hash is published before the competition opens. The seed stays secret until the competition closes, and its hash is published up front. '
              'After the close, the plan, the revealed seed, every entry and every saved ladder are published, and anyone on Python 3.14.0 can re-execute every record with <span class="mono">opgolf.py verify</span>. The only thing taken on trust is that the plan hash and the seed hash were published before the entries were run.</p></div></div></section></div></div>'
            + '<div class="band light"><div class="wrap band-in"><section class="card" id="enter"><h2>How to enter</h2>'
              '<p class="fine">The window is four weeks from opening, and it closes at a fixed UTC time announced with the plan hash. The round is open to anyone, with one handle per person or team. A handle can be a pseudonym, and nothing else about you is collected. '
              'You may resubmit as often as you like before the close: the latest file counts, and the earlier ones are kept. There is no prize.</p>'
              '<p class="fine"><strong>Submitting means consent to publish</strong> your file, its hash and its score after the close. You keep the copyright in your code; do not submit what you cannot publish.</p>'
              '<p class="fine"><strong>How to submit is not settled yet.</strong> The competition tool is not in the installable package today, so the way to check an entry and the channel to send it through will be announced with the plan before the round opens. '
              'Until then, you can read how the counting works in the <a href="domains.html#ai">AI section of the Domains page</a>.</p></section>'
            + '<section class="card"><h2>What this does and does not show</h2><ul class="fine"><li>It measures the arithmetic a program asks for, not how fast it runs. A faster kernel, lower precision or a better memory layout is invisible to it. It can show that an idea needs N times fewer operations; it cannot show that the idea is faster on any machine.</li>'
              '<li>The model is small, and the costs depend only on shapes, so they are the same for every instance of one size. A fresh seed tests that your tokens are correct, not the cost model.</li>'
              '<li>Entries run on the evaluation machine, inside a restricted subset of Python and a memory watchdog. That contains honest mistakes and casual tricks. It is not a proof against a determined attack on the interpreter, so scoring runs as an unprivileged throwaway user.</li>'
              '<li>The baseline was left with room to improve on purpose, and the held-back solution uses that room. So a gain over the baseline shows you found a better method; it does not show that no better method exists.</li></ul></section></div></div>')
    return _layout(P, r, st, now, body)


# ----------------------------------------------------------------------------------------------------------- any other round
def _generic_page(P, r, st, now, ctx):
    msgs = _messages(r, "Not open yet.", P.md(r["enter"]) if r.get("enter") else "Open. See the round's page on the portal for how to take part.", "Closed to new entries.")
    body = (_hero(P, r, st, P.portal_link(r["id"], "Round page on the portal"))
            + '<div class="band light"><div class="wrap band-in">' + _status_card(P, r, st, now, msgs)
            + '<section class="card"><h2>Details</h2><p class="fine">The rules, settings and seed commitments of this competition are published with the round. They are not on this page yet.</p>'
              '<p class="fine">What a result from a round like this means, and what it does not, is on the <a href="limits.html">Limits</a> page.</p></section></div></div>')
    return _layout(P, r, st, now, body)


BUILDERS = {"factor-1": _factor_page, "lattice-1": _lattice_page, "golf-1": _golf_page}


def pages(schedule, rounds_index, ledger_dir, portal_url, H, now=None):
    """{filename: html} for every round in the schedule. H supplies the builder's own layout, esc, cmd, banner and schedule_status."""
    now = time.time() if now is None else now
    P = _Page(H, portal_url)
    known = {x.get("id"): x.get("state") for x in (rounds_index or []) if isinstance(x, dict)}
    out = {}
    for r in schedule or []:
        fn = filename(r["id"])
        if not fn:
            continue
        r = dict(r)
        r["ledger"] = known.get(r["id"]) and str(known[r["id"]]) or ""
        st = H.schedule_status(r, now, known.get(r["id"]))
        P.status = st
        out[fn] = BUILDERS.get(r["id"], _generic_page)(P, r, st, now, {"ledger_dir": ledger_dir})
    return out
