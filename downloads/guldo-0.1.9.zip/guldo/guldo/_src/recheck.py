"""Recompute a compiled domain's checkable claims from its own record, and (optionally) re-measure its profile on this machine.

  python3 compile_domain.py recheck NAME             seconds to a minute: everything that is arithmetic, recomputed and compared
  python3 compile_domain.py recheck NAME --measure 3 also re-measure each ladder size with 3 instances on THIS machine and report the gap

What it proves: the declaration and reference are the hashed files; the validation checks still give the recorded verdicts; the ladder, n and
CPU-hour figures follow from the recorded plan; and the whole power table (seeded) comes out identical. What it cannot prove: that the
recorded profile timings, or the recorded self-test, were honestly measured. `--measure` does not prove them either: it shows how far this
machine's timings sit from the recorded ones, which is the evidence a reader needs about machine-to-machine spread. The self-test is not
recomputed (it takes hours); `compile_domain.py selftest NAME` reruns it.

SAFETY: this EXECUTES the declaration's decl.py and the reference solver on this machine, unsandboxed (validation derives instances with the
declaration; --measure runs the reference). Do not recheck a declaration you did not read, except in a throwaway VM.
"""
import math
import os
import statistics

import compile_domain as C
import declared

MEASURE_WARN_BITS = 1.0   # this machine's median differs from the recorded one by more than this many bits: say so


def _same_curve(a, b):
    return C.canon(a) == C.canon(b)


def recheck(dirpath, measure_k=0, log=C._log):
    out = []
    mod, ref, res = C.parse(dirpath)
    out += res
    if C.worst(res) == "fail":
        return out
    compiled = declared.read_compiled(dirpath)
    problems = declared.freshness_problems(dirpath, mod, compiled)
    out.append(C.R("record is current", "fail" if problems else "pass", "; ".join(problems) if problems else "decl.py and the reference hash as recorded"))
    if problems:
        return out

    plan, pw, official = compiled["plan"], compiled["power"], compiled["official"]
    bad = []
    if list(compiled["dims"]) != list(plan["sizes"]):
        bad.append(f"dims {compiled['dims']} != plan sizes {plan['sizes']}")
    if official["n"] != pw["n"]:
        bad.append(f"official n {official['n']} != power n {pw['n']}")
    if official["budget"] != plan["cap"]:
        bad.append(f"official budget {official['budget']} != plan cap {plan['cap']}")
    cost = C.cpu_hours(plan, pw["n"])
    if cost != compiled["cpu_hours"]:
        bad.append(f"CPU-hours recompute to {cost}, recorded {compiled['cpu_hours']}")
    out.append(C.R("plan arithmetic", "fail" if bad else "pass",
                   "; ".join(bad) if bad else f"ladder, n={pw['n']}, cap {plan['cap']} s and CPU-hours ({cost['expected']} expected, {cost['worst_case']} worst) follow from the record"))

    log("recheck: re-running the validation checks ...")
    fresh = C.validate(mod, dirpath, ref)
    old = {r["check"]: r["status"] for r in compiled["validation"]}
    new = {r["check"]: r["status"] for r in fresh}
    parsed = {r["check"] for r in out}   # the parse pass's own checks are recorded beside validation's, but validate() does not regenerate them
    diff = [f"{k}: recorded {old.get(k, 'absent')}, now {new.get(k, 'absent')}" for k in sorted(set(old) | set(new))
            if k not in parsed and old.get(k) != new.get(k)]
    out.append(C.R("validation reproduces", "fail" if diff else "pass",
                   "; ".join(diff) if diff else f"{len(new)} checks give the recorded verdicts (the recorded ones were run at compile time with the same seeds)"))

    log("recheck: recomputing the power table (seeded) ...")
    again = C.power_plan(plan, target_effect=pw["target_effect"], target_power=pw["target_power"], pair_noise=pw["pair_noise"],
                         triples=pw["triples"], boot=pw["boot"], log=lambda *a: None)
    if _same_curve(again, pw):
        out.append(C.R("power table reproduces", "pass", f"identical: n={again['n']}, certifies {again['min_certifiable_effect']} to {again['max_certifiable_effect']} bits, "
                       f"zero-effect false credit {100 * again['curve']['0']['single']:.1f}%"))
    else:
        keys = [k for k in again if C.canon(again[k]) != C.canon(pw.get(k))]
        out.append(C.R("power table reproduces", "fail", f"differs in {keys}: the record was not produced by this estimator and plan, or the Python/random version differs"))

    st = compiled.get("selftest") or {}
    out.append(C.R("self-test", "pass" if st.get("status") == "pass" else "warn",
                   f"recorded status {st.get('status', 'absent')} at {st.get('at', '?')}; NOT recomputed (hours): `python3 compile_domain.py selftest {os.path.basename(os.path.abspath(dirpath))}`"))

    if measure_k > 0:
        out += _measure(mod, ref, compiled, measure_k, log)
    else:
        out.append(C.R("profile timings", "warn", "recorded, not re-measured: add --measure K to compare this machine's costs with the recorded ones"))
    return out


def _positive(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) and x > 0


def _usable_costs(raw):
    """{instance index: (cost, solved)} from a record's `costs`, keeping only well-formed entries. A compiled record may come from someone else, so
    anything malformed (wrong shape, non-positive or non-finite cost) is dropped, never raised on and never divided by."""
    out = {}
    if not isinstance(raw, list):
        return out
    for e in raw:
        if isinstance(e, (list, tuple)) and len(e) == 3:
            i, c, ok = e
            if isinstance(i, int) and not isinstance(i, bool) and _positive(c) and isinstance(ok, bool):
                out[i] = (c, ok)
    return out


def _measure(mod, ref, compiled, k, log):
    prof = compiled["profile"]
    measure = C.default_measure(mod, ref, C.PROFILE_SEED, compiled["plan"]["cap"], prof["overhead"])
    res, gaps = [], []
    for s in compiled["dims"]:
        log(f"recheck: measuring size {s} ({k} instances) ...")
        recs = [measure(s, i) for i in range(k)]
        mine = statistics.median(C._cost(r, compiled["plan"]["cap"]) for r in recs)
        entry = prof["sizes"].get(str(s), {})
        recorded = _usable_costs(entry.get("costs"))
        # the SAME instances (instance i is a function of the public profiling seed), and only those SOLVED both when compiled and now: a timeout is a
        # censored cost (the cap it hit may differ between then and now), not a measurement
        both = [i for i in range(k) if i in recorded and recorded[i][1] and recs[i]["status"] == "solved"]
        used = k
        if recorded and both:
            mine = statistics.median(C._cost(recs[i], compiled["plan"]["cap"]) for i in both)
            rec, basis, warn_at, used = statistics.median(recorded[i][0] for i in both), "same", MEASURE_WARN_BITS, len(both)
            note = f" [on {len(both)} of {k} instances solved both then and now; the rest timed out or are not in the record]" if len(both) < k else ""
        elif _positive(entry.get("median_cost")):
            # an older record keeps only the median over all its instances: comparing K of them with it includes sampling noise, which is stated, not hidden
            sd = entry.get("sd_log2") or 1.5
            noise = sd / math.sqrt(k)
            rec, basis, warn_at = entry["median_cost"], "median", max(MEASURE_WARN_BITS, 2 * noise)
            note = (f" [recorded median over {entry.get('n', '?')} instances, compared with the first {k}: sampling noise alone is about ±{noise:.1f} bits (per-instance sd "
                    f"{sd:.1f}); recompile to record per-instance costs for an exact comparison]")
        else:
            res.append(C.R(f"size {s} timing", "warn", f"this machine {mine:.2f} s; no recorded median at this size"))
            continue
        gap = math.log2(mine / rec)
        gaps.append(gap)
        res.append(C.R(f"size {s} timing", "warn" if abs(gap) > warn_at else "pass",
                       f"this machine median {mine:.2f} s ({k} instances), recorded {rec:.2f} s: {gap:+.2f} bits{note}"))
        res[-1]["data"] = {"size": s, "mine": round(mine, 4), "recorded": round(rec, 4), "gap_bits": round(gap, 4), "k": k, "used": used, "basis": basis}
    if gaps:
        res.append(C.R("machine spread", "pass", f"this machine vs the recorded one: mean {statistics.mean(gaps):+.2f} bits, worst {max(gaps, key=abs):+.2f} bits over {len(gaps)} sizes "
                       "(a gap that is the same at every size is a hardware speed difference and cancels in a speedup ratio; one that changes with size is not)"))
    return res


# ------------------------------------------------------------------------------------------------------------- machine spread
SPREAD_FORMAT = "svp-measurements-v1"
MIN_TOLERANCE = 1.0   # bits. certificate.py's re-measurement compares single instances (pair noise ~0.6 bit); a tolerance below this fails honest certificates


def machine_id():
    """A description of this machine, and a short hash of its host name (so two files from one machine are recognised without printing the name;
    a guessable host name can still be confirmed from the hash, so do not treat it as anonymous)."""
    import hashlib
    import platform
    return {"platform": platform.platform(), "machine": platform.machine(), "python": platform.python_version(),
            "host_hash": hashlib.sha256(platform.node().encode()).hexdigest()[:12]}


def save_measurements(res, compiled, path):
    """Write the per-size gaps from a `recheck --measure` run. Never overwrites."""
    import json
    import time
    rows = [r["data"] for r in res if r.get("data") and "gap_bits" in r["data"]]
    if not rows:
        raise SystemExit("nothing to save: run with --measure K first")
    doc = {"format": SPREAD_FORMAT, "domain": compiled["name"], "version": compiled["version"], "decl_sha256": compiled["decl_sha256"],
           "machine": machine_id(), "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "sizes": rows}
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1, sort_keys=True)


def _read_measurements(path):
    """A measurement file comes from another machine, so it is untrusted: accept exactly the shape save_measurements writes, and make every string
    that will be printed plain ASCII (a hostile platform string must not be able to drive the terminal)."""
    import json
    import re
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        if not isinstance(d, dict) or d.get("format") != SPREAD_FORMAT:
            raise ValueError(f"not a {SPREAD_FORMAT} file")
        m = d["machine"]
        if not (isinstance(d["domain"], str) and isinstance(d["decl_sha256"], str) and re.fullmatch(r"[0-9a-f]{1,64}", d["decl_sha256"])
                and isinstance(m, dict) and isinstance(m["host_hash"], str) and re.fullmatch(r"[0-9a-f]{1,32}", m["host_hash"]) and isinstance(m["platform"], str)):
            raise ValueError("header fields are malformed")
        if not isinstance(d["sizes"], list) or not d["sizes"] or len(d["sizes"]) > 100:
            raise ValueError("sizes is not a short, non-empty list")
        for r in d["sizes"]:
            if not (isinstance(r, dict) and isinstance(r["size"], int) and not isinstance(r["size"], bool)
                    and isinstance(r["gap_bits"], (int, float)) and not isinstance(r["gap_bits"], bool) and math.isfinite(r["gap_bits"]) and abs(r["gap_bits"]) <= 64):
                raise ValueError("a size entry is malformed")
    except (OSError, ValueError, KeyError, TypeError) as e:
        raise SystemExit(f"REFUSED: {path} is not a valid measurement file ({type(e).__name__}: {str(e)[:80]})")
    d["machine"]["platform"] = re.sub(r"[^\x20-\x7e]", "?", m["platform"])[:80]
    d["domain"] = re.sub(r"[^\x20-\x7e]", "?", d["domain"])[:40]
    return d


def spread(files, min_machines=2):
    """Merge measurement files from different machines. -> (results, recommended tolerance in bits or None).

    A speedup is a ratio, so a uniform hardware difference cancels. What does not cancel is how a machine's gap CHANGES from size to size (the
    baseline and a solver sit at different costs, so a machine that is relatively slower at large sizes distorts the ratio). Each machine's
    within-machine range of gaps (max - min over sizes) bounds that; the recommendation is the largest range, rounded up to a quarter bit,
    never below 0.25. It is an estimate from a handful of sizes and machines, and is None until at least `min_machines` DISTINCT machines
    measured the SAME declaration."""
    import json
    docs = [_read_measurements(p) for p in files]
    res = []
    if len({(d["domain"], d["decl_sha256"]) for d in docs}) > 1:
        return [C.R("same declaration", "fail", "the files measured different declarations (name or decl hash differ): they cannot be merged")], None
    res.append(C.R("same declaration", "pass", f"{docs[0]['domain']} {docs[0]['decl_sha256'][:12]}"))
    machines = {}
    for d in docs:
        machines.setdefault(d["machine"]["host_hash"], []).append(d)
    ranges = {}
    for h, ds in machines.items():
        by_size = {}
        for d in ds:
            for r in d["sizes"]:
                by_size.setdefault(r["size"], []).append(r["gap_bits"])
        gaps = {s: statistics.mean(v) for s, v in by_size.items()}
        rng = max(gaps.values()) - min(gaps.values()) if len(gaps) > 1 else 0.0
        ranges[h] = rng
        res.append(C.R(f"machine {h}", "pass", f"{ds[0]['machine']['platform']}: mean gap {statistics.mean(gaps.values()):+.2f} bits, "
                       f"range across sizes {rng:.2f} bits ({len(gaps)} sizes)"))
    if len(machines) < min_machines:
        res.append(C.R("tolerance", "warn", f"{len(machines)} distinct machine(s): need at least {min_machines} to recommend a tolerance. The default stays loose"))
        return res, None
    if any(r.get("basis") != "same" for d in docs for r in d["sizes"]):
        res.append(C.R("comparison basis", "warn", "some gaps were measured against a recorded MEDIAN over different instances, so they include sampling noise "
                       "(often a bit or more): the recommendation below is inflated by it. Recompile the domain (records per-instance costs) and measure again for a clean figure"))
    rec = max(MIN_TOLERANCE, math.ceil(max(ranges.values()) * 4) / 4)
    res.append(C.R("tolerance", "pass", f"recommended --tolerance {rec:g} bits (largest within-machine range across sizes, {len(machines)} machines, never below {MIN_TOLERANCE:g}: "
                   "the re-measurement compares single instances, whose own noise is about 0.6 bit and is NOT measured here). "
                   "An estimate from a few sizes: use it for `certificate.py verify --tolerance`, do not treat it as a bound"))
    return res, rec
