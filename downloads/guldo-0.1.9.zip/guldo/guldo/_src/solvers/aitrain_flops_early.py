"""aitrain in the counted-operations API, TECHNIQUE: scale every feature to unit size, hold out the last fifth of the training set, take gradient steps and stop as soon as
that held-out fifth is classified at least 92% right (checked every 5 steps, at most 400 steps). The cost therefore differs from instance to instance."""
import math

import tensorops as tp

K = 3
KAPPA = 30.0
MAXSTEPS = 400
CHECK = 5
LR = 1.0
STOP = 0.92


def solve(seed, d, n, labels):
    sc = tp.tensor([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = tp.reshape(tp.stream(seed, 0, n * d), (n, d)) * sc
    nv = n // 5
    ntr = n - nv
    Xtr = X[0:ntr]
    inv = 1.0 / tp.sqrt(tp.mean(Xtr * Xtr, 0))
    A = Xtr * inv
    Av = X[ntr:n] * inv
    Y = tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(ntr)])
    Yv = tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(ntr, n)])
    At = tp.transpose(A, (1, 0))
    W = tp.zeros((d, K))
    for step in range(MAXSTEPS):
        Z = A @ W
        E = tp.exp(Z - tp.max(Z, 1, True))
        W = W - (At @ (E / tp.sum(E, 1, True) - Y)) * (LR / ntr)
        if step % CHECK == CHECK - 1:
            Zv = Av @ W
            gap = (tp.max(Zv, 1) - tp.sum(Zv * Yv, 1)).tolist()
            right = 0
            for g in gap:
                if g <= 0.0:
                    right += 1
            if right >= STOP * nv:
                break
    return [int(x * 1048576.0) for x in tp.reshape(W * tp.reshape(inv, (d, 1)), (d * K,)).tolist()]
