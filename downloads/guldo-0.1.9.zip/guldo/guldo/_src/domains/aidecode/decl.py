"""Declaration of an AI-decoding domain: greedy autoregressive generation from a small transformer, as cheaply as you can, token for token correct.

size = T, the number of tokens to generate after an 8-token prompt. The model is a 2-layer pre-RMSNorm transformer (d=128, 4 heads, FF 512, vocab 64,
tied output embedding, learned absolute positions, ReLU). Like `aiinfer` it is not shipped as data: every parameter and the prompt are a pure function of one
seed through a pinned SplitMix64 stream (stream layout and shapes in reference.py), so a solver rebuilds the exact floats with numpy alone.

The reference recomputes the whole sequence from scratch for every new token. Caching each layer's keys and values (a "KV cache") produces the same tokens
with O(1) projections per step instead of O(t): the textbook inference speedup, and one whose saving is in OPERATIONS, so the counted-FLOPs mode
(tflops.py) can certify it without trusting any machine. float32 and quantised variants are also allowed; they must keep every token right.

Verification is TEACHER-FORCED: the judge runs the model once, in float64 and in parallel, over prompt + submitted tokens and accepts the answer iff every
submitted token's logit is within TOL_SIGMA * std(logits) of the best logit at its position. Different arithmetic orders (cached, batched, float32) pass; a
shortcut (repeat a token, skip a layer, prune) fails at the first position where it disagrees. Weights are scaled (W_SCALE, POS_SCALE) so the greedy output
is NOT degenerate: with unit-scale weights the model repeats one token for ever and "repeat" would pass (measured, and why the scales are what they are).
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aidecode"
VERSION = "aidecode-v1"       # bump whenever derive() or the model definition changes
SIZE_RANGE = (256, 4096)      # below ~256 the reference costs under the compiler's 0.05 s measurability floor, which makes its first probe useless
SIZE_STEP = 32
REFERENCE_SOLVER = "reference.py"
V, D, H, DH, FF, L, PROMPT = 64, 128, 4, 32, 512, 2, 8
W_SCALE, POS_SCALE = 4.0, 3.0
TOL_SIGMA = 1e-3
DOC = ("solve(seed, prompt_len, T): rebuild the model and prompt from `seed` (SplitMix64 stream, layout in domains/aidecode/reference.py), generate T tokens "
       "greedily (argmax of the next-token logits; the prompt has prompt_len = 8 tokens) and return the list of T token ids. Every returned token must be, at its "
       "position, within 1e-3 standard deviations of the best logit given the prompt and your own earlier tokens (float32 passes; shortcuts do not). "
       "Return None for no answer.")
REFERENCE_NOTE = ("Recomputes the full forward pass over the whole sequence for every generated token (no KV cache), float64. Known to be beaten by caching "
                  "each layer's keys and values, which turns the per-token cost from O(t) projections to O(1); the saving grows with T.")

_GOLD = 0x9E3779B97F4A7C15
_C1 = 0xBF58476D1CE4E5B9
_C2 = 0x94D049BB133111EB


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _params(seed, T):
    o = [0]

    def take(shape, scale):
        n = int(np.prod(shape))
        a = (_uniform(seed, o[0], n) * scale).reshape(shape)
        o[0] += n
        return a
    sd, sf = W_SCALE * math.sqrt(3.0 / D), W_SCALE * math.sqrt(3.0 / FF)
    P = {"tok": take((V, D), math.sqrt(3.0)), "layers": []}
    for _ in range(L):
        P["layers"].append({"Wq": take((D, D), sd), "Wk": take((D, D), sd), "Wv": take((D, D), sd), "Wo": take((D, D), sd),
                            "W1": take((D, FF), sd), "W2": take((FF, D), sf)})
    P["pos"] = take((PROMPT + T, D), POS_SCALE * math.sqrt(3.0))
    P["prompt"] = np.minimum(((_uniform(seed, o[0], PROMPT) + 1.0) * 0.5 * V).astype(np.int64), V - 1)
    return P


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def _forward(P, toks):
    """Parallel causal forward over a whole sequence -> logits (n, V). The judge's definition of the model."""
    n = len(toks)
    x = P["tok"][toks] + P["pos"][:n]
    mask = np.triu(np.full((n, n), -1e30), 1)
    for l in P["layers"]:
        h = _rms(x)
        q, k, v = [(h @ l[w]).reshape(n, H, DH).transpose(1, 0, 2) for w in ("Wq", "Wk", "Wv")]
        s = q @ k.transpose(0, 2, 1) / math.sqrt(DH) + mask
        s -= s.max(-1, keepdims=True)
        a = np.exp(s)
        a /= a.sum(-1, keepdims=True)
        x = x + (a @ v).transpose(1, 0, 2).reshape(n, D) @ l["Wo"]
        x = x + np.maximum(_rms(x) @ l["W1"], 0.0) @ l["W2"]
    return _rms(x) @ P["tok"].T


def _greedy_cached(P, T):
    """Judge-side generation with a KV cache (fast): the planted answer."""
    n = PROMPT + T
    K = [np.zeros((n, D)) for _ in range(L)]
    Vv = [np.zeros((n, D)) for _ in range(L)]
    seq = [int(t) for t in P["prompt"]]
    out = []
    for p in range(n - 1):
        x = P["tok"][seq[p]] + P["pos"][p]
        for li, l in enumerate(P["layers"]):
            h = _rms(x)
            q = (h @ l["Wq"]).reshape(H, DH)
            K[li][p], Vv[li][p] = h @ l["Wk"], h @ l["Wv"]
            kc = K[li][:p + 1].reshape(p + 1, H, DH)
            vc = Vv[li][:p + 1].reshape(p + 1, H, DH)
            s = np.einsum("hd,thd->ht", q, kc) / math.sqrt(DH)
            s -= s.max(-1, keepdims=True)
            a = np.exp(s)
            a /= a.sum(-1, keepdims=True)
            x = x + np.einsum("ht,thd->hd", a, vc).reshape(D) @ l["Wo"]
            x = x + np.maximum(_rms(x) @ l["W1"], 0.0) @ l["W2"]
        if p >= PROMPT - 1:
            t = int(np.argmax(_rms(x) @ P["tok"].T))
            out.append(t)
            seq.append(t)
    return out


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aidecode-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    return {"args": [seed, PROMPT, size], "planted": _greedy_cached(_params(seed, size), size)}


def verify(inst: dict, ans) -> bool:
    seed, plen, T = inst["args"]
    if not isinstance(ans, list) or len(ans) != T:
        return False
    if any(isinstance(c, bool) or not isinstance(c, int) or not 0 <= c < V for c in ans):
        return False
    P = _params(seed, T)
    seq = np.concatenate([P["prompt"], np.asarray(ans, dtype=np.int64)])
    L_ = _forward(P, seq[:-1])[PROMPT - 1:]
    tol = TOL_SIGMA * float(L_.std())
    return bool(np.all(L_[np.arange(T), np.asarray(ans)] >= L_.max(axis=1) - tol))
