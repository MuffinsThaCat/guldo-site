def solve(oracle, bits):
    lo, hi = 0, (1 << bits) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if oracle(mid):
            lo = mid
        else:
            hi = mid - 1
    return lo
