"""aickpt in the counted API, CHEAT: truncated backpropagation. Keep only the last 4 steps' activations and backpropagate through those alone. Cheaper and smaller, and not the gradient: the judge must reject it."""
import math

import tensorops as tp


def parts(seed, w, B):
    X = tp.reshape(tp.stream(seed, 0, B * w), (B, w))
    W = tp.reshape(tp.stream(seed, B * w, w * w), (w, w)) * math.sqrt(3.0 / w)
    T = tp.reshape(tp.stream(seed, B * w + w * w, B * w), (B, w))
    return X, W, T


def step(h, W, alpha):
    """One forward step; returns the next activation and the ReLU mask (1 where the pre-activation was positive)."""
    a = h @ W
    ra = tp.relu(a)
    return h + ra * alpha, ra / (tp.sqrt(a * a) + 1e-300)


def fwd(h, W, alpha):
    """One forward step without the mask (a pass that will not be backpropagated)."""
    return h + tp.relu(h @ W) * alpha


def ints(dW, w):
    return [int(v * 1099511627776.0) for v in tp.reshape(dW, (w * w,)).tolist()]

KEEP = 4


def solve(seed, L, w, B):
    X, W, T = parts(seed, w, B)
    alpha = 0.5 / L
    Wt = tp.transpose(W, (1, 0))
    h = X
    X = 0
    hs = []
    ms = []
    for t in range(L):
        if t >= L - KEEP:
            hs.append(h)
            h, m = step(h, W, alpha)
            ms.append(m)
        else:
            h = fwd(h, W, alpha)
    delta = (h - T) * (1.0 / (B * w))
    dW = tp.zeros((w, w))
    for j in range(KEEP - 1, -1, -1):
        gm = delta * ms[j]
        dW = dW + (tp.transpose(hs[j], (1, 0)) @ gm) * alpha
        delta = delta + (gm @ Wt) * alpha
    return ints(dW, w)
