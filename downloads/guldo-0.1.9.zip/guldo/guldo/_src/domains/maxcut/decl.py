"""Declaration of a QUALITY challenge: max-cut on graphs with a planted good cut (see COMPILER.md, "Quality challenges").

A solver receives (n, edges) and returns a list of n bits (a side for every node). ANY such list is valid; the score is how many edges it cuts relative to the planted
partition's cut, capped at 1. So the question is not "who answers first" but "who finds the better cut inside the same CPU budget". The reference is a one-sweep greedy:
simulated annealing or repeated local search beats it by many points.
"""
import hashlib
import hmac
import random

NAME = "maxcut"
VERSION = "maxcut-v1"            # bump whenever derive() changes
SIZE_RANGE = (60, 300)           # number of nodes
SIZE_STEP = 60
REFERENCE_SOLVER = "reference.py"
QUALITY_BUDGET = 5               # CPU seconds per instance, for everyone
QUALITY_MIN_GAIN = 0.02          # a mean gain of two quality points is worth certifying
DOC = "solve(n, edges): return a list of n integers, each 0 or 1 (the side of every node). The score is the number of edges cut, divided by the planted partition's cut (at most 1)."
REFERENCE_NOTE = ("One random assignment improved by a single greedy sweep of single-node flips. Repeated local search or simulated annealing is known to beat it "
                  "by several quality points within the same budget.")
CROSS = 0.8                      # probability an edge crosses the planted partition


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"maxcut-v1:{size}:{idx}".encode(), hashlib.sha256).digest())
    side = [rng.randrange(2) for _ in range(size)]
    edges = []
    while len(edges) < 4 * size:
        u, v = rng.randrange(size), rng.randrange(size)
        if u == v:
            continue
        if (side[u] != side[v]) == (rng.random() < CROSS):
            edges.append([u, v])
    best = sum(side[u] != side[v] for u, v in edges)
    return {"args": [size, edges], "planted": side, "best": best}


def verify(inst: dict, ans) -> bool:
    n = inst["args"][0]
    return isinstance(ans, list) and len(ans) == n and all(isinstance(b, int) and not isinstance(b, bool) and b in (0, 1) for b in ans)


def quality(inst: dict, ans) -> float:
    edges = inst["args"][1]
    cut = sum(ans[u] != ans[v] for u, v in edges)
    return min(1.0, cut / inst["best"])
