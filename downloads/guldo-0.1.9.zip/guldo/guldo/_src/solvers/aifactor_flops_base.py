"""aifactor BASELINE for the operation-golf competition: a KV cache, with the low-rank feed-forward factors multiplied out into dense matrices once at setup (so every token pays for the dense 128x512 products). Beat its operation count: see COMPETITION.md."""
import math

import tensorops as tp

V, D, H, DH, FF, L, PROMPT, R = 64, 128, 4, 32, 512, 2, 8, 8
W_SCALE, POS_SCALE = 4.0, 3.0


def take_param(off, seed, shape, scale):
    n = 1
    for s in shape:
        n *= s
    a = tp.stream(seed, off[0], n, shape) * scale
    off[0] += n
    return a


def build(seed, T):
    off = [0]
    sd = W_SCALE * math.sqrt(3.0 / D)
    P = {"tok": take_param(off, seed, (V, D), math.sqrt(3.0)), "layers": []}
    for i in range(L):
        l = {"Wq": take_param(off, seed, (D, D), sd), "Wk": take_param(off, seed, (D, D), sd), "Wv": take_param(off, seed, (D, D), sd), "Wo": take_param(off, seed, (D, D), sd)}
        l["A1"] = take_param(off, seed, (D, R), sd)
        l["B1"] = take_param(off, seed, (R, FF), math.sqrt(3.0 / R))
        l["A2"] = take_param(off, seed, (FF, R), W_SCALE * math.sqrt(3.0 / FF))
        l["B2"] = take_param(off, seed, (R, D), math.sqrt(3.0 / R))
        P["layers"].append(l)
    P["pos"] = take_param(off, seed, (PROMPT + T, D), POS_SCALE * math.sqrt(3.0))
    u = tp.stream(seed, off[0], PROMPT).tolist()
    P["prompt"] = [min(int((x + 1.0) * 0.5 * V), V - 1) for x in u]
    return P


def rms(x):
    return x / tp.sqrt(tp.mean(x * x, -1, True) + 1e-6)


def softmax_rows(s):
    s = s - tp.max(s, -1, True)
    a = tp.exp(s)
    return a / tp.sum(a, -1, True)


def decode(P, T):
    n = PROMPT + T
    K = [tp.zeros((n, D)) for i in range(L)]
    Vv = [tp.zeros((n, D)) for i in range(L)]
    seq = list(P["prompt"])
    out = []
    for p in range(n - 1):
        x = tp.take(P["tok"], seq[p]) + P["pos"][p]
        li = 0
        for l in P["layers"]:
            h = rms(x)
            q = tp.reshape(h @ l["Wq"], (H, DH))
            K[li][p] = h @ l["Wk"]
            Vv[li][p] = h @ l["Wv"]
            kc = tp.reshape(K[li][0:p + 1], (p + 1, H, DH))
            vc = tp.reshape(Vv[li][0:p + 1], (p + 1, H, DH))
            a = softmax_rows(tp.einsum("hd,thd->ht", q, kc) / math.sqrt(DH))
            x = x + tp.reshape(tp.einsum("ht,thd->hd", a, vc), (D,)) @ l["Wo"]
            x = x + tp.relu(rms(x) @ l["W1"]) @ l["W2"]
            li += 1
        if p >= PROMPT - 1:
            t = tp.argmax(rms(x) @ tp.transpose(P["tok"], (1, 0)))
            out.append(t)
            seq.append(t)
    return out


def solve(seed, prompt_len, T):
    P = build(seed, T)
    for l in P["layers"]:
        l["W1"] = l["A1"] @ l["B1"]
        l["W2"] = l["A2"] @ l["B2"]
    return decode(P, T)
