"""SUPERSEDED (kept for the record): intended as a small-dimension-only win but pruning is slower than the baseline
at n<=60, so it never showed an early advantage. See fixed_overhead_ref.py for the working version of this red-team case."""
import os

from fpylll import BKZ, LLL, IntegerMatrix

_S = "/opt/homebrew/share/fplll/strategies/default.json"
STRATEGIES = _S if os.path.exists(_S) else "/opt/homebrew/Cellar/fplll/5.5.0/share/fplll/strategies/default.json"


def solve(basis, bound2):
    n = len(basis)
    A = IntegerMatrix.from_matrix(basis)
    LLL.reduction(A)
    pruned = n <= 60
    for beta in list(range(10, n + 1, 4)):
        if sum(x * x for x in A[0]) <= bound2:
            break
        kw = {"strategies": STRATEGIES} if pruned else {}
        BKZ.reduction(A, BKZ.Param(block_size=beta, flags=BKZ.AUTO_ABORT | BKZ.MAX_LOOPS, max_loops=8, **kw))
    v = [int(x) for x in A[0]]
    return v if sum(x * x for x in v) <= bound2 else None
