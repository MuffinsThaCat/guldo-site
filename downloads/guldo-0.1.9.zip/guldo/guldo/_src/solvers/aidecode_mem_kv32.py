"""aidecode with bytes counted (tflops_mem.py), TECHNIQUE: the KV cache of aidecode_flops_kv with the weights, embeddings and the cache itself held in fp32. Decoding re-reads every weight
for every token, so halving their width halves most of the bytes; the judge still demands every token right (the accuracy check does not bend for precision)."""
import math

import tensorops as tp

V, D, H, DH, FF, L, PROMPT = 64, 128, 4, 32, 512, 2, 8
W_SCALE, POS_SCALE = 4.0, 3.0


def take_param(off, seed, shape, scale):
    n = 1
    for s in shape:
        n *= s
    a = tp.cast(tp.stream(seed, off[0], n, shape) * scale, "fp32")
    off[0] += n
    return a


def build(seed, T):
    off = [0]
    sd = W_SCALE * math.sqrt(3.0 / D)
    sf = W_SCALE * math.sqrt(3.0 / FF)
    P = {"tok": take_param(off, seed, (V, D), math.sqrt(3.0)), "layers": []}
    for i in range(L):
        P["layers"].append({"Wq": take_param(off, seed, (D, D), sd), "Wk": take_param(off, seed, (D, D), sd), "Wv": take_param(off, seed, (D, D), sd),
                            "Wo": take_param(off, seed, (D, D), sd), "W1": take_param(off, seed, (D, FF), sd), "W2": take_param(off, seed, (FF, D), sf)})
    P["pos"] = take_param(off, seed, (PROMPT + T, D), POS_SCALE * math.sqrt(3.0))
    u = tp.stream(seed, off[0], PROMPT).tolist()
    P["prompt"] = [min(int((x + 1.0) * 0.5 * V), V - 1) for x in u]
    return P


def rms(x):
    return x / tp.sqrt(tp.mean(x * x, -1, True) + 1e-6)


def softmax_rows(s):
    s = s - tp.max(s, -1, True)
    a = tp.exp(s)
    return a / tp.sum(a, -1, True)


def decode(P, T):
    n = PROMPT + T
    K = [tp.cast(tp.zeros((n, D)), "fp32") for i in range(L)]
    Vv = [tp.cast(tp.zeros((n, D)), "fp32") for i in range(L)]
    seq = list(P["prompt"])
    out = []
    for p in range(n - 1):
        x = tp.take(P["tok"], seq[p]) + P["pos"][p]
        li = 0
        for l in P["layers"]:
            h = rms(x)
            q = tp.reshape(h @ l["Wq"], (H, DH))
            K[li][p] = h @ l["Wk"]
            Vv[li][p] = h @ l["Wv"]
            kc = tp.reshape(K[li][0:p + 1], (p + 1, H, DH))
            vc = tp.reshape(Vv[li][0:p + 1], (p + 1, H, DH))
            a = softmax_rows(tp.einsum("hd,thd->ht", q, kc) / math.sqrt(DH))
            x = x + tp.reshape(tp.einsum("ht,thd->hd", a, vc), (D,)) @ l["Wo"]
            x = x + tp.relu(rms(x) @ l["W1"]) @ l["W2"]
            li += 1
        if p >= PROMPT - 1:
            t = tp.argmax(rms(x) @ tp.transpose(P["tok"], (1, 0)))
            out.append(t)
            seq.append(t)
    return out


def solve(seed, prompt_len, T):
    return decode(build(seed, T), T)
