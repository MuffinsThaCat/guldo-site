# Sandbox for judging untrusted submissions

harness.py today isolates only by fresh process, empty cwd, scrubbed env and RLIMIT_CPU. That is fine for your own
solvers, not for strangers'. For a real competition run each (instance, submission) pair like this, from a judge-side
driver that owns the seed (the container never sees it):

    docker build --load -t svp-solver -f sandbox/Dockerfile.v2 .
    docker run --rm -i --network none --read-only --tmpfs /tmp --cpus 1 --memory 4g --pids-limit 64 \
        --cap-drop ALL --cap-add SETUID --cap-add SETGID --cap-add KILL --security-opt no-new-privileges -e BUDGET=120 \
        -v "$PWD/submissions/x.py:/work/submission.py:ro" svp-solver /work/submission.py < payload.json

This is exactly the command `harness.py --sandbox docker` runs (test_docker_shim.py fails if the two ever differ), plus `--name` so the
host can kill the container on a timeout. Things that look optional and are not:
- `-e BUDGET=<cpu seconds>`: the meter reads its cap from the environment and fails without it.
- `--cap-add SETUID --cap-add SETGID`: the meter runs as root and must drop the solver to uid 10001; with every capability dropped
  `setuid()` fails and no solver ever starts. The solver itself ends up with no capabilities (and `no-new-privileges` is set).
- `--cap-add KILL`: the meter (root) must signal solver processes that run as another uid; without CAP_KILL every `kill` fails with EPERM, the
  wall deadline is never enforced, and a sleeping daemon is only stopped by the host's backstop (found by the first CI run of test_sandbox).
- `payload.json` is `{"args": [...]}`: `[basis rows, bound2]` for the lattice families, `[n]` for factoring.
- To pin a core as well, add `--cpuset-cpus N` by hand; the harness does not (see "Still open" in README.md).

Requirements the judge must hold to:
1. Same machine, same pinned core, for baseline and every submission. Report CPU model in the results.
2. Seed file lives outside the container and outside any mounted path.
3. `--pids-limit` and a single `--cpus 1` stop fork/thread tricks from buying CPU time the meter doesn't see.
   (CPU time is summed over children by the host, so threads would still be billed; the limit prevents resource games.)
4. Time CPU via the host's cgroup/`docker stats` accounting, not the submission's own clock.

Status: harness.py has `--sandbox docker` (hardened `docker run`, named container killed and removed on host timeout,
image ID recorded in every results file) and sandbox/Dockerfile.v2 + meter.py are the supported path; the older
sandbox/Dockerfile is superseded and weaker. UNVERIFIED: after the meter was rewritten to reap and bill orphaned
descendants and to kill every solver-uid process at the wall deadline, Docker became unavailable and test_sandbox.py
never passed. Run `python3 -m unittest test_sandbox -v` (needs the image) before trusting any sandboxed result.
The harness-side control flow is tested with a fake `docker` (test_docker_shim.py), which does not test the sandbox.
Docker-free way to verify the meter: copy the project to any Linux machine (a throwaway VM or CI runner) and run
`sudo python3 sandbox/linux_selftest.py` (or `make linux-selftest`). It runs the orphan, daemon, hang and privilege
red-team solvers through meter.py directly (the meter's SOLVER_UID and RUNNER are env-overridable for this) and prints
PASS/FAIL per check. It does not test the container flags (read-only filesystem, no network, pid cap), which still need
Docker. It has not been executed yet: it was written on macOS, where it only skips.
Judge rule: the seed file must live outside the project tree and outside any mount (judge.py new-seed enforces it).
