"""Child process of gpu_meter.py: load a solver file, then answer one request per line. It supplies NO timing: the parent times every request itself.

  argv[1]   the solver file (a top-level `solve`; torch and numpy are available)
  stdin     one JSON request per line: {"op": "run", "args": [...]} or {"op": "quit"}
  stdout    first {"status": "ready", "torch": ..., "device": ...}; then, per request, {"status": "ok", "answer": ...} or {"status": "error", "err": "..."}

The parent measures from the moment it writes a request to the moment it reads the reply, on its own clock. This process therefore cannot under-report: it has nothing to report
except the answer. Each request is bracketed by torch.cuda.synchronize() so asynchronous kernels finish inside the measured interval. Importing the solver (and so any one-time
setup at module level) happens before `ready` and is not measured, like loading a model; per-instance work must happen in solve(). cuDNN autotuning is off and deterministic
algorithms are requested (best effort: a warning where none exists).

UNRUN: this file was written on a machine with no GPU and no torch. The parent-side protocol is tested against a fake transport in test_gpu_meter.py; this child never ran.
The solver runs unsandboxed with the operator's rights: this is an operator-trusted meter (see gpu_meter.py), not a containment.
"""
import importlib.util
import json
import sys

import runner


def _emit(obj):
    sys.__stdout__.write("\n" + json.dumps(obj) + "\n")        # a leading blank line: the parent skips blank lines, so stray output cannot glue itself to a reply
    sys.__stdout__.flush()


def main():
    sys.stdout = sys.stderr                                    # a solver's print() must not reach the reply channel
    try:
        import torch
    except ImportError:
        _emit({"status": "error", "err": "torch is not installed"})
        return
    if not torch.cuda.is_available():
        _emit({"status": "error", "err": "torch reports no CUDA device"})
        return
    try:
        torch.backends.cudnn.benchmark = False
        torch.use_deterministic_algorithms(True, warn_only=True)
        spec = importlib.util.spec_from_file_location("submission", sys.argv[1])
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    except BaseException as e:
        _emit({"status": "error", "err": f"could not load the solver: {type(e).__name__}: {str(e)[:300]}"})
        return
    _emit({"status": "ready", "torch": torch.__version__, "device": torch.cuda.get_device_name(0)})
    for line in sys.stdin:
        try:
            req = json.loads(line)
            if req.get("op") == "quit":
                break
            if req.get("op") != "run":
                raise ValueError(f"unknown op {req.get('op')!r}")
            torch.cuda.synchronize()
            answer = runner.normalize(mod.solve(*req["args"]))
            torch.cuda.synchronize()
            _emit({"status": "ok", "answer": answer})
        except BaseException as e:
            _emit({"status": "error", "err": f"{type(e).__name__}: {str(e)[:300]}"})


if __name__ == "__main__":
    main()
