"""Quality-metric statistics for a challenge (standard library only). The compiler imports this file; an exported bundle carries a byte copy as checker/quality_core.py.

A QUALITY challenge scores the ANSWER, not the clock. Every instance is solved under the same CPU cap; the declaration's quality(inst, ans) says how good a VALID answer is,
from 0 (worst) to 1 (best); an instance the solver does not answer validly counts as 0. The credit of a solver over the reference is the paired difference of qualities:

    per size, the mean over instances of  q_solver - q_reference;  the overall estimate is the mean over sizes (equal weight per size);
    conservative lower bound by a stratified bootstrap (instances resampled with replacement WITHIN each size; the 1st percentile, calibrated on real solves: see ALPHA);
    credit of one seed = max(0, lower bound); credit over several seeds = the MINIMUM (the speed protocol's convention).

Units are quality points (0.05 = five points of the 0..1 scale). A credit above the challenge's min_gain is "certified"; below it is "nothing certified", not "no gain".
What this does NOT know: how the answers were produced or whether quality() measures what you care about. It scores the numbers it is given.
"""
import math
import random

# One-sided: the lower bound is the 1st percentile of the bootstrap distribution. NOT the 5th: on REAL maxcut solves (450 ladders of two equally good solvers, 12 instances per size) the
# 5th-percentile bound earned false credit in 11-13% of single-seed ladders (nominal 5%); normal and t bounds did 10%, bootstrap-t 9%, because real paired differences are noisier and more
# skewed than any of them assume at this sample size. At the 1st percentile the same data gave 3.3%, and a true gain of 0.046 was still credited at >= 0.02 in 180 of 180 ladders. So this is a
# CONSERVATIVE bound whose measured single-seed false-credit rate on that data is about 3%, not a 99% interval; the minimum over seeds then makes a false credit rarer still.
ALPHA = 0.01


def clip01(x):
    return 0.0 if x < 0.0 else 1.0 if x > 1.0 else x


def strata_diffs(base, sub):
    """{size: [q_sub - q_base, ...]} (ids in sorted order) over the ids both ladders hold. `base`, `sub`: {size: {id: quality}}."""
    out = {}
    for d in sorted(base):
        ids = sorted(set(base[d]) & set(sub.get(d, {})))
        if ids:
            out[d] = [sub[d][i] - base[d][i] for i in ids]
    return out


def estimate(strata):
    return sum(sum(v) / len(v) for v in strata.values()) / len(strata)


MIN_BOOT = 60   # measured on real null ladders: the 1st-percentile bound earned false credit in 60% / 17% / 8% of them at 1 / 10 / 30 resamples, 5% at 60 and about 3-5% from 200 up


def lower_bound(strata, rng, boot, alpha=ALPHA):
    """Conservative lower bound of estimate() (see ALPHA): stratified bootstrap, boot resamples (at least MIN_BOOT: a percentile of a handful of resamples is not a bound)."""
    if boot < MIN_BOOT:
        raise ValueError(f"boot must be at least {MIN_BOOT}: the bound is a low percentile of the bootstrap distribution, and with fewer resamples it is not conservative")
    dims = sorted(strata)
    ests = []
    for _ in range(boot):
        tot = 0.0
        for d in dims:
            v = strata[d]
            tot += sum(rng.choices(v, k=len(v))) / len(v)
        ests.append(tot / len(dims))
    ests.sort()
    return ests[min(len(ests) - 1, int(alpha * len(ests)))]


def pair_noise(strata):
    """Pooled within-size sd of the paired differences: what the power table calls the per-instance noise. None if fewer than 8 residuals."""
    res = []
    for v in strata.values():
        if len(v) >= 2:
            m = sum(v) / len(v)
            res += [x - m for x in v]
    dof = len(res) - len(strata)
    if len(res) < 8 or dof < 1:
        return None
    return math.sqrt(sum(x * x for x in res) / dof)


def seed_credit(base, sub, rng, boot):
    """-> dict for one seed's pair of ladders. credit_quality = max(0, lower bound); None estimates when no instance is shared."""
    strata = strata_diffs(base, sub)
    if not strata:
        return {"estimate": None, "lower": None, "credit_quality": None, "instances": 0, "pair_noise": None, "improved": None, "worse": None}
    flat = [x for v in strata.values() for x in v]
    lo = lower_bound(strata, rng, boot)
    return {"estimate": estimate(strata), "lower": lo, "credit_quality": max(0.0, lo), "instances": len(flat), "pair_noise": pair_noise(strata),
            "improved": sum(x > 1e-12 for x in flat), "worse": sum(x < -1e-12 for x in flat)}


def combine(credits):
    """Credit over seeds: the minimum, an unscorable seed counting as 0."""
    return min(0.0 if c is None else c for c in credits)


def headroom(base):
    """Per size: the baseline's mean quality and the fraction of instances already at (>= 0.999) the top. A size with no headroom cannot show a gain."""
    out = {}
    for d in sorted(base):
        qs = list(base[d].values())
        out[d] = {"mean": sum(qs) / len(qs), "at_top": sum(q >= 0.999 for q in qs) / len(qs)}
    return out


# ------------------------------------------------------------------------------------------------------------------------------ power
def synth_ladders(profile, n, effect, noise, rng):
    """A synthetic (baseline, solver) pair of ladders. profile = {"sizes": [..], "mean": {size: mu}, "sd": {size: s}} describes the reference's quality;
    the solver is `effect` better per instance plus N(0, noise), clipped to [0, 1] like real qualities (so a gain near the top is truncated: headroom is modelled)."""
    base, sub = {}, {}
    for s in profile["sizes"]:
        mu, sd = profile["mean"][str(s)], profile["sd"][str(s)]
        base[s], sub[s] = {}, {}
        for i in range(n):
            b = clip01(rng.gauss(mu, sd))
            base[s][i] = b
            sub[s][i] = clip01(b + effect + rng.gauss(0, noise))
    return base, sub


def power_at(profile, n, effect, noise, gap, seeds, trials, boot, rng):
    """P(one seed credited >= gap) and P(all `seeds` seeds credited >= gap) for a true per-instance gain of `effect`."""
    credits = []
    for _ in range(seeds * trials):
        b, s = synth_ladders(profile, n, effect, noise, rng)
        credits.append(seed_credit(b, s, rng, boot)["credit_quality"])
    trip = [combine(credits[i:i + seeds]) for i in range(0, len(credits) - seeds + 1, seeds)]
    return {"single": sum(c >= gap for c in credits) / len(credits), "all_seeds": sum(c >= gap for c in trip) / len(trip)}


def power_table(profile, n, noise, gap, seeds, trials, boot, effects, seed=0):
    rng = random.Random(seed)
    return {e: power_at(profile, n, e, noise, gap, seeds, trials, boot, rng) for e in effects}


def certifiable_range(table, target):
    ok = [e for e, v in table.items() if v["all_seeds"] >= target]
    return (min(ok), max(ok)) if ok else (None, None)


def effects_for(gap):
    """The grid of true gains a power table covers, as multiples of the certification threshold."""
    return tuple(round(gap * m, 4) for m in (0, 0.5, 1, 1.5, 2, 3, 5, 10))
