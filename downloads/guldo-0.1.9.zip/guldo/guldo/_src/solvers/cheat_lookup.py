"""Red-team: ships precomputed answers for the PUBLIC practice instances, falls back to the baseline otherwise.
Looks astronomically fast on the practice seed; has zero edge on a commit-revealed seed."""
import hashlib
import json
import os

from fpylll import BKZ, LLL, IntegerMatrix

_TABLE = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "cheat_table.json")))


def solve(basis, bound2):
    key = hashlib.sha256(json.dumps(basis).encode()).hexdigest()
    if key in _TABLE:
        return _TABLE[key]
    n = len(basis)
    A = IntegerMatrix.from_matrix(basis)
    LLL.reduction(A)
    for beta in list(range(10, n + 1, 4)):
        if sum(x * x for x in A[0]) <= bound2:
            break
        BKZ.reduction(A, BKZ.Param(block_size=beta, flags=BKZ.AUTO_ABORT | BKZ.MAX_LOOPS, max_loops=8))
    v = [int(x) for x in A[0]]
    return v if sum(x * x for x in v) <= bound2 else None
