# Launch checklist: everything together

Honest state before you start: the whole Docker-free test suite (746 tests) passes on the author's Mac under Python 3.14, and that includes the real step
counter, the restricted-subset sandbox, counted rounds (with a stand-in counter), derived claims, the package and the site. What has **not** happened: a real counted round
with real submissions, anything on Linux, and the Docker sandbox on a real host (never run anywhere). This checklist is the order
that finds out, privately, before anything is public. `DEPLOY.md` has the long-form detail for each server step; this is the spine.

## What launching means here

| piece | needs | label it can honestly carry |
|---|---|---|
| the static site | any web host | "no result is official" (already on every page) |
| counted rounds (`ops.py round-new --count ...`) | a Linux host, Python 3.12, an unprivileged throwaway user; **no Docker** | COUNTED, never OFFICIAL |
| official timed rounds | the verified Docker sandbox on a Linux host, 3 independent seeds | OFFICIAL, only after Gate 2 passes |

If Gate 2 fails, launch with counted rounds only and say so on the Compete page.

## You do (I cannot)

1. A Linux VM: Ubuntu 24.04 LTS, x86-64, 2-4 vCPU, 4-8 GB RAM (Hetzner, DigitalOcean, Linode, EC2). Use a dedicated-CPU plan if you want clean timings. Add your SSH key.
2. Install on it: `apt install -y docker.io python3-pip rsync` and `pip install numpy cryptography` (Ubuntu 24.04 already has Python 3.12).
3. A domain and a DNS A record to the web VM (Caddy then gets TLS by itself, `deploy/Caddyfile`).
4. Decide: who is `ledger-ops`; whether rounds `--require-source` (counted rounds force it); where you will publish each round's log head hash
   (somewhere you cannot edit: a signed post, a git tag in another repo).
5. Treat the evaluating VM as disposable: the self-test runs hostile test programs. Put no keys on it.

## Gates (run in order; stop at the first failure)

From your Mac: `./launch_push.sh user@host` copies the project. On the box, in the project directory:

```
python3 launch_gates.py                      # Gate 0-1: environment; counter + counted rounds + claims (FIRST REAL RUN); whole suite; Linux meter self-test
python3 launch_gates.py --with-docker --data /srv/ledger/data     # Gate 2: sandbox image, test_sandbox, verify-sandbox (writes the marker the worker needs)
python3 launch_gates.py --with-rehearsal     # Gate 3: a real counted practice run, full re-execution, the three claims (slow: hours)
```

| gate | passes when | unlocks | if it fails |
|---|---|---|---|
| 0 env + counted + suite | `launch_gates.py` shows PASS for env, counted, suite | everything else; counted rounds are *possible* | fix the failure it prints, one at a time. Expect real findings in `count_runner.py` (does removing `sys.monitoring` break an import? does the proxy import work?), the estimator on counted ladders, and the log checks. Do not launch anything. |
| 1 selftest | `sandbox/linux_selftest.py` passes as root | the meter is trustworthy on Linux | read the failure: it names orphan/daemon/hang/privilege cases |
| 2 docker | `test_sandbox` passes and `portal.py verify-sandbox` writes the marker | official timed rounds | counted-only launch |
| 3 rehearsal | practice, `verify --rerun all --execute` and `claims.py check` all succeed | publish its certificate as the site's real example | the failure says which step; the work directory is kept |

The rehearsal is also where the defaults get measured: `--dims 38 40 42 --cap 40` are estimates from reading the loops. If the baseline costs under
about 0.5 counted seconds at the smallest size, or over the cap at the largest, change `--dims` and `--cap` and run again before creating a round.

## Server setup (after Gate 0-1; full detail in DEPLOY.md section 3)

1. Users, directories, code under `/opt/speedup-verification`, edit the three `deploy/` files for your domain (steps 2-4).
2. Web tier: systemd unit + Caddy (step 5). `curl -s https://<host>/healthz`.
3. Create the rounds as `ledger-ops`. Counted: `python3 ops.py round-new --data D --seed-dir S --id counted-1 --title "..." --family factor --closes ... --count --count-dims 38 40 42 --count-n 8 --count-cap 40`.
   Timed (only if Gate 2 passed): as in DEPLOY.md step 7. Announce the commitments.
4. Before announcing anything: `python3 ops.py preflight --data D --seed-dir S` (as ledger-ops) and `python3 deploy_smoke.py https://<host>` (from elsewhere).

## Private rehearsal round (before public)

1. Open a small counted round and invite two or three friendly submitters (one honest, one deliberately outside the subset, one that is slow).
2. `ops.py close`, then `ops.py worker --data D --id R --seed-dir S/R --unsandboxed` **as an unprivileged user** (it refuses root), `ops.py reveal`, `ops.py certs`.
3. From a different machine: `svp.py verify --round R --id X --rerun all --execute` for each certificate (a throwaway VM; it runs their code), then
   `claims.py correctness|worst-case CERT` and `claims.py negative CERT... --threshold 2`.
4. Check that the refused submission was refused *before* upload (`svp.py submit` says what is outside the subset) and that the slow one fails to verify, not the others.

## Launch day

1. Rebuild the site with the real certificates: `python3 build_site.py --out /srv/ledger/site.new --ledger-data /srv/ledger/data --portal-url https://<host> --certs certs --reveal ... --note ...`
   (the earlier build's `--reveal` and `--note` values are in the memory note; seed A's file does not match its commitment, so do not reveal it). Look at it in a browser first.
2. Update the places that say "Tested, not yet used" (the home page status row, the Other claims banner, the Install page's status banner) to what is now true after the rehearsal. Do not remove them before Gate 0-3 pass.
3. Open the public round. Publish the commitments and, after each close, the log head hash.
   Give submitters the command-line package: `make package` stages `dist/guldo/` (zip it as a download, or publish it to a package index), and they
   `pipx install` it and use `svp`. Build it from the same checkout the round committed to: the files a round hashes are copied byte for byte, so a mismatch
   would show up as a failed "rules" check. It has been installed and used on one real certificate, never on a clean machine.
4. Keep the kill switch in reach: `ops.py kill-switch --data D on` pauses submissions.

## Closing the open limits

`RESOLVE.md` is the runbook: each closable limit, the exact steps, the evidence that shows it closed, and the website text to change. `python3 limits_plan.py --data D`
prints where each stands (read-only). The Gate 2 and rehearsal runs above feed three of them directly (the sandbox, the first official round, one job at a time), and two
pre-registered experiments (`prereg_templates/`) should be written while the box is being set up, because they only count if registered before their data.
Three limits stay on the website for good; the Limits page says which.

## After launch

- After each round closes: publish the head hash; after the reveal, `ops.py certs`, then `ops.py export` and rebuild the site.
- Negative results need a certificate for every logged submission: if one failed evaluation, say so rather than hiding it (`claims.py negative` reports it as missing).
- Anything that fails a gate later (a Python upgrade on the box changes counts): counted certificates are only comparable on the same Python version; start a new round.
