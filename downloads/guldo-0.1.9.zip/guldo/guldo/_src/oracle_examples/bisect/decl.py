"""Worked INTERACTIVE example: a hidden number behind a comparison oracle (see oracle_core.py). The solver gets `bits` and an oracle; oracle(q) answers 1 if secret >= q else 0.
Reference: linear scan upward (about secret queries). A binary search needs `bits` queries. The score is the query count."""
import hashlib
import hmac

NAME = "bisect"
VERSION = "bisect-v1"
KIND = "oracle"
SIZE_RANGE = (6, 12)
SIZE_STEP = 3
REFERENCE_SOLVER = "reference.py"
QUERY_BUDGET = 5000
QUERY_UNIT = 100
DOC = "solve(oracle, bits): return the secret integer in [0, 2**bits). oracle(q) returns 1 if secret >= q else 0."
REFERENCE_NOTE = "Linear scan: ask q = 1, 2, 3, ... until the answer is 0. Binary search needs only `bits` queries."


def derive(master, size, idx):
    d = hmac.new(master, f"bisect-v1:{size}:{idx}".encode(), hashlib.sha256).digest()
    return {"args": [size], "planted": int.from_bytes(d[:8], "big") % (1 << size)}


def verify(inst, ans):
    return isinstance(ans, int) and not isinstance(ans, bool) and ans == inst["planted"]


def oracle_open(inst):
    return {"secret": inst["planted"]}


def oracle(state, query):
    if isinstance(query, bool) or not isinstance(query, int):
        raise ValueError("query must be an integer")
    return 1 if state["secret"] >= query else 0
