"""aiinfer on a GPU, REFERENCE: float32 on the device, one sample at a time (a matrix-vector product per input, one synchronising read-back per sample).
UNRUN: written without a GPU or torch. The model definition is exactly domains/aiinfer/reference.py's (regenerated on the host, then moved to the device)."""
import math

import numpy as np
import torch

_GOLD = 0x9E3779B97F4A7C15
_C1 = 0xBF58476D1CE4E5B9
_C2 = 0x94D049BB133111EB
_CLASSES = 10


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _model(seed, d, batch):
    s = math.sqrt(3.0 / d)
    o = 0
    W1 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W2 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W3 = (_uniform(seed, o, _CLASSES * d) * s).reshape(_CLASSES, d)
    o += _CLASSES * d
    X = _uniform(seed, o, batch * d).reshape(batch, d)
    return W1, W2, W3, X


def solve(seed, d, batch):
    dev = torch.device("cuda")
    W1, W2, W3, X = (torch.from_numpy(a).to(dev, dtype=torch.float32) for a in _model(seed, d, batch))
    out = []
    for i in range(batch):
        h = torch.relu(W1 @ X[i])
        h = torch.relu(W2 @ h)
        out.append(int(torch.argmax(W3 @ h)))
    return out
