"""A recording proxy for real model APIs: the deployable form of agent_attest's receipts. It sits between the agent under test and the provider, forwards every request unchanged, and signs a receipt
for each exchange. Run it on a machine the VERIFIER controls, under the verifier's key; point the agent at it (the official SDK honours ANTHROPIC_BASE_URL).

  python3 agent_proxy.py serve --key KEYFILE --log PROXY.jsonl [--upstream https://api.anthropic.com] [--port 8787]
      ALSO OpenAI-compatible endpoints (`compat:MODEL` agents): give the upstream's ROOT, because the agent's /v1/... path is appended to it, e.g. `--upstream http://127.0.0.1:11434` for Ollama or
      `--upstream https://api.openai.com`, and point the agent's GULDO_COMPAT_BASE_URL at http://127.0.0.1:8787/v1. The two formats are recognised per exchange (a Chat Completions reply has `choices`).
  python3 agent_proxy.py verify LADDER PROXY.jsonl --trusted KEYS (--seed F | --practice)      does every model call in the ladder have a matching receipt?

What a receipt holds: a signed chain entry with the SHA-256 of the exact request and response bodies, the status, the proxy's own clock, the model id and the usage numbers the provider reported. The log
file also keeps the bodies (base64) so a verifier can read them. The API key travels in a header the proxy forwards but NEVER records; bodies can contain the task text, so treat the log as sensitive.

HOW A LADDER IS CHECKED AGAINST THE LOG. A stored trajectory cannot be turned back into the exact request: the SDK echoes the model's own opaque, signed thinking blocks on later turns, and those are
not in the trajectory. So matching is by CONTENT, not by hash of a rebuilt request. For every assistant turn in every trial there must be one unused status-200 exchange whose response has the same
text and the same tool calls (a refusal or truncation note the adapter appended is allowed), whose request has the right number of messages, whose first message is the task prompt, and whose last message
is exactly the previous turn's tool results (or the prompt, on turn 0). Bodies must hash to the signed values; the chain and signatures must hold and use a pinned key; every status-200 exchange in
the log must belong to some recorded turn (a hidden or discarded run shows up as a stray exchange). Failed exchanges (429, 5xx) cost nothing and are ignored. The provider usage a ladder RECORDS for a turn must equal the usage the proxy SIGNED for its exchange (a halved, zeroed or deleted copy is rejected: found by trying it on the real live run, where it used to pass); the recorded numbers are the operator's copy and only the signed ones are evidence.

WHAT THIS PROVES AND DOES NOT. If the operator cannot reach the proxy's key or log, a hand-written trajectory has no exchange to match, and token counts come from the provider's own usage numbers as
signed by the proxy. It does not prove WHICH model the provider ran (it records the id the response reports, and verify compares it with the ladder's), it cannot see calls that bypass it, it
relies on the provider's usage report, and an operator who controls the proxy machine controls everything above. Tested against a local fake upstream, and ONCE against the live Anthropic API (4 real claude-haiku-4-5 trials through it, 24 signed exchanges, a genuine ladder attested and a hand-edited one rejected: AGENT_EVAL.md, "The first runs against the live Anthropic API"). Streaming
requests are refused (the adapter does not stream).
"""
import argparse
import base64
import hashlib
import http.server
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request

import agent_attest
import agent_core
import agent_domains_plus                                                            # noqa: F401  this module loads a ladder's domain by name: the extra domains must be registered
import agent_harness
import agent_providers
import agent_sig
from agent_core import canon, sha256_hex

_OPENER = urllib.request.build_opener(agent_providers._NoRedirect)
HTTP_FORMAT = "guldo-agent-http-receipt-v1"
HTTP_COUNTER = "attested-http-provider-usage-v1"
MAX_BODY = 32 * 1024 * 1024


class Recorder:
    def __init__(self, secret, log_path, session="s0"):
        self.secret, self.log_path, self.session = secret, log_path, session
        self.seq, self.prev = 0, agent_core.CHAIN_START
        self.lock = threading.Lock()
        try:                                     # continue an existing log: the chain must not restart
            rows = read_log(log_path)
            if rows:
                self.seq, self.prev = len(rows), sha256_hex(canon(rows[-1]["receipt"]))
        except OSError:
            pass

    def record(self, path, req, status, resp):
        usage, model = None, None
        try:
            doc = json.loads(resp.decode("utf-8"))
            u = doc.get("usage") or {}
            if isinstance(u.get("input_tokens"), int) and isinstance(u.get("output_tokens"), int):
                usage = {"input_tokens": u["input_tokens"] + int(u.get("cache_creation_input_tokens") or 0) + int(u.get("cache_read_input_tokens") or 0), "output_tokens": u["output_tokens"]}
            elif all(isinstance(u.get(k), int) and not isinstance(u.get(k), bool) and 0 <= u[k] <= 10 ** 9 for k in ("prompt_tokens", "completion_tokens")):
                usage = {"input_tokens": u["prompt_tokens"], "output_tokens": u["completion_tokens"]}          # OpenAI Chat Completions (the same sanity bounds the adapter applies)
            model = doc.get("model") if isinstance(doc.get("model"), str) else None
        except (ValueError, UnicodeDecodeError, AttributeError):
            pass
        with self.lock:
            body = {"format": HTTP_FORMAT, "session": self.session, "seq": self.seq, "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "path": path, "status": status,
                    "req": sha256_hex(req), "resp": sha256_hex(resp), "usage": usage, "model": model, "prev": self.prev}
            signed = agent_sig.sign_statement(body, self.secret)
            self.prev = sha256_hex(canon(signed))
            self.seq += 1
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(canon({"receipt": signed, "req_b64": base64.b64encode(req).decode("ascii"), "resp_b64": base64.b64encode(resp).decode("ascii")}) + "\n")
        return signed


def read_log(path):
    with open(path, "r", encoding="utf-8") as f:
        try:
            rows = [json.loads(ln) for ln in f.read().split("\n") if ln.strip()]
        except ValueError:
            raise agent_core.AgentEvalError("%s is not a JSON-lines proxy log" % path)
    if not all(isinstance(r, dict) for r in rows):
        raise agent_core.AgentEvalError("%s holds a line that is not an object" % path)
    return rows


def make_server(upstream, recorder, host="127.0.0.1", port=0, timeout=300):
    upstream = upstream.rstrip("/")

    class Handler(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):              # no access log: headers carry credentials and bodies carry tasks
            pass

        def _send(self, status, body, ctype="application/json"):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            # The path is appended to the upstream URL, so a crafted one ("@other-host/x") could aim the request, and the forwarded API key, at another host. Only the API's own paths pass.
            if not self.path.startswith("/v1/") or any(bad in self.path for bad in ("@", "..", "\\", "\r", "\n", " ", "//")):
                return self._send(403, b'{"error":"path not allowed"}')
            try:
                n = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                return self._send(400, b'{"error":"bad content-length"}')
            if n < 0 or n > MAX_BODY:
                return self._send(413, b'{"error":"body too large"}')
            req = self.rfile.read(n)
            try:
                if json.loads(req.decode("utf-8")).get("stream"):
                    return self._send(400, b'{"error":"the recording proxy does not support streaming"}')
            except (ValueError, UnicodeDecodeError, AttributeError):
                pass
            headers = {k: v for k, v in self.headers.items() if k.lower() in ("x-api-key", "authorization", "anthropic-version", "anthropic-beta", "content-type", "user-agent")}
            headers["Accept-Encoding"] = "identity"
            try:
                # NEVER follow a redirect: urllib re-sends a 301/302/303 as a GET WITH the credential headers, so the key would go to whatever origin the upstream names AND the signed receipt would
                # attest that origin's answer as the provider's (found by test). A 3xx is passed through unfollowed (and, not being a 200, never matches a turn).
                with _OPENER.open(urllib.request.Request(upstream + self.path, data=req, method="POST", headers=headers), timeout=timeout) as r:
                    status, body, ctype = r.status, r.read(), r.headers.get("Content-Type", "application/json")
            except urllib.error.HTTPError as e:
                status, body, ctype = e.code, e.read(), e.headers.get("Content-Type", "application/json")
                e.close()                              # an unclosed error response leaks a socket per failed upstream call in a long-running proxy
            except (urllib.error.URLError, OSError):
                return self._send(502, b'{"error":"upstream unreachable"}')
            recorder.record(self.path, req, status, body)
            self._send(status, body, ctype)

    srv = http.server.ThreadingHTTPServer((host, port), Handler)
    srv.daemon_threads = True
    return srv


# ---- verification ------------------------------------------------------------------------------------------------------------------------------------

def _is_chat(resp_bytes):
    """True for an OpenAI Chat Completions response (it has `choices`), False for an Anthropic messages response."""
    try:
        return isinstance(json.loads(resp_bytes.decode("utf-8")).get("choices"), list)
    except (ValueError, AttributeError, UnicodeDecodeError):
        return False


def _provider_view(resp_bytes):
    """(text, [{'name','args'}], stop_reason, model) of a messages or chat-completions response, or None if it is neither. A chat reply is normalised by the SAME function the adapter used
    (agent_providers.parse_chat_completion), so what the adapter stored and what is re-derived here from the signed bytes agree by construction."""
    try:
        d = json.loads(resp_bytes.decode("utf-8"))
        if isinstance(d.get("choices"), list):
            reply, served = agent_providers.parse_chat_completion(d)
            return reply["text"], reply["tool_calls"], d["choices"][0].get("finish_reason"), d.get("model") if isinstance(d.get("model"), str) else served
        blocks = d["content"]
        text = "".join(b["text"] for b in blocks if b.get("type") == "text")
        calls = [{"name": b["name"], "args": dict(b["input"])} for b in blocks if b.get("type") == "tool_use"]
        return text, calls, d.get("stop_reason"), d.get("model")
    except (ValueError, KeyError, TypeError, AttributeError, UnicodeDecodeError, agent_core.AgentEvalError):
        return None


def _chat_context_matches(msgs, turns, ti, system):
    """Does a Chat Completions request's message list match the ladder's turns before assistant turn `ti`? The system prompt is message 0, the task prompt message 1, then one message per assistant
    turn, one message PER TOOL RESULT (not one per tool turn: this is the difference from the Anthropic format), and one per nudge. The tail must be exactly the last turn's content."""
    expected = 1
    for t in turns[:ti]:
        expected += len(t.get("results", [])) if t.get("role") == "tool" else 1
    if len(msgs) != expected or not all(isinstance(m, dict) for m in msgs):
        return False
    if msgs[0].get("role") != "system" or msgs[0].get("content") != system or msgs[1].get("content") != turns[0].get("content"):
        return False
    if ti > 1:
        prev = turns[ti - 1]
        if prev.get("role") == "tool":
            tail = msgs[len(msgs) - len(prev["results"]):]
            return [m.get("role") for m in tail] == ["tool"] * len(tail) and [m.get("content") for m in tail] == [r["content"] for r in prev["results"]]
        if prev.get("role") == "user":
            return msgs[-1].get("role") == "user" and msgs[-1].get("content") == prev.get("content")
        return False
    return True


def _tool_result_texts(content):
    out = []
    for b in content if isinstance(content, list) else []:
        c = b.get("content") if isinstance(b, dict) else None
        out.append(c if isinstance(c, str) else json.dumps(c, sort_keys=True))
    return out


def verify_http(header, records, log, trusted_keys, master):
    """(problems, assignment). assignment maps (instance, trial, turn index) -> the matched log row. Never raises on damaged input."""
    try:
        agent_core.require_shape(header, records)
        if not trusted_keys:
            return ["no trusted keys given: signatures prove only that SOME key signed; pin the verifier's key"], {}
        if not isinstance(log, list) or not all(isinstance(r, dict) and isinstance(r.get("receipt"), dict) for r in log):
            return ["the proxy log is malformed"], {}
        return _verify_http(header, records, log, set(trusted_keys), master)
    except agent_core.AgentEvalError as e:
        return [str(e)], {}
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, OverflowError) as e:
        return ["malformed input (%s: %s)" % (type(e).__name__, str(e)[:100])], {}


def _verify_http(header, records, log, trusted, master=None):
    probs, assignments = _verify_http_arms([(header, records)], log, trusted, master)
    return probs, assignments[0]


def verify_http_arms(arms, log, trusted_keys, master=None):
    """Several ladders against ONE proxy log (the baseline and every entry of a round all went through the same proxy). `arms` is [(header, records), ...]. Exchanges are consumed once across
    all arms, so an exchange cannot vouch for two trials, and any exchange that belongs to NO arm's turn is a stray (a discarded or hidden run). Returns (problems, [assignment per arm]).
    Never raises on damaged input."""
    try:
        for header, records in arms:
            agent_core.require_shape(header, records)
        if not trusted_keys:
            return ["no trusted keys given: signatures prove only that SOME key signed; pin the verifier's key"], [{} for _ in arms]
        if not isinstance(log, list) or not all(isinstance(r, dict) and isinstance(r.get("receipt"), dict) for r in log):
            return ["the proxy log is malformed"], [{} for _ in arms]
        return _verify_http_arms(arms, log, set(trusted_keys), master)
    except agent_core.AgentEvalError as e:
        return [str(e)], [{} for _ in arms]
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, OverflowError) as e:
        return ["malformed input (%s: %s)" % (type(e).__name__, str(e)[:100])], [{} for _ in arms]


def _verify_http_arms(arms, log, trusted, master=None):
    probs = agent_attest._chain_problems([r["receipt"] for r in log], trusted, HTTP_FORMAT)
    rows = []
    for i, r in enumerate(log):
        st = r["receipt"].get("statement", {})
        try:
            req, resp = base64.b64decode(r["req_b64"], validate=True), base64.b64decode(r["resp_b64"], validate=True)
        except (ValueError, TypeError, KeyError):
            probs.append("log row %d: bodies missing or not base64" % i)
            continue
        if sha256_hex(req) != st.get("req") or sha256_hex(resp) != st.get("resp"):
            probs.append("log row %d: a body does not hash to the signed value" % i)
            continue
        if st.get("status") == 200:
            view = _provider_view(resp)
            try:
                reqdoc = json.loads(req.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                reqdoc = None
            if view is not None and isinstance(reqdoc, dict) and isinstance(reqdoc.get("messages"), list):
                rows.append({"i": i, "st": st, "view": view, "req": reqdoc, "used": False, "chat": _is_chat(resp)})
    assignments = []
    for header, records in arms:
        arm_probs, assignment = _match_arm(header, records, rows, master)
        probs += arm_probs
        assignments.append(assignment)
    stray = [r["i"] for r in rows if not r["used"]]
    if stray:
        probs.append("%d successful exchange(s) in the proxy log belong to no recorded turn (a discarded or hidden run?)" % len(stray))
    return probs, assignments


def _offered_tool_names(req):
    """The tool names a request offered the model: Anthropic `tools[].name` or Chat Completions `tools[].function.name`."""
    out = []
    for t in req.get("tools") or []:
        if isinstance(t, dict):
            n = t.get("name") if isinstance(t.get("name"), str) else (t.get("function") or {}).get("name") if isinstance(t.get("function"), dict) else None
            out.append(n)
    return sorted(str(x) for x in out)


def _match_arm(header, records, rows, master):
    """Match every assistant turn of every record of ONE arm to an unused exchange in `rows` (shared across arms: an exchange is consumed once). Beyond the content of the reply and the
    shape of the context, the request must carry the SYSTEM PROMPT and the TOOLS the ladder claims (a hand-edited header could otherwise misstate what the model was given)."""
    probs = []
    want_model = header.get("agent", {}).get("model")
    want_system = header.get("system", agent_harness.SYSTEM)
    assignment = {}
    tool_names = {}
    for rec in records:
        turns = rec.get("turns", [])
        k = 0
        names = None
        if master is not None:
            try:
                mod = agent_core.load_domain(rec["domain"])
                inst = agent_core.make_instance(mod, master, int(rec["size"]), int(rec["idx"]))
                names = sorted(s["name"] for s in agent_harness.effective_tools(mod, inst, header.get("allow_tools")))
            except (agent_core.AgentEvalError, KeyError, TypeError, ValueError):
                names = None
        for ti, t in enumerate(turns):
            if t.get("role") != "assistant":
                continue
            prev = turns[ti - 1]
            exp_text, exp_calls = t.get("text", ""), [{"name": c["name"], "args": c.get("args", {})} for c in t.get("tool_calls", [])]
            found = None
            for row in rows:
                if row["used"]:
                    continue
                text, calls, stop, _model = row["view"]
                if calls != exp_calls:
                    continue
                if not (text == exp_text or (stop in ("refusal", "max_tokens") and exp_text.startswith(text))):
                    continue
                if names is not None and _offered_tool_names(row["req"]) != names:
                    continue
                msgs = row["req"]["messages"]
                if row["chat"]:
                    if not _chat_context_matches(msgs, turns, ti, want_system):
                        continue
                    found = row
                    break
                if "system" in row["req"] and row["req"].get("system") != want_system:
                    continue
                # Anthropic format: one API message per preceding turn: the prompt, each assistant turn, each tool-results turn and (max_nudges > 0) each nudge. (It used to assume 2k+1, which a nudge breaks.)
                if len(msgs) != ti or not isinstance(msgs[0], dict) or msgs[0].get("content") != turns[0].get("content"):
                    continue
                last = msgs[-1]
                if ti > 1:
                    if prev.get("role") == "tool":
                        if _tool_result_texts(last.get("content")) != [x["content"] for x in prev["results"]]:
                            continue
                    elif prev.get("role") == "user":                       # a nudge: the request must end with exactly the text the ladder says was sent
                        if last.get("content") != prev.get("content"):
                            continue
                    else:
                        continue
                found = row
                break
            key = (rec["instance"], rec["trial"], k)
            if found is None:
                probs.append("%s trial %s turn %d: no unused exchange in the proxy log matches this turn" % (rec["instance"], rec["trial"], k))
            else:
                found["used"] = True
                assignment[key] = found
                if want_model and found["req"].get("model") != want_model:
                    probs.append("%s trial %s turn %d: the request asked for model %r, the ladder says %r" % (rec["instance"], rec["trial"], k, found["req"].get("model"), want_model))
                if found["st"].get("model") and want_model and not str(found["st"]["model"]).startswith(want_model.split("@")[0]):
                    probs.append("%s trial %s turn %d: the provider reports it served model %r" % (rec["instance"], rec["trial"], k, found["st"]["model"]))
                if t.get("usage") != found["st"].get("usage"):       # the usage a ladder records is the operator's copy: only the signed one is evidence. A halved, zeroed or deleted copy used to pass.
                    probs.append("%s trial %s turn %d: the usage recorded in the ladder (%s) differs from the signed provider usage (%s)" % (rec["instance"], rec["trial"], k, t.get("usage"), found["st"].get("usage")))
            k += 1
    return probs, assignment


def verify_round_http(base, rid, log, trusted_keys):
    """Attest a whole REVEALED agent round (agent_rounds.py) against one proxy log: the baseline and every entry went through the same proxy, so every model call of every arm must match a
    signed exchange, exchanges are consumed once across arms, and any exchange left over is a stray. The revealed seed is needed (the tools a request offered depend on the instance).
    Returns (problems, info)."""
    import agent_rounds as AR
    import rounds as R
    try:
        d = AR._require(base, rid)
    except AR.Rejected as e:
        return [str(e)], {}
    master = AR._revealed_master(d)
    if master is None:
        return ["the round has not been revealed: the offered tools of each request depend on the seed, so it cannot be attested yet"], {}
    arms, names = [], []
    for eid in ["baseline"] + [e["eid"] for e in AR._entries(d)]:
        path = os.path.join(d, "ladders", eid + ".jsonl")
        if not os.path.exists(path):
            return ["%s: no ladder" % eid], {}
        arms.append(agent_core.read_ladder(path))
        names.append(eid)
    probs, _ = verify_http_arms(arms, log, trusted_keys, master)
    info = {"round": rid, "arms": names, "exchanges": len(log), "proxy_log_sha256": None, "trusted_keys": sorted(trusted_keys)}
    return probs, info


def http_counts(records, assignment):
    """{(instance, trial): (input_tokens, output_tokens) or None}, from the signed usage of the matched exchanges."""
    out = {}
    for rec in records:
        n = sum(1 for t in rec.get("turns", []) if t.get("role") == "assistant")
        us = [assignment.get((rec["instance"], rec["trial"], k)) for k in range(n)]
        if not n or any(u is None or u["st"].get("usage") is None for u in us):
            out[(rec["instance"], rec["trial"])] = None
        else:
            out[(rec["instance"], rec["trial"])] = (sum(u["st"]["usage"]["input_tokens"] for u in us), sum(u["st"]["usage"]["output_tokens"] for u in us))
    return out


def convert_http(header, records, log, trusted_keys, master):
    probs, assignment = verify_http(header, records, log, trusted_keys, master)
    if probs:
        raise agent_core.AgentEvalError("the proxy log does not attest this ladder (%d problems, first: %s): refusing to convert" % (len(probs), probs[0]))
    counts = http_counts(records, assignment)
    if any(v is None for v in counts.values()):
        raise agent_core.AgentEvalError("some trial has no signed provider usage")
    out = []
    for rec in records:
        i, o = counts[(rec["instance"], rec["trial"])]
        out.append(dict(rec, tokens=i + o, proxy_tokens=rec["tokens"]))
    return dict(header, counter=HTTP_COUNTER), out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("serve")
    s.add_argument("--key", required=True)
    s.add_argument("--log", required=True)
    s.add_argument("--upstream", default="https://api.anthropic.com")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8787)
    v = sub.add_parser("verify")
    v.add_argument("ladder")
    v.add_argument("log")
    v.add_argument("--trusted", required=True)
    v.add_argument("--seed")
    v.add_argument("--practice", action="store_true")
    vr = sub.add_parser("verify-round", help="attest a whole revealed agent round (every arm) against one proxy log")
    vr.add_argument("round_id")
    vr.add_argument("log")
    vr.add_argument("--trusted", required=True)
    vr.add_argument("--base", default=".", help="directory holding agent-rounds/")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "verify-round":
            probs, info = verify_round_http(a.base, a.round_id, read_log(a.log), agent_sig.read_trusted(a.trusted))
            for p in probs[:20]:
                print("FAIL: " + p)
            print("ROUND ATTESTED: every model call of every arm (%s) matches a signed exchange from a pinned key, and none is left over" % ", ".join(info.get("arms", [])) if not probs
                  else "ROUND NOT ATTESTED (%d problems)" % len(probs))
            return 0 if not probs else 1
        if a.cmd == "serve":
            rec = Recorder(agent_sig.load_secret(a.key), a.log)
            srv = make_server(a.upstream, rec, a.host, a.port)
            print("recording proxy on http://%s:%d -> %s (log %s); point the agent here, e.g. ANTHROPIC_BASE_URL=http://%s:%d; Ctrl-C stops" % (a.host, srv.server_address[1], a.upstream, a.log, a.host, srv.server_address[1]))
            try:
                srv.serve_forever()
            except KeyboardInterrupt:
                pass
            return 0
        h, r = agent_core.read_ladder(a.ladder)
        probs, _ = verify_http(h, r, read_log(a.log), agent_sig.read_trusted(a.trusted), agent_core.read_master(a.seed, a.practice))
        for p in probs[:20]:
            print("FAIL: " + p)
        print("ATTESTED: every model call in the ladder matches a signed exchange from a pinned key" if not probs else "NOT ATTESTED (%d problems)" % len(probs))
        return 0 if not probs else 1
    except (agent_core.AgentEvalError, OSError, ValueError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
