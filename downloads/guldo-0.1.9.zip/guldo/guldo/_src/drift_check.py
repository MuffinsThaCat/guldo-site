"""Does running instances concurrently change their measured CPU time? Run before trusting `harness.py --jobs K`.

  python3 drift_check.py [--solver solvers/baseline_bkz.py] [--dims 62 64] [--n 6] [--jobs 4 6 8]

Runs the SAME instances once sequentially (the reference) and once per job count, then reports the paired
log2(concurrent cpu / sequential cpu): the median is the systematic bias in bits, the sd is the extra noise.
A bias under ~0.05 bits is negligible next to the 0.5-1.5 bit per-instance noise; above that, use fewer jobs.
Exit code 1 if any tested job count shows a median bias above --max-bias.
"""
import argparse
import math
import os
import statistics
import sys
from concurrent.futures import ThreadPoolExecutor

import families
import harness
import instances


def run_all(solver, tasks, budget, jobs):
    def work(t):
        dim, idx = t
        return harness.run_one(solver, families.derive("gm", instances.PRACTICE_SEED, dim, idx), budget)

    with ThreadPoolExecutor(max_workers=jobs) as ex:
        return list(ex.map(work, tasks))


def compare(seq, par, floor=0.05):
    """Paired log2(par/seq) over instances both solved, with cost above `floor` seconds. Returns (median, sd, n)."""
    v = [math.log2(p["cpu"] / s["cpu"]) for s, p in zip(seq, par)
         if s["status"] == "solved" and p["status"] == "solved" and s["cpu"] > floor and p["cpu"] > floor]
    if len(v) < 3:
        return None, None, len(v)
    return statistics.median(v), statistics.pstdev(v), len(v)


def ratio_shift(seq1, seq2, par1, par2, floor=0.05):
    """What matters for credit: does the paired log2(solver1/solver2) SPEEDUP change under concurrency?
    Per instance: (log2 c1/c2 under parallel) - (log2 c1/c2 sequential). Returns (median, sd, n)."""
    v = []
    for s1, s2, p1, p2 in zip(seq1, seq2, par1, par2):
        if all(r["status"] == "solved" and r["cpu"] > floor for r in (s1, s2, p1, p2)):
            v.append(math.log2(p1["cpu"] / p2["cpu"]) - math.log2(s1["cpu"] / s2["cpu"]))
    if len(v) < 3:
        return None, None, len(v)
    return statistics.median(v), statistics.pstdev(v), len(v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--solver2", help="a second solver: also report the shift of the SPEEDUP (solver / solver2), "
                    "which is what the credit uses and in which a uniform slowdown cancels")
    ap.add_argument("--solver", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "solvers", "baseline_bkz.py"))
    ap.add_argument("--dims", type=int, nargs="+", default=[62, 64])
    ap.add_argument("--n", type=int, default=6)
    ap.add_argument("--jobs", type=int, nargs="+", default=[4, 6, 8])
    ap.add_argument("--budget", type=float, default=60)
    ap.add_argument("--max-bias", type=float, default=0.05)
    a = ap.parse_args()
    solver = os.path.abspath(a.solver)
    tasks = [(d, i) for d in a.dims for i in range(a.n)]
    print(f"{len(tasks)} instances; machine has {os.cpu_count()} logical CPUs", flush=True)
    seq = run_all(solver, tasks, a.budget, 1)
    ref2 = run_all(solver, tasks, a.budget, 1)  # a second sequential pass: the noise floor of the comparison itself
    med, sd, n = compare(seq, ref2)
    print(f"sequential vs sequential (noise floor): median {med:+.3f} bits, sd {sd:.3f}, n={n}", flush=True)
    solver2 = os.path.abspath(a.solver2) if a.solver2 else None
    seq2 = run_all(solver2, tasks, a.budget, 1) if solver2 else None
    bad = False
    for j in a.jobs:
        par = run_all(solver, tasks, a.budget, j)
        med, sd, n = compare(seq, par)
        print(f"jobs={j:2d} vs sequential: absolute cpu time shifts by median {med:+.3f} bits, sd {sd:.3f}, n={n}", flush=True)
        if solver2:
            par2 = run_all(solver2, tasks, a.budget, j)
            m2, s2, n2 = ratio_shift(seq, seq2, par, par2)
            flag = "" if m2 is not None and abs(m2) <= a.max_bias else "   <-- BIASED"
            bad |= bool(flag)
            print(f"        SPEEDUP estimate shifts by median {m2:+.3f} bits, sd {s2:.3f}, n={n2}{flag}", flush=True)
        else:
            bad |= med is None or abs(med) > a.max_bias
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
