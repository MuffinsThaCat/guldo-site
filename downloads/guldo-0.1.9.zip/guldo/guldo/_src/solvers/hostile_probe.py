"""Red-team: tries to escape or tamper with the judge from inside a submission. Never solves anything; reports what it
managed to do by raising (the harness logs the exception text). Expect every 'escape' entry to be False in the sandbox."""
import os
import socket


def _try(f):
    try:
        f()
        return True
    except BaseException as e:  # noqa: BLE001
        return type(e).__name__


def solve(basis, bound2):
    rep = {"uid": os.getuid()}
    rep["forge_meter_stdout"] = _try(lambda: open(f"/proc/{os.getppid()}/fd/1", "w").write("forged"))
    rep["read_meter_env"] = _try(lambda: open(f"/proc/{os.getppid()}/environ").read())
    rep["setuid_root"] = _try(lambda: os.setuid(0))
    rep["write_work"] = _try(lambda: open("/work/pwn", "w").write("x"))
    rep["write_etc"] = _try(lambda: open("/etc/pwn", "w").write("x"))
    rep["network"] = _try(lambda: socket.create_connection(("1.1.1.1", 53), timeout=2))
    rep["read_host_home"] = _try(lambda: os.listdir("/Users"))
    pids = []
    for _ in range(100):
        try:
            pid = os.fork()
        except BaseException:  # noqa: BLE001
            break
        if pid == 0:
            import time
            time.sleep(2)
            os._exit(0)
        pids.append(pid)
    rep["forks_succeeded_of_100"] = len(pids)
    raise RuntimeError(repr(rep))
