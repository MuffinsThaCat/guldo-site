"""Baseline: one random assignment, then a single greedy sweep of single-node flips."""
import random


def solve(n, edges):
    rng = random.Random(12345)
    side = [rng.randrange(2) for _ in range(n)]
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)
    for u in range(n):
        same = sum(side[v] == side[u] for v in adj[u])
        if same > len(adj[u]) - same:
            side[u] ^= 1
    return side
