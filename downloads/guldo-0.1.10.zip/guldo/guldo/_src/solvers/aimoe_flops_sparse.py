"""aimoe in the counted-operations API, SPEEDUP: routing. Each token is sent only to its two experts, one batch per expert and slot, and the results are put back in token order."""
import math

import tensorops as tp

D, F, E = 32, 64, 8
ROUTER = 3.0


def solve(seed, n):
    o = n * D
    X = tp.stream(seed, 0, o, (n, D))
    Wg = tp.stream(seed, o, D * E, (D, E)) * (ROUTER * math.sqrt(3.0 / D))
    o += D * E
    W1 = tp.stream(seed, o, E * D * F, (E, D, F)) * math.sqrt(3.0 / D)
    o += E * D * F
    W2 = tp.stream(seed, o, E * F * D, (E, F, D)) * math.sqrt(3.0 / F)
    S = (X @ Wg).tolist()
    first = []
    second = []
    pa_col = []
    pb_col = []
    for row in S:
        a = 0
        for e in range(1, E):
            if row[e] > row[a]:
                a = e
        b = 1 if a == 0 else 0
        for e in range(E):
            if e != a and row[e] > row[b]:
                b = e
        pa = 1.0 / (1.0 + math.exp(row[b] - row[a]))
        first.append(a)
        second.append(b)
        pa_col.append([pa])
        pb_col.append([1.0 - pa])
    out = None
    for slot, chosen, weights in ((0, first, pa_col), (1, second, pb_col)):
        buckets = [[] for e in range(E)]
        for i in range(n):
            buckets[chosen[i]].append(i)
        order = []
        ys = []
        for e in range(E):
            if buckets[e]:
                order = order + buckets[e]
                ys.append(tp.relu(tp.take(X, buckets[e]) @ W1[e]) @ W2[e])
        inverse = [0] * n
        for p in range(n):
            inverse[order[p]] = p
        part = tp.take(tp.concat(ys, 0), inverse) * tp.tensor(weights)
        out = part if out is None else out + part
    return [int(x * 65536.0) for x in tp.reshape(out, (n * D,)).tolist()]
