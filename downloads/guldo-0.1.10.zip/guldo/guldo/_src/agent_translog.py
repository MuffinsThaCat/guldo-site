"""An append-only transparency log for agent-evaluation EVIDENCE: the thing that gives "published before" a clock the evaluator does not control.

A verifier's registry, a joint-seed commitment or a beacon record is only as early as the place it was published. This log is that place: a Merkle tree (RFC 9162, the tree code of translog.py) whose operator
signs a CHECKPOINT (size, root, time) after every entry, whose checkpoints independent WITNESSES co-sign after checking the log only grew, and whose heads can be stamped into Bitcoin through
OpenTimestamps (otsanchor.py). Anyone holding an entry, an inclusion proof and the log's PINNED key can check offline that the entry was in the log at a checkpoint, and when the operator said so.

ENTRY KINDS (each validated on admission, canonical JSON of at most 64 KB; `logged` is the operator's clock)
  commitment       a joint-seed party's signed commitment (agent_joint)        registry_entry   {identity, seq, hash, kind, round?}: an entry of a verifier's registry (agent_registry)
  registry_head    a signed head of a registry (agent_sig.sign_head)           beacon           a verified drand record (agent_beacon)
  round_head       {round, log_head, log_entries}: a round log's head

  python3 agent_translog.py init DIR --origin NAME --key K            python3 agent_translog.py append DIR --key K --kind KIND --file F
  python3 agent_translog.py prove DIR --seq N [--out F]               python3 agent_translog.py verify PROOF --log-key HEX [--witnesses KEYS --min-witnesses K]
  python3 agent_translog.py consistency DIR --old N [--new M]         python3 agent_translog.py verify-consistency PROOF --log-key HEX
  python3 agent_translog.py witness DIR --state S --log-key HEX --key W [--out F]        python3 agent_translog.py add-cosig DIR COSIG...
  python3 agent_translog.py anchor DIR [--no-network]                 python3 agent_translog.py check DIR --log-key HEX [--witnesses KEYS --min-witnesses K]

WHAT THIS PROVES. That an entry was in the log at a checkpoint the pinned key signed; that the log only ever grew between two checkpoints (consistency); that independent witnesses saw the same head (a log that
shows two readers two histories is caught the moment one reader compares). With an OpenTimestamps anchor: that a checkpoint existed before a Bitcoin block.
WHAT IT DOES NOT. `logged` is the OPERATOR'S clock: only witnesses' co-signature times and an anchor give a time the operator did not choose. Nothing forces anyone to log: "absent from the log" means "not
logged". A key shows who signed, never that its holder is independent of the party whose evidence is in the log: pin the keys you chose.
"""
import argparse
import base64
import calendar
import contextlib
import fcntl
import hashlib
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

import agent_beacon
import agent_core
import agent_joint
import agent_sig
import translog as T
from agent_core import canon

FORMAT = "guldo-agent-tlog-v1"
CP_FORMAT = "guldo-agent-checkpoint-v1"
COSIG_FORMAT = "guldo-agent-cosig-v1"
PROOF_FORMAT = "guldo-agent-inclusion-v1"
CONS_FORMAT = "guldo-agent-consistency-v1"
KINDS = ("commitment", "registry_entry", "registry_head", "beacon", "round_head")
REGISTRY_KINDS = ("round_open", "round_close", "round_void", "key_inception", "key_rotation", "key_retire")
MAX_ENTRY = 64 << 10
MAX_ENTRIES = 5_000_000
MAX_READ = 256 << 20
MAX_COSIGS = 200
ORIGIN_RE = re.compile(r"^[a-z0-9]([a-z0-9.-]{0,60}[a-z0-9])?(/[a-z0-9._-]{1,40}){0,3}$")
HEX64 = re.compile(r"^[0-9a-f]{64}$")
ISO_RE = re.compile(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")
FILES = ("log.json", "entries.jsonl", "checkpoints.jsonl", "cosigs.jsonl", "anchors.jsonl")


class LogError(Exception):
    pass


def now_iso(t=None):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() if t is None else t))


def epoch(iso):
    if not isinstance(iso, str) or not ISO_RE.match(iso):
        raise LogError("not an ISO time")
    return calendar.timegm(time.strptime(iso, "%Y-%m-%dT%H:%M:%SZ"))


def leaf_of(entry):
    return T.leaf_hash(canon(entry).encode("utf-8"))


def _cp_msg(body):
    return b"guldo-agent-tlog-checkpoint-v1\n" + canon(body).encode("utf-8")


def _cosig_msg(origin, log_key, size, root, t):
    """What a witness signs: it names the log's KEY as well as its origin, so a fork that copies the entries under another key cannot carry the original's co-signatures."""
    return ("guldo-agent-tlog-cosign-v1\n%s\n%s\n%d\n%s\n%s" % (origin, log_key, size, root, t)).encode("utf-8")


# ---- entries ------------------------------------------------------------------------------------------------------------------------------------------------

def validate_entry(kind, data):
    """Raise LogError unless `data` is an acceptable entry of `kind`. Cheap structural checks plus every signature or proof the entry carries."""
    if kind not in KINDS:
        raise LogError("unknown kind %r (one of %s)" % (kind, ", ".join(KINDS)))
    try:
        n = len(canon(data))
    except (TypeError, ValueError):
        raise LogError("the data is not JSON")
    if n > MAX_ENTRY:
        raise LogError("an entry is at most %d bytes" % MAX_ENTRY)
    if kind == "commitment":
        st = data.get("statement") if isinstance(data, dict) else None
        probs = agent_joint._commit_problems(data, st.get("ceremony") if isinstance(st, dict) else None)
        if probs:
            raise LogError("not a valid joint-seed commitment: " + probs[0])
    elif kind == "registry_entry":
        if not (isinstance(data, dict) and set(data) - {"round"} == {"identity", "seq", "hash", "kind"} and isinstance(data["identity"], str) and HEX64.match(data["identity"])
                and isinstance(data["hash"], str) and HEX64.match(data["hash"]) and isinstance(data["seq"], int) and not isinstance(data["seq"], bool) and data["seq"] >= 0
                and data["kind"] in REGISTRY_KINDS and (data.get("round") is None or isinstance(data.get("round"), str))):
            raise LogError("a registry_entry is {identity, seq, hash, kind, round?}")
    elif kind == "registry_head":
        if not (isinstance(data, dict) and agent_sig.statement_ok(data) and data["statement"].get("format") == agent_sig.HEAD_FORMAT):
            raise LogError("not a validly signed head")
    elif kind == "beacon":
        try:
            agent_beacon.check_record(data)
        except agent_beacon.BeaconError as e:
            raise LogError("the beacon record does not verify: %s" % e)
    elif kind == "round_head":
        if not (isinstance(data, dict) and set(data) == {"round", "log_head", "log_entries"} and isinstance(data["round"], str) and isinstance(data["log_head"], str) and HEX64.match(data["log_head"])
                and isinstance(data["log_entries"], int) and not isinstance(data["log_entries"], bool) and data["log_entries"] >= 1):
            raise LogError("a round_head is {round, log_head, log_entries}")


# ---- reading ------------------------------------------------------------------------------------------------------------------------------------------------

class Log(object):
    """A log as read from a directory or a URL (the files are static: publish the directory)."""

    def __init__(self, info, entries, checkpoints, cosigs, anchors):
        self.info, self.entries, self.checkpoints, self.cosigs, self.anchors = info, entries, checkpoints, cosigs, anchors
        self._tree = None

    @property
    def tree(self):
        if self._tree is None:
            self._tree = T.Tree([leaf_of(e) for e in self.entries])
        return self._tree

    def checkpoint_at(self, size):
        """The latest checkpoint of exactly this size, or None."""
        for cp in reversed(self.checkpoints):
            if cp["body"]["size"] == size:
                return cp
        return None

    def cosigs_for(self, size, root):
        return [c for c in self.cosigs if c.get("size") == size and c.get("root") == root][:MAX_COSIGS]


def _read_text(src, name):
    if re.match(r"^https?://", src):
        with urllib.request.urlopen(src.rstrip("/") + "/" + name, timeout=30) as r:
            data = r.read(MAX_READ + 1)
        if len(data) > MAX_READ:
            raise LogError("%s is too large" % name)
        return data.decode("utf-8")
    p = os.path.join(src, name)
    if not os.path.exists(p):
        return None
    with open(p, "r", encoding="utf-8") as f:
        return f.read(MAX_READ + 1)


def _jsonl(text):
    out = []
    for ln in (text or "").split("\n"):
        if ln.strip():
            try:
                out.append(json.loads(ln))
            except ValueError:
                raise LogError("a line of the log is not JSON")
    return out


def load(src):
    try:
        info = json.loads(_read_text(src, "log.json") or "null")
        entries = _jsonl(_read_text(src, "entries.jsonl"))
        cps = _jsonl(_read_text(src, "checkpoints.jsonl"))
        cos = _jsonl(_read_text(src, "cosigs.jsonl"))
        anchors = _jsonl(_read_text(src, "anchors.jsonl"))
    except (OSError, ValueError) as e:
        raise LogError("cannot read the log: %s" % type(e).__name__)
    if not isinstance(info, dict) or info.get("format") != FORMAT:
        raise LogError("not an agent transparency log")
    return Log(info, entries, cps, cos, anchors)


# ---- the operator ---------------------------------------------------------------------------------------------------------------------------------------------

@contextlib.contextmanager
def _locked(d):
    with open(os.path.join(d, "lock"), "a") as lf:
        fcntl.flock(lf, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lf, fcntl.LOCK_UN)


def _write_line(path, obj):
    with open(path, "a", encoding="utf-8") as f:
        f.write(canon(obj) + "\n")
        f.flush()
        os.fsync(f.fileno())


def _sign_checkpoint(d, secret, origin, size, root_hex, t):
    body = {"format": CP_FORMAT, "origin": origin, "size": size, "root": root_hex, "time": t}
    cp = {"body": body, "log": {"pubkey": agent_sig.public_key(secret).hex(), "sig": agent_sig.sign(secret, _cp_msg(body)).hex()}}
    _write_line(os.path.join(d, "checkpoints.jsonl"), cp)
    return cp


def init(d, origin, secret, now=None):
    if not ORIGIN_RE.match(origin or ""):
        raise LogError("an origin is a lowercase name like guldo.org/agent-log")
    if os.path.exists(os.path.join(d, "log.json")):
        raise LogError("%s already holds a log" % d)
    os.makedirs(d, exist_ok=True)
    pub = agent_sig.public_key(secret).hex()
    with open(os.path.join(d, "log.json"), "w", encoding="utf-8") as f:
        f.write(json.dumps({"format": FORMAT, "origin": origin, "pubkey": pub, "created": now_iso(now)}, indent=1, sort_keys=True) + "\n")
    for name in FILES[1:]:
        open(os.path.join(d, name), "a").close()
    _sign_checkpoint(d, secret, origin, 0, T.EMPTY_ROOT.hex(), now_iso(now))
    return pub


def append(d, secret, kind, data, now=None):
    """Admit one entry and sign a new checkpoint. Returns (entry, checkpoint). Identical evidence already in the log is NOT added twice (the existing entry is returned): a log cannot be flooded with copies."""
    validate_entry(kind, data)
    with _locked(d):
        log = load(d)
        if agent_sig.public_key(secret).hex() != log.info["pubkey"]:
            raise LogError("this is not the log's key")
        if len(log.entries) >= MAX_ENTRIES:
            raise LogError("the log is full")
        for e in log.entries:
            if e["kind"] == kind and canon(e["data"]) == canon(data):
                return e, log.checkpoints[-1]
        entry = {"v": 1, "seq": len(log.entries), "logged": now_iso(now), "kind": kind, "data": data}
        if entry["seq"] and epoch(entry["logged"]) < epoch(log.entries[-1]["logged"]):
            raise LogError("the clock ran backwards")
        _write_line(os.path.join(d, "entries.jsonl"), entry)
        log.entries.append(entry)
        log._tree = None
        cp = _sign_checkpoint(d, secret, log.info["origin"], len(log.entries), log.tree.root().hex(), entry["logged"])
        return entry, cp


def heartbeat(d, secret, now=None):
    """A fresh checkpoint at the current size: proves the log was alive and unchanged."""
    with _locked(d):
        log = load(d)
        if agent_sig.public_key(secret).hex() != log.info["pubkey"]:
            raise LogError("this is not the log's key")
        return _sign_checkpoint(d, secret, log.info["origin"], len(log.entries), log.tree.root().hex(), now_iso(now))


def add_cosigs(d, cosigs):
    """Merge witness co-signatures into the published file. Each must verify (the operator cannot forge one) AND be for a head this log really has: a witness that signed a size and root which are not
    this log's was shown a DIFFERENT history, and its signature is refused here (it is evidence of a fork, not a co-signature)."""
    with _locked(d):
        log = load(d)
        n = 0
        for c in cosigs:
            if _cosig_problem(c, log.info) is not None or canon(c) in {canon(x) for x in log.cosigs}:
                continue
            if c["size"] > len(log.entries) or log.tree.root(c["size"]).hex() != c["root"]:
                continue
            _write_line(os.path.join(d, "cosigs.jsonl"), c)
            n += 1
        return n


def _cosig_problem(c, info):
    try:
        if not isinstance(c, dict) or c.get("format") != COSIG_FORMAT or (c["origin"], c["log_key"]) != (info["origin"], info["pubkey"]):
            return "a co-signature for another log"
        if not (isinstance(c["size"], int) and HEX64.match(c["root"]) and HEX64.match(c["pubkey"]) and ISO_RE.match(c["time"])):
            return "a malformed co-signature"
        if c["pubkey"] == info["pubkey"]:
            return "the log's own key is not a witness"
        if not agent_sig.verify(bytes.fromhex(c["pubkey"]), _cosig_msg(c["origin"], c["log_key"], c["size"], c["root"], c["time"]), bytes.fromhex(c["sig"])):
            return "a co-signature does not verify"
    except (KeyError, TypeError, ValueError):
        return "a malformed co-signature"
    return None


# ---- proofs -------------------------------------------------------------------------------------------------------------------------------------------------

def checkpoint_problems(cp, log_key):
    """Problems with one signed checkpoint bundle {body, log}. `log_key` is the key YOU pinned."""
    try:
        b, lg = cp["body"], cp["log"]
        if set(b) != {"format", "origin", "size", "root", "time"} or b["format"] != CP_FORMAT or not ORIGIN_RE.match(b["origin"]) or not isinstance(b["size"], int) or isinstance(b["size"], bool) \
                or b["size"] < 0 or not HEX64.match(b["root"]) or not ISO_RE.match(b["time"]):
            return ["a malformed checkpoint body"]
        if not agent_sig.verify(bytes.fromhex(lg["pubkey"]), _cp_msg(b), bytes.fromhex(lg["sig"])):
            return ["the checkpoint's signature is not valid"]
        if log_key is None:
            return ["you did not pin the log's key: the signature shows only that SOME key signed"]
        if lg["pubkey"] != log_key:
            return ["the checkpoint is signed by %s..., not the key you pinned" % lg["pubkey"][:16]]
    except (KeyError, TypeError, ValueError, AttributeError):
        return ["a malformed checkpoint"]
    return []


def prove(log, seq, size=None):
    """An inclusion proof for entry `seq` against the checkpoint of `size` (the latest by default): one document a stranger can check offline."""
    size = len(log.entries) if size is None else size
    if not 0 <= seq < size <= len(log.entries):
        raise LogError("entry %d is not in a log of size %d" % (seq, size))
    cp = log.checkpoint_at(size)
    if cp is None:
        raise LogError("the log has no checkpoint of size %d" % size)
    return {"format": PROOF_FORMAT, "origin": log.info["origin"], "log_key": log.info["pubkey"], "entry": log.entries[seq], "index": seq, "size": size,
            "path": [h.hex() for h in log.tree.inclusion(seq, size)], "checkpoint": cp, "cosigs": log.cosigs_for(size, cp["body"]["root"])}


def verify_proof(proof, log_key, witnesses=(), min_witnesses=0):
    """(problems, info). Empty problems = the entry is in the log at the checkpoint, signed by the key you pinned, with at least `min_witnesses` co-signatures from keys you pinned."""
    probs, info = [], {}
    try:
        if not isinstance(proof, dict) or proof.get("format") != PROOF_FORMAT:
            return ["not an inclusion proof"], info
        e, cp = proof["entry"], proof["checkpoint"]
        probs += checkpoint_problems(cp, log_key)
        b = cp["body"]
        if (proof["size"], proof["origin"]) != (b["size"], b["origin"]):
            probs.append("the proof is for a different checkpoint than the one it carries")
        if e.get("seq") != proof["index"]:
            probs.append("the entry's sequence number is not its position")
        path = [bytes.fromhex(h) for h in proof["path"]]
        if not T.verify_inclusion(leaf_of(e), proof["index"], proof["size"], path, bytes.fromhex(b["root"])):
            probs.append("the entry is NOT in the tree the checkpoint signs")
        if epoch(e["logged"]) > epoch(b["time"]):
            probs.append("the entry claims to be logged AFTER the checkpoint that contains it")
        try:
            validate_entry(e["kind"], e["data"])
        except LogError as ex:
            probs.append("the entry is not a valid %s: %s" % (e.get("kind"), ex))
        pins, seen = set(witnesses or ()), {}
        for c in (proof.get("cosigs") or [])[:MAX_COSIGS]:
            if _cosig_problem(c, {"origin": b["origin"], "pubkey": cp["log"]["pubkey"]}) is None and (c["size"], c["root"]) == (b["size"], b["root"]):
                seen[c["pubkey"]] = c
        pinned = [k for k in seen if k in pins]
        if len(pinned) < min_witnesses:
            probs.append("only %d of the %d required witnesses you pinned co-signed this checkpoint" % (len(pinned), min_witnesses))
        info = {"entry": e, "logged": epoch(e["logged"]), "checkpoint_time": epoch(b["time"]), "size": b["size"], "index": proof["index"], "witnesses_pinned": len(pinned),
                "witness_times": sorted(epoch(seen[k]["time"]) for k in pinned)}
    except (KeyError, TypeError, ValueError, AttributeError, LogError) as ex:
        probs.append("malformed proof (%s)" % type(ex).__name__)
    return probs, info


def consistency_proof(log, old, new=None):
    new = len(log.entries) if new is None else new
    if not 0 <= old <= new <= len(log.entries):
        raise LogError("sizes %d..%d are outside the log" % (old, new))
    a, b = log.checkpoint_at(old), log.checkpoint_at(new)
    if a is None or b is None:
        raise LogError("the log has no checkpoint at one of those sizes")
    return {"format": CONS_FORMAT, "old": a, "new": b, "path": [h.hex() for h in log.tree.consistency(old, new)]}


def consistency_chain(log, proofs):
    """Consistency proofs between each pair of consecutive DISTINCT checkpoints that the inclusion proofs in `proofs` ({name: proof}) rely on. Proofs taken against different checkpoints can only be
    compared (entry order, times) if those checkpoints are one history: these are what shows it."""
    sizes = sorted({p["checkpoint"]["body"]["size"] for p in proofs.values()})
    return [consistency_proof(log, a, b) for a, b in zip(sizes, sizes[1:])]


def history_problems(proofs, consistency, log_key):
    """Problems unless every inclusion proof in `proofs` ({name: proof}) comes from ONE history of the log: no two proofs may give different roots for the same size, and the checkpoints they use must
    be linked, pair by pair in size order, by valid consistency proofs under the pinned key. (A log operator who signed two histories, one flattering each claim, is exactly what this catches.)"""
    probs, roots = [], {}
    for name, p in proofs.items():
        try:
            b = p["checkpoint"]["body"]
            if roots.setdefault(b["size"], b["root"]) != b["root"]:
                probs.append("proofs disagree about the root of a log of %d entries (%s): the log signed two histories" % (b["size"], name))
        except (KeyError, TypeError):
            probs.append("a proof carries no checkpoint")
    have = {}
    for c in consistency if isinstance(consistency, list) else []:
        pp = verify_consistency(c, log_key)
        if pp:
            probs.append("a consistency proof does not verify: %s" % pp[0])
            continue
        have[(c["old"]["body"]["size"], c["new"]["body"]["size"])] = (c["old"]["body"]["root"], c["new"]["body"]["root"])
    sizes = sorted(roots)
    for a, b in zip(sizes, sizes[1:]):
        got = have.get((a, b))
        if got is None:
            probs.append("nothing links the log's checkpoints of %d and %d entries: the proofs may come from different histories" % (a, b))
        elif got != (roots[a], roots[b]):
            probs.append("the consistency proof between %d and %d entries is for different checkpoints than the proofs use" % (a, b))
    return probs


def verify_consistency(proof, log_key):
    probs = []
    try:
        if proof.get("format") != CONS_FORMAT:
            return ["not a consistency proof"]
        probs += checkpoint_problems(proof["old"], log_key) + checkpoint_problems(proof["new"], log_key)
        o, n = proof["old"]["body"], proof["new"]["body"]
        if not T.verify_consistency(o["size"], n["size"], bytes.fromhex(o["root"]), bytes.fromhex(n["root"]), [bytes.fromhex(h) for h in proof["path"]]):
            probs.append("the older checkpoint is NOT a prefix of the newer one: the log was rewritten")
    except (KeyError, TypeError, ValueError, AttributeError):
        probs.append("malformed proof")
    return probs


# ---- witnesses ----------------------------------------------------------------------------------------------------------------------------------------------

def witness(log, state_path, log_key, secret, now=None):
    """A witness: check the log only GREW since the checkpoint this witness last saw (and that it can reproduce the root from the entries), then co-sign the latest checkpoint. The witness's state
    file records what it last saw. Returns the co-signature. Raises LogError, writing nothing, if the log forked or shrank."""
    cp = log.checkpoints[-1] if log.checkpoints else None
    if cp is None:
        raise LogError("the log has no checkpoint")
    probs = checkpoint_problems(cp, log_key)
    if probs:
        raise LogError(probs[0])
    b = cp["body"]
    if b["size"] != len(log.entries) or log.tree.root().hex() != b["root"]:
        raise LogError("the checkpoint is not the root of the entries published: the log is inconsistent with itself")
    state = {}
    if os.path.exists(state_path):
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
    if state:
        if state.get("log_key") != log_key:
            raise LogError("this state file belongs to another log key")
        if b["size"] < state["size"]:
            raise LogError("the log SHRANK from %d to %d entries" % (state["size"], b["size"]))
        if log.tree.root(state["size"]).hex() != state["root"]:
            raise LogError("EQUIVOCATION: the log's history no longer contains the checkpoint this witness saw at size %d" % state["size"])
    t = now_iso(now)
    pub = agent_sig.public_key(secret).hex()
    co = {"format": COSIG_FORMAT, "origin": b["origin"], "log_key": log_key, "size": b["size"], "root": b["root"], "pubkey": pub, "time": t,
          "sig": agent_sig.sign(secret, _cosig_msg(b["origin"], log_key, b["size"], b["root"], t)).hex()}
    with open(state_path, "w", encoding="utf-8") as f:
        json.dump({"log_key": log_key, "size": b["size"], "root": b["root"], "at": t}, f)
    return co


# ---- a round's evidence ---------------------------------------------------------------------------------------------------------------------------------------

def registry_entry_data(reg_rows, seq):
    """The log entry that publishes registry entry `seq`: its identity (the registry's first key), position and hash."""
    e = reg_rows[seq]
    d = {"identity": reg_rows[0]["pubkey"], "seq": seq, "hash": e["hash"], "kind": e["kind"]}
    if isinstance(e.get("data"), dict) and isinstance(e["data"].get("round"), str):
        d["round"] = e["data"]["round"]
    return d


def best_size(log, seq):
    """The checkpoint size to prove entry `seq` against: the EARLIEST checkpoint covering it that independent witnesses co-signed (so the proof carries a time the operator did not choose), or the
    latest checkpoint when no witness has co-signed one."""
    for s in sorted({cp["body"]["size"] for cp in log.checkpoints if cp["body"]["size"] > seq}):
        cp = log.checkpoint_at(s)
        if log.cosigs_for(s, cp["body"]["root"]):
            return s
    return len(log.entries)


def evidence_proofs(log, joint, reg_rows, rid, beacon_record=None):
    """{name: inclusion proof} for everything a reader needs to order a round: each joint-seed party's commitment, the registry's open and close entries of the round and (if the ceremony used one) the
    beacon record. Raises LogError listing whatever was never logged: unlogged evidence has no log time and cannot be ordered."""
    import agent_registry as REG
    out, missing = {}, []

    def find(kind, data):
        for e in log.entries:
            if e["kind"] == kind and canon(e["data"]) == canon(data):
                return e["seq"]
        return None
    for c in joint["parties"]:
        s = find("commitment", c)
        name = "commitment.%s" % c["statement"]["party"]
        if s is None:
            missing.append(name)
        else:
            out[name] = prove(log, s, best_size(log, s))
    info = REG.rounds(reg_rows).get(rid)
    if info is None:
        raise LogError("round %s is not in the registry" % rid)
    for label, ent in (("registry_open", info["open"]), ("registry_close", info["end"])):
        if ent is None:
            missing.append(label)
            continue
        s = find("registry_entry", registry_entry_data(reg_rows, ent["seq"]))
        if s is None:
            missing.append(label)
        else:
            out[label] = prove(log, s, best_size(log, s))
    if beacon_record is not None:
        s = find("beacon", beacon_record)
        if s is None:
            missing.append("beacon")
        else:
            out["beacon"] = prove(log, s, best_size(log, s))
    if missing:
        raise LogError("never logged, so it has no log time: %s" % ", ".join(missing))
    return out


# ---- external time: OpenTimestamps --------------------------------------------------------------------------------------------------------------------------

def checkpoint_digest(cp):
    return hashlib.sha256(canon(cp["body"]).encode("utf-8")).digest()


def anchor(d, http=None, calendars=None):
    """Stamp the latest checkpoint's digest with the OpenTimestamps calendars (a real network call unless `http` is injected). The proof is `pending` until Bitcoin confirms it, hours later; run
    `anchor` again or otsanchor.upgrade to complete it. Returns the anchors.jsonl line written."""
    import otsanchor
    with _locked(d):
        log = load(d)
        cp = log.checkpoints[-1]
        kw = {}
        if http is not None:
            kw["http"] = http
        if calendars is not None:
            kw["calendars"] = calendars
        proof, report = otsanchor.stamp(checkpoint_digest(cp), **kw)
        line = {"size": cp["body"]["size"], "root": cp["body"]["root"], "digest": checkpoint_digest(cp).hex(), "ots_b64": base64.b64encode(proof).decode("ascii"), "stamped": now_iso(),
                "calendars": sorted(k for k, v in report.items() if v is None)}
        _write_line(os.path.join(d, "anchors.jsonl"), line)
        return line


def anchor_status(line):
    """What an anchors.jsonl line CLAIMS (parsing only, nothing checked against Bitcoin): {'status': 'pending'|'bitcoin', 'heights': [...], 'pending': [calendar uris]}. `anchor_verify` is the check."""
    import otsanchor
    try:
        d = otsanchor.describe(base64.b64decode(line["ots_b64"]))
    except (KeyError, TypeError, ValueError, otsanchor.OtsError) as e:
        raise LogError("an unreadable anchor (%s)" % type(e).__name__)
    return {"status": "bitcoin" if d["bitcoin"] else "pending", "heights": d["bitcoin"], "pending": d["pending"], "digest": d["digest"]}


def anchor_verify(line, cp, http=None, explorers=None, min_sources=2):
    """Check an anchor line against the checkpoint it should stamp AND against Bitcoin (otsanchor.verify; a network call unless `http` is injected). The digest the proof stamps must be the digest of
    THIS checkpoint, recomputed here, never the line's own claim. Returns otsanchor's {status, detail, time, height}."""
    import otsanchor
    kw = {"min_sources": min_sources}
    if http is not None:
        kw["http"] = http
    if explorers is not None:
        kw["explorers"] = explorers
    if line.get("size") != cp["body"]["size"] or line.get("root") != cp["body"]["root"]:
        return {"status": "mismatch", "detail": "the anchor is for a different checkpoint", "time": None, "height": None}
    try:
        return otsanchor.verify(base64.b64decode(line["ots_b64"]), checkpoint_digest(cp), **kw)
    except (KeyError, TypeError, ValueError):
        return {"status": "invalid", "detail": "an unreadable anchor", "time": None, "height": None}


def anchor_upgrade(d, http=None):
    """Ask the calendars whether pending anchors now have a Bitcoin proof; append an upgraded line for each that does. Returns how many were upgraded."""
    import otsanchor
    n = 0
    with _locked(d):
        log = load(d)
        latest = {}
        for line in log.anchors:                                       # the file is append-only: only the LATEST line for a checkpoint counts, or every call would upgrade the old pending one again
            latest[(line.get("size"), line.get("root"))] = line
        for line in list(latest.values()):
            if anchor_status(line)["status"] != "pending":
                continue
            new, _notes = otsanchor.upgrade(base64.b64decode(line["ots_b64"]), **({"http": http} if http is not None else {}))
            if new is not None:
                _write_line(os.path.join(d, "anchors.jsonl"), dict(line, ots_b64=base64.b64encode(new).decode("ascii"), upgraded=now_iso()))
                n += 1
    return n


# ---- whole-log check --------------------------------------------------------------------------------------------------------------------------------------

def check(log, log_key, witnesses=(), min_witnesses=0):
    """Problems with a whole log: every checkpoint signed by the pinned key; every checkpoint's root reproduced from the entries (so the entries really are what each checkpoint signed); sizes and times never
    shrinking; every entry valid; every co-signature genuine; the latest checkpoint carrying `min_witnesses` of the witnesses you pinned."""
    probs = []
    if log.info.get("pubkey") != log_key:
        probs.append("the log's key is not the key you pinned")
    last_size, last_t = -1, 0
    for i, cp in enumerate(log.checkpoints):
        pp = checkpoint_problems(cp, log_key)
        if pp:
            probs.append("checkpoint %d: %s" % (i, pp[0]))
            continue
        b = cp["body"]
        if b["size"] > len(log.entries):
            probs.append("checkpoint %d claims %d entries; the log has %d" % (i, b["size"], len(log.entries)))
        elif log.tree.root(b["size"]).hex() != b["root"]:
            probs.append("checkpoint %d's root is not the root of the first %d entries" % (i, b["size"]))
        if b["size"] < last_size or epoch(b["time"]) < last_t:
            probs.append("checkpoint %d goes backwards" % i)
        last_size, last_t = b["size"], epoch(b["time"])
    if not log.checkpoints or log.checkpoints[-1]["body"]["size"] != len(log.entries):
        probs.append("the latest checkpoint does not cover every entry")
    for i, e in enumerate(log.entries):
        try:
            if e["seq"] != i:
                probs.append("entry %d is numbered %r" % (i, e["seq"]))
            validate_entry(e["kind"], e["data"])
            if i and epoch(e["logged"]) < epoch(log.entries[i - 1]["logged"]):
                probs.append("entry %d is dated before the one before it" % i)
        except (KeyError, TypeError, LogError) as ex:
            probs.append("entry %d is invalid (%s)" % (i, str(ex)[:60]))
    for c in log.cosigs:
        p = _cosig_problem(c, log.info)
        if p:
            probs.append(p)
    if log.checkpoints and min_witnesses:
        cp = log.checkpoints[-1]["body"]
        good = {c["pubkey"] for c in log.cosigs_for(cp["size"], cp["root"]) if _cosig_problem(c, log.info) is None and c["pubkey"] in set(witnesses or ())}
        if len(good) < min_witnesses:
            probs.append("the latest checkpoint has %d of the %d witnesses you pinned" % (len(good), min_witnesses))
    return probs


# ---- command line -------------------------------------------------------------------------------------------------------------------------------------------

def _jload(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init")
    p.add_argument("dir")
    p.add_argument("--origin", required=True)
    p.add_argument("--key", required=True)
    p = sub.add_parser("append")
    p.add_argument("dir")
    p.add_argument("--key", required=True)
    p.add_argument("--kind", required=True)
    p.add_argument("--file", required=True)
    p = sub.add_parser("prove")
    p.add_argument("dir")
    p.add_argument("--seq", type=int, required=True)
    p.add_argument("--out")
    p = sub.add_parser("verify")
    p.add_argument("proof")
    p.add_argument("--log-key", required=True)
    p.add_argument("--witnesses")
    p.add_argument("--min-witnesses", type=int, default=0)
    p = sub.add_parser("consistency")
    p.add_argument("dir")
    p.add_argument("--old", type=int, required=True)
    p.add_argument("--new", type=int)
    p.add_argument("--out")
    p = sub.add_parser("verify-consistency")
    p.add_argument("proof")
    p.add_argument("--log-key", required=True)
    p = sub.add_parser("witness")
    p.add_argument("dir")
    p.add_argument("--state", required=True)
    p.add_argument("--log-key", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--out")
    p = sub.add_parser("add-cosig")
    p.add_argument("dir")
    p.add_argument("cosigs", nargs="+")
    p = sub.add_parser("anchor")
    p.add_argument("dir")
    p = sub.add_parser("check")
    p.add_argument("dir")
    p.add_argument("--log-key", required=True)
    p.add_argument("--witnesses")
    p.add_argument("--min-witnesses", type=int, default=0)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "init":
            print("log %s created; its key is %s (publish it; keep the key file OUTSIDE %s)" % (a.origin, init(a.dir, a.origin, agent_sig.load_secret(a.key)), a.dir))
            return 0
        if a.cmd == "append":
            e, cp = append(a.dir, agent_sig.load_secret(a.key), a.kind, _jload(a.file))
            print("logged entry %d (%s) at %s; checkpoint size %d root %s..." % (e["seq"], e["kind"], e["logged"], cp["body"]["size"], cp["body"]["root"][:16]))
            return 0
        if a.cmd == "prove":
            doc = prove(load(a.dir), a.seq)
            if a.out:
                with open(a.out, "w", encoding="utf-8") as f:
                    json.dump(doc, f, indent=1, sort_keys=True)
                print("wrote %s" % a.out)
            else:
                print(json.dumps(doc, indent=1, sort_keys=True))
            return 0
        if a.cmd == "verify":
            wit = agent_sig.read_trusted(a.witnesses) if a.witnesses else ()
            probs, info = verify_proof(_jload(a.proof), a.log_key, wit, a.min_witnesses)
            for pr in probs:
                print("FAIL  " + pr)
            if not probs:
                print("PROOF VERIFIED: %s entry %d was in the log at checkpoint size %d (logged %s UTC; %d pinned witness(es))" % (
                    info["entry"]["kind"], info["index"], info["size"], time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(info["logged"])), info["witnesses_pinned"]))
            return 1 if probs else 0
        if a.cmd == "consistency":
            doc = consistency_proof(load(a.dir), a.old, a.new)
            out = json.dumps(doc, indent=1, sort_keys=True)
            if a.out:
                with open(a.out, "w", encoding="utf-8") as f:
                    f.write(out)
            else:
                print(out)
            return 0
        if a.cmd == "verify-consistency":
            probs = verify_consistency(_jload(a.proof), a.log_key)
            for pr in probs:
                print("FAIL  " + pr)
            print("CONSISTENT: the older checkpoint is a prefix of the newer" if not probs else "NOT CONSISTENT")
            return 1 if probs else 0
        if a.cmd == "witness":
            co = witness(load(a.dir), a.state, a.log_key, agent_sig.load_secret(a.key))
            out = json.dumps(co, indent=1, sort_keys=True)
            if a.out:
                with open(a.out, "w", encoding="utf-8") as f:
                    f.write(out)
                print("co-signed size %d; wrote %s" % (co["size"], a.out))
            else:
                print(out)
            return 0
        if a.cmd == "add-cosig":
            print("merged %d co-signature(s)" % add_cosigs(a.dir, [_jload(p_) for p_ in a.cosigs]))
            return 0
        if a.cmd == "anchor":
            line = anchor(a.dir)
            print("stamped checkpoint size %d with %d calendar(s); the proof is pending until Bitcoin confirms it" % (line["size"], len(line["calendars"])))
            return 0
        probs = check(load(a.dir), a.log_key, agent_sig.read_trusted(a.witnesses) if a.witnesses else (), a.min_witnesses)
        for pr in probs:
            print("FAIL  " + pr)
        print("LOG OK" if not probs else "LOG NOT OK")
        return 1 if probs else 0
    except (LogError, OSError, ValueError, KeyError, agent_core.AgentEvalError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
