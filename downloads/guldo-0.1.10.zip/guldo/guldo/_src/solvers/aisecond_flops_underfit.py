"""aisecond in the counted-operations API, CHEAT: the reference method stopped after 60 steps. It is cheap and nowhere near the minimum, so the judge must reject it."""
import math

import tensorops as tp

RHO = 0.97
LAM = 1e-4
STEPS = 60


def solve(seed, d, n, labels):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    X = (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)
    y = tp.tensor([float(v) for v in labels])
    Xt = tp.transpose(X, (1, 0))
    lr = 1.0 / (tp.sum(X * X).item() / (4.0 * n) + LAM)
    w = tp.zeros((d,))
    for step in range(STEPS):
        w = w - (Xt @ (1.0 / (1.0 + tp.exp(-(X @ w))) - y) * (1.0 / n) + w * LAM) * lr
    return [int(v * 1048576.0) for v in w.tolist()]
