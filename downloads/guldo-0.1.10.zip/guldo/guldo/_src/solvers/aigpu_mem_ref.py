"""aigpu with bytes counted (tflops_mem.py), REFERENCE: unfused attention in float64: scores Q K^T for every head at once, then the softmax as five separate passes over the n x n score matrix (max, subtract,
exp, sum, divide), then P V, the read-out and the labels. Every operation reads its operands and writes its result (the convention has no fusion), so the score matrix is written and read many times."""
import math

import tensorops as tp

CLASSES = 16


def inputs(seed, n, H, dk):
    m = H * n * dk
    d = H * dk
    Q = tp.reshape(tp.stream(seed, 0, m), (H, n, dk)) * 3.0
    K = tp.reshape(tp.stream(seed, m, m), (H, n, dk))
    V = tp.reshape(tp.stream(seed, 2 * m, m), (H, n, dk))
    Wout = tp.reshape(tp.stream(seed, 3 * m, d * CLASSES), (d, CLASSES)) * math.sqrt(3.0 / d)
    return Q, K, V, Wout


def labels(O, Wout, n, H, dk):
    rows = (tp.reshape(tp.transpose(O, (1, 0, 2)), (n, H * dk)) @ Wout).tolist()
    return [row.index(max(row)) for row in rows]


def solve(seed, n, H, dk):
    Q, K, V, Wout = inputs(seed, n, H, dk)
    S = (Q @ tp.transpose(K, (0, 2, 1))) * (1.0 / math.sqrt(dk))
    E = tp.exp(S - tp.max(S, 2, True))
    P = E / tp.sum(E, 2, True)
    return labels(P @ V, Wout, n, H, dk)
