"""aisecond in the counted-operations API, TECHNIQUE (the best FIRST-order method, for fairness): Nesterov's accelerated gradient with the strongly-convex momentum
beta = (sqrt(k)-1)/(sqrt(k)+1), k = L/lambda, step 1/L. It needs about the square root of the condition number in steps instead of the condition number. It stops when the gradient is
small enough that the loss is within the target of the minimum (|g|^2 / (2 lambda) bounds the gap), checked every 25 steps."""
import math

import tensorops as tp

RHO = 0.97
LAM = 1e-4
MAXSTEPS = 20000
CHECK = 25
GRAD2 = 2e-13          # |g|^2 <= GRAD2 means gap <= |g|^2 / (2 lambda) <= 1e-9: a margin of 10 under the judge's 1e-8


def solve(seed, d, n, labels):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    X = (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)
    y = tp.tensor([float(v) for v in labels])
    Xt = tp.transpose(X, (1, 0))
    L = tp.sum(X * X).item() / (4.0 * n) + LAM
    beta = (math.sqrt(L / LAM) - 1.0) / (math.sqrt(L / LAM) + 1.0)
    w = tp.zeros((d,))
    v = w
    for step in range(MAXSTEPS):
        g = Xt @ (1.0 / (1.0 + tp.exp(-(X @ v))) - y) * (1.0 / n) + v * LAM
        w_new = v - g * (1.0 / L)
        v = w_new + (w_new - w) * beta
        w = w_new
        if step % CHECK == CHECK - 1:
            g2 = Xt @ (1.0 / (1.0 + tp.exp(-(X @ w))) - y) * (1.0 / n) + w * LAM
            if tp.sum(g2 * g2).item() <= GRAD2:
                break
    return [int(v * 1048576.0) for v in w.tolist()]
