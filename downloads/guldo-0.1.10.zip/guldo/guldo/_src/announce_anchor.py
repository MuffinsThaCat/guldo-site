"""An OUTSIDE CLOCK for a round announcement, with no person involved: the announcement's hash is stamped with OpenTimestamps (Bitcoin). Standard library + otsanchor.py + agent_witness_kit.py (read-only use).

  announce_anchor.py stamp   ANNOUNCE.json [--out PROOF.ots] [--send]      send the announcement's digest to the public calendars (WITHOUT --send: show what would be sent and send nothing)
  announce_anchor.py upgrade PROOF.ots [--out FILE] [--send]               hours later: ask the calendars whether the Bitcoin proof is ready; writes a NEW file, never overwrites the proof
  announce_anchor.py status  ANNOUNCE.json PROOF.ots [--base B --round ID] [--online]       what the proof shows (WITHOUT --online: read the file only, ask nobody)

What leaves your computer, only with --send: sha256(digest || random nonce), to the calendar servers in otsanchor.CALENDARS. Not the announcement, not the plan, not the digest itself.
`status --online` asks block explorers (blockstream.info, mempool.space) for the block that the proof names.

WHAT IT SHOWS, AND THE ORDER THAT MAKES IT MEAN SOMETHING. A confirmed proof shows the announcement existed NO LATER THAN the Bitcoin block's time T, a clock the operator does not control. The round's own log
says when its first entry arrived, but that timestamp is the operator's word. A block's timestamp is also only accurate to about two hours (BLOCK_TIME_SLACK), so "before" needs T earlier than the first entry
by MORE than that, and a block that is earlier by less is reported as "close", which establishes nothing. So the claim "the plan was publicly fixed before the run" holds only if T is clearly earlier than the first entry: announce, stamp, WAIT for
the Bitcoin confirmation (hours; run `upgrade`, then `status --online`), and only then let entries in. `status --round` makes the comparison and says which way it came out. A stamp made after the run, or a run
that did not wait, still shows the plan existed by T, and says nothing about being before the run. It also does not show the seed was unknown to the operator, and it is not a witness: nobody checked anything.
"""
import argparse
import os
import sys

import agent_core
import agent_witness_kit as K
import otsanchor

NOTHING_SENT = "Nothing was sent."
BLOCK_TIME_SLACK = 7200      # seconds. A Bitcoin block's timestamp is not a precise clock: the network accepts one up to 2 hours AHEAD of real time and one that is merely later than the median of the previous 11 blocks, so
                             # it can understate the real time by an hour or more. "Before the first entry" therefore needs the block time to be earlier by MORE than this, not just earlier.


def digest_of(announce_doc):
    """The 32-byte digest that is stamped: sha256 of the announcement's canonical JSON, the same value a witness's bundle binds (`announce_sha256`)."""
    return bytes.fromhex(K.announce_sha256(announce_doc))


def anchor_status(announce_doc, proof, first_entry_ts=None, online=False, http=None, explorers=None):
    """-> {"verdict", "strength", "detail", "time", "height"}.
    verdict: "before"  Bitcoin confirms the announcement existed before the round's first entry, with a margin of BLOCK_TIME_SLACK for the imprecision of block timestamps;
             "close"   the block is earlier than the first entry but by less than that margin: the order is not established;
             "after"   it confirms it existed by T, but T is NOT earlier than the first entry (so it shows nothing about before-the-run);
             "anchored" confirmed, and no round was given to compare with;
             "pending"  held by calendars, no Bitcoin block yet;  "unverified"  claims Bitcoin but was not (or could not be) checked against it;
             "mismatch" the proof is for another digest or a block disagrees (forged/wrong);  "invalid"  not a proof.
    strength: "confirmed" (>= 2 independent explorers saw the block) or "single-source" (fewer: weaker) or None."""
    out = {"verdict": "invalid", "strength": None, "detail": "", "time": None, "height": None}
    digest = digest_of(announce_doc)
    if not online:
        try:
            info = otsanchor.describe(proof)
        except otsanchor.OtsError as e:
            out["detail"] = "not a valid OpenTimestamps proof: %s" % e
            return out
        if info["digest"] != digest.hex():
            out.update(verdict="mismatch", detail="this proof stamps a different digest than this announcement's")
        elif info["bitcoin"]:
            out.update(verdict="unverified", height=info["bitcoin"][0], detail="the file CLAIMS a Bitcoin attestation (block %s) but was not checked against Bitcoin: use --online" % info["bitcoin"][0])
        else:
            out.update(verdict="pending", detail="held by %s; no Bitcoin block yet" % (", ".join(info["pending"]) or "no calendar"))
        return out
    kwargs = {"http": http or otsanchor.default_http}
    if explorers:
        kwargs["explorers"] = explorers
    r = otsanchor.verify(proof, digest, **kwargs)
    status = r["status"]
    if status in ("confirmed", "single-source"):
        out.update(strength=status, time=r["time"], height=r.get("height"), detail=r["detail"])
        if first_entry_ts is None:
            out["verdict"] = "anchored"
        elif r["time"] + BLOCK_TIME_SLACK < first_entry_ts:
            out["verdict"] = "before"
        elif r["time"] < first_entry_ts:
            out["verdict"] = "close"
            out["detail"] += ("; the block is earlier than the round's first entry (%s) by only %d seconds, less than the %d seconds a block's timestamp can be off, so the order is NOT established" %
                              (first_entry_ts, int(first_entry_ts - r["time"]), BLOCK_TIME_SLACK))
        else:
            out["verdict"] = "after"
            out["detail"] += "; but the round's first entry is logged at %s, which is NOT after it" % first_entry_ts
    elif status in ("pending", "mismatch", "invalid"):
        out.update(verdict=status, detail=r["detail"])
    else:
        out.update(verdict="unverified", detail=r["detail"])
    return out


def _write_new(path, data):
    with open(path, "xb") as f:                                                       # never overwrites
        f.write(data)


def _load(path):
    import json
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main(argv=None, http=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("stamp"); p.add_argument("announce"); p.add_argument("--out"); p.add_argument("--send", action="store_true")
    p = sub.add_parser("upgrade"); p.add_argument("proof"); p.add_argument("--out"); p.add_argument("--send", action="store_true")
    p = sub.add_parser("status"); p.add_argument("announce"); p.add_argument("proof"); p.add_argument("--base"); p.add_argument("--round"); p.add_argument("--online", action="store_true")
    a = ap.parse_args(argv)
    h = http or otsanchor.default_http
    try:
        if a.cmd == "stamp":
            doc = _load(a.announce)
            digest = digest_of(doc)
            out = a.out or a.announce + ".ots"
            if os.path.exists(out):
                print("REFUSED: %s already exists (nothing is overwritten)" % out)
                return 1
            if not a.send:
                print("DRY RUN. Would stamp the digest of %s (sha256 of its canonical JSON) with these calendars, sending only sha256(digest || a random nonce):\n  %s\nand write %s. %s Add --send to do it." %
                      (a.announce, "\n  ".join(otsanchor.CALENDARS), out, NOTHING_SENT))
                return 0
            proof, report = otsanchor.stamp(digest, http=h)
            _write_new(out, proof)
            for cal, err in report.items():
                print("  %-52s %s" % (cal, "accepted" if err is None else "FAILED: " + err))
            print("wrote %s (pending). The Bitcoin proof is not there yet: run `upgrade` in a few hours, then `status --online`. Do not let the round take entries before it is confirmed if you want to claim the plan predates them." % out)
        elif a.cmd == "upgrade":
            with open(a.proof, "rb") as f:
                data = f.read()
            if not a.send:
                print("DRY RUN. Would ask each calendar named in %s (only the known public ones) whether the Bitcoin proof is ready. %s Add --send to do it." % (a.proof, NOTHING_SENT))
                return 0
            new, notes = otsanchor.upgrade(data, http=h)
            for uri, note in notes.items():
                print("  %s: %s" % (uri, note))
            if new is None:
                print("nothing changed yet; try again later. %s unchanged." % a.proof)
                return 0
            out = a.out or a.proof + ".upgraded"
            _write_new(out, new)
            print("wrote %s; %s is untouched. Next: status --online." % (out, a.proof))
        else:
            with open(a.proof, "rb") as f:
                proof = f.read()
            doc = _load(a.announce)
            first = None
            if bool(a.round) != bool(a.base):
                print("REFUSED: --base and --round go together (they name the round whose first entry the anchor is compared with)")
                return 1
            if a.round:
                first = K.round_facts(a.base, a.round)["first_entry_ts"]
            r = anchor_status(doc, proof, first, a.online, h)
            print("%s%s: %s" % (r["verdict"].upper(), " (" + r["strength"] + ")" if r["strength"] else "", r["detail"]))
            if r["verdict"] == "before" and r["strength"] == "confirmed":
                print("The announcement was publicly anchored before the round's first logged entry, by a clock the operator does not control.")
            elif r["verdict"] == "before":
                print("Weaker: only one explorer was seen to confirm the block.")
            if not a.online:
                print("(offline: nothing was asked of Bitcoin or any explorer; add --online to check it.)")
            return 0 if r["verdict"] in ("before", "close", "after", "anchored", "pending") else 1
    except (otsanchor.OtsError, agent_core.AgentEvalError, K.KitError, OSError, ValueError, KeyError, TypeError) as e:
        print("error: %s: %s" % (type(e).__name__, e), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
