"""Pre-registration files: write one, and check later that the code it pins has not changed.

A pre-registration is only worth something if the pass criteria and the exact code were fixed BEFORE any data existed. Two were written
by hand with shell heredocs and checked with an ad-hoc loop; this makes both steps mechanical.

  prereg.py new   --out results/PREREGISTERED_x.txt --title "..." --family gm \\
                  --baseline solvers/baseline_bkz.py --submission solvers/tuned_bkz.py \\
                  --commitment HEX [--commitment HEX ...] --criteria "credit >= 1.0 bit ..." [--criteria-file F] \\
                  [--sandbox docker|local] [--jobs N] [--pin EXTRA_FILE ...] [--root DIR]
  prereg.py check FILE [--root DIR]      exit 0 if every pinned file still hashes as registered; 1 if any changed or is missing

What it records: the date (UTC), every seed commitment (public from this moment), the family and its ladder, the official n and CPU cap,
the sandbox mode, the two solvers, your criteria (required, verbatim), and the sha256 of every file that generates, runs, meters and
scores instances (rounds.CODE_FILES) plus both solvers. It refuses to overwrite an existing registration. It cannot judge whether your
criteria are sensible or unconditional; that is yours to write. Note: build_site.py lists only the FIRST commitment of a multi-seed file.
"""
import argparse
import hashlib
import os
import re
import sys
import time

import families
import rounds

HERE = os.path.dirname(os.path.abspath(__file__))
HASH_LINE = re.compile(r"^([0-9a-f]{64})  (\S.*)$")
COMMIT_RE = re.compile(r"^[0-9a-f]{64}$")


def sha256_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def inside_root(rel, root):
    """True only for a relative path that, after resolving symlinks, stays inside `root`. An absolute path, a `..` that climbs out, or a
    symlink pointing elsewhere would let a registration pin (and `check` hash) a file that is not part of the project."""
    if os.path.isabs(rel):
        return False
    real_root = os.path.realpath(root)
    real = os.path.realpath(os.path.join(root, rel))
    return real == real_root or real.startswith(real_root + os.sep)


def pinned_files(baseline, submission, extra=()):
    """The files a registration pins, relative to the root, in a stable order without duplicates."""
    out = []
    for rel in list(rounds.CODE_FILES) + [baseline, submission] + list(extra):
        if rel not in out:
            out.append(rel)
    return out


def render(title, family, baseline, submission, commitments, criteria, sandbox, jobs, files, root, now=None):
    cfg = families.OFFICIAL[family]
    stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now if now is not None else time.time()))
    title = " ".join(title.split())  # one line: a newline in the title would break the header and the date line after it
    lines = [f"PRE-REGISTRATION, {title}. Written BEFORE any data from these seeds exists.", f"date: {stamp}"]
    lines += [f"seed commitment (sha256): {c}" for c in commitments]
    lines += [f"config: family {family}, sizes {families.DEFAULT_DIMS[family]}, n={cfg['n']} per size, cap {cfg['budget']} s, "
              f"sandbox {sandbox}, jobs {jobs}.",
              f"baseline: {baseline}. submission: {submission}.", "",
              "UNCONDITIONAL criteria (written before any data; applied without reinterpretation):", criteria.strip(), "",
              "code hashes (sha256):"]
    lines += [f"{sha256_file(os.path.join(root, rel))}  {rel}" for rel in files]
    return "\n".join(lines) + "\n"


def parse(text):
    """{relative path: sha256} for every pinned file in a registration. Only the block after the LAST `code hashes` header counts: the
    criteria above it are free text, and a criteria line must not be able to open the hash block early and plant pins of its own."""
    lines = text.splitlines()
    starts = [i for i, line in enumerate(lines) if line.startswith("code hashes")]
    pins = {}
    for line in lines[starts[-1] + 1:] if starts else []:
        m = HASH_LINE.match(line)
        if m:
            pins[m.group(2)] = m.group(1)
    return pins


def check(path, root=HERE):
    """(ok, report lines). Every pinned file must exist and hash as registered."""
    with open(path, encoding="utf-8") as f:
        pins = parse(f.read())
    if not pins:
        return False, ["no code hashes found in this file: not a registration made by prereg.py"]
    report, ok = [], True
    for rel, want in pins.items():
        full = os.path.join(root, rel)
        if not inside_root(rel, root):  # never hash a file the registration points at outside the project
            ok = False
            report.append(f"REFUSED path outside the root: {rel}")
        elif not os.path.exists(full):
            ok = False
            report.append(f"MISSING {rel}")
        elif sha256_file(full) != want:
            ok = False
            report.append(f"CHANGED {rel}")
        else:
            report.append(f"same    {rel}")
    return ok, report


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("new")
    p.add_argument("--out", required=True)
    p.add_argument("--title", required=True)
    p.add_argument("--family", required=True, choices=sorted(families.FAMILIES))
    p.add_argument("--baseline", required=True)
    p.add_argument("--submission", required=True)
    p.add_argument("--commitment", action="append", required=True, help="a seed commitment (64 hex); repeat for several seeds")
    p.add_argument("--criteria", help="the unconditional pass criteria, in your words")
    p.add_argument("--criteria-file", help="read the criteria from a file instead")
    p.add_argument("--sandbox", choices=["docker", "local"], default="docker")
    p.add_argument("--jobs", type=int, default=1)
    p.add_argument("--pin", action="append", default=[], help="an extra file to pin (repeatable)")
    p.add_argument("--root", default=HERE, help="directory the pinned paths are relative to (default: the project)")
    p = sub.add_parser("check")
    p.add_argument("file")
    p.add_argument("--root", default=HERE)
    a = ap.parse_args(argv)
    if a.cmd == "check":
        try:
            ok, report = check(a.file, a.root)
        except OSError as e:
            print(f"cannot read {a.file}: {e}", file=sys.stderr)
            return 1
        print("\n".join(report))
        print("OK: every pinned file is unchanged" if ok else "FAILED: the code differs from what was registered")
        return 0 if ok else 1
    criteria = a.criteria
    if a.criteria_file:
        with open(a.criteria_file, encoding="utf-8") as f:
            criteria = f.read()
    if not (criteria or "").strip():
        print("REFUSED: criteria are required (--criteria or --criteria-file): a registration without them registers nothing", file=sys.stderr)
        return 1
    bad = [c for c in a.commitment if not COMMIT_RE.match(c)]
    if bad or len(set(a.commitment)) != len(a.commitment):
        print("REFUSED: commitments must be distinct 64-character lowercase hex sha256 values", file=sys.stderr)
        return 1
    if os.path.exists(a.out):
        print(f"REFUSED: {a.out} already exists; a registration is never overwritten (write a new one and mark the old one void)", file=sys.stderr)
        return 1
    files = pinned_files(a.baseline, a.submission, a.pin)
    escaping = [rel for rel in files if not inside_root(rel, a.root)]
    if escaping:
        print(f"REFUSED: pinned paths must be relative and stay inside the project root; outside the root: {escaping}", file=sys.stderr)
        return 1
    missing = [rel for rel in files if not os.path.exists(os.path.join(a.root, rel))]
    if missing:
        print(f"REFUSED: cannot pin files that do not exist: {missing}", file=sys.stderr)
        return 1
    not_files = [rel for rel in files if not os.path.isfile(os.path.join(a.root, rel))]
    if not_files:
        print(f"REFUSED: not a regular file: {not_files}", file=sys.stderr)
        return 1
    text = render(a.title, a.family, a.baseline, a.submission, a.commitment, criteria, a.sandbox, a.jobs, files, a.root)
    fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)  # exclusive: never overwrite, even in a race
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"wrote {a.out}: {len(a.commitment)} commitment(s), {len(files)} pinned file(s). Publish the commitments now; run nothing that "
          "changes a pinned file until the run is finished (`prereg.py check` verifies).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
