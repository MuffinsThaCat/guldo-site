"""aidist in the cluster-counted API, TECHNIQUE: data parallelism with a SEPARATE all-reduce per gradient tensor (the first layer's, then the second's) instead of one fused one. The same bytes, twice the messages: the latency-bound machine pays for it."""
import math

import tensorops as tp

C = 8


def ints(g):
    """g: a 1-D tensor on device 0 -> the answer's integers (units of 2^-40)."""
    return list(map(int, (g * 1099511627776.0).tolist()))


def local_grads(x, W1T, W2, Y, B):
    """The gradient pieces for the batch rows in x (the loss is averaged over the WHOLE batch B, so each piece is already scaled by 1/(B*C))."""
    a = x @ tp.transpose(W1T, (1, 0))
    h1 = tp.relu(a)
    dy = (h1 @ W2 - Y) * (1.0 / (B * C))
    dh = (dy @ tp.transpose(W2, (1, 0))) * (h1 / (tp.sqrt(a * a) + 1e-300))
    return tp.transpose(dh, (1, 0)) @ x, tp.transpose(h1, (1, 0)) @ dy


def flat(a, b):
    return tp.concat([tp.reshape(a, (a.shape[0] * a.shape[1],)), tp.reshape(b, (b.shape[0] * b.shape[1],))], 0)


def solve(seed, d, B, P):
    h = 4 * d
    shard = B // P
    out = []
    for r in range(P):
        tp.use(r)
        x = tp.reshape(tp.stream(seed, r * shard * d, shard * d), (shard, d))
        W1T = tp.reshape(tp.stream(seed, B * d, h * d), (h, d)) * math.sqrt(3.0 / d)
        W2 = tp.reshape(tp.stream(seed, B * d + h * d, h * C), (h, C)) * math.sqrt(3.0 / h)
        Y = tp.reshape(tp.stream(seed, B * d + h * d + h * C + r * shard * C, shard * C), (shard, C))
        out.append(local_grads(x, W1T, W2, Y, B))
    t1 = tp.all_reduce([g1 for (g1, g2) in out])
    t2 = tp.all_reduce([g2 for (g1, g2) in out])
    return ints(flat(t1[0], t2[0]))
