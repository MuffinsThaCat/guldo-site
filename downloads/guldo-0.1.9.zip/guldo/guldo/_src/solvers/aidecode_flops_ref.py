"""aidecode in the counted-operations API, REFERENCE: recompute the whole sequence for every generated token (no KV cache)."""
import math

import tensorops as tp

V, D, H, DH, FF, L, PROMPT = 64, 128, 4, 32, 512, 2, 8
W_SCALE, POS_SCALE = 4.0, 3.0


def take_param(off, seed, shape, scale):
    n = 1
    for s in shape:
        n *= s
    a = tp.stream(seed, off[0], n, shape) * scale
    off[0] += n
    return a


def build(seed, T):
    off = [0]
    sd = W_SCALE * math.sqrt(3.0 / D)
    sf = W_SCALE * math.sqrt(3.0 / FF)
    P = {"tok": take_param(off, seed, (V, D), math.sqrt(3.0)), "layers": []}
    for i in range(L):
        P["layers"].append({"Wq": take_param(off, seed, (D, D), sd), "Wk": take_param(off, seed, (D, D), sd), "Wv": take_param(off, seed, (D, D), sd),
                            "Wo": take_param(off, seed, (D, D), sd), "W1": take_param(off, seed, (D, FF), sd), "W2": take_param(off, seed, (FF, D), sf)})
    P["pos"] = take_param(off, seed, (PROMPT + T, D), POS_SCALE * math.sqrt(3.0))
    u = tp.stream(seed, off[0], PROMPT).tolist()
    P["prompt"] = [min(int((x + 1.0) * 0.5 * V), V - 1) for x in u]
    return P


def rms(x):
    return x / tp.sqrt(tp.mean(x * x, -1, True) + 1e-6)


def softmax_rows(s):
    s = s - tp.max(s, -1, True)
    a = tp.exp(s)
    return a / tp.sum(a, -1, True)


def forward_last(P, toks):
    n = len(toks)
    x = tp.take(P["tok"], toks) + P["pos"][0:n]
    mask = tp.causal_mask(n)
    for l in P["layers"]:
        h = rms(x)
        q = tp.transpose(tp.reshape(h @ l["Wq"], (n, H, DH)), (1, 0, 2))
        k = tp.transpose(tp.reshape(h @ l["Wk"], (n, H, DH)), (1, 0, 2))
        v = tp.transpose(tp.reshape(h @ l["Wv"], (n, H, DH)), (1, 0, 2))
        a = softmax_rows((q @ tp.transpose(k, (0, 2, 1))) / math.sqrt(DH) + mask)
        o = tp.reshape(tp.transpose(a @ v, (1, 0, 2)), (n, D))
        x = x + o @ l["Wo"]
        x = x + tp.relu(rms(x) @ l["W1"]) @ l["W2"]
    return rms(x[n - 1]) @ tp.transpose(P["tok"], (1, 0))


def solve(seed, prompt_len, T):
    P = build(seed, T)
    seq = list(P["prompt"])
    for step in range(T):
        seq.append(tp.argmax(forward_last(P, seq)))
    return seq[PROMPT:]
