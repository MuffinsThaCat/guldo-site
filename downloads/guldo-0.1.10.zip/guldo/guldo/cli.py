"""The `guldo` command: the client, and `guldo <tool>` for the other tools. See `guldo tools`."""
import importlib
import inspect
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "_src")
TOOLS = {
    "claims": ("claims", "benchmark score, worst case, verified negative result or a comparison of two solvers from verified certificates; `claims check` recomputes a claim file"),
    "counted": ("counted", "step counting: `counted check SOLVER --family F --dim D` (is it deterministic and inside the restricted subset?), `counted evaluate`"),
    "tflops": ("tflops", "exact operation counts for AI workloads (inference, training): `tflops practice SOLVER --baseline REF --family aitrain --dims 32 40 48`, `tflops claim`, `tflops verify`"),
    "gpu-roofline": ("gpu_roofline", "does the roofline model predict real kernel times on THIS device? `gpu-roofline calibrate --out F.json` (needs PyTorch; any GPU or the CPU), `check F.json`, `agree A.json B.json`"),
    "tflops-mem": ("tflops_mem", "like tflops, and also exact bytes moved, precision (fp32/fp16 casts) and peak memory per instance: `tflops-mem practice SOLVER --baseline REF --family aitrain --dims 32 40 48`"),
    "tflops-mem2": ("tflops_mem2", "version 2 of tflops-mem: the same exact bytes, precision and peak memory, plus an int8 format (`tp.cast(x, 'int8', axis)`, one scale per index of the axis): `tflops-mem2 practice SOLVER --baseline REF --family aiintquant --dims 64 128 192`; compare with `tflops-compare --metric bytes`. Version-1 ladders are unchanged and not comparable"),
    "tflops-mem3": ("tflops_mem3", "version 3 of tflops-mem: the same exact bytes, precision and peak memory, plus int8, bf16, fp8 (e4m3, e5m2) and a sparse matrix product `tp.spmm(A, B, 'csr' | '2:4')` whose cost follows the nonzeros: `tflops-mem3 practice SOLVER --baseline REF --family aimixed --dims 16 32 48`; compare with `tflops-compare --metric bytes`"),
    "tflops-par": ("tflops_par", "like tflops, and also the exact DEPTH (critical path) of the tensor operations, for parallelism: `tflops-par practice SOLVER --baseline REF --family aipar --dims 64 128 256`; compare with `tflops-compare --metric span`"),
    "tflops-dist": ("tflops_dist", "like tflops, for a simulated CLUSTER: exact critical-path work, message rounds and bytes per device, so a run's time on ANY interconnect is exact: `tflops-dist practice SOLVER --baseline REF --family aidist --dims 16 24 32`; compare with `tflops-compare --metric time`"),
    "gpu-bench": ("gpu_bench", "time GPU solvers on whatever PyTorch device you have (CUDA, Apple MPS or CPU), parent-timed, answers judged outside the timed interval: `gpu-bench devices`, `gpu-bench run --family aigpu ...`, `gpu-bench check F.json`"),
    "tflops-compare": ("tflops_compare", "compare two solvers with each other on counted ladders, instance by instance: `tflops-compare compare BASELINE A B`; `tflops-compare check` recomputes the file"),
    "agent": ("agent_eval", "verifiable AI-AGENT evaluation: `agent domains`, `agent plan`, `agent run`, `agent verify LADDER --seed S`, `agent compare`, `agent check`, `agent claim`; see AGENT_EVAL.md and OUTSIDE_VERIFIER.md"),
    "agent-tools": ("agent_tools", "agent-evaluation extras: stratified bounds, attestation receipts, independent witnesses, GPU tiers, bounty ledger, certificate index, safety register, insurer and regulatory reports"),
    "agent-power": ("agent_power", "the POWER PASS for agent claims: how many instances and trials a claim needs, and the money, before any spend: `agent-power success-diff --p-base 0.6 --p-cand 0.85`, `agent-power cost-uplift --mean-bits 1.5 --sd-bits 1 --factor 2`, `agent-power pilot BASE CAND`"),
    "agent-rounds": ("agent_rounds", "commit-reveal agent ROUNDS on a hash-chained log: `agent-rounds create|enter|close|evaluate|reveal|result|verify|export`; entrants submit agent configurations, the operator evaluates, anyone verifies from the files"),
    "agent-cert": ("agent_cert", "agent-evaluation CERTIFICATES whose statement is generated from the data and re-derived by the verifier: `agent-cert build|verify|show`"),
    "agent-power": ("agent_power", "the power pass for agent evaluations, BEFORE any money is spent: how many instances and trials a claim needs and what a run costs: `agent-power solve-rate|success-diff|cost-uplift|pilot|budget|trials`"),
    "agent-rounds": ("agent_rounds", "commit-reveal ROUNDS for agent evaluation (create, enter, close, evaluate, reveal, result, verify, head-check) on a hash-chained log; `--sign-key K` publishes a signed head at each stage"),
    "agent-cert": ("agent_cert", "agent-evaluation CERTIFICATES: one document that states a result and that anyone can re-derive from the published ladders and the revealed seed"),
    "announce-anchor": ("announce_anchor", "an OUTSIDE clock for a round announcement, no person needed: `stamp` (OpenTimestamps/Bitcoin; sends nothing without --send), `upgrade`, `status` (what the proof shows, and whether it predates the round's first entry)"),
    "agent-calibrate": ("agent_calibrate", "fit the token calibration (billed vs proxy tokens) for ANY model from real, verified ladders: `fit` (changes nothing) and `write` (gated; recorded in agent_calibration.json, which `preflight` reads)"),
    "agent-witness-kit": ("agent_witness_kit", "OPTIONAL: get an outside witness for a round quickly: `announce` (before the run), `build` (a self-contained kit after the reveal), `witness` (the outsider's one command), `check` (anyone, recomputed)"),
    "agent-log": ("agent_log", "the public, append-only, witnessed LOG of agent certificates: `agent-log add` (only certificates that recompute from their round), `checkpoint`, `prove`, `verify-proof`, `check --remember`, `cosign`"),
    "agent-sandbox": ("agent_sandbox", "where agent-written code runs for the coding and bugfix domains: `agent-sandbox preflight`, `agent-sandbox selftest` (a hostile probe through the active backend); GULDO_SANDBOX=docker runs it in a locked-down container (never run against a real daemon yet)"),
    "agent-site": ("agent_site", "render the agent-evaluation site card (one static, script-free page generated from the live domain registry): `agent-site --out agent.html`"),
    "agent-proxy": ("agent_proxy", "the recording proxy for real model APIs, run by the VERIFIER: `agent-proxy serve --key K --log L` signs a receipt per model call; `agent-proxy verify LADDER LOG --trusted KEYS --seed S` checks a ladder against it"),
    "progress": ("progress_tracker", "the cross-problem record of verified progress and baseline-cost hardness evidence: `progress scan certs/ --md PROGRESS.md`"),
    "attest": ("attest", "sign and check independent attestations of a certificate"),
    "cert": ("certificate", "build and verify certificates (the standalone verifier). Not `guldo certificate`: that is the client's own command, which downloads one"),
    "compile": ("compile_domain", "declare a new problem and compile it into a challenge"),
    "kinds": ("compile_kinds", "run a non-speed declaration (KIND advantage / oracle / precomp / quantum): `kinds evaluate|score|compare|replay`; declare one with `compile init NAME --kind K`"),
    "intake": ("intake", "propose a problem to an operator (`intake pack`); for operators: receive, trial, accept or reject a proposal (set SVP_INTAKE_DIR first)"),
    "export": ("export_bundle", "export a compiled challenge as a platform-neutral bundle (checker, scorer, power analysis); `export verify DIR` re-checks one"),
    "ops": ("ops", "operator tools: create, close, evaluate, reveal, export rounds"),
    "lint": ("submit_check", "pre-flight check of a solver file"),
    "judge": ("judge", "the judge (seeds, evaluate, leaderboard)"),
    "log": ("translog", "the public certificate log: `log check --log URL`, `log prove`, `log verify-inclusion`, `log witness` (needs the [attest] extra for signatures)"),
    "runattest": ("runattest", "the sandbox operator's run attestation: `runattest make CERT --results DIR --key K` signs only if the operator's own records ARE the certificate's ladders; `runattest check`"),
}


def _version():
    from importlib.metadata import version
    for dist in ("guldo-cli", "guldo"):
        try:
            return version(dist)
        except Exception:
            continue
    return "unknown"


class _Hints:
    """Tools print follow-up commands as `python3 NAME.py ...`, which does not exist for someone who installed the package: say `guldo TOOL ...` instead. A text rewrite of
    the output only; the tool itself is untouched (some are pinned by hash in pre-registrations). Lines are written whole, so progress still streams."""
    def __init__(self, out):
        self.out = out
        self.names = {mod: name for name, (mod, _) in TOOLS.items()}

    def write(self, s):
        import re
        return self.out.write(re.sub(r"python3 (\w+)\.py ", lambda m: f"guldo {self.names[m.group(1)]} " if m.group(1) in self.names else m.group(0), s))

    def __getattr__(self, name):
        return getattr(self.out, name)


def _call(module, rest, prog):
    fn = importlib.import_module(module).main
    sys.argv = [prog] + rest
    try:
        takes_argv = bool(inspect.signature(fn).parameters)
    except (TypeError, ValueError):
        takes_argv = False
    real = sys.stdout
    sys.stdout = _Hints(real)
    try:
        return fn(rest) if takes_argv else fn()
    finally:
        sys.stdout = real


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if SRC not in sys.path:
        sys.path.insert(0, SRC)   # our modules first: a flat name like `judge` or `harness` must never resolve to something else installed
    if argv[:1] in (["--version"], ["-V"]):
        print(f"guldo {_version()}")
        return 0
    if argv[:1] == ["tools"]:
        print("guldo <tool> ...   (guldo --help shows the client's own commands)\n")
        for name, (_, what) in sorted(TOOLS.items()):
            print(f"  guldo {name:12s} {what}")
        return 0
    if argv and argv[0] in TOOLS:
        return _call(TOOLS[argv[0]][0], argv[1:], f"guldo {argv[0]}")
    import svp   # the client module keeps its file name; only the command a person types is `guldo`
    svp.PROG = "guldo"
    return svp.main(argv)


if __name__ == "__main__":
    sys.exit(main())
