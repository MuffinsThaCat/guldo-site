"""aipipe in the cluster-counted API, CHEAT: a pipeline (4 microbatches, one layer per device, one tp.exchange hand-off per step, exactly as aipipe_dist_gpipe4.py) in which the LAST stage skips its layer and passes its input through. It does less work and is not the network: the judge must reject it."""
import math

import tensorops as tp

M = 4


def solve(seed, d, B, P):
    mb = B // M
    W = []
    for s in range(P):
        tp.use(s)
        W.append(tp.reshape(tp.stream(seed, B * d + s * d * d, d * d), (d, d)) * math.sqrt(6.0 / d))
    inbox = {}
    outs = []
    for t in range(M + P - 1):
        res = {}
        for s in range(P):
            j = t - s
            if 0 <= j < M:
                tp.use(s)
                x = tp.reshape(tp.stream(seed, j * mb * d, mb * d), (mb, d)) if s == 0 else inbox[s]
                res[s] = tp.relu(x @ W[s]) if s < P - 1 else x
        sends = [(res[s], s + 1) for s in sorted(res) if s < P - 1]
        if sends:
            got = tp.exchange(sends)
            for (src, dst), r in zip([(s, s + 1) for s in sorted(res) if s < P - 1], got):
                inbox[dst] = r
        if P - 1 in res:
            outs.append(res[P - 1])
    return list(map(int, (tp.reshape(tp.concat(outs, 0), (B * d,)) * 1073741824.0).tolist()))
