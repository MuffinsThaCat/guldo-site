"""The agent harness: the trust boundary between an agent and a derived task.

An agent is any object with respond(system, tools, messages) -> {"text": str, "tool_calls": [{"name": str, "args": dict}], "usage": {"input_tokens": int, "output_tokens": int} (optional)}.
It may also have begin(instance_id, trial). The harness gives it ONLY the public prompt and the tools: the hidden part of an instance (private) never leaves this module's
process boundary into any message, and the agent cannot reach the verifier. For every turn the harness computes the PROXY token counts itself from the exact text it sends and
receives (agent_core.count_tokens), enforces the caps (tokens, tool calls, turns, wall time), executes tool calls against a fresh environment, and records the whole trajectory as
a hash chain. A provider's own usage numbers are stored beside the proxy counts, never instead of them.

check_trial() is the other half: from a stored record alone it re-derives the instance from the seed, re-verifies the final answer with the domain's exact verifier, replays every
tool call on a fresh environment and compares each recorded result, recomputes every proxy token count from the stored context, and checks the hash chain. An LLM agent cannot be
re-run to the same trajectory; this checks that what was recorded is internally true and that the recorded output is correct, which is all that non-determinism allows.
"""
import re
import threading
import time

import agent_core
from agent_core import canon, count_tokens

SYSTEM = ("You are an agent solving one task. Use the provided tools to find what you need. When you have the final answer, call the `submit` tool with it. "
          "Every call and every message costs; be efficient and correct.")
SUBMIT_SPEC = {"name": "submit", "description": "Submit the final answer and end the task.", "input_schema": {"type": "object", "properties": {"answer": {}}, "required": ["answer"]}}
MAX_TOOL_OUTPUT = 20000
DEFAULT_BUDGET = {"max_tokens": 80000, "max_tool_calls": 40, "max_turns": 30, "max_wall_s": 600, "max_nudges": 0}
# A real model sometimes writes "submit 50.04" in prose instead of calling the tool (seen on the first real run). With max_nudges > 0 the harness answers a reply that has no tool call with this ONE
# fixed reminder instead of ending the trial, up to that many times per trial. It is in the PLAN (so both arms of a comparison get the same), costs tokens like any other turn, and the verifier
# knows it: a nudge the harness would not have sent, or a trajectory that ends with one still available, is flagged.
NUDGE = "You did not call a tool. If you have the final answer, call the `submit` tool with it now; otherwise call the tool you need next."


def effective_tools(mod, instance, allow_tools=None):
    specs = list(mod.tool_specs(instance["public"]))
    if allow_tools is not None:
        specs = [s for s in specs if s["name"] in allow_tools]
    return specs + [SUBMIT_SPEC]


def wire(turn):
    """The part of a stored turn that was sent to / received from the model: what the proxy token count is computed over."""
    role = turn["role"]
    if role == "user":
        return {"role": "user", "content": turn["content"]}
    if role == "assistant":
        return {"role": "assistant", "text": turn["text"], "tool_calls": turn["tool_calls"]}
    if role == "tool":
        return {"role": "tool", "results": [{"id": r["id"], "name": r["name"], "content": r["content"]} for r in turn["results"]]}
    raise agent_core.AgentEvalError("unknown turn role %r" % role)


def context_tokens(system, tools, turns_before):
    return count_tokens(canon([system, tools, [wire(t) for t in turns_before]]))


def output_tokens(text, tool_calls):
    return count_tokens(text + canon(tool_calls))


def _clean_reply(reply):
    if not isinstance(reply, dict):
        raise ValueError("reply is not an object")
    text = reply.get("text", "")
    calls = reply.get("tool_calls", [])
    if not isinstance(text, str) or not isinstance(calls, list):
        raise ValueError("text must be a string and tool_calls a list")
    out = []
    for i, c in enumerate(calls):
        if not isinstance(c, dict) or not isinstance(c.get("name"), str) or not isinstance(c.get("args", {}), dict):
            raise ValueError("a tool call needs a string name and an object args")
        out.append({"id": "c%d" % i, "name": c["name"], "args": c.get("args", {})})
    canon(out)
    usage = reply.get("usage")
    if usage is not None and not (isinstance(usage, dict) and isinstance(usage.get("input_tokens"), int) and isinstance(usage.get("output_tokens"), int)):
        usage = None
    return text, out, usage


class _WallTimeout(Exception):
    pass


def _respond_within(agent, args, seconds):
    """agent.respond(*args), abandoned after `seconds`. The call runs in a daemon thread: Python cannot kill a thread, so a hung call keeps running in the background until it returns
    or the process ends, but the trial moves on and ends as over the wall-time budget. (The Anthropic adapter also has its own per-request timeout, so it does not hang for long.)"""
    box = {}

    def work():
        try:
            box["r"] = agent.respond(*args)
        except BaseException as e:
            box["e"] = e
    th = threading.Thread(target=work, daemon=True)
    th.start()
    th.join(max(seconds, 0.0))
    if th.is_alive():
        raise _WallTimeout()
    if "e" in box:
        raise box["e"]
    return box["r"]


def run_trial(agent, mod, instance, budget=None, trial=0, allow_tools=None, system=SYSTEM):
    """Run one trial. Returns the record (a plain dict). Never raises for agent misbehaviour: that is a failed trial with a reason."""
    budget = dict(DEFAULT_BUDGET, **(budget or {}))
    tools = effective_tools(mod, instance, allow_tools)
    allowed = set(s["name"] for s in tools)
    env = mod.make_env(instance)
    turns = [{"role": "user", "content": mod.prompt(instance["public"])}]
    if hasattr(agent, "begin"):
        agent.begin(instance["id"], trial)
    t0 = time.monotonic()
    tokens = n_calls = n_turns = n_nudges = 0
    error_note = None
    provider = [0, 0]
    provider_ok = True
    answer, reason, submitted = None, None, False
    while reason is None:
        if n_turns >= budget["max_turns"]:
            reason = "over turn budget"
            break
        if time.monotonic() - t0 > budget["max_wall_s"]:
            reason = "over wall-time budget"
            break
        proxy_in = context_tokens(system, tools, turns)
        try:
            text, calls, usage = _clean_reply(_respond_within(agent, (system, tools, [wire(t) for t in turns]), budget["max_wall_s"] - (time.monotonic() - t0)))
        except _WallTimeout:
            reason = "over wall-time budget"
            break
        except Exception as e:
            reason = "agent error: %s" % type(e).__name__
            error_note = str(e)[:300]                  # informational only (not verified): without it a real run's HTTP 400 was a mystery that took a replay to find
            break
        n_turns += 1
        proxy_out = output_tokens(text, calls)
        tokens += proxy_in + proxy_out
        if usage is None:
            provider_ok = False
        else:
            provider[0] += usage["input_tokens"]
            provider[1] += usage["output_tokens"]
        turn = {"role": "assistant", "text": text, "tool_calls": calls, "proxy_in": proxy_in, "proxy_out": proxy_out}
        if usage is not None:
            turn["usage"] = usage
        turns.append(turn)
        if tokens > budget["max_tokens"]:
            reason = "over token budget"
            break
        if not calls:
            if n_nudges < budget["max_nudges"]:
                n_nudges += 1
                turns.append({"role": "user", "content": NUDGE})
                continue
            reason = "no submit"
            break
        results = []
        for c in calls:
            if c["name"] == "submit":
                if "answer" not in c["args"]:
                    results.append({"id": c["id"], "name": "submit", "args": c["args"], "content": "error: submit needs an answer"})
                    continue
                answer, submitted = c["args"]["answer"], True
                break
            if n_calls >= budget["max_tool_calls"]:
                reason = "over tool-call budget"
                break
            n_calls += 1
            if c["name"] not in allowed:
                content = "error: tool %r is not available" % c["name"]
            else:
                try:
                    content = str(env.call(c["name"], c["args"]))
                except Exception as e:
                    content = "error: tool failed (%s)" % type(e).__name__
            if len(content) > MAX_TOOL_OUTPUT:
                content = content[:MAX_TOOL_OUTPUT] + "...(truncated)"
            results.append({"id": c["id"], "name": c["name"], "args": c["args"], "content": content})
        if results:
            turns.append({"role": "tool", "results": results})
        if submitted:
            break
    solved, vreason = False, reason
    domain_tools = allowed - {"submit"}
    calls_done = [{"name": r["name"], "args": r["args"]} for t in turns if t["role"] == "tool" for r in t["results"] if r["name"] in domain_tools]
    if submitted:
        try:
            canon(answer)
            solved, vreason = mod.verify(instance, answer, calls_done)
        except (TypeError, ValueError):
            solved, vreason = False, "answer is not JSON data"
    elif reason is None:
        vreason = "no submit"
    chained, head = agent_core.chain_turns(turns)
    out_rec = {"instance": instance["id"], "domain": mod.NAME, "size": instance["size"], "idx": int(instance["id"].rsplit("/", 1)[1]), "trial": trial,
            "solved": bool(solved), "reason": vreason, "answer": answer if submitted else None, "turns": chained, "head": head,
            "tokens": tokens, "tool_calls": n_calls, "n_turns": n_turns, "wall_s": round(time.monotonic() - t0, 3),
            "provider_tokens": (provider[0] + provider[1]) if provider_ok and n_turns else None}
    if error_note is not None:
        out_rec["agent_error"] = error_note
    return out_rec


def check_trial(rec, mod, master, header, replay_tools=True):
    """Re-check one stored trial from the record alone. Returns a list of problems (empty = consistent and correct as recorded)."""
    probs = []
    try:
        size, idx = int(rec["size"]), int(rec["idx"])
        instance = agent_core.make_instance(mod, master, size, idx)
    except Exception as e:
        return ["cannot re-derive the instance: %s" % type(e).__name__]
    if rec.get("instance") != instance["id"] or rec.get("domain") != mod.NAME:
        probs.append("instance id does not match the seed-derived instance")
    for key, typ in (("reason", str), ("solved", bool), ("tokens", int), ("tool_calls", int), ("n_turns", int), ("trial", int)):
        if not isinstance(rec.get(key), typ) or (typ is int and isinstance(rec.get(key), bool)):
            probs.append("field %r is missing or not a %s" % (key, typ.__name__))
    turns = rec.get("turns")
    if not isinstance(turns, list) or not turns:
        return probs + ["no turns"]
    ok, head = agent_core.check_chain(turns)
    if not ok:
        return probs + ["hash chain broken"]
    if head != rec.get("head"):
        probs.append("chain head differs from the record's head")
    if turns[0].get("role") != "user" or turns[0].get("content") != mod.prompt(instance["public"]):
        probs.append("first turn is not the task prompt derived from the seed")
    tools = effective_tools(mod, instance, header.get("allow_tools"))
    allowed = set(s["name"] for s in tools)
    system = header.get("system", SYSTEM)
    tokens = 0
    for i, t in enumerate(turns):
        if t.get("role") == "assistant":
            pi = context_tokens(system, tools, turns[:i])
            po = output_tokens(t.get("text", ""), t.get("tool_calls", []))
            if t.get("proxy_in") != pi or t.get("proxy_out") != po:
                probs.append("turn %d: proxy token counts do not match its context (%s/%s recorded, %d/%d recomputed)" % (i, t.get("proxy_in"), t.get("proxy_out"), pi, po))
            tokens += pi + po
    c_tokens, c_calls, c_turns = agent_core.cost_from_turns(turns)
    if (rec.get("tokens"), rec.get("n_turns")) != (tokens, c_turns) or c_tokens != tokens:
        probs.append("recorded cost does not match the trajectory")
    domain_tools = allowed - {"submit"}
    calls = [{"name": r["name"], "args": r["args"]} for t in turns if t.get("role") == "tool" for r in t["results"] if r["name"] in domain_tools]
    charged = sum(1 for t in turns if t.get("role") == "tool" for r in t["results"] if r["name"] != "submit")
    if rec.get("tool_calls") != charged:
        probs.append("recorded tool-call count does not match the trajectory")
    if replay_tools:
        env = mod.make_env(instance)
        for t in turns:
            if t.get("role") == "tool":
                for r in t["results"]:
                    if r["name"] in domain_tools:
                        got = str(env.call(r["name"], r["args"]))
                        got = got[:MAX_TOOL_OUTPUT] + "...(truncated)" if len(got) > MAX_TOOL_OUTPUT else got
                        if got != r["content"]:
                            probs.append("a tool result differs when the call is replayed")
                            break
    expect, submitted = _replay_control_flow(turns, header, domain_tools, probs)
    if probs and any(p.startswith("trajectory:") for p in probs):
        return probs
    if submitted is not NO_SUBMIT:
        if rec.get("answer") != submitted:
            probs.append("the recorded answer differs from the submitted one")
        else:
            good, why = mod.verify(instance, submitted, calls)
            if bool(rec.get("solved")) != bool(good):
                probs.append("recorded %s but the verifier says %s (%s)" % ("solved" if rec.get("solved") else "unsolved", "solved" if good else "unsolved", why))
            elif rec.get("reason") != why:
                probs.append("the recorded reason %r is not the verifier's %r" % (rec.get("reason"), why))
    else:
        if rec.get("answer") is not None or rec.get("solved"):
            probs.append("recorded an answer or a success for a trajectory that never submitted one")
        r = rec.get("reason")
        if expect == UNVERIFIABLE:
            if not (isinstance(r, str) and (re.fullmatch(r"agent error: [A-Za-z_][A-Za-z0-9_]*", r) or r == "over wall-time budget")):
                probs.append("the trajectory ended with no submit and no budget reached, but the recorded reason is %r" % (r,))
        elif r != expect:
            probs.append("the trajectory ends with %r but the recorded reason is %r" % (expect, r))
    return probs


NO_SUBMIT = object()
UNVERIFIABLE = "ended for a reason the stored turns cannot show (wall time or an agent error)"


def _replay_control_flow(turns, header, domain_tools, probs):
    """Re-simulate run_trial's loop over the stored turns. Appends 'trajectory: ...' problems for anything run_trial could not have produced (turns after the end, a turn past a cap,
    a missing or extra tool turn, tool results that are not the calls made). Returns (why it ended, the submitted answer or NO_SUBMIT)."""
    budget = dict(DEFAULT_BUDGET, **(header.get("budget") or {}))
    tokens = n_calls = n_turns = nudges = 0
    i = 1
    n = len(turns)

    def bad(msg):
        probs.append("trajectory: " + msg)
        return None, NO_SUBMIT
    while i < n:
        t = turns[i]
        if t.get("role") != "assistant":
            return bad("turn %d should be an assistant turn" % i)
        if n_turns >= budget["max_turns"]:
            return bad("turn %d is past the turn cap" % i)
        n_turns += 1
        tokens += int(t.get("proxy_in", 0)) + int(t.get("proxy_out", 0))
        i += 1
        if tokens > budget["max_tokens"]:
            return ("over token budget", NO_SUBMIT) if i == n else bad("turns follow the one that crossed the token cap")
        calls = t.get("tool_calls", [])
        if not calls:
            if i < n and turns[i].get("role") == "user":
                if turns[i].get("content") != NUDGE or nudges >= budget["max_nudges"]:
                    return bad("a user turn follows turn %d that the harness would not have sent" % (i - 1))
                nudges += 1
                i += 1
                continue
            if i == n:
                if nudges < budget["max_nudges"]:
                    return bad("the trajectory ends after a turn with no tool call although a nudge was still available")
                return ("no submit", NO_SUBMIT)
            return bad("turns follow a turn with no tool call")
        expected, ended, answer = [], None, NO_SUBMIT
        for c in calls:
            if c["name"] == "submit":
                if "answer" not in c["args"]:
                    expected.append((c["id"], "submit", c["args"]))
                    continue
                ended, answer = "submit", c["args"]["answer"]
                break
            if n_calls >= budget["max_tool_calls"]:
                ended = "over tool-call budget"
                break
            n_calls += 1
            expected.append((c["id"], c["name"], c["args"]))
        has_tool_turn = i < n and turns[i].get("role") == "tool"
        if expected:
            if not has_tool_turn:
                return bad("the tool results after turn %d are missing" % (i - 1))
            got = [(r.get("id"), r.get("name"), r.get("args")) for r in turns[i]["results"]]
            if got != expected:
                return bad("the tool results after turn %d are not the calls that were made" % (i - 1))
            i += 1
        elif has_tool_turn:
            return bad("an unexpected tool turn after turn %d" % (i - 1))
        if ended == "submit":
            return (None, answer) if i == n else bad("turns follow the submit")
        if ended == "over tool-call budget":
            return (ended, NO_SUBMIT) if i == n else bad("turns follow the tool-call cap")
    return ("over turn budget", NO_SUBMIT) if n_turns >= budget["max_turns"] else (UNVERIFIABLE, NO_SUBMIT)
