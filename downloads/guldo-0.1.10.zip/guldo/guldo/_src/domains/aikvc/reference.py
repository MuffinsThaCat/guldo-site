"""Reference for aikvc: the full float64 cache, read in full at every step.

The model definition (the contract a submission must reproduce): SplitMix64 counter stream under `seed`, element k = finalise((k+1)*GOLD + seed), mapped to [-1, 1) as
(z >> 11) * 2^-52 - 1. Stream layout, in order, row-major: Zk (n x 4, scale 1), Zv (n x 4, scale 1), Bk (4 x 32, scale 2 * 3/sqrt(4)), Bv (4 x 32, scale 3/sqrt(4)), base (64 x 32, scale 2).
K = Zk Bk, V = Zv Bv. Step t: q = base[t] + 4 o[t-1] (o[-1] = 0), o[t] = softmax(K q / sqrt(32)) V. The answer is the 64 outputs, flat, as integers in units of 2^-16.
"""
import math

import numpy as np

_D, _R, _S = 32, 4, 64


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, n):
    o = 0

    def take(shape, scale):
        nonlocal o
        m = int(np.prod(shape))
        a = (_uniform(seed, o, m) * scale).reshape(shape)
        o += m
        return a
    Zk, Zv = take((n, _R), 1.0), take((n, _R), 1.0)
    Bk, Bv = take((_R, _D), 2.0 * 3.0 / math.sqrt(_R)), take((_R, _D), 3.0 / math.sqrt(_R))
    base = take((_S, _D), 2.0)
    K, V = Zk @ Bk, Zv @ Bv
    prev, out = np.zeros(_D), []
    for t in range(_S):
        s = K @ (base[t] + 4.0 * prev) / math.sqrt(_D)
        a = np.exp(s - s.max())
        prev = (a / a.sum()) @ V
        out.append(prev)
    return [int(v) for v in np.rint(np.array(out) * 65536.0).ravel()]
