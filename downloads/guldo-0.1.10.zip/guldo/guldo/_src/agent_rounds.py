"""Commit-reveal ROUNDS for agent evaluation: the lifecycle the speed protocol has (create, enter, close, evaluate, reveal, result, verify) on the same hash-chained log.

  create    fix the plan (instances, trials, caps) and the seed COMMITMENT; pin the code; write log entry 0. The seed is read to compute the commitment and is NOT stored.
  enter     an entrant submits an agent CONFIGURATION (model spec, label, allowed tools, system prompt): not code. Hashed into the log. Open until the close time.
  close     no more entries.
  evaluate  the operator, who holds the seed, runs the baseline and every entry on the SAME planned instances through the harness; each ladder is written whole and its hashes logged.
  reveal    the seed is published (its hash matches the commitment in entry 0).
  result    anyone with the revealed seed re-verifies every ladder and recomputes every comparison against the baseline.
  verify    the whole round from the published files alone: log chain, pins, entries, ladders, seed, results.

WHY the operator evaluates: with a secret seed the entrants cannot see the instances, so they cannot run the test themselves. That is the commit-reveal point (no judged instance can have
been seen) and also its cost: the operator spends the API money and is trusted to have run each configuration as submitted. The attested-receipt path (agent_attest.py) is what removes
that trust; this module does not require it and does not claim it.

Entries are CONFIGURATIONS, so no entrant's code ever runs here; the code that runs is the harness, the domain and, for the coding domain, the code the MODEL writes (see the coding
domain's security note: a real coding round needs the operator to have isolated the seed from that code).

The code files are pinned in log entry 0: editing any of them after `create` blocks evaluation and verification by design (it would change what the round means). Layout:
base/agent-rounds/<id>/{round.json, plan.json, log.jsonl, entries/, ladders/, results.json, seed.revealed}.
"""
import datetime
import hashlib
import json
import os
import re
import sys
import time

import agent_compare
import agent_core
import agent_eval
import agent_harness
import agent_providers
import rounds as R
from agent_core import canon, sha256_hex

ROOT = "agent-rounds"
STATES = ("open", "closed", "evaluated", "revealed")
MAX_PER_HANDLE = 3
MAX_ENTRIES = 60
MAX_SYSTEM = 20000
LABEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,39}$")
MODEL_RE = re.compile(r"^[a-z0-9][a-z0-9.\-]{1,60}$")
EID_RE = re.compile(r"^(baseline|e[0-9]{3})$")
HERE = os.path.dirname(os.path.abspath(__file__))
CODE = ("agent_core.py", "agent_harness.py", "agent_compare.py", "agent_strata.py", "agent_providers.py", "agent_eval.py", "agent_rounds.py")


class Rejected(R.Rejected):
    pass


# ---- small helpers -------------------------------------------------------------------------------------------------------------------------------

def rdir(base, rid):
    if not R.ROUND_ID_RE.match(rid or ""):
        raise Rejected("a round id is 2-41 characters: lower-case letters, digits and hyphens")
    return os.path.join(base, ROOT, rid)


def _require(base, rid):
    d = rdir(base, rid)
    if not os.path.exists(os.path.join(d, "round.json")):
        raise Rejected("no such round: %s" % rid)
    return d


def _lock(d):
    return R.locked(os.path.join(d, "lock"))


def get_round(base, rid):
    return R._read_json(os.path.join(_require(base, rid), "round.json"))


def _parse_time(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        pass
    try:
        return datetime.datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
    except ValueError:
        raise Rejected("a time must be epoch seconds or ISO like 2027-01-10T23:59:00Z")


def _file_sha(path):
    return agent_core.file_sha256(path)


def code_hashes():
    return {rel: (_file_sha(os.path.join(HERE, rel)) if os.path.exists(os.path.join(HERE, rel)) else None) for rel in CODE}


def config_sha(config):
    return sha256_hex(canon(config))


def _set_state(d, r, state, now, kind, data):
    r["state"] = state
    R._write_json(os.path.join(d, "round.json"), r)
    return R.append_log(d, kind, data, now)


def validate_spec(spec):
    """An agent spec an entrant may submit: scripted:lean|bare|cheat|gullible[:P] or anthropic:MODEL[:EFFORT]. Checked without building the agent (a model needs the SDK and a key)."""
    if not isinstance(spec, str) or len(spec) > 120:
        raise Rejected("the agent spec must be a short string")
    parts = spec.split(":")
    if parts[0] == "scripted" and 2 <= len(parts) <= 3 and parts[1] in agent_providers.STYLES:
        if len(parts) == 3:
            try:
                if not 0.0 <= float(parts[2]) <= 1.0:
                    raise ValueError
            except ValueError:
                raise Rejected("a scripted failure probability must be between 0 and 1")
        return
    if parts[0] == "anthropic" and 1 <= len(parts) <= 3:
        if len(parts) > 1 and parts[1] and not MODEL_RE.match(parts[1]):
            raise Rejected("that is not a model id")
        if len(parts) > 2 and parts[2] not in ("", "low", "medium", "high", "xhigh", "max"):
            raise Rejected("effort must be low, medium, high, xhigh or max")
        return
    if parts[0] == "blackbox":
        # a vendor's own agent, driven through the evaluator-hosted tool service (agent_service.py): the spec names only a label for the vendor's product, never an address
        if len(parts) != 2 or not LABEL_RE.match(parts[1]):
            raise Rejected("blackbox:NAME needs a name of 1-40 letters, digits and _ . - (no URL: the vendor connects to the evaluator's service, never the other way round)")
        return
    if parts[0] == "compat":
        model = ":".join(parts[1:])
        # the endpoint is the OPERATOR's (an environment variable on the operator's machine): a spec can name only a model, never a URL, so an entrant cannot aim the operator's server anywhere
        if not model or not agent_providers.COMPAT_MODEL_RE.match(model) or "//" in model:
            raise Rejected("compat:MODEL needs a model id (letters, digits and . _ : / - only; no URL)")
        return
    raise Rejected("agent spec must be scripted:lean|bare|cheat|gullible[:P], anthropic:MODEL[:EFFORT], compat:MODEL or blackbox:NAME")


def normalise_config(config, domain_mod=None):
    if not isinstance(config, dict) or set(config) - {"agent", "label", "allow_tools", "system"}:
        raise Rejected("a configuration has exactly: agent, label, allow_tools (optional), system (optional)")
    validate_spec(config.get("agent"))
    label = config.get("label")
    if not isinstance(label, str) or not LABEL_RE.match(label) or label == "baseline":
        raise Rejected("label: 1-40 letters, digits and _ . : - , and not 'baseline'")
    allow = config.get("allow_tools")
    if allow is not None:
        if not isinstance(allow, list) or not all(isinstance(t, str) for t in allow) or len(allow) > 40:
            raise Rejected("allow_tools must be a list of tool names (or omitted for all tools)")
        if domain_mod is not None:
            inst = agent_core.make_instance(domain_mod, agent_core.PRACTICE_SEED, agent_core.domain_sizes(domain_mod)[0], 0)
            known = set(s["name"] for s in domain_mod.tool_specs(inst["public"]))
            if set(allow) - known:
                raise Rejected("unknown tool(s) for this domain: %s" % ", ".join(sorted(set(allow) - known)))
        allow = sorted(set(allow))
    system = config.get("system")
    if system is not None and (not isinstance(system, str) or len(system) > MAX_SYSTEM):
        raise Rejected("system must be text of at most %d characters" % MAX_SYSTEM)
    if system is not None and str(config["agent"]).startswith("blackbox:"):
        raise Rejected("a black-box agent has no system prompt the evaluator controls: leave `system` out")
    return {"agent": config["agent"], "label": label, "allow_tools": allow, "system": system}


# ---- create ---------------------------------------------------------------------------------------------------------------------------------------

def spec_model(spec):
    """The model id an `anthropic:` or `compat:` spec asks for (for anthropic the default when none is named), or None for a scripted agent. The allow-list is by model id and
    provider-agnostic: it names models the OPERATOR is willing to run on whichever endpoint(s) the operator configured."""
    parts = spec.split(":")
    if parts[0] == "compat":
        return ":".join(parts[1:])
    if parts[0] != "anthropic":
        return None
    return parts[1] if len(parts) > 1 and parts[1] else "claude-opus-5-5"


def model_allowed(spec, allowed_models):
    m = spec_model(spec)
    return m is None or allowed_models is None or m in allowed_models


def create_round(base, rid, title, domain, seed_path, sizes, n_per_size, trials, closes_at, baseline, budget=None, practice=False, max_entries=MAX_ENTRIES, now=None, allowed_models=None):
    """`baseline` is a configuration (agent spec, optional allow_tools and system) every entry is compared against. The seed is read only to commit to it.
    `allowed_models` (a list of model ids, pinned in the log) limits which real models an entrant may name: the OPERATOR pays for every trial, so without it any entrant can pick the most
    expensive model and effort. None allows any model (fine for a round whose entrants you trust)."""
    now = time.time() if now is None else now
    d = rdir(base, rid)
    if os.path.exists(d):
        raise Rejected("round %s already exists" % rid)
    mod = agent_core.load_domain(domain)
    try:
        master = agent_core.read_master(seed_path, practice)
    except agent_core.AgentEvalError as e:
        raise Rejected(str(e))
    closes = _parse_time(closes_at)
    if closes <= now:
        raise Rejected("the close time is in the past")
    if not 1 <= max_entries <= MAX_ENTRIES:
        raise Rejected("max_entries must be between 1 and %d" % MAX_ENTRIES)
    if allowed_models is not None:
        if not isinstance(allowed_models, list) or not all(isinstance(m, str) and agent_providers.COMPAT_MODEL_RE.match(m) and "//" not in m for m in allowed_models):
            raise Rejected("allowed_models must be a list of model ids")
        allowed_models = sorted(set(allowed_models))
    base_cfg = normalise_config(dict(baseline, label=baseline.get("label", "bare")), mod)
    if not model_allowed(base_cfg["agent"], allowed_models):
        raise Rejected("the baseline's model is not in allowed_models")
    try:
        plan = agent_eval.build_plan(mod, master, sizes, n_per_size, trials, budget or {})
    except agent_core.AgentEvalError as e:
        raise Rejected(str(e))
    os.makedirs(os.path.join(d, "entries"))
    os.makedirs(os.path.join(d, "ladders"))
    R._write_json(os.path.join(d, "plan.json"), plan)
    r = {"id": rid, "title": str(title)[:200], "state": "open", "domain": domain, "plan_hash": agent_eval.plan_hash(plan), "commitment": plan["commit"], "practice": plan["practice"],
         "closes_at": closes, "max_entries": max_entries, "baseline": base_cfg, "created": now, "allowed_models": allowed_models}
    R._write_json(os.path.join(d, "round.json"), r)
    with _lock(d):
        R.append_log(d, "round_created", {"commitments": [plan["commit"]], "plan_hash": r["plan_hash"], "plan": plan, "baseline": base_cfg, "baseline_sha256": config_sha(base_cfg),
                                          "closes_at": closes, "max_entries": max_entries, "max_per_handle": MAX_PER_HANDLE, "allowed_models": allowed_models,
                                          "code": code_hashes(), "python": agent_eval.PY}, now)
    return r


# ---- enter / close --------------------------------------------------------------------------------------------------------------------------------

def _entries(d):
    out = []
    ed = os.path.join(d, "entries")
    for name in sorted(os.listdir(ed)) if os.path.isdir(ed) else []:
        if name.endswith(".json"):
            out.append(R._read_json(os.path.join(ed, name)))
    return out


def enter(base, rid, handle, config, now=None):
    now = time.time() if now is None else now
    d = _require(base, rid)
    if not isinstance(handle, str) or not R.HANDLE_RE.match(handle):
        raise Rejected("a handle is 2-32 letters, digits and _ . -")
    with _lock(d):
        r = R._read_json(os.path.join(d, "round.json"))
        if r["state"] != "open":
            raise Rejected("this round is not open for entries")
        if now >= r["closes_at"]:
            raise Rejected("this round has closed")
        mod = agent_core.load_domain(r["domain"])
        cfg = normalise_config(config, mod)
        if not model_allowed(cfg["agent"], r.get("allowed_models")):
            raise Rejected("this round allows only these models: %s" % ", ".join(r["allowed_models"]))
        es = _entries(d)
        if len(es) >= r["max_entries"]:
            raise Rejected("this round is full")
        if sum(1 for e in es if e["handle"] == handle) >= MAX_PER_HANDLE:
            raise Rejected("at most %d entries per handle" % MAX_PER_HANDLE)
        if any(e["config"]["label"] == cfg["label"] for e in es) or cfg["label"] == r["baseline"]["label"]:
            raise Rejected("that label is already used in this round")
        h = config_sha(cfg)
        if any(e["config_sha256"] == h for e in es) or h == config_sha(r["baseline"]):
            raise Rejected("that exact configuration is already entered (or is the baseline)")
        eid = "e%03d" % (len(es) + 1)
        entry = {"eid": eid, "handle": handle, "config": cfg, "config_sha256": h, "entered": now}
        R._write_json(os.path.join(d, "entries", eid + ".json"), entry)
        R.append_log(d, "entry", {"eid": eid, "handle": handle, "config_sha256": h}, now)
    return entry


def close_round(base, rid, now=None, force=False):
    now = time.time() if now is None else now
    d = _require(base, rid)
    with _lock(d):
        r = R._read_json(os.path.join(d, "round.json"))
        if r["state"] != "open":
            raise Rejected("the round is already %s" % r["state"])
        if now < r["closes_at"] and not force:
            raise Rejected("the close time has not passed (use force to close early; it is logged)")
        _set_state(d, r, "closed", now, "round_closed", {"entries": len(_entries(d)), "forced": now < r["closes_at"]})
    return get_round(base, rid)


# ---- evaluate / reveal ----------------------------------------------------------------------------------------------------------------------------

def _check_pins(d, r):
    first = R.read_log(d)[0]["data"]
    problems = []
    now_hashes = code_hashes()
    for rel, h in first["code"].items():
        if now_hashes.get(rel) != h:
            problems.append("%s changed since the round was created" % rel)
    plan = R._read_json(os.path.join(d, "plan.json"))
    if plan.get("source_hashes") != agent_core.source_hashes(r["domain"]):
        problems.append("the domain, core or harness files differ from the plan's pins")
    if first.get("python") != agent_eval.PY:
        problems.append("Python %s differs from the %s the round was created under" % (agent_eval.PY, first.get("python")))
    return problems


def _evaluated_ids(d):
    return {e["data"]["eid"] for e in R.read_log(d) if e["kind"] == "evaluated"}


def evaluate_round(base, rid, seed_path, now=None, confirm_api_spend=False, accept_unsandboxed_code=False, agent_factory=None, progress=None):
    """Run the baseline and every entry. Resumable: an arm already evaluated (its ladder logged) is skipped. Returns the round."""
    now = time.time() if now is None else now
    d = _require(base, rid)
    with _lock(d):
        r = R._read_json(os.path.join(d, "round.json"))
        if r["state"] != "closed":
            raise Rejected("the round must be closed (and not yet evaluated) to evaluate: it is %s" % r["state"])
        try:
            master = agent_core.read_master(seed_path, r["practice"])
        except agent_core.AgentEvalError as e:
            raise Rejected(str(e))
        if agent_core.commitment(master) != r["commitment"]:
            raise Rejected("this seed does not match the round's commitment")
        problems = _check_pins(d, r)
        if problems:
            raise Rejected("REFUSED: " + "; ".join(problems))
        import agent_sandbox
        try:
            container = agent_sandbox.isolated(r["domain"])
        except agent_sandbox.SandboxError as e:
            raise Rejected("GULDO_SANDBOX=docker is set but the sandbox does not work (%s): a broken sandbox would make every entrant look like it failed" % e)
        if agent_core.runs_code(r["domain"]) and not r["practice"] and not accept_unsandboxed_code and not container:
            raise Rejected("the %s domain runs the MODEL's code" % r["domain"] + " as this user, where the seed file is readable; isolate the seed (container/VM), then pass accept_unsandboxed_code")
        plan = R._read_json(os.path.join(d, "plan.json"))
        mod = agent_core.load_domain(r["domain"])
        arms = [("baseline", None, r["baseline"])] + [(e["eid"], e["handle"], e["config"]) for e in _entries(d)]
        if any(agent_providers.is_real_model(cfg["agent"]) for _, _, cfg in arms) and not confirm_api_spend:
            total = len(arms) * len(plan["sizes"]) * plan["n_per_size"] * plan["trials"]
            raise Rejected("this runs up to %d trials against a real model and costs real money; pass confirm_api_spend" % total)
        done = _evaluated_ids(d)
        pending_bb = []
        for eid, handle, cfg in arms:
            if eid in done:
                continue
            if str(cfg["agent"]).startswith("blackbox:"):
                pending_bb.append(eid)                 # a vendor's agent is not run by this loop: the tool service evaluates it (agent_service.py serve-arm), logging the arm itself
                continue
            agent = (agent_factory or agent_providers.make_agent)(cfg["agent"], r["domain"])
            agent.label = cfg["label"] if eid != "baseline" else r["baseline"]["label"]
            system = cfg["system"] if cfg["system"] is not None else agent_harness.SYSTEM
            header = agent_eval.make_header(plan, cfg["agent"], agent.label, cfg["allow_tools"], system)
            if getattr(agent, "endpoint", None):
                header["agent"]["endpoint"] = agent.endpoint                   # host:port only, never a credential
            recs = []
            total = len(plan["sizes"]) * plan["n_per_size"] * plan["trials"]
            for s in plan["sizes"]:
                for i in range(plan["n_per_size"]):
                    inst = agent_core.make_instance(mod, master, s, i)
                    for t in range(plan["trials"]):
                        recs.append(agent_harness.run_trial(agent, mod, inst, plan["budget"], t, cfg["allow_tools"], system))
                        if progress:
                            progress(eid, len(recs), total)
            path = os.path.join(d, "ladders", eid + ".jsonl")
            agent_core.write_ladder(path, header, recs)
            sm = agent_compare.summarize(header, recs)
            R.append_log(d, "evaluated", {"eid": eid, "handle": handle, "label": agent.label, "ladder_sha256": _file_sha(path), "digest": agent_compare.ladder_digest(header, recs),
                                          "solved": sm["solved_instances"], "instances": sm["instances"], "served": dict(getattr(agent, "served", {}) or {})}, time.time())
        if pending_bb:
            raise Rejected("the white-box arms are done, but black-box arm(s) %s have no ladder yet: run `agent_service.py serve-arm` for each (the vendor connects to it), then evaluate again"
                           % ", ".join(pending_bb))
        _set_state(d, r, "evaluated", time.time(), "round_evaluated", {"arms": len(arms)})
    return get_round(base, rid)


def reveal(base, rid, seed_path, now=None):
    now = time.time() if now is None else now
    d = _require(base, rid)
    with _lock(d):
        r = R._read_json(os.path.join(d, "round.json"))
        if r["state"] != "evaluated":
            raise Rejected("reveal needs an evaluated round; it is %s" % r["state"])
        try:
            master = agent_core.read_master(seed_path, r["practice"])
        except agent_core.AgentEvalError as e:
            raise Rejected(str(e))
        if agent_core.commitment(master) != r["commitment"]:
            raise Rejected("this seed does not match the round's commitment")
        with open(os.path.join(d, "seed.revealed"), "w", encoding="utf-8") as f:
            f.write(master.decode("utf-8") + "\n")
        _set_state(d, r, "revealed", now, "revealed", {"seed_sha256": sha256_hex(master)})
    return get_round(base, rid)


# ---- result / verify ------------------------------------------------------------------------------------------------------------------------------

def _revealed_master(d):
    try:
        with open(os.path.join(d, "seed.revealed"), "rb") as f:
            return f.read().strip()
    except OSError:
        return None


def compute_results(d, r, replay=True):
    """Re-verify every ladder from the revealed seed and compare each entry to the baseline. Returns (results dict, problems)."""
    master = _revealed_master(d)
    problems = []
    if master is None:
        return None, ["no revealed seed"]
    base_path = os.path.join(d, "ladders", "baseline.jsonl")
    probs, _ = agent_eval.verify_ladder(base_path, master, replay=replay)
    if probs:
        problems += ["baseline: " + p for p in probs[:5]]
    bh, br = agent_core.read_ladder(base_path)
    rows = []
    for e in _entries(d):
        path = os.path.join(d, "ladders", e["eid"] + ".jsonl")
        if not os.path.exists(path):
            problems.append("%s: no ladder" % e["eid"])
            continue
        probs, _ = agent_eval.verify_ladder(path, master, replay=replay)
        if probs:
            problems += ["%s: %s" % (e["eid"], p) for p in probs[:5]]
            continue
        ch, cr = agent_core.read_ladder(path)
        cmp_ = agent_compare.compare(bh, br, ch, cr)
        rows.append({"eid": e["eid"], "handle": e["handle"], "label": e["config"]["label"], "config_sha256": e["config_sha256"], "ladder_digest": cmp_["candidate"]["digest"],
                     "summary": cmp_["candidate"]["summary"], "success": cmp_["success"], "cost": cmp_["cost"]})
    res = {"format": "guldo-agent-round-results-v1", "round": r["id"], "domain": r["domain"], "plan_hash": r["plan_hash"], "commitment": r["commitment"], "practice": r["practice"],
           "baseline": {"label": r["baseline"]["label"], "digest": agent_compare.ladder_digest(bh, br), "summary": agent_compare.summarize(bh, br)}, "entries": rows}
    return json.loads(json.dumps(res)), problems


def result(base, rid, now=None, replay=True):
    now = time.time() if now is None else now
    d = _require(base, rid)
    with _lock(d):
        r = R._read_json(os.path.join(d, "round.json"))
        if r["state"] != "revealed":
            raise Rejected("results need a revealed round; it is %s" % r["state"])
        res, problems = compute_results(d, r, replay)
        if problems:
            raise Rejected("REFUSED: a ladder does not verify: " + "; ".join(problems[:4]))
        R._write_json(os.path.join(d, "results.json"), res)
        sha = _file_sha(os.path.join(d, "results.json"))
        if not any(e["kind"] == "results" and e["data"].get("results_sha256") == sha for e in R.read_log(d)):
            R.append_log(d, "results", {"results_sha256": sha, "entries": len(res["entries"])}, now)
    return res


def verify_round(base, rid, replay=True, expected_head=None):
    """The whole round from its files, as a list of problems; NEVER raises on damaged files (a malformed file is a problem). See _verify_round."""
    try:
        return _verify_round(base, rid, replay, expected_head)
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, OverflowError, OSError, agent_core.AgentEvalError, agent_compare.CompareError) as e:
        return ["the round's files are malformed (%s: %s)" % (type(e).__name__, str(e)[:120])]


def _mirror_problems(r, first, log, entries_logged, d):
    """round.json and each entries/*.json repeat facts the LOG committed (closing time, entry cap, allowed models, baseline, who entered, when). The verifier decides from the log, so an edited copy
    changes no verdict, but anything that DISPLAYS round.json would show the edited value: every copy must therefore equal the committed one (times to within a second: the log rounds to ms)."""
    probs = []
    for key in ("closes_at", "max_entries", "allowed_models", "baseline"):
        if r.get(key) != first.get(key):
            probs.append("round.json says %s = %r but log entry 0 committed %r" % (key, r.get(key), first.get(key)))
    t0 = log[0]["ts"]
    if not (isinstance(r.get("created"), (int, float)) and not isinstance(r.get("created"), bool) and abs(r["created"] - t0) <= 1.0):
        probs.append("round.json's creation time does not match the log's first entry")
    for eid, e in entries_logged.items():
        path = os.path.join(d, "entries", eid + ".json")
        stored = R._read_json(path) if os.path.exists(path) else None
        if stored is None:
            continue
        en = stored.get("entered")
        if stored.get("eid") != eid or stored.get("handle") != e["data"]["handle"]:
            probs.append("%s: the stored entry names a different id or handle than the log" % eid)
        if not (isinstance(en, (int, float)) and not isinstance(en, bool) and abs(en - e["ts"]) <= 1.0):
            probs.append("%s: the stored entry time does not match the log's" % eid)
    return probs


def _verify_round(base, rid, replay=True, expected_head=None):
    """The whole round from its files. Returns a list of problems (empty = everything checks). `expected_head` is a log head hash the operator PUBLISHED at some point (after create, after
    close, after reveal): the log must contain it. Without one, nothing outside the round's own files can show that its tail was not cut off, which is why heads should be published."""
    try:
        d = _require(base, rid)
    except Rejected as e:
        return [str(e)]
    probs = []
    r = R._read_json(os.path.join(d, "round.json"))
    ok, n, head, err = R.verify_log(d, [r["commitment"]])
    if not ok:
        return ["log: " + err]
    log = R.read_log(d)
    first = log[0]["data"]
    for e in log:
        if e["kind"] in ("entry", "evaluated") and not (isinstance(e["data"].get("eid"), str) and EID_RE.match(e["data"]["eid"])):
            return ["the log names an entry id that is not 'baseline' or e001..e999 (it would be used as a file name)"]
    plan = R._read_json(os.path.join(d, "plan.json"))
    if plan != first["plan"] or agent_eval.plan_hash(plan) != first["plan_hash"] or first["plan_hash"] != r["plan_hash"]:
        probs.append("plan.json is not the plan committed in log entry 0")
    if config_sha(r["baseline"]) != first["baseline_sha256"]:
        probs.append("the baseline is not the one committed in log entry 0")
    probs += _mirror_problems(r, first, log, {e["data"]["eid"]: e for e in log if e["kind"] == "entry"}, d)
    kinds = [e["kind"] for e in log]
    order = ["round_created", "entry", "round_closed", "registered", "evaluated", "round_evaluated", "revealed", "results"]      # `registered`: a verifier's registry entry (agent_registry), BEFORE any arm ran
    pos = [order.index(k) for k in kinds if k in order]
    if pos != sorted(pos):
        probs.append("the log's events are out of order")
    closed_at = next((e["ts"] for e in log if e["kind"] == "round_closed"), None)
    entries_logged = {}
    for e in log:
        if e["kind"] == "entry":
            entries_logged[e["data"]["eid"]] = e
            if e["ts"] >= first["closes_at"]:
                probs.append("%s was entered at or after the close time" % e["data"]["eid"])
            if closed_at is not None and e["ts"] > closed_at:
                probs.append("%s was entered after the round closed" % e["data"]["eid"])
    derived = {"round_created": "open", "entry": "open", "round_closed": "closed", "registered": "closed", "evaluated": "closed", "round_evaluated": "evaluated", "revealed": "revealed", "results": "revealed"}.get(kinds[-1])
    if r["state"] != derived:
        probs.append("round.json says %r but the log's last event (%r) means %r" % (r["state"], kinds[-1], derived))
    if expected_head is not None and not any(e["hash"] == expected_head for e in log):
        probs.append("the published log head %s... is not in this log: entries were removed or the log was rebuilt" % expected_head[:12])
    # a prefix of a valid hash chain is itself valid, so removing the log's TAIL is invisible to the chain: every file on disk must therefore be accounted for in the log
    evaluated_logged = {e["data"]["eid"] for e in log if e["kind"] == "evaluated"}
    for sub, known in (("entries", set(entries_logged)), ("ladders", evaluated_logged)):
        sd = os.path.join(d, sub)
        for name in sorted(os.listdir(sd)) if os.path.isdir(sd) else []:
            if name.rsplit(".", 1)[0] not in known:
                probs.append("%s/%s exists but the log does not record it (was the log's tail removed?)" % (sub, name))
    if os.path.exists(os.path.join(d, "results.json")) and "results" not in kinds:
        probs.append("results.json exists but the log does not record it (was the log's tail removed?)")
    if os.path.exists(os.path.join(d, "seed.revealed")) and "revealed" not in kinds:
        probs.append("seed.revealed exists but the log does not record the reveal")
    per_handle = {}
    for eid, e in entries_logged.items():
        per_handle[e["data"]["handle"]] = per_handle.get(e["data"]["handle"], 0) + 1
        path = os.path.join(d, "entries", eid + ".json")
        stored = R._read_json(path) if os.path.exists(path) else None
        if stored is None or stored.get("config_sha256") != e["data"]["config_sha256"] or config_sha(stored["config"]) != e["data"]["config_sha256"]:
            probs.append("%s: the stored configuration is not the logged one" % eid)
    for eid in entries_logged:
        path = os.path.join(d, "entries", eid + ".json")
        stored = R._read_json(path) if os.path.exists(path) else None
        if stored is not None and not model_allowed(stored["config"]["agent"], first.get("allowed_models")):
            probs.append("%s names a model outside the round's allowed_models" % eid)
    if any(v > first["max_per_handle"] for v in per_handle.values()):
        probs.append("a handle exceeds the per-handle limit")
    if len(entries_logged) > first["max_entries"]:
        probs.append("more entries than the round allows")
    for e in log:
        if e["kind"] == "evaluated":
            path = os.path.join(d, "ladders", e["data"]["eid"] + ".jsonl")
            if not os.path.exists(path):
                probs.append("%s: logged but its ladder is missing" % e["data"]["eid"])
                continue
            if _file_sha(path) != e["data"]["ladder_sha256"]:
                probs.append("%s: the ladder file is not the one logged" % e["data"]["eid"])
                continue
            h, recs = agent_core.read_ladder(path)
            if agent_compare.ladder_digest(h, recs) != e["data"]["digest"]:
                probs.append("%s: the ladder digest differs from the logged one" % e["data"]["eid"])
            if h.get("plan_hash") != first["plan_hash"]:
                probs.append("%s: the ladder was made under a different plan" % e["data"]["eid"])
    if r["state"] in ("evaluated", "revealed"):
        evald = {e["data"]["eid"] for e in log if e["kind"] == "evaluated"}
        expect = {"baseline"} | set(entries_logged)
        if evald != expect:
            probs.append("the evaluated arms %s are not the planned %s" % (sorted(evald), sorted(expect)))
    revealed = next((e for e in log if e["kind"] == "revealed"), None)
    if r["state"] == "revealed" or revealed:
        master = _revealed_master(d)
        if master is None or revealed is None:
            probs.append("the round says revealed but the seed or its log entry is missing")
        else:
            if agent_core.commitment(master) != r["commitment"]:
                probs.append("the revealed seed does not match the commitment")
            if sha256_hex(master) != revealed["data"]["seed_sha256"]:
                probs.append("the revealed seed is not the one logged")
            res, ps = compute_results(d, r, replay)
            probs += ps
            stored = R._read_json(os.path.join(d, "results.json"))
            logged = next((e for e in log if e["kind"] == "results"), None)
            if stored is not None and res is not None and not ps and stored != res:
                probs.append("results.json is not what the ladders give")
            if logged is not None and stored is not None and _file_sha(os.path.join(d, "results.json")) != logged["data"]["results_sha256"]:
                probs.append("results.json is not the logged one")
    if r["state"] == "open" or r["state"] == "closed":
        pins = _check_pins(d, r)
        probs += pins
    return probs


def export_public(base, rid, out_base):
    """A verifiable copy of a REVEALED round: out_base/agent-rounds/<id>/ (no lock file). `verify_round(out_base, rid)` then works on the copy."""
    import shutil
    d = _require(base, rid)
    r = R._read_json(os.path.join(d, "round.json"))
    if r["state"] != "revealed":
        raise Rejected("export after the reveal: before it the entries' configurations and the ladders are not public")
    dest = rdir(out_base, rid)
    if os.path.exists(dest):
        raise Rejected("%s already exists" % dest)
    shutil.copytree(d, dest, ignore=shutil.ignore_patterns("lock", "*.tmp", "*.part"))
    return dest


# ---- command line ---------------------------------------------------------------------------------------------------------------------------------

def _load_config(args):
    cfg = {"agent": args.agent, "label": args.label}
    if getattr(args, "allow_tools", None) is not None:
        cfg["allow_tools"] = [t for t in args.allow_tools.split(",") if t]
    if getattr(args, "system", None):
        with open(args.system, "r", encoding="utf-8") as f:
            cfg["system"] = f.read()
    return cfg


def sign_round_head(base, rid, secret, now=None):
    """A SIGNED statement of the round log's current head ("at length n the head was H"). A round's log is a hash chain, which is not a signature: whoever holds the files could rewrite the WHOLE
    chain consistently, e.g. to back-date an entry. Hand these statements out at each stage (create, close, evaluate, reveal) and `verify --head` / `head-check` catch any later rewrite."""
    d = _require(base, rid)
    ok, err = _log_ok(d)
    if not ok:
        raise Rejected("the round's log does not verify (%s): not signing it" % err)
    import agent_sig
    return agent_sig.sign_head(R.read_log(d), secret, "agent-round-log", now, field="hash")


def _log_ok(d):
    """(ok, error) for a round's log; an unreadable log (junk lines, bad JSON) is a failed check, never an exception."""
    try:
        ok, _n, _head, err = R.verify_log(d)
        return ok, err
    except (ValueError, KeyError, TypeError, OSError) as e:
        return False, "the log is unreadable (%s)" % type(e).__name__


def check_round_head(base, rid, signed, trusted):
    """(ok, message): the round's log verifies AND extends the signed head, which a key in `trusted` signed."""
    d = _require(base, rid)
    ok, err = _log_ok(d)
    if not ok:
        return False, "the round's log does not verify: " + err
    import agent_sig
    return agent_sig.check_head(R.read_log(d), signed, trusted, "agent-round-log", field="hash")


def publish_head(base, rid, key_path, heads_dir, stage):
    """Write heads_dir/<rid>.<stage>.head.json, signed with the operator's key. Returns the path."""
    import agent_sig
    st = sign_round_head(base, rid, agent_sig.load_secret(key_path))
    os.makedirs(heads_dir, exist_ok=True)
    path = os.path.join(heads_dir, "%s.%s.head.json" % (rid, stage))
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps(st, indent=1, sort_keys=True) + "\n")
    return path


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", default=".", help="directory holding agent-rounds/")
    ap.add_argument("--sign-key", help="an Ed25519 key file: after create, close, evaluate and reveal, write a SIGNED head of the log to --heads-dir (publish these; see `head-check`)")
    ap.add_argument("--publish-dir", default="round-heads", help="where signed heads are written (default ./round-heads). Not named --head*: the verify command's own --head flag would then be an ambiguous prefix on older Pythons")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("create")
    p.add_argument("id")
    p.add_argument("--title", default="")
    p.add_argument("--domain", required=True)
    p.add_argument("--sizes", type=int, nargs="*")
    p.add_argument("--n", type=int, required=True)
    p.add_argument("--trials", type=int, default=1)
    p.add_argument("--closes", required=True)
    p.add_argument("--seed")
    p.add_argument("--practice", action="store_true")
    p.add_argument("--baseline-agent", required=True)
    p.add_argument("--baseline-label", default="bare")
    p.add_argument("--baseline-system")
    p.add_argument("--baseline-allow-tools")
    p.add_argument("--max-tokens", type=int)
    p.add_argument("--max-tool-calls", type=int)
    p.add_argument("--max-turns", type=int)
    p.add_argument("--max-wall-s", type=int)
    p.add_argument("--max-nudges", type=int, help="times per trial a reply with no tool call is answered with one fixed reminder (default 0); part of the plan, the same for every arm")
    p.add_argument("--allow-models", help="comma-separated model ids entrants may name (the operator pays for every trial); omit to allow any")
    p = sub.add_parser("enter")
    p.add_argument("id")
    p.add_argument("--handle", required=True)
    p.add_argument("--agent", required=True)
    p.add_argument("--label", required=True)
    p.add_argument("--allow-tools")
    p.add_argument("--system")
    p = sub.add_parser("close")
    p.add_argument("id")
    p.add_argument("--force", action="store_true")
    p = sub.add_parser("evaluate")
    p.add_argument("id")
    p.add_argument("--seed")
    p.add_argument("--practice", action="store_true")
    p.add_argument("--confirm-api-spend", action="store_true")
    p.add_argument("--accept-unsandboxed-code", action="store_true")
    p = sub.add_parser("reveal")
    p.add_argument("id")
    p.add_argument("--seed")
    p.add_argument("--practice", action="store_true")
    for name in ("result", "verify", "show"):
        p = sub.add_parser(name)
        p.add_argument("id")
        if name != "show":
            p.add_argument("--no-replay", action="store_true")
        if name == "verify":
            p.add_argument("--head", help="a log head hash the operator published earlier: the log must contain it (the only protection against a removed tail)")
    p = sub.add_parser("export")
    p.add_argument("id")
    p.add_argument("--out", required=True)
    p = sub.add_parser("head-check", help="check a signed head the operator published: the round's log must contain it")
    p.add_argument("id")
    p.add_argument("signed")
    p.add_argument("--trusted", required=True, help="a file of public keys (hex, one per line) YOU obtained out of band")
    args = ap.parse_args(argv)
    try:
        rc = _main_run(args)
        if rc == 0 and args.sign_key and args.cmd in ("create", "close", "evaluate", "reveal"):
            print("signed head -> " + publish_head(args.base, args.id, args.sign_key, args.publish_dir, {"create": "created"}.get(args.cmd, {"close": "closed", "evaluate": "evaluated", "reveal": "revealed"}.get(args.cmd))))
        return rc
    except (Rejected, agent_core.AgentEvalError, KeyError, OSError, ValueError) as e:
        print("error: %s" % (e.args[0] if e.args else e), file=sys.stderr)
        return 1


def _main_run(args):
    try:
        if args.cmd == "head-check":
            import agent_sig
            with open(args.signed, "r", encoding="utf-8") as f:
                signed = json.load(f)
            ok, msg = check_round_head(args.base, args.id, signed, agent_sig.read_trusted(args.trusted))
            print(("OK: " if ok else "FAIL: ") + msg)
            return 0 if ok else 1
        if args.cmd == "create":
            base_cfg = {"agent": args.baseline_agent, "label": args.baseline_label}
            if args.baseline_system:
                with open(args.baseline_system, "r", encoding="utf-8") as f:
                    base_cfg["system"] = f.read()
            if args.baseline_allow_tools is not None:
                base_cfg["allow_tools"] = [t for t in args.baseline_allow_tools.split(",") if t]
            r = create_round(args.base, args.id, args.title, args.domain, args.seed, args.sizes, args.n, args.trials, args.closes, base_cfg,
                             {k: v for k, v in (("max_tokens", args.max_tokens), ("max_tool_calls", args.max_tool_calls), ("max_turns", args.max_turns), ("max_wall_s", args.max_wall_s),
                                                ("max_nudges", args.max_nudges)) if v is not None} or None, args.practice,
                             allowed_models=[m for m in args.allow_models.split(",") if m] if args.allow_models else None)
            head = R.verify_log(rdir(args.base, args.id))[2]
            print("created %s; plan hash %s; log head %s" % (args.id, r["plan_hash"], head))
            print("publish the plan hash and the seed commitment %s BEFORE any entry" % r["commitment"])
        elif args.cmd == "enter":
            e = enter(args.base, args.id, args.handle, _load_config(args))
            print("entered %s as %s (config %s...)" % (e["eid"], e["config"]["label"], e["config_sha256"][:12]))
        elif args.cmd == "close":
            print("state: " + close_round(args.base, args.id, force=args.force)["state"])
        elif args.cmd == "evaluate":
            r = evaluate_round(args.base, args.id, args.seed, confirm_api_spend=args.confirm_api_spend, accept_unsandboxed_code=args.accept_unsandboxed_code,
                               progress=lambda eid, i, n: print("\r%s %d/%d" % (eid, i, n), end="", file=sys.stderr))
            print("\nstate: " + r["state"])
        elif args.cmd == "reveal":
            print("state: " + reveal(args.base, args.id, args.seed)["state"])
        elif args.cmd == "result":
            res = result(args.base, args.id, replay=not args.no_replay)
            print("baseline %s: solved %d/%d" % (res["baseline"]["label"], res["baseline"]["summary"]["solved_instances"], res["baseline"]["summary"]["instances"]))
            for row in res["entries"]:
                print("%s %-16s %-10s solved %d/%d  success: %s  cost: %s" % (row["eid"], row["label"], row["handle"], row["summary"]["solved_instances"], row["summary"]["instances"],
                                                                         row["success"]["verdict"], row["cost"]["verdict"]))
        elif args.cmd == "verify":
            probs = verify_round(args.base, args.id, replay=not args.no_replay, expected_head=args.head)
            for p in probs:
                print("PROBLEM: " + p)
            print("round %s: %s" % (args.id, "VERIFIED" if not probs else "%d problem(s)" % len(probs)))
            if not probs and not args.head:
                print("note: no published log head was given, so a removed tail cannot be ruled out beyond what the files themselves show; publish heads (agent_rounds.py show) and verify with --head")
            return 1 if probs else 0
        elif args.cmd == "show":
            r = get_round(args.base, args.id)
            print(json.dumps({k: r[k] for k in ("id", "title", "state", "domain", "plan_hash", "commitment", "practice", "closes_at")}, indent=1))
            print("entries: %d" % len(_entries(rdir(args.base, args.id))))
            ok, n, head, err = R.verify_log(rdir(args.base, args.id))
            print("log: %d entries, head %s%s" % (n, head, "" if ok else "  (DOES NOT VERIFY: %s)" % err))
        elif args.cmd == "export":
            print("wrote " + export_public(args.base, args.id, args.out))
    except (Rejected, agent_core.AgentEvalError, KeyError) as e:
        print("error: %s" % (e.args[0] if e.args else e), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
