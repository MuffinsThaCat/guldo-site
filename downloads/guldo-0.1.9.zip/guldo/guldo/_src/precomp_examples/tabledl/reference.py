def solve(public, h):
    p, g = public
    cur = 1
    for x in range(p - 1):
        if cur == h:
            return x
        cur = cur * g % p
    return None
