"""aimixed with bytes counted, CARELESS low precision: the reference method with every tensor in fp16, weights included. A quarter of the bytes of fp64, and it cannot work: once a gradient step
is smaller than half a unit in the last place of the weight it is rounded away, so the iteration stalls at a loss gap around 1e-4 to 3e-3, far over the judge's 1e-6. The judge must reject it."""
import math

import tensorops as tp

RHO = 0.9
LAM = 1e-3
STEPS = 10000


def features(seed, d, n):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    return (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)


def solve(seed, d, n, labels):
    X = features(seed, d, n)
    lr = 1.0 / (tp.sum(X * X).item() / (4.0 * n) + LAM)
    X = tp.cast(X, "fp16")
    y = tp.cast(tp.tensor([float(v) for v in labels]), "fp16")
    Xt = tp.transpose(X, (1, 0))
    w = tp.cast(tp.zeros((d,)), "fp16")
    for step in range(STEPS):
        w = w - (Xt @ (1.0 / (1.0 + tp.exp(-(X @ w))) - y) * (1.0 / n) + w * LAM) * lr
    return [int(v * 1048576.0) for v in w.tolist()]
