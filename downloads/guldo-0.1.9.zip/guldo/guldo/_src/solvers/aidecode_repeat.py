"""aidecode RED TEAM: a shortcut that costs nothing: repeat one token. The verifier must reject it."""


def solve(seed, prompt_len, T):
    return [seed % 64] * T
