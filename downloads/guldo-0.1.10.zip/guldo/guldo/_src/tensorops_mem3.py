"""Bytes, precision and peak memory for counted solvers, VERSION 3: tensorops_mem2.py (int8) plus bf16, two fp8 formats and a SPARSE matrix product. A run-time layer over tensorops.py, used by tflops_mem3_runner.py in the counting child ONLY.

tensorops_mem.py (version 1) is not touched: every existing ladder pins its hash, and its counts must stay what they were. This file is a separate counting program, so a ladder made with it says
`tflops-mem3` and cannot be mixed with a version-1 or version-2 ladder. Version 3 is a fork of version 2 (which is untouched). Everything below is as in version 1 (read tensorops_mem.py's docstring: widths, bytes moved with no cache and no fusion, peak memory,
the per-operation profile) except what this paragraph and the next say.

int8. `cast(x, "int8")` quantises SYMMETRICALLY with an absolute-maximum scale: scale = max|x| / 127 (an all-zero tensor gets scale 1), q = round(x / scale) clipped to [-127, 127], and the tensor then
holds q * scale, so the judge sees the real quantisation error. Scales are rounded to fp32 because that is what is stored and charged. `cast(x, "int8", axis)` keeps one scale per index of that axis
(per-channel scaling: the usual choice for weights; the scale is the absolute maximum over all the other axes), and is refused unless every scale covers at least 16 values (so a scale per value, which
would be lossless at 5 bytes, is not a quantisation). A tensor is 1 byte per value plus 4 bytes (an fp32) for every scale it carries, and both are counted in bytes moved and in peak memory. Quantising costs 3 operations per
element (the absolute maximum, the division, the rounding); casting an int8 tensor back to fp16/fp32/fp64 costs 1 per element, as any cast does.

What an operation on int8 tensors gives. If the WIDEST operand of an arithmetic operation (+ - * / @ einsum exp sqrt relu sum max mean concat-free) is int8, the result is 32 bits wide and rounded to fp32:
int8 is a storage and matrix-input format, and accumulations are wider, as in integer matrix units (an int32 accumulator; the fp32 rounding here is exact for sums below 2^24 and a rounding error of 6e-8
above that, which is smaller than any quantisation error). Mixed with a wider operand the result takes the wider width, as in version 1. Moving data without computing (slicing, reshape, transpose, take,
concat) keeps int8 when every operand is int8, with the scales it came with. int8 tensors are READ-ONLY: assigning into one raises TypeError (cast again instead), because a value written into a
quantised tensor has no meaning without re-deriving its scale.

bf16 and fp8. Every tensor now carries a FORMAT, not just a width, because bf16 and fp16 are both 16 bits wide and round differently. `cast(x, "bf16")` rounds to nearest-even onto bfloat16 (fp32's 8-bit exponent, a 7-bit
mantissa: no range problem, three fewer mantissa bits than fp16); `cast(x, "fp8e4m3")` and `cast(x, "fp8e5m2")` round onto the two 8-bit floating formats (e4m3: max 448, 3 mantissa bits, no infinity; e5m2: max 57344,
2 mantissa bits) and SATURATE at their maximum instead of overflowing (as the hardware conversions do when asked). An fp8 tensor is 1 byte per value with NO scale (the solver scales, or does not); casting costs 1
operation per element. Results follow the int8 rule: arithmetic on 8-bit operands is accumulated in fp32; two 16-bit operands of DIFFERENT formats (fp16 with bf16) give an fp32 result; a result of one
format is rounded to that format. 8-bit tensors (int8 and fp8) are read-only.

spmm(A, B). A SPARSE matrix product A @ B where A (m x k) is an ordinary tensor that holds zeros, and the cost follows its actual nonzeros: the result is the dense product, the charge is not.
  csr  (the default)  2 nnz n + nnz operations (a multiply-add per nonzero per output column, plus one decode per nonzero); bytes: A read as nnz values (its width) + nnz 4-byte column indices + (m + 1) 4-byte row pointers,
                      B read once, the result written. On OPERATIONS it beats the dense product (2 m k n) up to a density of 2n / (2n + 1), nearly always: the arithmetic is the nonzeros' and the decode is one
                      operation per nonzero shared by n columns. The real break-even is in BYTES: an index per nonzero makes the matrix cost nnz (width + 4) bytes against m k width dense, so
                      A is smaller only below density width / (width + 4): 2/3 at fp64, 1/3 at 16 bits, 1/5 at 8 bits. (Real unstructured kernels also pay irregular access, which no count here models:
                      this is the optimistic accounting.)
  2:4  (spmm(A, B, "2:4"))  the hardware-supported structured pattern: every group of 4 consecutive entries along a row of A holds AT MOST two nonzeros (else ValueError); the charge is for the kept half
                      whatever the data: m k n operations, bytes: A as m k / 2 values + 2 bits of metadata per kept value, B read once, the result written. Always half the operations, never more.
The unstructured pattern wins on operations whenever there are zeros and on bytes only when most of the matrix is zero (the lower the precision, the sparser it must be); the 2:4 pattern wins exactly half and needs the zeros in the right places. Neither is a model of a real sparse
kernel (no load imbalance, no gather cost, no blocking): they are the accounting a kernel author would start from.

What this is not: a model of an integer kernel (no saturation behaviour, no zero-points, no asymmetric or per-group or sub-8-bit formats, no calibration choice beyond the absolute maximum, no fused
dequantisation), a time, or a cache model. It certifies "fewer bytes / a smaller footprint under these rules", not "faster": whether a real device has a fast int8 path is not in it.
"""
import numpy as np

BITS = {"fp64": 64, "fp32": 32, "fp16": 16, "bf16": 16, "int8": 8, "fp8e4m3": 8, "fp8e5m2": 8}
FP8 = {"fp8e4m3": (448.0, -6, 3), "fp8e5m2": (57344.0, -14, 2)}    # format -> (max finite value, exponent of the smallest normal, mantissa bits)
INDEX_BYTES = 4            # a CSR column index or row pointer
META_BITS_2_4 = 2          # metadata bits per kept value of a 2:4 matrix
SCALE_BYTES = 4          # one fp32 per scale
MIN_VALUES_PER_SCALE = 16    # a scale must cover at least this many values: with one scale per value (or per few) "int8" would be a lossless 5-byte format that no integer format is
QUANT_OPS_PER_ELEMENT = 3
_BYTES = [0]
_LIVE = [0]
_PEAK = [0]
_PROFILE = {}      # (flops, bytes) of ONE operation -> how many operations had exactly that cost


def reset():
    _BYTES[0] = _LIVE[0] = _PEAK[0] = 0
    _PROFILE.clear()


def profile():
    """The run's operations grouped by their exact (flops, bytes): [[flops, bytes, count], ...], sorted. Their sums are the run's flops and bytes."""
    return [[f, b, n] for (f, b), n in sorted(_PROFILE.items())]


def _note(flops, nbytes):
    if flops or nbytes:
        _PROFILE[(flops, nbytes)] = _PROFILE.get((flops, nbytes), 0) + 1


def counters():
    """(bytes moved, peak live bytes) so far in this process."""
    return _BYTES[0], _PEAK[0]


def round_bf16(a):
    """Round float64 values to the nearest bfloat16 (ties to even): fp32's exponent and the top 7 mantissa bits."""
    with np.errstate(over="ignore", invalid="ignore"):
        f = np.ascontiguousarray(np.asarray(a, dtype=np.float64).astype(np.float32))
        u = f.view(np.uint32).astype(np.uint64)
        finite = np.isfinite(f)
        rounded = ((u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000).astype(np.uint32).view(np.float32)
        return np.where(finite, rounded, f).astype(np.float64)


def round_fp8(a, fmt):
    """Round float64 values to the nearest fp8 value of the format (ties to even), SATURATING at the format's maximum; NaN stays NaN."""
    top, emin, mbits = FP8[fmt]
    a = np.asarray(a, dtype=np.float64)
    mag = np.minimum(np.abs(a), top)
    _, e = np.frexp(mag)                                  # mag = m * 2^e with m in [0.5, 1): the unbiased exponent is e - 1
    spacing = np.exp2(np.maximum(e - 1, emin) - mbits)    # the gap between neighbouring values; constant below the smallest normal (subnormals)
    out = np.where(mag > 0, np.rint(mag / spacing) * spacing, 0.0)
    out = np.minimum(out, top)
    return np.where(np.isnan(a), np.nan, np.copysign(out, a))


def _round(a, bits, fmt=None):
    with np.errstate(over="ignore", invalid="ignore"):
        if bits == 32:
            return a.astype(np.float32).astype(np.float64)
        if bits == 16:
            return round_bf16(a) if fmt == "bf16" else a.astype(np.float16).astype(np.float64)
    return a                     # 64: exact; 8: already on its grid (cast puts it there)


FP32_TINY = float(np.finfo(np.float32).tiny)      # the smallest normal fp32: a scale below it would flush to zero
FP32_MAX = float(np.finfo(np.float32).max)


def _fp32(x):
    """A scale is STORED as an fp32 and charged as 4 bytes, so it is rounded to one: otherwise a float64 scale would carry information the byte count never paid for. It is also held inside fp32's
    normal range: a scale that underflowed to 0 or overflowed to infinity would make the quantised values NaN (0 * inf), where a real fp32 scale just saturates or flushes the data."""
    with np.errstate(over="ignore", under="ignore"):
        return np.clip(np.asarray(x, dtype=np.float64).astype(np.float32).astype(np.float64), FP32_TINY, FP32_MAX)


def quantise(a, axis=None):
    """-> (values on the int8 grid, number of scales). Symmetric absolute-maximum scaling with fp32 scales; per-slice along `axis` when given."""
    a = np.asarray(a, dtype=np.float64)
    if axis is None or a.ndim == 0:
        m = np.max(np.abs(a)) if a.size else 0.0
        s = float(_fp32(m / 127.0)) if m > 0 and np.isfinite(m) else 1.0
        return np.clip(np.rint(a / s), -127, 127) * s, 1
    ax = axis % a.ndim
    others = tuple(i for i in range(a.ndim) if i != ax)
    m = np.max(np.abs(a), axis=others, keepdims=True) if others else np.abs(a)
    s = np.where((m > 0) & np.isfinite(m), _fp32(m / 127.0), 1.0)
    return np.clip(np.rint(a / s), -127, 127) * s, int(a.shape[ax])


def install(tp):
    """Wrap the tensorops module `tp` in this process. Must be called once, before any solver code runs."""
    Base = tp.Tensor

    class MemTensor(Base):
        __slots__ = ("_b", "_x", "_f")

        def __del__(self):
            try:
                _LIVE[0] -= self._a.size * self._b // 8 + self._x
            except (AttributeError, TypeError):      # never registered, or the interpreter is shutting down
                pass
            Base.__del__(self)

    def bits_of(t):
        return getattr(t, "_b", 64)

    def fmt_of(t):
        return getattr(t, "_f", "fp64")

    def extra_of(t):
        return getattr(t, "_x", 0)

    def nbytes(t):
        return t._a.size * bits_of(t) // 8 + extra_of(t)

    def tensors_in(args):
        out = []
        for a in args:
            if isinstance(a, Base):
                out.append(a)
            elif isinstance(a, (list, tuple)):
                out += [x for x in a if isinstance(x, Base)]
        return out

    def register(t, bits, extra=0, fmt=None):
        fmt = fmt or {64: "fp64", 32: "fp32", 16: "fp16", 8: "int8"}[bits]
        if bits in (32, 16):
            t._a = _round(t._a, bits, fmt)
        t._b = bits
        t._f = fmt
        t._x = extra
        _LIVE[0] += t._a.size * bits // 8 + extra
        if _LIVE[0] > _PEAK[0]:
            _PEAK[0] = _LIVE[0]
        return t

    def widest(ts):
        return max([bits_of(t) for t in ts] or [64])

    def wrap(fn, mode, keeps_format=False):
        def wrapper(*args, **kw):
            ts = tensors_in(args)
            f0, b0 = tp._FLOPS[0], _BYTES[0]
            r = fn(*args, **kw)
            w = widest(ts)
            read = sum(nbytes(t) for t in ts) if mode in ("rw", "read") else 0
            if isinstance(r, Base):
                top_formats = {fmt_of(t) for t in ts if bits_of(t) == w}
                if keeps_format and ts and w == 8 and all(bits_of(t) == 8 for t in ts) and len(top_formats) == 1:
                    register(r, 8, min(sum(extra_of(t) for t in ts), SCALE_BYTES * r._a.size), top_formats.pop())      # data movement: still 8-bit, with the scales it came with
                elif w == 8:
                    register(r, 32)                                                                 # arithmetic on 8-bit operands accumulates in fp32
                elif w == 16 and len(top_formats) > 1:
                    register(r, 32)                                                                 # fp16 with bf16: no common 16-bit format, the result is fp32
                else:
                    register(r, w, 0, top_formats.pop() if len(top_formats) == 1 else None)         # a result keeps the format of its widest operands
                if mode in ("rw", "w"):
                    _BYTES[0] += read + nbytes(r)
                elif mode == "gather":
                    _BYTES[0] += 2 * nbytes(r)
                else:
                    _BYTES[0] += read
            else:
                _BYTES[0] += read
            _note(tp._FLOPS[0] - f0, _BYTES[0] - b0)
            return r
        wrapper.__name__ = getattr(fn, "__name__", "op")
        return wrapper

    def method(fn, mode, keeps_format=False):
        def wrapper(self, *args):
            return wrap(fn, mode, keeps_format)(self, *args)
        wrapper.__name__ = getattr(fn, "__name__", "op")
        return wrapper

    for name in ("__add__", "__radd__", "__sub__", "__rsub__", "__mul__", "__rmul__", "__truediv__", "__rtruediv__", "__neg__", "__matmul__"):
        setattr(MemTensor, name, method(getattr(Base, name), "rw"))
    setattr(MemTensor, "__getitem__", method(Base.__getitem__, "view", True))
    setattr(MemTensor, "tolist", method(Base.tolist, "read"))

    base_setitem = Base.__setitem__

    def setitem(self, k, v):
        if bits_of(self) == 8:
            raise TypeError("an int8 tensor is read-only: cast the new values again instead of assigning into it")
        key = tp._key(k)
        b0 = _BYTES[0]
        region = self._a[key].size * bits_of(self) // 8
        base_setitem(self, k, v)
        if bits_of(self) < 64:
            self._a[key] = _round(self._a[key], bits_of(self), fmt_of(self))
        _BYTES[0] += region + (nbytes(v) if isinstance(v, Base) else 0)
        _note(0, _BYTES[0] - b0)
    setattr(MemTensor, "__setitem__", setitem)

    tp.Tensor = MemTensor            # the module's own functions build `Tensor(...)` by global name: from now on they build MemTensors
    for name, mode, keeps in (("stream", "w", False), ("tensor", "w", False), ("zeros", "w", False), ("causal_mask", "w", False), ("take", "gather", True), ("concat", "rw", True),
                              ("reshape", "view", True), ("transpose", "view", True), ("einsum", "rw", False), ("exp", "rw", False), ("sqrt", "rw", False), ("relu", "rw", False),
                              ("sum", "rw", False), ("max", "rw", False), ("mean", "rw", False), ("argmax", "read", False)):
        setattr(tp, name, wrap(getattr(tp, name), mode, keeps))

    def cast(x, fmt, axis=None):
        if not isinstance(x, Base):
            raise TypeError("cast: a Tensor")
        if not isinstance(fmt, str) or fmt not in BITS:
            raise ValueError("cast: 'fp64', 'fp32', 'fp16', 'bf16', 'int8', 'fp8e4m3' or 'fp8e5m2'")
        if axis is not None and (fmt != "int8" or isinstance(axis, bool) or not isinstance(axis, int) or not -x._a.ndim <= axis < max(x._a.ndim, 1)):
            raise ValueError("cast: `axis` is an int naming one axis of the tensor, and only with 'int8' (one scale per index of that axis)")
        f0, b0 = tp._FLOPS[0], _BYTES[0]
        if fmt == "int8":
            if axis is not None and x._a.ndim > 0 and x._a.size < MIN_VALUES_PER_SCALE * x._a.shape[axis]:
                raise ValueError("cast: per-axis int8 needs at least %d values per scale (this tensor has %d values and would carry %d scales): a scale per value is not a quantisation"
                                 % (MIN_VALUES_PER_SCALE, x._a.size, x._a.shape[axis]))
            tp._charge(QUANT_OPS_PER_ELEMENT * x._a.size)
            vals, nscales = quantise(x._a, axis)
            r = MemTensor(vals)
            register(r, 8, SCALE_BYTES * nscales)
        elif fmt in FP8:
            tp._charge(x._a.size)
            r = MemTensor(round_fp8(x._a, fmt))
            register(r, 8, 0, fmt)                                            # 1 byte per value, no scale
        else:
            tp._charge(x._a.size)
            r = MemTensor(x._a.copy())
            register(r, BITS[fmt], 0, fmt)
        _BYTES[0] += nbytes(x) + nbytes(r)
        _note(tp._FLOPS[0] - f0, _BYTES[0] - b0)
        return r
    tp.cast = cast

    def spmm(A, B, pattern="csr"):
        """A @ B where A (m x k) holds zeros: the result is the dense product, the CHARGE follows A's nonzeros (see the module docstring for the two patterns)."""
        if not isinstance(A, Base) or not isinstance(B, Base):
            raise TypeError("spmm: two Tensors")
        if A._a.ndim != 2 or B._a.ndim not in (1, 2) or A._a.shape[1] != B._a.shape[0]:
            raise ValueError("spmm: A is m x k and B is k x n (or a k-vector)")
        if pattern not in ("csr", "2:4"):
            raise ValueError("spmm: the pattern is 'csr' or '2:4'")
        m, k = A._a.shape
        n = 1 if B._a.ndim == 1 else B._a.shape[1]
        wa, wb = bits_of(A), bits_of(B)
        if pattern == "2:4":
            if k % 4:
                raise ValueError("spmm 2:4: the inner dimension must be a multiple of 4")
            if int((np.count_nonzero(A._a.reshape(m, k // 4, 4), axis=2) > 2).sum()):
                raise ValueError("spmm 2:4: every group of 4 consecutive entries of a row may hold at most two nonzeros")
            flops = m * k * n
            a_bytes = m * k // 2 * wa // 8 + (m * k // 2) * META_BITS_2_4 // 8
        else:
            nnz = int(np.count_nonzero(A._a))
            flops = 2 * nnz * n + nnz
            a_bytes = nnz * (wa // 8 + INDEX_BYTES) + (m + 1) * INDEX_BYTES
        f0, b0 = tp._FLOPS[0], _BYTES[0]
        shape_out = (m,) if B._a.ndim == 1 else (m, n)
        tp._charge(flops)
        r = MemTensor(np.asarray(A._a @ B._a).reshape(shape_out))
        w = max(wa, wb)
        top_formats = {fmt_of(t) for t in (A, B) if bits_of(t) == w}
        if w == 8:
            register(r, 32)
        elif w == 16 and len(top_formats) > 1:
            register(r, 32)
        else:
            register(r, w, 0, top_formats.pop() if len(top_formats) == 1 else None)
        _BYTES[0] += a_bytes + nbytes(B) + nbytes(r)
        _note(tp._FLOPS[0] - f0, _BYTES[0] - b0)
        return r
    tp.spmm = spmm
    return MemTensor
