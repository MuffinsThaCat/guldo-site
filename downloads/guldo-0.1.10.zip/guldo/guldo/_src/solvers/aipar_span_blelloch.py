"""aipar in the work-and-span counted API, TECHNIQUE: a work-efficient parallel prefix scan (the recursive pairing form of Blelloch's scan). Compose neighbouring pairs of steps (half as many
elements), scan THOSE recursively, then fill in the in-between positions with one more composition each: about three times the work of the loop in total, depth logarithmic in T (about two
levels per halving). The input is padded with identity steps ((a, b) = (1, 0)) to a power of two and the padding dropped from the answer."""
import tensorops as tp


def scan(A, B, n, C):
    """Inclusive scan of the pairs (A[t], B[t]) under (a2, b2) o (a1, b1) = (a2 a1, a2 b1 + b2); n is a power of two."""
    if n == 1:
        return A, B
    half = n // 2
    A3 = tp.reshape(A, (half, 2, C))
    B3 = tp.reshape(B, (half, 2, C))
    Ae = A3[:, 0, :]
    Ao = A3[:, 1, :]
    Be = B3[:, 0, :]
    Bo = B3[:, 1, :]
    SA, SB = scan(Ao * Ae, Ao * Be + Bo, half, C)
    prevA = tp.concat([tp.zeros((1, C)) + 1.0, SA[0:half - 1]], 0)
    prevB = tp.concat([tp.zeros((1, C)), SB[0:half - 1]], 0)
    EA = Ae * prevA
    EB = Ae * prevB + Be
    outA = tp.reshape(tp.concat([tp.reshape(EA, (half, 1, C)), tp.reshape(SA, (half, 1, C))], 1), (n, C))
    outB = tp.reshape(tp.concat([tp.reshape(EB, (half, 1, C)), tp.reshape(SB, (half, 1, C))], 1), (n, C))
    return outA, outB


def solve(seed, T, C):
    A = tp.reshape(tp.stream(seed, 0, T * C), (T, C)) * 0.049 + 0.95
    B = tp.reshape(tp.stream(seed, T * C, T * C), (T, C))
    m = 1
    while m < T:
        m *= 2
    if m > T:
        A = tp.concat([A, tp.zeros((m - T, C)) + 1.0], 0)
        B = tp.concat([B, tp.zeros((m - T, C))], 0)
    SA, SB = scan(A, B, m, C)
    return list(map(int, (tp.reshape(SB[0:T], (T * C,)) * 1073741824.0).tolist()))
