"""aipar in the work-and-span counted API, TECHNIQUE: the Hillis-Steele parallel prefix scan. Treat each step as the pair (a_t, b_t) and compose pairs with the associative rule
(a2, b2) o (a1, b1) = (a2 a1, a2 b1 + b2). At level s = 1, 2, 4, ... every position t >= s composes itself with the position s earlier, all positions at once: ceil(log2 T) levels, each a handful
of whole-tensor operations. About log2 T times the work of the loop, depth logarithmic in T."""
import tensorops as tp


def solve(seed, T, C):
    A = tp.reshape(tp.stream(seed, 0, T * C), (T, C)) * 0.049 + 0.95
    B = tp.reshape(tp.stream(seed, T * C, T * C), (T, C))
    s = 1
    while s < T:
        Ap = tp.concat([tp.zeros((s, C)) + 1.0, A[0:T - s]], 0)
        Bp = tp.concat([tp.zeros((s, C)), B[0:T - s]], 0)
        B = A * Bp + B
        A = A * Ap
        s *= 2
    return list(map(int, (tp.reshape(B, (T * C,)) * 1073741824.0).tolist()))
