"""airealm with bytes counted (tflops_mem3.py), REFERENCE: the dense network on the noisy batch, one batched product per layer."""
import math

import tensorops as tp

CAL = 48
LAM = 1e-3


NOISE = {64: 64.0, 128: 64.0, 192: 64.0, 256: 76.0, 512: 84.0, 1024: 96.0}     # the noise scale per network width (decl.py)


def queries(H, seed, Q, X):
    """The noisy, clipped, scaled query matrix (Q x 784): x' / 255 with x' = clip(x + NOISE[H] u, 0, 255)."""
    v = tp.tensor(X) + tp.reshape(tp.stream(seed, 0, Q * 784), (Q, 784)) * NOISE[H]
    return (tp.relu(v) - tp.relu(v - 255.0)) * (1.0 / 255.0)


def labels_of(L):
    rows = L.tolist()
    return [row.index(max(row)) for row in rows]


def solve_spd(G, R, m, k):
    """Solve G x = R (m x m symmetric positive definite, m x k right-hand side) by Gauss-Jordan elimination on [G | R]."""
    A = tp.concat([G, R], 1)
    for j in range(m):
        row = A[j:j + 1] / A[j:j + 1, j:j + 1]
        M = A - A[:, j:j + 1] * row
        A = tp.concat([M[0:j], row, M[j + 1:m]], 0)
    return A[:, m:m + k]


def solve(H, Q, seed, X, W1, b1, W2, b2):
    x = queries(H, seed, Q, X)
    h = tp.relu(x @ tp.transpose(tp.tensor(W1), (1, 0)) + tp.reshape(tp.tensor(b1), (1, H)))
    return labels_of(h @ tp.transpose(tp.tensor(W2), (1, 0)) + tp.reshape(tp.tensor(b2), (1, 10)))
