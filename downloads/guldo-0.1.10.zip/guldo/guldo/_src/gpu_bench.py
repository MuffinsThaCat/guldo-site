"""Time GPU solvers on whatever PyTorch device you have (CUDA, Apple MPS or the CPU): a device-generic, parent-timed wall-clock meter, and the first one in this project that has actually RUN on a GPU.

  python3 gpu_bench.py devices                                             which devices PyTorch can see, and which one would be used
  python3 gpu_bench.py run --family aigpu --sizes 512 1024 2048 --n 3 --reps 5 --baseline solvers/aigpu_gpu_ref.py --overhead solvers/aigpu_gpu_noop.py \
                           solvers/aigpu_gpu_batched.py solvers/aigpu_gpu_sdpa.py solvers/aigpu_gpu_sdpa16.py solvers/aigpu_gpu_window.py [--device mps] [--seed SEEDFILE] [--out F.json]
  python3 gpu_bench.py check F.json                                        recompute every summary figure in a saved run from its own records

HOW IT MEASURES. The solvers are loaded in THIS process (the device is chosen once, through SVP_TORCH_DEVICE, before any solver is imported). Per size every solver first runs WARM_RUNS untimed warm-up calls on a PUBLIC
instance (never a measured one). Then, for each ladder instance, the solvers are visited in an order drawn from the instance's own id (so no solver is always first or last), and each one is called `reps` times: the
clock is time.perf_counter() around `solve(*args)` plus a device synchronize, so asynchronous kernels finish inside the measured interval; every call regenerates its inputs from the seed (nothing is cached between calls). The answer
of the first call is judged by the declaration's own verify(), OUTSIDE the timed interval: a solver whose answer is rejected is reported as rejected and never credited with a speedup. The time kept per instance is the median of its
`reps` calls. With --overhead, a probe solver that does only the instance regeneration and the transfer is timed the same way, and every other solver is also reported NET of it.

WHAT IT IS AND IS NOT. A measurement on ONE device model, by whoever ran it, on their clock, in an unsandboxed process they started: nobody else can re-execute it exactly, clocks, thermal state and other work on the machine
move it, and nothing here proves which device ran it beyond what PyTorch reports. It supports 'faster on this device as measured by this operator', not a proof, and says nothing about other devices. It is NOT the
stricter NVIDIA-only protocol of gpu_meter.py (which pins the device with nvidia-smi, samples throttling and contention, and refuses a run that saw either); use that for anything official. It does include real fused kernels,
which the exact operation and byte counts of tflops_mem.py cannot see. Exact counts and measured times answer different questions; PROTOCOL.md says how to read them together.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
import platform
import random
import statistics
import sys
import time

import instances
import tflops

HERE = os.path.dirname(os.path.abspath(__file__))
WARM_RUNS = 2
WARMUP_SEED = b"gpu-bench-warmup-public-seed"       # PUBLIC: warm-up instances come from this seed and are never ladder instances
FORMAT = "svp-gpu-bench-v1"
CLAIM_LIMITS = ("A GPU time is a wall-clock measurement on ONE device model, taken by an operator's process on the operator's clock: nobody else can re-execute it exactly, the solver runs unsandboxed in the "
                "same process, clocks, thermal state and other work on the machine move it, and nothing proves which device ran it beyond what PyTorch reports. It supports 'faster on this device, as "
                "measured by this operator', not a proof, and says nothing about other devices. This is not the NVIDIA-only gpu_meter.py protocol.")


class BenchError(Exception):
    pass


def device_choices():
    """-> {"cuda": bool, "mps": bool, "cpu": True} for the installed PyTorch (empty if there is none)."""
    try:
        import torch
    except ImportError:
        return {}
    return {"cuda": bool(torch.cuda.is_available()), "mps": bool(getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()), "cpu": True}


def pick_device(name=None):
    avail = device_choices()
    if not avail:
        raise BenchError("PyTorch is not installed")
    if name is None:
        name = "cuda" if avail["cuda"] else "mps" if avail["mps"] else "cpu"
    if not avail.get(name):
        raise BenchError(f"device {name!r} is not available here (PyTorch sees: {', '.join(k for k, v in avail.items() if v)})")
    return name


def device_label(name):
    import torch
    if name == "cuda":
        return f"{torch.cuda.get_device_name(0)} (CUDA {torch.version.cuda})"
    if name == "mps":
        return f"Apple GPU via MPS ({platform.machine()}, macOS {platform.mac_ver()[0]})"
    return f"CPU ({platform.processor() or platform.machine()})"


def make_sync(name):
    import torch
    if name == "cuda":
        return torch.cuda.synchronize
    if name == "mps":
        return torch.mps.synchronize
    return lambda: None


def load_solver(path):
    spec = importlib.util.spec_from_file_location("bench_" + hashlib.sha256(os.path.abspath(path).encode()).hexdigest()[:12], path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not callable(getattr(mod, "solve", None)):
        raise BenchError(f"{path} has no solve()")
    return mod.solve


def order_for(commit, size, idx, names):
    """The visiting order of the solvers for one instance, drawn from the instance's own id: reproducible by anyone, and different from instance to instance."""
    rng = random.Random(f"{commit}:{size}:{idx}")
    out = list(names)
    rng.shuffle(out)
    return out


def measure(solvers, verify, instances_by_id, reps, commit, clock=time.perf_counter, sync=lambda: None, warm=None, progress=None):
    """solvers: {name: solve}. instances_by_id: {(size, idx): inst}. warm: {size: inst} public warm-up instances. -> a list of records, one per (solver, instance):
    {solver, size, idx, ms: [per-call milliseconds], median_ms, correct}. Pure of the device: `clock` and `sync` are injected."""
    names = list(solvers)
    warmed = set()
    recs = []
    for (size, idx), inst in sorted(instances_by_id.items()):
        for name in order_for(commit, size, idx, names):
            fn = solvers[name]
            if warm and (name, size) not in warmed:
                warmed.add((name, size))
                for _ in range(WARM_RUNS):
                    try:
                        fn(*warm[size]["args"])
                        sync()
                    except Exception:
                        break                         # a solver that fails here fails again below, where it is recorded
            times, ans, err = [], None, None
            for r in range(reps):
                t0 = clock()
                try:
                    out = fn(*inst["args"])
                    sync()
                except Exception as e:
                    err = f"{type(e).__name__}: {str(e)[:200]}"
                    break
                times.append((clock() - t0) * 1000.0)
                if r == 0:
                    ans = out
            rec = {"solver": name, "size": size, "idx": idx}
            if err or not times:
                rec.update({"ms": [], "median_ms": None, "correct": False, "err": err or "no result"})
            else:
                try:
                    ok = bool(verify(inst, ans))
                except Exception as e:
                    ok, rec["verify_error"] = False, f"{type(e).__name__}: {str(e)[:200]}"
                rec.update({"ms": [round(t, 4) for t in times], "median_ms": round(statistics.median(times), 4), "correct": ok})
            recs.append(rec)
            if progress:
                progress(rec)
    return recs


def summarise(recs, baseline, overhead=None):
    """-> {solver: {size: {...}}}: per solver and size, over the instances where BOTH the solver and the baseline were correct: the median time, the median speedup against the baseline (bits = log2 of the time
    ratio, positive = faster), and the same net of the overhead probe's time on that instance. `rejected` counts instances where the solver's answer was rejected or crashed."""
    by = {}
    for r in recs:
        by.setdefault(r["solver"], {})[(r["size"], r["idx"])] = r
    if baseline not in by:
        raise BenchError("the baseline solver is not among the records")
    out = {}
    for name, rows in sorted(by.items()):
        if name == baseline or name == overhead:
            continue
        sizes = {}
        for (size, idx), r in sorted(rows.items()):
            s = sizes.setdefault(size, {"instances": 0, "rejected": 0, "ms": [], "bits": [], "net_bits": [], "overhead_ms": []})
            s["instances"] += 1
            b = by[baseline].get((size, idx))
            if not r["correct"]:
                s["rejected"] += 1
                continue
            if b is None or not b["correct"]:
                continue
            s["ms"].append(r["median_ms"])
            s["bits"].append(math.log2(b["median_ms"] / r["median_ms"]))
            o = by.get(overhead, {}).get((size, idx)) if overhead else None
            if o is not None and o["median_ms"] is not None:
                nb, nr = b["median_ms"] - o["median_ms"], r["median_ms"] - o["median_ms"]
                if nb > 0 and nr > 0:
                    s["net_bits"].append(math.log2(nb / nr))
                    s["overhead_ms"].append(o["median_ms"])
        out[name] = {}
        for size, s in sizes.items():
            med = lambda v: round(statistics.median(v), 4) if v else None
            out[name][str(size)] = {"instances": s["instances"], "rejected": s["rejected"], "compared": len(s["bits"]), "median_ms": med(s["ms"]),
                                    "median_bits_faster_than_baseline": med(s["bits"]), "median_bits_net_of_overhead": med(s["net_bits"]), "median_overhead_ms": med(s["overhead_ms"])}
    return out


def render(doc):
    h = doc["header"]
    out = [f"GPU BENCH on {h['device_label']}: family {h['family']}, baseline {h['baseline']}" + (f", overhead probe {h['overhead']}" if h.get("overhead") else "") + f", {h['reps']} calls per instance, median kept",
           f"  torch {h['torch']}, python {h['python']}, {h['platform']}" + ("; PRACTICE SEED (the inputs are computable by anyone)" if h["practice_seed"] else "")]
    for name, sizes in doc["summary"].items():
        for size, s in sizes.items():
            tag = f"  {name} @ {size}: "
            if s["compared"] == 0:
                out.append(tag + f"REJECTED on {s['rejected']} of {s['instances']} instances: no speedup is credited")
                continue
            out.append(tag + f"{s['median_ms']} ms, {s['median_bits_faster_than_baseline']:+.2f} bits vs baseline ({2 ** s['median_bits_faster_than_baseline']:.2f}x)"
                       + (f"; net of the {s['median_overhead_ms']} ms fixed overhead {s['median_bits_net_of_overhead']:+.2f} bits ({2 ** s['median_bits_net_of_overhead']:.2f}x)" if s["median_bits_net_of_overhead"] is not None else "")
                       + (f"; rejected on {s['rejected']}/{s['instances']}" if s["rejected"] else ""))
    out.append("  does not show: " + CLAIM_LIMITS)
    return out


def cmd_devices(a):
    avail = device_choices()
    if not avail:
        print("PyTorch is not installed")
        return 1
    for k, v in avail.items():
        print(f"  {k}: {'available' if v else 'not available'}")
    print("would use:", pick_device(None))
    return 0


def cmd_run(a):
    name = pick_device(a.device)
    os.environ["SVP_TORCH_DEVICE"] = name                # solvers read it when they are imported
    import torch
    master = open(a.seed, "rb").read().strip() if a.seed else instances.PRACTICE_SEED
    mod, derive, verify, ddir = tflops.load_family(a.family)
    files = [a.baseline] + ([a.overhead] if a.overhead else []) + list(a.solvers)
    names = [os.path.basename(f) for f in files]
    if len(set(names)) != len(names):
        raise BenchError("two solver files have the same name")
    solvers = {os.path.basename(f): load_solver(f) for f in files}
    sync = make_sync(name)
    ids = {(s, i): derive(master, s, i) for s in a.sizes for i in range(a.n)}
    warm = {s: derive(WARMUP_SEED, s, 0) for s in a.sizes}
    commit = instances.commit(master)
    recs = measure(solvers, verify, ids, a.reps, commit, sync=sync, warm=warm,
                   progress=lambda r: print(f"  {r['solver']} {r['size']}:{r['idx']}: {'ok' if r['correct'] else 'REJECTED'} {r['median_ms']} ms", flush=True))
    header = {"family": a.family, "device": name, "device_label": device_label(name), "torch": torch.__version__, "python": tflops.python_version(), "platform": platform.platform(),
              "commit": commit, "practice_seed": master == instances.PRACTICE_SEED, "reps": a.reps, "warm_runs": WARM_RUNS, "instance_version": mod.VERSION,
              "decl_sha256": tflops.sha256_file(os.path.join(ddir, "decl.py")), "baseline": os.path.basename(a.baseline), "overhead": os.path.basename(a.overhead) if a.overhead else None,
              "solver_sha256": {os.path.basename(f): tflops.sha256_file(f) for f in files}, "sizes": a.sizes, "n": a.n}
    doc = {"format": FORMAT, "header": header, "records": recs, "summary": summarise(recs, header["baseline"], header["overhead"])}
    out = a.out or os.path.join(HERE, "results", f"gpubench_{a.family}_{name}_{commit[:8]}_{int(time.time())}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if os.path.exists(out):
        raise BenchError(f"{out} exists")
    with open(out, "w") as f:
        json.dump(doc, f, indent=1)
    print("\n".join(render(doc)))
    print("saved:", out)
    return 0


def check_doc(doc):
    """-> (ok, why): a saved run is internally consistent: its summary is exactly what its own records give."""
    if not isinstance(doc, dict) or doc.get("format") != FORMAT:
        return False, "not a gpu_bench file"
    try:
        h, recs = doc["header"], doc["records"]
        for r in recs:
            if r["correct"] and (not r["ms"] or abs(statistics.median(r["ms"]) - r["median_ms"]) > 1e-3):
                return False, f"{r['solver']} {r['size']}:{r['idx']}: median_ms is not the median of ms"
        again = summarise(recs, h["baseline"], h.get("overhead"))
    except (KeyError, TypeError, ValueError, BenchError) as e:
        return False, f"unreadable ({type(e).__name__}: {e})"
    same = json.dumps(again, sort_keys=True) == json.dumps(doc.get("summary"), sort_keys=True)
    return same, "summary recomputed identically from the records" if same else "the stored summary differs from the one the records give"


def cmd_check(a):
    with open(a.file) as f:
        ok, why = check_doc(json.load(f))
    print(("OK: " if ok else "FAIL: ") + why)
    return 0 if ok else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("devices")
    p = sub.add_parser("run")
    p.add_argument("solvers", nargs="+", help="the solver files to time (besides the baseline and the overhead probe)")
    p.add_argument("--family", required=True)
    p.add_argument("--sizes", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, default=3, help="instances per size")
    p.add_argument("--reps", type=int, default=5, help="timed calls per solver per instance (the median is kept)")
    p.add_argument("--baseline", required=True)
    p.add_argument("--overhead")
    p.add_argument("--device", choices=("cuda", "mps", "cpu"))
    p.add_argument("--seed")
    p.add_argument("--out")
    p = sub.add_parser("check")
    p.add_argument("file")
    a = ap.parse_args(argv)
    try:
        return {"devices": cmd_devices, "run": cmd_run, "check": cmd_check}[a.cmd](a)
    except BenchError as e:
        print("error:", e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
