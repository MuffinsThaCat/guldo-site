# Checking an agent-evaluation result without trusting us

This page is for the first person outside the project who wants to check a published agent result, or to vouch for one. **Nobody outside the project has done this yet.** Three recorded runs of one small real model exist to check: a local 3-billion-parameter model on one domain, in
`agent_eval/real_runs_2026-11-27/` (its README gives the verification commands; the seeds there are already public). A fourth set, `anthropic_live/` in the same folder, holds claude-haiku-4-5 and claude-sonnet-5-5 on the public practice seed (9 trials each; its README gives the commands). Everything else run to date is scripted stand-ins on a public practice seed, and
no hosted model has been judged on a secret seed. The first valid round was run by the operator in-process, so for it you can check that the records are consistent and correct, not that the model produced them. The second
round, and a 4-trial practice run, went through the recording proxy and are attested; but the same person ran the proxy and the operator, so that is a demonstration of the mechanism, and an outside
verifier holding the proxy key is exactly what is still missing. This page says what you can do, with nothing but Python 3.9+ (standard library only) and a copy of this directory.

## What you need from the operator

A round is only checkable if the operator published, in this order: (1) the **plan hash** before any entry existed, (2) the **seed commitment** (it is inside the plan), (3) after the close, the
**seed**, the **plan file**, and every **ladder** (`*.jsonl`), plus the comparison file. If any of these is missing, you cannot check the result, and neither can anyone else.

## Step 1: does the ladder verify? (about a minute)

```
python3 agent_eval.py verify bare.jsonl --seed SEEDFILE --plan ROUND.plan.json --plan-hash PUBLISHED_HASH
python3 agent_eval.py verify harnessed.jsonl --seed SEEDFILE --plan ROUND.plan.json --plan-hash PUBLISHED_HASH
```

This re-derives every instance from the seed, re-runs the exact verifier on every stored answer, replays every tool call on a fresh environment, recomputes every token count and every hash chain, and
replays the harness's control flow (caps, reasons). `PUBLISHED_HASH` must be the value you saw **before** the deadline, from a place you trust (an archived page, the certificate log); a hash
the operator hands you afterwards proves nothing. Also confirm the seed matches the commitment: `verify` refuses a seed that does not.

If a ladder is a **coding** domain, verifying it runs the stored code on your machine. Do that in a throwaway VM or container.

## Step 2: does the comparison follow from the ladders?

```
python3 agent_eval.py check CLAIM.json bare.jsonl harnessed.jsonl
python3 agent_eval.py claim CLAIM.json --min-factor 3 --min-solve-rate 0.8
```

`check` recomputes the whole comparison and refuses unless it is identical. `claim` evaluates the operator's stated claim against it. Read the **limits** list in the comparison file: it says what
the number does not show.

## Step 3 (optional, the useful one): sign a statement as an independent witness

```
python3 agent_tools.py keygen --out witness.key                # prints your public key; publish it yourself, somewhere the operator does not control
python3 agent_tools.py witness-sign harnessed.jsonl --seed SEEDFILE --plan ROUND.plan.json --plan-hash PUBLISHED_HASH --key witness.key --out witness.harnessed.json
```

Send the statement to the operator or publish it. A reader counts it only if they pinned **your** key from a source other than the operator, so publish the key where people can find it. If the ladder
does not verify, the same command signs a **dissent** (the statement records that it failed and the first problems); a dissent fails the check whoever signed it, which is the point.

Readers check witnesses with: `python3 agent_tools.py witness-check harnessed.jsonl witness.*.json --trusted PINNED_KEYS.txt --min 1`.

## Step 4 (optional, costs money): rerun a sample yourself

A ladder shows its records are consistent and correct. It does **not** show a model produced them. The strongest thing an outsider can add is to run the same agent configuration on instances
**you** draw, which the operator could not have known: `agent_witness.draw_sample(header, m, your_secret_bytes)` picks them, you run those instances with the same plan, system prompt and tool list,
and `agent_witness.rerun_block` records whether your pass count is compatible with the operator's recorded pass rate (a one-sided exact test; a low count is flagged as inconsistent, which means
"ask", not "fraud": models change under the same name). This uses your own API key and your own money; nothing here runs without `--confirm-api-spend`.

## Step 5 (optional): check the provenance receipts

If the operator ran the model through a recording proxy that a **verifier** controls (not the operator), there is a log of signed receipts:

```
python3 agent_proxy.py verify harnessed.jsonl PROXY.jsonl --trusted PROXY_KEYS.txt --seed SEEDFILE
```

This checks every model call in the ladder has a matching signed exchange, from a key you pinned. If the operator held the proxy's key themselves, it proves nothing: ask who held it.

## For the operator: getting a witness set up quickly (optional; `agent_witness_kit.py`)

Nothing else depends on this, and the card's "outside witnesses" count stays 0 until a real witness has signed a real round. It exists so that when someone says yes, setting them up takes minutes.

1. **Before the round has any entry,** `python3 agent_witness_kit.py announce BASE ROUND_ID --out ANNOUNCE.json [--key OPERATOR.key] --text-out MESSAGE.txt` and send MESSAGE.txt to the witness by a channel that
   timestamps it on THEIR side (their inbox is the outside clock). It refuses once an entry exists: after that it fixes nothing.
2. Run the round as usual (a free local model costs nothing; for provenance, the witness can also hold the recording proxy).
3. **After the reveal,** `python3 agent_witness_kit.py build BASE ROUND_ID --out KIT [--proxy-log LOG --proxy-trusted KEYFILE]` makes a self-contained directory and `KIT.tar.gz` (tools, the revealed round, a README).
   It copies only an allow-listed set of round files, so no key and no unrevealed seed can leak into it, and it refuses an unrevealed round.
4. The witness runs ONE command inside the kit (`witness . ROUND_ID --announce ANNOUNCE.json --received-at TIME`). It verifies the round, ties it to the announcement they hold, checks that their receipt time
   precedes the first entry, and signs. A failure is signed as a dissent. `--rerun N` also runs a sample THEY draw.
5. **Anyone** then runs `python3 agent_witness_kit.py check BASE ROUND_ID witness.bundle.json --trusted PINNED_KEYS.txt --announce ANNOUNCE.json witness.*.json`, which recomputes everything itself and trusts none of
   the bundle's own flags.

**An outside clock without any person (optional).** `announce_anchor.py stamp ANNOUNCE.json --send` sends only sha256(digest || a random nonce) of the announcement to the public OpenTimestamps calendars; without `--send` it
sends nothing and shows what it would do. A few hours later `announce_anchor.py upgrade ANNOUNCE.json.ots --send` fetches the Bitcoin proof (it writes a NEW file), and `announce_anchor.py status ANNOUNCE.json ANNOUNCE.json.upgraded --online --base BASE --round ID`
says whether Bitcoin confirms the announcement existed before the round's first logged entry, with a margin of two hours because a block's timestamp is only that accurate (a block earlier by less than that is reported as "close", which establishes nothing). The order matters: stamp, WAIT for the confirmation, and only then let entries in; a stamp made after the run still shows the plan existed by
that block, and says nothing about being before the run. A reader can demand it: `agent_witness_kit.py check ... --anchor-proof ANNOUNCE.json.upgraded --online --require-anchor` (a wrong or forged proof fails the check; a pending, late or single-explorer one is only a note). Never run against the real calendars yet.

What it does not show: the witness's receipt time is their word about their own copy of the message (they should keep it with its headers), checked against the operator's log for consistency, not against a trusted clock.

## What you are NOT being asked to trust

Our word on any number (you recompute it), the seed's secrecy (you check the commitment), or that our code is bug-free (it is small, standard-library only, and has an adversarial test suite; read it,
break it, and tell us). You **are** still trusting: that the published plan hash was really published first, that your Python and OS are honest, and, for provenance, whoever held the proxy key.

## Known limits, in one place

Proxy tokens are not billed tokens. The tasks come from a public generator, so commit-reveal means no judged instance could have been seen, not that the skill could not be trained for. An exact
verifier is only as good as its tests. A certificate covers output correctness, and for the two safety domains one specified unsafe behaviour; it says nothing else about safety. See `AGENT_EVAL.md`
and `PROTOCOL.md` for the full list, and tell us what is missing.
