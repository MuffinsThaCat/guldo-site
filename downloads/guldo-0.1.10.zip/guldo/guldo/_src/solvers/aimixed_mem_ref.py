"""aimixed with bytes counted (tflops_mem.py), REFERENCE: plain full-batch gradient descent in float64 (the default width), step 1/L, L = |X|_F^2/(4N) + lambda, 10000 steps."""
import math

import tensorops as tp

RHO = 0.9
LAM = 1e-3
STEPS = 10000


def features(seed, d, n):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    return (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)


def solve(seed, d, n, labels):
    X = features(seed, d, n)
    y = tp.tensor([float(v) for v in labels])
    Xt = tp.transpose(X, (1, 0))
    lr = 1.0 / (tp.sum(X * X).item() / (4.0 * n) + LAM)
    w = tp.zeros((d,))
    for step in range(STEPS):
        w = w - (Xt @ (1.0 / (1.0 + tp.exp(-(X @ w))) - y) * (1.0 / n) + w * LAM) * lr
    return [int(v * 1048576.0) for v in w.tolist()]
