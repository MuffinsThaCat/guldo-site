"""Reference for aisecond: plain full-batch gradient descent on the L2-regularised logistic loss, step 1/L with L = |X|_F^2 / (4N) + lambda, 35000 steps, float64.

The features are regenerated from the seed with the SplitMix64 stream documented in domains/aisecond/decl.py (the same stream as aiinfer): every submission does the same.
"""
import math

import numpy as np

RHO = 0.97
LAMBDA = 1e-4
STEPS = 35000


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, n, labels):
    k = np.arange(d)
    U = np.triu(RHO ** np.clip(k[None, :] - k[:, None], 0, None))
    X = (_uniform(seed, 0, n * d).reshape(n, d) @ U) * math.sqrt(1.0 - RHO * RHO)
    y = np.asarray(labels, dtype=np.float64)
    lr = 1.0 / ((X * X).sum() / (4.0 * n) + LAMBDA)
    w = np.zeros(d)
    for _ in range(STEPS):
        w = w - lr * (X.T @ (1.0 / (1.0 + np.exp(-(X @ w))) - y) / n + LAMBDA * w)
    return [int(v) for v in np.rint(w * 2 ** 20)]
