"""aiinfer on a GPU, SPEEDUP: the whole batch in one matmul per layer on the device, one read-back at the end. Same float32 numbers as aiinfer_gpu_ref.
UNRUN: written without a GPU or torch."""
import math

import numpy as np
import torch

_GOLD = 0x9E3779B97F4A7C15
_C1 = 0xBF58476D1CE4E5B9
_C2 = 0x94D049BB133111EB
_CLASSES = 10


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _model(seed, d, batch):
    s = math.sqrt(3.0 / d)
    o = 0
    W1 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W2 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W3 = (_uniform(seed, o, _CLASSES * d) * s).reshape(_CLASSES, d)
    o += _CLASSES * d
    X = _uniform(seed, o, batch * d).reshape(batch, d)
    return W1, W2, W3, X


def solve(seed, d, batch):
    dev = torch.device("cuda")
    W1, W2, W3, X = (torch.from_numpy(a).to(dev, dtype=torch.float32) for a in _model(seed, d, batch))
    h = torch.relu(X @ W1.T)
    h = torch.relu(h @ W2.T)
    return (h @ W3.T).argmax(dim=1).tolist()
