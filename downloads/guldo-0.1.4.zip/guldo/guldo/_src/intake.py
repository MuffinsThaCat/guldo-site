"""Domain intake: how an outside person proposes a problem declaration, and how the operator takes it in (see INTAKE.md).

  intake.py screen DIR                       static check of decl.py + reference.py (+ NOTES.md); never imports or runs them
  intake.py pack DIR --contact TEXT --out F  screen, then write ONE JSON bundle to send to the operator
  intake.py receive FILE|-                   (operator) re-screen from scratch, quarantine under intake/NAME/HASH12/, log it (FILE may be a GitHub issue body)
  intake.py trial NAME[/HASH]                (operator) run the compiler's parse + validate passes on the quarantined copy in a limited child; write REVIEW.md
  intake.py accept NAME[/HASH] --i-read-it   copy into domains/NAME (a NEW directory only) and log it; does not compile
  intake.py reject NAME[/HASH] --reason T    log a refusal (the quarantined files are kept)
  intake.py list                             the queue, and whether the hash-chained intake log is intact

What this is NOT: a sandbox. The screen is an AST filter. It catches accidents and the obvious, and it cannot prove a file safe (an infinite loop
or a memory hog passes it; so does anything an AST filter has not been taught). decl.py and reference.py are operator code: the compiler imports
the first in the judge's process and runs the second in a bare local process. The control is that the operator READS both files before `accept`
(which refuses without --i-read-it, and refuses if the files changed since they were received). `trial` adds a child process with CPU and file-size
limits, a memory watcher (resident memory of the whole process group, same on Linux and macOS) and a hard wall-clock kill, and refuses to run as
root. It does NOT hide the filesystem or the network from the child: use a throwaway user or VM for anything you did not write.
"""
import argparse
import ast
import datetime
import hashlib
import importlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import types
import warnings

try:
    import resource
except ImportError:  # Windows: `trial` is unavailable there, everything else works
    resource = None
try:
    import fcntl
except ImportError:
    fcntl = None

HERE = os.path.dirname(os.path.abspath(__file__))
FORMAT = "svp-intake-v1"
LOG_FORMAT = "svp-intake-log-v1"
NAME_RE = re.compile(r"^[a-z]{2,16}$")   # the same rule as declared.NAME_RE (test_intake.py fails if they drift apart)
BUILTIN = ("gm", "mlwe", "factor")
NONSPEED_KINDS = ("advantage", "oracle", "precomp", "quantum")   # declarations with KIND = one of these are compiled by compile_kinds.py (must equal compile_kinds.KINDS: test_kinds checks)
MIN_SIZES = 3                           # the compiler's ladder needs at least this many sizes (compile_domain.MIN_SIZES)
PROPOSALS_URL = "https://github.com/MuffinsThaCat/guldo-site/issues/new"   # where proposers send a bundle: the public site's repo (the guldo repo is private); one constant to change
INPUT_MAX = 4 * 256 * 1024               # what `receive` will read: a bundle (at most MAX_BUNDLE) may sit among ordinary text, e.g. a GitHub issue body
RULES_VERSION = 2                       # bump when the screen's rules change: the log records it, so a later "why was this accepted" has an answer
MAX_SIZE = 100000                       # the compiler's check calls derive at the top of SIZE_RANGE: an absurd hi is a memory hog, not a problem
MIN_NOTE = 40                           # characters of REFERENCE_NOTE: a baseline nobody has described is the main way a challenge is made cheap
FILES = ("decl.py", "reference.py", "NOTES.md")
REQUIRED = ("decl.py", "reference.py")
MAX_FILE = 64 * 1024
MAX_NOTES = 16 * 1024
MAX_BUNDLE = 256 * 1024
MAX_CONTACT = 200
MAX_FINDINGS = 40
IGNORED_IN_DIR = {"compiled.json", "compiled.prev.json", "out", "__pycache__", ".DS_Store"}
GENESIS = "0" * 64

PURE = {"math", "itertools", "functools", "collections", "fractions", "heapq", "bisect", "struct", "array",
        "statistics", "random", "hashlib", "hmac", "binascii", "decimal"}
# Left out on purpose: `operator` (attrgetter/methodcaller and `string.Formatter` walk attributes from a STRING at run time, so the dunder rules cannot see them),
# `string`, and numpy/fpylll (numpy.fromfile/load/savetxt read and write files, and the baseline runs bare on the operator's machine during compile).
# A baseline that needs one of them is added by the operator by hand, after reading it, not through intake.
DECL_IMPORTS = PURE | {"instances"}                       # `instances` is the project's own module; the only helper it offers is _is_prime
REF_IMPORTS = set(PURE)
NEEDS_OPERATOR = {"numpy", "fpylll", "cysignals", "operator", "string"}
IMPORT_HINTS = {   # imports an honest author reaches for, and what to do instead
    "typing": "type hints need no import: write list[int], dict[str, int], tuple[int, ...] (Python 3.9+) or drop them; typing.get_type_hints evaluates strings, so the module is not available",
    "__future__": "not needed: annotations work without it",
    "dataclasses": "classes are not allowed: use tuples and dicts",
    "enum": "classes are not allowed: use integer constants",
    "abc": "classes are not allowed",
    "time": "derive must not read the clock: it has to be a pure function of (master, size, idx)",
    "os": "no files, environment or processes: derive and verify are pure functions",
    "sys": "no files, environment or processes: derive and verify are pure functions",
    "json": "not needed: the solver receives and returns plain Python values",
    "re": "not available: write the check directly",
}
ALLOWED_UNDERSCORE = {"_is_prime"}
FORBIDDEN_NAMES = {"eval", "exec", "compile", "open", "input", "breakpoint", "getattr", "setattr", "delattr", "globals", "locals", "vars",
                   "exit", "quit", "help", "print", "copyright", "credits", "license",   # print: stdout is the runner's result channel, a solver or baseline must not write to it
                   "SystemExit", "BaseException", "KeyboardInterrupt", "GeneratorExit"}  # these stop or swallow the judge's own control flow; `except Exception` is the ordinary form
FRAME_PREFIXES = ("f_", "gi_", "cr_", "ag_", "tb_", "co_")
FORMAT_ATTRS = {"format", "format_map"}                   # "{0.__class__}".format(x) walks attributes at run time, where no AST rule can see it
DANGEROUS_ATTRS = {"sys", "os", "builtins", "modules", "system", "popen", "fork", "execv", "spawn", "importlib", "subprocess", "environ",
                   "stdin", "stdout", "stderr", "import_module", "load_module"}
SOURCE_BANNED_NODES = {
    "ClassDef": "classes are not allowed: use functions, tuples and dicts",
    "AsyncFunctionDef": "async code is not allowed: derive, verify and solve are called synchronously",
    "AsyncFor": "async code is not allowed", "AsyncWith": "async code is not allowed", "Await": "async code is not allowed",
    "Global": "`global` is not allowed: derive must be a pure function of its arguments", "Nonlocal": "`nonlocal` is not allowed",
    "Match": "`match` is not allowed: a class pattern reads attributes by NAME at run time (`case object(__class__=c)`), which no attribute rule can see",
    "MatchClass": "class patterns are not allowed: they read attributes by name at run time",
}


def screener_id():
    """Which screen looked at a proposal: the rules version and the interpreter (the leaky-module set is computed from the interpreter's own modules)."""
    return f"rules-{RULES_VERSION} python-{sys.version_info.major}.{sys.version_info.minor}"


def prog():
    """The command the person actually typed, so a hint never sends a `guldo intake` user to a script they do not have."""
    return "guldo intake" if sys.argv and sys.argv[0] == "guldo intake" else "python3 intake.py"   # exactly what the package's dispatcher sets, nothing looser


def R(check, status, detail=""):
    return {"check": check, "status": status, "detail": _clean(detail, 300)}


def worst(results):
    order = {"pass": 0, "warn": 1, "fail": 2}
    return max((r["status"] for r in results), key=order.get, default="pass")


def _clean(s, n=160):
    """Text that came from someone else's file is shown, logged and written into REVIEW.md: no control characters, bounded length."""
    s = "".join(c if (c.isprintable() or c == " ") else "?" for c in str(s))
    return s if len(s) <= n else s[: n - 3] + "..."


def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False, ensure_ascii=True)


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# ------------------------------------------------------------------------------------------------------------- reading a directory
def read_dir(dirpath):
    """-> (files, findings). `files` maps file name to text for the files that may travel in a bundle. A symlink, a non-regular file, an oversized
    file, invalid UTF-8 or a NUL byte is a FAIL: the bundle must contain exactly what the author wrote, as text."""
    out, files = [], {}
    if not os.path.isdir(dirpath):
        return files, [R("directory", "fail", f"{dirpath} is not a directory")]
    for fn in FILES:
        p = os.path.join(dirpath, fn)
        try:
            st = os.lstat(p)
        except OSError:
            if fn in REQUIRED:
                out.append(R(fn, "fail", "missing"))
            continue
        limit = MAX_NOTES if fn == "NOTES.md" else MAX_FILE
        if not (st.st_mode & 0o170000) == 0o100000:
            out.append(R(fn, "fail", "not a regular file (symbolic links are refused)"))
            continue
        if st.st_size > limit:
            out.append(R(fn, "fail", f"{st.st_size} bytes; the limit is {limit}"))
            continue
        try:
            fd = os.open(p, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))   # a symlink swapped in after the lstat above is refused, not followed
        except OSError:
            out.append(R(fn, "fail", "could not be opened (a symbolic link, or it changed while being read)"))
            continue
        with os.fdopen(fd, "rb") as f:
            raw = f.read(limit + 1)
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            out.append(R(fn, "fail", "not valid UTF-8"))
            continue
        if "\x00" in text:
            out.append(R(fn, "fail", "contains a NUL byte"))
            continue
        if not text.strip():
            out.append(R(fn, "fail", "empty"))
            continue
        files[fn] = text
    extra = sorted(e for e in os.listdir(dirpath) if e not in FILES and e not in IGNORED_IN_DIR)
    if extra:
        out.append(R("other files", "warn", "not included in the bundle (only decl.py, reference.py and NOTES.md travel): " + ", ".join(_clean(e, 40) for e in extra[:8])))
    return files, out


# ------------------------------------------------------------------------------------------------------------- the static screen
_COOKIE = re.compile(r"^[ \t\f]*#.*?coding[:=][ \t]*([-\w.]+)")


def parse_source(text):
    """ast.parse on the exact bytes the file will hold, with the interpreter's own warnings about someone else's escapes kept out of the output."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return ast.parse(text.encode("utf-8"))


def _encoding_problem(text):
    for line in text.split("\n")[:2]:
        m = _COOKIE.match(line)
        if m and m.group(1).lower().replace("_", "-") not in ("utf-8", "utf8", "ascii", "us-ascii"):
            return f"source encoding cookie {m.group(1)!r}: the file must be UTF-8 so that what is screened is what runs"
    return None


def _is_dunder(s):
    return len(s) > 4 and s.startswith("__") and s.endswith("__")


def _module_cache():
    cache = {}

    def get(name):
        if name not in cache:
            try:
                cache[name] = importlib.import_module(name)
            except Exception:  # a third-party module the screening machine lacks: nothing to check dynamically
                cache[name] = None
        return cache[name]
    return get


_get_module = _module_cache()


def _leaky_names():
    """Attribute names that are, in some allowed module, a module that is NOT itself allowed (fractions.operator, fractions.sys, collections.abc ...).
    Banned by name on any receiver, because `m = fractions; m.operator` defeats a check that only looks at imported names. A name whose module IS allowed
    (statistics.random) stays usable, since `random.random()` is the function. Computed on the screening interpreter, so the operator's run is the authority."""
    universe = PURE | {"instances"}
    out = set()
    for m in sorted(universe):
        mod = _get_module(m)
        if mod is not None:
            out |= {k for k, v in vars(mod).items() if isinstance(v, types.ModuleType) and not k.startswith("_") and v.__name__ not in universe}
    return out


_LEAKY = _leaky_names()


def _rule_findings(tree, allowed, kind):
    """Every rule that applies to the whole tree. Returns a de-duplicated list of 'line N: message' strings."""
    problems, seen = [], set()
    aliases = {}   # local name -> module, collected BEFORE the main walk: the result must not depend on where an import sits in the tree
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if "." not in a.name and a.name in allowed:
                    aliases[a.asname or a.name] = a.name

    def bad(node, msg):
        key = msg
        if key not in seen:
            seen.add(key)
            problems.append(f"line {getattr(node, 'lineno', '?')}: {msg}")

    def module_attr_is_module(mod, attr):
        m = _get_module(mod)
        return m is not None and isinstance(getattr(m, attr, None), types.ModuleType)

    for node in ast.walk(tree):
        t = type(node).__name__
        if t in SOURCE_BANNED_NODES:
            bad(node, SOURCE_BANNED_NODES[t])
        if isinstance(node, ast.FunctionDef) and node.decorator_list:
            bad(node, "decorators are not allowed")
        if isinstance(node, ast.Import):
            for a in node.names:
                top = a.name.split(".")[0]
                if "." in a.name:
                    bad(node, f"`import {_clean(a.name, 40)}`: import the module itself and use its public names (submodules can reach modules this screen does not allow)")
                elif top not in allowed:
                    if top == "instances" and kind == "reference":
                        why = "the baseline must be self-contained: it runs in the sandbox, which has none of the judge's modules"
                    elif top in NEEDS_OPERATOR:
                        why = "not available through intake; if your problem truly needs it, say so in NOTES.md and the operator can add the file by hand"
                    elif top in IMPORT_HINTS:
                        why = IMPORT_HINTS[top]
                    else:
                        why = f"allowed here: {', '.join(sorted(allowed))}"
                    bad(node, f"imports `{_clean(top, 40)}` ({why})")
        elif isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            if node.level:
                bad(node, "relative imports are not allowed")
            elif "." in mod:
                bad(node, f"`from {_clean(mod, 40)} import ...`: import the module itself and use its public names")
            elif mod not in allowed:
                bad(node, f"imports from `{_clean(mod, 40)}` (" + (IMPORT_HINTS.get(mod) or f"allowed here: {', '.join(sorted(allowed))}") + ")")
            else:
                for a in node.names:
                    if a.name == "*":
                        bad(node, "`from ... import *` is not allowed: name what you use")
                    elif a.name.startswith("_") and not (mod == "instances" and a.name in ALLOWED_UNDERSCORE):
                        bad(node, f"`{_clean(a.name, 40)}` is not a public name")
                    elif mod == "instances" and a.name not in ALLOWED_UNDERSCORE:
                        bad(node, "the only helper the project's `instances` module offers a declaration is `_is_prime`; write your own for anything else")
                    elif a.name in _LEAKY or module_attr_is_module(mod, a.name):
                        bad(node, f"`{_clean(a.name, 40)}` is itself a module reachable through `{mod}`; import what you need directly")
        elif isinstance(node, ast.Name):
            if _is_dunder(node.id) or node.id.startswith("__"):
                bad(node, f"the name `{_clean(node.id, 40)}` is not allowed (no double-underscore names, so no `if __name__ == ...` either)")
            elif node.id in FORBIDDEN_NAMES:
                bad(node, f"`{node.id}` is not allowed (no files, no dynamic code, no reflection)")
        elif isinstance(node, ast.Attribute):
            a = node.attr
            if a.startswith("__"):
                bad(node, f"attribute `{_clean(a, 40)}` is not allowed (no double-underscore attributes)")
            elif a.startswith("_") and a not in ALLOWED_UNDERSCORE:
                bad(node, f"attribute `{_clean(a, 40)}` is not allowed (private names of a module can reach `os` and `sys`)")
            elif a.startswith(FRAME_PREFIXES):
                bad(node, f"attribute `{_clean(a, 40)}` is not allowed (frame and generator internals)")
            elif a in FORMAT_ATTRS:
                bad(node, f"`.{a}()` is not allowed: use an f-string, whose expressions this screen can read")
            elif a in DANGEROUS_ATTRS:
                bad(node, f"attribute `{a}` is not allowed")
            elif a in _LEAKY:
                bad(node, f"`.{_clean(a, 40)}` names a module that is not allowed (`fractions.sys` and `fractions.operator` are how an import list leaks); this applies through any variable too")
            if isinstance(node.ctx, (ast.Store, ast.Del)):
                bad(node, f"assigning to or deleting `.{_clean(a, 40)}` is not allowed: without classes it can only modify an imported module that the judge shares")
            elif isinstance(node.value, ast.Name) and aliases.get(node.value.id) == "instances" and a not in ALLOWED_UNDERSCORE:
                bad(node, "the only helper the project's `instances` module offers a declaration is `_is_prime`")
    return problems


def _top_level_shape(tree):
    """The module body may hold imports, constants and function definitions, and every top-level name is bound ONCE: the screen reads one definition
    and the interpreter runs the last, so `NAME, V = "factor", 1` after `NAME = "mine"`, or `derive = lambda ...` after `def derive`, would otherwise
    make the screened file differ from the one that runs."""
    problems, bound = [], {}

    def bind(name, st):
        if name in bound:
            problems.append(f"line {st.lineno}: `{_clean(name, 40)}` is bound twice at the top level (first on line {bound[name]})")
        else:
            bound[name] = st.lineno

    for i, st in enumerate(tree.body):
        if isinstance(st, ast.Import):
            for a in st.names:
                bind(a.asname or a.name.split(".")[0], st)
        elif isinstance(st, ast.ImportFrom):
            for a in st.names:
                if a.name != "*":
                    bind(a.asname or a.name, st)
        elif isinstance(st, ast.FunctionDef):
            bind(st.name, st)
        elif isinstance(st, ast.Assign) and all(isinstance(t, ast.Name) for t in st.targets):
            for t in st.targets:
                bind(t.id, st)
        elif isinstance(st, ast.AnnAssign) and isinstance(st.target, ast.Name):
            bind(st.target.id, st)
        elif i == 0 and isinstance(st, ast.Expr) and isinstance(st.value, ast.Constant) and isinstance(st.value.value, str):
            continue
        else:
            problems.append(f"line {st.lineno}: top-level `{type(st).__name__}`: the module body may hold only imports, constants and function definitions")
    return problems


def _literals(tree):
    """Top-level NAME = <literal> assignments, evaluated without running anything."""
    out = {}
    for st in tree.body:
        target, value = None, None
        if isinstance(st, ast.Assign) and len(st.targets) == 1 and isinstance(st.targets[0], ast.Name):
            target, value = st.targets[0].id, st.value
        elif isinstance(st, ast.AnnAssign) and isinstance(st.target, ast.Name) and st.value is not None:
            target, value = st.target.id, st.value
        if target is not None:
            try:
                out[target] = ast.literal_eval(value)
            except (ValueError, TypeError, SyntaxError, RecursionError, MemoryError):
                out[target] = _NOT_LITERAL
    return out


_NOT_LITERAL = object()


def _functions(tree):
    return {st.name: st for st in tree.body if isinstance(st, ast.FunctionDef)}


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _params(fn):
    a = fn.args
    return len(a.posonlyargs) + len(a.args), bool(a.vararg or a.kwarg or a.kwonlyargs), len(a.defaults)


def screen_decl(text, expect_name=None):
    out = []
    enc = _encoding_problem(text)
    if enc:
        return [R("decl.py encoding", "fail", enc)]
    try:
        tree = parse_source(text)
    except SyntaxError as e:
        return [R("decl.py syntax", "fail", f"{e.msg} (line {e.lineno})")]
    except (ValueError, RecursionError, MemoryError) as e:
        return [R("decl.py syntax", "fail", f"could not parse ({type(e).__name__})")]
    problems = _top_level_shape(tree) + _rule_findings(tree, DECL_IMPORTS, "decl")
    for p in problems[:MAX_FINDINGS]:
        out.append(R("decl.py rule", "fail", p))
    lit, fns = _literals(tree), _functions(tree)

    name = lit.get("NAME", None)
    if "NAME" not in lit:
        out.append(R("NAME", "fail", "missing: NAME = \"yourname\" (2-16 lowercase letters)"))
    elif not (isinstance(name, str) and NAME_RE.fullmatch(name)):   # fullmatch: `$` would also accept a trailing newline
        out.append(R("NAME", "fail", "must be a string literal of 2-16 lowercase letters a-z (no digits, hyphens or capitals)"))
    elif name in BUILTIN:
        out.append(R("NAME", "fail", f"{name!r} is a built-in family"))
    elif expect_name is not None and name != expect_name:
        out.append(R("NAME", "fail", f"NAME is {name!r} but the bundle says {expect_name!r}"))
    else:
        out.append(R("NAME", "pass", name))

    v = lit.get("VERSION", None)
    out.append(R("VERSION", "pass", v) if isinstance(v, str) and v.strip() and len(v) <= 64 and v.isprintable()
                else R("VERSION", "fail", "VERSION must be a non-empty printable string literal (at most 64 characters); bump it whenever derive() changes"))

    sr, step = lit.get("SIZE_RANGE", None), lit.get("SIZE_STEP", 1)
    if not (isinstance(sr, (tuple, list)) and len(sr) == 2 and all(_is_int(x) for x in sr) and 1 <= sr[0] < sr[1]):
        out.append(R("SIZE_RANGE", "fail", "must be a literal (lo, hi): two integers with 1 <= lo < hi"))
    elif sr[1] > MAX_SIZE:
        out.append(R("SIZE_RANGE", "fail", f"hi is {sr[1]}; sizes above {MAX_SIZE} are implausible (derive would be asked to build an instance of that size)"))
    elif not (_is_int(step) and step >= 1):
        out.append(R("SIZE_STEP", "fail", "if given, must be a positive integer literal"))
    elif (sr[1] - sr[0]) // step + 1 < (1 if lit.get("KIND") in NONSPEED_KINDS else MIN_SIZES):   # a speed ladder needs 3 sizes; the other kinds (compile_kinds.py) take whatever the declaration gives
        out.append(R("SIZE_RANGE", "fail", f"only {(sr[1] - sr[0]) // step + 1} sizes; the compiler needs a ladder of at least {MIN_SIZES}, so be generous"))
    else:
        out.append(R("SIZE_RANGE", "pass", f"{sr[0]}..{sr[1]} step {step} ({(sr[1] - sr[0]) // step + 1} sizes)"))

    out.append(R("REFERENCE_SOLVER", "pass", "reference.py") if lit.get("REFERENCE_SOLVER") == "reference.py"
               else R("REFERENCE_SOLVER", "fail", 'must be the literal "reference.py"'))

    note = lit.get("REFERENCE_NOTE", None)
    if isinstance(note, str) and len(note.strip()) >= MIN_NOTE:
        out.append(R("REFERENCE_NOTE", "pass", f"{len(note.strip())} characters"))
    else:
        out.append(R("REFERENCE_NOTE", "fail", f"required for a proposal: a string literal of at least {MIN_NOTE} characters saying what the reference algorithm is "
                                              "and what is known to beat it. A weak or undescribed baseline makes big speedups cheap, and nothing else can detect that"))
    doc = lit.get("DOC", None)
    out.append(R("DOC", "pass", f"{len(doc)} characters") if isinstance(doc, str) and doc.strip() and len(doc) <= 2000
               else R("DOC", "warn", "no DOC string literal (at most 2000 characters): solver authors need to know what solve() receives and must return"))

    for fname, want in (("derive", 3), ("verify", 2)):
        fn = fns.get(fname)
        if fn is None:
            out.append(R(fname, "fail", f"missing top-level `def {fname}(...)`"))
            continue
        n, extra, defaults = _params(fn)
        if n != want or extra or defaults:
            out.append(R(fname, "fail", f"must take exactly {want} plain positional parameters" +
                         (" (master, size, idx)" if fname == "derive" else " (inst, ans)")))
        else:
            out.append(R(fname, "pass", f"line {fn.lineno}"))
    w = fns.get("witness")
    if w is not None and (_params(w)[0] != 1 or _params(w)[1] or _params(w)[2]):
        out.append(R("witness", "fail", "if defined, must take exactly 1 plain positional parameter (inst)"))

    d = fns.get("derive")
    if d is not None and _params(d)[0] == 3:
        used = {n.id for n in ast.walk(d) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
        for p in [a.arg for a in d.args.args]:
            if p not in used:
                out.append(R("derive uses its arguments", "warn",
                             f"`{p}` is never read: an instance that ignores its seed, size or index makes the commitment commit to nothing (the compiler measures this too)"))
        rand = {a for a, m in _aliases_of(tree, "random").items()}
        for n in ast.walk(tree):
            if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in rand and n.attr not in ("Random",) and isinstance(n.ctx, ast.Load):
                out.append(R("global random", "warn", f"`random.{_clean(n.attr, 30)}` uses the global generator: derive must draw from random.Random(<seed built from master, size, idx>)"))
                break
    return out


def _aliases_of(tree, module):
    out = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.name == module:
                    out[a.asname or a.name] = module
    return out


def screen_reference(text):
    enc = _encoding_problem(text)
    if enc:
        return [R("reference.py encoding", "fail", enc)]
    try:
        tree = parse_source(text)
    except SyntaxError as e:
        return [R("reference.py syntax", "fail", f"{e.msg} (line {e.lineno})")]
    except (ValueError, RecursionError, MemoryError) as e:
        return [R("reference.py syntax", "fail", f"could not parse ({type(e).__name__})")]
    out = [R("reference.py rule", "fail", p) for p in (_top_level_shape(tree) + _rule_findings(tree, REF_IMPORTS, "reference"))[:MAX_FINDINGS]]
    solve = _functions(tree).get("solve")
    out.append(R("reference solve", "pass", f"line {solve.lineno}") if solve is not None
               else R("reference solve", "fail", "no top-level `def solve(...)` (called as solve(*args); it must return an int, a list of ints, or None)"))
    return out


def screen_files(files, expect_name=None):
    out = []
    if "decl.py" in files:
        out += screen_decl(files["decl.py"], expect_name)
    if "reference.py" in files:
        out += screen_reference(files["reference.py"])
    if "NOTES.md" in files and len(files["NOTES.md"]) > MAX_NOTES:
        out.append(R("NOTES.md", "fail", f"over {MAX_NOTES} characters"))
    return out


def declared_name(files):
    """NAME read from decl.py without running it (None if it is not a plain string literal)."""
    try:
        v = _literals(parse_source(files["decl.py"])).get("NAME")
    except (KeyError, SyntaxError, ValueError, RecursionError, MemoryError):
        return None
    return v if isinstance(v, str) else None


# ------------------------------------------------------------------------------------------------------------- the bundle
def bundle_hash(name, files):
    return hashlib.sha256(canon({"name": name, "files": files}).encode("ascii")).hexdigest()


def make_bundle(name, files, contact, now=None):
    now = now or datetime.datetime.now(datetime.timezone.utc)
    return {"format": FORMAT, "name": name, "contact": _clean(contact, MAX_CONTACT), "created": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "files": dict(files), "sha256": bundle_hash(name, files)}


def _no_dups(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise ValueError(f"duplicate key {k!r}")
        d[k] = v
    return d


def _no_const(c):
    raise ValueError(f"{c} is not allowed in a bundle")


def parse_bundle(raw):
    """-> (bundle or None, findings). Everything that crosses the trust boundary is checked here, before any file is written."""
    if len(raw) > MAX_BUNDLE:
        return None, [R("bundle", "fail", f"{len(raw)} bytes; the limit is {MAX_BUNDLE}")]
    try:
        b = json.loads(raw.decode("utf-8"), object_pairs_hook=_no_dups, parse_constant=_no_const)
    except (ValueError, RecursionError) as e:
        return None, [R("bundle", "fail", f"not valid JSON: {e}")]
    bad = lambda m: (None, [R("bundle", "fail", m)])
    if not isinstance(b, dict) or set(b) != {"format", "name", "contact", "created", "files", "sha256"}:
        return bad("must be an object with exactly: format, name, contact, created, files, sha256")
    if b["format"] != FORMAT:
        return bad(f"format must be {FORMAT!r}")
    if not (isinstance(b["name"], str) and NAME_RE.fullmatch(b["name"])):
        return bad("name must be 2-16 lowercase letters")
    if not (isinstance(b["contact"], str) and len(b["contact"]) <= MAX_CONTACT):
        return bad(f"contact must be a string of at most {MAX_CONTACT} characters")
    if not all(c.isprintable() for c in b["contact"]):
        return bad("contact contains control or non-printing characters (terminal escape sequences included)")
    if not (isinstance(b["created"], str) and re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ", b["created"])):
        return bad("created must look like 2026-11-22T12:00:00Z")
    if not isinstance(b["files"], dict) or not set(REQUIRED) <= set(b["files"]) or not set(b["files"]) <= set(FILES):
        return bad("files must hold decl.py and reference.py, and optionally NOTES.md, and nothing else")
    for fn, text in b["files"].items():
        limit = MAX_NOTES if fn == "NOTES.md" else MAX_FILE
        if not isinstance(text, str) or not text.strip() or "\x00" in text or len(text.encode("utf-8", "replace")) > limit:
            return bad(f"{fn} must be non-empty text without NUL bytes, at most {limit} bytes")
        try:
            text.encode("utf-8")
        except UnicodeEncodeError:
            return bad(f"{fn} is not valid text")
    if b["sha256"] != bundle_hash(b["name"], b["files"]):
        return bad("sha256 does not match the files (the bundle was altered or built by hand)")
    return b, []


def _fenced_blocks(text, limit=50):
    """The contents of the ``` fenced code blocks in `text`, in order (at most `limit`). A single linear pass over the lines: no regular expression, so
    a hostile body cannot make it slow. A fence that is never closed contributes nothing."""
    blocks, cur, inside = [], [], False
    for line in text.split("\n"):
        if line.strip().startswith("```"):
            if inside:
                blocks.append("\n".join(cur))
                cur = []
                if len(blocks) >= limit:
                    break
            inside = not inside
        elif inside:
            cur.append(line)
    return blocks


def extract_bundle(raw):
    """-> (bundle or None, findings). `raw` is a bundle file, or ordinary text (a GitHub issue body) with the bundle in a fenced code block: the first block
    that is a valid bundle wins. Either way the bundle goes through the same strict `parse_bundle`; this only finds it."""
    if len(raw) <= MAX_BUNDLE:
        b, res = parse_bundle(raw)
        if b is not None:
            return b, []
    else:   # an issue body can be larger than a bundle may be: say what is true of the input, not of a bundle
        res = [R("bundle", "fail", f"the input is {len(raw)} bytes, over the {MAX_BUNDLE}-byte bundle limit, and is not itself a bundle; "
                                   "in an issue body the bundle must be in a code block")]
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return None, res
    found = {}   # sha256 -> bundle: the SAME bundle pasted twice is one proposal, two different ones are ambiguous
    for block in _fenced_blocks(text.replace("\r\n", "\n")):
        cand = block.strip("\n").encode("utf-8")
        if len(cand) <= MAX_BUNDLE:
            b, _ = parse_bundle(cand)
            if b is not None:
                found.setdefault(b["sha256"], b)
    if len(found) == 1:
        return next(iter(found.values())), []
    if len(found) > 1:
        names = ", ".join(sorted(f"{x['name']}/{h[:8]}" for h, x in found.items()))
        return None, [R("bundle", "fail", f"the text holds {len(found)} different bundles ({names}): send one proposal per issue, so there is no doubt which one you meant")]
    return None, res if "```" not in text else [R("bundle", "fail", "no code block in the text holds a valid bundle (and the text is not a bundle itself)")]


# ------------------------------------------------------------------------------------------------------------- the intake folder and its log
def intake_dir():
    d = os.environ.get("SVP_INTAKE_DIR")
    if d:
        return d
    if "site-packages" in HERE or "dist-packages" in HERE:
        raise SystemExit("REFUSED: set SVP_INTAKE_DIR to a folder you back up. An installed package's own folder is replaced on upgrade, and the intake log is an audit trail.")
    return os.path.join(HERE, "intake")


def domains_dir():
    return os.environ.get("SVP_DOMAINS_DIR") or os.path.join(HERE, "domains")


def _write_new(path, text, mode=0o600):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
        f.write(text)


def _log_path():
    return os.path.join(intake_dir(), "log.jsonl")


def read_log():
    """-> (records, problems). The log is hash-chained: a changed, removed or reordered line is reported."""
    records, problems, prev = [], [], GENESIS
    try:
        with open(_log_path(), encoding="utf-8") as f:
            lines = f.read().split("\n")
    except OSError:
        return records, problems
    if lines and lines[-1] == "":
        lines.pop()
    for i, line in enumerate(lines, 1):
        try:
            r = json.loads(line)
            body = {k: v for k, v in r.items() if k != "hash"}
            ok = (r.get("seq") == i and r.get("prev") == prev and r.get("format") == LOG_FORMAT
                  and r.get("hash") == hashlib.sha256(canon(body).encode("ascii")).hexdigest())
        except (ValueError, AttributeError, TypeError, RecursionError):
            ok, r = False, None
        if not ok:
            problems.append(f"log line {i} is damaged, altered, or out of order")
            break
        records.append(r)
        prev = r["hash"]
    return records, problems


def append_log(event, name, bundle, detail=None, now=None):
    os.makedirs(intake_dir(), mode=0o700, exist_ok=True)
    now = now or datetime.datetime.now(datetime.timezone.utc)
    fd = os.open(_log_path(), os.O_RDWR | os.O_CREAT | os.O_APPEND, 0o600)
    with os.fdopen(fd, "r+", encoding="utf-8", newline="") as f:
        if fcntl:
            fcntl.flock(f, fcntl.LOCK_EX)
        records, problems = read_log()
        if problems:
            raise SystemExit("REFUSED: the intake log is damaged (" + problems[0] + "); nothing was recorded. Restore it from a backup first.")
        body = {"format": LOG_FORMAT, "seq": len(records) + 1, "time": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "event": event, "name": name,
                "bundle": bundle, "detail": detail or {}, "prev": records[-1]["hash"] if records else GENESIS}
        body["hash"] = hashlib.sha256(canon({k: v for k, v in body.items() if k != "hash"}).encode("ascii")).hexdigest()
        f.write(canon(body) + "\n")
        f.flush()
        os.fsync(f.fileno())
    return body


def states():
    """{(name, bundle sha256): {"events": [...], "state": str}} from the verified log."""
    records, problems = read_log()
    out = {}
    for r in records:
        e = out.setdefault((r["name"], r["bundle"]), {"events": [], "state": "received", "trial": None})
        e["events"].append(r)
        if r["event"] == "trial":
            e["trial"] = r["detail"].get("result")
        elif r["event"] in ("accepted", "rejected"):
            e["state"] = r["event"]
    return out, problems


def resolve(spec):
    """'name' or 'name/hashprefix' -> (name, full sha256, quarantine dir). Ambiguity is an error, never a guess."""
    name, _, prefix = spec.partition("/")
    if not NAME_RE.fullmatch(name):
        raise SystemExit(f"REFUSED: {_clean(spec, 60)!r} is not NAME or NAME/HASH")
    if prefix and not re.fullmatch(r"[0-9a-f]{6,64}", prefix.lower()):
        raise SystemExit(f"REFUSED: {_clean(prefix, 20)!r} is not a hash prefix (6 to 64 hex characters)")
    st, problems = states()
    if problems:
        raise SystemExit("REFUSED: the intake log is damaged (" + problems[0] + ")")
    hits = sorted(h for (n, h) in st if n == name and h.startswith(prefix.lower()))
    if not hits:
        raise SystemExit(f"REFUSED: nothing received under {spec!r} ({prog()} list)")
    if len(hits) > 1:
        raise SystemExit(f"REFUSED: {len(hits)} bundles match {spec!r}: " + ", ".join(h[:12] for h in hits) + "; give NAME/HASH")
    return name, hits[0], os.path.join(intake_dir(), name, hits[0][:12])


def load_quarantined(qdir, name, sha):
    """The bundle as it sits on disk NOW, verified against the hash it was received under."""
    try:
        with open(os.path.join(qdir, "bundle.json"), "rb") as f:
            b, problems = parse_bundle(f.read())
    except OSError:
        raise SystemExit(f"REFUSED: {qdir} is missing its bundle.json")
    if b is None or b["sha256"] != sha or b["name"] != name:
        raise SystemExit("REFUSED: the quarantined bundle is damaged or was changed after it was received: " + (problems[0]["detail"] if problems else "hash differs"))
    for fn, text in b["files"].items():
        try:
            with open(os.path.join(qdir, fn), encoding="utf-8", newline="") as f:
                on_disk = f.read()
        except OSError:
            raise SystemExit(f"REFUSED: {fn} is missing from {qdir}")
        if on_disk != text:
            raise SystemExit(f"REFUSED: {fn} in {qdir} differs from the bundle it was received in: it was edited after receipt")
    return b


# ------------------------------------------------------------------------------------------------------------- commands
def _print(results):
    for r in results:
        print(f"  {r['status'].upper():4s} {r['check']}: {r['detail']}")


def cmd_screen(a):
    files, res = read_dir(a.dir)
    if files and not any(r["status"] == "fail" for r in res):
        nm = declared_name(files)
        if nm and nm != os.path.basename(os.path.abspath(a.dir)):
            res.append(R("directory name", "warn", f"the directory is {os.path.basename(os.path.abspath(a.dir))!r} but NAME is {nm!r}; the compiler wants them equal, and the operator will create domains/{nm}"))
    res += screen_files(files) if files else []
    _print(res)
    if worst(res) == "fail":
        print("\nNOT ACCEPTABLE as a proposal: fix every FAIL line above.")
        return 1
    print("\nThe static screen passes" + (" (read the WARN lines)." if worst(res) == "warn" else ".") + " That is not approval: the operator reads both files before anything is compiled.")
    return 0


def cmd_pack(a):
    files, res = read_dir(a.dir)
    nm = declared_name(files) if files else None
    res += screen_files(files, expect_name=nm) if files else []
    if not nm:
        res.append(R("NAME", "fail", "could not read NAME from decl.py"))
    _print(res)
    if worst(res) == "fail":
        print("\nNothing written: fix every FAIL line above.")
        return 1
    if os.path.exists(a.out):
        print(f"REFUSED: {a.out} exists; nothing was overwritten.")
        return 1
    b = make_bundle(nm, files, a.contact or "")
    _write_new(a.out, json.dumps(b, indent=1, sort_keys=True) + "\n", 0o644)
    print(f"\nwrote {a.out}\n  bundle {b['sha256'][:12]}  NAME {nm}  files: {', '.join(sorted(files))}\n"
          f"Send it by opening an issue at {PROPOSALS_URL} titled `Proposal: {nm}` and pasting the whole file in a code block (if it is longer than GitHub's "
          "issue limit, attach it as a .txt file), one proposal per issue. The issue is PUBLIC, so use a GitHub handle as --contact, not a private address.\n"
          "By sending it you confirm you may share the code and let the project use and publish it and credit your handle (INTAKE.md, 'What you agree to').\n"
          "The operator reads your code before running it; keep REFERENCE_NOTE honest about what beats your baseline.")
    return 0


def cmd_receive(a):
    if a.file == "-":
        stream = getattr(sys.stdin, "buffer", None)   # bytes, so input that is not valid UTF-8 is refused below instead of raising out of a text read
        raw = stream.read(INPUT_MAX + 1) if stream is not None else sys.stdin.read(INPUT_MAX + 1).encode("utf-8", "replace")
    else:
        try:
            with open(a.file, "rb") as f:
                raw = f.read(INPUT_MAX + 1)
        except OSError as e:
            print(f"REFUSED: cannot read {_clean(a.file, 80)}: {e.strerror}")
            return 1
    if len(raw) > INPUT_MAX:
        print(f"REFUSED: the input is over {INPUT_MAX} bytes; nothing was written.")
        return 1
    b, res = extract_bundle(raw)
    if b is None:
        _print(res)
        print("\nREFUSED: not a valid bundle; nothing was written.")
        return 1
    res = screen_files(b["files"], expect_name=b["name"])
    _print(res)
    if worst(res) == "fail":
        print("\nREFUSED: the screen failed on the operator's side (the proposer's own pass does not count); nothing was written.")
        return 1
    st, problems = states()
    if problems:
        print("REFUSED: the intake log is damaged (" + problems[0] + ")")
        return 1
    sha = b["sha256"]
    q = os.path.join(intake_dir(), b["name"], sha[:12])
    if (b["name"], sha) in st:
        print(f"already received: {b['name']}/{sha[:12]} ({st[(b['name'], sha)]['state']}); nothing changed.")
        return 0
    others = sorted(h[:12] for (n, h) in st if n == b["name"] and h != sha and st[(n, h)]["state"] in ("received",))
    if others:
        print(f"  WARN another proposal for NAME {b['name']!r} is still pending: {', '.join(others)}. Only one can become domains/{b['name']}.")
    if os.path.isdir(os.path.join(domains_dir(), b["name"])):
        print(f"  WARN domains/{b['name']} already exists: `accept` will refuse until that is dealt with.")
    try:
        os.makedirs(q, mode=0o700, exist_ok=False)
    except FileExistsError:
        print(f"REFUSED: {q} already exists but the log has no record of it. Look at it, then move it aside; nothing was written.")
        return 1
    try:   # the folder is ours from here on: a failure removes exactly it, so no quarantine without a log record is left to block every retry
        _write_new(os.path.join(q, "bundle.json"), json.dumps(b, indent=1, sort_keys=True) + "\n")
        for fn, text in b["files"].items():
            _write_new(os.path.join(q, fn), text)
        _write_new(os.path.join(q, "SCREEN.txt"), "\n".join(f"{r['status'].upper():4s} {r['check']}: {r['detail']}" for r in res) + "\n")
        append_log("received", b["name"], sha, {"contact": b["contact"], "created": b["created"], "screen": worst(res), "screener": screener_id()})
    except BaseException:
        shutil.rmtree(q, ignore_errors=True)
        raise
    print(f"\nreceived {b['name']}/{sha[:12]}  (from: {_clean(b['contact'], MAX_CONTACT) or 'no contact given'})\nquarantined in {q}\n"
          f"next: READ {q}/decl.py and reference.py" + (" and NOTES.md (it may ask for something intake cannot do)" if "NOTES.md" in b["files"] else "") +
          f", then  {prog()} trial {b['name']}/{sha[:12]}")
    return 0


TRIAL_CPU = 300
TRIAL_WALL = 600
TRIAL_FSIZE = 16 * 1024 * 1024
TRIAL_MEM_MB = 3072


def _ps_table():
    """[(pid, ppid, rss_kb, command)] for every process. `ps` is the same on Linux and macOS, where RLIMIT_AS is not."""
    try:
        out = subprocess.run(["ps", "-axo", "pid=,ppid=,rss=,command="], capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    rows = []
    for line in out.splitlines():
        p = line.split(None, 3)
        if len(p) >= 3 and p[0].isdigit() and p[1].isdigit() and p[2].isdigit():
            rows.append([int(p[0]), int(p[1]), int(p[2]), p[3] if len(p) > 3 else ""])
        elif rows:
            rows[-1][3] += " " + line.strip()   # the rest of a command that contained raw newlines (the driver is a multi-line `python -c` script)
    return [tuple(r) for r in rows]


def _trial_pids(root_pid, scratch, table=None):
    """-> (set of pids, table). Every process that belongs to this trial: the child's whole process TREE, whatever session it is in (the harness runs the
    reference in a session of its own, outside the child's process group), plus anything whose command line names this trial's unique scratch directory
    (so an orphan already reparented to init is still found). This process is never in the set."""
    table = _ps_table() if table is None else table
    kids = {}
    for pid, ppid, _, _ in table:
        kids.setdefault(ppid, []).append(pid)
    mine, stack = set(), [root_pid] if root_pid else []
    while stack:
        for k in kids.get(stack.pop(), []):
            if k not in mine:
                mine.add(k)
                stack.append(k)
    if root_pid:
        mine.add(root_pid)
    tag = os.path.basename(scratch.rstrip(os.sep)) if scratch else ""   # the unique NAME, not the path: the compiler resolves symlinks (realpath), so a path
    mine |= {pid for pid, _, _, cmd in table if tag and tag in cmd}     # behind a symlinked TMPDIR is spelled differently in the reference's command line
    mine.discard(os.getpid())
    return mine, table


def _tree_rss_kb(root_pid, scratch):
    """Total resident memory (KiB) of every process of the trial, in any session; None when the process table could not be read at all (never 0: reading
    'cannot see' as 'uses nothing' would silently switch the memory limit off)."""
    mine, table = _trial_pids(root_pid, scratch)
    if not table:
        return None
    return sum(rss for pid, _, rss, _ in table if pid in mine)


def _die_on_signals():
    """SIGTERM and SIGHUP (a `kill`, a shutdown, a closed terminal) end Python with no cleanup at all, which would orphan the child exactly as Ctrl-C did.
    Turn them into SystemExit while a trial runs, so the cleanup above executes. -> a function that puts the old handlers back."""
    if threading.current_thread() is not threading.main_thread():
        return lambda: None

    def die(signum, frame):
        raise SystemExit(128 + signum)
    old = {s: signal.signal(s, die) for s in (signal.SIGTERM, signal.SIGHUP)}

    def restore():
        for s, handler in old.items():
            signal.signal(s, handler)
    return restore


def _kill_trial(proc, scratch):
    """Kill everything that belongs to this trial and reap the child. The child leads a process group of its own (it called setsid), but the reference
    and any orphan are in OTHER sessions, so they are found by `_trial_pids` (tree plus the trial's unique scratch path in the command line), never by a
    pattern that could match somebody else's process. `proc` may be None (a final sweep for stragglers after the child has already exited)."""
    mine, _ = _trial_pids(proc.pid if proc is not None else None, scratch)
    if proc is not None:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except OSError:
            proc.kill()
    for pid in mine:
        try:
            os.kill(pid, signal.SIGKILL)
            if os.getpgid(pid) == pid:   # a session leader (the reference runner): its own group may hold more
                os.killpg(pid, signal.SIGKILL)
        except OSError:
            pass
    if proc is not None:
        proc.wait()


def _limits(cpu):
    def apply():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))
        resource.setrlimit(resource.RLIMIT_FSIZE, (TRIAL_FSIZE, TRIAL_FSIZE))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
        if sys.platform.startswith("linux"):  # on macOS the address-space limit trips over the interpreter's own mappings; the RSS watcher covers both
            limit = (TRIAL_MEM_MB + 1024) * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
    return apply


def run_check(name, files, wall=None, cpu=None, mem_mb=None):
    """The compiler's parse and validate passes on a scratch copy, in a child with limits. -> (status, parsed results, output tail, note)."""
    wall = TRIAL_WALL if wall is None else wall
    cpu = TRIAL_CPU if cpu is None else cpu
    mem_mb = TRIAL_MEM_MB if mem_mb is None else mem_mb
    if resource is None:
        raise SystemExit("REFUSED: `trial` needs a Unix system (resource limits)")
    if os.geteuid() == 0:
        raise SystemExit("REFUSED: not as root. Run it as an unprivileged (ideally throwaway) user: this executes the proposer's code.")
    if not _ps_table():
        raise SystemExit("REFUSED: cannot read the process table (`ps -axo pid=,ppid=,rss=,command=` failed or is not supported here, as with BusyBox `ps`). "
                         "The trial's memory limit and its cleanup depend on it, so no child is started; install procps (or run it on another machine).")
    scratch = tempfile.mkdtemp(prefix="intake-trial-")
    restore_signals = _die_on_signals()
    proc = None
    try:
        target = os.path.join(scratch, "work", name)
        os.makedirs(target)
        os.makedirs(os.path.join(scratch, "none"))
        for fn in REQUIRED:
            _write_new(os.path.join(target, fn), files[fn])
        env = {"PATH": os.environ.get("PATH", ""), "HOME": scratch, "TMPDIR": scratch, "SVP_DOMAINS_DIR": os.path.join(scratch, "none"),
               "PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1"}
        outp = os.path.join(scratch, "out.txt")
        resultp = os.path.join(scratch, "result.json")
        with open(outp, "wb") as outf:
            note = ""
            try:
                proc = subprocess.Popen([sys.executable, "-c", _DRIVER, HERE, target, resultp], cwd=scratch, env=env,
                                        stdin=subprocess.DEVNULL, stdout=outf, stderr=subprocess.STDOUT, preexec_fn=_limits(cpu))
                deadline = time.monotonic() + wall
                blind = 0
                while True:
                    try:
                        proc.wait(timeout=0.5)
                        break
                    except subprocess.TimeoutExpired:
                        pass
                    rss = _tree_rss_kb(proc.pid, scratch)
                    blind = blind + 1 if rss is None else 0
                    why = (f"killed after {wall} s of wall-clock time" if time.monotonic() >= deadline
                           else "killed: the process table could not be read, so the memory limit cannot be enforced" if blind >= 3
                           else f"killed: memory over {mem_mb} MiB" if rss is not None and rss > mem_mb * 1024 else "")
                    if why:
                        _kill_trial(proc, scratch)
                        note = why
                        break
            except BaseException:
                if proc is not None:
                    _kill_trial(proc, scratch)   # the child is in its own session, so the operator's Ctrl-C never reaches it: without this it would be orphaned and keep running
                raise
        with open(outp, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 20000))
            tail = f.read().decode("utf-8", "replace")
        payload = None
        try:
            with open(resultp, "rb") as f:
                payload = f.read(RESULT_MAX + 1)
        except OSError:
            pass
        status, parsed, note = classify_results(proc.returncode, payload, note)
        return status, parsed, tail, note
    finally:
        restore_signals()
        _kill_trial(None, scratch)   # whatever of this trial is still running (an orphan of a driver that died on its own) goes before its directory does
        shutil.rmtree(scratch, ignore_errors=True)


# What the child runs: the compiler's own parse and validate passes (the ones `compile_domain.py check` runs), reported as DATA in a file. The verdict
# is read from that file and the exit status, never from the text the child printed: that text can contain anything a declaration puts in an
# exception message, so a crafted message could forge `PASS` lines or a final verdict line. Legal (screened) declaration code cannot open files.
# The first lines are a watchdog: if the operator's process is killed outright (SIGKILL cannot be handled, and the child lives in its own session), the
# child notices that its parent changed, kills every process that names this trial's scratch directory (the reference runs in a session of its own, so a
# group kill alone would miss it) and then its own process group, instead of running on until its CPU limit.
_DRIVER = '''import json, os, signal, sys, threading, time
_ppid = os.getppid()
def _watch_parent():
    while True:
        time.sleep(0.5)
        if os.getppid() != _ppid:
            try:
                import intake   # the same, tested process-table code the operator side uses (sys.path[0] is the project by now)
                scratch = os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[2])))
                for pid in intake._trial_pids(None, scratch)[0]:
                    try:
                        os.kill(pid, signal.SIGKILL)
                    except OSError:
                        pass
            except Exception:
                pass
            os.killpg(os.getpgrp(), signal.SIGKILL)
threading.Thread(target=_watch_parent, daemon=True).start()
sys.path.insert(0, sys.argv[1])
import compile_domain as C
d, out = sys.argv[2], sys.argv[3]
mod, ref, res = C.parse(d)
if C.worst(res) != "fail":
    if getattr(mod, "KIND", None) in C.KIND_NAMES:   # advantage / oracle / precomp / quantum: the kind's own validation (compile_kinds.py), not the speed passes
        import compile_kinds as K
        res += K.validate(K.load(d), d, ref, quick=True)
    else:
        res += C.validate(mod, d, ref, run_reference=True)
with open(out, "w", encoding="utf-8") as f:
    json.dump({"format": 1, "results": res}, f)
'''
RESULT_MAX = 1024 * 1024
RESULT_FORMAT = 1


def classify_results(returncode, payload, note=""):
    """-> (status, [(status, check, detail)], note) from the driver's exit status and result file. A PASS needs a clean exit AND a well-formed result file
    with at least one result and no failure; a crash, a kill, a missing or malformed file are all a FAIL (a declaration that breaks the compiler's own
    check must not be waved through)."""
    if returncode is not None and returncode < 0 and not note:
        note = f"the child was killed by signal {-returncode} (a CPU, memory or file-size limit)"
    if note:
        return "fail", [], note
    if returncode != 0:
        return "fail", [], f"the check process exited with status {returncode} before reporting any result (a crash inside the compiler's own check)"
    if payload is None:
        return "fail", [], "the check wrote no result file"
    if len(payload) > RESULT_MAX:
        return "fail", [], "the result file is implausibly large"
    try:
        data = json.loads(payload.decode("utf-8"), object_pairs_hook=_no_dups, parse_constant=_no_const)
    except (ValueError, RecursionError):
        return "fail", [], "the result file is not valid JSON"
    results = data.get("results") if isinstance(data, dict) and set(data) == {"format", "results"} and data["format"] == RESULT_FORMAT else None
    if not (isinstance(results, list) and 0 < len(results) <= 200 and all(
            isinstance(r, dict) and set(r) == {"check", "status", "detail"} and r["status"] in ("pass", "warn", "fail")
            and isinstance(r["check"], str) and isinstance(r["detail"], str) for r in results)):
        return "fail", [], "the result file has an unexpected shape"
    parsed = [(r["status"], _clean(r["check"], 60), _clean(r["detail"], 300)) for r in results]
    if any(p[0] == "fail" for p in parsed):
        return "fail", parsed, note
    return ("warn" if any(p[0] == "warn" for p in parsed) else "pass"), parsed, note


def _md(s):
    """Text that came from the proposer (contact, VERSION, the check's messages, the raw output) goes into REVIEW.md. Previewed in a markdown viewer, a raw
    `<img src=http://...>` would fetch a remote URL the proposer chose (telling them you looked), and a `[text](url)` would be a link to click, so neither
    markup nor link syntax survives; the original text is still in the quarantined files and in the log."""
    return str(s).replace("<", "&lt;").replace(">", "&gt;").replace("`", "'").replace("[", "(").replace("]", ")")


def _review(name, sha, b, screen, status, parsed, tail, note):
    def lines(text):
        return text.count("\n") + 1
    tree = parse_source(b["files"]["decl.py"])
    imports = sorted({a.name.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names} |
                     {n.module.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module})
    rows = ["# Intake review: " + name + " (bundle " + sha[:12] + ")", "",
            f"Received from: {_md(_clean(b['contact'], 200)) or 'no contact given'}; bundle created {b['created']}; full hash `{sha}`; screened by {screener_id()}.", "",
            "## Files", "", "| file | lines | sha256 |", "|---|---|---|"]
    for fn in sorted(b["files"]):
        rows.append(f"| {fn} | {lines(b['files'][fn])} | `{sha256_text(b['files'][fn])}` |")
    rows += ["", "## Static screen", ""] + [f"- {r['status'].upper()} {_md(r['check'])}: {_md(r['detail'])}" for r in screen]
    rows += ["", f"decl.py imports: {_md(', '.join(imports)) or 'none'}", "", "## The compiler's parse and validate passes (child process, CPU/file/memory limits, wall-clock kill; results come back as data, not as printed text)", "",
             f"Result: **{status.upper()}**" + (f" ({_md(note)})" if note else ""), ""]
    rows += [f"- {s.upper()} {_md(c)}: {_md(_clean(d, 300))}" for s, c, d in parsed]
    rows += ["", "<details><summary>raw output of the child (tail; untrusted text, never used for the verdict)</summary>", "", "```", _md("".join(ch if (ch.isprintable() or ch in "\n ") else "?" for ch in tail)).rstrip(), "```", "", "</details>", "",
             "## Read both files yourself before `accept` (this is the control; nothing above replaces it)", "",
             "- [ ] `derive` depends only on (master, size, idx), and the planted answer cannot be read off the arguments",
             "- [ ] `verify` is exact: it rejects everything that is not a real answer (the check above tried 19 junk values)",
             "- [ ] the reference is the plain, honest algorithm, and `REFERENCE_NOTE` says what beats it and by roughly how much",
             "- [ ] cost grows with size (otherwise the ladder cannot separate speedups) and the problem is worth certifying",
             "- [ ] nothing in either file is surprising: a helper you did not expect, an odd constant, a long precomputed table",
             "- [ ] you will compile it as an unprivileged throwaway user or VM (the compiler imports decl.py and runs the reference locally)", "",
             f"Then: `{prog()} accept {name}/{sha[:12]} --i-read-it`", ""]
    return "\n".join(rows)


def cmd_trial(a):
    name, sha, q = resolve(a.spec)
    b = load_quarantined(q, name, sha)
    screen = screen_files(b["files"], expect_name=name)
    if worst(screen) == "fail":
        print("REFUSED: the quarantined files no longer pass the screen (the rules changed since receipt?):")
        _print(screen)
        return 1
    print(f"trial {name}/{sha[:12]}: the compiler's checks in a limited child (wall {a.wall} s, cpu {TRIAL_CPU} s, memory {a.mem_mb} MiB) ...")
    status, parsed, tail, note = run_check(name, b["files"], wall=a.wall, mem_mb=a.mem_mb)
    for s, c, d in parsed:
        print(f"  {s.upper():4s} {c}: {_clean(d, 200)}")
    if note:
        print("  NOTE " + note)
    review = _review(name, sha, b, screen, status, parsed, tail, note)
    tmp = os.path.join(q, "REVIEW.md.tmp")
    if os.path.lexists(tmp):
        os.remove(tmp)   # a leftover from an interrupted trial, never trusted
    _write_new(tmp, review + "\n")
    os.replace(tmp, os.path.join(q, "REVIEW.md"))
    append_log("trial", name, sha, {"result": status, "note": note})
    print(f"\ntrial result: {status.upper()}   review written to {q}/REVIEW.md")
    if status == "fail":
        print("a FAIL cannot be accepted. Send the proposer the lines above; they can fix and pack again.")
        return 1
    print(f"next: read the files, then  {prog()} accept {name}/{sha[:12]} --i-read-it")
    return 0


def cmd_accept(a):
    if not a.i_read_it:
        print("REFUSED: pass --i-read-it to confirm you read decl.py and reference.py in full. decl.py runs in the judge's process; this flag is the control.")
        return 1
    name, sha, q = resolve(a.spec)
    st, _ = states()
    e = st[(name, sha)]
    if e["state"] in ("accepted", "rejected"):
        print(f"REFUSED: {name}/{sha[:12]} was already {e['state']}.")
        return 1
    if e["trial"] not in ("pass", "warn"):
        print(f"REFUSED: no passing trial on record (trial: {e['trial'] or 'not run'}). Run  {prog()} trial {name}/{sha[:12]}")
        return 1
    b = load_quarantined(q, name, sha)
    res = screen_files(b["files"], expect_name=name)
    if worst(res) == "fail":
        print("REFUSED: the files no longer pass the screen:")
        _print(res)
        return 1
    if name in BUILTIN:
        print(f"REFUSED: {name!r} is a built-in family.")
        return 1
    dest = os.path.join(domains_dir(), name)
    if os.path.lexists(dest):
        print(f"REFUSED: {dest} already exists; nothing was written. Choose another NAME with the proposer, or deal with the existing domain first.")
        return 1
    os.makedirs(domains_dir(), exist_ok=True)
    try:
        os.mkdir(dest, 0o755)
    except FileExistsError:   # it appeared after the check above: not ours, so nothing is touched
        print(f"REFUSED: {dest} already exists; nothing was written.")
        return 1
    # ours from here on: a failure below removes exactly this directory, so no half-accepted domain is left and the log never says accepted for it
    try:
        for fn in REQUIRED:
            _write_new(os.path.join(dest, fn), b["files"][fn], 0o644)
        append_log("accepted", name, sha, {"decl_sha256": sha256_text(b["files"]["decl.py"]), "reference_sha256": sha256_text(b["files"]["reference.py"])})
    except BaseException:
        shutil.rmtree(dest, ignore_errors=True)
        raise
    comp = "guldo compile" if prog().startswith("guldo") else "python3 compile_domain.py"
    print(f"accepted {name}/{sha[:12]} -> {dest}/decl.py and reference.py (no compiled.json: it is not a family yet)\n"
          f"next, as an unprivileged throwaway user or VM:\n"
          f"  {comp} compile {name}      # the real compile + self-test; tens of minutes to hours\n"
          f"  {comp} show {name}         # READY or NOT READY, and the exact next commands\n"
          f"then deploy domains/{name} with the code, and open a round when you choose (COMPILER.md; nothing about accepting a domain opens one).")
    return 0


def cmd_reject(a):
    reason = _clean(a.reason, 300)
    if not reason.strip():
        print("REFUSED: give a --reason (it goes in the log, and the proposer should hear it).")
        return 1
    name, sha, q = resolve(a.spec)
    st, _ = states()
    if st[(name, sha)]["state"] in ("accepted", "rejected"):
        print(f"REFUSED: {name}/{sha[:12]} was already {st[(name, sha)]['state']}.")
        return 1
    append_log("rejected", name, sha, {"reason": reason})
    print(f"rejected {name}/{sha[:12]}: {reason}\n(the quarantined files in {q} are kept)")
    return 0


def cmd_list(a):
    st, problems = states()
    if not st:
        print("no proposals received" + (" (but the log is damaged)" if problems else ""))
    for (name, sha), e in sorted(st.items(), key=lambda kv: kv[1]["events"][0]["seq"]):
        first = e["events"][0]
        trial = f", trial {e['trial']}" if e["trial"] else ""
        print(f"  {first['time']}  {name}/{sha[:12]}  {e['state'].upper()}{trial}  from {_clean(first['detail'].get('contact', ''), 60) or '-'}")
    if problems:
        print("\nLOG PROBLEM: " + "; ".join(problems) + "\nDo not accept anything until the log is restored from a backup.")
        return 1
    records = read_log()[0]
    print(f"\nintake log intact ({len(records)} entries). Head: {records[-1]['hash'][:16] if records else 'empty'}  "
          "(note it somewhere you cannot quietly edit: the chain shows a changed or removed middle, but only a recorded head shows a cut tail)")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="Propose a problem declaration (pack) and take proposals in (receive, trial, accept). See INTAKE.md.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("screen", help="static check of a declaration directory; never runs it")
    p.add_argument("dir")
    p = sub.add_parser("pack", help="screen, then write one bundle file to send to the operator")
    p.add_argument("dir")
    p.add_argument("--out", required=True)
    p.add_argument("--contact", default="", help="how the operator can reach you (shown in the queue; the issue you send it in is public, so a GitHub handle, not a private address)")
    p = sub.add_parser("receive", help="operator: re-screen a bundle and quarantine it")
    p.add_argument("file", help="a bundle file, or text (such as a GitHub issue body) with the bundle in a code block; '-' reads standard input")
    p = sub.add_parser("trial", help="operator: run the compiler's parse and validate passes on the quarantined copy in a limited child")
    p.add_argument("spec")
    p.add_argument("--wall", type=int, default=TRIAL_WALL, help="wall-clock seconds before the child is killed")
    p.add_argument("--mem-mb", type=int, default=TRIAL_MEM_MB, help="resident memory (MiB, whole process group) before the child is killed")
    p = sub.add_parser("accept", help="operator: copy into domains/NAME after reading it")
    p.add_argument("spec")
    p.add_argument("--i-read-it", action="store_true")
    p = sub.add_parser("reject", help="operator: record a refusal")
    p.add_argument("spec")
    p.add_argument("--reason", required=True)
    sub.add_parser("list", help="the queue and the log's integrity")
    a = ap.parse_args(argv)
    return {"screen": cmd_screen, "pack": cmd_pack, "receive": cmd_receive, "trial": cmd_trial, "accept": cmd_accept, "reject": cmd_reject, "list": cmd_list}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
