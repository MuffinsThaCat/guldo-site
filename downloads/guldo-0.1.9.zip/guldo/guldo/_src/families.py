"""Domain registry. A domain (family) is (derive(master, size, idx) -> inst, verify(inst, answer) -> bool) plus per-family
configuration below. An instance dict must carry "args": the JSON-serializable list the solver receives as solve(*args).
Lattice families supply (basis, bound2) as their args; factoring supplies (N,). Everything downstream of this file (harness,
estimator, judge, report, portal) is domain-neutral. To add a domain: write instances_<x>.py, then fill in every table here
(test_domains.py checks the configuration is complete). Or declare the domain and let compile_domain.py fill the tables (COMPILER.md)."""
import os
import sys

import instances
import instances_factor
import instances_mlwe

HERE = os.path.dirname(os.path.abspath(__file__))
DECLARED = {}         # name -> {"dir", "compiled", "decl_sha256"} for domains registered from domains/<name>/ by declared.load_all (see COMPILER.md)
DECLARED_ERRORS = {}  # directory name -> why a declaration under domains/ was NOT registered (stale compile, bad declaration, name clash)

FAMILIES = {
    "gm": (instances.derive, instances.verify),
    "mlwe": (instances_mlwe.derive, instances_mlwe.verify),
    "factor": (instances_factor.derive, instances_factor.verify),
}
VERSIONS = {"gm": "svp-gm-v2", "mlwe": "mlwe-v2", "factor": "factor-v1"}  # bump when a derive() changes; recorded in every results file
# Official-run thresholds per family. GM needs more instances and a larger cap: at (12 inst, 60 s) the baseline times
# out at dims >= 68 and an honest ~1-bit pruning speedup is not certifiable (measured twice on real data).
OFFICIAL = {"gm": {"n": 24, "budget": 120}, "mlwe": {"n": 12, "budget": 60}, "factor": {"n": 24, "budget": 120}}
# Ladders are tuned to the DEFAULT baseline (baseline_bkz): dims below its 0.5 s cost floor can never be used. A different
# baseline needs its own ladder (judge.py evaluate --dims ...).
DEFAULT_DIMS = {
    "gm": [64, 66, 68, 70, 72],
    "mlwe": [97, 105, 113, 121, 129, 137],
    "factor": [58, 60, 62, 64],  # bits of N; trial division costs ~1 s at 52 bits and doubles every 2 bits
}
# The reference solver instances are compared against, per family (paths relative to the project directory).
DEFAULT_BASELINE = {"gm": "solvers/baseline_bkz.py", "mlwe": "solvers/baseline_bkz.py", "factor": "solvers/factor_trial_py.py"}
# Small public sizes for `submit_check.py`: quick well-formedness checks, not performance.
PRACTICE_DIMS = {"gm": [24, 30, 36], "mlwe": [33, 49], "factor": [36, 40]}


def derive(family, master, dim, idx):
    inst = FAMILIES[family][0](master, dim, idx)
    inst["family"] = family
    if "args" not in inst:  # lattice families: the solver receives (basis, bound2)
        inst["args"] = [inst["basis"], inst["bound2"]]
    return inst


def verify(inst, v):
    return FAMILIES[inst.get("family", "gm")][1](inst, v)


import declared  # noqa: E402  (needs the tables above to exist)

declared.load_all(sys.modules[__name__])  # compiled declarations under domains/ become families like the built-in three
