"""aizero in the cluster-counted API, CHEAT: ZeRO stage 2 with the gradient reduction skipped, each device updating its shard from ITS OWN rows' gradient (scaled up by 8). No reduction, and not the gradient: the judge must reject it."""
import tensorops as tp

LR, B1, B2, EPS = 0.01, 0.9, 0.999, 1e-8
STEPS = 3


def ints(theta):
    return list(map(int, (theta * 1099511627776.0).tolist()))


def adam_update(theta, m, v, g, t):
    """One Adam step on whatever slice the device holds (the whole vector or its shard)."""
    m = m * B1 + g * (1 - B1)
    v = v * B2 + g * g * (1 - B2)
    theta = theta - (m * (1.0 / (1 - B1 ** t))) / (tp.sqrt(v * (1.0 / (1 - B2 ** t))) + EPS) * LR
    return theta, m, v


def local_grad(theta, X, y, B):
    """The gradient contribution of the rows in X: X^T (X theta - y) / B (the loss is averaged over the WHOLE batch B)."""
    r = X @ theta - y
    return tp.transpose(X, (1, 0)) @ r * (1.0 / B)


def solve(seed, d, B, P):
    n = 128 * d
    rb = B // P
    sh = n // P
    Xs, ys = [], []
    for r in range(P):
        tp.use(r)
        Xs.append(tp.reshape(tp.stream(seed, n + r * rb * n, rb * n), (rb, n)))
        ys.append(tp.stream(seed, n + B * n + r * rb, rb))
    thetas, ms, vs = [], [], []
    for r in range(P):
        tp.use(r)
        thetas.append(tp.stream(seed, 0, n) * 0.1)
        ms.append(tp.zeros((sh,)))
        vs.append(tp.zeros((sh,)))
    for t in range(1, STEPS + 1):
        news = []
        for r in range(P):
            tp.use(r)
            g = local_grad(thetas[r], Xs[r], ys[r], B) * float(P)
            new, ms[r], vs[r] = adam_update(thetas[r][r * sh:(r + 1) * sh], ms[r], vs[r], g[r * sh:(r + 1) * sh], t)
            news.append(new)
        thetas = tp.all_gather(news)
    return ints(thetas[0])
