"""Verify sandbox/meter.py on any Linux machine, WITHOUT Docker. Needs root (the meter drops the solver to an unprivileged
uid) and the project checked out. Intended for a throwaway VM or CI runner:

    sudo python3 sandbox/linux_selftest.py

It feeds the red-team solvers through meter.py exactly as the container entrypoint would and checks:
  * an orphaned child burning 4 CPU-s is BILLED (>= 3.5 s), not hidden
  * a double-forked daemon burning 4 CPU-s is billed
  * a sleeping daemon holding the stdout pipe cannot hang the meter (it finishes, flagged overrun, within the deadline)
  * the solver runs as the unprivileged uid and cannot setuid(0)
Exit 0 = all pass. It does NOT test the Docker flags (read-only fs, no network, pid cap): those need the container.
STATUS: written on macOS; never executed on Linux.
"""
import json
import os
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
UID = 54321  # unprivileged uid for the solver; created if missing


def ensure_user():
    r = subprocess.run(["id", str(UID)], capture_output=True)
    if r.returncode:
        subprocess.run(["useradd", "-M", "-u", str(UID), "-s", "/usr/sbin/nologin", "svpsolver"], check=True)


def run_meter(solver_src, budget=3):
    """Run solver source through meter.py; returns (parsed meter JSON, wall seconds)."""
    with tempfile.TemporaryDirectory() as td:
        os.chmod(td, 0o755)
        path = os.path.join(td, "submission.py")
        with open(path, "w") as f:
            f.write(solver_src)
        os.chmod(path, 0o644)
        env = {"PATH": os.environ.get("PATH", ""), "BUDGET": str(budget), "SOLVER_UID": str(UID),
               "RUNNER": os.path.join(ROOT, "runner.py")}
        t0 = time.time()
        r = subprocess.run([sys.executable, os.path.join(HERE, "meter.py"), path], input=json.dumps(
            {"basis": [[1]], "bound2": 1}).encode(), capture_output=True, env=env, timeout=budget * 3 + 40)
        wall = time.time() - t0
        return json.loads(r.stdout.decode().strip().splitlines()[-1]), wall


ORPHAN = """
import os, sys, time
def solve(basis, bound2):
    if os.fork() == 0:
        t = time.process_time()
        while time.process_time() - t < 4.0: pass
        sys.stdout.write("null"); sys.stdout.flush(); os._exit(0)
    os._exit(0)
"""
DAEMON = """
import os, time
def solve(basis, bound2):
    if os.fork() == 0:
        os.setsid()
        if os.fork() == 0:
            for fd in (0, 1, 2): os.close(fd)
            t = time.process_time()
            while time.process_time() - t < 4.0: pass
        os._exit(0)
    return None
"""
SLEEPER = """
import os, time
def solve(basis, bound2):
    if os.fork() == 0:
        os.setsid()
        while True: time.sleep(1)
    os._exit(0)
"""
WHOAMI = """
import os
def solve(basis, bound2):
    try:
        os.setuid(0); root = True
    except PermissionError:
        root = False
    raise RuntimeError(repr({"uid": os.getuid(), "can_setuid_root": root}))
"""


def main():
    if not sys.platform.startswith("linux") or os.geteuid() != 0:
        print("SKIP: needs Linux and root")
        return 0
    ensure_user()
    failures = []

    def check(name, cond, detail):
        print(("PASS " if cond else "FAIL ") + name + "  " + detail)
        if not cond:
            failures.append(name)

    m, wall = run_meter(ORPHAN, budget=10)
    check("orphaned child CPU is billed", m["cpu"] >= 3.5, f"billed {m['cpu']:.2f}s of ~4.0s real")
    m, wall = run_meter(DAEMON, budget=10)
    check("detached daemon CPU is billed", m["cpu"] >= 3.5, f"billed {m['cpu']:.2f}s of ~4.0s real")
    m, wall = run_meter(SLEEPER, budget=2)  # deadline = 2*3+10 = 16 s
    check("sleeping daemon cannot hang the meter", wall < 40 and m["overrun"], f"returned after {wall:.1f}s overrun={m['overrun']}")
    left = subprocess.run(["pgrep", "-u", str(UID)], capture_output=True, text=True).stdout.split()
    check("no solver processes are left behind", not left, f"left: {left}")
    m, _ = run_meter(WHOAMI, budget=5)
    check("solver is unprivileged and cannot setuid(0)", f"'uid': {UID}" in m["err"] and "'can_setuid_root': False" in m["err"],
          m["err"].strip().splitlines()[-1][:120] if m["err"].strip() else "no stderr")
    print("\nALL PASS" if not failures else f"\nFAILED: {failures}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
