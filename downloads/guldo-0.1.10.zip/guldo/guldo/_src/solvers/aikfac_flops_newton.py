"""aikfac in the counted-operations API, TECHNIQUE: full Newton. Form the exact 8n x 8n Hessian as a block matrix (block (k, l) = X^T diag(F[:, k, l]) X / N with F = diag(p) - p p^T per sample, plus lambda I), solve H step = gradient exactly by Gauss-Jordan, step, repeat until |g|^2 is small enough. The variables are ordered class-major (index k*n + a) so the blocks are contiguous. It costs about N (8n)^2 + (8n)^3 per iteration."""
import math

import tensorops as tp

K = 8
RHO = 0.9
LAM = 1e-3
GRAD2 = 2e-13          # gap <= |g|^2 / (2 lambda) <= 1e-10 (a margin of 100 under the judge's 1e-8)


def features(seed, n, N):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(n)] for k in range(n)])
    return (tp.reshape(tp.stream(seed, 0, N * n), (N, n)) @ U) * math.sqrt(1.0 - RHO * RHO)


def onehot(labels, N):
    return tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(N)])


def softmax(S):
    E = tp.exp(S - tp.max(S, 1, True))
    return E / tp.sum(E, 1, True)


def answer(W, n):
    return [int(v * 1048576.0) for v in tp.reshape(W, (n * K,)).tolist()]
MAXITER = 30


def solve_spd(H, g, m):
    A = tp.concat([H, tp.reshape(g, (m, 1))], 1)
    for j in range(m):
        row = A[j:j + 1] / A[j:j + 1, j:j + 1]
        M = A - A[:, j:j + 1] * row
        A = tp.concat([M[0:j], row, M[j + 1:m]], 0)
    return tp.reshape(A[:, m:m + 1], (m,))


def solve(seed, n, N, labels):
    X = features(seed, n, N)
    Y = onehot(labels, N)
    Xt = tp.transpose(X, (1, 0))
    m = n * K
    eye = tp.tensor([[LAM if i == j else 0.0 for j in range(m)] for i in range(m)])
    W = tp.zeros((n, K))
    for it in range(MAXITER):
        P = softmax(X @ W)
        G = Xt @ (P - Y) * (1.0 / N) + W * LAM
        if tp.sum(G * G).item() <= GRAD2:
            break
        cols = [P[:, k:k + 1] for k in range(K)]
        rows = []
        for k in range(K):
            blocks = []
            for l in range(K):
                f = cols[k] * (1.0 - cols[k]) if k == l else (cols[k] * cols[l]) * -1.0
                blocks.append(tp.transpose(X * f, (1, 0)) @ X)
            rows.append(tp.concat(blocks, 1))
        H = tp.concat(rows, 0) * (1.0 / N) + eye
        step = solve_spd(H, tp.reshape(tp.transpose(G, (1, 0)), (m,)), m)
        W = W - tp.transpose(tp.reshape(step, (K, n)), (1, 0))
    return answer(W, n)
