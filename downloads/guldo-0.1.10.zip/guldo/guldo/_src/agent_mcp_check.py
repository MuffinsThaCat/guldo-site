"""Drive the tool service with a REAL third-party MCP client (the official `mcp` Python SDK), to show that an off-the-shelf MCP agent product can be evaluated through it.

  pip install mcp        (Python 3.10+; kept out of the project's own requirements)
  python3 agent_mcp_check.py http://HOST:PORT/mcp/ARM_TOKEN [--tasks N] [--practice]

For each task it opens a new MCP connection (initialize starts a task), reads the task text from the server `instructions`, lists the tools, calls `describe`, makes one deliberately bad call (the
result must come back as an MCP tool error, not a protocol failure) and submits. With --practice the answer is computed from the PUBLIC practice seed (a cheating vendor: the point is the protocol, not the
agent); without it the task is attempted with describe only and submitted as 0 (it will fail, and the transcript is still valid).

Exit code 0 iff every task completed through the SDK client without a protocol error. This file is a checking tool: it is not part of any result.
"""
import argparse
import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import agent_core


async def one_task(url, table):
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    async with streamable_http_client(url) as streams:
        async with ClientSession(streams[0], streams[1]) as session:
            init = await session.initialize()
            names = sorted(t.name for t in (await session.list_tools()).tools)
            d = await session.call_tool("describe", {})
            bad = await session.call_tool("aggregate", {"op": "nope", "column": "x"})
            answer = table.get(init.instructions, 0) if table else 0
            r = await session.call_tool("submit", {"answer": answer})
            return {"server": init.server_info.name, "protocol": init.protocol_version, "tools": names, "describe_error": bool(d.is_error), "bad_call_is_tool_error": bool(bad.is_error),
                    "submit": r.content[0].text}


async def main(url, tasks, practice):
    table = {}
    if practice:
        mod = agent_core.load_domain("dataanalysis")
        for i in range(tasks):
            inst = agent_core.make_instance(mod, agent_core.PRACTICE_SEED, 200, i)
            table[mod.prompt(inst["public"])] = inst["private"]["answer"]
    out = []
    for _ in range(tasks):
        out.append(await one_task(url, table))
    return out


def run(url, tasks=2, practice=True):
    return asyncio.run(main(url, tasks, practice))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("url")
    ap.add_argument("--tasks", type=int, default=2)
    ap.add_argument("--practice", action="store_true")
    a = ap.parse_args()
    try:
        for r in run(a.url, a.tasks, a.practice):
            print(r)
    except Exception as e:
        print("FAILED: %s: %s" % (type(e).__name__, e), file=sys.stderr)
        sys.exit(1)
