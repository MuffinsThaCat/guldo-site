"""aimoed in the cluster-counted API, REFERENCE: one device runs the whole layer, regenerating each expert just in time (its working set fits the device capacity) and running only the tokens routed to it. No communication; nothing is parallel."""
import math

import tensorops as tp

E = 8
BIAS = (0.0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9, 1.05)


def ints(Y):
    return list(map(int, (Y * 1073741824.0).tolist()))


def expert_weights(seed, d, T, e):
    o = T * d + d * E + e * 4 * d * d
    W1 = tp.reshape(tp.stream(seed, o, 2 * d * d), (d, 2 * d)) * math.sqrt(6.0 / d)
    W2 = tp.reshape(tp.stream(seed, o + 2 * d * d, 2 * d * d), (2 * d, d)) * math.sqrt(3.0 / (2 * d))
    return W1, W2


def route_ids(x, R, bias):
    """The expert of each row of x: argmax of the scores plus the bias (lowest index on ties), as a Python list."""
    rows = (x @ R + bias).tolist()
    return [row.index(max(row)) for row in rows]


def solve(seed, d, T, P):
    tp.use(0)
    X = tp.reshape(tp.stream(seed, 0, T * d), (T, d))
    R = tp.reshape(tp.stream(seed, T * d, d * E), (d, E)) * math.sqrt(3.0 / d)
    ids = route_ids(X, R, tp.reshape(tp.tensor(list(BIAS)), (1, E)))
    order = []
    ys = []
    for e in range(E):
        idx = [t for t in range(T) if ids[t] == e]
        if idx:
            W1, W2 = expert_weights(seed, d, T, e)
            ys.append(tp.relu(tp.take(X, idx) @ W1) @ W2)
            order += idx
    inv = [0] * T
    for pos, t in enumerate(order):
        inv[t] = pos
    return ints(tp.reshape(tp.take(tp.concat(ys, 0), inv), (T * d,)))
