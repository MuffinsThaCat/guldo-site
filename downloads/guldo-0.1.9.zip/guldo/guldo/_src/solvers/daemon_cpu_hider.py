"""Red-team: classic double-fork daemon. The worker detaches (setsid, closes stdio) and keeps burning CPU after the
solver 'finishes'; the answer is returned immediately. Correct metering waits for / kills it and bills its CPU."""
import os
import time


def solve(basis, bound2):
    if os.fork() == 0:
        os.setsid()
        if os.fork() == 0:
            for fd in (0, 1, 2):
                os.close(fd)
            t = time.process_time()
            while time.process_time() - t < 4.0:
                pass
        os._exit(0)
    return None
