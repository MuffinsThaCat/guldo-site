"""Declaration of a mixed-precision domain: minimise a correlated-feature logistic-regression loss to within 1e-6 of its exact minimum, moving as few BYTES as you can.

size = d, the number of features. The training set holds N = 16 d points; feature j is an exponentially smoothed sum of the first j+1 independent uniform columns of the SplitMix64 stream
(X[i][j] = sqrt(1 - 0.9^2) * sum_{k <= j} 0.9^(j-k) * Z[i][k]), so the loss is moderately ill-conditioned (condition number about 60 to 300) and gradient descent takes thousands of small
steps. The labels are noisy, so the loss has a finite minimiser:  L(w) = mean_i log(1 + exp(-(2 y_i - 1) x_i . w)) + (LAMBDA / 2) |w|^2 with LAMBDA = 1e-3, fully determined by the instance's
arguments (nothing is hidden). The judge computes the exact minimiser L* (damped Newton in float64) and accepts an answer iff  L(w) - L* <= EPS = 1e-6.

WHY PRECISION MATTERS HERE. The tolerance is the point. An accuracy-only target (as in `aitrain`) is met by fp16 training just as well as by fp64, so it cannot tell a careful mixed-precision
recipe from careless low precision. A loss tolerance of 1e-6 can: with weights held in fp16, a gradient step smaller than half a unit in the last place of the weight (about 5e-4 at weight 1)
is LOST, so the iteration stalls far from the minimum along the ill-conditioned directions, and a pure fp16 run ends at a loss gap of about 1e-4 to 3e-3 (measured, see the notes in
PROTOCOL.md), between 70 and 3000 times over the tolerance. The standard remedy is the one this domain exists to test: compute the forward and backward matrix products on fp16 copies, keep the softmax,
the residual and the weight update in fp32 and keep MASTER weights in fp32, scaling the residual before the fp16 gradient product so that small values do not underflow (and not so much that the
sum overflows: loss scaling that is too large turns the run into NaNs). That reaches a gap of about 1e-8 to 5e-8 and moves about 0.64 of the bytes of fp32 (1.55x fewer, measured: the casts cost bytes too) and about a third of fp64's.

The answer is the d weights as a flat list of d INTEGERS in units of 2^-20. The cost compared is BYTES MOVED (tflops_mem.py: shapes and declared precisions, no cache, no fusion), with the
operation count shown beside it: it is an accounting convention anyone can recompute exactly, not a measurement of any memory system or tensor core. Python rounds each result to its width (a
solver that works in fp16 gets fp16 results, not float64 ones relabelled), so a technique that loses accuracy by lowering precision loses it here too and the judge sees it.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aimixed"
VERSION = "aimixed-v1"       # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 48)
SIZE_STEP = 8
REFERENCE_SOLVER = "reference.py"
RHO = 0.9                     # smoothing of the feature columns: the source of the correlation
LAMBDA = 1e-3                 # L2 regularisation: makes the loss strictly convex
N_PER_D = 16                  # training points per feature
EPS = 1e-6                    # the largest loss gap L(w) - L* the judge accepts
SCALE = 2 ** 20               # the answer's integers are weights in units of 1/SCALE
LIMIT = 2 ** 62               # no weight integer may exceed this in size
DOC = ("solve(seed, d, N, labels): the N = 16 d features are X[i][j] = sqrt(1-0.9^2) * sum_{k<=j} 0.9^(j-k) * Z[i][k] where Z[i][k] is the (i*d+k)-th float of the SplitMix64 stream under "
       "`seed` (tensorops.stream(seed, 0, N*d)); labels is the list of N classes (ints 0 or 1). Return the d weights of the L2-regularised logistic regression "
       "L(w) = mean_i log(1+exp(-(2y_i-1) x_i.w)) + 0.5e-3 |w|^2 as a flat list of d integers in units of 2^-20, whose loss is within 1e-6 of the exact minimum. Return None for no answer.")
REFERENCE_NOTE = ("Plain full-batch gradient descent in float64 with the safe step 1/L, L = |X|_F^2 / (4N) + lambda, 10000 steps (the slowest of 150 calibration instances reached a tenth of the "
                  "tolerance within 8700). Known to be matched on bytes by fp32 (half) and beaten by mixed precision (fp16 products, fp32 master weights and update, a loss scale): "
                  "fp16 everywhere fails the tolerance.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _mixing(d):
    """U[k][j] = RHO^(j-k) for k <= j, else 0 (so X = sqrt(1-RHO^2) * Z @ U)."""
    k = np.arange(d)
    return np.triu(RHO ** np.clip(k[None, :] - k[:, None], 0, None))


def _features(seed, d, n):
    return (_uniform(seed, 0, n * d).reshape(n, d) @ _mixing(d)) * math.sqrt(1.0 - RHO * RHO)


def _seed(master, tag, size, idx):
    return int.from_bytes(hmac.new(master, f"aimixed-v1:{tag}:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def loss(X, y, w):
    return float(np.mean(np.logaddexp(0.0, -(2.0 * y - 1.0) * (X @ w))) + 0.5 * LAMBDA * (w @ w))


def minimiser(X, y):
    """The exact minimiser: damped Newton in float64 (the Hessian is positive definite because LAMBDA > 0). -> (w, L*)."""
    n, d = X.shape
    w = np.zeros(d)
    cur = loss(X, y, w)
    for _ in range(100):
        p = 1.0 / (1.0 + np.exp(-(X @ w)))
        g = X.T @ (p - y) / n + LAMBDA * w
        H = (X.T * (p * (1.0 - p))) @ X / n + LAMBDA * np.eye(d)
        step = np.linalg.solve(H, g)
        t = 1.0
        while t > 1e-12:
            nxt = loss(X, y, w - t * step)
            if nxt <= cur:
                break
            t *= 0.5
        w, done = w - t * step, cur - nxt < 1e-16
        cur = min(cur, nxt)
        if done and np.linalg.norm(g) < 1e-9:
            break
    return w, loss(X, y, w)


def derive(master: bytes, size: int, idx: int) -> dict:
    d = size
    n = N_PER_D * d
    seed, wseed, lseed = (_seed(master, t, size, idx) for t in ("train", "teacher", "noise"))
    X = _features(seed, d, n)
    wstar = _uniform(wseed, 0, d) * 3.0 / math.sqrt(d)
    y = ((_uniform(lseed, 0, n) + 1.0) / 2.0 < 1.0 / (1.0 + np.exp(-2.0 * (X @ wstar)))).astype(np.int64)
    w, _ = minimiser(X, y.astype(np.float64))
    return {"args": [seed, d, n, [int(v) for v in y]], "planted": [int(v) for v in np.rint(w * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, d, n, labels = inst["args"]
    if not isinstance(ans, list) or len(ans) != d:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    X, y = _features(seed, d, n), np.asarray(labels, dtype=np.float64)
    _, best = minimiser(X, y)
    return bool(loss(X, y, np.array(ans, dtype=np.float64) / SCALE) - best <= EPS)
