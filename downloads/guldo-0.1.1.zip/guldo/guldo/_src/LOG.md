# The certificate log

`translog.py` (`guldo log ...` once installed). A public, append-only, witnessed record of verified certificates.

A certificate already proves its own arithmetic to whoever holds the file. What it cannot do is make a measurement **findable**, **permanent** and **ordered**.
The log adds exactly those three things and nothing else. It does not re-prove what certificates prove, and it does not make a timing honest.

## What it proves, precisely

| claim | how it is shown | who must be trusted |
|---|---|---|
| this certificate was in the log at head H | an inclusion proof: a Merkle path from the entry to H's root, plus H's signature | nobody, offline |
| the log only grew between two heads | a consistency proof, or recomputing both roots from `entries.jsonl` | nobody |
| the operator told everyone the same story | witnesses co-sign each head after checking it extends the last one they saw; if it ever does not, the witness holds a file (`check-evidence`) that proves one key signed two histories | at least one witness a reader pinned |
| an entry says what its certificate says | recompute the entry from the certificate (`check --recheck`): credit, status, flags and rules version are all derived | nobody |
| no logged certificate reaches T bits on problem P | an absence claim anyone recomputes from the entries | nobody, but see scope |
| a certificate was re-executed by key K, or K's own sandbox records are its ladders | an attestation / run entry in the same tree, signed by K, checked against the logged certificate | K (whom YOU pin) |
| this measurement is logged once | `measurement_sha256`: an edited copy is refused, a strict upgrade (seeds revealed, solver public, round log) is admitted | nobody: any reader enforces it from the entries |

## What it does NOT prove (read this before quoting the log)

* **Absence is "not submitted", not "does not exist".** Nothing forces anyone to submit. Certificate Transparency's "absent means not issued" works because browsers refuse
  certificates without a log proof. Nothing here has that forcing function, so every absence claim carries its scope in its own file.
* **A logged credit is not, by itself, a verified speed, and `OFFICIAL` is not evidence.** The credit is what the certificate recomputes to. In a timed certificate the clock readings are the submitter's own:
  nothing in the certificate stops anyone writing them. `OFFICIAL` is worse: it is derived from run metadata (`sandbox`, `cpu`, `n`, `budget`) that sits **inside the certificate**. The audit
  rewrote those fields in a self-built certificate's ladder headers and it verified as OFFICIAL, so the log records the status but never filters, ranks or vouches by it (there is no
  "official only" option, and the Log page says so). What the log CAN do is make the stronger claims *attributable*: see "Evidence" below. The tiers, weakest to strongest, are:
  *as logged* (whatever the entries say), *re-checked* (a reader recomputed the entry from its certificate: arithmetic and fairness, not clocks), *re-executed* (a key **you** pinned signed that it
  re-ran instances and its checks passed, including the re-run) and *run* (a key you pinned, the sandbox operator's, signed that its OWN records of the run are the certificate's ladders). The last two are
  exactly as trustworthy as the signer and their machine, and no `run` statement can exist until an official round has been run in the sandbox, which has not happened.
* **Witnesses the operator lists are not independent.** `trusted.txt` is written by the operator, so the Log page reports "named by its operator", never "independent". Only keys *you* pin count for you.
* **An old head is still a valid head.** A mirror that stopped updating looks like a log that stopped. `check` reports the head's age and `--max-age-hours N` makes it fatal.
* **Timings.** The log verifies that the certificate's arithmetic and fairness checks pass; whether the recorded timings were honest is a separate question. Step-counted certificates can close that gap for
  pure-Python solvers, but only for someone who re-executes them (`attest.py sign X.cert.json --key K --rerun 5 --execute --out X.att.json`, in a throwaway VM). Neither verification nor the log re-executes anything itself: what the log can do is
  COMMIT the signed statement that someone did, so a reader can ask for "re-executed by keys I pin". The `counted` flag lets readers filter.
* **It is permanent public storage for whatever fits in the fields it accepts.** The log is append-only and serves every admitted file for good; there is no delete. The fourth audit stored 400 KB of
  text of its own choosing in an unknown field of a certificate, of an attestation, of a run statement, in a signed `note` and in a signed `claim`. Now an attestation or run statement must be exactly the
  shape its tool writes with every field small (the whole file at most 64 KB; a full re-run's per-instance numbers need up to ~45 KB of that, so the `rerun` field is held to NUMBERS ONLY, at most 5,000 of them, rather than to a byte cap: the first
version's 1,000-byte cap rejected `attest.py sign ... --rerun all`, the strongest evidence there is), and a certificate may carry only the fields `certificate.build` writes with the free-text ones bounded. **What remains
  arbitrary is inherent to a certificate:** the solver's source (it must hash to the recorded value, which any text can), a declared domain's files, the ladder lines and round-log data, each bounded only by the 8 MB
  file cap. An operator who exposes the submission endpoint publicly should gate what is admitted (approve submitters, or publish only after a person has looked), because the log cannot take anything back.
* **Time.** `logged` is the operator's clock. A witness's co-signature time and an anchor are the earliest times anyone else can vouch for.
* **Independence.** A signature shows which key signed. An operator can mint five keys, so only keys a reader pinned count (`--trusted`), exactly as for attestations.
* **A witness that does not `--recheck` vouches only for append-only behaviour.** Re-checking is what catches an operator who signs an entry claiming more than its certificate says.

## The structure

An RFC 9162 Merkle tree (SHA-256; leaf = `H(0x00 || line)`, node = `H(0x01 || left || right)`). A leaf is one **line of `entries.jsonl`**, in canonical JSON, so the bytes that
are hashed are the bytes that are published; a non-canonical line is refused on load. The prover (`Tree`) uses the RFC's recursive definitions and the verifier uses its iterative
checks (2.1.3.2, 2.1.4.2), so one bug cannot hide behind itself. Tests pin the published RFC 6962 vectors and compare against a naive reference for every size and every `(index, size)` /
`(old, new)` pair up to 34 leaves.

A root does not commit to its size (a property of RFC 6962 trees: the same path can verify at sizes n and n+1 against root(n)). Size is bound by the **signed head**, which signs
`(origin, size, root, time)` together; `check_inclusion` enforces it.

### Files (a log is one directory; everything in it is public except `.lock`)

```
log.json           format, origin, the operator's public key, the hash rules
entries.jsonl      one canonical-JSON entry per line (the leaves)
checkpoints.jsonl  EVERY head the operator ever signed (append-only)
checkpoint.json    the newest head with the witnesses who co-signed it (what readers fetch)
cosigs.jsonl       every witness co-signature ever merged (append-only)
anchors.jsonl      the operator's notes of where a head was published elsewhere
certs/SHA.cert.json  the certificates (an entry never names one the log cannot serve)
proofs/N.json      an inclusion proof per entry against the newest head (convenience; skipped above 20,000 entries)
trusted.txt        witness keys the operator LISTS (optional; a list the operator wrote proves nothing about independence)
```

The operator's **signing key lives outside this directory** (`init` refuses otherwise). The directory is what you publish.

### An entry (all derived from the file it is about; `recheck_entry` regenerates it). Three kinds share one tree, so one head and one set of witnesses vouch for all of them

* **certificate**: `seq, logged, kind, cert_sha256, cert_canon_sha256, measurement_sha256, cert_bytes, family, solver, submission_sha256, credit_bits, status, private, counted, seeds_revealed, source
  (round|standalone), rules_sha256, checks`. `cert_canon_sha256` is what attestations sign (they sign the certificate's canonical form, not the bytes of one file); `measurement_sha256` is what was
  MEASURED (problem, solver, committed seeds, every raw record, rules), independent of how the file is written.
* **attestation** (attest.py's format): `target_seq, target_cert_sha256, att_sha256, attester, verified, exact, gap, executed, signed_at`. Someone re-checked or re-ran a logged certificate and signed what happened.
* **run** (runattest.py's format): `target_seq, target_cert_sha256, att_sha256, attester, sandbox, image, instance_version, round_id, round_log_head, signed_at`. The sandbox operator signed that their own records match.

Free text is limited to plain ASCII and short; a hostile problem name is refused at admission. Rules between entries are one function, `relation_problems`, run by the operator on every add **and by every reader
and witness on the whole log**: a certificate file once; a measurement once unless a later file is a strict upgrade; an attestation names an earlier certificate entry by hash, once, and one key may log at
most 8 statements about one certificate.

### Heads and co-signatures

* Head: `{format, origin, size, root, time}`, signed Ed25519 under domain-separated bytes. Several heads may exist at the same size (a **heartbeat**: same root, later time,
  proving the log was alive and unchanged). Two roots at one size can never both be consistent with `entries.jsonl`, and `parse_log` reports it.
* Co-signature: signs `(origin, log key, size, root, witness_time)`, **not** the operator's timestamp, so it survives a heartbeat. A new size needs new co-signatures. It names the log's **key**
  as well as its origin: without that, a fork that copies the entries under a new key (and the same origin string) would carry the original's endorsements, which are valid for any log with those entries.
* Head times never go backwards: a clock that steps back (NTP, a restored VM) is clamped to the previous head's time, because a log with a backwards head is read as damaged.
  **The converse is permanent:** a clock set far AHEAD once stamps a head in the future, and every later head is then clamped at or after it. `check` reports a head dated more than an hour ahead of the
  reader's clock as a failure (not "fresh"). There is no way to undo it inside the log; the recovery is a new log that anchors the old head. Check the operator machine's clock before `init`.
* **Reading a live log:** the operator appends entries *before* the head that covers them, so readers read the heads first and `entries.jsonl` **last**. Any other order shows a healthy log as damaged
  while it is being published.
* The log's own key cannot witness itself; a co-signature for a head the entries do not produce is refused.

## Admission

`add` runs `certificate.verify` (it **executes nothing from the certificate**) and admits only if no check fails and the claim equals the claim recomputed from the raw records.
**A measurement is logged once.** The first version refused only identical file bytes, so a copy with an edited `created` timestamp was a new entry (it could not raise the frontier, but it padded the log).
Refusing by *measurement* would also refuse legitimate upgrades, so the rule is: a later file for the same measurement is admitted only if it is a **strict upgrade**, never worse in any of (seeds revealed,
solver public, round log carried) and better in at least one. A sealed certificate republished with its seeds revealed is admitted; an edited copy, a private re-publication of a revealed file, or a file that
trades one kind of evidence for another is refused with the entry it duplicates. Oversize (>8 MB), non-JSON, `NaN`, wrong format: refused. A refused certificate leaves nothing in the log and no head is signed.
Rejection messages never name the verifier's temp directories.
One head is signed per batch, not per certificate, and whatever happens mid-batch (a verifier exception, Ctrl-C) every entry that reached the file is covered by a signed head before the lock is released.
A certificate that makes the verifier raise is reported as "could not be checked" and skipped; it does not abort the batch.

Reading a log over HTTP: `url_reader` follows redirects only between http and https and never from https down to http. (The audit found urllib following a `Location: ftp://host:port`, so a hostile
log URL could make the verifier open a connection to any host and port it named.) Use https, and `--log-key`, when witnessing a log you do not control: plain http lets anyone on the path serve you a log of their own.

**Rules versions.** A certificate verifies only under the protocol code it was built with (the `rules` check). The two certificates in `certs/` today fail it under the current
checkout, which is correct: they cannot be admitted until rebuilt. For auditing, every entry records `rules_sha256`, and a re-check under a different checkout reports
**unknown ("protocol code differs")**, never a mismatch. To audit an old entry, check out the protocol code its certificate names and re-check there. Only the `rules` fingerprint counts as a
version difference: a `domain` failure (a declaration that does not match its own recorded hash) is tampering and is a mismatch.

**A witness will not vouch for what it cannot re-check.** With `--recheck`, an entry it cannot re-check (unknown) makes it refuse to co-sign unless `--allow-unknown`, and then the co-signature
says in the output that those entries are not vouched for. (The audit found a re-checking witness co-signing a head that contained a 49-bit credit it could not check, and the Log page showing it as
the best result: an operator could otherwise log any credit for a certificate no witness can verify.) The page's re-checked columns never include an entry that was not actually re-checked.
**Tolerance is per entry:** `--allow-unknown` tolerates exactly the unverifiable entries present on that run, records their numbers in the state file (`tolerated`), and does not need repeating for them.
A *new* entry nobody can check is refused again until the flag is passed again. (The first version of this was all-or-nothing, so a witness that tolerated old entries once had to pass the flag on
every run, which also silently accepted every later unverifiable entry.)

## Witnesses

```
guldo log witness --log https://guldo.org/log --state ~/.guldo-witness.json --key witness.key --log-key LOGKEY --recheck --out cosig.json
```

Run it on a schedule from a machine the operator does not control. It refuses, and **keeps its old state**, on: a rolled-back log; first-`size` entries whose root is no longer the one it saw
(**history changed**); a bad signature; a missing or altered certificate (`--recheck`); entries it cannot re-check (unless `--allow-unknown`); and a `--log-key` different from the one its state
file follows (a witness never silently re-pins: use a new state file for another key).

The state file keeps the operator's own signature on the last head the witness saw. So on **history changed** the witness can write a self-contained **equivocation proof**
(`witness ... --evidence ev.json`): the old signed head, the new signed head, and the leaf hashes of the newer history. Anyone checks it offline with only the operator's public key
(`translog.py check-evidence ev.json --log-key LOGKEY`): it recomputes the newer root from the leaves, then the root of the first `old_size` leaves, and if that is not what the operator signed
before, one key has signed two histories that cannot both be one append-only log. A file whose heads are consistent says so and proves nothing. A **rollback** (the log now serves fewer entries
than a head it signed earlier) is refused but is not provable from this file alone; the witness's saved head proves the operator signed that size, which is withholding, not equivocation. First sight trusts the log key on first use unless `--log-key` pins it. Send the co-signature to the operator (`add-cosig`) or publish it yourself:
a reader can verify a co-signature file directly and pin your key in their own `trusted.txt`.

## Absence claims

`guldo log absence --log L --family F --threshold T --out claim.json` scans the entries the newest signed head covers. `check-absence` recomputes the root of the supplied entries, checks it
against the head's signature, and redoes the scan. Altering the best credit, the head size, or the entries all fail. `--counted-only` restricts to step-counted certificates.
The scan reads the credits **the entries say**; an operator that understated one would make a false claim verify. `check-absence --recheck` recomputes every entry from its certificate too, and is
what makes the claim trustworthy. Without it the command says so.

## Checking: every verdict needs a pinned key

`check`, `verify-inclusion`, `verify-consistency` (with heads), `check-evidence` and `check-absence` refuse to run without `--log-key HEX`, the key you got from somewhere other than the log. (`--unpinned`
accepts any key and the verdict then reads "... BUT THE LOG'S KEY IS NOT PINNED"; the audit found these printing a bare VERIFIED/OK, which anyone could earn by starting a log under their own key. The first fix
covered four of the five and missed `check`, the headline command; the second audit caught it.) `witness` is the one exception: first sight trusts the key on first use and says so; pass `--log-key` to pin it.

## Evidence: attestations and run statements (how the limits are overcome, and where they are not)

Two limits looked permanent: a timed credit is the submitter's own measurement, and `OFFICIAL` is a label anyone can write. Neither can be fixed *inside a certificate*, because each is a claim about an event that
only someone else witnessed. What can be done is make that someone SAY SO, in a form tied to a key a reader pins:

* **Re-execution (`attest.py`).** Anyone runs `attest.py sign X.cert.json --key K --rerun 5 --execute --out X.att.json` (in a throwaway VM: it runs the solver) and gets a signed statement whose own checks include the re-run
  (identical counts for a step-counted certificate, a timing within tolerance otherwise). `translog.py add-attestation DIR a.att.json --key LOGKEY` commits it. `frontier --tier reexecuted --trusted MYKEYS`
  then asks for the best credit among certificates that a key *you* pinned re-executed; `absence --tier reexecuted --trusted MYKEYS` makes the same claim about absence, recording the keys in the claim.
* **Run (`runattest.py`).** The sandbox operator runs `runattest make X.cert.json --results RESULTS --key OPKEY --round-data DATA`. It **refuses unless the operator's own result files are, byte for byte, the
  ladders in the certificate** (after the same private-solver redaction), unless the operator's own headers say the run was in a sandbox, and unless any round log in the certificate is the operator's own.
  The audit's forgery (rewrite the ladder headers to say `docker`; the certificate then verifies as OFFICIAL) produces ladders that match no file the operator holds, so it cannot be attested; inflating
  only the baseline's costs, or halving the solver's, fails the same comparison. A forger who signs with their own key produces a statement that the log records (it cannot know whose key to trust) and that
  counts for nobody who pinned the operator's key. `frontier --tier run --trusted OPKEY` is the reader's question.

What this does **not** do, plainly: an attestation is its signer's statement about their own machine, and a run statement vouches only that the operator's *records* match; neither proves the sandbox is sound
(that is the sandbox's own test suite, which has not yet been run on a verified host, so **no run statement can honestly exist yet**). The Log page's `trusted.txt` list is the operator's, so its
"listed key" columns show what the operator vouches for, not what is independent: ask with your own keys. Re-checking an attestation entry verifies the signature, the target and the file's hash; it cannot
re-run anything, and a witness never re-executes certificates itself.

## Submission: the web tier parks, a worker decides

`public_portal.py --log-queue DIR` adds `POST /api/log/submit` (a certificate or an attestation as the raw JSON body) and `GET /api/log/submission/<sha256>.json`. The web tier checks only **shape and size**, applies the
portal's own per-address and global rate limits (refused junk costs tokens too), a pending cap and the kill switch, and parks the file: it **never verifies, never runs, never holds the signing key**, and a test
asserts it does not even import the verifier. `translog.py ingest DIR --queue Q --key K` (the worker, `deploy/log-ingest.*`, a different user with no network) runs each file through `add` /
`add-attestation` **in its own subprocess with a wall-clock limit**, writes a result the web tier serves (`queued` / `admitted` with the entry number / `rejected` with a reason scrubbed of server paths) and
removes the file. A file that hangs the verifier costs its timeout and nothing else; if the log itself is unusable the worker stops and leaves everything queued.

Three properties of the worker that the fourth audit had to establish, because the obvious versions were wrong: (1) the limit is a **process-group** kill (`run_group`): `subprocess.run(timeout=)` kills only the
direct child, and `certificate.verify` runs `extrapolate.py` in a child of its own, which kept running after the "limit" fired; (2) the worker reads each file's outcome from a **JSON result file** the CLI writes
(`--results-json`), not from the human output (a queue path containing a space lost every rejection reason); (3) it signs **one head per run** (`add --no-sign`, then a single `sign`), not one per admitted
file, which under a flood would bloat `checkpoints.jsonl` and rewrite every proof file each time; if a run dies before signing, the next run signs the unsigned tail first, even with nothing queued. Submit
a certificate before any attestation about it: the worker processes the queue oldest first, and an attestation whose certificate is not yet in the log is rejected.

Three more, from the fifth audit: only **one worker drains a queue at a time** (an exclusive, non-blocking lock; two workers listing the same file would otherwise both process it, and the second, finding it already
logged, wrote `rejected` over the first's `admitted`); **a decision is never made twice** (a file whose result already exists is removed, not reprocessed); and **a failed final `sign` does not take the run down**
(the results are already written, and the next run signs the unsigned tail first). The process helper also only signals the process group while the leader is still unreaped, never after a normal exit (the group
id could by then belong to something else), and stops waiting for a grandchild that left the group but still holds its pipes.

And, from the sixth audit, the worker's treatment of failures is split by WHOSE fault they are: a timeout or any deterministic exception while running one file **rejects that file** (otherwise one such file at
the head of an oldest-first queue wedges it forever: every run dies on it and nothing behind it is processed); an `OSError` (the command could not even start: a fork limit, no interpreter) is the machine's
problem and **stops the run with nothing decided**; a log that cannot be opened stops it too. A `sign` that exits non-zero is reported on stderr (server paths scrubbed) rather than swallowed.

`deploy/log-heartbeat.*` signs a head daily (so a stopped log is distinguishable from a quiet one), `deploy/log-witness.*` is a template for an independent witness, and `deploy/Caddyfile` serves `/log/*`
live from the log directory (hiding `.lock`) with its own 4 MB cap for the submit route. **None of these units has been started and the Caddyfile has not been validated**: no systemd or Caddy was available
where they were written. `test_log_deploy.py` checks what a static test can: every `ExecStart` parses under the real command-line parser, only the worker and the heartbeat name the signing key, and the
network-free units have no network.

## Anchors

`translog.py anchor DIR` prints one line (`guldo-tlog <origin> <size> <root> <time>`). Publish it somewhere the operator cannot edit (a repository README, a signed commit, a paper, a
DNS TXT record, a newspaper). `anchor-check URL --log L` confirms the page shows the current head. `anchor --record KIND REF` notes where in `anchors.jsonl`; that note is the operator's
own and is labelled so on the page. The log has no blockchain and does not need one: the anchor is a one-line commitment, not a ledger.

## Operator runbook

```
translog.py init ~/guldo-log --origin guldo.org/log --new-key ~/.guldo-operator.key     # key is written 0600, never overwritten, OUTSIDE the log dir. BACK IT UP.
translog.py add  ~/guldo-log cert1.json cert2.json --key ~/.guldo-operator.key           # verify, append, sign one head
translog.py sign ~/guldo-log --key ~/.guldo-operator.key                                  # a heartbeat (daily is enough)
translog.py add-cosig ~/guldo-log witness1.cosig.json
translog.py add-attestation ~/guldo-log a.att.json run.att.json --key ~/.guldo-operator.key   # re-executions by others, and (later) the sandbox operator's own run statements
translog.py ingest ~/guldo-log --queue /srv/ledger/log-queue --key ~/.guldo-operator.key        # what deploy/log-ingest.timer runs: drain strangers' submissions
translog.py anchor ~/guldo-log --record readme https://github.com/.../README.md
make site LOG=~/guldo-log                                                                  # re-verifies the log at build time and publishes it under /log
```

Put the log's public key (printed by `init`, and on the Log page) somewhere **else** a reader can pin it from. A key that only appears on the page serving the log says which key signed, not whose.
Back up the whole directory (it is small) and the key separately. A torn last line after a crash is reported and `repair` drops it, but only when no signed head covers it.
There is no delete: a mistaken entry is answered by a later entry or a note, never removed. A lost key means starting a new log and anchoring the old head into it.

## What is not built (needs wiring)

Built and tested here, but not run anywhere real:

* **The submission endpoint, worker and timers** exist (see "Submission"). They have been exercised over a loopback socket and in subprocesses, never under systemd or behind Caddy, and the portal's rate
  limits are the defaults of an unmeasured guess.
* **Release.** `guldo-cli` 0.1.1 (with `guldo log` and `guldo runattest`) is built, passes `twine check` and installs into a clean virtualenv, but **has not been uploaded**: the PyPI 0.1.0 does not have the log.

Not built, because it needs a decision or a machine that does not exist yet:

* **A real log.** None has been started: no operator key exists. `init` is one command, and the key must be backed up outside the log directory.
* **Real witnesses.** None exist. Until one does the Log page says, in its banner, that the operator alone vouches for the log. A witness has to be someone the operator does not control.
* **A verified sandbox.** `run` statements vouch that the operator's records match; whether the sandbox that produced them is sound is the sandbox's own unrun test (`make test-sandbox`, needs Docker, which the
  project has chosen not to use). Until then the strongest honest tier a real log can show is *re-executed*, by keys readers pin.
* **Witnesses that re-execute.** A witness re-checks arithmetic and signatures; it deliberately does not run certificates' solvers (that executes untrusted code). Re-execution is done by individual attesters.
