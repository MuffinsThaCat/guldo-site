"""Sealed delivery: encrypt a secret (a seed share) to a key that lives INSIDE an attested enclave, so the host that runs the enclave never sees it.

  keypair() -> (secret, public)                      X25519
  seal(recipient_public, info, aad, plaintext)       HPKE (RFC 9180) base mode, DHKEM(X25519, HKDF-SHA256), HKDF-SHA256, ChaCha20-Poly1305 -> enc || ciphertext
  open_sealed(recipient_secret, sealed, info, aad)   the inverse (raises SealError on any failure)
  seal_to_enclave(evidence, plaintext, ...)          verify TEE evidence (agent_tee), take the PUBLIC KEY the enclave's attestation document carries, and seal to it, with the binding digest as the
                                                     HPKE `info`: the ciphertext can only be opened by the enclave that attested THIS binding

Everything is the standard construction, in pure Python. WHAT WAS ACTUALLY CHECKED: `python3 agent_seal.py selftest` reproduces the RFC 9180 appendix A.2 vector (seal_vectors.py, generated from the RFC
text) stage by stage (the public keys, `enc`, the shared secret, `key`, `base_nonce`, and the ciphertext of every listed encryption, opened back), the RFC 7748 section 6.1 Diffie-Hellman example, a random
round trip, and the refusals a user relies on. It passed on Python 3.14 on 27 Nov 2026. **It is a self-check command, NOT part of the unit-test suite** (there is no test file for this module, at the
author's instruction), it was not run on Python 3.9, and nothing was cross-checked against another implementation (such as the `cryptography` package). Treat it as checked against the RFCs' vectors, not as
audited cryptography.
It is variable-time Python: do not use it where a local timing side channel on the SECRET key matters. The enclave's key is generated inside the enclave.

WHAT THIS GIVES. A party can verify an enclave's attestation against the image IT built, then encrypt its share to the key in that very document: the host that relays the ciphertext cannot read it.
WHAT IS STILL NOT BUILT: the enclave program that generates the key, requests the document (agent_nsm.py, never run on hardware), receives the shares, combines them and serves; and the
two-phase binding that this needs (the attestation precedes the seed commitment, which depends on the shares). Until that exists the seed still passes through a host-controlled channel in a real deployment.
"""
import base64
import hashlib
import hmac
import os
import struct

import agent_tee
from agent_core import canon

P = 2 ** 255 - 19
A24 = 121665
BASE = (9).to_bytes(32, "little")
KEM_ID, KDF_ID, AEAD_ID = 0x0020, 0x0001, 0x0003
SEALED_FORMAT = "guldo-sealed-v1"
MAX_PLAINTEXT = 1 << 16


class SealError(Exception):
    pass


# ---- X25519 (RFC 7748) -------------------------------------------------------------------------------------------------------------------------------------------

def x25519(k, u):
    if not (isinstance(k, (bytes, bytearray)) and len(k) == 32 and isinstance(u, (bytes, bytearray)) and len(u) == 32):
        raise SealError("X25519 takes 32-byte scalars and points")
    kb = bytearray(k)
    kb[0] &= 248
    kb[31] &= 127
    kb[31] |= 64
    kk = int.from_bytes(kb, "little")
    x1 = (int.from_bytes(u, "little") & ((1 << 255) - 1)) % P
    x2, z2, x3, z3, swap = 1, 0, x1, 1, 0
    for t in range(254, -1, -1):
        bit = (kk >> t) & 1
        swap ^= bit
        if swap:
            x2, x3, z2, z3 = x3, x2, z3, z2
        swap = bit
        a, b = (x2 + z2) % P, (x2 - z2) % P
        aa, bb = a * a % P, b * b % P
        e = (aa - bb) % P
        c, d = (x3 + z3) % P, (x3 - z3) % P
        da, cb = d * a % P, c * b % P
        x3 = pow(da + cb, 2, P)
        z3 = x1 * pow(da - cb, 2, P) % P
        x2 = aa * bb % P
        z2 = e * (aa + A24 * e) % P
    if swap:
        x2, x3, z2, z3 = x3, x2, z3, z2
    return (x2 * pow(z2, P - 2, P) % P).to_bytes(32, "little")


def keypair():
    sk = os.urandom(32)
    return sk, x25519(sk, BASE)


# ---- ChaCha20-Poly1305 (RFC 8439) -----------------------------------------------------------------------------------------------------------------------------

def _rotl(x, n):
    return ((x << n) & 0xffffffff) | (x >> (32 - n))


def _quarter(s, a, b, c, d):
    s[a] = (s[a] + s[b]) & 0xffffffff
    s[d] = _rotl(s[d] ^ s[a], 16)
    s[c] = (s[c] + s[d]) & 0xffffffff
    s[b] = _rotl(s[b] ^ s[c], 12)
    s[a] = (s[a] + s[b]) & 0xffffffff
    s[d] = _rotl(s[d] ^ s[a], 8)
    s[c] = (s[c] + s[d]) & 0xffffffff
    s[b] = _rotl(s[b] ^ s[c], 7)


def chacha20_block(key, counter, nonce):
    init = list(struct.unpack("<4I", b"expand 32-byte k")) + list(struct.unpack("<8I", key)) + [counter & 0xffffffff] + list(struct.unpack("<3I", nonce))
    s = list(init)
    for _ in range(10):
        _quarter(s, 0, 4, 8, 12)
        _quarter(s, 1, 5, 9, 13)
        _quarter(s, 2, 6, 10, 14)
        _quarter(s, 3, 7, 11, 15)
        _quarter(s, 0, 5, 10, 15)
        _quarter(s, 1, 6, 11, 12)
        _quarter(s, 2, 7, 8, 13)
        _quarter(s, 3, 4, 9, 14)
    return struct.pack("<16I", *[(s[i] + init[i]) & 0xffffffff for i in range(16)])


def _chacha20_xor(key, counter, nonce, data):
    out = bytearray()
    for i in range(0, len(data), 64):
        block = chacha20_block(key, counter + i // 64, nonce)
        chunk = data[i:i + 64]
        out += bytes(a ^ b for a, b in zip(chunk, block))
    return bytes(out)


def poly1305(key, msg):
    r = int.from_bytes(key[:16], "little") & 0x0ffffffc0ffffffc0ffffffc0fffffff
    s = int.from_bytes(key[16:32], "little")
    acc, p = 0, (1 << 130) - 5
    for i in range(0, len(msg), 16):
        n = int.from_bytes(msg[i:i + 16] + b"\x01", "little")
        acc = (acc + n) * r % p
    return ((acc + s) & ((1 << 128) - 1)).to_bytes(16, "little")


def _pad16(b):
    return b"\x00" * (-len(b) % 16)


def aead_seal(key, nonce, aad, pt):
    if len(key) != 32 or len(nonce) != 12:
        raise SealError("ChaCha20-Poly1305 takes a 32-byte key and a 12-byte nonce")
    otk = chacha20_block(key, 0, nonce)[:32]
    ct = _chacha20_xor(key, 1, nonce, pt)
    tag = poly1305(otk, aad + _pad16(aad) + ct + _pad16(ct) + struct.pack("<QQ", len(aad), len(ct)))
    return ct + tag


def aead_open(key, nonce, aad, sealed):
    if len(key) != 32 or len(nonce) != 12 or len(sealed) < 16:
        raise SealError("a malformed ciphertext")
    ct, tag = sealed[:-16], sealed[-16:]
    otk = chacha20_block(key, 0, nonce)[:32]
    want = poly1305(otk, aad + _pad16(aad) + ct + _pad16(ct) + struct.pack("<QQ", len(aad), len(ct)))
    if not hmac.compare_digest(want, tag):
        raise SealError("the ciphertext does not authenticate (wrong key, wrong info or aad, or it was altered)")
    return _chacha20_xor(key, 1, nonce, ct)


# ---- HKDF-SHA256 and HPKE base mode (RFC 9180) -----------------------------------------------------------------------------------------------------------------

def _hkdf_extract(salt, ikm):
    return hmac.new(salt or b"\x00" * 32, ikm, hashlib.sha256).digest()


def _hkdf_expand(prk, info, n):
    out, t, i = b"", b"", 1
    while len(out) < n:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        out += t
        i += 1
    return out[:n]


_KEM_SUITE = b"KEM" + KEM_ID.to_bytes(2, "big")
_SUITE = b"HPKE" + KEM_ID.to_bytes(2, "big") + KDF_ID.to_bytes(2, "big") + AEAD_ID.to_bytes(2, "big")


def _lextract(suite, salt, label, ikm):
    return _hkdf_extract(salt, b"HPKE-v1" + suite + label + ikm)


def _lexpand(suite, prk, label, info, n):
    return _hkdf_expand(prk, n.to_bytes(2, "big") + b"HPKE-v1" + suite + label + info, n)


def _dh(sk, pk):
    out = x25519(sk, pk)
    if out == b"\x00" * 32:
        raise SealError("a low-order public key (the DH output is zero)")
    return out


def _extract_and_expand(dh, kem_context):
    eae = _lextract(_KEM_SUITE, b"", b"eae_prk", dh)
    return _lexpand(_KEM_SUITE, eae, b"shared_secret", kem_context, 32)


def encap(recipient_public, ephemeral_secret=None):
    """(shared secret, enc). `ephemeral_secret` is only for deterministic tests."""
    sk = ephemeral_secret if ephemeral_secret is not None else os.urandom(32)
    pk_e = x25519(sk, BASE)
    return _extract_and_expand(_dh(sk, recipient_public), pk_e + recipient_public), pk_e


def decap(enc, recipient_secret):
    pk_r = x25519(recipient_secret, BASE)
    return _extract_and_expand(_dh(recipient_secret, enc), enc + pk_r)


def key_schedule(shared_secret, info):
    """(key, base_nonce) for mode 0 (base)."""
    psk_id_hash = _lextract(_SUITE, b"", b"psk_id_hash", b"")
    info_hash = _lextract(_SUITE, b"", b"info_hash", info)
    ctx = b"\x00" + psk_id_hash + info_hash
    secret = _lextract(_SUITE, shared_secret, b"secret", b"")
    return _lexpand(_SUITE, secret, b"key", ctx, 32), _lexpand(_SUITE, secret, b"base_nonce", ctx, 12)


def nonce_for(base_nonce, seq):
    return (int.from_bytes(base_nonce, "big") ^ seq).to_bytes(12, "big")


def seal(recipient_public, info, aad, plaintext, ephemeral_secret=None):
    """Single-shot HPKE seal. Returns enc (32 bytes) || ciphertext||tag. NEVER pass `ephemeral_secret` outside a test: it exists only to reproduce the RFC's vector, and a fixed ephemeral key used
    twice for the same recipient would reuse the key and nonce."""
    if not isinstance(plaintext, (bytes, bytearray)) or len(plaintext) > MAX_PLAINTEXT:
        raise SealError("the plaintext is bytes of at most %d" % MAX_PLAINTEXT)
    ss, enc = encap(bytes(recipient_public), ephemeral_secret)
    key, base_nonce = key_schedule(ss, bytes(info))
    return enc + aead_seal(key, nonce_for(base_nonce, 0), bytes(aad), bytes(plaintext))


def open_sealed(recipient_secret, sealed, info, aad):
    if not isinstance(sealed, (bytes, bytearray)) or len(sealed) < 32 + 16:
        raise SealError("a malformed sealed message")
    enc, ct = bytes(sealed[:32]), bytes(sealed[32:])
    key, base_nonce = key_schedule(decap(enc, bytes(recipient_secret)), bytes(info))
    return aead_open(key, nonce_for(base_nonce, 0), bytes(aad), ct)


# ---- sealing to an ATTESTED enclave ---------------------------------------------------------------------------------------------------------------------------

def seal_to_enclave(evidence, plaintext, expect_pcrs, expect_binding=None, aad=b"", **verify_kw):
    """Verify `evidence` (agent_tee.verify_evidence: it must be ATTESTED against the image measurement YOU built) and seal `plaintext` to the X25519 public key in the enclave's attestation document.
    The HPKE `info` is the digest of the evidence's binding, so only the enclave that attested exactly this binding can open it. Returns a JSON-able dict."""
    status, probs, info = agent_tee.verify_evidence(evidence, expect_binding, expect_pcrs, **verify_kw)
    if status != "attested":
        raise SealError("not sealing to an enclave that is not attested (%s: %s)" % (status, probs[0] if probs else "no reason"))
    pk_hex = info.get("public_key")
    if not (isinstance(pk_hex, str) and len(pk_hex) == 64):
        raise SealError("the attestation document carries no 32-byte public key to seal to")
    digest = agent_tee.binding_digest(evidence["binding"])
    return {"format": SEALED_FORMAT, "binding_digest": digest.hex(), "aad_b64": base64.b64encode(aad).decode("ascii"),
            "sealed_b64": base64.b64encode(seal(bytes.fromhex(pk_hex), digest, aad, plaintext)).decode("ascii")}


def open_for_enclave(recipient_secret, doc, expect_binding_digest):
    """The enclave's side: open a sealed message, but only if it was sealed for THIS binding."""
    if not isinstance(doc, dict) or doc.get("format") != SEALED_FORMAT or doc.get("binding_digest") != expect_binding_digest.hex():
        raise SealError("not a message sealed for this binding")
    try:
        return open_sealed(recipient_secret, base64.b64decode(doc["sealed_b64"], validate=True), expect_binding_digest, base64.b64decode(doc["aad_b64"], validate=True))
    except (KeyError, ValueError, TypeError):
        raise SealError("a malformed sealed message")


def selftest():
    """(ok, [(check, ok)]): reproduce the RFC 9180 appendix A.2 vector stage by stage (the ephemeral and recipient public keys, enc, shared secret, key, base nonce, EVERY listed encryption sealed and
    opened), the RFC 7748 section 6.1 Diffie-Hellman example, and the properties a user relies on (a random round trip; refusal of a wrong key, wrong info, wrong aad and an altered ciphertext).
    Run it with `python3 agent_seal.py selftest`. It is a self-check of this file's arithmetic on this machine, not a security audit."""
    import seal_vectors as V
    h = bytes.fromhex
    s, out = V.SETUP, []

    def add(name, ok):
        out.append((name, bool(ok)))
    add("RFC 9180 A.2: public keys derive from the vector's secret keys", x25519(h(s["skEm"]), BASE).hex() == s["pkEm"] and x25519(h(s["skRm"]), BASE).hex() == s["pkRm"])
    ss, enc = encap(h(s["pkRm"]), h(s["skEm"]))
    add("RFC 9180 A.2: enc and the shared secret", enc.hex() == s["enc"] and ss.hex() == s["shared_secret"] and decap(h(s["enc"]), h(s["skRm"])) == ss)
    key, base = key_schedule(ss, h(s["info"]))
    add("RFC 9180 A.2: the key and the base nonce", key.hex() == s["key"] and base.hex() == s["base_nonce"])
    for e in V.ENCRYPTIONS:
        nonce = nonce_for(base, e["seq"])
        add("RFC 9180 A.2: encryption %d seals to the listed ciphertext and opens back" % e["seq"], nonce.hex() == e["nonce"] and aead_seal(key, nonce, h(e["aad"]), h(e["pt"])).hex() == e["ct"]
            and aead_open(key, nonce, h(e["aad"]), h(e["ct"])) == h(e["pt"]))
    a_sk, b_sk = h("77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a"), h("5dab087e624a8a4b79e17f8b83800ee66f3bb1292618b6fd1c2f8b27ff88e0eb")
    a_pk, b_pk = x25519(a_sk, BASE), x25519(b_sk, BASE)
    add("RFC 7748 6.1: Alice's and Bob's public keys", a_pk.hex() == "8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a"
        and b_pk.hex() == "de9edb7d7b7dc1b4d35b61c2ece435373f8343c85b78674dadfc7e146f882b4f")
    add("RFC 7748 6.1: the shared secret, from both sides", x25519(a_sk, b_pk) == x25519(b_sk, a_pk) and x25519(a_sk, b_pk).hex() == "4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742")
    sk, pk = keypair()
    sealed = seal(pk, b"info", b"aad", b"a seed share")
    add("a random seal/open round trip", open_sealed(sk, sealed, b"info", b"aad") == b"a seed share")

    def refuses(fn):
        try:
            fn()
        except SealError:
            return True
        return False
    other_sk, _ = keypair()
    add("a wrong recipient key, wrong info, wrong aad, an altered ciphertext and a truncated message are all refused",
        refuses(lambda: open_sealed(other_sk, sealed, b"info", b"aad")) and refuses(lambda: open_sealed(sk, sealed, b"other", b"aad")) and refuses(lambda: open_sealed(sk, sealed, b"info", b"other"))
        and refuses(lambda: open_sealed(sk, sealed[:-1] + bytes([sealed[-1] ^ 1]), b"info", b"aad")) and refuses(lambda: open_sealed(sk, sealed[:40], b"info", b"aad")))
    add("a low-order public key is refused (the DH output would be zero)", refuses(lambda: seal(b"\x00" * 32, b"i", b"a", b"x")))
    return all(ok for _n, ok in out), out


if __name__ == "__main__":
    import sys
    if sys.argv[1:] == ["selftest"]:
        good, rows = selftest()
        for name, ok in rows:
            print("%s  %s" % ("PASS" if ok else "FAIL", name))
        print("SELFTEST PASSED" if good else "SELFTEST FAILED")
        sys.exit(0 if good else 1)
    print("usage: python3 agent_seal.py selftest", file=sys.stderr)
    sys.exit(2)
