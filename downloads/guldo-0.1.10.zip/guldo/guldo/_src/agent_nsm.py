"""The ENCLAVE side of Nitro attestation: ask the Nitro Secure Module (NSM) for an attestation document that commits to this service. `agent_tee.py` verifies what this produces.

  request_attestation(user_data, nonce=None, public_key=None)  -> the raw attestation document (COSE_Sign1 bytes)
  attest_service(service_pubkey, plan_hash, commitment, manifest)  -> agent_tee evidence JSON: the binding, whose digest was put in the document's `user_data`

STATUS: **NEVER RUN ON REAL HARDWARE.** No Nitro enclave was available while this was written, so nothing here has spoken to a real /dev/nsm. What IS tested (test_agent_nsm) is everything that does not need the
device: the CBOR request is exactly what the NSM API defines (`{"Attestation": {"user_data", "nonce", "public_key"}}`, serde externally-tagged, as in aws-nitro-enclaves-nsm-api), the 32-byte `nsm_message`
the ioctl takes (two iovecs: request pointer+length, response pointer+length), the ioctl number (_IOWR(0x0A, 0, 32 bytes) = 0xC0200A00), the 0x3000-byte response buffer, and the parsing of a response and of
every error the NSM can return, against an EMULATION of the kernel's behaviour. If the real interface differs from the aws-nitro-enclaves-nsm-api definition this was written from, the first attestation
request in a real enclave will fail loudly (an ioctl error or an `{"Error": ...}` response); it cannot silently produce a document that verifies, because a document is only accepted by agent_tee if AWS's
signature, the chain, the PCRs you built and the binding digest all check.

WHAT IS STILL MISSING FOR A SEED THAT NEVER LEAVES THE ENCLAVE. The enclave must receive the seed share without the host seeing it: it should generate a keypair INSIDE, put the PUBLIC key in the attestation
(`public_key` below), and the verifier, after checking the document against the image it built, encrypts the share to that key. That sealed delivery (an authenticated public-key encryption, e.g. an
X25519 sealed box) is NOT built here; as it stands a verifier would hand the seed to the enclave over a channel the host controls. The enclave image (a reproducible build whose PCR0 you can recompute) is also
yours to make: `nitro-cli build-enclave` from a Docker image containing the files named by `agent_tee.SERVICE_FILES`.
"""
import ctypes
import fcntl
import os
import struct

import agent_tee

DEVICE = "/dev/nsm"
NSM_IOCTL_MAGIC = 0x0A
IOC_READ_WRITE = 3
MESSAGE_SIZE = 32                                                  # two struct iovec { void *base; size_t len; } on a 64-bit kernel
NSM_IOCTL = (IOC_READ_WRITE << 30) | (MESSAGE_SIZE << 16) | (NSM_IOCTL_MAGIC << 8) | 0      # _IOWR(0x0A, 0, struct nsm_message)
RESPONSE_MAX = 0x3000
MAX_USER_DATA = 512
KNOWN_ERRORS = ("InvalidArgument", "InvalidIndex", "InvalidResponse", "ReadOnlyIndex", "InvalidOperation", "BufferTooSmall", "InputTooLarge", "InternalError")


class NsmError(Exception):
    pass


def encode_request(user_data=None, nonce=None, public_key=None):
    """The CBOR request the NSM expects for an attestation document."""
    for name, v, limit in (("user_data", user_data, MAX_USER_DATA), ("nonce", nonce, MAX_USER_DATA), ("public_key", public_key, MAX_USER_DATA)):
        if v is not None and (not isinstance(v, (bytes, bytearray)) or len(v) > limit):
            raise NsmError("%s must be at most %d bytes" % (name, limit))
    return agent_tee.cbor_encode({"Attestation": {"user_data": None if user_data is None else bytes(user_data), "nonce": None if nonce is None else bytes(nonce),
                                                 "public_key": None if public_key is None else bytes(public_key)}})


def parse_response(raw):
    """The attestation document inside an NSM response, or NsmError naming the NSM's own error."""
    try:
        r = agent_tee.cbor_decode(raw)
    except agent_tee.TeeError as e:
        raise NsmError("an unreadable NSM response (%s)" % e)
    if isinstance(r, dict) and "Error" in r:
        err = r["Error"]
        raise NsmError("the NSM refused the request: %s" % (err if err in KNOWN_ERRORS else "an unknown error"))
    inner = r.get("Attestation") if isinstance(r, dict) else None
    doc = inner.get("document") if isinstance(inner, dict) else None
    if not isinstance(doc, bytes) or not doc:
        raise NsmError("the NSM response carries no attestation document")
    return doc


def _real_ioctl(fd, request, arg):
    fcntl.ioctl(fd, request, arg, True)


def request_attestation(user_data=None, nonce=None, public_key=None, device=DEVICE, opener=os.open, closer=os.close, ioctl=_real_ioctl):
    """Ask the NSM for an attestation document. `opener`, `closer` and `ioctl` exist so that the kernel interface can be emulated in tests; in a real enclave leave them alone."""
    if ctypes.sizeof(ctypes.c_void_p) != 8 or struct.pack("=I", 1)[0] != 1:
        raise NsmError("the nsm_message layout here assumes a 64-bit little-endian machine (as every Nitro enclave is)")
    req = encode_request(user_data, nonce, public_key)
    req_buf = ctypes.create_string_buffer(req, len(req))
    resp_buf = ctypes.create_string_buffer(RESPONSE_MAX)
    msg = bytearray(struct.pack("<QQQQ", ctypes.addressof(req_buf), len(req), ctypes.addressof(resp_buf), RESPONSE_MAX))
    try:
        fd = opener(device, os.O_RDWR)
    except OSError as e:
        raise NsmError("cannot open %s (%s): this must run INSIDE a Nitro enclave" % (device, type(e).__name__))
    try:
        try:
            ioctl(fd, NSM_IOCTL, msg)
        except OSError as e:
            raise NsmError("the NSM ioctl failed (%s)" % type(e).__name__)
    finally:
        closer(fd)
    resp_len = struct.unpack_from("<Q", msg, 24)[0]                       # the kernel writes the response length back into the second iovec
    if not 0 < resp_len <= RESPONSE_MAX:
        raise NsmError("the NSM returned an impossible response length")
    return parse_response(resp_buf.raw[:resp_len])


def attest_service(service_pubkey, plan_hash, commitment, manifest=None, nonce=None, public_key=None, **kw):
    """Evidence for THIS service: bind {service key, plan, seed commitment, code measurement}, put the binding's digest in the document's user_data, and package the document with the binding."""
    manifest = manifest if manifest is not None else agent_tee.code_manifest()
    bind = agent_tee.binding(service_pubkey, plan_hash, commitment, agent_tee.code_measurement(manifest))
    doc = request_attestation(agent_tee.binding_digest(bind), nonce, public_key, **kw)
    return agent_tee.make_evidence("aws-nitro", bind, doc, manifest)
