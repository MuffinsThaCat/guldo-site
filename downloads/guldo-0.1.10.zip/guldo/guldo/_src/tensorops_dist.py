"""A simulated CLUSTER for counted solvers: per-device work, explicit collectives and what they cost, exactly. A run-time layer over tensorops.py, used by tflops_dist_runner.py in the counting child ONLY.

tensorops.py (and its cost table) is not modified: `install(tensorops, ranks)` wraps its functions and its Tensor class in this process. The solver then writes an SPMD-style program for up to `ranks` devices:

  tp.use(k)                  make device k current: tensors made from now on with stream, tensor, zeros live on device k
  every tensor lives on ONE device; an operation on tensors of different devices is an ERROR (communicate first); its arithmetic is charged to the device its operands live on
  tp.all_reduce(xs)          xs[i] on device i, all one shape: returns p tensors, device i holding the elementwise SUM   (ring: 2(p-1) rounds, 2(p-1)/p * n * 8 bytes per device)
  tp.reduce_scatter(xs)      as all_reduce but device i keeps only chunk i of the sum, split along axis 0              ((p-1) rounds, (p-1)/p * n * 8 bytes per device)
  tp.all_gather(xs)          xs[i] on device i, all one shape: every device gets the concatenation along axis 0       ((p-1) rounds, (p-1) * m * 8 bytes per device, m = one shard's elements)
  tp.broadcast(x, p)         x on device 0 copied to devices 0..p-1                                                   (ceil(log2 p) rounds, ceil(log2 p) * n * 8 bytes)
  tp.exchange(sends)         sends = [(tensor, dst), ...], one send from each device at most: every pair moves in ONE superstep (a pipeline's hand-off, a ring shift)   (1 round, the largest bytes any device sends or receives)
  tp.all_to_all(xss)         xss[i][j] on device i goes to device j; chunks may differ in size (load imbalance), even be empty        (p-1 rounds, the largest bytes any device sends or receives)
  MEMORY. Each device holds the tensors alive on it (8 bytes per element, a view counted as a copy); the run records the PEAK any one device reached, and when the instance gives a per-device capacity a device
  that would pass it ends the run with OutOfDeviceMemory (a BaseException a solver cannot catch). That is what makes strategies whose point is CAPACITY (tensor, pipeline, expert parallelism, sharded optimiser state) testable.
  HOST TRANSFERS: item() and tolist() (device to host) and tensor(list) (host to device) are charged like a message (one round, n * 8 bytes): data cannot be teleported between devices through Python for free.

BULK-SYNCHRONOUS ACCOUNTING (Valiant's BSP). Between two collectives each device does its own arithmetic, one flop per time unit, so the phase takes as long as its BUSIEST device; every collective and every host
transfer is a barrier. The run's numbers, all exact integers:
    wcrit   the sum over phases of the busiest device's flops   (so load imbalance costs exactly what it costs)
    rounds  the total message rounds on the critical path
    comm    the total bytes per device on the critical path, times L = lcm(1..ranks) (so ring formulas stay integers; divide by L)
and with the solver's own sequential Python instructions `steps` (counted, as everywhere, one each, and charged IN FULL as serial time: the simulation runs every rank's Python in one thread, so for a symmetric
SPMD program this overstates a real rank's Python by up to a factor of `ranks`; it can never understate, so work cannot be hidden in Python) the time of the run on a machine of latency alpha (flop-times per round)
and inverse bandwidth beta (flop-times per byte) is EXACTLY   wcrit + steps + alpha * rounds + beta * comm / L.   One run therefore fixes its time on EVERY interconnect, and two runs can be compared on all of
them at once (tflops_dist.py): one dominates if it is no worse in all of wcrit + steps, rounds and comm, otherwise the winner depends on the machine and the crossover is computed, not measured.

What this is not: a measurement, a topology model (every collective is a ring or a tree over identical links), a model of overlap between compute and communication (a collective is a barrier, so it can only
overstate a solver that would have overlapped them), of congestion, of the arithmetic of the reduction itself (at most n per device against 16 n bytes moved), or of memory. See PROTOCOL.md.
"""
import math

import numpy as np

_PHASE = {}
_W = [0]
_R = [0]
_C = [0]
_CUR = [0]
_CFG = {"ranks": 1, "L": 1}
_LIVEK = {}        # per device: bytes of tensors alive on it now (8 per element; a view counts as a copy)
_PEAKK = {}        # per device: the most bytes alive on it at one instant
_CAPK = [None]     # the most bytes any one device may hold (None: unlimited); past it the run dies with OutOfDeviceMemory


class OutOfDeviceMemory(BaseException):
    """A BaseException, so a solver's `except Exception` cannot swallow it: a device was asked to hold more than its capacity."""


def lcm_upto(n):
    out = 1
    for k in range(1, n + 1):
        out = out * k // math.gcd(out, k)
    return out


def reset(ranks, cap_bytes=None):
    _PHASE.clear()
    _LIVEK.clear()
    _PEAKK.clear()
    _W[0] = _R[0] = _C[0] = 0
    _CUR[0] = 0
    _CAPK[0] = cap_bytes
    _CFG["ranks"], _CFG["L"] = ranks, lcm_upto(ranks)


def counters():
    """-> (wcrit, rounds, comm): the critical-path work including the phase still open, the message rounds, and the per-device bytes times L."""
    return _W[0] + max(_PHASE.values() or [0]), _R[0], _C[0]


def peak_bytes():
    """The most bytes any ONE device held at one instant during the run."""
    return max(_PEAKK.values() or [0])


def _barrier():
    _W[0] += max(_PHASE.values() or [0])
    _PHASE.clear()


def _message(rounds, nbytes):
    _R[0] += rounds
    _C[0] += nbytes * _CFG["L"]


def install(tp, ranks, cap_bytes=None):
    """Wrap the tensorops module `tp` in this process, once, before any solver code runs. cap_bytes: the most any one device may hold (None: unlimited)."""
    Base = tp.Tensor
    reset(ranks, cap_bytes)

    class DistTensor(Base):
        __slots__ = ("_k",)

        def __init__(self, a):
            Base.__init__(self, a)
            self._k = None                      # set by `put` once the operation knows which device the result lives on

        def __del__(self):
            try:
                k = getattr(self, "_k", None)
                if k is not None:
                    _LIVEK[k] = _LIVEK.get(k, 0) - self._a.size * 8
            except (AttributeError, TypeError):      # never registered, or the interpreter is shutting down
                pass
            Base.__del__(self)

    def put(t, dev):
        """Place a freshly made tensor on a device and account for its bytes there; past the device's capacity the run ends."""
        t._k = dev
        n = _LIVEK.get(dev, 0) + t._a.size * 8
        _LIVEK[dev] = n
        if n > _PEAKK.get(dev, 0):
            _PEAKK[dev] = n
        if _CAPK[0] is not None and n > _CAPK[0]:
            raise OutOfDeviceMemory(f"device {dev} would hold {n} bytes, over its capacity of {_CAPK[0]}")
        return t

    def dev_of(args):
        """The one device the tensor operands live on (the current device if there are none); mixed devices are an error."""
        found = set()
        for a in args:
            if isinstance(a, DistTensor):
                found.add(a._k)
            elif isinstance(a, (list, tuple)):
                found |= {t._k for t in a if isinstance(t, DistTensor)}
        if len(found) > 1:
            raise ValueError("operands live on different devices " + str(sorted(found)) + ": communicate first (all_reduce, all_gather, ...)")
        return found.pop() if found else _CUR[0]

    def charged(dev, f0):
        d = tp._FLOPS[0] - f0
        if d:
            _PHASE[dev] = _PHASE.get(dev, 0) + d

    def method(name):
        fn = getattr(Base, name)

        def wrapper(self, *args):
            dev = dev_of((self,) + args)
            f0 = tp._FLOPS[0]
            r = fn(self, *args)
            charged(dev, f0)
            if isinstance(r, DistTensor):
                put(r, dev)
            return r
        return wrapper

    for name in ("__add__", "__radd__", "__sub__", "__rsub__", "__mul__", "__rmul__", "__truediv__", "__rtruediv__", "__neg__", "__matmul__", "__getitem__", "__setitem__"):
        setattr(DistTensor, name, method(name))

    base_item, base_tolist = Base.item, Base.tolist

    def host_read(base):
        def wrapper(self):
            f0 = tp._FLOPS[0]
            r = base(self)
            charged(self._k, f0)
            _barrier()
            _message(1, self._a.size * 8)
            return r
        return wrapper
    DistTensor.item, DistTensor.tolist = host_read(base_item), host_read(base_tolist)
    tp.Tensor = DistTensor

    def wrap(name, creator=False, host_write=False):
        fn = getattr(tp, name)

        def wrapper(*args, **kw):
            dev = _CUR[0] if creator else dev_of(args)
            f0 = tp._FLOPS[0]
            r = fn(*args, **kw)
            charged(dev, f0)
            if isinstance(r, DistTensor):
                put(r, dev)
                if host_write:
                    _message(1, r._a.size * 8)
            return r
        wrapper.__name__ = name
        setattr(tp, name, wrapper)

    for name in ("stream", "zeros", "causal_mask"):
        wrap(name, creator=True)
    wrap("tensor", creator=True, host_write=True)
    for name in ("take", "concat", "reshape", "transpose", "einsum", "exp", "sqrt", "relu", "sum", "max", "mean"):
        wrap(name)
    base_argmax = tp.argmax

    def argmax(x):
        f0 = tp._FLOPS[0]
        r = base_argmax(x)
        charged(x._k, f0)
        _barrier()
        _message(1, 8)
        return r
    tp.argmax = argmax

    def use(k):
        if isinstance(k, bool) or not isinstance(k, int) or not 0 <= k < _CFG["ranks"]:
            raise ValueError(f"use(k): a device number 0 .. {_CFG['ranks'] - 1}")
        _CUR[0] = k

    def group(xs):
        if not isinstance(xs, (list, tuple)) or not xs or not all(isinstance(t, DistTensor) for t in xs):
            raise TypeError("a collective takes a non-empty list of Tensors, one per device")
        p = len(xs)
        if p > _CFG["ranks"]:
            raise ValueError(f"a collective over {p} devices: this instance has {_CFG['ranks']}")
        if any(t._k != i for i, t in enumerate(xs)):
            raise ValueError("xs[i] must live on device i")
        if any(t._a.shape != xs[0]._a.shape for t in xs):
            raise ValueError("every tensor in a collective has the same shape")
        return p

    def place(arrs):
        out = []
        for i, a in enumerate(arrs):
            out.append(put(DistTensor(a), i))
        return out

    def all_reduce(xs):
        p = group(xs)
        n = xs[0]._a.size
        if p > 1:
            _barrier()
            _R[0] += 2 * (p - 1)
            _C[0] += 2 * (p - 1) * n * 8 * (_CFG["L"] // p)
        total = np.sum([t._a for t in xs], axis=0)
        return place([total.copy() for _ in range(p)])

    def reduce_scatter(xs):
        p = group(xs)
        n = xs[0]._a.size
        if xs[0]._a.ndim < 1 or xs[0]._a.shape[0] % p:
            raise ValueError("reduce_scatter splits axis 0 into p equal chunks")
        if p > 1:
            _barrier()
            _R[0] += p - 1
            _C[0] += (p - 1) * n * 8 * (_CFG["L"] // p)
        total = np.sum([t._a for t in xs], axis=0)
        return place([c.copy() for c in np.split(total, p, axis=0)])

    def all_gather(xs):
        p = group(xs)
        m = xs[0]._a.size
        if xs[0]._a.ndim < 1:
            raise ValueError("all_gather concatenates along axis 0: a tensor of at least one dimension")
        if p > 1:
            _barrier()
            _R[0] += p - 1
            _C[0] += (p - 1) * m * 8 * _CFG["L"]
        whole = np.concatenate([t._a for t in xs], axis=0)
        return place([whole.copy() for _ in range(p)])

    def broadcast(x, p):
        if not isinstance(x, DistTensor) or x._k != 0:
            raise ValueError("broadcast(x, p): x must live on device 0")
        if isinstance(p, bool) or not isinstance(p, int) or not 1 <= p <= _CFG["ranks"]:
            raise ValueError("broadcast(x, p): 1 <= p <= ranks")
        if p > 1:
            steps = (p - 1).bit_length()
            _barrier()
            _R[0] += steps
            _C[0] += steps * x._a.size * 8 * _CFG["L"]
        return place([x._a.copy() for _ in range(p)])

    def exchange(sends):
        """sends: a list of (tensor, dst) pairs, at most one send from each device and at most one arrival at each: ONE superstep in which every pair moves at once (a pipeline's hand-off to the next stage, a
        shift around a ring). Returns the received tensors in the same order, each on its dst. Cost: a barrier, one round, and the largest number of bytes any one device sends or receives."""
        if not isinstance(sends, (list, tuple)) or not sends:
            raise TypeError("exchange takes a non-empty list of (tensor, dst) pairs")
        srcs, dsts, sent, recv = set(), set(), {}, {}
        for item in sends:
            if not isinstance(item, (list, tuple)) or len(item) != 2 or not isinstance(item[0], DistTensor):
                raise TypeError("exchange takes (tensor, dst) pairs")
            t, dst = item
            if isinstance(dst, bool) or not isinstance(dst, int) or not 0 <= dst < _CFG["ranks"]:
                raise ValueError(f"exchange: a destination device 0 .. {_CFG['ranks'] - 1}")
            if t._k in srcs or dst in dsts:
                raise ValueError("exchange: at most one send from each device and one arrival at each")
            srcs.add(t._k)
            dsts.add(dst)
            if dst != t._k:
                sent[t._k] = t._a.size * 8
                recv[dst] = t._a.size * 8
        _barrier()
        _R[0] += 1
        _C[0] += max([*sent.values(), *recv.values(), 0]) * _CFG["L"]
        out = []
        for t, dst in sends:
            u = DistTensor(t._a.copy())
            out.append(put(u, dst))
        return out

    def all_to_all(xss):
        """xss: p lists of p tensors; xss[i][j] lives on device i and goes to device j (chunks may differ in size, even be empty: that is load imbalance). Returns p lists: out[j][i] = xss[i][j], on device j.
        Cost: a barrier, p-1 rounds, and the largest number of bytes any one device sends or receives (its own chunk stays put)."""
        if not isinstance(xss, (list, tuple)) or not xss or not all(isinstance(r, (list, tuple)) and len(r) == len(xss) for r in xss):
            raise TypeError("all_to_all takes p lists of p tensors")
        p = len(xss)
        if p > _CFG["ranks"]:
            raise ValueError(f"an all_to_all over {p} devices: this instance has {_CFG['ranks']}")
        for i, row in enumerate(xss):
            if not all(isinstance(t, DistTensor) and t._k == i for t in row):
                raise ValueError("xss[i][j] must be a Tensor living on device i")
        if p > 1:
            _barrier()
            _R[0] += p - 1
            sent = [sum(xss[i][j]._a.size * 8 for j in range(p) if j != i) for i in range(p)]
            recv = [sum(xss[i][j]._a.size * 8 for i in range(p) if i != j) for j in range(p)]
            _C[0] += max(sent + recv) * _CFG["L"]
        return [[put(DistTensor(xss[i][j]._a.copy()), j) for i in range(p)] for j in range(p)]

    tp.use, tp.all_reduce, tp.reduce_scatter, tp.all_gather, tp.broadcast, tp.exchange, tp.all_to_all = use, all_reduce, reduce_scatter, all_gather, broadcast, exchange, all_to_all
    return DistTensor
