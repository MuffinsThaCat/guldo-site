"""airealm with bytes counted, TECHNIQUE: as airealm_mem3_refit50.py but keeping only a quarter of the hidden units."""
import math

import tensorops as tp

CAL = 48
LAM = 1e-3


NOISE = {64: 64.0, 128: 64.0, 192: 64.0, 256: 76.0, 512: 84.0, 1024: 96.0}     # the noise scale per network width (decl.py)


def queries(H, seed, Q, X):
    """The noisy, clipped, scaled query matrix (Q x 784): x' / 255 with x' = clip(x + NOISE[H] u, 0, 255)."""
    v = tp.tensor(X) + tp.reshape(tp.stream(seed, 0, Q * 784), (Q, 784)) * NOISE[H]
    return (tp.relu(v) - tp.relu(v - 255.0)) * (1.0 / 255.0)


def labels_of(L):
    rows = L.tolist()
    return [row.index(max(row)) for row in rows]


def solve_spd(G, R, m, k):
    """Solve G x = R (m x m symmetric positive definite, m x k right-hand side) by Gauss-Jordan elimination on [G | R]."""
    A = tp.concat([G, R], 1)
    for j in range(m):
        row = A[j:j + 1] / A[j:j + 1, j:j + 1]
        M = A - A[:, j:j + 1] * row
        A = tp.concat([M[0:j], row, M[j + 1:m]], 0)
    return A[:, m:m + k]

KEEP = 0.25


def solve(H, Q, seed, X, W1, b1, W2, b2):
    x = queries(H, seed, Q, X)
    W1t = tp.tensor(W1)
    W2t = tp.transpose(tp.tensor(W2), (1, 0))
    k = max(1, int(math.ceil(KEEP * H)))
    hc = tp.relu(x[0:CAL] @ tp.transpose(W1t, (1, 0)) + tp.reshape(tp.tensor(b1), (1, H)))
    imp = (tp.mean(hc, 0) * tp.sqrt(tp.sum(W2t * W2t, 1))).tolist()
    keep = [i for (v, i) in sorted(zip(imp, range(H)))[H - k:]]
    W1k = tp.take(W1t, keep)
    b1k = tp.reshape(tp.take(tp.reshape(tp.tensor(b1), (H, 1)), keep), (1, k))
    Hk = tp.relu(x[0:CAL] @ tp.transpose(W1k, (1, 0)) + b1k)
    A = tp.concat([Hk, tp.zeros((CAL, 1)) + 1.0], 1)
    teacher = hc @ W2t + tp.reshape(tp.tensor(b2), (1, 10))
    At = tp.transpose(A, (1, 0))
    eye = tp.tensor([[LAM if i == j else 0.0 for j in range(k + 1)] for i in range(k + 1)])
    coef = solve_spd(At @ A + eye, At @ teacher, k + 1, 10)
    h = tp.relu(x @ tp.transpose(W1k, (1, 0)) + b1k)
    return labels_of(tp.concat([h, tp.zeros((Q, 1)) + 1.0], 1) @ coef)
