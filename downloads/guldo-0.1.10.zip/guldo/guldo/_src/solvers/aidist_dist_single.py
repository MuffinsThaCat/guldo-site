"""aidist in the cluster-counted API, REFERENCE: one device does everything. No communication; all the arithmetic is on device 0."""
import math

import tensorops as tp

C = 8


def ints(g):
    """g: a 1-D tensor on device 0 -> the answer's integers (units of 2^-40)."""
    return list(map(int, (g * 1099511627776.0).tolist()))


def local_grads(x, W1T, W2, Y, B):
    """The gradient pieces for the batch rows in x (the loss is averaged over the WHOLE batch B, so each piece is already scaled by 1/(B*C))."""
    a = x @ tp.transpose(W1T, (1, 0))
    h1 = tp.relu(a)
    dy = (h1 @ W2 - Y) * (1.0 / (B * C))
    dh = (dy @ tp.transpose(W2, (1, 0))) * (h1 / (tp.sqrt(a * a) + 1e-300))
    return tp.transpose(dh, (1, 0)) @ x, tp.transpose(h1, (1, 0)) @ dy


def flat(a, b):
    return tp.concat([tp.reshape(a, (a.shape[0] * a.shape[1],)), tp.reshape(b, (b.shape[0] * b.shape[1],))], 0)


def solve(seed, d, B, P):
    h = 4 * d
    tp.use(0)
    x = tp.reshape(tp.stream(seed, 0, B * d), (B, d))
    W1T = tp.reshape(tp.stream(seed, B * d, h * d), (h, d)) * math.sqrt(3.0 / d)
    W2 = tp.reshape(tp.stream(seed, B * d + h * d, h * C), (h, C)) * math.sqrt(3.0 / h)
    Y = tp.reshape(tp.stream(seed, B * d + h * d + h * C, B * C), (B, C))
    g1, g2 = local_grads(x, W1T, W2, Y, B)
    return ints(flat(g1, g2))
