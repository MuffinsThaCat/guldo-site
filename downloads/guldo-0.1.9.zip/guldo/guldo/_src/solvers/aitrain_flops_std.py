"""aitrain in the counted-operations API, TECHNIQUE: scale every feature to unit size (divide by its root mean square), run 40 gradient steps, then fold the scaling back into the weights."""
import math

import tensorops as tp

K = 3
KAPPA = 30.0
STEPS = 40
LR = 1.0


def solve(seed, d, n, labels):
    sc = tp.tensor([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = tp.reshape(tp.stream(seed, 0, n * d), (n, d)) * sc
    inv = 1.0 / tp.sqrt(tp.mean(X * X, 0))
    Xs = X * inv
    Y = tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(n)])
    Xt = tp.transpose(Xs, (1, 0))
    W = tp.zeros((d, K))
    for step in range(STEPS):
        Z = Xs @ W
        E = tp.exp(Z - tp.max(Z, 1, True))
        W = W - (Xt @ (E / tp.sum(E, 1, True) - Y)) * (LR / n)
    return [int(x * 1048576.0) for x in tp.reshape(W * tp.reshape(inv, (d, 1)), (d * K,)).tolist()]
