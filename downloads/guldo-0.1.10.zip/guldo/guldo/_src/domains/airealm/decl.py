"""Declaration of a REAL-DATA, REAL-MODEL, LOOKUP-RESISTANT inference domain at MNIST scale: label a batch of real handwritten digits, corrupted by a seed-keyed noise, with a real trained network, as cheaply as you can.

Nothing is planted. The images are real (the 10000 MNIST TEST digits, 28 x 28, pixel values 0..255) and the model is a real network that training produced: a 784 -> H -> 10 ReLU MLP (H = size = 64, 128, 192,
256, 512 or 1024) trained on the 60000 MNIST TRAINING images only (train.py rebuilds everything; the networks reach 97.2%, 97.6%, 97.9%, 98.0%, 98.1% and 98.1% on the test images). The weights are committed in this directory by content hash
(a changed byte fails at import), rounded to 6 decimals so they travel as short numbers.

The instance's ARGUMENTS are [H, Q, seed, X, W1, b1, W2, b2]: Q = 128 test images drawn by a seed-keyed choice (X, Q x 784 integer pixels) and the network (W1 H x 784, b1 H, W2 10 x H, b2 10). The images the network
is asked about are the clean test images PLUS noise the solver regenerates from `seed`:  x' = clip(x + s u, 0, 255) with s = 64 (widths 64 to 192), 76 (256), 84 (512) or 96 (1024), and u the SplitMix64 stream under `seed` (tensorops.stream(seed, 0, Q * 784), u in [-1, 1),
row-major, the same floats as domains/aiinfer), clip by relu(x + 64 u) - relu(x + 64 u - 255). The network computes logits = W2 relu(W1 (x' / 255) + b1) + b2. The answer is the list of Q class labels (ints 0-9) that
agrees with the network's own prediction on at least 98% of the queries (at most 2 of 128 may differ; a tie counts as agreement). The judge is self-contained (it recomputes from the arguments) and never looks at the true labels.

WHY THE NOISE. The domain `aireal` (8x8 digits) is attackable by a precomputed lookup table: its pool and networks are public and fixed, so the answers are a fixed table. Here the answers depend on the noise, which
depends on a seed the entrants do not have until the round closes (a committed master seed, as everywhere in this project), so a table of the network's answers on the CLEAN images agrees with the network on the noisy ones
only about 90% of the time at every width (calibrated per width: at the same +-64 the clean table agrees 90% of the time at width 64 but 95% at 256, 96% at 512 and 97% at 1024, and passed the 98% bar on 30% of the width-1024 instances, which is why the scale rises with the width), far under the 98% bar, and a solver cannot know the noise in advance. Honest techniques are unaffected: they compute the network on the noisy images.
The price is that the queries are no longer pristine digits but digits with uniform noise of +-64 to +-96 of 255 (25 to 38% of the range), a heavy corruption; the networks still read them (about 89 to 90% right).

What this is for: the planted domains test techniques on models built to be compressible; `aireal` asked the question of a small real network; this one asks it at MNIST scale (up to 800 thousand weights), with queries that cannot
be answered by lookup, and with instances far larger than the 16 KB the plain counting transport can carry (tflops._run_watched deadlocks above that; the version-3 tool uses runwatch.py, which does not).

COUNTED-ONLY BY NECESSITY. An instance carries the whole network, 0.9 MB at width 64, 2.5 MB at width 256 and about 15 MB at width 1024, and compile_domain.py refuses instances over 1 MiB (the timed protocol's limit), so this domain
cannot be compiled for the timed protocol at widths of 128 and above: `compile_domain.py check` reports that one extra FAIL besides "not compiled". That is a property of the scale, not an oversight.

The cost is counted operations and bytes (tflops_mem3.py): exactly reproducible, not a time. The weights are given in the arguments, so loading them is free for everyone.
"""
import hashlib
import hmac
import os

import numpy as np

NAME = "airealm"
VERSION = "airealm-v2"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (64, 1024)
SIZE_STEP = 64
REFERENCE_SOLVER = "reference.py"
HERE = os.path.dirname(os.path.abspath(__file__))
WIDTHS = (64, 128, 192, 256, 512, 1024)
Q = 128
NOISE = {64: 64.0, 128: 64.0, 192: 64.0, 256: 76.0, 512: 84.0, 1024: 96.0}   # the noise scale per network width: wider networks are more noise-robust, so a clean-image table would otherwise pass them
AGREE = 0.98
MNIST_SHA256 = "c3f9adf9c66efb572b1f9326c3a511b45910c7173b97be66ceceeeeaef6b802b"
MODEL_SHA256 = {64: "ed9fc466d154eecbb8f4ee6ef2b2ce850ee07a9720ef3e305d1122ec8d36e691", 128: "51920412f4203c5fdf2c409a2032021df9626e083bc746fe594716566cabe4ff",
                192: "e4d9ff87e3d523ed99d284094370dcd90e8de798eef352f9e8bbfed9c7a14f3b", 256: "47850fa8070ef567f1d2957a7bd09d6964f970a2c4970f6565aaf3ca3d8e60f5",
                512: "b72da9c25643b6101fb73f736f6658f25def0cfb8ae700790fe96aed8b3b4f83", 1024: "5ea23f69b275e4224888523c2fc8e27e40a45a5a936f1e57136a0058654b6b47"}
DOC = ("solve(H, Q, seed, X, W1, b1, W2, b2): X is Q x 784 integer pixels (0..255) of real MNIST test digits; the queries are x' = clip(x + s u, 0, 255) with s = 64 (H <= 192), 76 (256), 84 (512), 96 (1024) and u = tensorops.stream(seed, 0, Q*784) (u in [-1, 1), "
       "row-major, reshaped Q x 784); the network is logits = W2 relu(W1 (x'/255) + b1) + b2 with W1 H x 784, b1 H, W2 10 x H, b2 10. Return the list of Q class labels (ints 0-9) that agrees with the network's own "
       "prediction (the arg-max logit) on at least 98% of the queries. Return None for no answer.")
REFERENCE_NOTE = ("The dense network on the noisy batch: one batched product per layer in float64. Whether pruning, distillation or lower precision pay on a REAL network at this scale, and by how much, is what the "
                  "domain measures; a lookup table of the clean images' answers does not pass it.")


def _content_hash(*arrs):
    m = hashlib.sha256()
    for a in arrs:
        m.update(np.ascontiguousarray(a).tobytes())
    return m.hexdigest()


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


_CACHE = {}


def load():
    """-> (images (10000 x 784 uint8), labels (10000), {H: (W1, b1, W2, b2)}), each checked against its committed content hash."""
    if "d" not in _CACHE:
        d = np.load(os.path.join(HERE, "mnist_test.npz"))
        X, y = d["X"], d["y"]
        if _content_hash(X, y) != MNIST_SHA256:
            raise RuntimeError("airealm: mnist_test.npz does not match its committed content hash")
        models = {}
        for H in WIDTHS:
            m = np.load(os.path.join(HERE, f"model_{H}.npz"))
            P = (m["W1"], m["b1"], m["W2"], m["b2"])
            if _content_hash(*P) != MODEL_SHA256[H]:
                raise RuntimeError(f"airealm: model_{H}.npz does not match its committed content hash")
            models[H] = P
        _CACHE["d"] = (X, y, models)
    return _CACHE["d"]


def _seed(master, tag, size, idx):
    return int.from_bytes(hmac.new(master, f"airealm-v2:{tag}:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def queries(seed, X, H):
    """The noisy queries the width-H network is asked about, float64 Q x 784."""
    u = _uniform(seed, 0, X.shape[0] * 784).reshape(X.shape[0], 784)
    v = X.astype(np.float64) + NOISE[H] * u
    return np.maximum(v, 0.0) - np.maximum(v - 255.0, 0.0)


def logits(args):
    H, q, seed, X, W1, b1, W2, b2 = args
    Xq = queries(seed, np.asarray(X), H)
    return np.maximum(Xq / 255.0 @ np.asarray(W1).T + np.asarray(b1), 0.0) @ np.asarray(W2).T + np.asarray(b2)


def derive(master: bytes, size: int, idx: int) -> dict:
    X, y, models = load()
    pick = np.random.RandomState(_seed(master, "pick", size, idx) % (2 ** 32)).choice(len(y), Q, replace=False)
    W1, b1, W2, b2 = models[size]
    args = [size, Q, _seed(master, "noise", size, idx), X[pick].astype(int).tolist(), W1.tolist(), b1.tolist(), W2.tolist(), b2.tolist()]
    return {"args": args, "planted": [int(v) for v in np.argmax(logits(args), axis=1)], "truth": [int(y[i]) for i in pick], "clean": [int(v) for v in np.argmax(
        np.maximum(X[pick].astype(np.float64) / 255.0 @ W1.T + b1, 0.0) @ W2.T + b2, axis=1)]}


def verify(inst: dict, ans) -> bool:
    args = inst["args"]
    q = args[1]
    if not isinstance(ans, list) or len(ans) != q:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or not 0 <= v < 10 for v in ans):
        return False
    L = logits(args)
    agree = int((L[np.arange(q), np.asarray(ans)] >= L.max(axis=1)).sum())
    return bool(agree >= int(np.ceil(AGREE * q)))
