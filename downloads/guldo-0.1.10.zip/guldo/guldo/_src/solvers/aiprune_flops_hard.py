"""aiprune in the counted-operations API, OVER-PRUNED CHEAT: structured pruning exactly as aiprune_flops_prune.py, but dropping every unit whose importance is below 12% of the largest instead of 2%. It
leaves far fewer units, so it is much cheaper, and it removes units that still matter: on most instances the labels leave the judge's tolerance and the judge must reject it."""
import math

import tensorops as tp

C = 10
ZETA = 3.0
KEEP = 0.12           # CHEAT: keep only units within 12% of the largest importance: too few, and the labels leave the judge's tolerance


def solve(seed, d, Q):
    H = 4 * d
    W1 = tp.reshape(tp.stream(seed, 0, H * d), (H, d)) * math.sqrt(3.0 / d)
    gain = tp.exp((tp.stream(seed, H * d, H) + 1.0) * (-ZETA * math.log(10.0)))
    W2t = tp.transpose(tp.reshape(tp.stream(seed, H * d + H, C * H), (C, H)) * math.sqrt(3.0 / H) * tp.reshape(gain, (1, H)), (1, 0))      # H x C
    X = tp.reshape(tp.stream(seed, H * d + H + C * H, Q * d), (Q, d))
    imp = (tp.sum(W1 * W1, 1) * tp.sum(W2t * W2t, 1)).tolist()      # importance squared, per unit
    cut = KEEP * KEEP * max(imp)
    keep = [i for i in range(H) if imp[i] >= cut]
    rows = (tp.relu(X @ tp.transpose(tp.take(W1, keep), (1, 0))) @ tp.take(W2t, keep)).tolist()
    return [row.index(max(row)) for row in rows]
