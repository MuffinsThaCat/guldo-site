"""Worked DISTINGUISHING example: toy LWE vs uniform (see advantage_core.py). solve(q, A, b) returns 1 if (A, b) looks like LWE (b = A s + e with s ternary and e in {-1,0,1}), 0 if b is uniform.
Instances come in PAIRS (index 2k and 2k+1): exactly one of each pair is LWE, in an order fixed by the committed seed, so answering a constant scores exactly 1/2 for any even instance count.
Reference: a coin from the data (no better than chance). A brute-force search over the 3^n ternary secrets distinguishes perfectly at these sizes."""
DOC = "solve(q, A, b): return 1 if (A, b) is LWE (b = A s + e mod q, s ternary, e in {-1,0,1}), 0 if b is uniform. The score is the advantage over guessing."
import hashlib
import hmac
import random

NAME = "lwedist"
VERSION = "lwedist-v1"
KIND = "advantage"
SIZE_RANGE = (5, 7)          # secret length n
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
MODULUS = 17
SAMPLES = 30
REFERENCE_NOTE = "A coin read off the parity of b: no better than guessing. Exhaustive search over the 3^n ternary secrets distinguishes perfectly at these toy sizes."


def coin(master, size, idx):
    """1 = LWE. Pair k = idx // 2 holds one of each; the seed decides which comes first."""
    first = hmac.new(master, f"lwedist-v1:pair:{size}:{idx // 2}".encode(), hashlib.sha256).digest()[0] & 1
    return first ^ (idx & 1)


def derive(master, size, idx):
    rng = random.Random(hmac.new(master, f"lwedist-v1:{size}:{idx}".encode(), hashlib.sha256).digest())
    c = coin(master, size, idx)
    A = [[rng.randrange(MODULUS) for _ in range(size)] for _ in range(SAMPLES)]
    if c:
        s = [rng.choice((-1, 0, 1)) for _ in range(size)]
        b = [(sum(a * x for a, x in zip(row, s)) + rng.choice((-1, 0, 1))) % MODULUS for row in A]
    else:
        b = [rng.randrange(MODULUS) for _ in range(SAMPLES)]
    return {"args": [MODULUS, A, b], "planted": c}


def verify(inst, ans):
    return ans in (0, 1) and not isinstance(ans, bool)
