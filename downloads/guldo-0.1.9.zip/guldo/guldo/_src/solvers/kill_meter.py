"""Red-team: tries to kill, stop or trace the root meter that supervises it, and to change the container. The container grants the meter CAP_KILL so it can
enforce its deadline; the solver, running as an unprivileged uid, must NOT inherit that power. Reports what it managed by raising; every entry must
be False/an error name, and the report itself reaching the judge proves the meter survived."""
import ctypes
import os
import signal


def _try(f):
    try:
        f()
        return True
    except BaseException as e:  # noqa: BLE001
        return type(e).__name__


def solve(basis, bound2):
    libc = ctypes.CDLL(None, use_errno=True)
    rep = {"uid": os.getuid(), "ppid": os.getppid()}
    rep["kill_parent"] = _try(lambda: os.kill(os.getppid(), signal.SIGKILL))
    rep["stop_parent"] = _try(lambda: os.kill(os.getppid(), signal.SIGSTOP))
    rep["kill_pid1"] = _try(lambda: os.kill(1, signal.SIGKILL))
    rep["ptrace_parent"] = libc.ptrace(16, os.getppid(), 0, 0) == 0          # PTRACE_ATTACH
    rep["mount"] = libc.mount(b"none", b"/tmp", b"tmpfs", 0, None) == 0
    rep["write_proc_sys"] = _try(lambda: open("/proc/sys/kernel/hostname", "w").write("pwned"))
    rep["setgid_root"] = _try(lambda: os.setgid(0))
    raise RuntimeError(repr(rep))
