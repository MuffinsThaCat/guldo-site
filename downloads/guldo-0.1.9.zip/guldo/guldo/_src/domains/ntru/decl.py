"""Declaration of a key-recovery domain: NTRU in R_q = Z_q[x]/(x^n - x - 1) (the NTRU Prime ring), q a prime near 3329 chosen per n so that
x^n - x - 1 is irreducible mod q, i.e. R_q is a FIELD.

A solver receives (q, h) with h = g * f^(-1) mod q for ternary f, g. It returns the pair as one list [f_0..f_{n-1}, g_0..g_{n-1}] of 2n ints
in {-1, 0, 1}, f and g not all zero, with h * f = g in R_q (g read centred). Any accepted pair counts, and the verifier does not care which is
returned. size = n; the reference is a meet-in-the-middle search over f (about 3^(n/2) work).

Why not x^n + 1: for n not a power of two it factors, and its zero-divisors give public ternary vectors (for odd n, the alternating vector
(1, -1, 1, ...)) that are valid answers whenever h takes a value like +-1 at the matching root: free answers on about 1 in 2n instances,
found by an audit. In a field there are no zero-divisors, so the only short answers should be the planted pair and its negation.
This is still a domain where attacks that exploit ring structure live (lattice reduction of the NTRU lattice; subfield and overstretched
attacks need a different ring, so they are NOT covered here); at these toy parameters plain reduction wins by a very large margin.
"""
import hashlib
import hmac
import itertools
import random

NAME = "ntru"
VERSION = "ntru-v5"           # bump whenever derive() changes
SIZE_RANGE = (24, 28)
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
DOC = ("solve(q, h): h is a length-n coefficient list (lowest degree first) of an element of Z_q[x]/(x^n - x - 1), q prime. Return a list of 2n ints in "
       "{-1, 0, 1}: f then g, neither all zero, with h * f = g in that ring (reduced mod q, centred). Return None for no answer.")
REFERENCE_NOTE = ("The reference is a meet-in-the-middle search over ternary f (about 3^(n/2) work). Lattice reduction of the NTRU lattice is known "
                  "to beat it by a wide margin as n grows; no claim is made about which is fastest. The ring is the NTRU Prime field Z_q[x]/(x^n - x - 1) with a "
                  "small modulus, so overstretched-modulus and subfield attacks do not apply here. Scope: toy rings (n <= 28, ternary keys), NOT evidence about attacks on real NTRU parameters, and a certificate "
                  "here must not be read as one.")


def _centre(x, q):
    x %= q
    return x - q if x > q // 2 else x


def mulmod(a, s, q):
    """a * s in Z_q[x]/(x^n - x - 1), coefficient lists of equal length n."""
    n = len(a)
    out = [0] * (2 * n - 1)
    for i in range(n):
        if a[i]:
            for j in range(n):
                out[i + j] += a[i] * s[j]
    for k in range(2 * n - 2, n - 1, -1):  # x^k = x^(k-n) * (x + 1); k - n + 1 <= n - 1, so one pass suffices
        c = out[k]
        out[k - n] += c
        out[k - n + 1] += c
    return [c % q for c in out[:n]]


def _is_prime(q):
    return q > 1 and all(q % d for d in range(2, int(q ** 0.5) + 1))


def _trim(p):
    while p and p[-1] == 0:
        p.pop()
    return p


def _gcd_is_one(a, b, q):
    """gcd of two polynomials over F_q (lowest degree first) is a nonzero constant."""
    a, b = _trim([c % q for c in a]), _trim([c % q for c in b])
    while b:
        inv = pow(b[-1], -1, q)
        while len(a) >= len(b):
            c = a[-1] * inv % q
            sh = len(a) - len(b)
            for i, bi in enumerate(b):
                a[sh + i] = (a[sh + i] - c * bi) % q
            _trim(a)
            if not a:
                break
        a, b = b, a
    return len(a) == 1


def _powmod(base, e, q, n):
    result = [1] + [0] * (n - 1)
    while e:
        if e & 1:
            result = mulmod(result, base, q)
        base = mulmod(base, base, q)
        e >>= 1
    return result


def _irreducible(n, q):
    """Rabin's test for x^n - x - 1 over F_q."""
    f = [-1, -1] + [0] * (n - 2) + [1]
    X = [0, 1] + [0] * (n - 2)
    frob = [X]                       # frob[k] = x^(q^k) mod f
    for _ in range(n):
        frob.append(_powmod(frob[-1], q, q, n))
    if frob[n] != X:
        return False
    for r in range(2, n + 1):
        if n % r == 0 and _is_prime(r):
            d = [(a - b) % q for a, b in zip(frob[n // r], X)]
            if not _gcd_is_one(f, d, q):
                return False
    return True


_Q_CACHE = {}


def modulus(n):
    """The first prime q >= 3329 for which x^n - x - 1 is irreducible mod q (so R_q is a field); a pure function of n."""
    if n not in _Q_CACHE:
        q = 3329
        while not (_is_prime(q) and _irreducible(n, q)):
            q += 1
        _Q_CACHE[n] = q
    return _Q_CACHE[n]


def _solve(M, g, q):
    """Solve M h = g mod prime q by Gauss-Jordan; None if M is singular."""
    n = len(M)
    R = [row[:] + [gi] for row, gi in zip(M, g)]
    for c in range(n):
        piv = next((r for r in range(c, n) if R[r][c] % q), None)
        if piv is None:
            return None
        R[c], R[piv] = R[piv], R[c]
        inv = pow(R[c][c], -1, q)
        R[c] = [x * inv % q for x in R[c]]
        for r in range(n):
            if r != c and R[r][c] % q:
                f = R[r][c]
                R[r] = [(x - f * y) % q for x, y in zip(R[r], R[c])]
    return [R[i][n] for i in range(n)]


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"ntru-v5:{size}:{idx}".encode(), hashlib.sha256).digest())
    n = size
    q = modulus(n)
    while True:
        f = [rng.choice((-1, 0, 1)) for _ in range(n)]
        g = [rng.choice((-1, 0, 1)) for _ in range(n)]
        # sparse keys make degenerate instances (a monomial f makes h itself ternary, so f = 1, g = h is a free answer): require at least n // 2 nonzero
        if sum(map(bool, f)) < n // 2 or sum(map(bool, g)) < n // 2:
            continue
        # column j of the multiplication-by-f matrix is f * x^j
        cols, col = [], f[:]
        for _ in range(n):
            cols.append(col)
            col = mulmod(col, [0, 1] + [0] * (n - 2), q)
        M = [[cols[j][i] % q for j in range(n)] for i in range(n)]
        h = _solve(M, [c % q for c in g], q)
        if h is not None and not _sparse_answer(h, q, n):
            return {"args": [q, h], "planted": f + g}


def _sparse_answer(h, q, n):
    """True if some f' of weight <= 3 already gives a ternary nonzero g' = h f': a free answer for a solver that enumerates sparse vectors
    (the lattice has other short vectors besides the planted pair; an audit found them on ~3% of instances at n = 10, ~0 by n = 16)."""
    cols, col = [], [c % q for c in h]
    for _ in range(n):
        cols.append(col)
        col = mulmod(col, [0, 1] + [0] * (n - 2), q)
    for k in (1, 2, 3):
        for pos in itertools.combinations(range(n), k):
            for sg in itertools.product((1, -1), repeat=k - 1):
                signs = (1,) + sg            # f' and -f' are the same up to sign, so fix the first sign
                g = [sum(s * cols[p][i] for s, p in zip(signs, pos)) % q for i in range(n)]
                if all(c <= 1 or c >= q - 1 for c in g) and any(g):
                    return True
    return False


def verify(inst: dict, ans) -> bool:
    q, h = inst["args"]
    n = len(h)
    if not isinstance(ans, list) or len(ans) != 2 * n:
        return False
    for c in ans:
        if isinstance(c, bool) or not isinstance(c, int) or c not in (-1, 0, 1):
            return False
    f, g = ans[:n], ans[n:]
    if not any(f) or not any(g):
        return False
    prod = mulmod(h, f, q)
    return all(_centre(p, q) == gi for p, gi in zip(prod, g))
