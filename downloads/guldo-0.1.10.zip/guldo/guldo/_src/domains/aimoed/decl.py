"""Declaration of an EXPERT-parallelism domain: run a mixture-of-experts layer over a batch of tokens on 8 devices that cannot each hold all the experts, with as little time as the machine allows.

size = d. T = 8 d tokens of width d (X, T x d). There are E = 8 experts, each a two-layer ReLU MLP  y = relu(x W1_e) W2_e  with W1_e (d x 2d, scaled by sqrt(6/d)) and W2_e (2d x d, scaled by sqrt(3/(2d))). A router
sends each token to ONE expert: expert(t) = argmax_e (x_t R)_e + BIAS_e, with R (d x 8, scaled by sqrt(3/d)) and a fixed bias that makes the load UNEVEN (a few experts get most tokens, as untrained routers do).
X, R, then for e = 0..7 W1_e and W2_e are the SplitMix64 stream under `seed` (tensorops.stream, the same floats as domains/aiinfer), row-major, in that order. The answer is the layer's output for every token in
token order (T x d, row-major) as a flat list of T*d INTEGERS in units of 2^-30; the judge recomputes it in float64 and accepts an answer within 3e-9 in every entry (ties in the router go to the lowest expert).
A token sent to the wrong expert, an expert applied to the wrong tokens, or a DROPPED token (its output left at zero) fails the check.

Why expert parallelism. Each device has a CAPACITY (device_cap below, in bytes): it cannot hold all eight experts' weights plus a working set, so replicating the experts on every device (the data-parallel
way) runs out of memory. One device can still do the whole layer by regenerating each expert just in time; eight devices can each hold one expert and have the TOKENS travel to it: an all-to-all to dispatch the
tokens, the expert's compute, an all-to-all to bring the results back. The price is communication, and LOAD IMBALANCE: the busiest expert's device sets the pace and the busiest device's traffic sets the bytes.
A common shortcut, dropping the tokens an overloaded expert has no room for (a capacity factor), keeps the load even and breaks the answer; the judge rejects it.

The cost compared is the one of tflops_dist.py (tensorops_dist.py defines the machine): critical-path work, message rounds and bytes per device, the peak bytes on the busiest device, from which the time on ANY
interconnect is exact. An accounting convention over identical devices and links (a barrier at every collective, no overlap), not a measurement of any cluster.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aimoed"
VERSION = "aimoed-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 48)
SIZE_STEP = 16
REFERENCE_SOLVER = "reference.py"
RANKS = 8
EXPERTS = 8
BIAS = (0.0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9, 1.05)
CAP_PER_D2 = 310              # a device may hold CAP_PER_D2 * d^2 bytes (calibrated between the working set of one expert and that of all eight; see test_aimoed.py)
SCALE = 2 ** 30
LIMIT = 2 ** 62
TOL = 3e-9
DOC = ("solve(seed, d, T, P): X (T x d, T = 8d), R (d x 8, times sqrt(3/d)) and for e = 0..7 W1_e (d x 2d, times sqrt(6/d)), W2_e (2d x d, times sqrt(3/(2d))) are the SplitMix64 stream under `seed` "
       "(tensorops.stream, u in [-1, 1), row-major, in that order). Token t goes to expert argmax_e ((x_t R)_e + BIAS_e) with BIAS = (0, .15, .3, .45, .6, .75, .9, 1.05) (lowest index on ties); its output is "
       "relu(x_t W1_e) W2_e. P = 8 devices, each able to hold device_cap(d) bytes. Return all T outputs in token order (T x d, row-major) as a flat list of T*d integers in units of 2^-30, each within 3e-9. "
       "Return None for no answer.")
REFERENCE_NOTE = ("One device does the whole layer, regenerating each expert just in time and running the tokens routed to it (the working set fits the capacity; nothing is parallel). Known to be beaten, on a machine whose "
                  "network is fast enough, by expert parallelism: one expert per device, tokens dispatched and combined by all-to-all.")


def device_cap(size):
    return int(CAP_PER_D2 * size * size)


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def route(seed, d):
    T = 8 * d
    X = _uniform(seed, 0, T * d).reshape(T, d)
    R = _uniform(seed, T * d, d * EXPERTS).reshape(d, EXPERTS) * math.sqrt(3.0 / d)
    return X, np.argmax(X @ R + np.array(BIAS), axis=1)


def layer(seed, d):
    X, ids = route(seed, d)
    T = len(X)
    out = np.zeros((T, d))
    o = T * d + d * EXPERTS
    for e in range(EXPERTS):
        W1 = _uniform(seed, o, d * 2 * d).reshape(d, 2 * d) * math.sqrt(6.0 / d)
        W2 = _uniform(seed, o + d * 2 * d, 2 * d * d).reshape(2 * d, d) * math.sqrt(3.0 / (2 * d))
        o += 4 * d * d
        sel = ids == e
        out[sel] = np.maximum(X[sel] @ W1, 0.0) @ W2
    return out


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aimoed-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, 8 * size, RANKS], "planted": [int(v) for v in np.rint(layer(seed, size).ravel() * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, d, T, P = inst["args"]
    if not isinstance(ans, list) or len(ans) != T * d:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    return bool(np.max(np.abs(np.array(ans, dtype=np.float64) / SCALE - layer(seed, d).ravel())) <= TOL)
