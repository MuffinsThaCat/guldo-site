"""dlog, full baby-step/giant-step: about sqrt(p) work instead of p (a true speedup of roughly half the exponent size in bits)."""
import math


def solve(p, g, h):
    m = math.isqrt(p - 1) + 1
    table = {}
    cur = 1
    for j in range(m):
        table.setdefault(cur, j)
        cur = cur * g % p
    step = pow(pow(g, m, p), -1, p)
    cur = h % p
    for i in range(m + 1):
        j = table.get(cur)
        if j is not None and i * m + j < p - 1:
            return i * m + j
        cur = cur * step % p
    return None
