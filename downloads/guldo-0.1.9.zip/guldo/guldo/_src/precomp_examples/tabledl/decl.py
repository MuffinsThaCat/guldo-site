"""Worked PRECOMPUTATION example: discrete log mod a small safe prime (see precomp_core.py). public = (p, g); an instance is h = g^x. Reference: exhaustive search (about p/2 steps per
instance, no precomputation). A baby-step table of sqrt(p) entries makes every instance cost about sqrt(p) giant steps; the table is paid for once."""
import hashlib
import hmac

NAME = "tabledl"
VERSION = "tabledl-v1"
KIND = "precomp"
SIZE_RANGE = (16, 22)
SIZE_STEP = 2
REFERENCE_SOLVER = "reference.py"
HORIZON = 12
STATE_MAX_BYTES = 8 << 20
DOC = "preprocess((p, g)) -> state;  solve(state, h): return x with g^x = h mod p."
REFERENCE_NOTE = "Exhaustive search over exponents, no table. A baby-step giant-step table beats it once several instances share (p, g)."


def _prime(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True


def public(master, size):
    p = (1 << size) + 1
    while not (_prime(p) and _prime((p - 1) // 2)):
        p += 2 if p % 2 else 1
    q = (p - 1) // 2
    g = 2
    while pow(g, 2, p) == 1 or pow(g, q, p) == 1:
        g += 1
    return [p, g]


def derive(master, size, idx):
    p, g = public(master, size)
    d = hmac.new(master, f"tabledl-v1:{size}:{idx}".encode(), hashlib.sha256).digest()
    x = int.from_bytes(d[:8], "big") % (p - 1)
    return {"args": [pow(g, x, p)], "planted": x, "public": [p, g]}


def verify(inst, ans):
    p, g = inst["public"]
    return isinstance(ans, int) and not isinstance(ans, bool) and 0 <= ans < p - 1 and pow(g, ans, p) == inst["args"][0]
