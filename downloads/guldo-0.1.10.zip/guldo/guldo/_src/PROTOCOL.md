# Adversarial speedup verification: lattice SVP track

Goal: credit a claim of the form "my algorithm is X bits faster than the baseline" without trusting the claimant.
A solution is NP-checkable; a speedup is not. This protocol converts the second into the first plus a conservative
statistical bound.

## Interface
A submission is one Python file exposing `solve(basis: list[list[int]], bound2: int) -> list[int] | None`.
It must return a nonzero lattice vector with squared norm <= `bound2` (1.05 x Gaussian heuristic, squared). It receives
nothing else: no seed, no instance index, no network, no files.

## Instances (instances.py, instances_mlwe.py, families.py)
Three families (two lattice, one integer factoring: `factor`, semiprimes of a given bit size, accepting any nontrivial divisor),
each a pure function of (master_seed, dim, idx) via HMAC-SHA256, each with a judge-side planted witness so every instance is
provably solvable (the solver never sees it). The two lattice families:
- `gm`: Goldstein-Mayer SVP-challenge lattices (accept any vector <= 1.05 x Gaussian heuristic). A typical-length vector is
  planted. Without planting, some small-dimension instances had NO vector within the bound (two seen at dims 40 and 45,
  confirmed by exhaustive enumeration; 2 of ~160 small-dimension baseline runs recorded).
- `mlwe`: Kannan-embedding lattice of a module-LWE-shaped instance (Z_3329[x]/(x^4+1), rank k, dim 8k+1, Gaussian error
  sigma=8; ladder 97,105,...,137). The judge accepts any short lattice vector, checked by modular arithmetic, not only the
  planted secret. Ring dimension 4 (not 8) so the ladder steps by 8: with step 16 only one dimension fell between the
  0.5 s floor and the timeout ceiling and the family could never produce a credit. Calibration (baseline BKZ, 3 instances,
  60 s cap): 97: 0.3 s, 105: 0.5 s, 113: 0.7 s, 121: ~1.5 s (1 of 3 timed out), 129: 2-5 s (1 of 3), 137: 24 s (2 of 3).
  Measured with BOTH solvers (practice seed, 6 instances/dim, tuned_bkz vs baseline_bkz, medians in seconds):
  105: 0.52 / 0.55, 113: 0.58 / 0.74, 121: 1.77 / 2.04 (baseline 1 of 6 timed out), 129: 32.4 / 2.00 (baseline 3 of 6
  timed out). All four clear the 0.5 s floor, but 105 does so by a hair and 129 sits exactly at the 50% baseline-timeout
  drop threshold, so with other seeds or n the usable set can shrink to two or three dimensions. Per-dimension speedup
  of tuned over baseline: -0.25, -0.38, +0.45, +2.69 bits; Tier-1 credit 0 (pooled over 113/121/129: median 0.4, lower
  bound -0.1). So the ladder can produce a measurement, but this solver pair has no certifiable speedup on it. (An
  earlier version of this note, on the old N=8 ladder with 12 instances, found only dim 113 usable.)
1. Judge draws a 256-bit master seed and publishes sha256(seed) **before** the submission deadline (`judge.py new-seed`).
2. Submissions are frozen at the deadline.
3. Judge reveals the seed; anyone can check the commitment (`judge.py check`) and regenerate every instance.
Consequence: a submission cannot contain answers for, or be tuned to, the judged instances. The public practice seed is
for development only; `solvers/cheat_lookup.py` demonstrates the attack this blocks.

## Cost
CPU seconds (user+sys) of the solver process TREE, minus the cost of a no-op solver, strictly sequential.
In the Docker sandbox (the only mode `judge.py evaluate` accepts by default) `sandbox/meter.py` runs as root, drops the
solver to uid 10001, and after the solver exits waits for and reaps every descendant (orphans, double-forked daemons)
so their CPU is billed; stragglers are killed at the wall deadline and the instance counts as a timeout.
Failures (timeout, crash, no answer, invalid answer) are censored at the budget, so they count against the solver.
Bare local mode exists only for your own solvers (`--insecure-local`): a solver there can read the seed and the judge's
code and can orphan processes to hide CPU. Both exploits were reproduced against the bare harness
(solvers/planted_peek.py, solvers/orphan_cpu_hider.py).
STATUS OF THE SANDBOX (be precise): the first meter was verified against a hostile probe (non-root uid, no forging the
meter's output, no setuid, read-only filesystem, no network, pid cap). The CURRENT meter (descendant reaping, subreaper,
kill-all-at-deadline) and its tests in test_sandbox.py have NOT been run against a real Docker daemon: Docker became
unavailable during testing. Treat orphan-CPU billing and the hang protection as unverified until
`python3 -m unittest test_sandbox` passes. The harness's Docker control flow (flags, parsing, timeout cleanup) is
tested against a fake `docker` (test_docker_shim.py), which says nothing about the sandbox itself.
A results file records `instance_version`, `budget`, `sandbox` and the image ID; `extrapolate.py` refuses to compare
ladders that differ in any of them. Seeds must live outside the project tree (`judge.py new-seed` enforces it).

## Claim (extrapolate.py)
s(n) = median over instances of log2(baseline cost / submission cost) on the same instance, per dimension n on the
ladder (`families.DEFAULT_DIMS`, tuned to the default baseline; `--dims` overrides it for another baseline; cap per
`families.OFFICIAL`). A dimension is used only if both solvers' median
cost is at least 0.5 s (fixed-cost guard: setup costs fade with n and would fake a speedup that grows with n; the
floor is absolute so genuinely fast solvers are not penalized). Consequence: a speedup can only be certified in a
regime where the faster solver still costs >= 0.5 s, so the ladder must reach dimensions that are expensive enough.
Censoring only ever hurts the claimant: a baseline timeout understates its cost and a submission timeout overstates
the submission's, and both shrink s(n). A ladder where the baseline mostly times out is a bad ladder, not a big
speedup; pick dimensions the baseline can finish.
Two tiers, reported separately:

**Tier 1, MEASURED (this is the credit): difficulty-stratified.** Group instances (all dimensions together) into octaves
of the BASELINE's cost, starting at 0.5 s: [0.5,1), [1,2), [2,4), ... A bin is usable when it holds >= 5 instances and
the submission's median cost in it is >= 0.5 s (fixed-cost guard). Take the 3 hardest usable bins, pool their paired
per-instance log2(baseline cost / submission cost), and report the one-sided 95% JOINT-bootstrap lower bound of the pooled
median: every resample redraws instances from the whole eligible pool and RE-SELECTS the usable and hardest bins, so the
uncertainty of that selection is inside the bound (a resample with fewer than 2 usable bins counts as 0 bits). An earlier
version resampled within fixed bins; by simulation its bound exceeded the truth 5-9% of the time instead of <= 5%, and on
real seed-A data it overstated the credit (1.3 bits vs 0.1 corrected). Instances the baseline timed out on are excluded (unknown cost:
conservative); submission failures stay in at the budget cost. No model, no extrapolation: "on instances the baseline
found hard, this solver is at least X bits faster". Needs >= 2 usable bins, else inconclusive. Leaderboard credit is
the MIN over >= 3 independent committed seeds; an inconclusive seed counts as 0.
Why not by dimension: on real data the baseline's cost is heavy-tailed and non-monotone in dimension (median 1.2 s at
dim 66, 60 s at 68, 4.6 s at 70, 60 s at 72 on one seed), so choosing "the largest dimensions" was erratic and dropped
the dimensions where the effect was large. Selecting by the baseline's own cost depends only on the reference solver,
so it cannot favour the submission. The rule (top-3 hardest bins, bin size, floor) was fixed BEFORE computing any
credit with it, but the author had looked at the seed-A bin medians while designing it; independent data was checked
afterwards (see Real-data checks). The old dimension-pooled claim is still printed as an informational line.

**Tier 2, EXTRAPOLATED (information, never credit).** Four growth models (constant, linear, power-law, log-decay) are
fit to the per-dimension medians, each tested out-of-sample (fit without the largest dimension, predict it, reject if
off by > 1 bit); the extrapolated bits at the target dimension are min(min over surviving models, bootstrap 5th
percentile, 2 x the largest measured speedup). No surviving model => inconclusive. It is model-dependent and
statistically weak at realistic noise (see Statistical power), which is why it is not the credit.

**What makes a leaderboard credit official** (`judge.py leaderboard`): >= 3 distinct seeds, each run in the Docker
sandbox, with the family's official instances per dimension and CPU cap (`families.OFFICIAL`: gm 24 instances / 120 s,
mlwe 12 / 60 s), an instance version, and a seed verified against a
commitment published beforehand (`judge.py evaluate --published-commit HEX`). Credit = MIN over those seeds, an
inconclusive seed counts as 0. Anything else is shown as PROVISIONAL with the reasons; board entries record n, budget,
commitment, sandbox, instance version and image ID. `judge.py rescore` rebuilds entries from saved ladder files after
a rule change.

Both tiers use paired speedups (same instance, both solvers). A dimension is dropped when more than half of the
BASELINE's instances time out (its cost there is unmeasured) or when either solver costs under 0.5 s. A dimension is
NOT dropped because the submission failed there: failures count at the budget cost and pull the pooled speedup down.
(An earlier rule dropped dimensions on submission timeouts too; a solver that failed every instance at dims >= 66
then earned the same credit as one that solved them all. Fixed, with regression tests.) `solvers/fixed_overhead_ref.py` (reference with 1 CPU-second of fixed setup cost) shows a
fading advantage earning < 1 bit at the top dimensions (test_extrapolate.py).

## What this does NOT guarantee
- The credit is a measured lower bound at the dimensions the ladder reaches (about 60-72 for GM). It says nothing
  certain about NIST-scale dimensions; the extrapolated tier is a model, not a proof.
- CPU seconds depend on hardware; judges must run baseline and submission on the same pinned machine.
- The Docker sandbox is a container, not a VM, and its current meter is unverified (see Cost). Run it on a dedicated
  judge machine with a pinned core.
- "dimension" means different things in the two families (GM dimension vs 16k+1), so compare within a family only.
- A speedup is certifiable only where the faster solver still costs >= 0.5 s (fixed-cost floor) and the baseline mostly
  finishes within the cap; a speedup of a few tenths of a bit is below what 1.5-2.8 bits of per-instance noise allows.

## Accelerator (GPU) workloads: a weaker, device-pinned tier (gpu_meter.py)
Every cost in the CPU path is CPU time of a process tree the meter can bill (`getrusage` / the root meter), or, for counted certificates, a Python bytecode count.
Neither sees a GPU: kernels run asynchronously on a device whose time is not in the process's CPU time, the Docker sandbox image has no device passthrough, and no
deterministic instruction counter exists for GPU kernels. So a GPU claim cannot be proved, only MEASURED by a trusted operator, and `gpu_meter.py` does that and nothing
more: the wall-clock time to the answer on a PINNED device model + driver, with ladders that `extrapolate.py` refuses to compare across devices. The PARENT does the timing:
it writes a request line to a child that has loaded the solver and been warmed up on public instances, reads the reply line, and takes the elapsed time on its own clock, so
the child supplies no timing and cannot under-report; each timed run is a different instance, so nothing can be cached across repetitions; one-time setup (imports, loading
a model) is untimed and per-instance work must happen in the solve call. A measurement is rejected, not kept, if another process shares the measured GPU (checked before and
after the run) or the GPU reports a hardware or thermal slowdown while it runs. The ladder can be fixed in advance (`plan`: family, sizes, instances per size, budget, seed
commitment, device, with a hash to publish first) and a ladder verifies against the plan only if it is exactly the planned one.
Limits, stated in every verdict: it is an operator's clock on an operator's box (nothing proves which device ran it, that clocks were not locked or raised, or that the box
was not tuned for one solver), nobody can re-execute a time exactly (`verify --rerun` re-measures single runs on the same device model and agrees within a factor of 1.3), the
solver runs unsandboxed, and a result says nothing about any other device. The parent-side rules are tested against a fake nvidia-smi and a fake transport with a fake clock,
and the process transport against tiny real children; the child (`gpu_runner.py`) and the torch solvers were written without a GPU and have never run. The CPU domains
(`aiinfer`, `aidecode`) remain the evidence that carries full weight.

## GPU trust model: what "independently verifiable" can and cannot mean
A reviewer's fair objection is that GPU measurements rest on a trusted operator, so AI-side results are better than self-reported but not at the trust level of the crypto domains. "GPU execution"
bundles three different claims, and only one is the gap:
1. **That the GPU produced the right answers.** Already independently verifiable: the judge checks every answer against the hidden test, and anyone can re-check on any hardware. Not the gap.
2. **How much work a technique asks for** (operations, bytes moved, peak memory). Verifiable with no hardware trust at all: the counted tiers (`tflops.py`, `tflops_mem.py`) are exact and anyone re-executes them. This is
   the tier at which two AI techniques can be compared at the same trust level as the crypto domains, with the stated limit that it is an accounting convention and not a time.
3. **How long it took on a device.** This is the gap, and no software can make a time exact: it depends on the device, driver, clocks, temperature and neighbours. It can only be narrowed, in tiers.

| Tier | What backs the time | Status |
|---|---|---|
| R | NO time at all: an exact comparison of two runs' per-operation flops and bytes over every device balance (faster everywhere, tied, or a stated crossover), plus a calibration anyone can run and compare on their own device (`roofline.py`, `gpu_roofline.py`) | built and tested; calibrated on one real GPU (Apple M4 Pro via MPS) and checked for reproducibility; model error about a third, results below |
| T1 | one operator's clock on one pinned device model, device and thermal checks (`gpu_meter.py`) | designed and tested against a fake device; the child and torch solvers have NEVER run on a GPU |
| T2 | the same ladder independently re-measured on the same named device model by two or more parties the verifier chose, each signing the outcome | NOT built for GPU: `attest.py` signs certificates, GPU ladders are not wrapped in them; needs a GPU to test |
| T3 | hardware-counted work: instruction and memory-traffic counters (Nsight Compute / CUPTI) for a deterministic kernel, identical on the same architecture and driver | NOT built; NVIDIA only; a count of real GPU work including cache and memory behaviour, not a time |
| T4 | the measurement harness run inside an attested confidential-computing GPU environment, proving which device, firmware and software produced it | NOT built; needs the newest datacentre GPUs; proves provenance, still not an exact time |

What to claim today: counted costs (tier 2 above) are fully verifiable; any GPU time is T1 at best, and must be described as one operator's measurement on one device model. The target that a skeptical reviewer
will accept (the standard MLPerf-style benchmarks use) is T2 on a named cloud instance type with the image hash published, so that anyone can rent the same instance and reproduce within the stated tolerance (a factor of 1.3
for a single run today); T3 adds real-hardware work counts; T4 adds provenance. None of T2 to T4 can be built or tested on a machine without an NVIDIA GPU, which is why they are listed as not built.
The roofline tier (R) needs no NVIDIA machine and changes what has to be trusted. A kernel cannot finish faster than max(flops / peak compute, bytes / bandwidth); dividing by the bandwidth turns a device into one number, its
balance beta (peak flop/s over byte/s). A run is a SEQUENCE of operations, so on a device its time is the SUM of each operation's roofline time, T(beta) = sum of max(f / beta, b) over its operations. `tflops_mem.py` records every
run's exact operation profile ([flops, bytes, count] groups that add up exactly to the recorded totals, which verification checks), and `roofline.py` compares two profiles for EVERY beta in exact rational arithmetic: one run is at
least as fast on every device (dominance), they tie exactly (identical profiles), or the faster side changes at stated crossover balances. `tflops_compare.py` prints this for every byte-counted comparison, over every paired instance
(one reversed instance refuses dominance). A CORRECTION to an earlier version of this section: it compared only total flops and total bytes, and called equal totals 'no device can tell them apart'. Totals give max(sum f / beta, sum b),
which is only a LOWER BOUND on T(beta) (perfect overlap of the operations); two runs with identical totals differ by up to 2x in T(beta) (a compute-only operation plus a memory-only one against two balanced ones; a test builds
exactly that), so the totals-based functions remain only as a labelled lower-bound reading and the verdict uses the profiles.
On the real comparisons (practice seed; every record re-executed): fp16 training against fp64 is faster on every device whose balance exceeds about 0.055 flop/byte (the crossover is 0.053 to 0.056 depending on the instance; below
it the fp64 run's fewer flops win); the fp32 KV cache against the fp64 one crosses at about 0.25 flop/byte; the solver that frees what it no longer needs and the one that does not have identical profiles, an exact tie in speed with
only peak memory different. The earlier figures of 0.51 and 0.26 came from the totals and are superseded. The device measured below has a balance of about 30 flop/byte and datasheet balances for datacentre GPUs are higher still
(confirm the figure for any device from its own datasheet), so crossovers of a tenth of a flop per byte or less hold on all of them.
What is left to trust is whether the roofline FORM describes real hardware, and that is measured, not assumed: `gpu_roofline.py calibrate` times simple kernels on a device, fits its launch overhead, bandwidth and per-precision
compute rate from them ALONE, and then tests the constants on kernels never used to fit them, including a full training step of the technique being compared. On a real GPU (Apple M4 Pro, PyTorch MPS; about 217 to 221 GB/s,
6.7 TFLOP/s fp32, 7.3 to 7.4 TFLOP/s fp16) the held-out kernels were predicted with a median error of 30% (matrix-vector products 5 to 6%, an MLP block 21 to 22%, the training step 30%, an unfused softmax chain 58%: the counted
bytes assume no cache and no fusion, and this chip's large cache absorbs most of that chain's intermediate traffic). The ratio the project actually claims, fp32 time over fp16 time on the same shape, was on the right side of 1 on
13 of 13 held-out shapes in both runs, but its magnitude is only predicted to a median 34 to 41% (worst 84 to 87%): an earlier version of this section quoted a 14% median that mixed in the kernels the constants were fitted on, and
is withdrawn. Absolute times are overestimated by roughly a third; the direction of a comparison is reliable, its size is not. The calibration reproduces: two runs of the same GPU agree on every fitted constant to within 1.7%
(`gpu_roofline.py agree`), so an independent party with the same device model can check an operator's calibration with one small script. The roofline form fits a very different device worse: the same Mac's CPU, run the same
way, was off by 107% on matrix-vector products, so the model is a statement about accelerators with the memory behaviour it was checked on, not about every machine. Everything in `results/gpu_roofline_*.json` is recomputable with
`gpu_roofline.py check`. The thing a reviewer has to trust shrinks from 'this operator timed this submission honestly' to 'this device behaves roughly like its roofline', which they can test themselves; it is still one device, one
operator's timings, a model with errors of about a third, and no measurement of any submission. A claim made this way reads 'at least as fast as, under the sequential roofline model, on devices with balance above X',
never 'faster'.

## Training, and comparing two AI techniques with each other (counted operations)
What can be proved about an AI technique, on any machine, is how much ARITHMETIC it asks for, so the counted-operations mode (`tflops.py`, exact and re-executable) is the
tier to compare techniques on; the GPU tier above stays the weaker, device-pinned one. Two additions use it.
`aitrain` is a training domain. A small softmax classifier is trained on a seeded, ill-conditioned training set until it reaches 85% on a HIDDEN test set. The teacher and the
test set are derived from the round's master seed and are not in the solver's arguments, so nothing can be trained on them and the answer cannot be computed without
learning it; the answer is the weight matrix as integers, and the cost is the operations spent. The reference is plain gradient descent (12000 steps, the slowest of 90
calibration instances needed 8580); feature scaling, momentum and adaptive steps are what the domain exists to compare. A solver that stops too early fails the check and is
charged the whole budget. The declaration passes the compiler's validation (determinism, junk rejected, no trivial answer, no witness reuse, the reference solves it); it has
NOT been compiled into a timed round, and its saved runs are practice runs on the public practice seed, not official results.
`tflops_compare.py` compares two SUBMISSIONS with each other, which a certificate (one solver against a baseline) cannot. Because a count is exact, the comparison is paired:
the same instances, instance by instance, the gap in bits at every size, a per-size table, `--plan` to demand that every ladder is exactly a plan committed in advance, and `--rerun all` to re-execute every
record of all three ladders. It refuses unless the ladders are the same test (family, declaration, seed commitment, budget, interpreter, counting program, unit, instances,
two different submissions and a baseline). `check` recomputes a saved comparison; the order of A and B matters. Statistics are only used where they mean something: a size at
which both solvers cost exactly the same on every instance (a fixed number of steps) is one exact fact and carries no p-value, because identical instances are not
independent trials (an earlier version reported p = 1e-7 for exactly such a case, which overstated the evidence); the exact sign test and the deterministic bootstrap
interval use only the sizes where costs vary, and a side is called cheaper there only when the sign test AND the interval of the mean gap agree (an earlier rule used the sign test
alone and called a solver cheaper that won 20 of 24 instances by 1% and lost 4 by 16 times, whose mean gap and whole interval favoured the other side). The first real case that does vary, adaptive early stopping against a fixed 40 steps, is not separated (median +0.11 bits,
interval spanning zero, p = 0.84), and the tool says so. Ladders on the public practice seed are flagged: anyone can compute their hidden teacher and test set. A size counts as fixed-cost only when at least 3 paired instances cost
exactly the same (two equal costs can be a coincidence of an adaptive solver). `--rerun all` is the only full audit and the only setting for which the output says every record
was re-executed; a number K re-executes a random sample and the output says it was only a sample; `--solvers DIR` names where the three solver files are (each must match the hash
in its ladder, and a name that is not a plain file name is refused). The bootstrap uses a SHA-256 generator, not Python's `random`, so a saved comparison recomputes identically
on any interpreter.
What this does not show: a time, memory traffic, kernel quality or GPU speed; large-model behaviour (the task is small on purpose, so the method carries over, not the
numbers); a gap at sizes that were not measured; or anything about solvers that were not submitted. A solver whose cost depends only on the size gives one cost per size, so
its evidence is per size and not per instance. Wall-clock GPU speed cannot be made exact by any counting, which is why it stays the trusted-operator tier.
Bytes, precision and peak memory (`tflops_mem.py`, `tensorops_mem.py`). Operation counts are blind to the three things that decide most real speedups, so a second counter adds them as
exact, recomputable accounting, in a new counting program (a run-time layer over the unchanged `tensorops.py`, in its own ladder format `tflopsmem_*`, so no existing ladder or
pre-registration is touched). Every tensor has a width, 64 bits by default; `tp.cast(x, "fp32" | "fp16")` rounds its values to that format and labels it, and the result of an operation
is as wide as its widest operand and is rounded to that width, so a technique that loses accuracy by lowering precision loses it here and the judge's hidden test set sees it. Every
operation is charged the bytes it reads and writes, with no cache and no fusion; the peak is the most bytes of tensors alive at once, deterministic because CPython frees a tensor when
its last name goes. For a program that casts nothing the layer leaves the operation count exactly as it was: checked on the aitrain solvers and on all three transformer-decoding solvers
(steps, flops and statuses identical with and without the layer). `tflops_compare.py --metric ops|bytes|peak` compares two solvers on any of the three, with the same exactness,
re-execution and plan checks. Results on the public practice seed (so not certified): for aitrain at sizes 32-48 every variant solved 24/24; fp32 moved 46% fewer bytes than fp64, fp16
69% fewer (1.68 bits, 3.2x), at a cost of 0.003 bits more operations for the casts; a variant that frees what it no longer needs had the identical operation and byte counts and a 42%
smaller peak. For transformer decoding with a KV cache the operation saving against the uncached reference is 4.9 bits but the bytes saving only 1.05 bits, and the fp32 cache moves
1.83x fewer bytes than the fp64 cache with a 1.59x smaller peak: the operation count alone would have called the first the whole story. Everything above was re-executed in full
(`--rerun all`) and the saved comparison files recompute. What it still is not: a time, a kernel or cache model, or a hardware counter; it certifies "fewer bytes / a smaller footprint
under these rules", never "faster". A failed run has no bytes or peak to charge, so these costs compare only the instances both solvers solved and carry no credit bound.
An exact credit for operations: against the baseline each solver gets a distribution-free 95% lower bound on the median gap (the k-th smallest of the per-instance gaps, k from the
binomial), with a failure charged the whole budget so it can only lower the bound. For adaptive early stopping the noisy-clock estimator gave 0.0 bits (its bound cannot clear zero
with 8 instances and a 100-fold cost spread, which is correct for timings and needlessly cautious for exact counts); the exact bound is at least 6.59 bits (median 8.30).
Carry-over beyond the declared sizes, run the full committed way (private seed, plan hash fixed first, ladders required to match the plan, every record re-executed): at sizes 64-128
the reference still solved every instance and standardization beat momentum by 5.188 bits, against 5.187 at sizes 32-48, with exact credit bounds of at least 8.186 and 2.998 bits.
The first use of `claims compare` on real certificates (two freshly built, verifying timed aiinfer certificates, different seeds, both inconclusive on this machine at 2 questions per
size) refused nothing and said "neither is shown to be ahead", which is the right verdict.
A caution found by auditing the byte counter: bytes and peak memory are counted only for tensor operations, so arithmetic done in a solver's own Python moves no counted bytes (it pays
in operations instead). A solver could therefore look cheaper on bytes by moving work out of the tensors. `tflops_compare.py --metric bytes|peak` always prints the operations gap beside
the verdict and, when the side that wins on bytes or peak spends at least twice the operations, appends that to the verdict itself; a fabricated pair that moves 1000x fewer counted bytes
for 4x the operations is reported as such, while the honest fp32 and fp16 variants (operations within 0.01 bits) are not flagged. The exact credit is a bound on the median of the instances
pooled over the measured sizes, not on any one size, and instances where the baseline itself failed are left out (the output counts them).
`aimlp` is a second training domain with a NON-CONVEX loss: a two-layer, 32-unit ReLU network trained on moderately ill-conditioned features (scales 1 down to 1/10) against a hidden
8-unit teacher, with the same hidden test set and integer answer format as aitrain, so what the comparison shows does not rest on convexity. Auditing it found two flaws in its first versions, both
now fixed and pinned by tests. (1) A random ReLU teacher often put 80-100% of the inputs in one class, so on 8-14% of instances a constant answer passed (and an 8-step 'cheat' passed 1 in 16);
teachers are now drawn again until no class takes more than half of the test inputs. (2) With a target of 0.80 a purely LINEAR model (least squares, no hidden layer) passed a third of
instances, so the task did not need the network; measured on 60 instances a linear model never exceeded 0.854 while the network reached at least 0.893, so the target is now 0.87 and a teacher is
also drawn again if a linear least-squares fit on the instance's own training set already reaches 0.84 on its test inputs. A test writes that linear model out as a valid network answer (ReLU
pairs) and shows the judge rejects it on every instance. Raising the target exposed a third problem: with the first conditioning (1/30) plain gradient descent on the raw features could not reach
0.87 on 8 of 36 instances even after 30000 steps, so it was no valid reference; with ratio 10 the reference reaches the target on 48 of 48 (the slowest needs 5800 steps, hence 12000), standardised
descent on 180 of 180 (slowest 320, used with 500), and Adam on 177 of 180: on 3 instances Adam at learning rate 0.03 never reached 0.87 in 3000 steps, a genuinely non-convex failure that a fixed-step
solver shows as a failed instance. It passes the compiler's validation. On the public practice seed at sizes 8, 12, 16 (re-executed in full, exact bounds): Adam at least 4.903 bits below the
reference, feature scaling at least 4.585, momentum at least 0.414; Adam beat momentum by 4.5 bits. Adam's 0.3-bit edge over scaling is the difference between the safety margins their solvers were
given (400 against 500 steps), not a ranking of the techniques: a fixed-step solver's cost includes its margin, and adaptive stopping removes it. Like aitrain it is not compiled for the timed protocol.
A check of `aitrain` found that closed-form least squares passes every instance (0.89-0.90 against a target of 0.85): the data admit a one-shot solution. It cannot be written with the counted
tensor operations directly (there is no solve), but conjugate gradient on the standardised normal equations can, and 3 iterations already pass 40 of 40 instances at every size (the standardised
problem is well conditioned). The counted solver `aitrain_flops_cg.py` (6 iterations, matrix-free) solves all 24 practice instances at least 10.64 bits below the reference, 2.46 bits below the best
gradient method shown before: the domain's best technique is a solver, not an optimiser, and the exact bound says so where the clock-noise estimator would have given 0 (its cost is below the floor).
Using it from the installed package: the commands are `guldo tflops ...` and `guldo tflops-compare ...`. The reference and example solvers are in the package's solvers folder
(`python3 -c "import guldo, os; print(os.path.join(os.path.dirname(guldo.__file__), '_src', 'solvers'))"` prints it), where `aitrain_flops_ref.py` is the baseline. The `next:`
hints that `tflops practice` prints read `python3 tflops.py claim ...` in the source; the installed `guldo` command rewrites every `python3 NAME.py ...` a tool prints into
`guldo TOOL ...` as it is printed, line by line so progress still streams. (`tflops.py` is pinned by hash in an earlier pre-registration, so the rewrite is done around it,
not in it.) This path was run end to end from a clean install: self-check, a practice experiment, a comparison with `--rerun all`, and
`check`, with the same numbers as in the checkout.

## Systems techniques: second-order optimisers, mixed precision, checkpointing, parallelism, distillation, pruning, a GPU (AI_SYSTEMS_SPEEDUPS.md)
Nine more counted domains (the last two, `aidist` and `aireal`, are described after the span and checkpointing notes below), each judged on an equivalent result and each with a solver the judge must reject: `aisecond` (operations; correlated-feature logistic loss, accepted iff its gap to the exact minimum is
at most 1e-8), `aimixed` (bytes; accepted iff the gap is at most 1e-6, a tolerance that pure fp16 misses by 70 to 3000 times and a mixed-precision recipe meets with margin), `aickpt` (peak memory; the exact gradient of
an unrolled network), `aipar` (span; a linear recurrence), `aidistill` and `aiprune` (operations; a labelled batch accepted iff within a logit margin of the model's best), `aigpu` (counts and wall time).
**Span** is a third exact count, `tflops_par.py` (`tensorops_par.py` explains the convention): the depth of the longest chain of dependent tensor operations, a conservative bound, with the solver's Python instructions
added one for one. With work F, depth D and Python steps S on P identical processors, `max(F/P, D, S) <= time <= F/P + D + S` (Brent), so "A is certainly faster than B on P processors" is an exact computation from
the counts (`tflops_compare.py --metric span` prints the processor counts), and a parallel algorithm that does more work is correctly reported as SLOWER at one processor. It models no communication, synchronisation,
load imbalance or contention. **Checkpointing** lowers the peak and raises both operations and bytes: it buys capacity, and the roofline says so exactly. **GPU time** (`gpu_bench.py`) is a device-generic,
parent-timed wall clock for any PyTorch device; it has run on an Apple GPU (MPS) and never on CUDA, it is one operator's measurement on one device model, and it is weaker than `gpu_meter.py`; it exists because a fused
kernel is exactly what the no-fusion byte convention cannot see.
**Cluster cost** (`tflops_dist.py`, `tensorops_dist.py`, domain `aidist`): tensors live on up to 8 simulated devices, an operation across devices is an error, data moves only through collectives (all-reduce,
reduce-scatter, all-gather, broadcast) or the host (charged like a message), and every collective is a barrier. A run's exact `wcrit` (the sum over phases of the busiest device's flops), message `rounds` and bytes
per device give its time on any machine of latency alpha and inverse bandwidth beta as `wcrit + steps + alpha * rounds + beta * bytes` exactly, so two solvers are compared on every interconnect at once: one either
dominates or the winner is a computed function of the machine. **Real data** (`aireal`): digits and trained networks, nothing planted, one agreement bar fixed in advance; the planted domains' pruning and distillation
gains do not transfer to it (`aireal_frontier.py`). Instances larger than about 16 KB deadlock `tflops._run_watched` when the child is slow to start (it never resumes a partial write): tools other than the pinned `tflops.py` use `runwatch.py`, which hands the
instance over as a file (verified at 8 MB). **Second build** (AI_SYSTEMS_SPEEDUPS.md): the cluster counter gained `tp.exchange` (pipeline hand-offs), `tp.all_to_all` (expert routing, imbalance charged) and per-device
memory with a capacity (`aipipe`, `aimoed`, `aizero`); `tflops_mem3.py` (a fork of the version-2 byte counter) adds bf16, fp8 and a sparse product `tp.spmm` whose cost follows the nonzeros; `aikfac` tests a
Kronecker-factored preconditioner (K-FAC and Shampoo); `airealm` repeats the real-data experiment at MNIST scale (six widths up to 1024) with queries that carry a secret-seed noise so that a lookup table fails, and `aireal`
is now version 3, with the same kind of noise (version 2 could be passed by a precomputed table at zero cost; the noise scale rises with the network width because wider networks are more noise-robust: a single scale
let a clean-image table pass 30% of the widest `airealm` network's instances). **Third build** (AI_SYSTEMS_SPEEDUPS.md): `tflops_dist3.py` is version 3 of the cluster counter, WITH A TOPOLOGY: devices in nodes, an intra-node and
an inter-node link, collectives over groups (a list of disjoint groups runs as one concurrent superstep), a run's time exact on every pair of links (`wcrit + steps + a_i ri + b_i ci/L + a_x rx + b_x cx/L`), a 36-machine grid
(the 12 intra-node machines times an inter-node link 1, 10 or 100 times slower) and dominance over five counts; on one node it counts exactly as version 2. It carries `aitopo` (2D parallel layouts on two nodes of
four) and `aipipetrain` (pipeline-parallel training under a per-device memory cap, with GPipe and 1F1B schedules and activation recomputation); `airealc` asks the real-data question of a convolutional network small
enough (under 1 MiB per instance) to be compiled for the timed protocol. **Fourth build** (AI_SYSTEMS_SPEEDUPS.md): `airealt` asks it of a small transformer language model on real text (an exact last-position shortcut survives; head, MLP-unit, sparsity and fp8 compression do not on a
network this small), and `validate_counts.py` sets the counted ratios beside measured times of independent torch implementations on the machine it runs on (saved reports for an Apple GPU and CPU: the byte ordering of lower
precision and the cost of recomputation agree on the GPU; a fused kernel is invisible to the counts; the sparse accounting is optimistic; the topology and pipeline counters are not validated).

## Statistical power of the earlier DIMENSION-POOLED estimator (superseded as the credit; kept as an informational line)
NOTE: everything in this section describes pooling by dimension. The credit is now the difficulty-stratified claim; its
real-data checks and real-noise power are in "Real-data checks" above.
(simulated; Gaussian per-instance noise sd 2.2 bits, the measured range is 1.5-2.8)
12 instances/dimension, dims 56..72 step 2, effect rising 0.2 -> 5.5 bits (the tuned-vs-baseline trend measured):
| claim | zero effect credited >= 1 bit | tuned-like effect credited >= 1 bit | constant 0.5-bit effect |
|---|---|---|---|
| Tier 1 measured | 0/150 (CI 0-2%) | 139/150 = 93% (CI 87-96%) | 0/150 |
| Tier 2 extrapolated | 0/120 | 2/120 = 2% (n=12), 50% only at 64/dim | n/a |
The Tier 2 claim was nearly unusable at realistic noise, which is why Tier 1 is the credit. These are simulations of
the estimator under an assumed noise model, not measurements of the real pipeline; real noise is heavier-tailed.

**Caveat: the Tier-1 power above does NOT transfer to the real ladder as configured.** The simulation assumed the top
three usable dimensions are uncensored and reach 72, where the tuned-like effect is ~4.7 bits. In real data the
baseline times out on most instances at the top dimensions (cap 60 s), those dimensions are dropped, and the usable
ones sit where the effect is small. Real-data check (GM v1, practice seed, tuned vs baseline, 12 instances/dim; HISTORICAL: these ladders predate the `instance_version` field and
the current estimator refuses them, so these numbers cannot be re-scored today and are kept for the reasoning, not as current results): usable
dims {60, 65}; pooled median 0.23 bits, one-sided lower bound -0.49, i.e. credit 0, although the same solver is 4.6 bits
faster at dim 70 (censored, dropped). Certifying a real speedup therefore needs a CPU budget large enough that the
baseline mostly finishes at the dimensions where the effect is large (budget vs dimension is the binding constraint),
or a baseline that scales more gently. Treat "93%" as the estimator's power given such data, not as the pipeline's
power. A second real-data run (GM, fresh seed, 12 instances/dim, 60 s cap, fixed rules) agrees: usable dims {64, 66, 70}
(68 and 72 dropped for 58% baseline timeouts), per-dimension speedups 0.7 / 0.17 / 1.31 bits, credit 0.0.
**Minimum detectable effect (simulated power curve).** A constant true effect at every dimension, per-instance noise
sd 2.2 bits (the measured range is 1.5-2.8), costs high enough that the 0.5 s floor does not bind, 120 trials per cell;
cell = probability that the Tier-1 credit is >= 1 bit:
| true effect | 1.0 bit | 1.5 bits | 2.0 bits | 2.5 bits | 3.0 bits |
|---|---|---|---|---|---|
| n = 12 per dimension | 10% | 35% | 75% | 93% | 100% |
| n = 24 per dimension | 9% | 58% | 91% | 100% | 100% |
A back-of-envelope formula (credit = median - 1.645 x 1.25 x sigma / sqrt(3n)) puts the break-even at about 1.8 bits
(n=12) and 1.5 bits (n=24); that is the ~50% point, NOT a power guarantee. For 80% power plan on about 2.1 bits at n=12
and about 1.8 bits at n=24 (hence gm official n=24). A real speedup of 0.5-1 bit is inconclusive by design, and the
honest tuned-vs-unpruned pair (about 0.2-1.3 bits at the dimensions where the baseline finishes) sits below that.
With floor and censoring effects the real thresholds are higher than these clean-case figures.
Two independent runs of the same baseline differ by only +0.03 bits median (worst dimension +0.08), so timing
drift is not the limiting factor; per-instance difficulty noise (1.5-2.8 bits) and censoring are.

## Parallel local runs (`harness.py --jobs K`, local mode only)
The official GM config is hours of CPU, so local runs can use K concurrent instances. CPU time is each child's own
`wait4` rusage, so concurrent runs do not corrupt each other's accounting. Concurrency does slow each process a little,
and that varies between runs (absolute time +0.01 to +0.10 bits at 4-10 jobs on this machine). What matters for the credit
is the SPEEDUP estimate, a ratio in which a uniform slowdown cancels: `drift_check.py` measured it shifting by only
-0.02 bits (sd 0.04) at 4, 6 and 8 jobs, baseline vs tuned, same instances, against a sequential noise floor of 0.01.
Both ladders of a comparison must use the same `--jobs` (`extrapolate.py` refuses otherwise); the sandbox path is
sequential only. Re-run `drift_check.py --solver ... --solver2 ...` on a new machine before using --jobs there.

## Real-data checks of the difficulty-stratified claim
(`extrapolate.py`; `power.py` for the noise/power numbers; baseline = baseline_bkz, submission = tuned_bkz unless stated)
| data | result |
|---|---|
| GM v2, fresh seed A, 12 inst/dim, dims 56-72, cap 60 s (in-sample: used to design the rule) | credit 0.1 bits (median 2.2) with the corrected joint bootstrap (1.3 with the withdrawn fixed-bin bootstrap); the credit pools the three hardest usable bins, 1-2 s (+0.54 bits, 5 instances), 2-4 s (+2.2, 8) and 16-32 s (+5.0, 7), each holding only 5-8 instances; the 0.5-1 s bin (+0.17, 15 instances) is usable but not among the three hardest, and 4-8 s (+1.9, 4 instances), 8-16 s and 32-64 s (1 each) are not usable; exploratory hard-pool claim >= 2.3 bits (n=13), also in-sample (its 4 s threshold was chosen after seeing this table) |
| GM v1, practice seed, independent older ladder (HISTORICAL: the files predate `instance_version`, so the current estimator refuses them and this row cannot be re-scored; kept as the record of what was found then) | credit 0.00 (median 0.6); effects +4 to +5.5 bits exist but sit in bins with 1-3 instances (< 5) |
| **GM v2, seed D, PRE-REGISTERED, 24 inst/dim, dims 64-72, cap 120 s, 6 jobs (OUT-OF-SAMPLE)** | **primary credit 2.6 bits (median 4.1)**: the credit pools the three hardest USABLE bins: 4-8 s (+2.56 bits, 11 instances), 16-32 s (+4.91, 13) and 32-64 s (+5.04, 5); the 2-4 s bin (+2.28, 10) is usable but not among the three hardest, and 64-128 s has 1 instance so it is not usable; criterion (a) >= 1.0 MET. Exploratory hard-pool claim 2.9 bits (30 instances, submission median cost 0.96 s): first out-of-sample support for promoting it. Cheapest bin (0.5-1 s) is -0.86 bits: the tuned solver's fixed cost makes it slower there, which is why the cost floor exists |
| seed D concurrency check (pre-registered, baseline only) | 25 baseline instances re-measured sequentially: median -0.050 bits, per-octave medians -0.041 to -0.074, none solved differently; criteria (median within +-0.10, no octave beyond +-0.20) MET |
| **factoring positive control, seed E, PRE-REGISTERED, sizes 58-64 bits, 24/size, cap 120 s, 6 jobs** | credit 4.1 bits (median 4.2) vs the calibrated ~4.4: credit criterion (a) met. **Concurrency criterion FAILED** (pre-registered, both ladders): baseline re-measured sequentially -0.033 bits (passes), numpy submission **-1.160 bits** (n=16, sd 0.08; limit 0.10). The sequential speedup is therefore probably ~5.2-5.6 bits (inference, not measured), and the match with 4.4 is partly a coincidence of two offsetting effects. Solver-dependent concurrency bias is a measurement hazard of `--jobs > 1` |
| seed D concurrency, tuned ladder (POST-HOC, not pre-registered) | all 113 tuned instances at >= 0.5 s re-measured: median -0.084 bits. The baseline is slowed by concurrency 0.050 bits and the tuned solver 0.084, so the speedup is UNDERestimated by about 0.034 bits: concurrency makes this credit slightly conservative |
| two independent runs of the SAME baseline (true effect 0) | inconclusive; every bin -0.03 to -0.05 bits (timing drift) |
| module-LWE v2, n=6 | inconclusive (1 usable bin) |
| fixed-overhead fallacy (reference = baseline + 1 s) | no credit: its +3.2-bit easy bin is below the floor |
| cheat on the PUBLIC seed (lookup table) | no credit: its cost is milliseconds, below the floor (commit-reveal is the real defence) |
Real per-instance noise inside difficulty bins is 0.5-1.5 bits (vs ~2.2 pooling by dimension). `power.py` with that real
noise on the seed-A ladder size (12/dim, 60 s cap), CORRECTED estimator, RE-RUN 2026-11-19 with the default settings (200 trials per
effect, seed 0; output saved as results/power_seedA_default.txt): false credit 0%, and P(credit >= 1) = 0.5% at a true effect of 1 bit,
1.0% at 1.5 and 0% from 2 to 4 bits (inconclusive 28% at 2.5, 58% at 3, 66% at 4). An earlier version of this paragraph quoted "0% at every
effect" and inconclusive 61% / 79% at 3 and 4 bits; the re-run does not reproduce those exactly (the 4-bit figure is outside sampling noise).
The conclusion stands: that ladder is too small to certify anything with the corrected bound. (The figures 12% / 46% / 41% / 31% / 6% / 27% quoted in earlier versions came from the withdrawn
fixed-bin bootstrap.) Larger true effects get HARDER to certify here because
the submission's cost falls under the 0.5 s floor in the bins where the baseline is cheap, leaving too few hard
instances. This is inherent to a cost floor (subtracting each solver's measured fixed cost instead was rejected: a solver
could inflate that measurement on trivial instances and make every real instance look free). More instances per
dimension and a larger cap fill the hard bins; the gm official config (24/dim, 120 s) exists for that reason and has been run once
(seed D, above).

**Power at the OFFICIAL configuration (measured; re-run 2026-11-19).** `power.py` on the seed-D pair (24/dim, 120 s cap, REAL per-instance
noise, 200 trials per effect, default settings; output saved as results/power_seedD_default.txt). P(credit >= 1 bit) for a CONSTANT true
speedup: 0% at 0 bits (no false credit), 6.5% at 1, 70.5% at 1.5, 98% at 2, 100% at 2.5, 73% at 3 and **1% at 4 bits**. Power FALLS for
large effects at n=24. Mechanism (checked, not assumed): at 4 bits the point estimate is still exactly right (4.00 bits) but the 95% lower bound
is 0.00 in every trial, because only 2-3 hard bins remain usable (this ladder has 13, 5 and 1 instances above 16 s and none at 8-16 s), some
of them marginal (5 instances), and the joint bootstrap re-selects bins in every resample, so the bound collapses when the usable set is
unstable. That is a property of how many HARD baseline instances the ladder has, not of the estimator being blind.

**More instances help, up to a hard ceiling.** `power.py --copies K --resample` builds each synthetic ladder with K x the instances per size, drawn at
random WITH REPLACEMENT from the real seed-D baseline records (so the number of hard instances varies from ladder to ladder, as it would for a genuinely
larger ladder of fresh instances); outputs saved as results/power_seedD_copies2_resample.txt and _copies4_resample.txt, 100 trials per effect.
P(credit >= 1):

| true speedup | n=24 (official) | n=48 | n=96 |
|---|---|---|---|
| 3 bits | 73% | 99% | 100% |
| 4 bits | 1% | 68% | 100% |
| 5 bits | not run | 50% | 98% |
| 6 bits | not run | 0% (inconclusive 93%) | 0% (inconclusive 66%) |

(An earlier version of this section used `--copies` WITHOUT `--resample`, which repeats the observed instances exactly and so guarantees K times
seed D's hard-instance count: that gave 99% at 4 bits and 73% at 5 bits for n=48, and 100% for both at n=96, results/power_seedD_copies2.txt and
_copies4.txt. Those are the optimistic case where a larger ladder happens to have exactly the observed composition; the resampled numbers above are
the honest ones, and they differ materially at n=48.)

So a round that expects a 4 to 5-bit speedup should set `n` to about 96 (`ops.py round-new --n 96`; logged in the round's first entry, accepted by the
board because the rule is n >= the minimum; the price is proportionally more machine time): n=48 is borderline (68% at 4 bits, 50% at 5). But NO n
removes the ceiling: at 6 bits the submission
costs under 0.5 s on every instance the baseline finished in under 32 s, only the 32-128 s bins could be usable, and the credit needs at least two
usable bins with 5 instances each, so the result is inconclusive. **The practical ceiling of the solver-versus-solver design at a 120 s cap is
about 5 bits.** The formula that stood here before, "maximum certifiable effect is about log2(hardest-bin baseline cost / 0.5 s), at most ~7 bits
at a 60 s cap" is therefore not attainable and is WITHDRAWN as a statement of what can be certified. Caveats: the simulation applies one constant
effect to every instance, while a real solver's effect varies (tuned BKZ's grows with dimension and it WAS certified at 2.6 bits at n=24), and
`--copies` assumes a larger ladder would have the same cost distribution as seed D's (a different seed or solver pair could have more or fewer hard
instances), and every cell carries roughly +-10 points of simulation noise: `power.py` draws 150 bootstrap resamples per trial while the real estimator
draws 300, and a re-run at 300 (results/power_seedD_boot300_n24.txt and _n48_resample.txt, 100 trials) gave 64% at 3 bits for n=24 (73% at 150), and
61% and 54% at 4 and 5 bits for n=48 (68% and 50% at 150), with the same regime in every cell and 0% false credit. So these show the shape of the limits, not a prediction for any particular
solver. Claims above about 5 bits need a different design (a baseline that is a model rather than a solver: EGG.md, "Ways forward" 2); not built.

**What to expect from the official run of the real pair (bootstrap of the real instances, n=24 only).** `power.py --real-pairs` resamples seed D's REAL
paired instances (the solver's real, instance-dependent speedup and its real failures) into 300 fresh ladders of the same size (boot 300; output saved as
results/power_seedD_realpairs_n24.txt). Credit per ladder: median 2.56 (the run itself gave 2.58), 5th percentile 1.15, 95th 2.94. P(one seed's credit >= 1
bit) = 96.7% and P(ALL THREE seeds >= 1 bit) = 91.0% (100 independent triples); the board credit is the minimum over seeds, so the likely official figure
sits near the low end of those. Caveats: this bootstraps ONE seed's instances, so it captures instance-sampling variation but not seed-to-seed or machine
variation; seed D ran with 6 concurrent jobs, which slowed the tuned solver more than the baseline (about 0.03 bits post hoc), so a sequential sandbox run
is, if anything, slightly better for this pair; the 1-bit threshold is the one registered for seed D, and the official run's own criteria are written when
it is registered. The same bootstrap scaled to 2x and 4x the instances is REFUSED by `power.py`: duplicating observed submission costs duplicates their
noise, so the bootstrap believes it has more information and reports an inflated credit (median 2.56 -> 2.94 -> 3.67); the invalid attempt is kept as
results/INVALID_power_seedD_realpairs_n48_duplicated_noise.txt and _n96_. Larger-ladder power comes from the synthetic mode above, where the noise is
redrawn for every instance.

**Exploratory hard-pool claim.** Because the bin-selection step is what makes small samples fragile, `extrapolate.py` also
prints a selection-free claim: pool every instance the baseline solved at cost >= 4 s (threshold fixed in advance as 8 x the
floor), require >= 12 of them and a submission median cost >= 0.5 s, and bootstrap the median normally. It is NOT the
credit; it is reported beside it so a validation run can say whether it should become the credit. Its 4 s threshold was
fixed after the author had seen seed A's bin table, so only runs pre-registered afterwards count as validation.

**Harness fixes found by audit:** the CPU cap used to be applied with `subprocess` `preexec_fn`, documented as unsafe when
spawning from several threads (possible deadlock); it is now set inside `runner.py` (soft = hard, set before the solver is
imported, so the solver cannot raise it). The hand-managed pipes also leaked 3 descriptors per run (macOS default limit
256); they are closed explicitly. Both have tests (test_harness_local.py), including 72 spawns at 12 jobs and an
fd-leak check. `remeasure.py` re-runs a stratified sample of a finished ladder sequentially to check, per cost octave,
that concurrent timings of HARD instances match sequential ones (end-to-end check on the sequential seed-A baseline ladder:
12 instances up to 38 s reproduced within +-0.06 bits each, median -0.012).

A second audit found the first fix introduced a hang: with an orphan holding the output pipe, the reader thread stayed
blocked in `read()` and my explicit `close()` then blocked on the stream's lock, so the harness never returned (reproduced:
no return after 90 s on a 2 s budget). Readers are now non-blocking and stoppable (select with a stop flag), the child runs
in its own session, and after a 2 s grace period everything left in that session is killed. Regression tests cover a
sleeping orphan and a CPU-burning orphan. KNOWN LIMIT of bare local mode: a solver that calls `setsid()` escapes that
cleanup and its daemon keeps running (and burning CPU) after the harness returns, unbilled; only the Linux/Docker meter
(unverified) can bill and kill such descendants. Local mode is for your own solvers.
Also found: on macOS a solver that ignores SIGXCPU is not killed at the CPU limit (Linux kills at the hard limit); it ran to
18.95 s CPU on a 3 s budget before the wall timer stopped it. It is still billed and marked a timeout, so there is no credit
advantage, but it stalls a run. The local wall backstop is now 1.5 x budget + 10 s (a solver killed by it, e.g. one that only
sleeps, is labelled `timeout`, not `crash`). `--jobs` above the safe maximum is refused. The maximum counts PERFORMANCE
cores only, minus 2 (8 on this 10-P-core machine, the range the drift check validated): jobs beyond that would run on
efficiency cores or oversubscribe, distorting timings and making wall time exceed CPU time, which the backstop assumes.

## Related work (checked by web search, not from memory)
The TU Darmstadt SVP Challenge and LWE Challenge are long-running fixed-instance lattice challenges with checkable
solutions and public records (SVP up to dimension ~180); they rank by capability (dimension solved), not by paired
bits-of-speedup over a reference under a committed seed. A 2024 benchmarking paper (arXiv 2408.00882) calls the Darmstadt
challenges the only concrete LWE benchmark and notes they omit standardized-parameter (small-secret, ring/module) cases.
This protocol is a complement to those, not the first lattice competition.

## Reproducing the baseline
`python3 judge.py evaluate --seed <seed> --submission solvers/baseline_bkz.py` must credit ~0 bits. If it doesn't, the
verifier is biased and results should not be trusted.
