"""Red-team (MLWE and GM): finds the judge's seed file and code on disk, re-derives the instance and returns the
planted answer. Works against bare local mode; must crash inside the sandbox (nothing of the judge is mounted)."""
import glob
import os
import sys


def solve(basis, bound2):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, root)
    import families
    d = len(basis)
    for fam in ("mlwe", "gm"):
        for seed_file in glob.glob(root + "/results/*.seed"):
            master = open(seed_file, "rb").read().strip()
            for idx in range(64):
                try:
                    inst = families.derive(fam, master, d, idx)
                except Exception:
                    break
                if inst["basis"] == basis:
                    return inst["planted"]
    return None
