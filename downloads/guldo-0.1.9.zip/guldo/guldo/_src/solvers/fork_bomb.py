"""Red-team: forks without end, each child spinning the CPU. The container's process limit and the meter's wall deadline must contain it:
a timeout or crash in bounded time, never a solve, and no process or container left behind."""
import os
import time


def solve(basis, bound2):
    while True:
        try:
            pid = os.fork()
        except OSError:
            time.sleep(0.05)   # process limit reached: keep trying
            continue
        if pid == 0:
            t = time.process_time()
            while time.process_time() - t < 30:
                pass
            os._exit(0)
