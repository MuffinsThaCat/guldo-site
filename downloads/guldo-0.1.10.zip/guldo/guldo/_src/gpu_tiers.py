"""GPU trust tiers T2, T3 and T4 (PROTOCOL.md, "GPU trust model"): the verifier-side code, written and tested WITHOUT a GPU.

  T2  independent re-measurement   make_t2_statement / check_t2      two or more parties the VERIFIER chose each re-measure the same ladder on the same named device model and sign whether
                                                                     their per-size medians agree with the operator's within the stated factor.
  T3  hardware-counted work        parse_ncu_csv / counters_to_work /  parse Nsight Compute output (`ncu --csv --page raw`), turn instruction and traffic counters into flops and bytes,
                                   compare_runs / make_t3_statement    check two runs of the same kernels agree, and sign the counts with the hash of the raw output.
  T4  attested confidential GPU    parse_attestation_token /           decode a GPU attestation token (a JWT), verify its signature against a public key YOU pinned, and apply a policy
                                   verify_token_signature /            (secure boot, debug off, allowed driver and firmware versions, measurements matched, nonce bound to the ladder).
                                   check_t4

  tier_report(...)   which tiers this evidence reaches and what each does NOT show.

STATUS, in capitals because it matters: NONE OF THIS HAS TOUCHED REAL HARDWARE OR A REAL TOOL OUTPUT. It is tested against fixtures I wrote from the tools' documented shapes (an ncu CSV layout, a JWT
whose claim names are configurable because I could not confirm NVIDIA's exact names here). Expect the first real run on an NVIDIA box to find format mismatches; `parse_ncu_csv` and the claim
map in POLICY_CLAIMS are the likely places. What the tiers can and cannot show is stated in each result and in PROTOCOL.md: T2 narrows who must be trusted, T3 counts real GPU work (not a time), T4
shows provenance (which device, firmware and software), still not an exact time.
"""
import base64
import csv
import io
import json
import re
import time

import agent_core
import agent_sig
from agent_core import canon, sha256_hex

RERUN_TOLERANCE = 1.3          # the same factor gpu_meter.verify --rerun uses
T2_FORMAT = "guldo-gpu-t2-v1"
T3_FORMAT = "guldo-gpu-t3-v1"


# ---- ladders (the gpu_meter format: one meta line, then one record per instance) --------------------------------------------------------------------------

def read_gpu_ladder(path):
    with open(path, "r", encoding="utf-8") as f:
        rows = [json.loads(ln) for ln in f if ln.strip()]
    if not rows or not rows[0].get("meta") or rows[0].get("cost_model") != "gpu_time":
        raise agent_core.AgentEvalError("%s: not a gpu_time ladder" % path)
    return rows[0], [r for r in rows[1:] if not r.get("meta")]


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and x == x and abs(x) != float("inf")


def check_shape(meta, recs):
    """Refuse a damaged GPU ladder with a clear error instead of a crash in the arithmetic. Not verification."""
    if not isinstance(meta, dict) or not isinstance(meta.get("cpu"), str) or not isinstance(recs, list):
        raise agent_core.AgentEvalError("malformed GPU ladder: the meta line needs a device string and the records must be a list")
    for r in recs:
        if not (isinstance(r, dict) and isinstance(r.get("id"), str) and isinstance(r.get("status"), str) and (r.get("status") != "solved" or (_num(r.get("cpu")) and _num(r.get("dim")) and r["cpu"] >= 0))):
            raise agent_core.AgentEvalError("malformed GPU ladder: a record lacks id/status, or a solved record lacks a numeric dim and cpu time")


def ladder_digest(meta, recs):
    check_shape(meta, recs)
    return sha256_hex(canon(meta) + "\n" + "\n".join("%s|%s|%s" % (r["id"], r["status"], r.get("cpu")) for r in sorted(recs, key=lambda r: r["id"])))


def medians_by_dim(recs):
    by = {}
    for r in recs:
        if r.get("status") == "solved" and not r.get("invalid"):
            by.setdefault(r["dim"], []).append(float(r["cpu"]))
    return {d: agent_core.median(v) for d, v in by.items()}


# ---- T2 ----------------------------------------------------------------------------------------------------------------------------------------------------

def compare_ladders(op_meta, op_recs, my_meta, my_recs, tolerance=RERUN_TOLERANCE):
    """The independent party's own ladder against the operator's. Returns (agree, problems, per_dim). Same device model string, solver hash, seed commitment and dims are required first."""
    check_shape(op_meta, op_recs)
    check_shape(my_meta, my_recs)
    probs = []
    for k in ("cpu", "solver_sha256", "commit", "family", "instance_version", "budget"):
        if op_meta.get(k) != my_meta.get(k):
            probs.append("%s differs (%r vs %r): not the same test on the same device" % (k, op_meta.get(k), my_meta.get(k)))
    a, b = medians_by_dim(op_recs), medians_by_dim(my_recs)
    if set(a) != set(b):
        probs.append("the two ladders do not have measured sizes in common (%s vs %s)" % (sorted(a), sorted(b)))
    per = {}
    for d in sorted(set(a) & set(b)):
        ratio = max(a[d] / b[d], b[d] / a[d]) if a[d] > 0 and b[d] > 0 else float("inf")
        per[str(d)] = {"operator_median_s": round(a[d], 6), "mine_median_s": round(b[d], 6), "factor": round(ratio, 4), "within": ratio <= tolerance}
        if ratio > tolerance:
            probs.append("size %s: medians differ by a factor of %.2f (tolerance %.2f)" % (d, ratio, tolerance))
    if not per:
        probs.append("nothing to compare")
    return not probs, probs, per


def make_t2_statement(op_meta, op_recs, my_meta, my_recs, secret, tolerance=RERUN_TOLERANCE, note="", now=None):
    agree, probs, per = compare_ladders(op_meta, op_recs, my_meta, my_recs, tolerance)
    st = {"format": T2_FORMAT, "ladder_digest": ladder_digest(op_meta, op_recs), "device": my_meta.get("cpu"), "agree": agree, "tolerance": tolerance, "per_dim": per, "problems": probs[:8],
          "own_ladder_digest": ladder_digest(my_meta, my_recs), "at": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "note": note[:300], "machine_self_reported": True}
    return agent_sig.sign_statement(st, secret)


def check_t2(op_meta, op_recs, statements, trusted, min_parties=2):
    digest = ladder_digest(op_meta, op_recs)
    good, dissent, unvouched, lines = set(), set(), set(), []
    for s in statements:
        if not agent_sig.statement_ok(s):
            lines.append("a statement has a bad signature (ignored)")
            continue
        st = s["statement"]
        try:
            if st.get("format") != T2_FORMAT or st.get("ladder_digest") != digest or st.get("device") != op_meta.get("cpu"):
                lines.append("a statement from %s... is about a different ladder or device (ignored)" % st.get("pubkey", "")[:12])
                continue
            if st.get("agree") is not True:           # anything but a plain True (including a malformed field) is a dissent
                dissent.add(st["pubkey"])
                lines.append("DISSENT from %s...: %s" % (st["pubkey"][:12], "; ".join(str(x) for x in st.get("problems", []) if isinstance(x, str))[:300]))
            elif st["pubkey"] in set(trusted or []):
                good.add(st["pubkey"])
            else:
                unvouched.add(st["pubkey"])
        except (TypeError, AttributeError, KeyError):
            lines.append("a signed statement is malformed (ignored)")
    ok = len(good) >= min_parties and not dissent
    lines.append("T2 %s: %d independent re-measurement(s) agree (%d needed), %d dissent, %d from unpinned keys not counted" % ("REACHED" if ok else "NOT reached", len(good), min_parties, len(dissent), len(unvouched)))
    return {"ok": ok, "independent": sorted(good), "dissent": sorted(dissent), "lines": lines}


# ---- T3 ----------------------------------------------------------------------------------------------------------------------------------------------------

# Nsight Compute raw metric names (documented in its roofline sections): single-precision FLOPs = fadd + fmul + 2 * ffma; DRAM traffic from dram__bytes.
FLOP_METRICS = {"sm__sass_thread_inst_executed_op_fadd_pred_on.sum": 1, "sm__sass_thread_inst_executed_op_fmul_pred_on.sum": 1, "sm__sass_thread_inst_executed_op_ffma_pred_on.sum": 2}
BYTE_METRICS = ("dram__bytes.sum",)
NCU_METRICS = list(FLOP_METRICS) + list(BYTE_METRICS) + ["smsp__inst_executed.sum"]


def ncu_command(python_cmd, metrics=None):
    """The command line to profile a measurement run. Run it yourself on the NVIDIA box; this only builds the string."""
    return ["ncu", "--csv", "--page", "raw", "--metrics", ",".join(metrics or NCU_METRICS)] + list(python_cmd)


def _num(text):
    t = str(text).replace(",", "").replace(" ", "").strip()
    if t in ("", "n/a", "N/A"):
        return None
    try:
        return float(t)
    except ValueError:
        return None


def parse_ncu_csv(text):
    """Rows of `ncu --csv --page raw` -> [{'kernel': name, 'id': kernel launch id, metric: value}] one dict per launch. Lines before the CSV header (==PROF== chatter) are skipped.
    Two layouts are accepted: one row per (launch, metric) with 'Metric Name'/'Metric Value' columns, and one row per launch with a column per metric."""
    lines = text.splitlines()
    start = next((i for i, ln in enumerate(lines) if ln.startswith('"ID"') or ln.startswith("ID,")), None)
    if start is None:
        raise agent_core.AgentEvalError("no CSV header found in the ncu output")
    rows = list(csv.DictReader(io.StringIO("\n".join(lines[start:]))))
    launches = {}
    for r in rows:
        key = r.get("ID", "")
        d = launches.setdefault(key, {"id": key, "kernel": r.get("Kernel Name") or ""})
        if "Metric Name" in r:
            v = _num(r.get("Metric Value"))
            if v is not None:
                d[r["Metric Name"]] = d.get(r["Metric Name"], 0.0) + v
        else:
            for k, v in r.items():
                if k and "__" in k and _num(v) is not None:
                    d[k] = _num(v)
    if not launches:
        raise agent_core.AgentEvalError("the ncu output holds no kernel launches")
    return list(launches.values())


def counters_to_work(launches):
    """Total flops and DRAM bytes over all launches, and a per-kernel-name profile. Missing counters count as zero but are listed in `missing`."""
    flops = bytes_ = 0.0
    missing = set()
    per = {}
    for L in launches:
        f = sum(w * L.get(m, 0.0) for m, w in FLOP_METRICS.items())
        b = sum(L.get(m, 0.0) for m in BYTE_METRICS)
        for m in list(FLOP_METRICS) + list(BYTE_METRICS):
            if m not in L:
                missing.add(m)
        flops += f
        bytes_ += b
        e = per.setdefault(L["kernel"], [0.0, 0.0, 0])
        e[0] += f
        e[1] += b
        e[2] += 1
    return {"flops": flops, "bytes": bytes_, "launches": len(launches), "missing_metrics": sorted(missing), "per_kernel": {k: v for k, v in sorted(per.items())}}


def compare_runs(a, b, rel_tol=0.02):
    """Two profiled runs of the same measurement must report the same work: the same kernels, launch counts, and flops/bytes within rel_tol (caches move traffic a little; flops should be identical)."""
    probs = []
    if set(a["per_kernel"]) != set(b["per_kernel"]):
        probs.append("the two runs launched different kernels")
    for k in sorted(set(a["per_kernel"]) & set(b["per_kernel"])):
        fa, ba, na = a["per_kernel"][k]
        fb, bb, nb = b["per_kernel"][k]
        if na != nb:
            probs.append("%s: launch counts differ (%d vs %d)" % (k, na, nb))
        for name, x, y in (("flops", fa, fb), ("bytes", ba, bb)):
            if max(x, y) > 0 and abs(x - y) / max(x, y) > rel_tol:
                probs.append("%s: %s differ by %.1f%% (tolerance %.1f%%)" % (k, name, 100 * abs(x - y) / max(x, y), 100 * rel_tol))
    return not probs, probs


def make_t3_statement(raw_ncu_text, work, solver_sha256, device, secret, runs_agree, now=None):
    st = {"format": T3_FORMAT, "raw_ncu_sha256": sha256_hex(raw_ncu_text), "solver_sha256": solver_sha256, "device": device, "flops": work["flops"], "bytes": work["bytes"], "launches": work["launches"],
          "missing_metrics": work["missing_metrics"], "runs_agree": bool(runs_agree), "at": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    return agent_sig.sign_statement(st, secret)


# ---- T4 ----------------------------------------------------------------------------------------------------------------------------------------------------

# Claim names and value types CHECKED on 11-27 against NVIDIA's attestation documentation (docs.nvidia.com/attestation, "GPU Claims"): measres is "success"/"fail", secboot a boolean, dbgstat "enabled"/
# "disabled", eat_nonce a string, hwmodel/driver/vbios strings, and the vendor verifier's own booleans below. NOT checked against a real token (no NVIDIA machine here); still configurable via claim_map.
# Map: policy key -> claim name in the token payload.
POLICY_CLAIMS = {"secure_boot": "secboot", "debug_status": "dbgstat", "measurements": "measres", "driver_version": "x-nvidia-gpu-driver-version", "vbios_version": "x-nvidia-gpu-vbios-version",
                 "hw_model": "hwmodel", "nonce": "eat_nonce", "overall": "x-nvidia-overall-att-result", "report_nonce_match": "x-nvidia-gpu-attestation-report-nonce-match",
                 "driver_rim_sig": "x-nvidia-gpu-driver-rim-signature-verified", "vbios_rim_sig": "x-nvidia-gpu-vbios-rim-signature-verified", "report_sig": "x-nvidia-gpu-attestation-report-signature-verified"}
VENDOR_VERDICT_KEYS = ("overall", "report_nonce_match", "driver_rim_sig", "vbios_rim_sig", "report_sig")


def _b64d(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def parse_attestation_token(token):
    """(header, payload) of a JWT, NOT verified. Never trust a payload before verify_token_signature."""
    parts = token.strip().split(".")
    if len(parts) != 3:
        raise agent_core.AgentEvalError("not a JWT (three dot-separated parts expected)")
    try:
        h, p = json.loads(_b64d(parts[0])), json.loads(_b64d(parts[1]))
    except (ValueError, TypeError):             # binascii.Error and UnicodeDecodeError are ValueErrors
        raise agent_core.AgentEvalError("the JWT header or payload is not JSON")
    if not isinstance(h, dict) or not isinstance(p, dict):
        raise agent_core.AgentEvalError("the JWT header and payload must be JSON objects")
    return h, p


def verify_token_signature(token, public_pem):
    """True/False for ES256/ES384/RS256 against a PEM public key YOU obtained from the vendor's documented endpoint; None if the `cryptography` package is missing (then nothing is verified)."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec, padding, utils
    except ImportError:
        return None
    try:
        h, _ = parse_attestation_token(token)
        p = token.strip().split(".")
        msg, sig = (p[0] + "." + p[1]).encode("ascii"), _b64d(p[2])
    except (agent_core.AgentEvalError, ValueError, TypeError):
        return False
    try:
        key = serialization.load_pem_public_key(public_pem if isinstance(public_pem, bytes) else public_pem.encode())
        alg = h.get("alg")
        if alg in ("ES256", "ES384"):
            half = len(sig) // 2
            der = utils.encode_dss_signature(int.from_bytes(sig[:half], "big"), int.from_bytes(sig[half:], "big"))
            key.verify(der, msg, ec.ECDSA(hashes.SHA256() if alg == "ES256" else hashes.SHA384()))
        elif alg == "RS256":
            key.verify(sig, msg, padding.PKCS1v15(), hashes.SHA256())
        else:
            return False
        return True
    except Exception:
        return False


def check_t4(token, public_pem, policy, ladder_digest_hex, claim_map=None, now=None):
    """Apply a policy to a token. policy keys: allowed_drivers, allowed_vbios, hw_model (list or None), require_nonce_binding (bool, default True). Returns {ok, signature, lines}."""
    cm = dict(POLICY_CLAIMS, **(claim_map or {}))
    lines = []
    sig = verify_token_signature(token, public_pem)
    if sig is None:
        lines.append("FAIL: the `cryptography` package is missing, so the token's signature was NOT verified")
    elif not sig:
        lines.append("FAIL: the token's signature does not verify against the pinned public key")
    try:
        _h, pl = parse_attestation_token(token)
    except agent_core.AgentEvalError as e:
        return {"ok": False, "signature_verified": sig, "claims_seen": {}, "lines": lines + ["FAIL: " + str(e)]}
    ok = sig is True
    exp = pl.get("exp")
    if isinstance(exp, (int, float)) and exp < (now if now is not None else time.time()):
        lines.append("note: the token has expired (tokens are short-lived; what matters is that it was valid when issued, so check `iat` against the measurement time)")

    def need(cond, text):
        nonlocal ok
        lines.append(("PASS: " if cond else "FAIL: ") + text)
        ok = ok and cond
    if policy.get("require_vendor_verdict", True):       # the vendor verifier's own booleans: overall result, report nonce match, and that the RIM and report signatures were verified
        for key in VENDOR_VERDICT_KEYS:
            need(pl.get(cm[key]) is True, "the vendor verifier says %s is true (claim %s = %r)" % (key.replace("_", " "), cm[key], pl.get(cm[key])))
    need(pl.get(cm["measurements"]) in ("success", True), "measurements matched the reference (claim %s = %r)" % (cm["measurements"], pl.get(cm["measurements"])))
    need(pl.get(cm["secure_boot"]) in (True, "true", "enabled"), "secure boot (claim %s = %r)" % (cm["secure_boot"], pl.get(cm["secure_boot"])))
    need(pl.get(cm["debug_status"]) in ("disabled", "disabled-since-boot", False), "debug off (claim %s = %r)" % (cm["debug_status"], pl.get(cm["debug_status"])))
    if policy.get("allowed_drivers"):
        need(pl.get(cm["driver_version"]) in policy["allowed_drivers"], "driver version %r is on the allow-list" % pl.get(cm["driver_version"]))
    if policy.get("allowed_vbios"):
        need(pl.get(cm["vbios_version"]) in policy["allowed_vbios"], "firmware version %r is on the allow-list" % pl.get(cm["vbios_version"]))
    if policy.get("hw_model"):
        need(pl.get(cm["hw_model"]) in policy["hw_model"], "hardware model %r is on the allow-list" % pl.get(cm["hw_model"]))
    if policy.get("require_nonce_binding", True):
        nonce = str(pl.get(cm["nonce"], ""))
        need(nonce in (ladder_digest_hex, sha256_hex(ladder_digest_hex)), "the token's nonce is the ladder digest (or its sha256): the token was issued for THIS measurement")
    return {"ok": ok, "signature_verified": sig, "claims_seen": {k: pl.get(v) for k, v in cm.items()}, "lines": lines}


# ---- the summary -------------------------------------------------------------------------------------------------------------------------------------------

TIER_MEANING = {
    "T1": "one operator's clock on one pinned device model (gpu_meter.py)",
    "T2": "independently re-measured on the same device model by parties you pinned; narrows who must be trusted, still times on rented or owned hardware",
    "T3": "real GPU work counted by hardware counters (flops, DRAM bytes): not a time, but not the operator's word either",
    "T4": "provenance: an attested confidential-computing GPU produced the measurement; still not an exact time"}


def tier_report(t1_ok, t2=None, t3_ok=None, t4=None):
    reached = []
    if t1_ok:
        reached.append("T1")
    if t2 and t2.get("ok"):
        reached.append("T2")
    if t3_ok:
        reached.append("T3")
    if t4 and t4.get("ok"):
        reached.append("T4")
    return {"tiers_reached": reached, "meaning": {t: TIER_MEANING[t] for t in reached},
            "not_shown": ["that any claim holds on another device model", "an exact time (none exists)", "anything about code paths the measured instances did not exercise"],
            "tested_on_hardware": False}
