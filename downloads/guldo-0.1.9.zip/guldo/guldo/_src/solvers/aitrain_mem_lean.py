"""aitrain with peak memory counted (tflops_mem.py), TECHNIQUE: the same fp64 method as aitrain_flops_std with the same operation count, but it drops the raw feature matrix as soon as the
scaled one exists and forms the gradient with an einsum instead of keeping a transposed copy of the features alive. The footprint is smaller; the work is the same."""
import math

import tensorops as tp

K = 3
KAPPA = 30.0
STEPS = 40
LR = 1.0


def solve(seed, d, n, labels):
    sc = tp.tensor([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = tp.reshape(tp.stream(seed, 0, n * d), (n, d)) * sc
    inv = 1.0 / tp.sqrt(tp.mean(X * X, 0))
    Xs = X * inv
    X = 0
    Y = tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(n)])
    W = tp.zeros((d, K))
    for step in range(STEPS):
        Z = Xs @ W
        E = tp.exp(Z - tp.max(Z, 1, True))
        W = W - tp.einsum("ni,nk->ik", Xs, E / tp.sum(E, 1, True) - Y) * (LR / n)
    return [int(x * 1048576.0) for x in tp.reshape(W * tp.reshape(inv, (d, 1)), (d * K,)).tolist()]
