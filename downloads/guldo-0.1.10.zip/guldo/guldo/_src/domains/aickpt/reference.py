"""Reference for aickpt: store every activation and ReLU mask of the forward pass, then backpropagate over them (float64)."""
import math

import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, L, w, B):
    X = _uniform(seed, 0, B * w).reshape(B, w)
    W = _uniform(seed, B * w, w * w).reshape(w, w) * math.sqrt(3.0 / w)
    T = _uniform(seed, B * w + w * w, B * w).reshape(B, w)
    alpha = 0.5 / L
    hs, ms, h = [X], [], X
    for _ in range(L):
        a = h @ W
        ms.append((a > 0).astype(np.float64))
        h = h + alpha * np.maximum(a, 0.0)
        hs.append(h)
    delta = (h - T) / (B * w)
    dW = np.zeros((w, w))
    for t in range(L - 1, -1, -1):
        gm = delta * ms[t]
        dW += alpha * (hs[t].T @ gm)
        delta = delta + alpha * (gm @ W.T)
    return [int(v) for v in np.rint(dW.ravel() * 2 ** 40)]
