# Verifiable agent evaluation (operator guide)

New files only; nothing in `rounds.CODE_FILES` / `COUNT_FILES` was touched, so no open round's fingerprint moved (factor-1, lattice).

| file | what it is |
|---|---|
| `agent_core.py` | seeds (HMAC per instance), exact statistics (Clopper-Pearson, exact sign test, deterministic bootstrap), ladder format, hash-chained trajectories, domain registry |
| `agent_domains/{dataanalysis,toolstate,coding}.py` | three task domains: `derive(seed, size)`, tools, exact `verify(instance, answer, calls)` |
| `agent_harness.py` | the trust boundary: public view only, proxy token counting, caps, trajectory record, `check_trial` (the re-verification) |
| `agent_providers.py` | scripted stand-in agents (NOT models) and an Anthropic Messages API agent (UNRUN against the live API) |
| `agent_compare.py` | per-agent summary and the paired comparison, the verdict rule, claim checks |
| `agent_eval.py` | command line: `domains checkdomain plan run verify summary compare check claim selftest` |
| `test_agent_eval.py` | 85 tests (Python 3.9 and 3.14), no network, no key |

## What it proves, and what it does not

A ladder verifies when, from the stored records and the revealed seed alone: every instance is re-derived and matches; every submitted answer passes the exact verifier; every
tool call is replayed on a fresh environment and gives the recorded result; every proxy token count is recomputed from the stored context; the hash chain holds; the plan hash
and pinned code match. A comparison is then recomputable by anyone from the two ladders (`check`).

**NOT shown, and the most important limit:** that a particular model produced the trajectories. A language model cannot be re-run to the same trajectory, so verification checks
that a record is internally true and its output correct. An operator could write a trajectory by hand that passes every check. What stops that today is only trust in the operator,
exactly as in the early speed rounds. Closing it needs one of: the provider signing its responses, a counting/recording proxy the verifier trusts, running the agent in the
verifier's own environment, or independent witnesses re-running a sample. None is built. Say so whenever a result is quoted.

Other limits (also printed in every comparison file): tokens are PROXY tokens (`ceil(utf-8 bytes / 4)` of the exact context re-sent each turn plus the output), recomputable but not a
provider's billed count; the tasks come from a public generator, so commit-reveal means no judged instance could have been seen, not that the skill could not be trained for; an
instance is "solved" when more than half of its trials pass and cost is the mean over solved trials; unsolved instances are excluded from the cost gap (understating that side's
cost); the coding sandbox has limits but is NOT a security sandbox (run untrusted agents in a container or VM you can lose); the three domains are pilot size and one agent
configuration is compared to another, not "models" in general.

## Status (what has and has not been run)

* RUN and passing: all 75 tests on Python 3.14.0 and 3.9.6; `checkdomain` on all three domains (including controls: a cheating agent solves 0, the lean scripted agent solves all);
  `selftest`; the whole CLI workflow on all three domains with scripted agents, 3 trials per instance, `check` and `claim` confirming; a 120-case fuzz of damaged ladders (found and
  fixed: a crash on a record missing a field, a header whose `plan_hash` or `counter` could be deleted, an untyped `reason`).
* NEVER RUN (as first written; ONE small local model HAS since been run on one domain, see "The first real-model runs" below, so read "any real model" as "any hosted or larger model"): the Anthropic adapter against the live API (RUN since: see "The first runs against the live Anthropic API"); any real model on any domain (RUN since);
  anything on the Linux server; any outside user.
* Results so far are scripted stand-ins on the PRACTICE seed. They show the pipeline and what a tool-use policy costs. They say nothing about any model.

## Audit of 27 November (first pass, by the author, with the code in front of them)

Found by reproducing each suspicion before changing anything, then fixed, each with a regression test (85 tests now):

1. **An honest trial was reported as a forgery.** A correct final answer submitted on the very turn that crosses the token cap is (rightly) scored unsolved, but `verify` then said
   "recorded as unsolved but the verifier accepts the answer". The verifier now RE-SIMULATES the harness's control flow over the stored turns (`agent_harness._replay_control_flow`), so
   it knows which calls were executed and how the trial had to end. A matrix test covers 15 ways an honest trial can end (each cap, no submit, malformed submit, disallowed tool, agent error, ...).
2. **Turns after the end, or a missing/extra tool turn, were not noticed.** Now flagged ("trajectory: ...").
3. **The caps were never checked at verification.** A trial over its turn or tool-call cap, or a recorded reason that is not how the trajectory ends, is now flagged.
4. **The `practice` flag was not tied to the seed.** A ladder made with the public practice seed could say `practice: false`. Now flagged.
5. **Coding sandbox memory.** `RLIMIT_AS` is not enforced on macOS; a runaway solution could eat the laptop. A resident-memory watchdog now runs inside the child (768 MB, tested at 150 MB).
6. **Two things that cannot be fixed in code, now stated and guarded.** (a) The coding domain runs the agent's code as the operator's user; with a SECRET seed on the same machine the code
   could read the seed file and derive every hidden test. A real coding round now refuses to start without `--accept-unsandboxed-code` (run in a container or VM that does not hold the
   seed file). (b) Verifying a coding ladder EXECUTES the submitted code on the verifier's machine (a warning is printed): verify in a container.
7. **Statistics wording.** Each verdict is one-sided at 5% and the report names whichever direction occurs, so the false-"difference" rate is about 10%; quote the pre-registered `claim`
   (direction fixed in advance), not an after-the-fact verdict. Now stated in the code and here.
8. Earlier in the build, a 120-case fuzz of damaged ladders found a crash on a missing field, a deletable `plan_hash`/`counter`, and an untyped `reason`.

Still open after this pass: the operator-can-forge-a-trajectory gap (closed only by the attestation path in "Extras", and only if the verifier holds the shim key; UPDATE, later the same day: it is now also closed for a whole round by the recording proxy, `agent_proxy.py verify-round`, and a certificate can embed and re-check that, demonstrated once on a local model, but only when a verifier who is NOT the operator runs the proxy and holds the key); the scripted agents are not models.

## Second audit and the open items (27 November, later)

**Second audit of the first audit's fixes.** A differential fuzz: 1,260 honest trials from random agents (illegal calls, errors, silence, random caps) through the REAL harness all verify clean (0 false
positives, every ending type reached), and 10,074 single-field forgeries of valid records are all flagged (132 were accepted at first: the recorded reason `agent error: X` was matched by prefix, so
`agent error: X!` passed; now an exact pattern). Kept as a permanent test (`test_differential_fuzz...`).

**Open item: the wall-time cap now covers a hung agent.** `agent_harness._respond_within` runs `respond` in a daemon thread and abandons it at the cap (the trial ends `over wall-time budget`;
Python cannot kill the thread, so it runs on in the background until it returns).

**Open item: the Anthropic adapter was checked against the SDK's current guidance and was WRONG in five ways, now fixed** (`agent_providers.AnthropicAgent`): it sent `temperature=0.0` (a 400 on the current
models: sampling parameters are removed); `max_tokens` was 2048 (thinking is always on and counts against it); it dropped the model's signed `thinking` blocks when echoing history (they must be passed back
unchanged); it used raw `urllib` instead of the official `anthropic` SDK (now an OPTIONAL dependency, imported only for real-model runs: `pip install anthropic`); and it ignored `refusal` and could not
notice a silent fallback to another model (`served` records the model ids the API reports and `run` warns on a difference; NO server-side fallback is enabled, since a fallback would make "which model" meaningless).
Default model is `claude-opus-5-5`; `anthropic:MODEL[:EFFORT]` selects model and effort. Tested with a fake client everywhere and with the REAL SDK (2.14.0) over a mock transport where it is installed (request
body inspected, a real `Message` parsed, thinking echoed): at that point never sent to the live API (it has since been: see "The first runs against the live Anthropic API").

**The things the document implied but the first build skipped (all NEW files, scripted agents only, never with a real model):**

* `agent_power.py`, the POWER PASS: how many instances and trials a claim needs, and the money, before any spend. Exact for the solve-rate bound (Clopper-Pearson) and the paired success test (exact sign
  test); seeded simulation of the real rule for the cost verdict and the stratified bound; `from_pilot` estimates the assumptions from a pilot pair and says when the pilot is too small to trust (under 20
  instances, under 8 solved by both); prices are YOURS (none built in). Found while testing: positive correlation between two agents' outcomes RAISES the sign test's power, so independence (rho = 0) is
  the conservative default. `python3 agent_power.py success-diff --p-base 0.6 --p-cand 0.85` -> about 45 instances; `cost-uplift --mean-bits 1.5 --sd-bits 1 --factor 2` -> about 34. 24 tests.
* `agent_rounds.py`, the ROUND LIFECYCLE on the project's own hash-chained log: create (plan, seed COMMITMENT, code pins; the seed is never stored) -> enter (an entrant submits an agent CONFIGURATION:
  model spec, label, allowed tools, system prompt, never code) -> close -> evaluate (the operator holds the seed and runs the baseline and every entry on the same instances; resumable) -> reveal ->
  result -> verify -> export. Evaluation is the operator's because with a secret seed entrants cannot run the test themselves: that is the commit-reveal point and its cost (the operator spends the money
  and is trusted to have run each configuration as submitted; the attested path removes that trust). Verification re-checks the log chain, the pins, every entry, every ladder (file hash, digest, plan),
  the seed, and the results, and found two holes while being tested: a removed log TAIL is invisible to a hash chain (now every file on disk must be logged, `round.json`'s state must match the log, and
  `verify --head H` requires a head the operator published earlier: publish heads after create, close and reveal, or a removed tail with its files cannot be ruled out); an edited `state` field. 26 tests.
* `agent_cert.py`, the CERTIFICATE: one document per entry, bound to the round (plan hash, commitment, log head, both ladder hashes, the entry's configuration). Its statement is GENERATED from the numbers,
  and `verify` re-verifies both ladders from the seed, recomputes the comparison, regenerates the statement and the claims, and checks the log head and configuration hash against the round's files.
  Optional Ed25519 signature (`agent_sig.py`) says who issued it and adds nothing to what the data prove. 17 tests. NOT in `certificate.py`'s speed format and NOT in `translog.py` (that log's leaves are
  speed certificates; an agent leaf type is a change to that shared file).
* Test counts now: `test_agent_eval` 97, `test_agent_power` 24, `test_agent_rounds` 26, `test_agent_cert` 17, all green on Python 3.9 and 3.14. `test_agent_extras` (other session's) had 4 errors at the time of
  writing (a changed `agent_attest.convert` signature and the speed-certificate progress tracker); not caused by these files.

Still NOT done: any real model run; a counted-tokens proxy for providers; intake/portal/site/package integration for agent rounds (below); a transparency-log leaf type for agent certificates.

## Third audit (all of it, 27 November): found by running things, not only reading

**Fixed (each with a regression test; 280 agent tests pass in ONE process, as the Makefile gate runs them, and on Python 3.9 and 3.14):**

1. **Large-n overflow.** `binom_upper_tail` multiplied `math.comb(n, i)` by a float and `sign_test_p` divided by `float(2 ** n)`: both raised `OverflowError` past about n = 1030 / 1023. Exact integer path kept up to
   n = 1000 (no value changed), log-gamma above (matches exact fractions to about 12 digits).
2. **The power pass took 418 s to answer a hard target** (p 0.72 against a 0.70 claim): every n up to 1500 with unmemoised 11-point windows. Now memoised and coarse-then-fine (exact step 1 up to n = 120): 11 s, same answers.
3. **Entrants could run up the operator's bill.** An entry names any model and effort and the operator pays per trial: `create_round(allowed_models=...)` pins an allow-list in the log; entry and `verify_round` both enforce it.
4. **Ed25519 small-order public key forged signatures.** Under RFC 8032's bare equation the identity point as a public key with signature (identity, 0) verified for EVERY message; any signed statement carries its own
   public key. `agent_sig.verify` now rejects small-order keys and nonces (RFC test vectors 1 and 2, malleability, truncation, non-canonical keys all checked; `test_agent_sig_audit.py`).
5. **Bounty ledger, three bugs.** (a) A claim file made by the normal `agent_eval.py compare --out` carries a `reverified` note and could NEVER pass the exact-recomputation check. (b) **A ladder built after the seed
   is revealed wins any bounty**: anyone can write an agent that re-derives every answer in one turn (demonstrated: 31.8x fewer tokens, 16/16 solved, passes every check). A bounty now names its `round_id`; the ladders
   must be ones that round's log recorded BEFORE its reveal, from the claimant's own entry, in a round that verifies; a real bounty with no round cannot be posted (explicit `allow_unbound_ladders` for demos, shown in
   the verdict). `agent_tools.py bounty ... --round-base DIR` supplies the round. (c) Two concurrent appends forked the hash chain (12 writers left 2 entries and an unverifiable ledger): now `flock`ed.
6. **The cost verdict's 5% was nominal.** With a true mean gap of ZERO but rare large losses in the population (usually a little cheaper, occasionally much dearer) it said "candidate uses fewer tokens" 10-35% of
   the time: a small sample often contains no loss and the bootstrap bound of a mean is then invalid. The bound is now computed after ONE pessimistic pseudo-observation (a loss as large as the worst loss seen, at least
   1 bit; `agent_core.pessimistic_gap`): 0% on the 90/10 and 80/20 cases; on a 10% x 12-fold blow-up it only HALVES the false rate at n = 40 (15% -> 6-8%, measured through `compare()`; a first write-up said 3%, from a standalone experiment: wrong) and does nothing at n = 20; little power lost (0.93 -> 0.91 at n = 20, 1 bit, sd 1). A first version scaled with big WINS and cut a
   consistent 14.5x gain to 6.1x; the shipped one gives 9.4x. The comparison now also reports `lower95_bits_unadjusted`, `worst_gap_bits` and `dearer_by_1_bit_or_more_on`. `agent_power.cost_power` follows the same rule.
   **NOT fixable by any rule:** a blow-up that is rare AND huge (5% of instances 500x dearer, n = 20) is not in most samples; false verdicts stay near 38% there. A harness that can run to the token cap needs a large n.
7. Wiring finished: Makefile UNIT, `static_check.py` (84 files, 0 problems), `build_package.py` tools `agent-power`, `agent-rounds`, `agent-cert` (their entry points are now `main()`), README.

**Checked and fine:** coverage of the pooled Clopper-Pearson bound, the stratified bound and the worst-size bound (simulated: 0.98-1.00 against the 0.95 target, conservative); the RFC 8032 vectors; every ending of an honest
trial through the verifier (1,260 trials, 10,074 forgeries); the safety domains (a gullible agent is recorded UNSAFE 12/12 and the verifier agrees); the other session's bounty state machine and witness statistics.

**Re-audit of the third audit's own fixes (measuring the SHIPPED functions, not the experiments that justified them):**
* The tail correction's reverse claim ("baseline is cheaper") REUSED the forward claim's pseudo-observation, but its worst loss is the candidate's biggest WIN: mirrored skewed data got a slightly more lenient verdict
  (0.150 vs 0.127 false verdicts at n = 20). Fixed (each claim gets its own). A deterministic case (19 gaps of 0.6 bits one way, 1 of 3 bits the other) is the regression test and was mutation-checked to FAIL on the
  old behaviour; a first symmetry test I wrote passed on the old behaviour too (vacuous) and was replaced.
* **A number I documented was wrong:** "3% false verdicts on a 10% x 12-fold blow-up at n = 40" came from a standalone experiment. Through `compare()` it is 6-8% (15% without the correction), and at n = 20 the
  correction does essentially nothing for that shape (about 14%). Corrected here and in `agent_core.pessimistic_gap`.
* `agent_tools.py bounty verdict` without `--round-base` on a round-bound bounty recorded a PERMANENT FAIL (verdicts are never overwritten), ending a legitimate claim and unlocking the sponsor's refund over a
  forgotten flag. Now refused with nothing recorded; so is "could not be evaluated here" (an environment problem, not a verdict).
* Verified, no change needed: shipped `compare()` has 0% false verdicts on the 90/10 skew and 0.90 power at 1 bit / n = 20, forward and mirrored alike; all 8 small-order Ed25519 encodings are rejected as keys and
  as nonces; rounds' default model equals the adapter's (a test now, so the allow-list cannot drift); the coarse power search equals brute force beyond n = 120 (249 = 249); 291 agent tests pass in one process on
  Python 3.14 and 3.9 (a few transient failures appeared only while another session was editing `coding.py` and `agent_eval.py`).

**Found, then FIXED later the same day (see "Fourth audit" below for how far each fix goes, and what it cannot do):** the best-of-N shim sessions hole in `agent_attest.py`, the free witness veto in
`agent_witness.check_witnesses`, and the unlimited unauthenticated bounty challenges in `agent_bounty.py`.

**Found, NOT fixed:**
* A removed log TAIL together with its files is invisible without a head the operator published earlier: `agent_rounds verify --head H`. (The same is true of the new session registry: `--registry-head`.)
* Still never run (as of this audit; a later section records three runs of one small local model, two of them through the recording proxy to a local Ollama server): any hosted model, the Anthropic adapter against the live API, the recording proxy against a hosted provider, any GPU, any outside user.

## Fourth audit (27 November): closing the three "found, not fixed" holes as far as identities and a provider are not needed

Tests: `test_agent_gaps.py` (46, including the preflight and the audit fixes below), mutation-checked on a scratch copy (14 + 11 + 5 deliberate breakages, all caught); the existing agent suites still pass. Nothing here ran against a real model, provider or outside user.

1. **Best-of-N shim sessions** (`agent_attest.SessionRegistry`, `check_sessions`; `attest-verify/convert --registry FILE [--allow-multiple-sessions] [--registry-head H]`). The shim holder keeps an append-only, hash-chained,
   SIGNED registry of every session it OPENS (the shim, not the caller, picks the session number) and CLOSES (receipt count and last-receipt hash). A verifier given the registry learns how many sessions were opened for
   a plan, whether the presented receipts are the complete closed chain of one registered session (truncated, extended, spliced or unclosed ones are refused), and, unless told to allow it, refuses a plan with more than
   one session (the ladder may be the best of several); with `--allow-multiple-sessions` the count is a stated fact. **Limits:** it moves trust to the shim holder's key and file, like the receipts; a model call routed
   around the shim is invisible; and a registry with its LAST events removed looks shorter, not wrong, unless the verifier holds the head recorded earlier (`--registry-head`), exactly as for the round logs. Without
   `--registry` the command now prints that selection among sessions cannot be ruled out.
2. **Free witness veto** (`agent_witness.check_witnesses(..., own_problems=)`; `witness-check ... --seed F|--practice`). A dissent from a key you PINNED blocks, as before. A dissent from a key you did not pin saying
   "this ladder does not verify" is checkable, so it blocks only until you recompute: with your own verification result it is REFUTED (listed, not blocking) if you found nothing, CONFIRMED if you found something.
   An unpinned rerun-inconsistency flag cannot be checked without paying to run the model: listed, not blocking. 24 throwaway keys can no longer freeze a ladder you have verified. **Limit:** a real outside dissent about
   a rerun is now only advisory unless you pin that witness.
3. **Bounty challenges** (`agent_bounty.challenge(..., ground=)`; `bounty challenge --ground verification|other`). `settle` already re-runs the whole claim check, so a "does not verify" challenge (`verification`) is
   recorded and never blocks. Any other ground blocks until a human resolves it, with one challenge per name for the bounty's life, at most 3 blocking at once, and none after a passing claim's window has closed.
   **Limit:** the ledger cannot authenticate challengers, so someone inventing names can still hold a bounty for the window and cost the resolver up to 3 decisions: bounded, not prevented.

4. **Preflight for the first real run** (`agent_preflight.py`; `python3 agent_tools.py preflight --plan P --agent anthropic:MODEL --seed S --out L [--price-in X --price-out Y] [--pilot-done]`). Everything that can be
   checked WITHOUT a model call, so the first live run does not waste money or produce an unusable result: the plan matches the seed and the pinned files; the seed is not in this checkout or any git repository and is not
   world-readable; the Anthropic SDK is installed and finds credentials (resolved, never read or printed; nothing is sent); whether calls go through a recording proxy (otherwise the result is operator-trusted, said as a
   WARN); a token and money CEILING from the plan's cap and prices YOU give (none built in; it is a ceiling on proxy tokens, not a guarantee, and says so); a warning for a plan of more than 6 trials with no
   one-instance pilot; the code-running domains need a container or an explicit acceptance; the output path is never overwritten. It prints the exact `run` command and does NOT run it. Tested without any network
   (11 of 11 deliberate breakages caught). **Cannot know:** that the provider accepts the key, that the model name exists, or the real cost: the `--n 1` pilot is the check for those.

**Audit of the above, same day, by trying to break it (each reproduced before it was fixed):**
* **The session registry handed ONE id to concurrent shims** (16 simultaneous `open()`s all got `s0`): the count was read before the file lock was taken. The id is now chosen inside the lock (24 concurrent opens: 24 distinct
  ids, chain intact). This was a real hole in the fix for the best-of-N problem. Regression test with 20 threads.
* **`attest-verify --allow-multiple-sessions` passed silently**, which defeats "state the attempt count". It now prints `SESSIONS: N opened for this plan, this ladder is session sK (...abandoned)`.
* **One person could use all three blocking challenge slots** as "carol", "Carol", "carol ": names are now compared after Unicode compatibility normalisation, case-folding and whitespace collapse; empty names are
  refused; and a bounty accepts at most 25 recorded challenges of any ground (500 non-blocking ones were accepted before). **Still not caught:** homoglyphs from another script (a Cyrillic "a"): that needs identities.
* **Preflight said the Anthropic SDK "finds credentials".** The SDK may build a client with no credential and fail only on the first request (not verifiable here: the SDK is not installed). It now checks the
  environment for `ANTHROPIC_API_KEY`/`ANTHROPIC_AUTH_TOKEN` itself (WARN if absent; an `ant auth login` profile cannot be seen), never echoes the value, and its docstring says the no-request property of the real SDK's
  constructor was not verified.
* **A line in `agent_tools.py` (another session's, in `witness-rerun`) re-imported `agent_providers` inside `run()`**, making the name local for the whole function and breaking every earlier use, including `preflight`. Removed the redundant local import.

**Overcoming the limits that audit left (the bullets above that say "not verifiable", "needs identities" or "someone must keep the head" are superseded by this):**
* **The Anthropic SDK behaviour is now MEASURED, not assumed.** Installed `anthropic` 2.14.0 in a scratch virtualenv and ran it with every socket blocked: construction makes **zero network calls** and does **not** raise
  without a credential (so the adapter's old "no credentials found" branch was dead code and a run would have recorded an agent error on every trial); a keyless request fails locally with `TypeError`. The SDK's own
  offline validation (`agent_providers.credentials_resolve`: True / False / None = cannot tell) sees an API key, an auth token, and a stored login, so preflight now FAILs on a definite "no credential" and
  `AnthropicAgent` refuses to start a run without one. Tested with fakes everywhere and against the REAL SDK when it is installed (`test_the_real_sdk_when_installed...`, run and passing in the scratch virtualenv).
  Uses a private SDK method: another version answers None and the environment is the fallback.
* **Bounty challenger identity** (`challenger_pubkeys` in the spec; `bounty challenge --key FILE`). If the sponsor pins the keys of those allowed to object, a BLOCKING challenge must be signed by one, one per key
  (`check_challenge_signature`: covers the bounty, name and reason; a stranger's valid signature, a second challenge from the same key, and an edited row are all refused). The invented-name attack (50 names) freezes
  nothing. Without pinned keys the earlier bounds still apply, now with stricter names: ASCII only after normalisation (this refuses a Cyrillic "a") and common lookalikes folded (0/o, 1/l/i, 5/s, 3/e, 4/a, 8/b, @, $),
  which can refuse a second honest name that folds the same (they file under another). Free "verification" challenges stay open to anyone but obey the name rules. **Remaining limit:** with no pinned keys, someone
  inventing ASCII names unlike each other can still hold a bounty for the window and cost the resolver up to 3 decisions.
* **Registry truncation / rewriting** (`SessionRegistry.signed_head()`, `registry-head` command, `attest-verify --signed-head FILE`, repeatable). The shim signs "N events, last hash H". Anyone who ever saw one can later
  prove a registry was SHORTENED ("events were REMOVED") or REWRITTEN, even by someone holding the shim key who re-signed a flawless chain of the same length (tested: only the head catches it). **Remaining limit:** the head
  must come from AFTER the hidden session (an earlier one cannot show it, tested), and someone must have kept it: publish one at every close.
* **A torn registry line** (the shim died mid-write) is now a clear "damaged at line N" refusal that overwrites nothing, instead of a raw JSON error that would block every future session.
* **Quantiser edge** (`tensorops_mem2.py`): with fp32 scales, data far outside fp32's range gave an infinite scale and NaN values (1e300 input). Scales are clamped to fp32's normal range, so such data saturates or
  flushes to zero like a stored fp32 scale would. The saved `aiintquant` ladders were re-made (numbers unchanged).

**Third pass (found by trying to defeat the previous fixes):**
* **A row appended to the ledger file froze a pinned-challenger bounty.** The ledger is a hash chain, not a signature: anyone holding the file can append a well-formed `challenge` entry, and `state()` counted it as
  blocking without checking the signature. `state()` now counts a blocking challenge under pinned keys only if it is validly signed by a pinned key (`check_challenge_signature`); others are listed as ignored.
* **A forged row naming a real key used up that key's one challenge**, locking the genuine holder out. Keys are now recorded only from validly signed rows. Both attacks have regression tests.
* **"The SDK sees a stored login" was inferred from source, now MEASURED** with the real SDK 2.14.0, sockets blocked: a login profile on disk (`ANTHROPIC_CONFIG_DIR`, `configs/default.json` +
  `credentials/default.json`) passes the offline check with no API key; so does `credentials=` with a provider. **New finding:** an `ANTHROPIC_CONFIG_DIR` with no profile makes the SDK *constructor itself*
  raise `CredentialsError`; the adapter already caught that, and its message now names the cause.
* **The tests that need the real libraries had never run.** In a scratch virtualenv with `anthropic` 2.14.0 and `cryptography`: the real-SDK ladder routed through the recording proxy (credentials forwarded, never
  logged), the pure-Python Ed25519 cross-checked against OpenSSL, the GPU-attestation policy tests and RS256 token tests all pass; 317 agent tests with 0 skipped once `cryptography` is present.

**Fourth pass:**
* **Separate PROCESSES** (real shims are processes, not threads) are never handed the same session id either: 16 subprocesses, 16 distinct ids, chain intact; permanent test.
* **`bounty challenge` without a reason crashed with a raw `TypeError`** (`None[:500]`), and a non-string reason did too. It is now a clear refusal; nothing is recorded by a refused attempt.
* **The registry wrote an event with a single `os.write`**, which may write less than asked and leave a torn event: it now finishes the line.
* **The real-SDK tests are repeatable:** `make test-real-sdk` (builds a throwaway virtualenv at `SDKVENV`, default `/tmp/guldo-sdk-venv`, installs `anthropic`, `cryptography`, `numpy`; runs 250 agent tests with the API key
  unset and none skipped). Run it before trusting any change to the adapter, proxy or signing.

Tests: `test_agent_gaps.py` 66 (the real-SDK tests skip without the SDK and pass under `make test-real-sdk`), 18 + 1 further mutants caught.

One existing test encoded the old free veto (`test_agent_extras.TestWitness`); it now states the new rule.

**What stays open, and why I cannot close it:** a real model run (needs your API key and your consent to spend: nothing here starts one), the recording proxy against a real provider, a witness who is not us, GPU
hardware, a payment provider. The forgery gap is closed only where a verifier runs the proxy or shim under a key the operator does not hold; that is a deployment fact, not a code change.

## Model providers: the adapter interface, and why there is more than one

The harness measures anything with `respond(system, tools, messages) -> {"text": str, "tool_calls": [{"name", "args"}], "usage": {"input_tokens", "output_tokens"} (optional)}` and an optional
`begin(instance_id, trial)`, `label`, `endpoint` and `served`. Everything above that (rounds, certificates, the power pass, bounties) is provider-neutral. Without a REAL-model adapter the whole
stack can only ever certify scripted stand-ins, which prove the pipeline and say nothing about any model. Three agent kinds exist (`agent_providers.make_agent`):

| spec | what | dependency | notes |
|---|---|---|---|
| `scripted:lean\|bare\|cheat\|gullible[:P]` | deterministic stand-ins | none | free; the pipeline, never a model |
| `anthropic:MODEL[:EFFORT]` | the official `anthropic` SDK | `pip install anthropic` (optional) | credentials from the SDK's own resolution; thinking blocks echoed back; no fallback; the recording proxy (`agent_proxy.py`) attests THIS format |
| `compat:MODEL` | any OpenAI-compatible Chat Completions server: OpenAI, vLLM, OpenRouter, LM Studio, llama.cpp, **Ollama (`/v1`), i.e. a LOCAL model that costs nothing** | none (standard library) | `compat:llama3.1:8b`, `compat:meta-llama/Llama-3.1-8B-Instruct` |

`compat` configuration is the OPERATOR's, by environment: `GULDO_COMPAT_BASE_URL` (else `OPENAI_BASE_URL`, else `https://api.openai.com/v1`) and `GULDO_COMPAT_API_KEY` (else `OPENAI_API_KEY`; optional for a
local server). A spec can name only a model, never a URL, so an entrant in a round cannot aim the operator's machine at an arbitrary address. The key is sent only as a bearer header, never stored (checked: a
whole ladder and round are searched for it in the tests), redacted from error messages BEFORE they are truncated, and REFUSED over plain http to a non-local host. The ladder header records `agent.provider`,
`agent.model` and `agent.endpoint` (host:port only). Rounds accept `compat:` entries (validated, allow-listed by model id like any other, spend-confirmed like any other real model).
Not sent unless you ask: sampling parameters. Handled, not crashed on: a truncated reply, a refusal or content filter (the trial ends as a failure with a note), tool arguments that are not valid JSON (the tool
rejects them and the model sees the error), a server that sends no usage numbers, content as a list of parts, `reasoning_content` (ignored: not in the trajectory or the proxy count).

Limits, all of them real. `compat` has been run against ONE real model on ONE real server: qwen2.5:3b (a 3-billion-parameter local model) through Ollama 0.35.1. It has NEVER been run against a vendor's
endpoint (OpenAI, OpenRouter, vLLM...) or a large model, and a hosted service may differ in details this does not know about (for instance `max_completion_tokens` on some OpenAI models: `max_tokens_param`).
The model must support tool calling; one that answers in prose makes every trial end as `no submit` unless nudged (below). A black-box vendor AGENT (its own loop, no tool-call visibility) does not fit this
interface at all; an outputs-only mode is NOT built (the design that would work: the EVALUATOR hosts the tools as a service and logs every call on its side; it is a project, not a flag).
To add a provider: write a class with `respond`, add its spec to `make_agent`, `rounds.validate_spec`, `agent_eval.make_header` and `agent_providers.is_real_model`, and copy `test_agent_compat.py`'s
fake-server tests.

**Attestation of `compat` runs works, on real traffic.** The recording proxy (`agent_proxy.py`) now recognises OpenAI Chat Completions exchanges as well as Anthropic ones, per exchange. It normalises a reply
with the SAME function the adapter used (`agent_providers.parse_chat_completion`), so what the adapter stored and what is re-derived from the signed bytes agree by construction, and it checks the Chat
Completions request shape (system prompt as message 0, one message per tool RESULT, nudges). Run it in front of the endpoint on a machine the verifier controls: `agent_proxy.py serve --key K --log L --upstream
http://127.0.0.1:11434 --port 18788` (the upstream is the ROOT; the agent's `/v1/...` path is appended), point `GULDO_COMPAT_BASE_URL` at `http://127.0.0.1:18788/v1`, then `agent_proxy.py verify LADDER L
--trusted PUBKEYS --practice|--seed F`. Done once for real (4 trials of qwen2.5:3b through the real proxy and the real Ollama: ATTESTED); an edited model tool call, an edited reply, a key the verifier did
not pin and a hand-written extra trial were each refused; the signed provider usage (1,038 tokens for the first trial) replaced the harness's proxy count (861).

**A whole round can be attested, and the certificate carries and re-checks it** (`agent_proxy.verify_round_http`, `agent_proxy.py verify-round ROUND LOG --trusted KEYS --base DIR`, `agent_cert.py build|verify
--proxy-log L --proxy-trusted KEYS`). Every arm (baseline and each entry) is matched against ONE proxy log: exchanges are consumed once across arms (a copy of one arm's ladder cannot vouch for another), a
leftover exchange is a stray (a hidden or discarded run), and the round must be revealed (the tools a request offered depend on the seed). A certificate that CLAIMS an attestation fails closed unless the
verifier supplies the proxy log and THEIR OWN pinned keys; a pasted-in attestation with a wrong log hash, count or arm list is caught. Done for real once (round 3 below): all 143 model calls of both arms matched.
Matching now also pins what the model was GIVEN: the request's system prompt (message 0 of a chat request, the `system` field of an Anthropic one) and its offered tool names must equal the ladder header's
(`system`, `allow_tools`), so an operator cannot misstate either (the Anthropic matcher did not check them before). The proxy found two more bugs of its own kind (below).

## The first real-model runs (27 November, qwen2.5:3b locally through Ollama: free, a 3B model, a PRACTICE-sized task: what they show and what they do not)

Two complete commit-reveal rounds (`agent_rounds.py`), secret seed, plan hash and commitment fixed first, baseline = the model with the default system prompt, entry = the same model with a "guided" system prompt
(use the one-call `aggregate` tool, always call `submit`), data-analysis domain, 2 nudges allowed. They found six real problems that no scripted agent and no fake server had:

1. **The adapter sent `content: null` for an empty assistant reply.** A strict server (Ollama) answers HTTP 400 and the trial died as `agent error`. 3 of the bare arm's 12 trials were killed by this BUG,
   not by the model: **the first comparison (guided 11/12 against bare 5/12) was biased against the bare arm and is not a result.** Fixed (`""` when there are no tool calls); a strict fake server now enforces
   the rule in the tests. The second round, with a fresh seed, had 0 agent errors in either arm.
2. **Agent errors were invisible.** The error text was not stored. It is now kept in the record (`agent_error`, informational), counted (`agent_error_trials`), and warned about in `compare`, in the
   certificate statement and by `verify` ("usually the operator's infrastructure, not the model, yet they count as failures").
3. **`urllib` followed redirects with the API key** (found by a test, before the real run): on a 301/302/303 it re-sent the request as a GET WITH the `Authorization` header to whatever origin the endpoint
   named, and the adapter then took that origin's answer for the model's. A 3xx is now an error, never followed (mutation-checked). The same pass bounded a hostile endpoint: reply size, NaN/Infinity,
   recursion bombs, tool calls per reply, reply text, usage numbers and the served-model record are all capped or sanity-checked; a read timeout (a plain `OSError` on Python 3.9) is retried, not leaked.
4. **The model writes `submit 50.04` in prose instead of calling the tool.** New, in the PLAN: `max_nudges` (default 0): a reply with no tool call is answered with one fixed reminder instead of ending the trial.
   The verifier understands it (a nudge the harness would not have sent, or a trajectory that ends with one still available, is flagged; differential fuzz: 1,500 honest random trials, 0 wrongly flagged) and so
   does the recording proxy. Both arms get the same allowance; it costs tokens like any turn.
5. **My tools were stricter than needed**: `column: null` for a count and `limit: null` for an optional value were rejected. Only those cases are loosened.
6. **Local servers can silently truncate a long prompt.** Not seen here (largest prompt 1,853 tokens), but `verify` now warns when the provider counted far fewer input tokens than the harness sent
   (ratio below 0.6; 1.0-2.0x was normal here).

**Round 2 (the valid one; practice-sized: 16 instances, 1 trial each, one 3B model, one task family).** Guided 16/16, bare 8/16 (exact sign test p = 0.0039, 8 candidate-only and 0 baseline-only); on the 8
instances both solved the guided configuration used 4.1x fewer proxy tokens (corrected one-sided 95% lower bound 2.0x); the bare arm used 13 nudges and a median 4,965 tokens a trial against 856. The round
verifies, and a certificate for it verifies on all 20 checks (`agent_cert.py`). **What it does NOT show:** anything about a larger model or a hosted one; that the prompt, rather than a luckier draw of
instances, is the whole difference beyond what the exact tests say; that a 16-instance practice result transfers to other task families; that tokens are billed tokens (the server's own counts were 1.2-1.7x the
proxy's); or that the operator did not edit the ladders (that run was NOT attested, because it ran in-process; the separate 4-trial proxy run was).

**Round 3: the same comparison, every model call through the recording proxy, a fresh secret seed.** Guided 14/16, bare 5/16 (sign p = 0.00195; 0 agent errors in either arm); on the 5 instances both solved
the guided configuration used 4.9x fewer proxy tokens (corrected lower bound 1.8x). **ATTESTED: all 143 model calls of both arms matched signed exchanges, none left over; the certificate embeds the attestation,
verifies, and is REJECTED by a verifier who is not given the proxy log and their own keys.** Round 2 and round 3 differ (16/16 vs 8/16, then 14/16 vs 5/16): a stochastic 3B model on different instances,
so neither number is "the" rate; the direction and the exact tests are what repeat. What attestation still does not prove: that the model the provider reported is the model that answered beyond the id it
returned; that the proxy machine was not the operator's (here I ran both roles, so this is a demonstration of the mechanism, not of an independent verifier); anything about a hosted vendor or a large model.

**Two more bugs of the same kinds, found by auditing the proxy and fixed (each with a test):** the PROXY also followed redirects with the credential headers (`urlopen`), sending the key to the redirect target and
returning that origin's reply to be SIGNED as the provider's: a signed receipt would have attested a stranger's answer (a 3xx is now passed through unfollowed); and an upstream HTTP error response was read but never
closed (a socket per failed upstream call in a long-running proxy). A missing round given to `verify-round` was a traceback; it is a message.

## The first runs against the live Anthropic API (27 November: claude-haiku-4-5 and claude-sonnet-5-5, PRACTICE seed, about $0.33 in total)

Run by this project with the account owner's key and an explicit $5 budget. Everything saved is in `agent_eval/real_runs_2026-11-27/anthropic_live/` (plans, ladders, the comparison, the proxy's signed log, the PUBLIC key, and the two
forgeries in a folder named as a negative control); the proxy's secret key and the API key were not saved anywhere. The practice seed is public, so these show the machinery and a method, not a certified number about any model.
`test_agent_gaps.TestLiveRunsReverify` re-verifies all of it from the files on every test run (no network, no key).

* **Pilot (1 trial, research size 1, haiku-4-5): solved in 4 tool calls, verified.** **Study (sizes 1-3, 3 instances each, 1 trial, cap 20,000 proxy tokens): haiku-4-5 9/9 and sonnet-5-5 9/9, both ladders verified from the seed, the
  comparison confirmed.** The project's verdict: same solve rate (sign p = 1); sonnet used 1.15x fewer proxy tokens on average but the one-sided 95% bound is 0.90x, so **"neither is shown cheaper"**: nine instances cannot rank two
  models and the rules refuse to claim otherwise. Billed: haiku $0.101 ($1/$5 per MTok), sonnet $0.163 ($2/$10): fewer proxy tokens did not mean less money.
* **Proxy tokens versus billed tokens, and a CORRECTION.** The provider billed about 2.2x the project's proxy count on every turn. I first explained that as "the system prompt and tool definitions are billed and not in the stored
  context": **that was wrong**, the proxy count already includes both (`agent_harness.context_tokens(system, tools, ...)`), and turn 0 (nothing but system, tools and task) shows the same ~2.2x (280 proxy against 804 billed). The data
  support a different account, and a usable model: over the 155 real calls, **billed input = 1.477 x proxy + 387 tokens per call for haiku (R^2 0.997, worst error 2.8%) and 1.589 x proxy + 251 for sonnet (R^2 0.985)**, i.e. the
  crude bytes/4 counter undercounts JSON-dense text, plus a fixed per-call overhead of about the size the API's own injected tool-use prompt would be (the cause of the intercept is inferred, not isolated: that would need the
  token-counting endpoint). Held out: the fit made WITHOUT one trial predicted that trial's billed input to +0.6%. Output is model-dependent (haiku 2.1x; sonnet 3.6x, which includes hidden thinking tokens).
  `agent_preflight` now estimates cost from this calibration (and labels any model it was not measured on as NOT calibrated, using the worst measured values), alongside a separate pessimistic bound. **Not calibrated:** other models,
  other domains, long contexts, prompt caching, retries. For the 9-trial haiku plan it estimates 0.40 "if every trial ran to its cap" against the 0.10 actually spent.
* **The recording proxy against the live API (listed here as never run): 4 real haiku trials through `agent_proxy.py`, 24 signed exchanges, exactly one per model call; the genuine ladder is ATTESTED.** Two forgeries were built from it.
  A CRUDE one (one assistant reply rewritten, turn chain recomputed) is caught by the ORDINARY verifier already ("recorded cost does not match": the token counts changed), so it shows little. A CAREFUL one (same rewrite, and every
  proxy token count, the total and the chain repaired) **passes ordinary ladder verification ("VERIFIED") and is rejected only by the proxy log**: "no unused exchange in the proxy log matches this turn", and the real exchange it
  replaced belongs to no recorded turn. I had claimed the first forgery was internally consistent; it was not, which is why the careful one was built. The credential appears in none of the 192 base64 fields of the log once decoded.
  **Caveat that matters:** the same party ran the proxy and the agent, so this shows the MECHANISM works against the real provider, not that an independent verifier was involved.
* **What a conclusive haiku-versus-sonnet comparison would take (computed from the saved pilot, no spend):** `agent_power.py pilot` says that to show sonnet uses at least 1.1x fewer tokens with 80% power takes about 64
  instances both agents solve: **66 instances (22 per size) x 1 trial x 2 agents = 132 trials**. Priced from the providers' own usage numbers in the pilot ladders (haiku $0.0112 and sonnet $0.0181 per trial) that is **about $1.93**.
  The tool's own estimate was $0.70, and the real figure is 2.8x that, ABOVE its stated 2.5x "high": proxy tokens are not billed tokens and it prices every arm at one price pair. `agent_power.budget` now also reports
  `usd_calibrated_mid`/`usd_calibrated_high` (x2.2 and x4.0 the proxy-token mid; here $1.53 to $2.78, which brackets $1.93) and says so; the old fields are unchanged. **Caveat on the 64:** the pilot's token counts are nearly
  deterministic per size (sd 0.03 bits over 9 instances, 0.04 conservative), which is what makes so few instances enough; trial-to-trial variation and larger sizes are unmeasured, and the tool itself warns that a 9-instance pilot is
  for sanity-checking a plan, not sizing it.
* **Audit of the above (next pass, offline):** every figure quoted here was recomputed from the saved files and matched; the README's five commands were run literally and behave as documented; and the money is now fully
  accounted for (`TestLiveRunsReverify.test_every_dollar_spent_is_accounted_for_by_a_saved_ladder`: $0.3306 over 24 trials in five ladders: the one-trial Sonnet pilot had only been in a temp folder and is now saved). Found and fixed:
  * **`agent_power.need_cost_uplift` returned the SECOND size of its confirmed pair**, up to one 8% search step above the first, so `plan` printed "power 0.97 at 66 instances (needs 71 for 80%)", a line that contradicted
    itself. It now returns the first size of the pair (65 for this plan: power 0.93 there, 0.97 at 66, 0.725 one step below). Regression tests; the old behaviour restored in a scratch copy is caught.
  * **Preflight's only money figures were "if every trial ran to its cap" ($9.91 for the planned study, above the $4.67 left) and a pessimistic bound**: honest, but neither is what a go/no-go needs, because trials stop far short of
    the cap (the pilot averaged about 3,700 proxy tokens against a 20,000 cap). `preflight --pilot-ladder LADDER` now reports the EXPECTED cost from the pilot's own provider usage numbers ($0.74 haiku + $1.19 sonnet = $1.93 for 66
    trials each; $2.70 if every trial cost what the dearest pilot trial did). A trial whose usage is missing on any turn is left out rather than summed from its remaining turns (which would understate it); a mutant that
    summed partial usage escaped my first tests and is now caught.
  * `agent_eval/planned_study_haiku_vs_sonnet/` holds the prepared (NOT run) 66-instance study: plan, pre-registered claim, the secret seed generated outside the repository, the cost figures and `RUN.md` with every step
    (regenerating the plan reproduces the same hash, checked).
* **Attack found by trying it, and closed: the usage numbers a ladder records could be falsified without detection.** Halving, zeroing or deleting the recorded provider `usage` on the real attested ladder still passed
  `agent_proxy verify` (ATTESTED), because the verifier matched content but never compared usage, even though the proxy log holds the provider's signed usage for every call. The attested token COUNTS (`convert`) were never at risk
  (they come from the log), but anything reading the ladder's own `usage` was: `agent_eval verify`'s "provider-reported / proxy" line, preflight's pilot cost, and the calibration in this document. `verify_http` now requires each
  turn's recorded usage to EQUAL the signed usage (24 of 24 equal on the genuine ladder; the local-model attested run and round still verify); all four tamperings (halved, output set to 1, deleted, inflated) are rejected on every
  turn. **Consequence for what I wrote earlier:** the calibration and the spend ledger rest on usage numbers this project recorded itself; only the 4 attested trials are cross-checked against signed values (they match). The
  others are my record, not independent evidence, and the text above now says so.
  No comparison, certificate, bounty or index rests on the ladder's usage (they use proxy tokens), but `agent_regulatory.py` tells readers that proxy receipts vouch the "token usage relayed unmodified": that sentence
  was untrue for the HTTP proxy path until this check existed, and is true now.
* **Real-API behaviour learned:** the SDK sends nothing without a credential and fails locally with a clear error; haiku-4-5 needs no `effort` or thinking setting from the adapter; an `sk-ant-usr-...` key was accepted; the per-turn
  `usage` the harness records is what makes the billed-versus-proxy comparison (and the calibration above) possible.
* **Not shown:** anything about a model on a hidden seed (every instance here can be derived by anyone); statistical separation of the two models; behaviour at larger sizes or other domains; an independent verifier; the coding
  domain (which runs the agent's code and needs a container).

## Black-box vendor agents and an independent verifier (27 November: built, tested, run ONCE by one person playing every role)

Full documents: **`BLACKBOX.md`** (the protocol and what it proves) and **`INDEPENDENT_VERIFIER.md`** (who must be trusted for what, a threat matrix, the protocol, a runbook). Evidence: `agent_eval/real_runs_2026-11-27/blackbox_independent/`.

**Black box.** A vendor's agent is a program we cannot see inside, so the evaluator hosts the *tools*: `agent_service.py` serves the task over HTTP (and MCP), holds the seed, enforces `max_tool_calls` and `max_wall_s`, records every call in a hash-chained transcript, signs each session, and returns a signed receipt per call (so the vendor can check the published transcript is exactly what it saw). `agent_blackbox.py` re-verifies a trial from the revealed seed: every tool call replayed, the answer re-verified, cost and counts recomputed, the service signature checked; `agent_vendor_example.py` is a stdlib-only reference vendor. Cost is **interaction tokens** (what crossed the tool service), never compared with proxy tokens; success can be compared across modes with a stated budget caveat. Journalled and restartable; one attempt per task; `serve-arm --exec` runs a vendor-supplied command (containerise first).

**Independent verifier.** Independence is a social fact that cryptography can make checkable. Built: `agent_joint.py` (N-party signed-commitment joint seed: no single party can steer or foresee the instances), `agent_registry.py` (the verifier's signed append-only register of every round it opens, closes or voids; registration also goes into the round's own chained log as the `registered` event, so "registered before it ran" is a chain position, not a clock), `agent_verifier.py` (`bundle`, `audit` with only the keys YOU pinned, `quorum` of K distinct verifiers). The audit checks the manifest, the whole round re-derived from the revealed seed, every black-box session's signature against your key, every certificate, the registry, the joint seed, how many other rounds the same configuration entered, and that the verifier's keys differ from every other party's.

**Run once** (qwen2.5:3b, 16 committed instances, a three-party joint seed, the tool service and the vendor as separate OS processes): the vendor-style agent solved 9/16 against the white-box baseline's 5/16, exact sign test p = 0.109, so the certificate says **"no difference in solve rate shown"**, cost not comparable, budgets not equal. The audit and the vendor's receipt check both pass. **One person played operator, verifier, vendor and auditor on one laptop: this shows the mechanism, not independence. No independent party has run a round.**

**Defects found by auditing the first build (all fixed, each with a test):** the vendor's receipt check did not verify the published transcript's own hash chain (an edit without re-chaining passed); a verifier record with a list as `role` crashed the checker (it never raises now); the index would have ranked black-box agents "cheapest" against white-box ones by different token units; the witness tool would have "rerun" a vendor's agent through our own harness; an NTP step backwards mid-session would have wedged the whole arm (per-session monotone clock); an unread request body on an early 401 could corrupt a keep-alive connection; and a late registration was only detectable by comparing two clocks the same party controls (now a chain position in the round's log).

**Tests:** `test_agent_blackbox` (47: session state machine, a sweep of more than 150 single-field forgeries, HTTP/MCP hostile requests, restart equivalence, a whole round with a black-box arm, `--exec` with a hung process killed) and `test_agent_independent` (32: joint seed, registry tamper tests, a full three-key scenario attacked layer by layer with the manifest rebuilt, quorum). **A documented limit with a test:** a key-holder can insert a made-up call that replays correctly and passes verification from the seed; only the vendor's receipts expose it.

**Added in a second pass the same day (each with tests; `ONBOARDING.md` is the runbook):** a real third-party MCP client check (official `mcp` SDK 2.3.0); TLS with certificate pinning and hostile-load limits; key rotation with a pre-committed next key; an evidence transparency log with witnesses, anchoring and an audit **timeline** (commitments ordered before registration and before a beacon round); a drand beacon bound into the joint seed, verified by a pure-Python BLS12-381 pairing (RFC 9380 vectors and real drand signatures); AWS Nitro attestation **verification** (three real AWS documents, `cryptography` as an oracle); and `agent_verifier.py init` / `selfcheck` for a prospective verifier.

**Still not done:** a real vendor; an independent verifier (a person or organisation other than the author); a TEE deployment that has ever run (`agent_nsm.py` is tested only against an emulated kernel interface; `agent_seal.py` has no test file; the enclave program and the two-phase binding do not exist) and any other TEE platform; a deployed public log with real witnesses and a Bitcoin-confirmed anchor; and every limit stated above.

## Running a real round

1. `python3 -c "import secrets; open('AGENT_ROUND.seed','w').write(secrets.token_hex(32))"`; `chmod 600`; keep it OUTSIDE any repository and backed up.
2. `python3 agent_eval.py checkdomain coding` (all PASS), then fix the plan and publish its hash BEFORE any entry:
   `python3 agent_eval.py plan --domain coding --n 20 --trials 3 --seed AGENT_ROUND.seed --out ROUND.plan.json`
3. Run each configuration against the SAME plan. For a real model, try ONE instance first (`--n 1` plan), then the full plan; a real run costs API money and needs `--confirm-api-spend`:
   `python3 agent_eval.py run --plan ROUND.plan.json --agent anthropic:MODEL --label bare --seed AGENT_ROUND.seed --out bare.jsonl --allow-tools run_tests`
   `python3 agent_eval.py run ... --label harnessed --system my_harness_prompt.txt --out harnessed.jsonl` (the "harness" is whatever differs: system prompt, allowed tools; both are recorded in the header).
   `--resume` continues an interrupted run from its `.part` file.
4. After the close, publish the seed, the plan, both ladders, and the comparison; anyone runs:
   `agent_eval.py verify bare.jsonl --seed S --plan ROUND.plan.json --plan-hash H`, then `compare ... --seed S --out claim.json`, `check`, and `claim --min-factor 3 --min-solve-rate 0.8`.

## Needs wiring (WAS "not done on purpose"; all of it except the last two items is DONE: see "Wiring" below)

* DONE: `Makefile` UNIT list and `static_check.py`'s default list now include the agent tests and modules (the round and certificate modules import `rounds.py`, which imports the pinned speed modules:
  read-only, but they must be importable where the tests run). `pip install anthropic` only where real-model runs happen.
* A real agent round needs: a seed kept off any machine the model's code runs on; the plan hash, the seed commitment and the log head published BEFORE entries, after close and after reveal.
* DONE: `build_package.py` TOOLS (`guldo agent` and ten more tool names) and `agent_domains/` packaged; checked by building a package and running them.
* DONE: the `README.md` row and the site card (`agent.html` in `build_site.py`). STILL NOT DONE: a transparency-log entry for a real round (there is no real round), `translog.py` leaf types (pinned; `agent_log.py`
  is the separate log), and the Anthropic adapter's first live run (needs the owner's key and consent to spend).
* The vision document's "what to build" A1-A6 are now built at pilot scale; see "Extras (added 11-27)" for the rest.

## Extras (added 11-27): the rest of the vision list, all NEW files, none run against a real model, GPU, payment provider or outside user

| item | file | status |
|---|---|---|
| A1 research domain | `agent_domains/research.py` | built; `checkdomain` all PASS (multi-hop through a document library, sizes 1-4) |
| A2 attested token count | `agent_attest.py`, `agent_sig.py` | built; signed receipts from a shim (pure-Python Ed25519, RFC 8032 vector + `cryptography` cross-check); verify, convert to attested units. Closes the forgery gap ONLY if the shim runs under a key the verifier holds, outside the operator's control. No real provider call went through it |
| A4 difficulty-stratified bound | `agent_strata.py` (also in `summarize`: `solve_rate_stratified_lower95`, `worst_size_lower95`; `claim --min-stratified-rate`) | built; Bonferroni over sizes, conservative by design |
| B1 independent witnesses | `agent_witness.py` | built; verify + sign, a witness's own random-sample rerun with an exact consistency test, dissent fails whoever signed; counts only keys you pin. Nobody has run one |
| B2 GPU tiers T2-T4 | `gpu_tiers.py` | verifier-side code only, tested on FIXTURES. Never touched a GPU or real `ncu`/attestation output: the ncu CSV parser and the attestation claim names (`POLICY_CLAIMS`, configurable) are the likely mismatches on first contact |
| B3 evaluation machine | (not built by me) | you said the Linux machine is set up; the lattice round is separate |
| B4 first outside user | (cannot be built) | needs a person; `WITNESS_OUTREACH.md` and the witness commands are what to hand them |
| C1 bounty/settlement | `agent_bounty.py` | built as a hash-chained escrow LEDGER with a machine-checked settlement condition (both ladders re-verified from the seed, comparison recomputed byte for byte, thresholds). MOVES NO MONEY: `ManualRail` prints what a human must do; no payment provider, KYC or legal review. Fiat only, no token |
| C2 orchestrator index | `agent_index.py` | built; refuses unverifiable ladders, excludes practice and scripted entries by default, `route` ranks by cheapest tokens among agents clearing a stated bound AT THAT SIZE |
| C3 safety domains | `agent_domains/injection.py`, `agent_domains/toyctf.py`, `agent_safety.py` | built: injection resistance (unsafe outcome counted apart from failure, exact upper bound) and an invented multi-step puzzle, plus a hash-chained dated register. Both are stand-ins for a property, NOT hazard measures. Bio/chem and persuasion domains are deliberately not built (reasons in `agent_safety.py`) |
| C4 regulatory packaging | `agent_regulatory.py` | evidence index, NOT a compliance assessment. Checked this session: EU AI Act Art. 55(1)(a), NIST AI RMF MEASURE 2.3, NIST AI 800-1 (draft). Art. 15 is from memory and labelled so; the Code of Practice and harmonised standards were not read |
| C5 insurer reports | `agent_insurer.py` | built; exact failure-rate upper bounds, expected loss only from caller-supplied assumptions |
| C6 progress tracker | `progress_tracker.py` | built; run on `certs/` (all PROVISIONAL, so no "best official"); hardness rows are BASELINE cost, not problem hardness |
| C7 the paper | `paper/guldo_protocol.tex` (5pp) | draft; no venue chosen; related work for AI evaluation NOT surveyed; says so |
| command line | `agent_tools.py` | `strata keygen attest-verify attest-convert witness-sign witness-check gpu-t2-* gpu-t3-parse gpu-t4-check bounty index safety insurer regulatory` |
| A2 (deployable form) | `agent_proxy.py` | an HTTP recording proxy the VERIFIER runs (`serve --key K --log L`; the official SDK honours `ANTHROPIC_BASE_URL`) and `verify LADDER LOG --trusted KEYS --seed S`. Matching is by CONTENT (response text and tool calls, first and last request message), not by a rebuilt request, because the SDK echoes opaque thinking blocks that are not in the stored trajectory. Tested end to end against a LOCAL fake upstream only, never the live API; streaming is refused |
| B4 kit | `OUTSIDE_VERIFIER.md` | the one-page procedure for a first outside verifier / witness; nobody has followed it yet |
| tests | `test_agent_extras.py` | Python 3.9 and 3.14 (tests needing `cryptography` skip on 3.9); safeguard mutations each caught (see the audit block below) |

Edits to files I made earlier: `agent_core.py` (DOMAIN_NAMES), `agent_providers.py` (scripted agents for the three new domains; style `gullible`), `agent_compare.py` (stratified fields, `claim_check`), `agent_eval.py` (`--min-stratified-rate`, one summary line). No pinned file (`rounds.CODE_FILES`/`COUNT_FILES`) was touched.

### Audit of the extras (11-27, by me, after building them) and what it changed

Method: a fuzz that damaged every verifier's inputs (receipts, statements, ledgers, registers, index files, certificates, tokens, ncu text; deleting, retyping or inflating one random field at a time),
adversarial reading of each rule, and safeguard mutations on a scratch copy. 114 distinct crash sites on damaged input became 0 (they were refusals by crash, not false accepts, but a verifier must say
"malformed"). Real defects found and fixed, each with a test in `TestAudit`/`TestProxy`:

1. **Unsafe actions in a trial that never submitted were not counted.** The harness only runs the domain verifier on a submit, so an agent that leaked and then ran out of budget ended as "no submit".
   `agent_safety.safety_summary(master=...)` now recomputes unsafe from the stored trajectory; without the seed the summary says in its note that such trials are invisible.
2. **The progress tracker promoted `COUNTED, PROVISIONAL` (and any unknown status) to official**, and trusted each certificate's own fields. Now only `OFFICIAL...` is official, exactly `COUNTED` is its own
   tier, everything else is provisional, and every certificate is recomputed with `certificate.verify`; a claim that fails recomputation is demoted whatever its status says. (Today the two `dlog`
   certificates in `certs/` fail the `rules` check because the pinned code hashes moved since they were made, so they are demoted; the `aiinfer` one recomputes cleanly. All three are PROVISIONAL either way.
   An earlier version of this note said all three failed; that was wrong and was caught by the second audit. Re-issue the two `dlog` certificates if they are meant to stand.)
3. **Bounty ledger:** `state()` replayed entries without checking the chain; a verdict line could be appended or overwritten without the computation having run; a spec could carry a requirement
   (`require_attested_by`) that nothing enforced; a refund could go to the sponsor while a filed claim had no verdict. Now: a broken chain is refused everywhere, a verdict is immutable and needs an existing claim,
   unknown spec fields are rejected, a refund waits for every filed claim's verdict, and `settle` (CLI) RE-RUNS the whole check at settlement time. The ledger is a hash chain, NOT a signature: whoever holds the
   file can rewrite all of it, so both parties should keep or publish the head hash (`bounty status` prints it).
4. **Reports on unverified ladders looked authoritative.** `insurer`, `regulatory`, `safety` now re-verify from the seed when given one, refuse a ladder that does not verify, and say in capitals when no seed was given.
   `regulatory` no longer takes `--attested/--witnesses` on the caller's word: attestation and witnesses are computed from receipt and statement files and pinned keys.
5. `attest-convert` verified nothing and could double-count a rerun's receipts; it now verifies first. Malformed `rerun`/`agree`/`verified` fields in signed statements read as DISSENT, not as silence.
   Index entries are validated (types, ranges, each lower bound equals the Clopper-Pearson bound of its own counts) and `Index.recheck` rebuilds an entry from its ladder. `require_shape` turns a damaged ladder into
   a refusal for every consumer. Found by the repo's own `static_check.py`: a leftover assignment onto a module in my own test.

Mutations (a deliberately broken copy must fail the tests): every one of the following was caught: usage check, witness dissent, challenge window, claim recomputation, register chain, stratified level, unsafe
check, pinned-key check (GPU T2 and receipts), nonce binding, practice exclusion, signature malleability, proxy body hashes, request-shape match, stray-exchange check, tool-call match, header-key forwarding,
last-message match, ledger chain in `state()`, verdict immutability, refund-waits-for-verdicts, tier promotion, `n_per_size` bound, witness `verified is True`.

**Second audit (11-27, same day, "audit it all" again),** aimed at what the first pass had not tested empirically:

* Statistics, checked independently: Clopper-Pearson is exact for every k at n in {1, 2, 5, 20, 60, 200} (the defining tail equals 0.05 to 1e-9); simulated coverage of the single-stratum bound
  is 3.7% misses (allowed 5%); the Bonferroni stratified bound missed 0% in every configuration tried (valid, and very conservative, as documented); the exact sign test matches brute-force binomial sums.
* Domains at scale: lean scripted agents solved 560 of 560 instances of research, injection and toyctf across all sizes (no unsolvable instance, no truncated search, no canary or flag in any public
  view), and all six domains derive BYTE-IDENTICAL instances on Python 3.9 and 3.14 (one hash over 1,000+ instances matched on both).
* Real flaws found: (1) `agent_sig.verify` accepted small-order public keys: with the identity point as the key, (R = identity, S = 0) verified for EVERY message, so anyone could forge a witness or
  receipt statement that carries its own key. Found and fixed by the other session working in this directory; I added the regression test (`test_small_order_keys_cannot_forge_statements`). I missed it.
  (2) The recording proxy appended the client's request path to the upstream URL, so a crafted path could aim the request, and the forwarded API key, at another host; it now forwards only `/v1/...`
  paths free of `@`, `..`, backslashes, spaces and `//` (an exploit attempt in the form I tried got a 502, so I cannot show it was exploitable, but the construction was unsafe).
  (2b) Also found and fixed by the other session: a bounty bound to nothing could be won AFTER the seed was revealed by an agent that simply re-derives the answers (the whole point of commit-reveal).
  A real bounty now names the agent round (`round_id`) and a claim passes only if both ladders were recorded in that round's hash-chained log BEFORE its reveal, by the configuration's entrant;
  unbound bounties need an explicit `allow_unbound_ladders` (demos). I missed this too; `test_a_real_bounty_must_name_a_round` pins the default.
  (3) My own documentation was wrong in one place: it said every certificate in `certs/` fails recomputation (only the two `dlog` ones do; corrected above).
* Limits now stated in the code: the bounty ledger cannot authenticate who a claimant is (published ladders can be copied, so settlement instructions tell the human to confirm identity out of band);
  the witness rerun test treats trials as independent (simulated honest-witness flag rate 1.0% against a nominal 1% in one setting).
* Paper numbers re-derived after the other session's harness changes: unchanged (2.21x with lower bound 2.10x on research, 5.14x with 4.96x on toyctf; pooled solve-rate lower bound 0.883 against a
  worst-size bound of 0.482 on research).

**Third audit (11-27, "audit it all and overcome limits if you can").** Limits I could overcome, and how; each is tested. Mutation-checked on a scratch copy (a deliberately broken copy must fail the tests): signed heads, signed claims and payee pinning, the vendor-verdict
claims, and the signing-backend switch (9 of 10 caught at once; the tenth, the head's "kind" check, was a weak test and was fixed). NOT mutation-checked: the round-head pin, the certificate checks, the
round-mirror checks, the SDK test, the regulatory rows. Those were tested only individually, and the FULL suite was not run on both Pythons after the last edits (the run was stopped at the user's request).

* *"Signing is not constant-time"* -> `agent_sig.sign` and `public_key` now use the `cryptography` package (OpenSSL, constant-time) when installed and fall back to pure Python only when it is not; `backend()` says
  which, `keygen` prints it, both backends give identical bytes (tested), and `GULDO_PURE_ED25519=1` forces the fallback. Verification stays pure Python (nothing secret). Still NOT constant-time without the package.
* *"A hash chain is not a signature"* -> SIGNED HEADS (`agent_sig.sign_head/check_head`, `bounty` and safety-register wrappers, CLI `head-sign` / `head-check`): "at length n the chain's head was H, signed by K".
  A holder of such a statement detects any later rewrite, even one with every hash repaired (tested), and truncation. It is a detection tool for people who KEEP the statement: someone must.
* *"The ledger cannot authenticate who a claimant is"* -> optional SIGNED CLAIMS: a bounty may set `require_signed_claims` and pin `payee_pubkeys` (out of band, e.g. from the entry form); a claim then carries an
  Ed25519 signature over its own contents, a thief's valid signature is refused, a ledger holder who rewrites the claimant name cannot redirect the money (the signature covers the name; tested), and settlement records the key paid.
* *"The proxy was only tested against my own fake client"* -> the repo's real `AnthropicAgent` over the real SDK (anthropic 2.14.0, in a scratch virtualenv: `pip install anthropic`) now runs a ladder through the
  recording proxy to a local fake provider and `verify_http` accepts it (`TestProxyWithTheRealSdk`; skipped when the SDK is absent). The SDK sends credentials as `Authorization`, which the proxy forwards and never logs.
  (Never the live API at the time; since run, see "The first runs against the live Anthropic API".)
* *"GPU / attestation claim names unconfirmed"* -> CHECKED against NVIDIA's attestation documentation (docs.nvidia.com/attestation, GPU claims): `measres` is "success"/"fail", `secboot` boolean, `dbgstat` "enabled"/"disabled",
  `eat_nonce`, `hwmodel`, driver and vbios strings. The T4 check now also requires the vendor verifier's own verdicts (`x-nvidia-overall-att-result`, `...report-nonce-match`, and the driver-RIM, vbios-RIM and report
  signature-verified booleans) unless a caller explicitly sets `require_vendor_verdict: false`. The `ncu --csv --page raw` layout is NOT documented precisely enough to confirm (NVIDIA says only that each metric is a
  three-column row with name, unit and value), so `parse_ncu_csv` stays tolerant and unverified against real output. Still never on a real token or real ncu output.
* *"Regulatory items cited from memory / unread"* -> read now: EU AI Act Art. 15 (high-risk systems ONLY; appropriate accuracy and robustness, accuracy levels and metrics declared in the instructions of use),
  NIST AI 800-1 (still a second public draft: January 2025, comments closed March 2025), and the GPAI Code of Practice (final 10 July 2025, voluntary; its Safety and Security chapter expects state-of-the-art model
  evaluations with recorded inputs and outputs). `agent_regulatory.py` has a new row for the Code and its caveats say the Code is known from the Commission's page and summaries, not its text.
* *"Paper has no AI-evaluation related work"* -> checked LiveCodeBench, SWE-bench and SWE-bench Verified, Miller's "Adding Error Bars to Evals", MLPerf Inference against their own pages or abstracts and wrote a
  related-work section that says only what they say and what differs (the paper was 6 pages then; it is 7 after the real-run paragraphs). A sample, not a survey.

Audit of the OTHER session's modules (agent_rounds, agent_cert, the bounty round binding), by damage-fuzzing and adversarial reading; fixes are small and tested in `TestRoundsAudit` and `TestRoundHeadPin`:

1. `agent_rounds.verify_round` raised on damaged files in 15 places (its contract is a list of problems); it now never raises. It also accepted EDITED copies of facts the log had committed (`closes_at`,
   `max_entries`, `allowed_models`, the baseline, `created`, each entry's `entered` time, handle and id): 17 of 250 mutations passed silently (16 substantive, 1 a JSON-identical rewrite; 1 harmless one remains). Every mirrored field must now equal the committed one.
2. `agent_cert.verify_certificate` passed when the displayed candidate and baseline `config` (agent spec, SYSTEM PROMPT, tool list, label) or the whole `not_shown` list of caveats was edited or DELETED, and
   when the handle or log length was changed: 51 of 800 mutations passed (48 substantive, 3 JSON-identical no-ops, which still pass). A certificate could be made to name a different agent or have its limits removed and still verify. Now checked: the limits are the
   standard ones, the candidate config hashes to the certified value, each config equals what its ladder header says it ran with, the log length is the head's position, the handle is the logged one. Crashes 7 -> 0.
3. The bounty's round binding (which stops an agent that re-derives the answers AFTER the reveal from winning) called `verify_round` with no published head, so whoever holds the round's files could rewrite the
   whole log and back-date a "pre-reveal" entry for a ladder built afterwards; the chain is self-consistent after such a rewrite. A bounty on a round must now pin `round_head` (the head the operator published),
   or explicitly set `allow_unpinned_round_head`; practice bounties are exempt but say so in capitals. A test performs the rewrite: the chain verifies, no pin cannot tell, the pin catches it.
   (The other session's `test_agent_bounty_audit` had one fixture post a real bounty with no head; I added one to it.)

What the audit still does NOT cover: any real model's behaviour (the three recorded local-model runs were checked from their files only, and re-checked after their files changed on disk: the valid rounds verify, the first certificate passes all 20 checks, both attested runs verify, the second certificate verifies with its proxy log and fails without it, and the biased first attempt correctly fails; I did not reproduce the runs), GPU, `ncu` output, attestation token or payment provider; independent cryptographic review of `agent_sig.py` (the RFC 8032 vector, agreement with the
`cryptography` package, and small-order-key refusal are tested; the pure-Python fallback is not constant-time and says so); legal review of anything in `agent_regulatory.py` or `agent_bounty.py`;
`agent_power.py` (its 28 tests pass; I did not review or fuzz its statistics); the rest of the other session's `agent_rounds`/`agent_cert` beyond the three items above; the coding domain's sandbox
(still not a security sandbox; a container is needed and Docker is not used on this laptop); and the contamination limit that the task generators are public (commitment hides the judged instances, not the family).

STILL NOT DONE (needs something I cannot supply): a real HOSTED-model run (SINCE DONE on the public practice seed only, see "The first runs against the live Anthropic API"; one judged on a SECRET seed is still not done; a hosted run needs your API key and consent to spend: it is never started without `--confirm-api-spend`), a real
proxy/shim deployment under a verifier's key, a witness who is not us, GPU hardware, a payment provider, the evaluation-machine round, bio/chem and persuasion domains (deliberately not built). Wiring is DONE as of
this audit: `Makefile` UNIT, `static_check.py`, `build_package.py` (tools `agent`, `agent-tools`, `agent-proxy`, `progress`; `agent_domains/` and two docs packaged; checked by building the package and running
`agent selftest` and `agent domains` from it), README row. Not done at that point: a site card, a transparency-log entry (there is no real round plan to log), and a PyPI release. The first two are built in the next section.

### Sixth batch (11-27): sealed generators, bugfix, witness rerun, signed round heads, the agent log, power-checked plans, the site card

All new files or small edits to files named below; tests in `test_agent_next.py` (wired into the Makefile and `static_check.py`); each safeguard mutation-checked on a scratch copy (results below).

* **Sealed generators** (`agent_core.Style`, `research:sealed`, `injection:sealed`, `toyctf:sealed`, `bugfix:sealed`). The generators are public, so a lab can train on the family; commit-reveal hides only the
  judged instances. A sealed domain keeps the public generator but draws its SURFACE parameters (vocabulary pools, names, notice wordings, attacker address formats, numeric ranges, flag prefixes, function names) from
  `HMAC(master seed, "agent-style|domain|version")`: secret until the reveal and already committed, with no extra machinery. It is selected by the domain NAME in the plan, so every call site is unchanged.
  Canonical instances are byte-for-byte what they were (a pinned hash over 3 domains x every size x 30 instances guards that). Surface entropy per round (`agent_core.sealed_entropy_bits`): research about 282
  bits, toyctf 78, injection 47.5, bugfix 115 (function names, ledger account names, and value, window and clamp ranges). **It does not change the SKILL tested** (following links, decoding a shift,
  resisting an injected instruction, locating a bug): a model trained on that skill generally still gains. It narrows memorisation of surface forms and fixed vocabularies, nothing more; injection's 47.5 bits
  is a modest seal, and bugfix's templates, bug catalog and the way a bug is injected are the public generator's, so the 115 bits overstate how much a bug-fixing model that learned the catalog would have to
  guess. (The bugfix seal was first names only, 98 bits, then deepened with parameter ranges; canonical bugfix instances were verified unchanged by a hash before and after.)
* **`bugfix` domain** (`agent_domains/bugfix.py`, sizes 1..4 = number of injected bugs). A generated multi-module package (size + 3 functions from 7 templates), bugs drawn from a catalog and checked at derive
  time to CHANGE BEHAVIOUR (no equivalent mutants) and to be exposed by at least one public example, so every instance is solvable from what the agent can see. Tools: `list_files`, `read_file`, `run_tests`
  (public examples, one line per failing function so none is ever hidden), `edit_file` (exact text replacement, `occurrence` to disambiguate). The judge REPLAYS the recorded edits on a fresh copy and runs 25
  HIDDEN tests per function in a resource-limited child process; a function replaced by a table of the public examples passes everything the agent can see and fails the judge (tested). It runs agent-written code:
  `RUNS_CODE = True` (also set on `coding`), and `agent_core.runs_code` now drives the "--accept-unsandboxed-code" gate in `agent_eval.py` and `agent_rounds.py` and the witness rerun, instead of a hard-coded
  "coding". Still NOT a security sandbox. Scripted stand-ins solved 640 of 640 instances (lean and bare, plain and sealed); a first version failed some because `run_tests` truncated its output and because edits in one
  file were applied front to back (both fixed, both found by running it).
* **Witness rerun** (`agent_tools.py witness-rerun`, `agent_witness.witness_rerun`): verify the ladder, DRAW your own secret sample of M instances, run the agent on them yourself with the ladder's own system prompt,
  tools and caps, test your pass count against the operator's recorded rate, sign the lot. A real model needs `--confirm-api-spend`; a code-running domain needs `--accept-unsandboxed-code`. A rerun far below the
  operator's rate is signed as dissent. Tested with scripted agents only; no real model has been rerun by anyone.
* **Signed round heads** (`agent_rounds.sign_round_head / check_round_head / publish_head`, CLI `--sign-key --publish-dir`, `head-check`; first named `--head-key`, which Python 3.9's argparse treated as an ambiguous prefix of the existing `verify --head` flag: found only by the full run on 3.9): after create, close, evaluate and reveal the operator's key signs "at length n
  the head was H"; any later rewrite of the round's log, even a self-consistent one, is caught by anyone holding a head (a test performs the rewrite). Reading the unreadable-log case found a crash that is now a refusal.
* **The agent log** (`agent_log.py`; `translog.py` is pinned and strict about leaf kinds, so I did NOT add a leaf type there and instead built a separate log on its tested RFC 9162 primitives, imported read-only).
  Admits a certificate only if every `agent_cert.verify_certificate` check passes against its round; inclusion proofs verified offline against a signed checkpoint; `check --remember` proves the log only grew
  since the head you kept (a consistency proof); witnesses you pinned co-sign heads, and a witness refuses to sign a log that no longer contains the head it saw. It is as strong as the people who keep heads and
  pin witness keys, which today is nobody: it has logged nothing real. Absence from it means "not submitted".
* **Power-checked planning** (`agent_eval.py plan --assume-p-cand ... --solve-claim ... --require-power`; `agent_power.plan_report`): the plan reports its power for each claim you name (and what each needs) and can
  refuse to be written when underpowered (0.12 power at 20 instances for "lower bound >= 0.8 from a true rate of 0.9", which needs 94). The assumptions are your guesses.
* **Site card** (`agent_site.py`): one static, script-free, deterministic page generated from the live domain registry (a test checks it loads and links nothing, escapes every string, and that its claims follow the
  counts it was given: it says "no result on this page is a measurement of any model" only while real model runs = 0). It was first kept out of `build_site.py`; it is now WIRED IN (see "Wiring" below).

Audit of this batch (damage-fuzz of the new verifiers, then the mutation run): `agent_log` had crash sites on damaged inputs (a certificate with a bad round id, an unreadable `log.json`, a checkpoint row that is
not an object, a proof with no format) and now refuses with `LogError`; the damage test itself found one more (`check_cosigs` on a malformed checkpoint). The mutation run found two TEST gaps, now closed: nothing
proved `bugfix.verify` judges on the hidden tests rather than the public ones, and nothing proved a proof's checkpoint SIGNATURE is checked independently of its Merkle path. Mutation results for the sixth batch: 20 mutants of the
sealed core, bugfix, witness, round-head, log, power, site and CLI safeguards; 17 were caught at once; the other 3 were the two test gaps above and one INVALID mutant (its anchor matched a docstring, not the code);
after the fixes and a corrected anchor all 20 were caught.

### Seventh batch (11-27): the container sandbox, a log self-check, a deeper bugfix seal

* **Container sandbox** (`agent_sandbox.py`; `GULDO_SANDBOX=docker`). Until now "runs agent-written code, not a sandbox" was a stated limit with nothing to do about it. Both code-running domains (`coding`,
  `bugfix`) now go through one function that runs the same child either locally (unchanged) or in `docker run --network none --read-only --cap-drop ALL --security-opt no-new-privileges --user 65534
  --memory 768m --pids-limit 64 --cpus 1`, a small noexec tmpfs, and ONLY the generated package mounted read-only: the seed file and the home directory are not there. A SandboxError (no docker, no daemon, a
  failed start) is an error, never a verdict: a correct fix must not score as a failure because Docker is down (tested), and every real run does a PREFLIGHT first. A container run also counts as isolating the
  seed for the `--accept-unsandboxed-code` gate in `agent_eval.py run`, `agent_rounds.py evaluate` and `witness-rerun`. A timed-out container is killed BY NAME (killing the CLI would not stop it).
  `python3 agent_sandbox.py selftest` is a hostile probe (network, filesystem, home, /etc, a named secret path, environment, a fork bomb, a 2.5 GB allocation) run through whichever backend is active.
  **What is and is not shown.** The command construction, preflight, failure handling, timeout kill and gate are tested (15 tests, both Pythons) against a FAKE docker executable. **None of it has run against a real
  Docker daemon**, and Docker is not used on the laptop, so the real selftest has never been run by anyone: `make agent-sandbox-check SECRET=/path/to/seed` on the Linux server is the first real test. I ran the
  probe once in LOCAL mode, as evidence that local mode is not a sandbox: 7 of 9 hostile actions were allowed (it connected out to 1.1.1.1:53, listed the home directory, read /etc/passwd, forked 200 children,
  allocated 2.5 GB, saw the environment, and wrote into the package directory; only a write to / and a hidden secret path failed). A container shares the host kernel: stronger than local mode, weaker than a VM.
* **`agent_log.check` now rebuilds each entry from its stored certificate** and compares: an entry edited after the last signed checkpoint (which no signature yet covers) was previously unnoticed (found by
  reading the checker, tested, mutation-checked).
* **Deeper bugfix seal:** parameter ranges, window sizes, clamp bounds, value ranges and the ledger's account names are sealed as well as the function names (98 -> 115 bits). Canonical bugfix instances were
  hashed before and after and are identical; the scripted agents solve all 240 sealed instances of the new generator. The templates and the bug catalog remain public: say so whenever the number is quoted.
* **Make targets:** `make agent-card` (a standalone copy of the site card) and `make agent-sandbox-check` (server only).

### Wiring (11-27, the item that had been left undone on purpose)

* **The site.** `build_site.py` lists a new page `agent.html` ("Agents" in every page's nav), builds it with `page_agent()` from `agent_site.site_body()` (the live domain registry, the card's honest status and
  scope sentences, the limits, and the copy-able commands in the site's own `cmd()` markup), and adds it to the sitemap through the existing page list. The page reads "Real model runs: 0 ... No result on this
  page is a measurement of any model", and says the log's code exists and none is running: `agent_site.py` takes the counts and its sentences follow them, so they must be changed when (and only when) the things
  happen. The first draft of that card said "and a public log" among what exists: wrong (the code exists, no log does), found on re-reading and fixed. The phone layout of the longer nav has NEVER BEEN SEEN (no browser was used), but the static argument that
  it cannot overflow is now pinned by a test: the stylesheet makes the nav and header wrap (`flex-wrap:wrap`), puts tables in a horizontally scrolling container, and wraps long commands (`white-space:pre-wrap;
  overflow-wrap:anywhere`), and the card uses all three and contains no `<pre>` or fixed-width inline style (5 mutants of those rules and that markup all fail the test). That shows it should not run off the
  screen; it does not show it looks good. `test_site`, `test_site_ai`, `test_site_schedule` (100 tests) pass with the new page.
* **The commands on the site are checked.** `test_docs_commands` only judged commands of modules it knew, so commands of the agent tools would have been silently skipped (a vacuous pass); it now knows
  `agent_eval`, `agent_tools`, `agent_log`, `agent_sandbox`, `agent_proxy`, `agent_site`, `agent_power`, `agent_rounds`, `agent_cert`, `progress_tracker`, and `test_agent_next` pins that each command on the
  card comes back valid and that broken ones come back as errors.
* **`build_package.py`** now has tool entries `agent-power`, `agent-rounds`, `agent-cert` as well as `agent`, `agent-tools`, `agent-log`, `agent-site`, `agent-sandbox`, `agent-proxy`, `progress`; all were run from a
  freshly built package. Still not done: the PyPI release itself (it publishes, and needs the owner's sign-off), and `translog.py` leaf types (pinned; `agent_log.py` is the separate log instead).
* Mutation check of the wiring: 6 mutants (page dropped from the nav, from the page dict, a non-zero status, the doc-command module list regressed, the "none is running" sentence, unescaped default command
  rendering): all caught; one survived at first and exposed that the default command renderer's escaping was never tested with hostile input (now tested).

### Audit after the wiring (11-27): my own claims had gone stale

* **I had been saying "no real model has ever been run" for hours after another session ran one.** `agent_eval/real_runs_2026-11-27/` holds a local 3B model's runs (documented in "The first real-model runs"
  above). My statements that said otherwise were wrong: the README row, `OUTSIDE_VERIFIER.md`, the paper (abstract, the "never run" list, the missing-evidence paragraph), three sentences in this file, and, worst,
  the site card, which was PUBLISHED-to-be showing "Real model runs: 0". I checked the evidence rather than trusting its README: the round verifies, its certificate passes all 20 checks (including the stricter
  ones added this session, run for the first time on a real certificate), the attested proxy run verifies, and the biased first attempt correctly FAILS verification (it was made with an older harness).
  All corrected to say exactly what exists: one small local model, one domain, an operator-run (not attested) 16-instance round plus one attested practice run; nothing hosted, larger or on the Anthropic API.
* **The card now reads `agent_status.json`** (the committed real counts, validated on load, packaged with the tool), and a test ties it to the evidence directory: it fails if the file says zero while evidence
  exists, claims runs with no evidence, or claims a witness, an official round or a logged certificate (none has ever happened; each would need its own evidence check before the test lets it be nonzero).
  7 mutants of that tie all fail the test. The library functions still default to zeros; only the site build and the card's command line read the file.
* **Lesson, stated so it is not repeated:** my docs recorded "what has never been done" as static text. Facts that other work can change belong in a checked file with a test, not in prose.
* **Not touched in this pass:** nothing was deployed, released or published; the site was not rebuilt for deployment.

### Audit of those fixes (11-27, same day): the fix itself went stale within the hour

* **The status file I had just written was already wrong.** It said 2 runs; the other session had added a third (`round3_attested/`: every model call of a 16-instance round through the recording proxy) after I
  read the directory. My first evidence test only checked "evidence exists, status is positive", so it could not notice. It now demands an EXACT match (one recorded run = one sub-directory that holds a round or a
  ladder, excluding those named BIASED/INVALID/NOT_A_RESULT) and failed on the stale file with the right message; checked in four scenarios (a fourth run appears: fails; a BIASED one appears: ignored; evidence
  removed: fails; baseline: passes). The status is now 3, with a note; Round 3 was verified by me from its files, not from its README: the proxy log's 143 exchanges equal the 143 assistant turns across both arms,
  `verify-round` says ATTESTED with none left over, the certificate verifies with the proxy log and FAILS without it (it refuses to claim an attestation it cannot check), and the pass counts are 5/16 and 14/16.
  The paper, README row and `OUTSIDE_VERIFIER.md` were updated to the three runs and to the caveat the evidence carries itself: one person ran both the proxy and the operator, so it shows the mechanism and
  is not an independent verifier.
* **My own too-long note was refused by the validator I wrote** (663 characters against a 600 limit) and the site build failed on it, as designed; the note was shortened rather than the limit loosened.
* **The card's "Official rounds: 0" read as contradicting two real rounds.** It now says "Official rounds (run on the separate verified evaluation machine)", the only sense in which it is zero.
* **A real bug found by trying the evidence against my own tools: the agent log could not admit an attested certificate.** `agent_log.admit` called the certificate check without the proxy log or keys, so every
  certificate that claims an attestation (round 3) was refused with "the claimed attestation is re-checked": the log could hold only the WEAKER kind. My tests never saw it because no test certificate was
  attested. Fixed: `admit(..., proxy_log=, proxy_trusted=)` / `agent_log.py add --proxy-log --proxy-trusted` re-attest the whole round against the keys the LOG'S OPERATOR pinned; an attestation-claiming
  certificate without them is refused (never logged as if unattested), a proxy log given for a certificate that claims none is refused (never implying an attestation), the entry records `attested` and the proxy
  keys and log hash (derived from the certificate, so `check` still rebuilds it), and a copy of the proxy log is kept in `proxy_logs/` named by its hash. Tests use the real round-3 files (5 tests); restoring the
  original bug is caught. What is still not done: the log holds no real entry (none has been admitted into a log anyone runs).
* **Outside-witness kit built (optional, 11-27), `agent_witness_kit.py`, no witness exists yet.** Question asked: do we have to have one? No; it only changes how much weight an outside reader can give. Finding that motivated the
  design: the existing `witness-sign` only says "this ladder verifies"; nothing outside the operator anchored that the plan hash existed BEFORE a run (rounds 2 and 3 were never announced to anyone, so no witness can
  retrofit that). So the kit has four commands: `announce` (before any entry; refused after), `build` (self-contained kit; allow-listed round files, refuses unrevealed rounds), `witness` (the outsider's one command: verifies
  the round, binds every ladder statement to the plan hash in THEIR copy of the announcement, checks their receipt time precedes the first entry, signs; failure = signed dissent; optional `--rerun N`), and `check`
  (anyone; recomputes the round, every ladder digest and the time ordering; trusts none of the bundle's flags). Tested on the real round-3 files with the witness step in a clean subprocess inside the kit (Python 3.9 as
  the system default works): 18 tests, and 13 mutations of the safeguards all killed (3 survived the first test set because my tampered-ladder test was caught by the witness's own dissent first; fixed with tests
  that isolate the reader's re-verification, bundle coverage and the per-ladder plan-hash binding). NOT done: no real person has run it, the pre-announcement channel is not automated (you send the message), and the
  receipt time is the witness's word, checked for consistency against the operator's log, not against a trusted clock. To use it for real, announce BEFORE the next round runs.
* **Audit of the witness kit (same day), four real defects, all fixed and tested; 24 tests, 18 mutations of the safeguards all killed.**
  1. **Python 3.9 rejected `check` with statement files after the options** (argparse: "unrecognized arguments"; 3.12+ accepts it). My first run showed 7 failures on 3.9 only; an outside reader on an older Python
     would have hit it. Leftover arguments are now collected by hand (a leftover that looks like an option is still an error).
  2. **`--rerun` killed the whole witness process after the first ladder, exit code 0, no bundle written** (`agent_tools.main()` ends with `sys.exit`). A witness would have believed they were done. It now calls
     `run()`, treats any exit as a failed rerun, and refuses to sign a bundle over a rerun that wrote no statement (tested with a real-model spec and no `--confirm-api-spend`: refused before any network call).
  3. **A rewritten round log could be swapped in after a witness looked** (the log's timestamps are the operator's): the bundle now carries the log's final chain hash and `check` requires it to match.
  4. **The kit shipped the operator's own copy of the signing program, which the round's pinned-hash check does not cover** (CORRECTED on a later read-only audit: a REVEALED round checks only the plan's four `source_hashes`, `agent_core.py`, `agent_harness.py` and the domain files, so tampering with those is caught (tested with `agent_harness.py`), but NOT tampering with `agent_eval.py`, `agent_rounds.py`, `agent_compare.py` or the signing program; the seven files pinned in log entry 0 are enforced only while a round is open or closed, and four of them already differ from today's code, which does not matter for the revealed real rounds). The kit README
     now tells the witness to run the PUBLIC copy of the tool against the kit's data (tested to work), and a format-string slip I made while writing that README is covered by a test.
  5. **Three small defects from a later read-only audit, fixed with tests (27 tests; every one of the 6 new safeguards mutation-killed, one only after its test was strengthened, because the skip message
     printed even when the rerun still ran).** (a) An announcement file that was not a JSON object (a list, a string, `null`) with `--rerun` was a traceback; it is now a signed dissent, the rerun is SKIPPED (a witness
     should not pay for a rerun of a round that already is not witnessed) and the error handler also covers wrongly-shaped input. (b) A `build` that failed part-way (or whose proxy-log path was a typo) left a
     half-made kit directory that the retry then refused; inputs are checked before anything is created and any failure removes what was made. (c) The kit now carries `KIT_MANIFEST.sha256` (every tool file's hash, in
     `shasum -a 256 -c` format) so a witness can compare the operator's tool files with the public package's; the README says so. It is a comparison aid, not a proof: it is only as good as the copy of the
     public package the witness compares against. The kit still carries whatever the import closure of `agent_tools` pulls in at build time, including the other session's `agent_blackbox.py` and `agent_preflight.py`,
     which I have not audited; the manifest at least makes that visible.
  6. **Second audit of those fixes (same day).** (a) The fifth run set the status file now counts, `blackbox_independent/`, was verified by me from its files (the auditor's command passes, the vendor's receipts match, 5/16
     and 9/16 as stated, no key or secret anywhere in the folder). (b) The kit had only ever been run on a plain white-box round; it now has tests on that black-box round (white-box baseline + vendor entry): it needs no
     `bb/` journal folder, a reader accepts it, `--rerun` reruns the baseline and says why the vendor arm is not rerun. (c) The other session's black-box branch inside `witness_round` worked only because a second `if`
     fell through to the `else`; it is now one explicit chain (`do_rerun`, then a note, then the plain statement). Mutation-checking it found a real gap: **a ladder that failed verification could still be rerun, which
     with a hosted model costs money**; the existing tests never combined a tampered ladder with `--rerun`. It is covered now (31 tests, py3.14 and 3.9; all 11 mutations of this audit killed). (d) The modules the kit carries
     from the other session (`agent_blackbox.py`, `agent_preflight.py`), and every other module in its import closure (38), were statically scanned for what runs at IMPORT time, the moment a witness's machine would
     execute them: no network, subprocess, eval or exec; no top-level statement other than definitions, imports, constants and `__main__` guards, except `families.py` calling `declared.load_all`, which reads a `domains/`
     folder the kit does not ship. The server (`agent_service.py`) and the vendor example are NOT in the kit. This is a scan of what happens on import, not a review of those modules' logic.
  7. **Four builds from "what else do we need to build?" (11-27).** None deployed, nothing sent, no API spend; every safeguard mutation-checked (round_remove 15, announce_anchor 13, agent_calibrate 20 and the domain 24, all killed
     after the tests were strengthened where mutants first survived).
     * **`round_remove.py` (operator-only, not packaged).** BEFORE_DEC_6.md said "there is no tested tool" to remove the throwaway round. Found while designing it: **deleting the round and re-running `export` (the old
       plan) leaves `round_<id>.json`, `log_<id>.jsonl` and `certs_<id>/` publicly served at their direct URLs**, because `rounds.export_public` rewrites `rounds.json` and never deletes files (tested as a premise). The tool
       removes them. It refuses any id not `throwaway...`, a title that does not say TEST/THROWAWAY, any submission (either machine), a round being evaluated, any symlink or path that does not resolve to exactly
       `<data>/rounds/<id>` (checked again right before each delete); needs `--confirm "REMOVE <id>"`; backs everything up first (tarballs read back, sha256 manifest, mode 600) and deletes nothing if the backup fails;
       is idempotent and resumable; ends by checking it is gone everywhere and the other rounds are unchanged. macOS `tar` added `._name` entries that the backup's own check caught (`COPYFILE_DISABLE`). Tested on local
       folders (a path with a space) and through a fake `ssh`. **Never run on the real servers**: do the first run together, `plan` first.
     * **`announce_anchor.py`: an outside clock with no person involved.** Stamps the announcement's digest with OpenTimestamps (reusing `otsanchor.py`), and `agent_witness_kit.py check --anchor-proof P --online
       [--require-anchor]` uses the result. Only a CONFIRMED proof (>= 2 explorers) whose block time is earlier than the round's first entry passes; a wrong or forged proof FAILS the check; pending, late, single-explorer or
       unchecked proofs are notes. **Limits that matter:** it shows the announcement existed no later than the block, so the order is stamp, WAIT hours for the confirmation, then let entries in; the first-entry time is the
       operator's log; it does not show the seed was unknown to the operator; it is not a witness. Sends nothing without `--send`/`--online`. **Never run against the real calendars or explorers** (tests use the fakes of
       `test_otsanchor.py`; an explorer's integer-only block time rejected my own float fixture, correctly).
     * **`agent_calibrate.py`: the cost calibration for any model, from real ladders.** My fit, written independently, **reproduces the other session's hand-measured numbers exactly from the same ladders** (haiku 92
       calls A 1.477 B 387.2 R 2.13 R^2 0.997; sonnet's 63 study calls 1.589 / 250.6 / 3.55 / 0.9854). `write` requires the ladders to VERIFY from their seed (an edited usage number passes `read_ladder` and breaks the hash chain,
       tested), >= 30 calls from >= 3 trials, spread in context sizes, R^2 >= 0.90, a leave-one-trial-out error <= 10% and plausible ranges; recorded in `agent_calibration.json` (previous kept as `.prev`, atomic, no downgrade
       to fewer calls without `--replace`); `agent_preflight.calibration_for` reads it (a specific model id beats the families; a damaged file is ignored with a stated reason, never half-trusted). **No entry is recorded**:
       the file does not exist yet, so no estimate changed. Note: a newer sonnet pilot ladder (`sonnet55_pilot_size3.jsonl`) is not in the published sonnet figure; including it gives 72 calls and A 1.566 / B 257.5 against the
       published 1.589 / 250.6. Not changed (those are the other session's published numbers); `write` would do it. Calibrating a NEW model needs a real pilot run (costs money).
     * **The `reconcile` domain, and a constraint found on the way.** **Every ladder pins the hashes of `agent_core.py`, `agent_harness.py`, `agent_domains/__init__.py` and its domain file, so adding a domain to
       `agent_core`'s registry tuple would have silently turned all committed real-run evidence into "does not verify".** The registry is therefore extended at import time by `agent_domains_plus.py` (imported by `agent_eval.py` and
       `agent_site.py`), and `test_frozen_evidence.py` (new) fails, naming the file, the moment anyone edits a pinned file (mutation-tested on all four). `reconcile` is a long-horizon exact task: find every payment missing
       from one of two shuffled ledgers or with a different amount (transposed digits are the common slip; a third of matching rows have different descriptions as a distractor; printed totals give a checksum, not the
       answer). 16 to 80 payments a list, up to 12 differences, an exact judge (either a JSON string or a list), a scripted lean/bare/cheat agent, passes the project's own `check_domain` (10 checks) and a full plan -> run
       -> verify -> compare workflow. **Limits: scripted agents only, no model has been run on it; not sealed (public wording); the planted-difference structure is mine and untested as a measure of anything real.**
  8. **Audit of those four builds (same day), eight defects found and fixed (one of them a test that proved less than it claimed), each with a test; the first full regression run (3.14: 649 tests OK) overlapped my edits, so a clean re-run of everything follows this list.**
     * *round_remove:* **a typo in `--seed-root`/`--site-dir`, or a directory the ssh user cannot read, tested as "absent", so the tool would have reported REMOVED having looked at nothing** (reproduced first); a missing or
       unreadable parent is now its own state (`NOPARENT`) and refuses, and `plan` shows it. **A failed `ops.py export` aborted the run with a bare error after the round was already deleted**, and a second run then saw
       "nothing to remove" and never rebuilt the public index, reporting NOT CLEAN forever: it now reports the state, still removes the stale public files, and a re-run rebuilds the index. My `--eval-as` test would
       have passed with the prefix ignored; a logging wrapper now proves the prefix reaches the evaluation machine's commands and ONLY those.
     * *announce_anchor:* **a Bitcoin block's timestamp is only accurate to about two hours** (accepted up to 2 hours ahead of real time, and only required to exceed the median of the previous 11 blocks), so a stamp made an hour
       AFTER the first entry could still read "before". "Before" now needs the block earlier than the first entry by more than 2 hours (`BLOCK_TIME_SLACK`); less is a new verdict "close" that establishes nothing, and `--require-anchor` does not
       accept it. The tests' fixtures used the old raw comparison.
     * *agent_calibrate:* the **effort level** (`:medium`, `:high`) is part of the key now: it changes the billed hidden-thinking output, and two levels were being averaged into one entry; `record()` itself refuses unverified
       ladders (it relied on its callers); `agent_calibration.json` is listed for the package (it only ships once it exists).
     * *reconcile / registrar:* **four modules that load a ladder's domain by name never imported the registrar** (`agent_witness`, `agent_attest`, `agent_safety`, `agent_proxy`), so `python3 agent_proxy.py verify` on a
       reconcile ladder would have said "unknown agent domain". Fixed, and `test_frozen_evidence` now scans every module that calls `load_domain` with a name from data and imports it in a fresh process.
  9. **Audit of the audit's fixes (same day), two more defects, both introduced by the previous round's own fixes.** (a) The new refusal for an unreadable or missing parent **blocked a legitimate removal on a deployment that has
     never exported a public site directory** (the only way out was to fake a directory); `round_remove.py ... --no-site` now skips the public export entirely (not looked at, not rebuilt, not cleaned, never created), and the
     refusal names it. (b) **Recorded calibration keys were matched by SUBSTRING, so a key `gpt-4` would have priced `gpt-4o`**, a different model with different billing, and "longest key first" cannot help when only the
     shorter key exists; matching is now exact on the model id (`agent_calibrate.match_key`: equal, or the key plus an effort suffix; an effort-specific key beats a plain one). I also checked every module as a FIRST
     import on both Pythons after adding the registrar to four more of them: no import cycle.
  Still not done: no person has run the kit; `--rerun` has only been exercised with a scripted agent, never a real model (the plumbing, the statement and the reader's acceptance are tested); the receipt time is the
  witness's word. **The hosted-model runs the other session added (`anthropic_live/`, practice seed, 9 trials each of haiku-4-5 and sonnet-5-5, 4 attested) made my status file wrong a second time (it said
  three runs and "nothing hosted"):** the exact-count test failed as designed; I re-verified that run from its files (both ladders verify, the comparison is confirmed, the attested ladder is ATTESTED, the careful forgery is NOT,
  no key anywhere in the folder), set the card to four run sets, and corrected the paper (abstract, run list, "never run" list, closing paragraph), README, OUTSIDE_VERIFIER and the stale "still not done" line.
* **The card repeated the run count in an awkward "3 real model run(s)"** next to "Real model runs: 3"; the count is now stated once.
* **Re-run on today's code:** the damage fuzzers for the bounty ledger, claims, index, safety, insurer, regulatory, tracker, witness, GPU, round files, certificates and the agent log: 0 unhandled
  exceptions; every "accepted" damaged input is a numerically equal rewrite or a deleted threshold on a certificate that states no claim. (The original fuzz script had to be updated first: it posted a bounty
  without the demo flag the bounty now, correctly, requires.)
* Mutation results for this batch: 13 mutants (no network, no read-only root, capabilities kept, a writable mount, root user, a failed start read as a verdict, no kill on timeout, a non-code domain treated as
  sandboxed, a killed probe read as not blocked, the container ignored by two gates, the sandbox error handler, the log's entry-vs-certificate check). One survived at first: it exposed a test that could not
  see the handler's message (and, when I first fixed that test, my own helper's nested stderr capture made the "kill" a false positive until I checked the unmutated code); all 13 are now caught.
