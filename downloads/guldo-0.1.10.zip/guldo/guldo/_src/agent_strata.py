"""Difficulty-stratified solve-rate bounds for agent ladders (the agent analogue of the speed protocol's difficulty-stratified claim).

The flat bound in agent_compare pools every instance as if they were exchangeable draws. A ladder is not: sizes differ in difficulty, and an agent that clears the easy sizes and fails the hard
ones can still post a respectable pooled number that says nothing about the hard end. Here each size is its own stratum.

  stratified_lower(strata, weights, alpha)   one-sided lower bound on the WEIGHTED solve rate sum(w_s * p_s). Each stratum gets an exact Clopper-Pearson lower bound at level alpha/S; with
                                             probability >= 1 - alpha all S bounds hold together (Bonferroni), so the weighted sum of the bounds is a valid lower bound on the weighted rate.
                                             Valid but conservative: with few instances per size it is noticeably lower than the pooled bound, and that is the honest price of not assuming
                                             the sizes are alike. Weights must be fixed BEFORE the run (the plan can carry them); default is equal weight per size.
  worst_stratum_lower(strata, alpha)         the lowest per-stratum bound at alpha/S: "at every size the agent solves at least this much" (simultaneous).
  frontier(strata, target, alpha)            the largest size such that this size AND every smaller one have a simultaneous lower bound >= target, or None: how hard a task the agent is shown to
                                             handle at that rate.
  curve(strata, alpha)                       the per-size table (solved, n, rate, simultaneous lower and upper bounds).

Independence: bounds treat the instances of a stratum as independent draws from that size's distribution (they are derived from distinct HMAC seeds), and an instance counts as solved by the
majority-of-trials rule used everywhere in agent_compare. A solve rate on THESE generators; nothing about other tasks.
"""
import agent_core


def strata_from_summary(by_size, key_solved="solved", key_n="instances", key_size="size"):
    """[(size, solved, n)] from the `by_size` list of agent_compare.summarize, sorted by size."""
    return sorted((s[key_size], s[key_solved], s[key_n]) for s in by_size)


def _check(strata):
    if not strata:
        raise agent_core.AgentEvalError("no strata")
    for _s, k, n in strata:
        if not (isinstance(k, int) and isinstance(n, int) and 0 <= k <= n and n >= 1):
            raise agent_core.AgentEvalError("a stratum needs 0 <= solved <= n and n >= 1")


def curve(strata, alpha=agent_core.ALPHA):
    _check(strata)
    a = alpha / len(strata)
    return [{"size": s, "solved": k, "n": n, "rate": k / float(n), "lower_simultaneous": round(agent_core.cp_lower(k, n, a), 6),
             "upper_simultaneous": round(agent_core.cp_upper(k, n, a), 6)} for s, k, n in strata]


def stratified_lower(strata, weights=None, alpha=agent_core.ALPHA):
    _check(strata)
    if weights is None:
        weights = {s: 1.0 for s, _, _ in strata}
    if set(weights) != set(s for s, _, _ in strata) or any(w < 0 for w in weights.values()) or sum(weights.values()) <= 0:
        raise agent_core.AgentEvalError("weights must cover exactly the sizes, be non-negative, and not all be zero")
    tot = float(sum(weights.values()))
    a = alpha / len(strata)
    return sum(weights[s] / tot * agent_core.cp_lower(k, n, a) for s, k, n in strata)


def worst_stratum_lower(strata, alpha=agent_core.ALPHA):
    _check(strata)
    a = alpha / len(strata)
    return min(agent_core.cp_lower(k, n, a) for _s, k, n in strata)


def frontier(strata, target, alpha=agent_core.ALPHA):
    _check(strata)
    a = alpha / len(strata)
    best = None
    for s, k, n in sorted(strata):
        if agent_core.cp_lower(k, n, a) >= target:
            best = s
        else:
            break
    return best


def report(strata, weights=None, alpha=agent_core.ALPHA, target=0.5):
    return {"alpha": alpha, "method": "Clopper-Pearson per size at alpha/S (Bonferroni), weights fixed in advance", "weights": weights or "equal",
            "weighted_lower": round(stratified_lower(strata, weights, alpha), 6), "worst_size_lower": round(worst_stratum_lower(strata, alpha), 6),
            "frontier_at_target": {"target": target, "size": frontier(strata, target, alpha)}, "curve": curve(strata, alpha)}
