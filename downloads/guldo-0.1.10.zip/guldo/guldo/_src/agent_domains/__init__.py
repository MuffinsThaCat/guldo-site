"""Agent task domains. Each module: NAME, VERSION, SIZE_RANGE, SIZE_STEP, derive(seed, size), tool_specs(public), make_env(instance), reference_answer(instance), verify(instance, answer, calls)."""
