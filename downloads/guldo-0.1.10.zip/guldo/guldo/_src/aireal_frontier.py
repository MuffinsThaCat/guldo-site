"""The frontier of the aireal domain: for every counted solver, at every size, over a fixed set of instances, how closely its answers follow the real network and how accurate they are on the REAL digit labels.

  python3 aireal_frontier.py [--n 12] [--out results/aireal_frontier.json]

The judge of the domain is a single bar (98% agreement with the network, fixed in advance); this script shows what is behind it: the mean and the worst agreement of each technique, its accuracy against the true
labels (the network's own is the reference), its counted operations relative to the dense reference, and how many instances cleared the bar. Deterministic: a fixed seed, exact counts."""
import argparse
import json
import math
import os
import statistics
import sys

import numpy as np

import tflops

HERE = os.path.dirname(os.path.abspath(__file__))
NAMES = ["ref", "prune_w50", "prune_a50", "refit50", "refit25", "hard12", "distill", "lookup"]
SEED = b"aireal-frontier-seed"


def run(solver, inst):
    """-> (the solver's answer or None, steps, flops): the counted child run directly, so the answer is kept (count_instance keeps only the verdict)."""
    payload = json.dumps({"args": inst["args"], "limit": int(800 * tflops.UNIT_OPS)}).encode()
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "1", "PATH": os.environ.get("PATH", "")}
    import tempfile
    with tempfile.TemporaryDirectory() as empty:
        out, err, killed = tflops._run_watched([sys.executable, "-B", tflops.RUNNER, os.path.abspath(solver)], payload, env, empty, 600, tflops.MAX_RSS_MB)
    r = json.loads([ln for ln in out.decode().splitlines() if ln.strip()][-1])
    return r.get("ans"), r["steps"], r["flops"]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--n", type=int, default=12)
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    mod, derive, verify, d = tflops.load_family("aireal")
    rows = {}
    for size in (16, 32, 48):
        for i in range(a.n):
            inst = derive(SEED, size, i)
            planted, truth = np.array(inst["planted"]), np.array(inst["truth"])
            base = None
            for name in NAMES:
                ans, steps, flops = run(os.path.join(HERE, "solvers", f"aireal_flops_{name}.py"), inst)
                cost = steps + flops
                base = cost if name == "ref" else base
                ans = np.array(ans)
                rows.setdefault((name, size), []).append({"agree": float(np.mean(ans == planted)), "acc": float(np.mean(ans == truth)), "net_acc": float(np.mean(planted == truth)),
                                                          "bits": math.log2(base / cost), "passed": bool(verify(inst, [int(v) for v in ans]))})
    out = {"format": "svp-aireal-frontier-v1", "seed": SEED.decode(), "n": a.n, "agreement_bar": mod.AGREE, "queries": mod.Q, "results": {}}
    print(f"aireal frontier: {a.n} instances per size, 98% agreement bar, {mod.Q} real digit images per instance")
    print("solver      size  cleared  agree(mean/worst)  acc on true labels (net)  ops vs dense (median bits)")
    for (name, size), rs in rows.items():
        s = {"cleared": sum(r["passed"] for r in rs), "n": len(rs), "agree_mean": statistics.fmean(r["agree"] for r in rs), "agree_worst": min(r["agree"] for r in rs),
             "acc_mean": statistics.fmean(r["acc"] for r in rs), "net_acc_mean": statistics.fmean(r["net_acc"] for r in rs), "median_bits_vs_dense": statistics.median(r["bits"] for r in rs)}
        out["results"][f"{name}:{size}"] = s
        print(f"{name:11s} {size:4d}  {s['cleared']:2d}/{s['n']:<2d}   {s['agree_mean']:.3f}/{s['agree_worst']:.3f}      {s['acc_mean']:.3f} ({s['net_acc_mean']:.3f})            {s['median_bits_vs_dense']:+.2f}")
    if a.out:
        if os.path.exists(a.out):
            sys.exit(f"{a.out} exists")
        with open(a.out, "w") as f:
            json.dump(out, f, indent=1, sort_keys=True)
        print("wrote", a.out)


if __name__ == "__main__":
    main()
