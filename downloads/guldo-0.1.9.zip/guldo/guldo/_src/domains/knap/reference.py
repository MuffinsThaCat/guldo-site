"""Reference for knap: classic meet in the middle (two lists of 2^(m/2) subset sums), scanning the whole of the second list."""


def _sums(ws):
    v = [0]
    for w in ws:
        v = v + [x + w for x in v]     # index bit t (least significant first) says whether ws[t] is in the subset
    return v


def solve(a, s):
    k = len(a) // 2
    left, right = _sums(a[:k]), _sums(a[k:])
    table = {v: i for i, v in enumerate(left)}
    found = None
    for j, v in enumerate(right):
        i = table.get(s - v)
        if i is not None and found is None:
            found = [(i >> t) & 1 for t in range(k)] + [(j >> t) & 1 for t in range(len(a) - k)]
    return found
