#!/usr/bin/env python3
"""Score solver ladders with the compiler's own estimator (checker/estimator.py is a byte copy of the protocol's extrapolate.py).

    python3 score.py score   --pair BASELINE.jsonl SUBMISSION.jsonl [--pair ... --pair ...]   credit of one solver vs the reference
    python3 score.py compare --a A1.jsonl A2.jsonl A3.jsonl --b B1.jsonl B2.jsonl B3.jsonl    is solver A really faster than solver B?
    python3 score.py power [--pair-noise X] [--min-gap G]                                      what this challenge can and cannot certify (re-simulated if asked)
    python3 score.py recheck RESULT.json [--dir D]                                             recompute a --out result from its input ladders: same numbers or fail

A ladder is a JSON-lines file, one record per instance, id exactly "SIZE:INDEX" with INDEX running 0..n-1 for every size of the challenge (extra keys are ignored).
The first line should be {"meta": true, "commit": SHA256_OF_THE_SEED, "budget": CAP}: without a commitment the ladder cannot be tied to a published seed, so
`score` refuses it unless --lenient (and then the result is PROVISIONAL).

    {"id": "28:0", "dim": 28, "status": "solved", "cost": 3.41}        cost > 0 is CPU seconds (or any unit that is "seconds" to the floor below)
    {"id": "28:1", "dim": 28, "status": "timeout"}                      statuses: solved, timeout, crash, failed, wrong; only "solved" counts as solved

`cpu_net` is accepted in place of `cost` (the guldo harness writes it). An unsolved instance is charged the CPU cap, never excused.

The credit is the protocol's: instances are grouped by how hard the BASELINE found them (octaves of its cost above 0.5 s); the paired log2
speedup of the 3 hardest usable bins is pooled; a one-sided 95% joint-bootstrap lower bound is reported; the credit over several seeds is the
MINIMUM and an inconclusive seed counts as 0. Needs numpy. What this does NOT know: how the costs were measured. Garbage costs in, a
well-formed number out. See README.md ("What a score does not show").
"""
import argparse
import hashlib
import io
import json
import math
import os
import random
import re
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

try:
    import estimator as E  # noqa: E402
except ImportError:   # a QUALITY bundle ships no speed estimator: qscore.py is its scorer and reuses this file's readers and limits
    E = None

STATUSES = {"solved", "timeout", "crash", "failed", "wrong"}
ID_RE = re.compile(r"^[0-9]{1,9}:[0-9]{1,9}$")


class Refused(Exception):
    """The input cannot be turned into a trustworthy number: say why, produce no number."""


def manifest():
    with open(os.path.join(ROOT, "challenge.json"), encoding="utf-8") as f:
        return json.load(f)


def int_arg(lo, hi):
    """argparse type: an integer in [lo, hi], else a one-line usage error (never a traceback, never an unbounded computation)."""
    def parse(text):
        try:
            v = int(text)
        except ValueError:
            raise argparse.ArgumentTypeError(f"{text!r} is not an integer")
        if not lo <= v <= hi:
            raise argparse.ArgumentTypeError(f"{v} is outside the allowed range {lo}..{hi}")
        return v
    return parse


def float_arg(lo, hi):
    def parse(text):
        try:
            v = float(text)
        except ValueError:
            raise argparse.ArgumentTypeError(f"{text!r} is not a number")
        if not math.isfinite(v) or not lo <= v <= hi:
            raise argparse.ArgumentTypeError(f"{text} is not a finite number in {lo}..{hi}")
        return v
    return parse


def finite_float(x):
    """x as a float if it is a finite real number (not a bool, not a string, not an int too big for a float), else None."""
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        return None
    try:
        f = float(x)
    except OverflowError:
        return None
    return f if math.isfinite(f) else None


LIMIT_LADDER = 32 << 20   # 20,000 records of ~150 bytes is 3 MB
LIMIT_JSON = 16 << 20


def _open_regular(path, limit):
    """fd of a regular file no bigger than `limit`, opened WITHOUT blocking, else Refused. A FIFO would block every reader for ever and /dev/zero never ends (found by
    probing: every tool hung on a FIFO, and a 300 MB single-line file took 626 MB)."""
    import stat
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_BINARY", 0))   # no O_NONBLOCK on Windows (no FIFOs to block on)
    except OSError as e:
        raise Refused(f"cannot read {path}: {e.strerror}")
    st = os.fstat(fd)
    if not stat.S_ISREG(st.st_mode):
        os.close(fd)
        raise Refused(f"{path} is not a regular file (a FIFO, device, socket or directory is refused: reading it could block or never end)")
    if limit is not None and st.st_size > limit:
        os.close(fd)
        raise Refused(f"{path} is {st.st_size} bytes, over the {limit} byte limit for this kind of file")
    return fd


def read_text(path, limit):
    fd = _open_regular(path, limit)
    try:
        chunks, total = [], 0
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                break
            total += len(chunk)
            if total > limit:
                raise Refused(f"{path} grew past {limit} bytes while being read")
            chunks.append(chunk)
    finally:
        os.close(fd)
    try:
        return b"".join(chunks).decode("utf-8")
    except UnicodeDecodeError:
        raise Refused(f"{path} is not UTF-8 text")


def load_ladder(path, default_budget):
    meta, by_dim = None, {}
    f = io.StringIO(read_text(path, LIMIT_LADDER))
    with f:
        for n, line in enumerate(f, 1):
            if n > MAX_RECORDS:   # the bootstrap is O(resamples x records): a million-line file ran >10 minutes (measured), and a real ladder is ~10^3 records
                raise Refused(f"{path}: more than {MAX_RECORDS} lines; this is not a ladder of this challenge (sizes x instances per size is about {1000}) and scoring it would not finish")
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                raise Refused(f"{path}:{n}: not JSON")
            if not isinstance(r, dict):
                raise Refused(f"{path}:{n}: not a JSON object")
            if r.get("meta"):
                if meta is not None:
                    raise Refused(f"{path}:{n}: a second meta line")
                meta = r
                continue
            for k in ("id", "dim", "status"):
                if k not in r:
                    raise Refused(f"{path}:{n}: no {k!r}")
            if not isinstance(r["status"], str) or r["status"] not in STATUSES:
                raise Refused(f"{path}:{n}: status {str(r['status'])[:30]!r} is not one of {sorted(STATUSES)}")
            dim = r["dim"]
            if isinstance(dim, bool) or not isinstance(dim, int):
                raise Refused(f"{path}:{n}: dim must be an integer")
            if not (isinstance(r["id"], str) and ID_RE.match(r["id"]) and int(r["id"].split(":")[0]) == dim):
                raise Refused(f"{path}:{n}: id {r['id']!r} must be 'SIZE:INDEX' with SIZE equal to dim ({dim})")
            cost = r.get("cpu_net", r.get("cost"))
            if r["status"] == "solved":
                cost = finite_float(cost)
                if cost is None or cost <= 0:
                    raise Refused(f"{path}:{n}: a solved record needs a finite cost > 0")
            else:
                cost = 0.0
            rid = str(r["id"])
            if rid in by_dim.setdefault(dim, {}):
                raise Refused(f"{path}:{n}: instance {rid} appears twice")
            by_dim[dim][rid] = {"id": rid, "dim": dim, "status": r["status"], "cpu_net": float(cost)}
    if not by_dim:
        raise Refused(f"{path}: no records")
    meta = meta or {}
    commit = meta.get("commit")
    if commit is not None and not (isinstance(commit, str) and 0 < len(commit) <= 128):
        raise Refused(f"{path}: meta.commit must be a short string (the seed's sha256)")
    budget = finite_float(meta.get("budget", default_budget))
    if budget is None or budget <= 0:
        raise Refused(f"{path}: budget must be a positive, finite number")
    for dim in by_dim.values():
        for r in dim.values():
            if r["status"] == "solved" and r["cpu_net"] > budget * 1.0000001:
                raise Refused(f"{path}: instance {r['id']} is 'solved' at {r['cpu_net']} s, above the {budget} s cap (it is a timeout)")
    return meta, by_dim, float(budget)


def ladder_problems(by_dim, ch):
    """How this ladder differs from the challenge's declared size ladder: a dropped hard size would hide failures."""
    want, n = set(ch["ladder"]["dims"]), ch["ladder"]["n"]
    out = []
    if set(by_dim) - want:
        out.append(f"sizes {sorted(set(by_dim) - want)} are not on the challenge ladder")
    if want - set(by_dim):
        out.append(f"ladder sizes {sorted(want - set(by_dim))} are missing")
    off = {}
    for d, recs in by_dim.items():
        diff = set(recs) ^ {f"{d}:{i}" for i in range(n)}
        if d in want and diff:
            off[d] = len(diff)
    if off:
        out.append(f"each size must hold exactly the instances SIZE:0..SIZE:{n - 1}; differing ids per size: {off}")
    return out


def load_pair(base_path, sub_path, ch, strict):
    mb, base, bb = load_ladder(base_path, ch["ladder"]["budget_seconds"])
    ms, sub, bs = load_ladder(sub_path, ch["ladder"]["budget_seconds"])
    if bb != bs:
        raise Refused(f"the two ladders ran with different CPU caps ({bb} vs {bs}): censoring would not be comparable")
    notes = []
    if bb != ch["ladder"]["budget_seconds"]:
        notes.append(f"cap {bb} s differs from the challenge's {ch['ladder']['budget_seconds']} s")
    cb, cs = mb.get("commit"), ms.get("commit")
    if cb and cs and cb != cs:
        raise Refused("the ladders were run on different seeds (commitments differ)")
    commit = cb or cs
    if not commit:
        notes.append("no seed commitment in the ladders: cannot tie them to a published seed")
    only_b, only_s = E.coverage_mismatch(base, sub)
    if only_b or only_s:
        raise Refused(f"the ladders do not cover the same instances ({len(only_b)} only in the first, {len(only_s)} only in the second): "
                      "a truncated run would give a credit computed on a biased subset")
    for label, by_dim in (("baseline", base), ("submission", sub)):
        for p in ladder_problems(by_dim, ch):
            notes.append(f"{label}: {p}")
    if strict and notes:
        raise Refused("; ".join(notes) + " (use --lenient to score it anyway; the result is then PROVISIONAL)")
    return base, sub, bb, commit, notes


def observed_pair_noise(tb, ts, bc, sc):
    """Pooled within-difficulty-bin sd of the paired log2 ratios (both solved, baseline above the floor): the per-instance noise the power table
    ASSUMED (challenge.json power.pair_noise_bits), measured on this pair. None with fewer than 8 residuals from bins of >= 4."""
    by_bin = {}
    for d in tb:
        for i, cb in tb[d].items():
            if i in ts.get(d, {}) and not bc[d][i] and not sc[d][i] and cb >= E.FLOOR_ABS:
                by_bin.setdefault(int(math.floor(math.log2(cb / E.FLOOR_ABS))), []).append(math.log2(cb / ts[d][i]))
    res = [x - statistics.median(v) for v in by_bin.values() if len(v) >= 4 for x in v]
    return statistics.pstdev(res) if len(res) >= 8 else None


def pair_credit(base_path, sub_path, ch, strict, boot):
    base, sub, budget, commit, notes = load_pair(base_path, sub_path, ch, strict)
    (tb, bc), (ts, sc) = E.per_dim_times(base, budget), E.per_dim_times(sub, budget)
    meas, top, info = E.measured_by_difficulty(tb, ts, bc, random.Random(1), boot=boot)
    hp, hp_n, hp_sub = E.hard_pool_claim(tb, ts, bc, random.Random(1), boot=boot)
    eligible = [(tb[d][i], ts[d][i]) for d in tb for i in tb[d] if i in ts.get(d, {}) and not bc[d][i] and tb[d][i] >= E.FLOOR_ABS]
    below = sum(c < E.FLOOR_ABS for _, c in eligible)
    return {
        "eligible_instances": len(eligible),
        "submission_below_floor_fraction": (below / len(eligible)) if eligible else None,
        "raw_median_bits": statistics.median(math.log2(b / c) for b, c in eligible) if eligible else None,
        "pair_noise_bits": observed_pair_noise(tb, ts, bc, sc),
        "baseline": os.path.basename(base_path), "submission": os.path.basename(sub_path), "commit": commit, "budget": budget,
        "credit_bits": None if meas is None else max(0.0, meas[1]),
        "median_bits": None if meas is None else meas[0],
        "bins": {str(k): v for k, v in sorted(info.items())},
        "credited_bins": [[info[k]["lo"], info[k]["hi"]] for k in top] if meas is not None else [],
        "hard_pool": None if hp is None else {"median": hp[0], "lower": hp[1], "n": hp_n},
        "solved": {str(d): sum(r["status"] == "solved" for r in sub[d].values()) for d in sorted(sub)},
        "wrong_answers": sum(r["status"] == "wrong" for d in sub for r in sub[d].values()),
        "notes": notes,
    }


def combine(pairs, ch, strict):
    seeds = ch["protocol"]["seeds_required"]
    commits = [p["commit"] for p in pairs if p["commit"]]
    if len(set(commits)) != len(commits):
        msg = "two pairs share a seed commitment: one seed would be counted twice"
        if strict:
            raise Refused(msg)
    credits = [0.0 if p["credit_bits"] is None else p["credit_bits"] for p in pairs]
    inconclusive = sum(p["credit_bits"] is None for p in pairs)
    notes = sorted({n for p in pairs for n in p["notes"]})
    if len(set(commits)) != len(commits):
        notes.append("two pairs share a seed commitment")
    complete = len(pairs) >= seeds and not notes
    return {"credit_bits": min(credits), "per_seed": credits, "inconclusive_seeds": inconclusive, "seeds": len(pairs),
            "seeds_required": seeds, "status": "COMPLETE" if complete else "PROVISIONAL",
            "why_provisional": ([] if len(pairs) >= seeds else [f"{len(pairs)} seed(s); {seeds} required"]) + notes}


def window_note(credit, ch, pairs=()):
    pw = ch["power"]
    lo, hi = pw["min_certifiable_bits"], pw["max_certifiable_bits"]
    if lo is None:
        return "this challenge's own power analysis found NO speedup it can certify: treat every credit as weak"
    if credit == 0 and any(floor_limited(p) for p in pairs):
        return "0 here means TOO FAST TO MEASURE on this ladder, not slow: the submission falls under the cost floor (see the raw medians above)"
    if credit == 0:
        return f"0 bits is 'nothing certified', not 'no speedup': below about {lo} bits this ladder usually cannot tell"
    if credit >= hi:
        return f"at or above the top of what this ladder can certify ({hi} bits): a larger true speedup would read about the same"
    if credit < lo:
        return f"below the {lo}-bit lower edge of the certifiable range: weak evidence"
    return None


def floor_limited(p):
    """The faster side costs under the 0.5 s floor on most instances the slower side finds hard: the estimator discards exactly the evidence."""
    f = p.get("submission_below_floor_fraction")
    return f is not None and f >= 0.5


def resolve_hint(p):
    """What it would take to resolve a gap this big: the slower solver must cost about FLOOR * 2^gap on the hard instances, which the cap may forbid."""
    raw = p.get("raw_median_bits")
    if raw is None or raw <= 0:
        return ""
    need, cap = E.FLOOR_ABS * 2 ** raw, p["budget"]
    return (f" Resolving a gap of about {raw:.1f} bits needs the slower solver to cost about {need:,.0f} s on the hard instances; this challenge's cap is {cap:g} s, "
            + ("so no ladder under this cap can resolve it: it needs a higher cap or a stronger reference (recompile the declaration)" if need > cap
               else "so a ladder with larger sizes can: recompile with a harder size range"))


def why_inconclusive(p):
    if floor_limited(p):
        return (f"the submission costs < {E.FLOOR_ABS:g} s on {p['submission_below_floor_fraction']:.0%} of the {p['eligible_instances']} instances the baseline finds hard: "
                f"faster than this ladder can resolve (raw median {p['raw_median_bits']:.1f} bits, descriptive only, NOT a bound)." + resolve_hint(p))
    return "fewer than 2 difficulty bins hold >= %d instances where the submission also costs >= %g s" % (E.MIN_BIN, E.FLOOR_ABS)


GRID = (0, 0.5, 1, 1.5, 2, 3, 4, 5, 6)


def simulate(ch, effect, noise, gap, trials, boot, rng):
    """P(one seed credited >= gap) and P(all seeds credited >= gap) for a true speedup of `effect` bits at per-instance noise `noise`, through the
    estimator in this bundle, on ladders drawn from the compiled profile (challenge.json "simulation"). Mirrors the compiler's own power analysis."""
    sim = ch.get("simulation")
    if not sim:
        raise Refused("this bundle has no simulation block (it was exported by an older tool): re-export it")
    n, cap, sig, k = ch["ladder"]["n"], sim["cap"], sim["sigma"], ch["protocol"]["seeds_required"]
    credits = []
    for _ in range(k * trials):
        tb, ts, bc = {}, {}, {}
        for s in sim["sizes"]:
            m = sim["median_log2"][str(s)]
            tb[s], ts[s], bc[s] = {}, {}, {}
            for i in range(n):
                c = 2 ** (m + sig * rng.gauss(0, 1))
                cens = c > cap
                cost = cap if cens else max(c, 1e-3)
                tb[s][i], bc[s][i] = cost, cens
                ts[s][i] = min(max(cost * 2 ** -(effect + rng.gauss(0, noise)), 1e-3), cap)
        meas, _, _ = E.measured_by_difficulty(tb, ts, bc, rng, boot=boot)
        credits.append(None if meas is None else max(0.0, meas[1]))
    trip = [min(0.0 if c is None else c for c in credits[i:i + k]) for i in range(0, len(credits) - k + 1, k)]
    return {"single": sum(c is not None and c >= gap for c in credits) / len(credits), "all_seeds": sum(c >= gap for c in trip) / len(trip)}


def simulate_table(ch, noise, gap, trials, boot, rng):
    return {e: simulate(ch, e, noise, gap, trials, boot, rng) for e in GRID}


def certifiable_range(table, target):
    ok = [e for e, v in table.items() if v["all_seeds"] >= target]
    return (min(ok), max(ok)) if ok else (None, None)


def noise_note(pairs, ch, trials=20, boot=40):
    """The power table assumed a per-instance noise; if these ladders show clearly more, say so and re-simulate at the observed value."""
    obs = [p["pair_noise_bits"] for p in pairs if p.get("pair_noise_bits") is not None]
    assumed = ch["power"].get("pair_noise_bits")
    if not obs or assumed is None or not ch.get("simulation"):
        return None
    o = statistics.median(obs)
    if o <= assumed + 0.15:
        return None
    lo, hi = certifiable_range(simulate_table(ch, o, ch["power"]["threshold_bits"], trials, boot, random.Random(0)), ch["power"]["target_power"])
    where = f"from about {lo} to about {hi} bits" if lo is not None else "NO speedup on the grid"
    return (f"observed per-instance noise {o:.2f} bits is above the {assumed} the power table assumed: that table is optimistic here. Re-simulated at {o:.2f}, "
            f"this ladder certifies {where} (all seeds, {int(100 * ch['power']['target_power'])}% power)")


def print_score(res, pairs, ch):
    for p in pairs:
        c = p["credit_bits"]
        print(f"  {p['submission']} vs {p['baseline']}: " + (f"INCONCLUSIVE: {why_inconclusive(p)}" if c is None else
              f">= {c:.2f} bits (median {p['median_bits']:.2f}) over bins {p['credited_bins']}") + (f"; {p['wrong_answers']} WRONG answers" if p["wrong_answers"] else ""))
    print(f"credit = min over {res['seeds']} seed(s), inconclusive counted as 0: {res['credit_bits']:.2f} bits   [{res['status']}]")
    for w in res["why_provisional"]:
        print("  provisional because: " + w)
    note = window_note(res["credit_bits"], ch, pairs)
    if note:
        print("  " + note)
    nn = noise_note(pairs, ch)
    if nn:
        print("  " + nn)


def write_out(path, obj):
    if path is None:
        return
    try:
        f = open(path, "x", encoding="utf-8")   # exclusive create: no window between 'does it exist' and 'write it'
    except FileExistsError:
        raise Refused(f"{path} exists: this tool never overwrites")
    except OSError as e:
        raise Refused(f"cannot write {path}: {e.strerror}")
    with f:
        json.dump(obj, f, indent=1, sort_keys=True)
    print("wrote", path)


def sha256_file(path):
    fd = _open_regular(path, None)
    try:
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                return h.hexdigest()
            h.update(chunk)
    finally:
        os.close(fd)


def tool_binding():
    return {"challenge_json_sha256": sha256_file(os.path.join(ROOT, "challenge.json")), "estimator_sha256": sha256_file(os.path.join(HERE, "estimator.py")),
            "score_py_sha256": sha256_file(os.path.abspath(__file__))}


def input_binding(paths, base=""):
    try:
        return {p: sha256_file(os.path.join(base, p) if base and not os.path.isabs(p) else p) for p in sorted(set(paths))}
    except OSError as e:
        raise Refused(f"cannot read {e.filename}: {e.strerror}")


def run_score(pairs_paths, ch, strict, boot):
    pairs = [pair_credit(b, s, ch, strict, boot) for b, s in pairs_paths]
    return combine(pairs, ch, strict), pairs


def run_compare(la, lb, ch, strict, boot, min_gap):
    if len(la) != len(lb):
        raise Refused("--a and --b need one ladder per seed, in the same seed order")
    a_over_b = [pair_credit(b, x, ch, strict, boot) for x, b in zip(la, lb)]   # baseline = the other solver, so bins follow ITS difficulty
    b_over_a = [pair_credit(x, b, ch, strict, boot) for x, b in zip(la, lb)]
    ra, rb = combine(a_over_b, ch, strict), combine(b_over_a, ch, strict)
    ga, gb = ra["credit_bits"], rb["credit_bits"]
    if ga >= min_gap and ga > gb:
        verdict = f"A is faster: >= {ga:.2f} bits over B (lower bound, min over seeds)"
    elif gb >= min_gap and gb > ga:
        verdict = f"B is faster: >= {gb:.2f} bits over A (lower bound, min over seeds)"
    elif any(floor_limited(p) for p in a_over_b + b_over_a):
        who, ps = ("A", a_over_b) if any(floor_limited(p) for p in a_over_b) else ("B", b_over_a)
        raw = [p["raw_median_bits"] for p in ps if p["raw_median_bits"] is not None]
        verdict = (f"UNRESOLVABLE BY THIS LADDER: {who} costs < {E.FLOOR_ABS:g} s on most instances the other finds hard, so the estimator discards the evidence "
                   f"(raw median gap {statistics.median(raw):.1f} bits, descriptive only, NOT a bound)." + resolve_hint(ps[0] | {"raw_median_bits": statistics.median(raw)}))
    else:
        verdict = f"CANNOT SEPARATE: neither lower bound reaches {min_gap} bits (A over B {ga:.2f}, B over A {gb:.2f}); the gap, if any, is inside the noise"
    if ra["status"] != "COMPLETE" or rb["status"] != "COMPLETE":
        verdict += "  [PROVISIONAL]"
    return {"verdict": verdict, "min_gap": min_gap, "a_over_b": ra, "b_over_a": rb}, a_over_b, b_over_a


def cmd_score(a):
    ch, strict = manifest(), not a.lenient
    res, pairs = run_score(a.pair, ch, strict, a.boot)
    print_score(res, pairs, ch)
    paths = [p for pair in a.pair for p in pair]
    write_out(a.out, {"challenge": ch["name"], "version": ch["version"], "command": {"name": "score", "pairs": a.pair, "boot": a.boot, "lenient": a.lenient},
                      "result": res, "pairs": pairs, "binding": {**tool_binding(), "inputs": input_binding(paths)}})
    return 0


def same(x, y, tol=1e-9):
    if isinstance(x, dict) and isinstance(y, dict):
        return x.keys() == y.keys() and all(same(x[k], y[k], tol) for k in x)
    if isinstance(x, list) and isinstance(y, list):
        return len(x) == len(y) and all(same(p, q, tol) for p, q in zip(x, y))
    if isinstance(x, float) or isinstance(y, float):
        if not (isinstance(x, (int, float)) and isinstance(y, (int, float))):
            return False
        try:
            return abs(x - y) <= tol * max(1.0, abs(x), abs(y))
        except OverflowError:   # an int too big for a float: equal only if exactly equal
            return x == y
    return x == y


MAX_BOOT = 5000       # measured: scoring is linear in records x resamples; 50,000 records at 400 resamples took 48 s,
MAX_TRIALS = 2000
MAX_SIM_WORK = 200000  # trials x resamples for `power`: the default (30 x 60, 9 effects x 3 seeds) is ~2000; this allows 100x that (minutes), not hours
MAX_RECORDS = 20000   # so these two caps bound the worst accepted case near two minutes (a real ladder: ~10^3 records, 400 resamples)


def validate_result(rec, name):
    """A result file is untrusted input: check its whole shape before anything is read from or computed with it. -> (command, binding)"""
    bad = Refused(f"{name} is not a result written by this tool")
    try:
        cmd, bind = rec["command"], rec["binding"]
        strs = lambda v: isinstance(v, list) and v and all(isinstance(p, str) for p in v)   # noqa: E731
        if not (isinstance(cmd, dict) and isinstance(bind, dict) and cmd["name"] in ("score", "compare") and isinstance(cmd["lenient"], bool)):
            raise bad
        boot = cmd["boot"]
        if isinstance(boot, bool) or not isinstance(boot, int) or not 1 <= boot <= MAX_BOOT:
            raise Refused(f"{name}: the bootstrap count must be an integer from 1 to {MAX_BOOT}")
        if cmd["name"] == "score":
            ok = isinstance(cmd["pairs"], list) and cmd["pairs"] and all(isinstance(p, list) and len(p) == 2 and all(isinstance(x, str) for x in p) for p in cmd["pairs"])
            paths = [x for p in cmd["pairs"] for x in p] if ok else []
        else:
            ok = strs(cmd["a"]) and strs(cmd["b"]) and finite_float(cmd["min_gap"]) is not None
            paths = list(cmd["a"]) + list(cmd["b"]) if ok else []
        if not ok or not all(isinstance(bind.get(k), str) for k in ("challenge_json_sha256", "estimator_sha256", "score_py_sha256")):
            raise bad
        if not (isinstance(bind["inputs"], dict) and all(isinstance(k, str) and isinstance(v, str) for k, v in bind["inputs"].items())):
            raise bad
        if not set(paths) <= set(bind["inputs"]):
            raise Refused(f"{name} does not bind all of its input ladders by hash, so it cannot be re-checked")
    except (KeyError, TypeError, AttributeError):
        raise bad
    return cmd, bind


def cmd_recheck(a):
    """Recompute a result file from its input ladders and demand the same numbers: tamper-evidence for a published score."""
    try:
        rec = json.loads(read_text(a.result, LIMIT_JSON))
    except (OSError, ValueError, RecursionError) as e:
        raise Refused(f"{a.result} is not a result written by this tool ({type(e).__name__})")
    cmd, bind = validate_result(rec, a.result)
    ch, problems = manifest(), []
    now = tool_binding()
    for k, v in now.items():
        if bind.get(k) != v:
            problems.append(f"{k} differs: these numbers came from a different challenge, estimator or scorer than this one")
    paths = list(bind["inputs"])
    have = input_binding(paths, a.dir or "")
    problems += [f"input changed: {p}" for p in paths if have[p] != bind["inputs"][p]]
    if not problems:
        base = a.dir or ""
        fix = lambda p: os.path.join(base, p) if base and not os.path.isabs(p) else p   # noqa: E731
        strict = not cmd["lenient"]
        if cmd["name"] == "score":
            res, pairs = run_score([[fix(b), fix(s)] for b, s in cmd["pairs"]], ch, strict, cmd["boot"])
            fresh = {"result": res, "pairs": pairs}
        else:
            res, ab, ba = run_compare([fix(p) for p in cmd["a"]], [fix(p) for p in cmd["b"]], ch, strict, cmd["boot"], cmd["min_gap"])
            fresh = {"result": res, "a_over_b_pairs": ab, "b_over_a_pairs": ba}
        got = json.loads(json.dumps(fresh))
        for k, v in got.items():
            if not same(v, rec.get(k)):
                problems.append(f"{k}: recomputed numbers differ from the recorded ones")
    print("RECHECK OK: recomputed from the input ladders, identical" if not problems else "RECHECK FAILED:\n  " + "\n  ".join(problems))
    return 1 if problems else 0


def compare_power_line(res, pairs, ch, min_gap, trials=20, boot=40):
    """The power of THIS comparison, simulated at the noise actually observed (the assumed one if the ladders are too thin to measure it)."""
    if not ch.get("simulation"):
        return None
    obs = [p["pair_noise_bits"] for p in pairs if p.get("pair_noise_bits") is not None]
    noise = statistics.median(obs) if obs else ch["power"].get("pair_noise_bits")
    if noise is None:
        return None
    tab = simulate_table(ch, noise, min_gap, trials, boot, random.Random(0))
    lo, hi = certifiable_range(tab, ch["power"]["target_power"])
    where = f"a true gap of about {lo} to {hi} bits" if lo is not None else "no gap on the grid"
    return (f"power of this comparison (simulated, {'observed' if obs else 'assumed'} noise {noise:.2f} bit, declared at >= {min_gap} bit): {where} is declared with >= "
            f"{int(100 * ch['power']['target_power'])}% probability; a true gap of 0 is declared {100 * tab[0]['all_seeds']:.0f}% of the time")


def cmd_compare(a):
    ch, strict = manifest(), not a.lenient
    res, a_over_b, b_over_a = run_compare(a.a, a.b, ch, strict, a.boot, a.min_gap)
    print(res["verdict"])
    for w in res["a_over_b"]["why_provisional"]:
        print("  provisional because: " + w)
    print("  resolves only gaps on instances where the slower solver costs >= 0.5 s and the faster one does too; a tie below that says nothing.")
    line = None if res["verdict"].startswith("UNRESOLVABLE") else compare_power_line(res, a_over_b + b_over_a, ch, a.min_gap)   # a power range says nothing about a gap beyond the ladder
    if line:
        print("  " + line)
    nn = noise_note(a_over_b + b_over_a, ch)
    if nn:
        print("  " + nn)
    write_out(a.out, {"challenge": ch["name"], "version": ch["version"], "command": {"name": "compare", "a": a.a, "b": a.b, "boot": a.boot, "lenient": a.lenient, "min_gap": a.min_gap},
                      "result": res, "a_over_b_pairs": a_over_b, "b_over_a_pairs": b_over_a,
                      "binding": {**tool_binding(), "inputs": input_binding(list(a.a) + list(a.b))}})
    return 0


def cmd_power(a):
    ch = manifest()
    pw = ch["power"]
    print(f"{ch['name']}: {ch['ladder']['n']} instances per size, sizes {ch['ladder']['dims']}, cap {ch['ladder']['budget_seconds']} s, assumed pair noise {pw['pair_noise_bits']} bit")
    print(f"certifiable (all {ch['protocol']['seeds_required']} seeds credited >= {pw['threshold_bits']} bit with >= {int(100 * pw['target_power'])}% power): "
          f"{pw['min_certifiable_bits']} to {pw['max_certifiable_bits']} bits")
    print("true speedup (bits) | P(one seed credited) | P(all seeds credited)")
    for e, v in pw["curve"].items():
        print(f"{e:>19} | {100 * v['single']:>19.0f}% | {100 * v['all_seeds']:>20.0f}%")
    if a.pair_noise is not None or a.min_gap is not None:
        if a.trials * a.boot > MAX_SIM_WORK:
            raise Refused(f"--trials {a.trials} x --boot {a.boot} = {a.trials * a.boot} exceeds the limit {MAX_SIM_WORK} (the default is {30 * 60}): the simulation would run for hours")
        noise = pw["pair_noise_bits"] if a.pair_noise is None else a.pair_noise
        gap = pw["threshold_bits"] if a.min_gap is None else a.min_gap
        tab = simulate_table(ch, noise, gap, a.trials, a.boot, random.Random(0))
        lo, hi = certifiable_range(tab, pw["target_power"])
        print(f"\nsimulated here: pair noise {noise} bit, a seed counts as credited at >= {gap} bit, {a.trials} trials per point "
              f"(Monte-Carlo error about +-{100 * 0.5 / math.sqrt(a.trials):.0f} points); certifiable {lo} to {hi} bits")
        print("true effect (bits) | P(one seed credited) | P(all seeds credited)")
        for e, v in tab.items():
            print(f"{e:>18} | {100 * v['single']:>19.0f}% | {100 * v['all_seeds']:>20.0f}%")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("score")
    p.add_argument("--pair", nargs=2, action="append", required=True, metavar=("BASELINE", "SUBMISSION"))
    p = sub.add_parser("compare")
    p.add_argument("--a", nargs="+", required=True, metavar="LADDER")
    p.add_argument("--b", nargs="+", required=True, metavar="LADDER")
    p.add_argument("--min-gap", type=float_arg(0, 100), default=0.5, help="bits a lower bound must reach to call one solver faster (default 0.5; the power printed with the verdict is simulated, "
                   "but the threshold itself is a convention, not a pre-registered test)")
    p = sub.add_parser("power", help="the compiled power table; with --pair-noise / --min-gap it is re-simulated here")
    p.add_argument("--pair-noise", type=float_arg(0, 50), help="per-instance noise (bits) to simulate at, e.g. the value `score` observed")
    p.add_argument("--min-gap", type=float_arg(0, 100), help="credit threshold (bits) to simulate at (default: the challenge's)")
    p.add_argument("--trials", type=int_arg(1, MAX_TRIALS), default=30, help=f"Monte-Carlo trials per point (1..{MAX_TRIALS}; trials x boot may not exceed {MAX_SIM_WORK})")
    p.add_argument("--boot", type=int_arg(1, MAX_BOOT), default=60)
    p = sub.add_parser("recheck", help="recompute a --out result file from its input ladders; fails if anything differs")
    p.add_argument("result")
    p.add_argument("--dir", help="directory the recorded ladder paths are relative to (default: the current one)")
    for name in ("score", "compare"):
        q = sub.choices[name]
        q.add_argument("--boot", type=int_arg(1, MAX_BOOT), default=400, help=f"bootstrap resamples (1..{MAX_BOOT}; default 400)")
        q.add_argument("--lenient", action="store_true", help="score ladders that do not match the challenge's ladder or lack a commitment; the result is PROVISIONAL")
        q.add_argument("--out", help="also write the full result as JSON (never overwrites)")
    a = ap.parse_args(argv)
    try:
        if manifest().get("metric") == "quality":
            raise Refused("this bundle is a QUALITY challenge (answers are scored, not the clock): use qscore.py")
        return {"score": cmd_score, "compare": cmd_compare, "power": cmd_power, "recheck": cmd_recheck}[a.cmd](a)
    except Refused as e:
        print("REFUSED: " + str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
