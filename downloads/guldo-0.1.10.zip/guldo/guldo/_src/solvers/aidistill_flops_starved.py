"""aidistill in the counted-operations API, STARVED: distillation into a linear student exactly as aidistill_flops_distill.py, but fitted on only 2d teacher queries instead of 6d. It is cheaper, and too little
teacher data makes the fit noisy: some instances leave the judge's tolerance. The judge decides instance by instance, so this shows how far the saving can be pushed before the answer stops being equivalent."""
import math

import tensorops as tp

C = 10
E = 4
TRAIN = 2               # CHEAT-ish: only 2d teacher queries to fit on: too few, and some instances leave the judge's tolerance


def solve_spd(G, R, m, k):
    """Solve G x = R for an m x m symmetric positive definite G and an m x k right-hand side by Gauss-Jordan elimination on [G | R]."""
    A = tp.concat([G, R], 1)
    for j in range(m):
        row = A[j:j + 1] / A[j:j + 1, j:j + 1]
        M = A - A[:, j:j + 1] * row
        A = tp.concat([M[0:j], row, M[j + 1:m]], 0)
    return A[:, m:m + k]


def solve(seed, d, Q):
    H = 4 * d
    n = TRAIN * d
    X = tp.reshape(tp.stream(seed, E * (H * d + H + C * H), Q * d), (Q, d))
    Xs = X[0:n]
    o = 0
    T = tp.zeros((n, C))
    for e in range(E):
        W1 = tp.reshape(tp.stream(seed, o, H * d), (H, d)) * math.sqrt(3.0 / d)
        o += H * d
        b = tp.stream(seed, o, H) + 1.0
        o += H
        W2 = tp.reshape(tp.stream(seed, o, C * H), (C, H)) * (math.sqrt(3.0 / H) / E)
        o += C * H
        T = T + tp.relu(Xs @ tp.transpose(W1, (1, 0)) + tp.reshape(b, (1, H))) @ tp.transpose(W2, (1, 0))
    A = tp.concat([Xs, tp.zeros((n, 1)) + 1.0], 1)
    At = tp.transpose(A, (1, 0))
    eye = tp.tensor([[1e-6 if i == j else 0.0 for j in range(d + 1)] for i in range(d + 1)])
    coef = solve_spd(At @ A + eye, At @ T, d + 1, C)
    rows = (tp.concat([X, tp.zeros((Q, 1)) + 1.0], 1) @ coef).tolist()
    return [row.index(max(row)) for row in rows]
