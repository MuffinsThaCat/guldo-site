"""Bounties settled by certificate: an escrow LEDGER whose settlement condition is a machine-checked agent-evaluation claim. Fiat, no token.

A sponsor posts a bounty: "pay X if an agent configuration shows at least F-fold fewer tokens (or at least R solve rate) on THIS committed plan". Money is held by a real escrow or payment
provider the parties choose; THIS MODULE MOVES NO MONEY. It is the record both sides can audit and the referee for the one question that can be settled by computation: does the claim hold?

Lifecycle (an append-only, hash-chained file; every entry names its bounty):
  post     the spec: domain, plan hash, seed commitment, thresholds, claim deadline, challenge window, amount (integer cents) and currency
  fund     a HUMAN records the escrow reference after the provider confirms the money is held (nothing can be claimed on an unfunded bounty)
  claim    a claimant files a comparison claim with the digests of both ladders
  verdict  `evaluate_claim` ran: both ladders re-verified against the revealed seed, the comparison recomputed byte-for-byte, the thresholds checked; stores pass/fail and the reasons
  challenge  anyone may object during the window with a reason and an evidence hash. One challenge per name; a "verification" challenge is recorded and never blocks (settlement re-runs the check); any other
             blocks settlement until a human `resolve`s it, at most MAX_OPEN_CHALLENGES at a time, none after the window of a passing claim has closed
  settle   only after a passing verdict, the whole challenge window, and no open challenge; names who is to be paid and how much
  refund   only after the claim deadline with no passing verdict (or a resolved challenge that overturned it)

What is and is not decided here. COMPUTED: ladders consistent and correct, comparison recomputed, thresholds met, rules of the ledger (order of events, windows, no double settlement). NOT
decided: that a model produced the trajectories (see agent_attest.py and agent_witness.py: a bounty spec may REQUIRE them), who owns the money, tax, KYC, law. A real deployment needs a payment
provider's API behind `PaymentRail`; `ManualRail` only prints what a human must do. Nothing here has handled real money.
"""
import json
import os

import agent_compare
import agent_core
import agent_eval
import agent_sig
from agent_core import canon, sha256_hex

FORMAT = "guldo-bounty-ledger-v1"
DAY = 86400
KINDS = ("post", "fund", "claim", "verdict", "challenge", "resolve", "settle", "refund")
GROUNDS = ("verification", "other")   # what a challenge says is wrong. "verification": the claim does not verify - settlement RE-RUNS the whole check, so this is recorded but never blocks. "other": needs a human.
MAX_OPEN_CHALLENGES = 3               # blocking challenges open at once on one bounty: a stuck bounty needs at most this many `resolve`s, not as many as anyone cares to file
MAX_RECORDED_CHALLENGES = 25          # challenges of any ground on one bounty: the ledger is append-only, so without a cap non-blocking ones could grow it without limit


_LOOKALIKES = str.maketrans({"0": "o", "1": "l", "i": "l", "|": "l", "5": "s", "$": "s", "3": "e", "4": "a", "@": "a", "8": "b"})


def unicodedata_ascii(who):
    """True if the name is ASCII once Unicode compatibility-normalised (full-width 'CAROL' becomes 'CAROL'; a Cyrillic 'a' does not)."""
    import unicodedata
    return unicodedata.normalize("NFKC", str(who)).isascii()


def _name_key(who):
    """A name as the one-challenge-per-name rule compares it: Unicode compatibility form, case-folded, whitespace and punctuation removed, common ASCII lookalikes folded (0/o, 1/l/i, 5/s, 3/e, 4/a,
    8/b, @/a, $/s). 'Carol', 'carol ', ' CAROL', 'c4r0l' and 'car-o1' are one name. A heuristic: it can fold two different honest names together (a second challenger then files under another)."""
    import unicodedata
    text = unicodedata.normalize("NFKC", str(who)).casefold().translate(_LOOKALIKES)
    return "".join(ch for ch in text if ch.isalnum())
SPEC_KEYS = {"sponsor", "domain", "plan_hash", "commit", "amount_cents", "currency", "min_factor", "min_solve_rate", "min_stratified_rate", "claim_deadline", "challenge_days", "practice_allowed", "note",
             "round_id", "allow_unbound_ladders", "require_signed_claims", "payee_pubkeys", "round_head", "allow_unpinned_round_head", "challenger_pubkeys"}


class BountyError(Exception):
    pass


# ---- ledger ------------------------------------------------------------------------------------------------------------------------------------------

def read(path):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        try:
            rows = [json.loads(ln) for ln in f.read().split("\n") if ln.strip()]
        except ValueError:
            raise BountyError("%s is not a JSON-lines ledger" % path)
    if not all(isinstance(r, dict) for r in rows):
        raise BountyError("%s holds a line that is not an object" % path)
    return rows


def sign_head(path, secret, now=None):
    """A signed statement of the ledger's current head. Give it to every party: a later rewrite of the ledger (even one with a consistent chain) will no longer contain it."""
    ok, _head, probs = verify_ledger(path)
    if not ok:
        raise BountyError("the ledger does not verify (%s): not signing it" % "; ".join(probs))
    return agent_sig.sign_head(read(path), secret, "bounty-ledger", now)


def check_head(path, signed, trusted):
    """(ok, message): the ledger verifies AND extends the signed head (signed by a key in `trusted`)."""
    ok, _head, probs = verify_ledger(path)
    if not ok:
        return False, "the ledger does not verify: " + "; ".join(probs)
    return agent_sig.check_head(read(path), signed, trusted, "bounty-ledger")


def verify_ledger(path):
    """(ok, head, problems). The chain detects any edit, reordering or truncation in the middle of a ledger whose head someone else holds. It is NOT a signature: whoever controls the file can rewrite
    the WHOLE chain consistently, so both parties (and anyone who relies on it) should keep or publish the head hash they last saw, and treat a head that changed without a new entry as tampering."""
    prev, probs = agent_core.CHAIN_START, []
    try:
        rows = read(path)
    except BountyError as e:
        return False, prev, [str(e)]
    for i, row in enumerate(rows):
        entry = {k: v for k, v in row.items() if k not in ("prev", "h")}
        if row.get("prev") != prev or row.get("h") != sha256_hex(prev + canon(entry)) or entry.get("index") != i or entry.get("format") != FORMAT:
            probs.append("entry %d does not chain" % i)
            break
        prev = row["h"]
    return not probs, prev, probs


def _append(path, entry, now):
    import fcntl
    # one writer at a time: two concurrent appends would both chain to the same head and fork the ledger (every later append then refuses)
    lock_fd = os.open(path + ".lock", os.O_CREAT | os.O_RDWR, 0o644)
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        ok, head, probs = verify_ledger(path)
        if not ok:
            raise BountyError("the ledger does not verify (%s): refusing to extend it" % "; ".join(probs))
        entry = dict(entry, format=FORMAT, index=len(read(path)), at=int(now))
        row = dict(entry, prev=head, h=sha256_hex(head + canon(entry)))
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
        with os.fdopen(fd, "a", encoding="utf-8") as f:
            f.write(canon(row) + "\n")
            f.flush()
            os.fsync(f.fileno())
        return row
    finally:
        fcntl.flock(lock_fd, fcntl.LOCK_UN)
        os.close(lock_fd)


def state(path, bounty_id):
    """Replay the ledger for one bounty. Returns a dict with status and the facts the rules need. Refuses a ledger whose chain does not verify: nothing is decided from entries that were edited."""
    ok, _head, probs = verify_ledger(path)
    if not ok:
        raise BountyError("the ledger does not verify (%s)" % "; ".join(probs))
    s = {"spec": None, "funded": False, "claims": [], "verdicts": {}, "open_challenges": 0, "status": "unknown", "settled": None, "refunded": False, "overturned": set(),
         "challenge_names": [], "challenge_keys": [], "open_queue": []}
    for row in read(path):
        if row.get("bounty") != bounty_id:
            continue
        try:
            k = row["kind"]
            if k == "post":
                s["spec"], s["status"] = row["spec"], "posted"
            elif k == "fund":
                s["funded"], s["escrow_ref"], s["status"] = True, row["escrow_ref"], "open"
            elif k == "claim":
                s["claims"].append(row)
            elif k == "verdict":
                s["verdicts"][row["claim_index"]] = row
            elif k == "challenge":
                s["challenge_names"].append(row.get("by"))
                if row.get("challenger_pubkey") and check_challenge_signature({"challenger_pubkeys": [row["challenger_pubkey"]]}, row)[0]:
                    s["challenge_keys"].append(row["challenger_pubkey"])    # only a VALIDLY signed row uses up a key: a forged row naming someone's key must not burn their one challenge
                if row.get("ground", "other") != "verification":           # a ledger from before grounds existed has none: those were all blocking
                    if check_challenge_signature(s["spec"] or {}, row)[0]:     # a bounty that pins challengers is only blocked by a challenge SIGNED by one: the ledger is a hash chain, so
                        s["open_challenges"] += 1                              # anyone holding the file can append a well-formed row, and must not be able to freeze the bounty with it
                        s["open_queue"].append(row.get("by"))
                    else:
                        s.setdefault("ignored_challenges", []).append(row.get("by"))
            elif k == "resolve":
                s["open_challenges"] = max(0, s["open_challenges"] - 1)
                if s["open_queue"]:
                    s["open_queue"].pop(0)                                 # resolutions close the oldest blocking challenge first
                if row.get("overturn_claim") is not None:
                    s["overturned"].add(row["overturn_claim"])
            elif k == "settle":
                s["settled"], s["status"] = row, "settled"
            elif k == "refund":
                s["refunded"], s["status"] = True, "refunded"
        except (KeyError, TypeError):
            raise BountyError("ledger entry %s is malformed" % row.get("index"))
    return s


def post(path, bounty_id, spec, now):
    need = ("sponsor", "domain", "plan_hash", "commit", "amount_cents", "currency", "claim_deadline", "challenge_days")
    miss = [k for k in need if k not in spec]
    if miss:
        raise BountyError("spec lacks %s" % ", ".join(miss))
    if not isinstance(spec["amount_cents"], int) or isinstance(spec["amount_cents"], bool) or spec["amount_cents"] <= 0:
        raise BountyError("amount_cents must be a positive integer (money is never a float)")
    if not any(spec.get(k) is not None for k in ("min_factor", "min_solve_rate", "min_stratified_rate")):
        raise BountyError("a bounty needs at least one threshold: min_factor, min_solve_rate or min_stratified_rate")
    if not (isinstance(spec["plan_hash"], str) and len(spec["plan_hash"]) == 64):
        raise BountyError("plan_hash must be the 64-hex hash of the published plan")
    if spec.get("require_signed_claims") is not None and not isinstance(spec["require_signed_claims"], bool):
        raise BountyError("require_signed_claims must be true or false")
    pk = spec.get("payee_pubkeys")
    if pk is not None:
        if not spec.get("require_signed_claims") or not isinstance(pk, list) or not pk or not all(isinstance(k, str) and len(k) == 64 and all(c in "0123456789abcdef" for c in k) for k in pk):
            raise BountyError("payee_pubkeys must be a non-empty list of 64-hex Ed25519 public keys, and needs require_signed_claims")
    ck = spec.get("challenger_pubkeys")
    if ck is not None and (not isinstance(ck, list) or not ck or not all(isinstance(k, str) and len(k) == 64 and all(c in "0123456789abcdef" for c in k) for k in ck)):
        raise BountyError("challenger_pubkeys must be a non-empty list of 64-hex Ed25519 public keys")
    unknown = sorted(set(spec) - SPEC_KEYS)
    if unknown:
        raise BountyError("unknown spec field(s) %s: a requirement this module does not enforce must not look like one (allowed: %s)" % (", ".join(unknown), ", ".join(sorted(SPEC_KEYS))))
    for k in ("claim_deadline", "challenge_days"):
        if not agent_core._is_int(spec[k], 0, 10 ** 10):
            raise BountyError("%s must be a non-negative integer" % k)
    if spec.get("min_factor") is not None and not (isinstance(spec["min_factor"], (int, float)) and not isinstance(spec["min_factor"], bool) and spec["min_factor"] > 0):
        raise BountyError("min_factor must be a positive number")
    for k in ("min_solve_rate", "min_stratified_rate"):
        if spec.get(k) is not None and not (isinstance(spec[k], (int, float)) and not isinstance(spec[k], bool) and 0 < spec[k] <= 1):
            raise BountyError("%s must be in (0, 1]" % k)
    for k in ("sponsor", "domain", "currency", "commit"):
        if not isinstance(spec[k], str) or not spec[k]:
            raise BountyError("%s must be a non-empty string" % k)
    rh = spec.get("round_head")
    if rh is not None and not (isinstance(rh, str) and len(rh) == 64 and all(c in "0123456789abcdef" for c in rh) and spec.get("round_id")):
        raise BountyError("round_head must be the 64-hex log head the operator published, and needs round_id")
    if spec.get("round_id") and not rh and not spec.get("practice_allowed") and not spec.get("allow_unpinned_round_head"):
        raise BountyError("a real bounty on a round must pin a published log head (round_head), or explicitly set allow_unpinned_round_head: otherwise a rewritten log could back-date a ladder built after the reveal")
    if spec.get("round_id") is not None and not (isinstance(spec["round_id"], str) and 2 <= len(spec["round_id"]) <= 41):
        raise BountyError("round_id must be the id of the agent round (agent_rounds.py) the claims are judged in")
    if spec.get("allow_unbound_ladders") is not None and not isinstance(spec["allow_unbound_ladders"], bool):
        raise BountyError("allow_unbound_ladders must be true or false")
    if not spec.get("round_id") and not spec.get("practice_allowed") and not spec.get("allow_unbound_ladders"):
        raise BountyError("a real bounty must name the agent round its claims are judged in (round_id): otherwise anyone can win it AFTER the reveal with an agent that just re-derives "
                          "the answers. For a demo, set allow_unbound_ladders (or practice_allowed) explicitly.")
    if state(path, bounty_id)["spec"] is not None:
        raise BountyError("bounty %r already exists" % bounty_id)
    return _append(path, {"kind": "post", "bounty": bounty_id, "spec": dict(spec, practice_allowed=bool(spec.get("practice_allowed", False)))}, now)


def fund(path, bounty_id, escrow_ref, now):
    s = state(path, bounty_id)
    if s["spec"] is None or s["funded"]:
        raise BountyError("bounty is unknown or already funded")
    if not escrow_ref or not isinstance(escrow_ref, str):
        raise BountyError("record the escrow provider's reference for the held funds")
    return _append(path, {"kind": "fund", "bounty": bounty_id, "escrow_ref": escrow_ref}, now)


def _claim_payload(bounty_id, claimant, claim_sha, base_sha, cand_sha):
    return {"format": "guldo-bounty-claim-v1", "bounty": bounty_id, "claimant": claimant, "claim_sha": claim_sha, "base_sha": base_sha, "cand_sha": cand_sha}


def check_claim_signature(spec, row):
    """(ok, text). If the bounty requires signed claims, the claim must carry an Ed25519 signature over its own contents by `claimant_pubkey`, and when the spec pins `payee_pubkeys` the key must be
    one of them. This authenticates that the claimant CONTROLS a key; whether that key belongs to the party who really submitted the configuration is what `payee_pubkeys` (pinned by the sponsor
    out of band, e.g. from the entry form) is for. Without it a key proves only 'the same party filed this and will be paid'."""
    if not spec.get("require_signed_claims"):
        return True, "signatures not required by this bounty"
    pub, sig = row.get("claimant_pubkey"), row.get("claim_sig")
    try:
        payload = _claim_payload(row["bounty"], row["claimant"], row["claim_sha"], row["base_sha"], row["cand_sha"])
        good = agent_sig.verify(bytes.fromhex(pub), canon(payload).encode("utf-8"), bytes.fromhex(sig))
    except (TypeError, ValueError, KeyError):
        good = False
    if not good:
        return False, "the claim is not signed by a valid key"
    if spec.get("payee_pubkeys") and pub not in spec["payee_pubkeys"]:
        return False, "the claim's key is not one of the payee keys the sponsor pinned"
    return True, "the claim is signed by %s...%s" % (pub[:12], " (a pinned payee key)" if spec.get("payee_pubkeys") else "")


def claim(path, bounty_id, claimant, claim_file, base_ladder, cand_ladder, now, secret=None):
    s = state(path, bounty_id)
    if not s["funded"] or s["status"] in ("settled", "refunded"):
        raise BountyError("the bounty is not open for claims")
    if now > s["spec"]["claim_deadline"]:
        raise BountyError("the claim deadline has passed")
    for f in (claim_file, base_ladder, cand_ladder):
        if not os.path.isfile(f):
            raise BountyError("%s is not a file" % f)
    entry = {"kind": "claim", "bounty": bounty_id, "claimant": claimant, "claim_sha": agent_core.file_sha256(claim_file), "base_sha": agent_core.file_sha256(base_ladder),
             "cand_sha": agent_core.file_sha256(cand_ladder)}
    if secret is not None:
        payload = _claim_payload(bounty_id, claimant, entry["claim_sha"], entry["base_sha"], entry["cand_sha"])
        entry["claimant_pubkey"] = agent_sig.public_key(secret).hex()
        entry["claim_sig"] = agent_sig.sign(secret, canon(payload).encode("utf-8")).hex()
    ok, why = check_claim_signature(s["spec"], entry)
    if not ok:
        raise BountyError("this bounty requires a signed claim: " + why)
    return _append(path, entry, now)


# ---- the machine-checked settlement condition ---------------------------------------------------------------------------------------------------------

def evaluate_claim(spec, claim_file, base_ladder, cand_ladder, master, row=None, round_base=None):
    """Returns (passed, lines). Every line is a check that must hold; the claim passes only if all do. `row` (the ledger's claim entry) pins the files by hash if given.
    `round_base` is the directory holding the round (agent_rounds.py) the bounty names with `round_id`: the ladders must then be ones that round's log recorded BEFORE its reveal.
    Never raises on damaged input: a file that cannot be read or parsed is a FAIL line."""
    try:
        return _evaluate_claim(spec, claim_file, base_ladder, cand_ladder, master, row, round_base)
    except (agent_core.AgentEvalError, agent_compare.CompareError, KeyError, TypeError, ValueError, AttributeError, IndexError, OverflowError, OSError) as e:
        return False, ["FAIL: the claim could not be evaluated (%s: %s)" % (type(e).__name__, str(e)[:160])]


def _round_binding(spec, base_ladder, cand_ladder, row, round_base, need):
    """Once the seed is revealed ANYONE can write an agent that re-derives every instance and submits the answer in one turn: its ladder verifies perfectly and beats any token claim. A ladder is
    therefore only evidence if it was recorded BEFORE the reveal. The round's hash-chained log is that record: both ladders' digests and file hashes must be in `evaluated` entries that
    precede the `revealed` entry, the round must verify, and the claimant must be the entrant of the winning configuration. (The log's head should have been published earlier: see agent_rounds.)"""
    import agent_rounds as AR
    import rounds as R
    rid = spec.get("round_id")
    if not rid:
        if spec.get("allow_unbound_ladders") and not spec.get("practice_allowed"):
            need(True, "the sponsor EXPLICITLY allowed ladders not bound to a round (allow_unbound_ladders): any ladder built after the seed was public qualifies; use this only for a demo")
            return
        need(bool(spec.get("practice_allowed")), "the bounty names a round (round_id): without one a ladder built AFTER the seed is public (an agent that just re-derives the answers) would win it")
        return
    if round_base is None:
        need(False, "the round's files were supplied (the bounty names round %s)" % rid)
        return
    head = spec.get("round_head")
    if head:
        need(True, "the bounty pins a log head the operator published before the reveal (round_head): the round's log must contain it")
    elif spec.get("practice_allowed") or spec.get("allow_unpinned_round_head"):
        need(True, "NOTE: no round_head is pinned (practice bounty or an explicit opt-out): whoever controls the round's files could rewrite its whole hash chain and back-date an entry for a ladder built after the reveal")
    else:
        need(False, "the bounty pins a published log head (round_head): without one a self-consistent REWRITE of the round's log (a fake pre-reveal entry for a ladder built after the reveal) cannot be detected")
        return
    probs = AR.verify_round(round_base, rid, expected_head=head or None)
    need(not probs, "the round's own files verify (%s)" % (probs[0] if probs else "log chain, pins, entries, ladders, seed, results"))
    if probs:
        return
    d = AR.rdir(round_base, rid)
    r = R._read_json(os.path.join(d, "round.json"))
    need(r["plan_hash"] == spec["plan_hash"] and r["commitment"] == spec["commit"], "the round is the bounty's plan and seed commitment")
    log = R.read_log(d)
    revealed = next((e["seq"] for e in log if e["kind"] == "revealed"), None)
    need(revealed is not None, "the round has been revealed")
    for name, path in (("baseline", base_ladder), ("candidate", cand_ladder)):
        h, recs = agent_core.read_ladder(path)
        dig, sha = agent_compare.ladder_digest(h, recs), agent_core.file_sha256(path)
        hit = next((e for e in log if e["kind"] == "evaluated" and e["data"]["digest"] == dig and e["data"]["ladder_sha256"] == sha), None)
        need(hit is not None and revealed is not None and hit["seq"] < revealed, "the %s ladder is one the round's log recorded before the reveal" % name)
        if name == "candidate" and hit is not None and row is not None:
            entry = R._read_json(os.path.join(d, "entries", hit["data"]["eid"] + ".json")) if hit["data"]["eid"] != "baseline" else None
            need(entry is not None and entry.get("handle") == row.get("claimant"), "the claimant is the entrant who submitted the winning configuration")


def _evaluate_claim(spec, claim_file, base_ladder, cand_ladder, master, row=None, round_base=None):
    lines, ok = [], True

    def need(cond, text):
        nonlocal ok
        lines.append(("PASS: " if cond else "FAIL: ") + text)
        ok = ok and bool(cond)
    if row is not None:
        need(agent_core.file_sha256(claim_file) == row["claim_sha"] and agent_core.file_sha256(base_ladder) == row["base_sha"] and agent_core.file_sha256(cand_ladder) == row["cand_sha"],
             "the files are the ones the claim entry pinned by hash")
        sig_ok, sig_why = check_claim_signature(spec, row)
        need(sig_ok, sig_why)
    with open(claim_file, "r", encoding="utf-8") as f:
        res = json.load(f)
    bh, br = agent_core.read_ladder(base_ladder)
    ch, cr = agent_core.read_ladder(cand_ladder)
    need(bh.get("plan_hash") == spec["plan_hash"] and ch.get("plan_hash") == spec["plan_hash"], "both ladders are bound to the bounty's plan hash")
    need(bh.get("commit") == spec["commit"] and ch.get("commit") == spec["commit"], "both ladders carry the bounty's seed commitment")
    need(bh.get("domain") == spec["domain"], "the domain is the bounty's domain")
    need(spec.get("practice_allowed") or not bh.get("practice"), "not a practice-seed run")
    need(agent_core.commitment(master) == spec["commit"], "the revealed seed matches the commitment")
    _round_binding(spec, base_ladder, cand_ladder, row, round_base, need)
    for name, path in (("baseline", base_ladder), ("candidate", cand_ladder)):
        probs, _ = agent_eval.verify_ladder(path, master, None, spec["plan_hash"], True)
        need(not probs, "%s ladder re-verified from the seed (%s)" % (name, ("%d problems: %s" % (len(probs), "; ".join(probs[:2]))) if probs else "every record consistent and correct"))
    try:
        again = agent_compare.compare(bh, br, ch, cr)
        # `agent_eval.py compare --out` adds a `reverified` note to the file it writes; it is not part of the comparison, so compare without it (otherwise no normally made claim file could ever pass)
        need(canon(again) == canon({k: v for k, v in res.items() if k != "reverified"}), "the comparison file is exactly what recomputation gives")
    except agent_compare.CompareError as e:
        need(False, "comparison could not be recomputed: %s" % e)
        again = res
    rows = agent_compare.claim_check(again, spec.get("min_factor"), spec.get("min_solve_rate"), spec.get("min_stratified_rate"))
    for text, good in rows:
        need(good, text)
    return ok, lines


def record_verdict(path, bounty_id, claim_index, passed, lines, now):
    s = state(path, bounty_id)
    if s["status"] != "open" or not agent_core._is_int(claim_index, 0) or claim_index >= len(s["claims"]):
        raise BountyError("no such claim on an open bounty")
    if claim_index in s["verdicts"]:
        raise BountyError("claim %d already has a verdict; a verdict is never overwritten" % claim_index)
    return _append(path, {"kind": "verdict", "bounty": bounty_id, "claim_index": claim_index, "passed": bool(passed), "lines": lines[:40]}, now)


def _challenge_payload(bounty_id, who, reason, ground):
    return {"format": "guldo-bounty-challenge-v1", "bounty": bounty_id, "by": who, "reason_sha256": sha256_hex(reason[:500].encode("utf-8")), "ground": ground}


def challenge(path, bounty_id, who, reason, evidence_sha, now, ground="other", secret=None):
    """Object to a bounty. A challenge on ground "verification" (the claim does not verify) is recorded and never blocks, because `settle` re-runs the whole check anyway and that decides it. Any other
    ground blocks until a human resolves it, and then:

      * IF THE SPONSOR PINNED `challenger_pubkeys` (the people allowed to object, agreed out of band) a blocking challenge must be SIGNED (`secret`) by one of those keys, one per key: inventing names no
        longer works, because a name is not an identity here, a pinned key is. This is the real answer to "anyone can freeze it".
      * WITHOUT pinned keys the ledger cannot tell who `who` is, so the limits do not rest on identity: a name may challenge ONCE (compared after Unicode normalisation, case-folding, and folding of
        common lookalikes such as 0/o and 1/l/i; non-ASCII names are refused, which is what stops a Cyrillic 'a'), at most MAX_OPEN_CHALLENGES block at a time, at most MAX_RECORDED_CHALLENGES are
        recorded, and none is accepted after the window of a passing claim has closed. Someone willing to invent ASCII names unlike each other can still hold a bounty for the window and cost the resolver
        up to MAX_OPEN_CHALLENGES decisions: bounded, not prevented. The lookalike folding can refuse a second honest name that happens to fold the same: that person files under another name."""
    if ground not in GROUNDS:
        raise BountyError("a challenge's ground is one of %s" % ", ".join(GROUNDS))
    if not isinstance(reason, str) or not reason.strip():
        raise BountyError("a challenge needs a reason (what is wrong, in words)")
    s = state(path, bounty_id)
    if s["status"] != "open":
        raise BountyError("no open bounty to challenge")
    if not isinstance(who, str) or not _name_key(who):
        raise BountyError("a challenge needs a name")
    pinned = s["spec"].get("challenger_pubkeys")
    entry_extra = {}
    if pinned and ground != "verification":
        if secret is None:
            raise BountyError("this bounty pins its challengers: a blocking challenge must be signed by one of their keys (--key)")
        pub = agent_sig.public_key(secret).hex()
        if pub not in pinned:
            raise BountyError("this key is not one of the challenger keys the sponsor pinned")
        if pub in s["challenge_keys"]:
            raise BountyError("this key has already challenged this bounty: one challenge per key")
        entry_extra = {"challenger_pubkey": pub, "challenge_sig": agent_sig.sign(secret, canon(_challenge_payload(bounty_id, who, reason, ground)).encode("utf-8")).hex()}
    if not pinned or ground == "verification":                       # anything that is not signed by a pinned key is only as good as its name
        if not unicodedata_ascii(who):
            raise BountyError("challenge names must be ASCII (after normalisation): the ledger cannot tell lookalike letters from other scripts apart")
        if _name_key(who) in {_name_key(n) for n in s["challenge_names"]}:
            raise BountyError("%s has already challenged this bounty: one challenge per name, however it is capitalised, spaced or spelt with lookalike characters (put every objection in one reason)" % who)
    if len(s["challenge_names"]) >= MAX_RECORDED_CHALLENGES:
        raise BountyError("this bounty already has %d recorded challenges: no more are accepted" % len(s["challenge_names"]))
    window = s["spec"]["challenge_days"] * DAY
    for i, v in s["verdicts"].items():
        if v["passed"] and i not in s["overturned"] and now >= v["at"] + window:
            raise BountyError("the challenge window for the passing claim ended at %d: too late to object" % (v["at"] + window))
    if ground != "verification" and s["open_challenges"] >= MAX_OPEN_CHALLENGES:
        raise BountyError("%d challenges are already open on this bounty: they must be resolved before another can be filed" % s["open_challenges"])
    return _append(path, dict({"kind": "challenge", "bounty": bounty_id, "by": who, "reason": reason[:500], "evidence_sha": evidence_sha, "ground": ground}, **entry_extra), now)


def check_challenge_signature(spec, row):
    """(ok, text) for a recorded blocking challenge under a spec that pins `challenger_pubkeys`: signed over its own contents by a pinned key. Used by `verify_challenges`."""
    if not spec.get("challenger_pubkeys") or row.get("ground") == "verification":
        return True, "no signature required"
    pub, sig = row.get("challenger_pubkey"), row.get("challenge_sig")
    try:
        good = agent_sig.verify(bytes.fromhex(pub), canon(_challenge_payload(row["bounty"], row["by"], row.get("reason", ""), row.get("ground", "other"))).encode("utf-8"), bytes.fromhex(sig))
    except (TypeError, ValueError, KeyError):
        good = False
    if not good:
        return False, "the challenge is not signed by a valid key"
    if pub not in spec["challenger_pubkeys"]:
        return False, "the challenge's key is not one the sponsor pinned"
    return True, "signed by pinned key %s..." % pub[:12]


def resolve(path, bounty_id, arbiter, outcome, now, overturn_claim=None):
    s = state(path, bounty_id)
    if s["open_challenges"] < 1:
        raise BountyError("no open challenge")
    return _append(path, {"kind": "resolve", "bounty": bounty_id, "arbiter": arbiter, "outcome": outcome[:500], "overturn_claim": overturn_claim}, now)


def settlement_ready(path, bounty_id, now):
    """(claim_index or None, reason). The oldest passing, un-overturned claim whose challenge window has elapsed, with no open challenge."""
    s = state(path, bounty_id)
    if s["status"] != "open":
        return None, "bounty is %s" % s["status"]
    if s["open_challenges"]:
        return None, "an open challenge blocks settlement"
    window = s["spec"]["challenge_days"] * DAY
    for i, v in sorted(s["verdicts"].items()):
        if v["passed"] and i not in s["overturned"]:
            if now < v["at"] + window:
                return None, "the challenge window ends at %d" % (v["at"] + window)
            return i, "ok"
    return None, "no passing claim"


def settle(path, bounty_id, now, recheck=None):
    """`recheck`, if given, is a callable (claim_row) -> (passed, lines) that RE-RUNS evaluate_claim at settlement time; settling then needs it to pass again. The CLI always supplies it, so a verdict
    line written into the ledger without the computation having run cannot release money."""
    i, why = settlement_ready(path, bounty_id, now)
    if i is None:
        raise BountyError("cannot settle: " + why)
    s = state(path, bounty_id)
    c = s["claims"][i]
    sig_ok, sig_why = check_claim_signature(s["spec"], c)
    if not sig_ok:
        raise BountyError("cannot settle: " + sig_why)
    if recheck is not None:
        ok, lines = recheck(c)
        if not ok:
            raise BountyError("the claim no longer passes when re-evaluated now: " + "; ".join(x for x in lines if x.startswith("FAIL"))[:300])
    return _append(path, {"kind": "settle", "bounty": bounty_id, "claim_index": i, "to": c["claimant"], "to_pubkey": c.get("claimant_pubkey"), "amount_cents": s["spec"]["amount_cents"],
                          "currency": s["spec"]["currency"], "escrow_ref": s["escrow_ref"]}, now)


def refund(path, bounty_id, now):
    s = state(path, bounty_id)
    if s["status"] != "open":
        raise BountyError("bounty is %s" % s["status"])
    if now <= s["spec"]["claim_deadline"]:
        raise BountyError("the claim deadline has not passed")
    i, why = settlement_ready(path, bounty_id, now)
    if i is not None or why.startswith("the challenge window") or why.startswith("an open challenge"):
        raise BountyError("a claim is still live (%s)" % why)
    waiting = [k for k in range(len(s["claims"])) if k not in s["verdicts"] and k not in s["overturned"]]
    if waiting:
        raise BountyError("claim(s) %s were filed in time and have no verdict yet: evaluate them before refunding the sponsor" % waiting)
    return _append(path, {"kind": "refund", "bounty": bounty_id, "to": s["spec"]["sponsor"], "amount_cents": s["spec"]["amount_cents"], "currency": s["spec"]["currency"], "escrow_ref": s["escrow_ref"]}, now)


class ManualRail:
    """What a human must do. A real payment provider would implement `release` and `refund` against its API; none is built."""

    @staticmethod
    def instructions(row):
        verb = "RELEASE" if row["kind"] == "settle" else "RETURN"
        return ("%s %d.%02d %s held under escrow reference %s to %s; then record the provider's confirmation outside this ledger. "
                "BEFORE paying, confirm by other means that %s really is the party who submitted this configuration: the ledger records the name a claim was filed under and cannot check who filed it "
                "(published ladders can be copied, so anyone could file a valid-looking claim for someone else's result)." % (
                    verb, row["amount_cents"] // 100, row["amount_cents"] % 100, row["currency"], row["escrow_ref"], row["to"], row["to"]))
