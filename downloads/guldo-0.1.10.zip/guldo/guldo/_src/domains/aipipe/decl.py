"""Declaration of a PIPELINE-parallelism domain: push a batch through an 8-layer network whose layers live on 8 devices, with as little time as the machine allows.

size = d. The network has 8 layers h_{l+1} = relu(h_l W_l) with W_l of shape d x d (scaled by sqrt(6/d), so activations keep their size), applied to a batch of B = 64 vectors X (B x d). X and W_0 .. W_7 are the
SplitMix64 stream under `seed` (tensorops.stream, the same floats as domains/aiinfer), X first, then each W_l row-major. The answer is the final activations (B x d, row-major) as a flat list of B*d INTEGERS in
units of 2^-30; the judge recomputes them in float64 and accepts an answer within 3e-9 in every entry. A layer left out, a microbatch dropped or reordered, or a stale activation fails the check.

Pipeline parallelism puts one layer on each device and streams the batch through in MICROBATCHES: while stage s works on microbatch j, stage s+1 works on microbatch j-1. With m microbatches and P = 8 stages the
whole thing takes m + P - 1 steps of one microbatch's work instead of P * m, so the speedup over one device is P*m / (m + P - 1): the "bubble" (the first and last steps, when most stages idle) is what limits it,
and more microbatches shrink the bubble but add messages (one hand-off per step). With m = 1 nothing overlaps at all. That trade, and where it pays, is what this domain measures.

The cost compared is the one of tflops_dist.py (tensorops_dist.py defines the machine): critical-path work, message rounds and bytes per device, from which the time on ANY interconnect is exact. The hand-off between
stages is tp.exchange (one superstep, one round, the activations of one microbatch). An accounting convention over identical devices and links, with a barrier at every exchange: it models the pipeline as a
sequence of supersteps (the standard schedule), not a measurement of any cluster.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aipipe"
VERSION = "aipipe-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 48)
SIZE_STEP = 16
REFERENCE_SOLVER = "reference.py"
RANKS = 8                     # devices = pipeline stages = layers
LAYERS = 8
BATCH = 64
SCALE = 2 ** 30
LIMIT = 2 ** 62
TOL = 3e-9
DOC = ("solve(seed, d, B, P): X (B x d) and W_0 .. W_7 (each d x d, times sqrt(6/d)) are the SplitMix64 stream under `seed` (tensorops.stream, u in [-1, 1), row-major; X first, then W_0 .. W_7; B = 64, P = 8 devices). "
       "Run h = X; for l = 0..7: h = relu(h W_l). Return h (B x d, row-major) as a flat list of B*d integers in units of 2^-30, each within 3e-9. Return None for no answer.")
REFERENCE_NOTE = ("One device does all 8 layers on the whole batch: no communication, all the arithmetic on device 0. Known to be beaten, on a machine whose network is fast enough, by a pipeline: one layer per device, "
                  "the batch split into microbatches that overlap.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def forward(seed, d):
    h = _uniform(seed, 0, BATCH * d).reshape(BATCH, d)
    for l in range(LAYERS):
        W = _uniform(seed, BATCH * d + l * d * d, d * d).reshape(d, d) * math.sqrt(6.0 / d)
        h = np.maximum(h @ W, 0.0)
    return h


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aipipe-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, BATCH, RANKS], "planted": [int(v) for v in np.rint(forward(seed, size).ravel() * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, d, B, P = inst["args"]
    if not isinstance(ans, list) or len(ans) != B * d:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    got = np.array(ans, dtype=np.float64) / SCALE
    return bool(np.max(np.abs(got - forward(seed, d).ravel())) <= TOL)
