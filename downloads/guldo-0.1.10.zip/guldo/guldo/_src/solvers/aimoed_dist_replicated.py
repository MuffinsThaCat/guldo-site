"""aimoed in the cluster-counted API, the data-parallel way: every device regenerates ALL eight experts and runs its own T/8 tokens through them, no communication at all. It is the obvious thing and it does not fit: eight experts' weights plus the working set pass the device capacity, so the run ends with OutOfDeviceMemory."""
import math

import tensorops as tp

E = 8
BIAS = (0.0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9, 1.05)


def ints(Y):
    return list(map(int, (Y * 1073741824.0).tolist()))


def expert_weights(seed, d, T, e):
    o = T * d + d * E + e * 4 * d * d
    W1 = tp.reshape(tp.stream(seed, o, 2 * d * d), (d, 2 * d)) * math.sqrt(6.0 / d)
    W2 = tp.reshape(tp.stream(seed, o + 2 * d * d, 2 * d * d), (2 * d, d)) * math.sqrt(3.0 / (2 * d))
    return W1, W2


def route_ids(x, R, bias):
    """The expert of each row of x: argmax of the scores plus the bias (lowest index on ties), as a Python list."""
    rows = (x @ R + bias).tolist()
    return [row.index(max(row)) for row in rows]


def solve(seed, d, T, P):
    shard = T // P
    outs = []
    for i in range(P):
        tp.use(i)
        x = tp.reshape(tp.stream(seed, i * shard * d, shard * d), (shard, d))
        R = tp.reshape(tp.stream(seed, T * d, d * E), (d, E)) * math.sqrt(3.0 / d)
        e_of = route_ids(x, R, tp.reshape(tp.tensor(list(BIAS)), (1, E)))
        ws = [expert_weights(seed, d, T, e) for e in range(E)]
        rows = []
        for t in range(shard):
            W1, W2 = ws[e_of[t]]
            rows.append(tp.relu(x[t:t + 1] @ W1) @ W2)
        outs.append(tp.reshape(tp.concat(rows, 0), (shard * d,)))
    return ints(tp.all_gather(outs)[0])
