"""Reference for airealm: the dense network on the noisy batch, float64, one batched product per layer."""
import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


NOISE = {64: 64.0, 128: 64.0, 192: 64.0, 256: 76.0, 512: 84.0, 1024: 96.0}     # per width, as in decl.py


def solve(H, Q, seed, X, W1, b1, W2, b2):
    v = np.asarray(X, dtype=np.float64) + NOISE[H] * _uniform(seed, 0, Q * 784).reshape(Q, 784)
    x = (np.maximum(v, 0.0) - np.maximum(v - 255.0, 0.0)) / 255.0
    return [int(t) for t in np.argmax(np.maximum(x @ np.asarray(W1).T + np.asarray(b1), 0.0) @ np.asarray(W2).T + np.asarray(b2), axis=1)]
