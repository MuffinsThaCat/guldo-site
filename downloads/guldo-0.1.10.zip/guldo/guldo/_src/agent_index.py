"""A queryable index of verified agent certificates, and routing by certified success rate and cost: "the certificate is the resume".

  build_entry(ladder_path, master)       verifies the ladder from the revealed seed (the whole check: re-derive, re-verify, replay tools, recompute cost, chains) and turns it into an index entry.
                                         A ladder that does not verify is REFUSED, never indexed with a warning.
  Index.add / save / load / digest      a JSON file with its own hash; entries are keyed by the ladder digest so the same ladder cannot be listed twice.
  query(...)                            filter by domain, size, agent kind, minimum bounds, maximum unsafe rate, age.
  route(domain, size, ...)              rank the agents that clear a stated bar at THAT size by median tokens on solved instances (cheapest first); each row says why it qualifies.

What an entry means. "On this committed plan, at this size, this agent configuration solved at least R of the instances (exact one-sided 95% lower bound, n instances) at a median of T proxy tokens."
It is a statement about the tested generator at the tested sizes and a particular configuration on a particular date. Routing a different task to it extends that outside what was measured; the router
cannot know that, so every route result repeats it. Practice-seed entries and scripted stand-ins are excluded unless asked for, models change under the same name (use `max_age_days`), and a
certificate is not a trust decision by itself: the caller decides what a failure costs. Counts in the index are proxy tokens unless the ladder was converted with agent_attest.convert.
"""
import json
import os
import time

import agent_compare
import agent_core
import agent_eval
import agent_safety
from agent_core import AgentEvalError, canon, sha256_hex

FORMAT = "guldo-agent-index-v1"
NOTE = ("An entry is a statement about the tested generator at the tested sizes, one agent configuration, on the date it was indexed. Routing other work to it goes beyond what was measured.")


def build_entry(ladder_path, master, now=None, plan=None, plan_hash_expected=None):
    probs, _ = agent_eval.verify_ladder(ladder_path, master, plan, plan_hash_expected, True)
    if probs:
        raise AgentEvalError("%s does not verify (%d problems, first: %s): refusing to index it" % (ladder_path, len(probs), probs[0]))
    header, records = agent_core.read_ladder(ladder_path)
    sm = agent_compare.summarize(header, records)
    by_size = []
    for row in sm["by_size"]:
        by_size.append({"size": row["size"], "instances": row["instances"], "solved": row["solved"], "lower95": round(agent_core.cp_lower(row["solved"], row["instances"]), 6),
                        "median_tokens_on_solved": row["median_tokens_on_solved"]})
    entry = {"agent": header["agent"], "domain": header["domain"], "version": header["version"], "plan_hash": header["plan_hash"], "commit": header["commit"], "practice": header["practice"],
             "counter": header["counter"], "sizes": header["sizes"], "n_per_size": header["n_per_size"], "trials": header["trials"], "budget": header["budget"],
             "allow_tools": header.get("allow_tools"), "ladder_digest": agent_compare.ladder_digest(header, records), "ladder_sha256": agent_core.file_sha256(ladder_path),
             "solve_rate_lower95": sm["solve_rate_lower95"], "solve_rate_stratified_lower95": sm["solve_rate_stratified_lower95"], "worst_size_lower95": sm["worst_size_lower95"],
             "median_tokens_on_solved": sm["median_tokens_on_solved"], "by_size": by_size, "verified": True, "indexed_at": int(now if now is not None else time.time())}
    if header.get("cost_unit"):                           # a black-box ladder: its cost is INTERACTION tokens, which must never be ranked against proxy tokens (only present then, so old entries are unchanged)
        entry["cost_unit"], entry["mode"] = header["cost_unit"], header.get("mode")
    if agent_safety.is_safety_domain(header["domain"]):
        s = agent_safety.safety_summary(header, records, master=master)
        entry["safety"] = {"unsafe_trials": s["unsafe_trials"], "trials": s["trials"], "unsafe_rate_upper95": s["unsafe_rate_upper95"]}
    return entry


def validate_entry(e):
    """Refuse an entry with a missing or mistyped field (a self-consistent forged index file must not crash the router or slip a string where a bound belongs)."""
    def bad(m):
        raise AgentEvalError("malformed index entry: " + m)
    if not isinstance(e, dict):
        bad("not an object")
    num = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool) and x == x
    for k, t in (("agent", dict), ("domain", str), ("plan_hash", str), ("ladder_digest", str), ("practice", bool), ("by_size", list), ("sizes", list)):
        if not isinstance(e.get(k), t):
            bad("%r is missing or not a %s" % (k, t.__name__))
    if not _is_int(e.get("indexed_at")):
        bad("indexed_at")
    for k in ("solve_rate_lower95", "solve_rate_stratified_lower95", "worst_size_lower95"):
        if not (num(e.get(k)) and 0 <= e[k] <= 1):
            bad("%r must be a number in [0, 1]" % k)
    if e.get("median_tokens_on_solved") is not None and not num(e["median_tokens_on_solved"]):
        bad("median_tokens_on_solved")
    for r in e["by_size"]:
        if not (isinstance(r, dict) and _is_int(r.get("size")) and _is_int(r.get("instances")) and _is_int(r.get("solved")) and 0 <= r["solved"] <= r["instances"] <= 10 ** 6 and num(r.get("lower95")) and 0 <= r["lower95"] <= 1
                and "median_tokens_on_solved" in r and (r["median_tokens_on_solved"] is None or num(r["median_tokens_on_solved"]))):
            bad("a by_size row is malformed")
        if abs(r["lower95"] - agent_core.cp_lower(r["solved"], r["instances"])) > 1e-5:
            bad("a by_size lower bound is not the Clopper-Pearson bound of its own counts")
    if "cost_unit" in e and not (isinstance(e["cost_unit"], str) and len(e["cost_unit"]) <= 40):
        bad("cost_unit")
    if "safety" in e:
        s = e["safety"]
        if not (isinstance(s, dict) and num(s.get("unsafe_rate_upper95")) and 0 <= s["unsafe_rate_upper95"] <= 1):
            bad("the safety block is malformed")


def _is_int(x):
    return isinstance(x, int) and not isinstance(x, bool)


class Index:
    def __init__(self, entries=None):
        self.entries = list(entries or [])
        for e in self.entries:
            validate_entry(e)

    def recheck(self, entry, ladder_path, master):
        """Re-verify one entry against its ladder file: the ladder must verify from the seed and rebuild EXACTLY this entry (apart from indexed_at). An index entry is otherwise only the word of
        whoever built the index file; this is how a reader stops taking it."""
        fresh = build_entry(ladder_path, master, now=entry.get("indexed_at"))
        a = {k: v for k, v in fresh.items() if k != "indexed_at"}
        b = {k: v for k, v in entry.items() if k != "indexed_at"}
        return canon(a) == canon(b)

    def add(self, entry):
        validate_entry(entry)
        if any(e["ladder_digest"] == entry["ladder_digest"] for e in self.entries):
            raise AgentEvalError("this ladder is already in the index")
        self.entries.append(entry)

    def digest(self):
        return sha256_hex(canon(sorted(self.entries, key=lambda e: e["ladder_digest"])))

    def save(self, path):
        doc = {"format": FORMAT, "note": NOTE, "entries": sorted(self.entries, key=lambda e: e["ladder_digest"])}
        doc["index_sha256"] = sha256_hex(canon(doc))
        tmp = path + ".part"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(json.dumps(doc, indent=1, sort_keys=True) + "\n")
        os.replace(tmp, path)

    @classmethod
    def load(cls, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                doc = json.load(f)
        except ValueError:
            raise AgentEvalError("%s is not JSON" % path)
        if not isinstance(doc, dict) or doc.get("format") != FORMAT:
            raise AgentEvalError("%s is not a %s file" % (path, FORMAT))
        want = doc.pop("index_sha256", None)
        if sha256_hex(canon(doc)) != want:
            raise AgentEvalError("%s: the index hash does not match its content (edited?)" % path)
        if not isinstance(doc.get("entries"), list):
            raise AgentEvalError("the index has no entries list")
        for e in doc["entries"]:
            if not (isinstance(e, dict) and e.get("verified") is True):
                raise AgentEvalError("an entry is not marked verified")
        return cls(doc["entries"])

    def query(self, domain=None, size=None, kind=None, min_lower=None, max_unsafe_upper=None, include_practice=False, include_scripted=False, max_age_days=None, now=None):
        now = int(now if now is not None else time.time())
        out = []
        for e in self.entries:
            if domain and e["domain"] != domain:
                continue
            if e["practice"] and not include_practice:
                continue
            if e["agent"].get("kind") == "scripted" and not include_scripted:
                continue
            if kind and e["agent"].get("kind") != kind:
                continue
            if max_age_days is not None and now - e["indexed_at"] > max_age_days * 86400:
                continue
            if size is not None:
                row = next((r for r in e["by_size"] if r["size"] == size), None)
                if row is None or (min_lower is not None and row["lower95"] < min_lower):
                    continue
            elif min_lower is not None and e["solve_rate_stratified_lower95"] < min_lower:
                continue
            if max_unsafe_upper is not None and ("safety" not in e or e["safety"]["unsafe_rate_upper95"] > max_unsafe_upper):
                continue
            out.append(e)
        return out

    def route(self, domain, size, min_lower=0.8, max_unsafe_upper=None, cost_unit="proxy-tokens", **kw):
        """Qualifying agents at this size, cheapest median tokens first. Returns [(entry, reason)]. Only agents costed in the SAME unit are ranked against each other: black-box agents (interaction
        tokens) are left out of the default ranking, and are ranked among themselves with cost_unit="interaction-tokens"."""
        rows = []
        for e in self.query(domain=domain, size=size, min_lower=min_lower, max_unsafe_upper=max_unsafe_upper, **kw):
            if e.get("cost_unit", "proxy-tokens") != cost_unit:
                continue
            r = next(r for r in e["by_size"] if r["size"] == size)
            tok = r["median_tokens_on_solved"]
            rows.append((tok if tok is not None else float("inf"), e, "solved %d/%d at size %d (95%% lower bound %.3f), median %s proxy tokens, plan %s..." % (r["solved"], r["instances"], size, r["lower95"], tok, e["plan_hash"][:12])))
        rows.sort(key=lambda t: (t[0], t[1]["ladder_digest"]))
        return [(e, why) for _t, e, why in rows]
