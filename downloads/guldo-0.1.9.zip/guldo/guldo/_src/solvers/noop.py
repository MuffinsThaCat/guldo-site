from fpylll import IntegerMatrix  # noqa: F401  (pay the same import cost as real solvers)


def solve(basis, bound2):
    return None
