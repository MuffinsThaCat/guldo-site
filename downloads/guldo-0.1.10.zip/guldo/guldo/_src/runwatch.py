"""A robust way to run a counting child: the same contract as tflops._run_watched, without its deadlock on large instances.

tflops._run_watched hands the instance to the child through a pipe with `Popen.communicate(input=payload, timeout=0.05)` and, after the first timeout, calls `communicate(input=None)`: the unsent rest of
the payload is then never written (the second call does not register stdin for writing), so any instance larger than the pipe buffer (about 16 KB on macOS) deadlocks until the wall-clock kill whenever the child
is slow to start reading (reproduced and measured while building the aireal domain: 16 KB passed, 24 KB did not). tflops.py is pinned by a pre-registration hash and cannot be fixed in place; this module is the
fix for every tool that is not pinned (tflops_par, tflops_dist, tflops_mem, tflops_mem2 use it).

How: the payload goes to an anonymous temporary FILE that becomes the child's stdin, so there is no pipe to fill and no partial write; stdout and stderr are still read concurrently by communicate(), so a large
answer cannot block the child either. The parent-side resident-memory and wall-clock watchdog is unchanged: a child past `max_rss_mb` of resident memory, or past `wall_timeout` seconds, is killed.
"""
import subprocess
import tempfile
import time


def rss_mb(pid):
    """Resident memory of a process in MB, read by the PARENT with `ps` (works on macOS and Linux). 0 when it cannot be read (the process is gone)."""
    try:
        out = subprocess.run(["ps", "-o", "rss=", "-p", str(pid)], capture_output=True, text=True, timeout=5).stdout.strip()
        return int(out) / 1024.0 if out else 0.0
    except (OSError, ValueError, subprocess.SubprocessError):
        return 0.0


def run_watched(argv, payload, env, cwd, wall_timeout, max_rss_mb, poll=0.05):
    """-> (stdout, stderr, killed) with killed in (None, "memory", "wall"). Same arguments and results as tflops._run_watched."""
    with tempfile.TemporaryFile() as stdin:
        stdin.write(payload)
        stdin.flush()
        stdin.seek(0)
        p = subprocess.Popen(argv, stdin=stdin, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, cwd=cwd)
        deadline = time.time() + wall_timeout
        while True:
            try:
                out, err = p.communicate(timeout=poll)
                return out, err, None
            except subprocess.TimeoutExpired:
                pass
            killed = "memory" if rss_mb(p.pid) > max_rss_mb else "wall" if time.time() > deadline else None
            if killed:
                p.kill()
                out, err = p.communicate()
                return out, err, killed
