"""The independent verifier's toolkit: package a round's evidence, and let someone who trusts nobody's word audit it with their own pinned keys.

An INDEPENDENT VERIFIER is a party the operator and the vendor do not control, that holds three things: the tool service (it serves the tasks and signs every session: agent_service.py), the round's
registry (it records every round it opens, closes or voids: agent_registry.py) and its share of the joint seed (agent_joint.py). INDEPENDENT_VERIFIER.md has the whole argument; this module is its
mechanical half.

  bundle   --base B --round R --out DIR --cert C.json ... [--registry F] [--joint J --joint-revealed JR] [--proxy-log L]
           copy a REVEALED round and its evidence into one directory with a manifest of file hashes and the audit command
  audit    DIR --trusted VERIFIER_KEYS [--party-keys KEYS] [--verifier-party NAME] [--require-registry] [--require-joint]
           check EVERYTHING from the bundle's own files and the keys you pinned: that the files are the manifest's; that the round verifies (log, plan, every ladder re-derived from the revealed seed, every
           black-box session replayed and its signature checked); that each certificate regenerates from the data and is signed by a pinned key; that the verifier's registry is intact, signed by a pinned key,
           registered this round BEFORE it ran and recorded its outcome; how many OTHER rounds the same configuration was entered in; that the joint seed really is the hash of every party's committed
           share and produces the round's commitment; and that the verifier's keys are DIFFERENT from every other party's key
  quorum   DIR1 DIR2 ... --trusted KEYS --need K
           K independent verifiers, each of whom ran the same plan with its own seed and signed its own certificate: audit each bundle, require every one to pass, require K DISTINCT pinned verifier
           keys and the same candidate configuration. A vendor that passes K independent rounds has not been lucky once.

WHAT THIS CANNOT DO. It checks keys, not people: "the verifier's key differs from the vendor's" is a fact about bytes; "the verifier is not the vendor's friend" is a fact about the world, and you
supply it by choosing which keys to pin. It proves the evidence is consistent and signed by the keys you chose to trust, and that nothing in it could have been changed since; it cannot prove the
verifier did not leak instances to a favourite while the round ran (the joint seed and a quorum of independent verifiers shrink that, nothing eliminates it).
"""
import argparse
import json
import os
import shutil
import sys
import time

import agent_cert
import agent_core
import agent_eval
import agent_joint
import agent_registry as REG
import agent_rounds as AR
import agent_sig
import rounds as R
from agent_core import canon, file_sha256

BUNDLE_FORMAT = "guldo-agent-bundle-v1"
MANIFEST = "BUNDLE.json"


class BundleError(Exception):
    pass


def _walk(root):
    out = []
    for dp, _dn, fns in os.walk(root):
        for fn in fns:
            rel = os.path.relpath(os.path.join(dp, fn), root).replace(os.sep, "/")
            if rel != MANIFEST:
                out.append(rel)
    return sorted(out)


def make_bundle(base, rid, out_dir, cert_paths=(), registry=None, joint=None, joint_revealed=None, proxy_log=None, now=None, log_dir=None, tee_evidence=None):
    """Assemble the evidence of a REVEALED round. The secret seed is not in it (the revealed seed IS: that is the point of a reveal); the verifier's key, the arm tokens and the shares of a joint
    seed that were never revealed are not either. With `log_dir` (an agent_translog log that holds the round's evidence) the bundle also carries an INCLUSION PROOF for every joint-seed commitment, the
    registry's open and close entries and the beacon record, so a reader can order them with the log's clock instead of the verifier's."""
    d = AR._require(base, rid)
    r = R._read_json(os.path.join(d, "round.json"))
    if r["state"] != "revealed":
        raise BundleError("bundle a round after the reveal: it is %s" % r["state"])
    problems = AR.verify_round(base, rid)
    if problems:
        raise BundleError("REFUSED: the round does not verify (%s)" % problems[0])
    if os.path.exists(out_dir) and os.listdir(out_dir):
        raise BundleError("%s is not empty" % out_dir)
    os.makedirs(out_dir, exist_ok=True)
    AR.export_public(base, rid, os.path.join(out_dir, "round"))
    os.makedirs(os.path.join(out_dir, "certificates"))
    for p in cert_paths:
        shutil.copy(p, os.path.join(out_dir, "certificates", os.path.basename(p)))
    for src, name in ((registry, "registry.jsonl"), (joint, "joint.json"), (joint_revealed, "joint.revealed.json"), (proxy_log, "proxy_log.jsonl")):
        if src:
            shutil.copy(src, os.path.join(out_dir, name))
    if tee_evidence:
        os.makedirs(os.path.join(out_dir, "tee"))
        shutil.copy(tee_evidence, os.path.join(out_dir, "tee", "evidence.json"))
    if log_dir:
        if not (registry and joint):
            raise BundleError("log proofs need the registry and the joint-seed record: they are what is being proven")
        import agent_translog as TL
        try:
            log = TL.load(log_dir)
            revealed = _read_json(joint_revealed) if joint_revealed else {}
            proofs = TL.evidence_proofs(log, _read_json(joint), REG.read(registry), rid, revealed.get("beacon"))
        except TL.LogError as e:
            raise BundleError("REFUSED: %s" % e)
        os.makedirs(os.path.join(out_dir, "log", "proofs"))
        for name, pr in proofs.items():
            with open(os.path.join(out_dir, "log", "proofs", name + ".json"), "w", encoding="utf-8") as f:
                json.dump(pr, f, indent=1, sort_keys=True)
        with open(os.path.join(out_dir, "log", "consistency.json"), "w", encoding="utf-8") as f:       # links the checkpoints the proofs use into ONE history
            json.dump(TL.consistency_chain(log, proofs), f, indent=1, sort_keys=True)
        shutil.copy(os.path.join(log_dir, "log.json"), os.path.join(out_dir, "log", "log.json"))
        if os.path.exists(os.path.join(log_dir, "anchors.jsonl")):
            shutil.copy(os.path.join(log_dir, "anchors.jsonl"), os.path.join(out_dir, "log", "anchors.jsonl"))
    files = {rel: file_sha256(os.path.join(out_dir, rel)) for rel in _walk(out_dir)}
    man = {"format": BUNDLE_FORMAT, "round": rid, "created": round(time.time() if now is None else now, 3), "files": files}
    with open(os.path.join(out_dir, MANIFEST), "w", encoding="utf-8") as f:
        f.write(json.dumps(man, indent=1, sort_keys=True) + "\n")
    with open(os.path.join(out_dir, "README.txt"), "w", encoding="utf-8") as f:
        f.write("Evidence for round %s. Audit it with YOUR OWN pinned keys (a file of public keys, one hex per line):\n\n  python3 agent_verifier.py audit %s --trusted YOUR_PINNED_VERIFIER_KEYS "
                "[--party-keys KEYS --verifier-party NAME] --require-registry\n\nThe audit trusts nothing in this directory that it can recompute.\n" % (rid, os.path.basename(os.path.normpath(out_dir))))
    # README is not in the manifest on purpose (it is not evidence); the manifest is written last over everything else
    return man


def _read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def audit(bundle_dir, trusted, party_keys=None, verifier_party=None, require_registry=False, require_joint=False, log_key=None, log_witnesses=None, min_witnesses=0, require_log=False,
          tee_pcrs=None, tee_roots=None, tee_source=None, allow_tee_debug=False, require_tee=False):
    """Returns [(check, ok, detail)]. All ok = the bundle is exactly what it says, signed by the keys you pinned. `log_key` pins the transparency log that ordered the evidence; `log_witnesses` and
    `min_witnesses` pin independent witnesses of that log, whose co-signature times then replace the log operator's own clock in the timeline checks."""
    rows = []

    def add(name, ok, detail=""):
        rows.append((name, bool(ok), detail))
    trusted = set(trusted or [])
    if not trusted:
        return [("you pinned no verifier key", False, "an audit with no pinned key checks only that the evidence is self-consistent, which anyone can fake: pin the verifier's key (--trusted)")]
    try:
        man = _read_json(os.path.join(bundle_dir, MANIFEST))
    except (OSError, ValueError):
        return [("the bundle has a readable manifest", False, "")]
    if man.get("format") != BUNDLE_FORMAT or not isinstance(man.get("files"), dict) or not isinstance(man.get("round"), str):
        return [("the bundle's manifest is well formed", False, "")]
    rid = man["round"]
    listed = man["files"]
    present = _walk(bundle_dir)
    bad = [rel for rel in listed if rel not in present or file_sha256(os.path.join(bundle_dir, rel)) != listed[rel]]
    extra = [rel for rel in present if rel not in listed and rel != "README.txt"]
    add("every file in the bundle is the one the manifest lists, and there are no others", not bad and not extra, ("changed or missing: %s" % ", ".join(bad[:3])) if bad else
        ("unlisted: %s" % ", ".join(extra[:3]) if extra else "%d files" % len(listed)))
    if bad or extra:
        return rows
    round_base = os.path.join(bundle_dir, "round")
    problems = AR.verify_round(round_base, rid)
    add("the round verifies from its own files (log, plan, every ladder re-derived from the revealed seed, every session replayed)", not problems, problems[0] if problems else "")
    if problems:
        return rows
    d = AR.rdir(round_base, rid)
    master = agent_core.read_master(os.path.join(d, "seed.revealed"), False)
    r = R._read_json(os.path.join(d, "round.json"))
    verifier_keys = set()
    # -- the verifier's KEY HISTORY, from its registry (if any): a reader pins the identity's FIRST key; a key it rotated to is accepted for exactly the rounds that fall inside that key's term, and
    # not for a round that overlaps a compromise the owner declared. Without a registry the only keys accepted are the ones pinned. ---------------------------------------------------------------
    round_key, key_problem, key_trail = None, None, None
    reg_file = os.path.join(bundle_dir, "registry.jsonl")
    if os.path.exists(reg_file):
        try:
            reg_rows = REG.read(reg_file)
            wprobs, terms = REG.walk(reg_rows)
            info = REG.rounds(reg_rows).get(rid)
            tf = REG.trusted_from(terms, trusted)
            if not wprobs and info is not None and tf is not None:
                o_seq, e_seq = info["open"]["seq"], (info["end"]["seq"] if info["end"] else None)
                t_open, t_end = REG.term_at(terms, o_seq), (REG.term_at(terms, e_seq) if e_seq is not None else None)
                cs = t_open["compromised_since"] if t_open else None
                if t_open is None or (t_end is not None and t_end is not t_open):
                    key_problem = "the round was opened under one key and closed under another"
                elif o_seq < tf:
                    key_problem = "the round was registered before the first key term you pinned: the earlier history is not authenticated by your pins"
                elif cs is not None and (o_seq >= cs or (e_seq is not None and e_seq >= cs)):
                    key_problem = "the owner declared this key COMPROMISED from registry entry %d, and this round is at or after it" % cs
                else:
                    round_key = t_open["key"]
            key_trail = " -> ".join("%s...[%s..%s]" % (t["key"][:8], t["from_seq"], "now" if t["to_seq"] is None else t["to_seq"]) for t in terms) if terms else None
        except (REG.RegistryError, KeyError, TypeError, ValueError):
            pass
    eff = set(trusted) | ({round_key} if round_key else set())               # the keys this round's signatures may legitimately be under
    # -- black-box arms: the service key that signed every session must be one you pinned --------------------------------------------------------------------------
    whitebox = []
    for name in sorted(os.listdir(os.path.join(d, "ladders"))):
        h, _recs = agent_core.read_ladder(os.path.join(d, "ladders", name))
        if h.get("mode"):
            k = (h.get("service") or {}).get("pubkey")
            verifier_keys.add(k)
            add("black-box arm %s: every session was signed by a service key you pinned (or one it was legitimately rotated to)" % h["agent"]["label"], k in eff, str(k)[:16])
        else:
            whitebox.append(h["agent"]["label"])
    if whitebox:
        add("INFO white-box arm(s) %s" % ", ".join(whitebox), True, "run by the verifier's own harness: consistent with the seed, but no per-trial signature and nothing but the verifier's word that a model produced "
            "them (a recording proxy held by a third party, agent_proxy.py, or serving the arm as a black box, would add that)")
    # -- certificates -------------------------------------------------------------------------------------------------------------------------------------------
    cdir = os.path.join(bundle_dir, "certificates")
    certs = sorted(os.listdir(cdir)) if os.path.isdir(cdir) else []
    add("the bundle holds at least one certificate", bool(certs), "")
    proxy = os.path.join(bundle_dir, "proxy_log.jsonl")
    cand_hashes = []
    for fn in certs:
        try:
            doc = _read_json(os.path.join(cdir, fn))
            body = doc["statement"] if isinstance(doc, dict) and "signature" in doc and isinstance(doc.get("statement"), dict) else doc
            eid = body["candidate"]["eid"]
            if body["round"]["id"] != rid:
                add("certificate %s is for this round" % fn, False, body["round"]["id"])
                continue
            if "signature" in doc and isinstance(doc["statement"].get("pubkey"), str):
                verifier_keys.add(doc["statement"]["pubkey"])
            cand_hashes.append(body["candidate"]["config_sha256"])
            res = agent_cert.verify_certificate(doc, os.path.join(d, "ladders", "baseline.jsonl"), os.path.join(d, "ladders", eid + ".jsonl"), master, eff, round_base,
                                                proxy if os.path.exists(proxy) else None, eff if os.path.exists(proxy) else None)
            failed = [n for n, ok, _ in res if not ok]
            add("certificate %s regenerates from the data and is signed by a pinned key (%d checks)" % (fn, len(res)), not failed, "; ".join(failed[:3]))
        except (KeyError, TypeError, ValueError, OSError) as e:
            add("certificate %s is readable" % fn, False, type(e).__name__)
    # -- the registry -------------------------------------------------------------------------------------------------------------------------------------------
    reg_path = os.path.join(bundle_dir, "registry.jsonl")
    joint_doc = _read_json(os.path.join(bundle_dir, "joint.json")) if os.path.exists(os.path.join(bundle_dir, "joint.json")) else None
    if os.path.exists(reg_path):
        try:
            reg = REG.read(reg_path)
            probs = REG.check(reg, trusted)
            add("the registry is intact and signed by a key you pinned", not probs, probs[0] if probs else "%d entries" % len(reg))
            if not probs:
                verifier_keys.add(round_key if round_key else reg[0]["pubkey"])
                if len(set(e["pubkey"] for e in reg)) > 1 or reg[0]["kind"] == "key_inception":
                    add("the verifier's key history is sound and this round was signed under ONE authenticated key (pre-committed rotation, none while a round was open, no declared compromise)",
                        key_problem is None and round_key is not None, key_problem or str(key_trail))
                rp = REG.round_problems(reg, round_base, rid, joint_doc)
                add("the registry's account of this round matches the round (registered BEFORE it ran, outcome recorded, arms and joint seed as registered)", not rp, rp[0] if rp else "")
                for ch in sorted(set(cand_hashes)):
                    others = REG.attempts(reg, config_sha256=ch, exclude=rid)
                    add("INFO disclosure: other rounds this candidate configuration was entered in", True,
                        "none" if not others else "%d: %s" % (len(others), ", ".join("%s (%s)" % (a, b) for a, b, _ in others[:8])))
        except (REG.RegistryError, KeyError, TypeError, ValueError) as e:
            add("the registry is readable", False, type(e).__name__ + ": " + str(e)[:80])
    else:
        add("a registry is included", not require_registry, "none: the reader cannot tell how many other rounds this configuration was entered in" if not require_registry else "required")
    # -- the joint seed -----------------------------------------------------------------------------------------------------------------------------------------
    jr_path = os.path.join(bundle_dir, "joint.revealed.json")
    if joint_doc is not None and os.path.exists(jr_path):
        probs = agent_joint.verify(joint_doc, _read_json(jr_path), r["commitment"], set(party_keys) if party_keys else None)
        add("the joint seed is the hash of every party's committed share and produces the round's commitment%s" % (" (party keys pinned)" if party_keys else " (party keys NOT pinned)"),
            not probs, probs[0] if probs else "%d parties" % len(joint_doc["parties"]))
        if not probs and verifier_party:
            pk = agent_joint.party_keys(joint_doc)
            vk = pk.get(verifier_party)
            others = {p: k for p, k in pk.items() if p != verifier_party}
            add("the verifier's share was committed by a key that also signed this round's sessions/certificates/registry", vk in verifier_keys, str(vk)[:16])
            add("no OTHER party's key is a verifier key (key separation: operator, vendors and verifier are different keys)", not (set(others.values()) & verifier_keys),
                ", ".join(sorted(p for p, k in others.items() if k in verifier_keys)))
    else:
        add("a joint seed is included", not require_joint, "none: the seed host alone chose the seed" if not require_joint else "required")
    # -- the transparency log: ORDER by a clock the verifier does not control ---------------------------------------------------------------------------------------
    _log_section(bundle_dir, rid, joint_doc, reg_file, log_key, log_witnesses, min_witnesses, require_log, add)
    # -- hardware attestation of the service ------------------------------------------------------------------------------------------------------------------------
    svc_keys = set()
    for name in sorted(os.listdir(os.path.join(d, "ladders"))):
        h, _recs = agent_core.read_ladder(os.path.join(d, "ladders", name))
        if h.get("mode"):
            svc_keys.add((h.get("service") or {}).get("pubkey"))
    _tee_section(bundle_dir, r, svc_keys, tee_pcrs, tee_roots, tee_source, allow_tee_debug, require_tee, add)
    add("INFO what this audit cannot show", True, "distinct keys are not distinct people, and nothing here shows the verifier did not leak instances while the round ran"
        + ("" if os.path.exists(os.path.join(bundle_dir, "tee", "evidence.json")) else " (no hardware attestation was supplied: the host is trusted not to have)"))
    return rows


def _tee_section(bundle_dir, r, svc_keys, tee_pcrs, tee_roots, tee_source, allow_debug, require_tee, add):
    import agent_tee as TEE
    path = os.path.join(bundle_dir, "tee", "evidence.json")
    if not os.path.exists(path):
        add("TEE evidence is included" if require_tee else "INFO no TEE evidence", not require_tee, "required" if require_tee else "the host of the seed is trusted not to have leaked it or altered the service")
        return
    try:
        ev = _read_json(path)
    except (OSError, ValueError):
        add("the TEE evidence is readable", False, "")
        return
    expect = {"plan_hash": r["plan_hash"], "commitment": r["commitment"]}
    if len(svc_keys) == 1:
        expect["service_pubkey"] = next(iter(svc_keys))
    elif len(svc_keys) > 1:
        add("the TEE evidence names the service key of every black-box arm", False, "%d different service keys: one enclave serves one key" % len(svc_keys))
        return
    if isinstance(ev, dict) and "document_b64" in ev and not tee_pcrs:
        add("TEE evidence is evaluated" if require_tee else "INFO TEE evidence is present but you supplied no expected PCR values (--tee-pcr)", not require_tee,
            "a hardware document compared with no image measurement of yours attests nothing")
        return
    roots = tuple(tee_roots) if tee_roots else (TEE.NITRO_ROOT_SHA256,)
    st, probs, info = TEE.verify_evidence(ev, expect, tee_pcrs, roots, tee_source, allow_debug)
    if st == "attested":
        add("TEE: a genuine enclave running the image YOU built attests this service key, this plan and this seed commitment%s" % (" and the code you hold" if tee_source else ""), True,
            "%s, PCR0 %s..." % (info.get("platform"), str((info.get("pcrs") or {}).get(0, ""))[:16]))
    elif st == "claimed":
        add("TEE binding is a CLAIM with no hardware evidence" if not require_tee else "TEE evidence is attested (a bare claim is not)", not require_tee, "; ".join(probs[:2]) or "never counted as attested")
    else:
        add("TEE evidence verifies", False, probs[0] if probs else "invalid")


def _log_section(bundle_dir, rid, joint_doc, reg_file, log_key, log_witnesses, min_witnesses, require_log, add):
    import agent_translog as TL
    proofs_dir = os.path.join(bundle_dir, "log", "proofs")
    plan_time = None
    if joint_doc is not None:
        try:
            plan_time = agent_joint.beacon_time(joint_doc)
        except (agent_joint.JointError, KeyError, TypeError, ValueError):
            plan_time = None
    if not os.path.isdir(proofs_dir):
        add("transparency-log proofs are included", not require_log, "required" if require_log else "none: the evidence is ordered only by the verifier's own clock")
        if plan_time is not None and not require_log:
            add("INFO a beacon round was planned (released %s UTC)" % time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(plan_time)), True,
                "but no log proofs order the commitments before it: the beacon alone fixes only that the seed did not exist before then")
        return
    if not log_key:
        add("you pinned no transparency-log key", False, "the bundle carries log proofs: pin the log's key (--log-key), or they prove only that SOME key signed")
        return
    pins = set(log_witnesses or ())
    infos, docs = {}, {}
    for fn in sorted(os.listdir(proofs_dir)):
        name = fn[:-5] if fn.endswith(".json") else fn
        try:
            pr = _read_json(os.path.join(proofs_dir, fn))
        except (OSError, ValueError):
            add("log proof %s is readable" % name, False, "")
            continue
        # an independent witness's clock matters only where a DEADLINE is checked: the commitments (before the beacon round). A witness co-signs a checkpoint at one moment, so entries logged after its
        # last co-signature have no witnessed checkpoint covering them, and demanding one for them would fail an honest round.
        need = min_witnesses if name.startswith("commitment.") else 0
        probs, info = TL.verify_proof(pr, log_key, pins, need)
        add("log proof %s verifies under the pinned log key%s" % (name, " and %d pinned witness(es)" % need if need else ""), not probs,
            probs[0] if probs else "entry %d, logged %s UTC" % (info["index"], time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(info["logged"]))))
        if not probs:
            infos[name] = info
            docs[name] = pr
    # every proof is checked against ITS OWN checkpoint, so nothing yet says the checkpoints are one history: a log that signed two histories could show each claim its own. Require them linked.
    try:
        cons = _read_json(os.path.join(bundle_dir, "log", "consistency.json")) if os.path.exists(os.path.join(bundle_dir, "log", "consistency.json")) else []
    except (OSError, ValueError):
        cons = None
    hp = ["the consistency proofs are unreadable"] if cons is None else TL.history_problems(docs, cons, log_key)
    add("every log proof comes from ONE history of the log (consistency proofs link the checkpoints they use)", not hp, hp[0] if hp else "%d distinct checkpoint(s)" % len({p["checkpoint"]["body"]["size"] for p in docs.values()}))
    reg = REG.read(reg_file) if os.path.exists(reg_file) else None
    if joint_doc is not None:
        for c in joint_doc.get("parties", []):
            nm = "commitment.%s" % c["statement"]["party"]
            add("the log holds %s's signed commitment exactly as the joint-seed record has it" % c["statement"]["party"], nm in infos and canon(infos[nm]["entry"]["data"]) == canon(c), "")
    rinfo = REG.rounds(reg).get(rid) if reg else None
    if rinfo is not None:
        for label, ent in (("registry_open", rinfo["open"]), ("registry_close", rinfo["end"])):
            if ent is None:
                continue
            add("the log holds the registry's %s entry of this round exactly" % label[9:], label in infos and infos[label]["entry"]["data"] == TL.registry_entry_data(reg, ent["seq"]), "")

    def when(inf):
        if min_witnesses and inf["witness_times"]:
            return min(inf["witness_times"]), "a pinned witness's co-signature"
        return inf["logged"], "the log operator's own clock"
    commits = {n: i for n, i in infos.items() if n.startswith("commitment.")}
    op, cl = infos.get("registry_open"), infos.get("registry_close")
    if commits and op:
        add("every joint-seed commitment is in the log BEFORE the registry's open entry (log order)", max(i["index"] for i in commits.values()) < op["index"],
            "commitments at %s, registration at %d" % (sorted(i["index"] for i in commits.values()), op["index"]))
    if op and cl:
        add("the registry's close entry is in the log AFTER its open entry", cl["index"] > op["index"], "")
    if plan_time is not None:
        if not commits:
            add("every commitment was in the log before the planned beacon round was released", False, "a beacon round was planned but the bundle carries no commitment proofs")
        else:
            latest = max(when(i)[0] for i in commits.values())
            clock = when(next(iter(commits.values())))[1]
            add("every commitment was in the log BEFORE the planned beacon round was released: no party, even colluding, could have known the seed when it committed (by %s)" % clock, latest < plan_time,
                "latest commitment %s UTC, round released %s UTC" % (time.strftime("%H:%M:%S", time.gmtime(latest)), time.strftime("%H:%M:%S", time.gmtime(plan_time))))
            if not min_witnesses:
                add("INFO the timeline above rests on the log operator's own clock", True, "pin independent witnesses of the log (--log-witnesses, --min-witnesses) to use their co-signature times instead")
    anchors = os.path.join(bundle_dir, "log", "anchors.jsonl")
    if os.path.exists(anchors):
        with open(anchors, "r", encoding="utf-8") as f:
            for ln in f:
                if ln.strip():
                    try:
                        st = TL.anchor_status(json.loads(ln))
                        add("INFO log checkpoint anchor (OpenTimestamps)", True, "%s%s" % (st["status"], (", Bitcoin block(s) %s" % st["heights"]) if st["heights"] else ", not yet in a Bitcoin block"))
                    except (TL.LogError, ValueError):
                        add("INFO log checkpoint anchor (OpenTimestamps)", True, "unreadable")


def quorum(bundle_dirs, trusted, need, party_keys=None, **audit_kw):
    """(ok, rows): audit each bundle (every one must pass; `audit_kw` is passed to each audit, e.g. the pinned log key), and require `need` DISTINCT pinned verifier keys certifying the SAME
    candidate configuration in the same domain."""
    rows = []
    signers, cands, domains = {}, set(), set()
    for bd in bundle_dirs:
        res = audit(bd, trusted, party_keys, **audit_kw)
        failed = [n for n, ok, _ in res if not ok]
        rows.append(("bundle %s passes the audit" % os.path.basename(os.path.normpath(bd)), not failed, "; ".join(failed[:2])))
        try:
            man = _read_json(os.path.join(bd, MANIFEST))
            d = AR.rdir(os.path.join(bd, "round"), man["round"])
            r = R._read_json(os.path.join(d, "round.json"))
            domains.add(r["domain"])
            for fn in sorted(os.listdir(os.path.join(bd, "certificates"))):
                doc = _read_json(os.path.join(bd, "certificates", fn))
                if "signature" in doc:
                    cands.add(doc["statement"]["candidate"]["config_sha256"])
                    if not failed:
                        ident = doc["statement"]["pubkey"]
                        rp = os.path.join(bd, "registry.jsonl")
                        if os.path.exists(rp):                                  # a verifier is its IDENTITY (its first key), not whichever key it holds today: a rotated key is not a second verifier
                            ident = REG.identity_of(REG.read(rp)) or ident
                        signers.setdefault(ident, []).append(bd)
        except (OSError, KeyError, ValueError, TypeError):
            rows.append(("bundle %s is readable for the quorum" % bd, False, ""))
    rows.append(("every bundle certifies the same candidate configuration", len(cands) == 1, "%d different" % len(cands)))
    rows.append(("every bundle is in the same domain", len(domains) == 1, ", ".join(sorted(domains))))
    rows.append(("%d DISTINCT pinned verifier keys certify it (found %d)" % (need, len(signers)), len(signers) >= need, ""))
    return all(o for n, o, _detail in rows if not n_info(n)), rows


def n_info(name):
    return str(name).startswith("INFO")


def init_home(home):
    """Create a verifier home: `verifier.key` (mode 600), a second key to keep OFFLINE whose hash the registry's first entry commits to (so a thief of the signing key cannot take the identity over:
    only the holder of this key can rotate), the registry with that inception entry, and `verifier.pub`. Refuses to overwrite anything."""
    if os.path.exists(os.path.join(home, "verifier.key")) or os.path.exists(os.path.join(home, "registry.jsonl")):
        raise BundleError("%s already holds a verifier: nothing was changed" % home)
    os.makedirs(home, mode=0o700, exist_ok=True)
    pub = agent_sig.keygen(os.path.join(home, "verifier.key"))
    npub = agent_sig.keygen(os.path.join(home, "NEXT_KEY_KEEP_OFFLINE.key"))
    REG.init_identity(os.path.join(home, "registry.jsonl"), agent_sig.load_secret(os.path.join(home, "verifier.key")), npub)
    with open(os.path.join(home, "verifier.pub"), "w", encoding="utf-8") as f:
        f.write(pub + "  # the verifier's identity key (first key of its registry)\n")
    return {"pubkey": pub, "next_pubkey": npub}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("bundle")
    p.add_argument("--base", default=".")
    p.add_argument("--round", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--cert", action="append", default=[])
    p.add_argument("--registry")
    p.add_argument("--joint")
    p.add_argument("--joint-revealed")
    p.add_argument("--proxy-log")
    p.add_argument("--log", help="an agent_translog log directory holding the round's evidence: its inclusion proofs go into the bundle")
    p.add_argument("--tee-evidence", help="agent_tee evidence JSON for the service (hardware attestation or a bare claim)")

    def log_flags(p_):
        p_.add_argument("--log-key", help="the transparency log's public key as YOU obtained it")
        p_.add_argument("--log-witnesses", help="file of pinned witness public keys")
        p_.add_argument("--min-witnesses", type=int, default=0)
        p_.add_argument("--require-log", action="store_true")
        p_.add_argument("--tee-pcr", action="append", default=[], help="INDEX=HEX: an expected enclave PCR value from YOUR build of the image (repeatable)")
        p_.add_argument("--tee-root", action="append", default=[], help="sha256 of a platform root certificate you pin (default: the AWS Nitro root)")
        p_.add_argument("--tee-source", help="your checkout of the service code, to recompute its measurement")
        p_.add_argument("--allow-tee-debug", action="store_true")
        p_.add_argument("--require-tee", action="store_true")
    p = sub.add_parser("init", help="set up a verifier home: signing key, a PRE-COMMITTED offline next key, and the registry's identity entry")
    p.add_argument("dir")
    p = sub.add_parser("selfcheck", help="a complete dry run of a round on this machine with throwaway keys")
    p.add_argument("--keep", help="keep the artefacts in this directory (default: a temporary one, removed afterwards)")
    p = sub.add_parser("audit")
    p.add_argument("dir")
    p.add_argument("--trusted", required=True)
    p.add_argument("--party-keys")
    p.add_argument("--verifier-party")
    p.add_argument("--require-registry", action="store_true")
    p.add_argument("--require-joint", action="store_true")
    log_flags(p)
    p = sub.add_parser("quorum")
    p.add_argument("dirs", nargs="+")
    p.add_argument("--trusted", required=True)
    p.add_argument("--party-keys")
    p.add_argument("--need", type=int, required=True)
    log_flags(p)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "init":
            info = init_home(a.dir)
            print("verifier home %s created." % a.dir)
            print("  signing key (keep secret, back it up):  %s/verifier.key" % a.dir)
            print("  NEXT key (move it OFFLINE now; it alone can rotate the identity): %s/NEXT_KEY_KEEP_OFFLINE.key" % a.dir)
            print("  PUBLISH this public key where readers can obtain it independently of the operator: %s" % info["pubkey"])
            print("  the registry %s/registry.jsonl already names the pre-committed next key (identity %s...)" % (a.dir, info["pubkey"][:16]))
            return 0
        if a.cmd == "selfcheck":
            import agent_selfcheck
            ok, _rows = agent_selfcheck.run(print, a.keep)
            return 0 if ok else 1
        if a.cmd == "bundle":
            man = make_bundle(a.base, a.round, a.out, a.cert, a.registry, a.joint, a.joint_revealed, a.proxy_log, log_dir=a.log, tee_evidence=a.tee_evidence)
            print("wrote %s: %d files; audit it with: python3 agent_verifier.py audit %s --trusted KEYS" % (a.out, len(man["files"]), a.out))
            return 0
        trusted = agent_sig.read_trusted(a.trusted)
        pk = agent_sig.read_trusted(a.party_keys) if a.party_keys else None
        lw = agent_sig.read_trusted(a.log_witnesses) if a.log_witnesses else None
        pcrs = {}
        for item in a.tee_pcr:
            i, _, v = item.partition("=")
            pcrs[int(i)] = v.lower()
        lk = dict(log_key=a.log_key, log_witnesses=lw, min_witnesses=a.min_witnesses, require_log=a.require_log, tee_pcrs=pcrs or None, tee_roots=a.tee_root or None, tee_source=a.tee_source,
                  allow_tee_debug=a.allow_tee_debug, require_tee=a.require_tee)
        if a.cmd == "audit":
            rows = audit(a.dir, trusted, pk, a.verifier_party, a.require_registry, a.require_joint, **lk)
            for n, ok, det in rows:
                print("%s  %s%s" % ("INFO" if n_info(n) else ("PASS" if ok else "FAIL"), n[5:] if n_info(n) else n, ("  (" + det + ")") if det else ""))
            good = all(ok for n, ok, _ in rows)
            print("AUDIT PASSED: everything checked is exactly what the pinned keys signed" if good else "AUDIT FAILED")
            return 0 if good else 1
        ok, rows = quorum(a.dirs, trusted, a.need, pk, **lk)
        for n, o, det in rows:
            print("%s  %s%s" % ("PASS" if o else "FAIL", n, ("  (" + det + ")") if det else ""))
        print("QUORUM MET" if ok else "QUORUM NOT MET")
        return 0 if ok else 1
    except (BundleError, AR.Rejected, OSError, ValueError, KeyError, agent_core.AgentEvalError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
