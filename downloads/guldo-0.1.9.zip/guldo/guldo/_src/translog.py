"""Transparency log for certificates: an append-only Merkle tree (RFC 9162) with signed heads, witness co-signatures, proofs and absence claims.

  translog.py init DIR --origin guldo.org/log (--key K | --new-key K)     a new log; K is the operator's Ed25519 key (keep it OUTSIDE DIR: DIR is published)
  translog.py add DIR CERT... --key K                                     verify each certificate (executes nothing from it), append it, sign a new head
  translog.py sign DIR --key K                                            a fresh head at the current size (a heartbeat: proves the log was alive and unchanged)
  translog.py prove --log DIR|URL (--cert CERT | --seq N) [--out F]       an inclusion proof: one file a stranger can check offline
  translog.py verify-inclusion PROOF [--cert CERT] --log-key HEX [--trusted KEYS --min-witnesses K]
  translog.py consistency --log DIR|URL --old N [--new M]                a proof that the log at size N is a prefix of the log at size M
  translog.py verify-consistency PROOF
  translog.py witness --log DIR|URL --state S [--key W] [--log-key HEX] [--recheck] [--out cosig.json] [--evidence ev.json]   check the log only grew; with --key, co-sign its head
  translog.py check-evidence EV.json [--log-key HEX]                      a witness's proof that one key signed two incompatible histories, checkable by anyone offline
  translog.py add-cosig DIR COSIG...                                      the operator merges witness co-signatures into the published head
  translog.py check --log DIR|URL --log-key HEX [--trusted KEYS --min-witnesses K]   check the head, every old head, and (with --recheck) every certificate
  translog.py frontier --log DIR|URL [--family F] [--counted-only]        the best credit per problem as logged (not "verified speed": see SCOPE below and LOG.md)
  translog.py absence --log DIR|URL --family F --threshold BITS [--out F]   a claim "no logged certificate reaches BITS", and check-absence to verify one
  translog.py anchor DIR [--record KIND REF]                              the one line to publish somewhere the operator cannot edit; anchor-check URL re-reads it

WHAT IT PROVES. That a certificate was in the log at a tree head; that the log only ever grew between two heads; that the operator signed one history
(two different roots at one size are a signed contradiction); that the operator's recorded credit is what the certificate recomputes to.
WHAT IT DOES NOT. Nothing forces anyone to submit, so "absent from the log" means "not submitted", not "does not exist". A log entry is not an official
result and says nothing about whether recorded timings were honest (the certificate's own limits stand). The operator's clock stamps `logged`; only
witnesses and anchors give a time the operator did not choose. A signature shows which key signed, never that the key's owner is independent of the operator.
See LOG.md for the design, the threat model and the operator's runbook.
"""
import argparse
import calendar
import contextlib
import fcntl
import hashlib
import json
import math
import os
import re
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

import attest as A
import certificate as K
import logqueue
import otsanchor as O
import runattest as RA
import webarchive as W

HERE = os.path.dirname(os.path.abspath(__file__))
LOG_FORMAT = "guldo-tlog-v1"
CP_FORMAT = "guldo-checkpoint-v1"
COSIG_FORMAT = "guldo-cosig-v1"
INCL_FORMAT = "guldo-inclusion-v1"
CONS_FORMAT = "guldo-consistency-v1"
ABSENCE_FORMAT = "guldo-absence-v1"
STATE_FORMAT = "guldo-witness-state-v1"
EVID_FORMAT = "guldo-equivocation-v1"
MAX_CERT_BYTES = 8 << 20
MAX_LOG_BYTES = 256 << 20
MAX_COSIGS = 200               # co-signatures checked per head bundle: a hostile bundle cannot make a verifier burn CPU on millions of signatures
STATIC_PROOF_LIMIT = 20000    # above this many entries the per-entry proof files are not written (`prove` still works, and so does computing them from entries.jsonl)
PUBLIC_FILES = ("log.json", "entries.jsonl", "checkpoints.jsonl", "checkpoint.json", "cosigs.jsonl", "anchors.jsonl", "trusted.txt")

_HEX64 = re.compile(r"[0-9a-f]{64}")
_TIME = re.compile(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ")
_ORIGIN = re.compile(r"[a-z0-9]([a-z0-9.-]{0,60}[a-z0-9])?(/[a-z0-9._-]{1,40}){0,3}")
_FAMILY = re.compile(r"[A-Za-z0-9_.-]{1,60}")
_NAME = re.compile(r"[A-Za-z0-9_.:+/ -]{0,60}")
_READ_NAME = re.compile(r"[A-Za-z0-9._-]+(/[A-Za-z0-9._-]+)?")


class LogError(Exception):
    """The log itself is damaged or unreadable (a structural problem, never a verdict on one certificate)."""


class Rejected(ValueError):
    """A certificate (or co-signature) was not admitted; the message says why."""


def now_iso(t=None):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t if t is not None else time.time()))


def _clean(s, limit):
    return "".join(c if 32 <= ord(c) < 127 else "?" for c in str(s))[:limit]


_PATH = re.compile(r"(/[\w.@+\-]+){2,}")


def _scrub(s):
    """A rejection message is shown to whoever submitted the file (and, behind a public endpoint, to a stranger): it must not name the verifier's temp directories."""
    return _PATH.sub("<path>", str(s))


# ------------------------------------------------------------------ the Merkle tree (RFC 9162 section 2.1)
def _h(b):
    return hashlib.sha256(b).digest()


EMPTY_ROOT = _h(b"")


def leaf_hash(data):
    return _h(b"\x00" + data)


def node_hash(left, right):
    return _h(b"\x01" + left + right)


def _split(n):
    """The largest power of two strictly below n (n > 1)."""
    return 1 << ((n - 1).bit_length() - 1)


class Tree:
    """The proving side: roots, inclusion paths and consistency paths over a list of leaf hashes (RFC 9162 2.1.1 - 2.1.4, the recursive definitions).
    The verifying side below is written from a different algorithm (the iterative checks of 2.1.3.2 and 2.1.4.2), so a bug in one is not hidden by the other."""

    def __init__(self, leaves=None):
        self.leaves = list(leaves or [])
        self._memo = {}

    def __len__(self):
        return len(self.leaves)

    def append(self, lh):
        self.leaves.append(lh)

    def _mth(self, lo, hi):
        n = hi - lo
        if n == 1:
            return self.leaves[lo]
        v = self._memo.get((lo, hi))
        if v is None:
            k = _split(n)
            v = node_hash(self._mth(lo, lo + k), self._mth(lo + k, hi))
            self._memo[(lo, hi)] = v
        return v

    def root(self, n=None):
        n = len(self.leaves) if n is None else n
        if not 0 <= n <= len(self.leaves):
            raise ValueError(f"tree size {n} is outside 0..{len(self.leaves)}")
        return EMPTY_ROOT if n == 0 else self._mth(0, n)

    def _path(self, m, lo, hi):
        n = hi - lo
        if n == 1:
            return []
        k = _split(n)
        if m < k:
            return self._path(m, lo, lo + k) + [self._mth(lo + k, hi)]
        return self._path(m - k, lo + k, hi) + [self._mth(lo, lo + k)]

    def inclusion(self, index, n=None):
        n = len(self.leaves) if n is None else n
        if not 0 <= index < n <= len(self.leaves):
            raise ValueError(f"leaf {index} is not in a tree of size {n}")
        return self._path(index, 0, n)

    def _subproof(self, m, lo, hi, complete):
        n = hi - lo
        if m == n:
            return [] if complete else [self._mth(lo, hi)]
        k = _split(n)
        if m <= k:
            return self._subproof(m, lo, lo + k, complete) + [self._mth(lo + k, hi)]
        return self._subproof(m - k, lo + k, hi, False) + [self._mth(lo, lo + k)]

    def consistency(self, m, n=None):
        n = len(self.leaves) if n is None else n
        if not 0 <= m <= n <= len(self.leaves):
            raise ValueError(f"sizes {m}..{n} are outside the tree (size {len(self.leaves)})")
        if m == 0 or m == n:
            return []
        return self._subproof(m, 0, n, True)


def verify_inclusion(leaf, index, size, path, root):
    """RFC 9162 2.1.3.2. leaf/path/root are 32-byte hashes. True only if the path ties this leaf at this index to this root of a tree of this size."""
    if not 0 <= index < size:
        return False
    fn, sn, r = index, size - 1, leaf
    for p in path:
        if sn == 0:
            return False
        if fn & 1 or fn == sn:
            r = node_hash(p, r)
            if not fn & 1:
                while not fn & 1 and fn != 0:
                    fn >>= 1
                    sn >>= 1
        else:
            r = node_hash(r, p)
        fn >>= 1
        sn >>= 1
    return sn == 0 and r == root


def verify_consistency(first, second, root1, root2, path):
    """RFC 9162 2.1.4.2. True only if the tree of size `first` with root1 is a prefix of the tree of size `second` with root2."""
    if first > second or first < 0:
        return False
    if first == second:
        return not path and root1 == root2
    if first == 0:
        return not path
    path = list(path)
    if not path:
        return False
    if first & (first - 1) == 0:
        path.insert(0, root1)
    fn, sn = first - 1, second - 1
    while fn & 1:
        fn >>= 1
        sn >>= 1
    fr = sr = path[0]
    for c in path[1:]:
        if sn == 0:
            return False
        if fn & 1 or fn == sn:
            fr, sr = node_hash(c, fr), node_hash(c, sr)
            if not fn & 1:
                while not fn & 1 and fn != 0:
                    fn >>= 1
                    sn >>= 1
        else:
            sr = node_hash(sr, c)
        fn >>= 1
        sn >>= 1
    return fr == root1 and sr == root2 and sn == 0


def _hx(b):
    return b.hex()


def _unhex(s):
    if not isinstance(s, str) or not _HEX64.fullmatch(s):
        raise ValueError("not a 64-hex hash")
    return bytes.fromhex(s)


# ------------------------------------------------------------------ signatures, heads and co-signatures
def _cp_msg(body):
    return b"guldo-tlog-checkpoint-v1\n" + K.canon(body).encode()


def _cosig_msg(origin, log_key, size, root, t):
    """What a witness signs. It names the log's KEY as well as its origin: otherwise a fork that copies a log's entries under a new key (and the same origin string) could carry
    the original's co-signatures, which are valid for any log with those entries."""
    return f"guldo-tlog-cosign-v2\n{origin}\n{log_key}\n{size}\n{root}\n{t}".encode()


def _sign(key_path, msg):
    priv, ser = A._load_key(key_path)
    return A._pub_hex(priv, ser), priv.sign(msg).hex()


def _sig_ok(pub_hex, sig_hex, msg):
    ed, _ = A._ed()
    try:
        ed.Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub_hex)).verify(bytes.fromhex(sig_hex), msg)
        return True
    except Exception:
        return False


def _valid_body(b):
    return (isinstance(b, dict) and set(b) == {"format", "origin", "size", "root", "time"} and b["format"] == CP_FORMAT
            and isinstance(b["origin"], str) and _ORIGIN.fullmatch(b["origin"]) is not None
            and isinstance(b["size"], int) and not isinstance(b["size"], bool) and 0 <= b["size"] <= 10 ** 12
            and isinstance(b["root"], str) and _HEX64.fullmatch(b["root"]) is not None
            and isinstance(b["time"], str) and _TIME.fullmatch(b["time"]) is not None)


def _valid_sigfield(s):
    return (isinstance(s, dict) and set(s) == {"pubkey", "sig"} and isinstance(s["pubkey"], str) and _HEX64.fullmatch(s["pubkey"]) is not None
            and isinstance(s["sig"], str) and re.fullmatch(r"[0-9a-f]{128}", s["sig"]) is not None)


def _valid_cosig(c):
    return (isinstance(c, dict) and set(c) >= {"format", "origin", "log_key", "size", "root", "pubkey", "time", "sig"}
            and set(c) <= {"format", "origin", "log_key", "size", "root", "pubkey", "time", "sig", "note"}
            and c["format"] == COSIG_FORMAT and isinstance(c["origin"], str) and _ORIGIN.fullmatch(c["origin"]) is not None
            and isinstance(c["log_key"], str) and _HEX64.fullmatch(c["log_key"]) is not None
            and isinstance(c["size"], int) and not isinstance(c["size"], bool) and 0 <= c["size"] <= 10 ** 12
            and isinstance(c["root"], str) and _HEX64.fullmatch(c["root"]) is not None
            and isinstance(c["pubkey"], str) and _HEX64.fullmatch(c["pubkey"]) is not None
            and isinstance(c["time"], str) and _TIME.fullmatch(c["time"]) is not None
            and isinstance(c["sig"], str) and re.fullmatch(r"[0-9a-f]{128}", c["sig"]) is not None
            and (not isinstance(c.get("note"), str) or len(c["note"]) <= 200))


def make_cosig(origin, log_key, size, root_hex, key_path, now=None, note=""):
    t = now or now_iso()
    pub, sig = _sign(key_path, _cosig_msg(origin, log_key, size, root_hex, t))
    c = {"format": COSIG_FORMAT, "origin": origin, "log_key": log_key, "size": size, "root": root_hex, "pubkey": pub, "time": t, "sig": sig}
    if note:
        c["note"] = _clean(note, 200)
    return c


def _chk(out, check, status, detail=""):
    out.append({"check": check, "status": status, "detail": detail})


def check_checkpoint(bundle, log_pubkey=None, trusted=(), min_witnesses=0, tree_root=None):
    """A head bundle {"body", "log", "witnesses"} -> {"ok", "checks", "pinned", "unvouched", "body"}.
    log_pubkey is the key the READER pinned for this log (obtained out of band); without it the log signature only shows that SOME key signed. Witness
    signatures count as independent only when their key is in `trusted`, which the reader chose: anyone can mint a key."""
    out, trusted = [], {k.lower() for k in (trusted or [])}
    res = {"ok": False, "checks": out, "pinned": 0, "unvouched": 0, "body": None}
    if not isinstance(bundle, dict) or not _valid_body(bundle.get("body")) or not _valid_sigfield(bundle.get("log")):
        _chk(out, "head", "fail", "not a well-formed signed head")
        return res
    body = bundle["body"]
    res["body"] = body
    _chk(out, "head", "pass", f"{body['origin']}: {body['size']} entries, root {body['root'][:16]}..., {body['time']}")
    if not A.have_crypto():
        _chk(out, "signatures", "warn", "the `cryptography` package is not installed (pip install 'guldo-cli[attest]'): NO signature was checked, so none is counted")
        return res
    if tree_root is not None and tree_root != body["root"]:
        _chk(out, "entries", "fail", "the head's root is not the root of the entries supplied")
    elif tree_root is not None:
        _chk(out, "entries", "pass", "the head's root is the root of the entries supplied")
    lg = bundle["log"]
    if not _sig_ok(lg["pubkey"], lg["sig"], _cp_msg(body)):
        _chk(out, "log signature", "fail", "the operator's signature does not verify")
    elif log_pubkey is None:
        _chk(out, "log signature", "warn", f"valid for key {lg['pubkey'][:16]}..., but you did not pin the log's key (--log-key): it shows a key signed this, not whose key it is")
    elif lg["pubkey"] != log_pubkey.lower():
        _chk(out, "log signature", "fail", f"signed by {lg['pubkey'][:16]}..., not the key you pinned ({log_pubkey[:16]}...)")
    else:
        _chk(out, "log signature", "pass", f"signed by the pinned log key {lg['pubkey'][:16]}...")
    seen = {}
    ws = bundle.get("witnesses")
    if ws is not None and not isinstance(ws, list):
        _chk(out, "witness", "warn", "the witnesses field is not a list: ignored")
        ws = []
    if ws and len(ws) > MAX_COSIGS:
        _chk(out, "witness", "warn", f"{len(ws)} co-signatures supplied: only the first {MAX_COSIGS} are checked")
        ws = ws[:MAX_COSIGS]
    for w in ws or []:
        if not _valid_cosig(w) or (w["origin"], w["log_key"], w["size"], w["root"]) != (body["origin"], lg["pubkey"], body["size"], body["root"]):
            _chk(out, "witness", "warn", "a co-signature is malformed or is for a different head, or for a different key's log: ignored")
        elif w["pubkey"] == lg["pubkey"]:
            _chk(out, "witness", "warn", "the log's own key co-signed its own head: not counted as a witness")
        elif not _sig_ok(w["pubkey"], w["sig"], _cosig_msg(w["origin"], w["log_key"], w["size"], w["root"], w["time"])):
            _chk(out, "witness", "warn", f"the co-signature of {w['pubkey'][:16]}... does not verify: ignored")
        else:
            seen[w["pubkey"]] = w
    res["pinned"] = sum(1 for k in seen if k in trusted)
    res["unvouched"] = len(seen) - res["pinned"]
    _chk(out, "witnesses", "pass" if res["pinned"] >= max(min_witnesses, 1) else ("skip" if not min_witnesses else "fail"),
         f"{res['pinned']} co-signature(s) from keys you pinned, {res['unvouched']} from keys nobody vouched for (only the first number counts as independent)"
         + (f"; you required {min_witnesses}" if min_witnesses else ""))
    res["ok"] = all(c["status"] != "fail" for c in out)
    return res


# ------------------------------------------------------------------ entries and admission
ENTRY_VERSION = 2
KINDS = ("certificate", "attestation", "run")
# Three kinds of leaf share one tree, so one head and one set of witnesses vouch for all of them:
#   certificate  a verified certificate (what the log was built for)
#   attestation  a signed statement by a key that RE-CHECKED or RE-EXECUTED a logged certificate (attest.py's format)
#   run          a signed statement by a key that RAN it: the operator's own sandbox records match the certificate's ladders byte for byte (runattest.py)
CERT_KEYS = {"v", "seq", "logged", "kind", "cert_sha256", "cert_canon_sha256", "measurement_sha256", "cert_bytes", "family", "solver", "submission_sha256", "credit_bits",
             "status", "private", "counted", "seeds_revealed", "source", "rules_sha256", "checks"}
ATT_KEYS = {"v", "seq", "logged", "kind", "target_seq", "target_cert_sha256", "att_sha256", "attester", "verified", "exact", "gap", "executed", "signed_at"}
RUN_KEYS = {"v", "seq", "logged", "kind", "target_seq", "target_cert_sha256", "att_sha256", "attester", "sandbox", "image", "instance_version", "round_id", "round_log_head", "signed_at"}
CLAIM_FIELDS = ("cert_sha256", "cert_canon_sha256", "measurement_sha256", "family", "submission_sha256", "credit_bits", "status", "private", "counted", "seeds_revealed", "source", "rules_sha256")
MAX_ATT_BYTES = 64 << 10      # a statement is a few KB, up to ~45 KB for a full re-run's per-instance gaps (MAX_GAPS numbers): this cap is what keeps the log from being a place to park text
MAX_ATT_PER_PAIR = 8       # attestations one key may log about one certificate: a key can re-measure again later, but cannot bury a log in its own statements
_SANDBOX = re.compile(r"[a-z0-9_.-]{1,30}")
_IMAGE = re.compile(r"[A-Za-z0-9_.:@+/-]{1,128}")
_ROUNDID = re.compile(r"[A-Za-z0-9_.-]{1,64}")


def _isint(x):
    return isinstance(x, int) and not isinstance(x, bool)


def _hex_or_none(x):
    return x is None or (isinstance(x, str) and _HEX64.fullmatch(x) is not None)


def _valid_entry(e, seq):
    """Any kind of entry. Every field is plain, bounded and typed: an entry is attacker-influenced data that is printed, hashed and shown on a web page."""
    try:
        if not (isinstance(e, dict) and e.get("v") == ENTRY_VERSION and _isint(e.get("seq")) and e["seq"] == seq and e.get("kind") in KINDS
                and isinstance(e.get("logged"), str) and _TIME.fullmatch(e["logged"]) is not None):
            return False
        if e["kind"] == "certificate":
            return _valid_cert_entry(e)
        if not (isinstance(e.get("target_seq"), int) and not isinstance(e["target_seq"], bool) and 0 <= e["target_seq"] < seq
                and isinstance(e.get("target_cert_sha256"), str) and _HEX64.fullmatch(e["target_cert_sha256"]) is not None
                and isinstance(e.get("att_sha256"), str) and _HEX64.fullmatch(e["att_sha256"]) is not None
                and isinstance(e.get("attester"), str) and _HEX64.fullmatch(e["attester"]) is not None
                and isinstance(e.get("signed_at"), str) and _TIME.fullmatch(e["signed_at"]) is not None):
            return False
        if e["kind"] == "attestation":
            ex = e.get("exact")
            return (set(e) == ATT_KEYS and isinstance(e["verified"], bool) and isinstance(e["executed"], bool)
                    and (ex is None or (isinstance(ex, dict) and set(ex) == {"k", "of", "mismatches"} and all(_isint(v) and 0 <= v <= 10 ** 9 for v in ex.values())))
                    and (e["gap"] is None or (isinstance(e["gap"], float) and math.isfinite(e["gap"]))))
        return (set(e) == RUN_KEYS and isinstance(e["sandbox"], str) and _SANDBOX.fullmatch(e["sandbox"]) is not None
                and isinstance(e["image"], str) and _IMAGE.fullmatch(e["image"]) is not None
                and isinstance(e["instance_version"], str) and _NAME.fullmatch(e["instance_version"]) is not None
                and (e["round_id"] is None or (isinstance(e["round_id"], str) and _ROUNDID.fullmatch(e["round_id"]) is not None)) and _hex_or_none(e["round_log_head"]))
    except (KeyError, TypeError):
        return False


def _valid_cert_entry(e):
    try:
        return (set(e) == CERT_KEYS
                and isinstance(e["cert_sha256"], str) and _HEX64.fullmatch(e["cert_sha256"]) is not None
                and isinstance(e["cert_canon_sha256"], str) and _HEX64.fullmatch(e["cert_canon_sha256"]) is not None
                and isinstance(e["measurement_sha256"], str) and _HEX64.fullmatch(e["measurement_sha256"]) is not None
                and _isint(e["cert_bytes"]) and 0 <= e["cert_bytes"] <= MAX_CERT_BYTES
                and isinstance(e["family"], str) and _FAMILY.fullmatch(e["family"]) is not None
                and isinstance(e["solver"], str) and _NAME.fullmatch(e["solver"]) is not None
                and (e["submission_sha256"] is None or (isinstance(e["submission_sha256"], str) and _HEX64.fullmatch(e["submission_sha256"]) is not None))
                and (e["credit_bits"] is None or (isinstance(e["credit_bits"], float) and math.isfinite(e["credit_bits"])))
                and isinstance(e["status"], str) and len(e["status"]) <= 200 and all(32 <= ord(c) < 127 for c in e["status"])
                and all(isinstance(e[k], bool) for k in ("private", "counted", "seeds_revealed")) and e["source"] in ("round", "standalone")
                and isinstance(e["rules_sha256"], str) and _HEX64.fullmatch(e["rules_sha256"]) is not None
                and isinstance(e["checks"], dict) and set(e["checks"]) <= {"pass", "fail", "skip", "warn"} and all(_isint(v) and 0 <= v <= 1000 for v in e["checks"].values()))
    except (KeyError, TypeError):
        return False


def _bad_constant(name):
    raise ValueError(f"{name} is not valid JSON")


def measurement_id(cert):
    """What was MEASURED, independent of how the certificate file happens to be written: the problem, the solver, the committed seeds, every raw record, and the rules.
    Two certificates with the same id are the same measurement (an edited `created` timestamp changes the file's hash but not this)."""
    sub = cert.get("submission") if isinstance(cert.get("submission"), dict) else {}
    ladders = cert.get("ladders")
    try:
        # a PRIVATE-solver certificate strips the failure text (a traceback quotes the solver's own lines) from its submission ladders. Hash every certificate's ladders as that
        # redaction leaves them (it is idempotent), or the private and public forms of one run would be two "different" measurements as soon as one instance crashed
        ladders = K.make_private({"submission": {}, "ladders": ladders})["ladders"]
    except Exception:  # noqa: BLE001 a malformed ladder: verification refuses it anyway; hash what is there
        pass
    return K.sha256(K.canon({"family": cert.get("family"), "submission": sub.get("sha256"), "commitments": cert.get("commitments"), "ladders": ladders, "rules": cert.get("rules")}))


def rank(e):
    """How much evidence a certificate file carries about its measurement: seeds revealed (instances recomputable), solver public (re-runnable), a round log (commitments shown first)."""
    return (int(e["seeds_revealed"]), int(not e["private"]), int(e["source"] == "round"))


def is_upgrade(new, old):
    return all(a >= b for a, b in zip(new, old)) and any(a > b for a, b in zip(new, old))


def build_entry(seq, now, raw, cert, res):
    """The log's record of one verified certificate. Everything in it is recomputed from the certificate, so anyone holding the file can regenerate it (`recheck_entry`)."""
    claim, sub = res["claim"], (cert.get("submission") if isinstance(cert.get("submission"), dict) else {})
    cr = claim.get("credit_bits")
    family = cert.get("family")
    if not isinstance(family, str) or not _FAMILY.fullmatch(family):
        raise Rejected("the problem name is not plain text (letters, digits, _ . -)")
    sub_sha = sub.get("sha256")
    checks = {}
    for c in res["checks"]:
        checks[c["status"]] = checks.get(c["status"], 0) + 1
    return {"v": ENTRY_VERSION, "seq": seq, "logged": now, "kind": "certificate", "cert_sha256": K.sha256(raw), "cert_canon_sha256": K.sha256(K.canon(cert)),
            "measurement_sha256": measurement_id(cert), "cert_bytes": len(raw), "family": family,
            "solver": _clean(sub.get("name", ""), 60), "submission_sha256": sub_sha if isinstance(sub_sha, str) and _HEX64.fullmatch(sub_sha) else None,
            "credit_bits": float(cr) if isinstance(cr, (int, float)) and not isinstance(cr, bool) and math.isfinite(cr) else None,
            "status": _clean(claim.get("status", ""), 200), "private": cert.get("private") is True, "counted": bool(res.get("counted")),
            "seeds_revealed": cert.get("seeds_revealed") is True, "source": "round" if isinstance(cert.get("log"), list) and cert["log"] else "standalone",
            "rules_sha256": K.sha256(K.canon(cert.get("rules"))), "checks": checks}


def _quiet(*a, **k):
    pass


def _default_verify(cert):
    return K.verify(cert, log=_quiet)    # certificate.verify prints every check by default; the log reports its own outcome


def admit(raw, verify=None):
    """-> (certificate, verification result). A certificate is untrusted input: nothing in it is executed (certificate.verify's default), and it is admitted only if EVERY check
    passes or is skipped and the claim it makes is the claim recomputed from its raw records."""
    verify = verify or _default_verify
    if not isinstance(raw, bytes):
        raise TypeError("a certificate is bytes")
    if len(raw) > MAX_CERT_BYTES:
        raise Rejected(f"larger than the {MAX_CERT_BYTES >> 20} MB limit")
    try:
        cert = json.loads(raw.decode("utf-8"), parse_constant=_bad_constant)
    except (UnicodeDecodeError, ValueError, RecursionError) as e:
        raise Rejected(f"not JSON ({type(e).__name__})")
    if not isinstance(cert, dict) or cert.get("format") != K.FORMAT:
        raise Rejected(f"not a {K.FORMAT} certificate")
    problem = cert_shape_problem(cert)
    if problem:
        raise Rejected(problem)
    try:
        res = verify(cert)
    except Exception as e:  # noqa: BLE001 certificate.verify catches only some exception types: a 400-character `reference_name` raises OSError (File name too long) straight through it
        raise Rejected(f"the verifier could not process it ({type(e).__name__})")
    if not res.get("ok") or not isinstance(res.get("claim"), dict):
        bad = [f"{c['check']}: {_scrub(_clean(c.get('detail', ''), 400))[:160]}" for c in res.get("checks", []) if c.get("status") == "fail"]
        raise Rejected("does not verify (" + "; ".join(bad[:3]) + ")")
    return cert, res


def _hexstr(x):
    return isinstance(x, str) and _HEX64.fullmatch(x) is not None


ATT_STATEMENT_KEYS = frozenset({"at", "cert_sha256", "checks", "claim", "executed", "format", "machine", "note", "private_solver", "pubkey", "rerun", "rerun_requested", "sample_seed", "verified"})
CERT_TOP_KEYS = frozenset({"format", "created", "family", "claim", "entries", "rules", "commitments", "seeds", "seeds_revealed", "submission", "baseline", "ladders", "log", "log_note",
                           "private", "domain", "count"})


def _small(x, n):
    try:
        return len(K.canon(x)) <= n
    except (TypeError, ValueError, RecursionError):
        return False


def attestation_shape_problem(att):
    """None if `att` is exactly the shape attest.py writes with every field small, else why not. A log is append-only and public: whatever a stranger gets admitted is stored and
    served FOR GOOD, so a signed statement may not carry a megabyte of text of the signer's choosing (the fourth audit stored 400 KB in an unknown field, in a signed `note`, and in `claim`)."""
    if not isinstance(att, dict) or set(att) != {"statement", "signature"} or not isinstance(att["signature"], str) or not re.fullmatch(r"[0-9a-f]{128}", att["signature"]):
        return "not the shape attest.py writes"
    st = att["statement"]
    if not isinstance(st, dict) or set(st) != ATT_STATEMENT_KEYS:
        return "a statement with fields attest.py never writes, or missing some"
    ok = (isinstance(st["verified"], bool) and isinstance(st["executed"], bool) and isinstance(st["private_solver"], bool)
          and _isint(st["rerun_requested"]) and 0 <= st["rerun_requested"] <= 10 ** 6 and (st["sample_seed"] is None or _isint(st["sample_seed"]))
          and isinstance(st["note"], str) and len(st["note"]) <= 300 and isinstance(st["at"], str) and len(st["at"]) <= 30
          and isinstance(st["checks"], list) and len(st["checks"]) <= 40
          and all(isinstance(c, dict) and set(c) == {"check", "status"} and isinstance(c["check"], str) and len(c["check"]) <= 80 and isinstance(c["status"], str) and len(c["status"]) <= 10 for c in st["checks"])
          and (st["claim"] is None or (isinstance(st["claim"], dict) and _small(st["claim"], 4000)))
          and (st["rerun"] is None or _rerun_ok(st["rerun"]))
          and isinstance(st["machine"], dict) and _small(st["machine"], 600))
    return None if ok else "a statement field is outside the sizes and types attest.py writes"


RERUN_KEYS = frozenset({"k", "of", "exact", "mismatches", "median_gap_bits", "gaps_bits", "tolerance_bits", "sample_seed"})
MAX_GAPS = 5000


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) and abs(x) <= 1e6


def _rerun_ok(rr):
    """What certificate._rerun records about a re-execution: counts and NUMBERS only. A timed re-run keeps one gap per re-run instance (`gaps_bits`), so `attest sign --rerun all` on an ordinary
    certificate writes hundreds of numbers: a byte cap on the whole field (the first version) rejected exactly the strongest evidence. Numbers only, bounded in count, is the right bound."""
    if not isinstance(rr, dict) or not set(rr) <= RERUN_KEYS:
        return False
    for k in ("k", "of", "mismatches"):
        if k in rr and not (_isint(rr[k]) and 0 <= rr[k] <= 10 ** 9):
            return False
    if "exact" in rr and not isinstance(rr["exact"], bool):
        return False
    if "sample_seed" in rr and not (rr["sample_seed"] is None or _isint(rr["sample_seed"])):
        return False
    for k in ("median_gap_bits", "tolerance_bits"):
        if k in rr and not _num(rr[k]):
            return False
    g = rr.get("gaps_bits")
    return g is None or (isinstance(g, list) and len(g) <= MAX_GAPS and all(_num(x) for x in g))


def cert_shape_problem(cert):
    """None if the certificate has only the fields `certificate.build` writes, with the free-text ones bounded. What remains arbitrary text (the solver's source, a declared
    domain's files, ladder lines, round-log data) is inherent to a certificate and bounded only by MAX_CERT_BYTES: an operator who exposes a public endpoint must know that."""
    extra = set(cert) - CERT_TOP_KEYS
    if extra:
        return "it carries fields a certificate never has (" + ", ".join(sorted(_clean(k, 30) for k in list(extra)[:3])) + ")"
    for k, allowed in (("submission", {"name", "sha256", "source"}), ("baseline", {"name", "sha256", "source"}), ("rules", {"code", "dims", "instance_version", "cost_model"}),
                       ("domain", {"name", "reference_name", "files"}), ("count", {"steps_per_second", "python", "dims", "n", "cap", "counter_sha256"})):
        v = cert.get(k)
        if v is not None and (not isinstance(v, dict) or set(v) - allowed):
            return f"its `{k}` section carries fields a certificate never has"
    if not isinstance(cert.get("created", ""), str) or len(cert.get("created", "")) > 30:
        return "its `created` field is not a timestamp"
    if cert.get("log_note") is not None and (not isinstance(cert["log_note"], str) or len(cert["log_note"]) > 500):
        return "its `log_note` is too long"
    lad = cert.get("ladders")
    if isinstance(lad, dict) and any(not isinstance(v, dict) or set(v) != {"baseline", "submission"} for v in lad.values()):
        return "a ladder entry carries fields a certificate never has"
    dom = cert.get("domain")
    if isinstance(dom, dict) and isinstance(dom.get("files"), dict) and any(not isinstance(f, dict) or set(f) != {"sha256", "text"} for f in dom["files"].values()):
        return "a declared-domain file carries fields a certificate never has"
    return None


def parse_attestation(att):
    """-> (kind, fields) of an attestation or a run statement whose SIGNATURE verifies. Raises Rejected. The statement's own claims (verified, re-run results) are the
    signer's, recorded as signed: what they are worth depends on whether the reader pinned the signer's key."""
    if not isinstance(att, dict) or not isinstance(att.get("statement"), dict):
        raise Rejected("not an attestation")
    if not A.have_crypto():
        raise Rejected("the `cryptography` package is not installed here, so a signature cannot be verified")
    st = att["statement"]
    if st.get("format") == A.FORMAT:
        problem = attestation_shape_problem(att)
        if problem:
            raise Rejected(problem)
        if not A._valid_signature(att):
            raise Rejected("the signature does not verify")
        try:
            w = A._wellformed(st)
        except (ValueError, KeyError, TypeError) as e:
            raise Rejected(f"malformed statement ({e})")
        pub, canon, at = st.get("pubkey"), st.get("cert_sha256"), st.get("at")
        if not (_hexstr(pub) and _hexstr(canon) and isinstance(at, str) and _TIME.fullmatch(at)):
            raise Rejected("malformed key, certificate digest or time")
        return "attestation", {"attester": pub, "cert_canon": canon, "signed_at": at, "verified": w["verified"], "exact": w["exact"], "gap": w["gap"], "executed": st.get("executed") is True}
    if st.get("format") == RA.FORMAT:
        try:
            return "run", RA.parse(att)
        except ValueError as e:
            raise Rejected(str(e))
    raise Rejected("an unknown attestation format")


def build_att_entry(seq, now, raw, kind, f, target):
    e = {"v": ENTRY_VERSION, "seq": seq, "logged": now, "kind": kind, "target_seq": target["seq"], "target_cert_sha256": target["cert_sha256"], "att_sha256": K.sha256(raw),
         "attester": f["attester"], "signed_at": f["signed_at"]}
    if kind == "attestation":
        e.update(verified=f["verified"], exact=f["exact"], gap=f["gap"], executed=f["executed"])
    else:
        e.update(sandbox=f["sandbox"], image=f["image"], instance_version=f["instance_version"], round_id=f["round_id"], round_log_head=f["round_log_head"])
    return e


def admit_attestation(raw, certs, load_cert):
    """-> (kind, fields, target entry). `certs` maps a certificate's canonical digest to its log entry; load_cert(entry) returns the certificate the log serves for it (or None).
    A run statement must also carry the digest of THAT certificate's ladders, so it cannot be moved onto a different measurement."""
    if not isinstance(raw, bytes):
        raise TypeError("an attestation is bytes")
    if len(raw) > MAX_ATT_BYTES:
        raise Rejected(f"larger than the {MAX_ATT_BYTES >> 10} KB limit")
    try:
        att = json.loads(raw.decode("utf-8"), parse_constant=_bad_constant)
    except (UnicodeDecodeError, ValueError, RecursionError) as e:
        raise Rejected(f"not JSON ({type(e).__name__})")
    kind, f = parse_attestation(att)
    target = certs.get(f["cert_canon"])
    if target is None:
        raise Rejected(f"it is not about a certificate in this log (it names {f['cert_canon'][:16]}...)")
    if kind == "run":
        cert = load_cert(target)
        if not isinstance(cert, dict) or not isinstance(cert.get("ladders"), dict) or RA.ladders_sha256(cert) != f["ladders_sha256"] or cert.get("family") != f["family"]:
            raise Rejected("its ladder digest is not the logged certificate's ladders")
    return kind, f, target


def _recheck_attestation(entry, raw, entries, load_cert=None):
    if K.sha256(raw) != entry["att_sha256"]:
        return "mismatch", "the file does not hash to the entry's att_sha256"
    try:
        kind, f = parse_attestation(json.loads(raw.decode("utf-8"), parse_constant=_bad_constant))
    except (Rejected, ValueError, UnicodeDecodeError, RecursionError) as e:
        return "mismatch", f"the attestation no longer verifies: {e}"
    target = entries[entry["target_seq"]] if entries is not None and 0 <= entry["target_seq"] < len(entries) else None
    if target is None or target["kind"] != "certificate":
        return "mismatch", "its target is not a certificate entry"
    if f["cert_canon"] != target["cert_canon_sha256"]:
        return "mismatch", "it is about a different certificate than the entry says"
    if kind == "run" and load_cert is not None:
        cert = load_cert(target)
        if not isinstance(cert, dict) or not isinstance(cert.get("ladders"), dict) or RA.ladders_sha256(cert) != f["ladders_sha256"]:
            return "mismatch", "its ladder digest is not the logged certificate's ladders"
    again = build_att_entry(entry["seq"], entry["logged"], raw, kind, f, target)
    diff = [k for k in again if again[k] != entry.get(k)]
    return ("mismatch", "recomputed differently: " + ", ".join(f"{k} is {entry.get(k)!r} in the log, {again[k]!r} recomputed" for k in diff)) if diff else ("match", "recomputed from the file: identical")


def recheck_entry(entry, raw, verify=None, entries=None, load_cert=None):
    """An auditor's check of one entry against the file it names -> ("match" | "mismatch" | "unknown", detail).
    "unknown" is not an accusation: a certificate verifies only under the protocol code it was built with, and a newer checkout reports that as a failed `rules` check.
    Attestations need `entries` (to find their target) and, for a run statement, `load_cert` (to compare ladder digests)."""
    if entry["kind"] != "certificate":
        return _recheck_attestation(entry, raw, entries, load_cert)
    if K.sha256(raw) != entry["cert_sha256"]:
        return "mismatch", "the file does not hash to the entry's cert_sha256"
    try:
        cert, res = admit(raw, verify)
    except Rejected as e:
        failed = []
        if str(e).startswith("does not verify"):
            try:
                failed = [c["check"] for c in (verify or _default_verify)(json.loads(raw.decode("utf-8"))).get("checks", []) if c.get("status") == "fail"]
            except Exception:  # noqa: BLE001 a certificate that crashes the verifier is not a version difference
                failed = []
        if failed and set(failed) <= {"rules"}:     # ONLY the rules fingerprint: a version difference. A `domain` failure means the declaration does not match its own recorded hash: tampering, never "unknown"
            return "unknown", "this checkout's protocol code differs from the one the certificate was built with (rules); rebuild that version to re-check"
        return "mismatch", f"the certificate no longer verifies: {e}"
    again = build_entry(entry["seq"], entry["logged"], raw, cert, res)
    diff = [k for k in CLAIM_FIELDS if again.get(k) != entry.get(k)]
    return ("mismatch", "recomputed differently: " + ", ".join(f"{k} is {entry.get(k)!r} in the log, {again.get(k)!r} recomputed" for k in diff)) if diff else ("match", "recomputed from the certificate: identical")


def recheck_served(d, e, serve, verify=None):
    """recheck_entry for an entry whose file the log serves through `serve(path)` -> bytes | None. None means the log does not serve it."""
    raw = serve(entry_path(e))
    if raw is None:
        return None

    def load_cert(t):
        r = serve(entry_path(t))
        try:
            return json.loads(r.decode("utf-8")) if r is not None else None
        except (ValueError, UnicodeDecodeError, RecursionError):
            return None
    return recheck_entry(e, raw, verify, d.entries, load_cert)


# ------------------------------------------------------------------ reading a log (a directory, or a URL: the same files)
def dir_reader(path):
    def read(name):
        if not _READ_NAME.fullmatch(name) or ".." in name:
            raise LogError(f"refusing to read {name!r}")
        p = os.path.join(path, name)
        if not os.path.isfile(p):
            return None
        if os.path.getsize(p) > MAX_LOG_BYTES:
            raise LogError(f"{name} is larger than {MAX_LOG_BYTES >> 20} MB")
        with open(p, "rb") as f:
            return f.read()
    return read


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    """A log server must not be able to aim the reader somewhere else: urllib follows a redirect to ftp:// (a connection to any host and port the server names) and would follow
    https to http. Redirects stay on http(s) and never downgrade."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        old = urllib.parse.urlparse(req.full_url).scheme
        new = urllib.parse.urlparse(urllib.parse.urljoin(req.full_url, newurl)).scheme
        if new not in ("http", "https") or (old == "https" and new != "https"):
            raise urllib.error.HTTPError(req.full_url, code, f"refused a redirect to {new}://", headers, fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_OPENER = urllib.request.build_opener(_SafeRedirect)


def url_reader(base, timeout=30):
    if urllib.parse.urlparse(base).scheme not in ("http", "https"):
        raise LogError("a log URL must be http or https")

    def read(name):
        if not _READ_NAME.fullmatch(name) or ".." in name:
            raise LogError(f"refusing to read {name!r}")
        req = urllib.request.Request(base.rstrip("/") + "/" + name, headers={"User-Agent": "guldo-translog"})
        try:
            with _OPENER.open(req, timeout=timeout) as r:
                data = r.read(MAX_LOG_BYTES + 1)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise LogError(f"{name}: HTTP {e.code}")
        except (urllib.error.URLError, OSError) as e:
            raise LogError(f"{name}: {e}")
        if len(data) > MAX_LOG_BYTES:
            raise LogError(f"{name} is larger than {MAX_LOG_BYTES >> 20} MB")
        return data
    return read


def reader_for(where):
    return url_reader(where) if re.match(r"https?://", where) else dir_reader(where)


def _json_lines(raw):
    """Complete lines only. -> (list of parsed objects, list of raw lines, torn: bool)."""
    if not raw:
        return [], [], False
    torn = not raw.endswith(b"\n")
    lines = raw.split(b"\n")[:-1]
    objs = []
    for ln in lines:
        objs.append(json.loads(ln.decode("utf-8"), parse_constant=_bad_constant))
    return objs, lines, torn


def relation_problems(entries):
    """Rules BETWEEN entries, which no single entry shows, checked from the entries alone so any reader (and any witness) can enforce them on an operator that would not:
      * a certificate file is logged once;
      * a measurement is logged once, unless a later file is a strict UPGRADE of it (seeds revealed, solver public, a round log): an edited timestamp is not a new measurement;
      * an attestation or run statement names an EARLIER certificate entry, by hash, is logged once, and one key attests one certificate at most MAX_ATT_PER_PAIR times."""
    out, seen_cert, seen_att, meas, pair = [], {}, {}, {}, {}
    for i, e in enumerate(entries):
        if e["kind"] == "certificate":
            if e["cert_sha256"] in seen_cert:
                out.append(f"entry {i} repeats the certificate of entry {seen_cert[e['cert_sha256']]}")
            seen_cert[e["cert_sha256"]] = i
            prev = meas.get(e["measurement_sha256"])
            if prev is not None and not is_upgrade(rank(e), prev[1]):
                out.append(f"entry {i} is the same measurement as entry {prev[0]} and not a strict upgrade of it (seeds revealed, solver public, or a round log)")
            else:
                meas[e["measurement_sha256"]] = (i, rank(e))
        else:
            t = entries[e["target_seq"]]
            if t["kind"] != "certificate" or t["cert_sha256"] != e["target_cert_sha256"]:
                out.append(f"entry {i} ({e['kind']}) does not name the certificate entry {e['target_seq']} it claims to")
            if e["att_sha256"] in seen_att:
                out.append(f"entry {i} repeats the {e['kind']} file of entry {seen_att[e['att_sha256']]}")
            seen_att[e["att_sha256"]] = i
            k = (e["kind"], e["attester"], e["target_seq"])
            pair[k] = pair.get(k, 0) + 1
            if pair[k] == MAX_ATT_PER_PAIR + 1:
                out.append(f"entry {i}: one key has logged more than {MAX_ATT_PER_PAIR} {e['kind']} statements about certificate entry {e['target_seq']}")
    return out


def entry_path(e):
    """Where a log serves the file an entry is about."""
    return f"certs/{e['cert_sha256']}.cert.json" if e["kind"] == "certificate" else f"attestations/{e['att_sha256']}.att.json"


def entry_file_sha(e):
    return e["cert_sha256"] if e["kind"] == "certificate" else e["att_sha256"]


class LogData:
    def __init__(self):
        self.meta, self.head = None, None
        self.lines, self.entries, self.checkpoints, self.cosigs, self.anchors = [], [], [], [], []
        self.tree = Tree()
        self.problems = []
        self.torn = False

    @property
    def certs(self):
        return [e for e in self.entries if e["kind"] == "certificate"]

    @property
    def size(self):
        return len(self.entries)

    @property
    def origin(self):
        return self.meta["origin"] if self.meta else None


def parse_log(read):
    """Read and structurally check a whole log. Never raises on bad data: every defect is a line in .problems (a reader decides what to do)."""
    d = LogData()
    # Read order matters when a log is being served live: the operator appends entries BEFORE the head that covers them, so a reader must read the heads first and
    # entries.jsonl LAST. Any other order can see a head for entries it has not got yet and report a healthy log as "damaged".
    raws = {name: read(name) for name in ("log.json", "checkpoint.json", "checkpoints.jsonl", "cosigs.jsonl", "anchors.jsonl", "entries.jsonl")}
    try:
        raw = raws["log.json"]
        meta = json.loads(raw.decode("utf-8"), parse_constant=_bad_constant) if raw else None
    except (ValueError, UnicodeDecodeError):
        meta = None
    if (not isinstance(meta, dict) or meta.get("format") != LOG_FORMAT or not isinstance(meta.get("origin"), str) or not _ORIGIN.fullmatch(meta["origin"])
            or not isinstance(meta.get("pubkey"), str) or not _HEX64.fullmatch(meta["pubkey"])):
        d.problems.append("log.json is missing or is not a guldo transparency log")
        return d
    d.meta = meta
    try:
        objs, lines, d.torn = _json_lines(raws["entries.jsonl"])
    except (ValueError, UnicodeDecodeError, RecursionError) as e:
        d.problems.append(f"entries.jsonl is not one JSON object per line ({type(e).__name__})")
        return d
    if d.torn:
        d.problems.append("entries.jsonl ends in a partial line (a write was interrupted): the operator must run `translog.py repair`")
    for i, (e, ln) in enumerate(zip(objs, lines)):
        if not _valid_entry(e, i):
            d.problems.append(f"entry {i} is malformed or out of order")
            return d
        if K.canon(e).encode() != ln:
            d.problems.append(f"entry {i} is not in canonical form, so its leaf bytes are ambiguous")
            return d
        d.entries.append(e)
        d.lines.append(ln)
        d.tree.append(leaf_hash(ln))
    d.problems.extend(relation_problems(d.entries))
    try:
        cps, _, _ = _json_lines(raws["checkpoints.jsonl"])
    except (ValueError, UnicodeDecodeError, RecursionError):
        d.problems.append("checkpoints.jsonl is not one JSON object per line")
        cps = []
    last = None
    for j, c in enumerate(cps):
        if not isinstance(c, dict) or not _valid_body(c.get("body")) or not _valid_sigfield(c.get("log")):
            d.problems.append(f"head {j} is malformed")
            continue
        b = c["body"]
        if b["origin"] != d.meta["origin"]:
            d.problems.append(f"head {j} is for another log ({b['origin']})")
        elif b["size"] > d.size:
            d.problems.append(f"head {j} covers {b['size']} entries but the log holds {d.size}: entries were removed")
        elif b["root"] != _hx(d.tree.root(b["size"])):
            d.problems.append(f"head {j} (size {b['size']}) signs a root that the entries do not produce: history was rewritten")
        if last and (b["size"] < last["size"] or b["time"] < last["time"]):
            d.problems.append(f"head {j} goes backwards (size {b['size']} after {last['size']}, or earlier in time)")
        last = b
        d.checkpoints.append(c)
    try:
        cos, _, _ = _json_lines(raws["cosigs.jsonl"])
    except (ValueError, UnicodeDecodeError, RecursionError):
        d.problems.append("cosigs.jsonl is not one JSON object per line")
        cos = []
    for j, c in enumerate(cos):
        if not _valid_cosig(c):
            d.problems.append(f"co-signature {j} is malformed")
        elif c["origin"] != d.meta["origin"] or c["log_key"] != d.meta["pubkey"] or c["size"] > d.size or c["root"] != _hx(d.tree.root(c["size"])):
            d.problems.append(f"co-signature {j} is for a head, or another key's log, that these entries do not produce")
        else:
            d.cosigs.append(c)
    try:
        d.anchors, _, _ = _json_lines(raws["anchors.jsonl"])
    except (ValueError, UnicodeDecodeError, RecursionError):
        d.problems.append("anchors.jsonl is not one JSON object per line")
    try:
        raw = raws["checkpoint.json"]
        head = json.loads(raw.decode("utf-8"), parse_constant=_bad_constant) if raw else None
    except (ValueError, UnicodeDecodeError):
        head = None
        d.problems.append("checkpoint.json is not JSON")
    if head is not None:
        if not isinstance(head, dict) or not _valid_body(head.get("body")) or not _valid_sigfield(head.get("log")):
            d.problems.append("checkpoint.json is not a well-formed signed head")
        elif head["body"]["size"] > d.size or head["body"]["root"] != _hx(d.tree.root(head["body"]["size"])):
            d.problems.append("checkpoint.json signs a root that the entries do not produce")
        elif not any(K.canon(c["body"]) == K.canon(head["body"]) and c["log"] == head["log"] for c in d.checkpoints):
            d.problems.append("checkpoint.json is not among the heads in checkpoints.jsonl")
        else:
            d.head = head
    return d


def verify_signatures(d, pinned=None):
    """Every head ever issued must carry a valid signature by the log's key. -> list of problems (empty = fine); needs `cryptography`."""
    if not A.have_crypto():
        raise A.NeedsCryptography("checking signatures needs the `cryptography` package")
    key = (pinned or d.meta["pubkey"]).lower()
    bad = []
    if d.meta["pubkey"] != key:
        bad.append(f"log.json names key {d.meta['pubkey'][:16]}..., not the key you pinned ({key[:16]}...)")
    for j, c in enumerate(d.checkpoints):
        if c["log"]["pubkey"] != key:
            bad.append(f"head {j} is signed by {c['log']['pubkey'][:16]}..., not the log's key")
        elif not _sig_ok(c["log"]["pubkey"], c["log"]["sig"], _cp_msg(c["body"])):
            bad.append(f"head {j} (size {c['body']['size']}): the signature does not verify")
    for j, c in enumerate(d.cosigs):
        if not _sig_ok(c["pubkey"], c["sig"], _cosig_msg(c["origin"], c["log_key"], c["size"], c["root"], c["time"])):
            bad.append(f"co-signature {j} does not verify")
    return bad


def head_witnesses(d, body):
    """The co-signatures merged for exactly this head (latest per witness key)."""
    latest = {}
    for c in d.cosigs:
        if ((c["origin"], c["log_key"], c["size"], c["root"]) == (body["origin"], d.meta["pubkey"], body["size"], body["root"])
                and (c["pubkey"] not in latest or c["time"] >= latest[c["pubkey"]]["time"])):
            latest[c["pubkey"]] = c
    return sorted(latest.values(), key=lambda c: c["pubkey"])


# ------------------------------------------------------------------ proofs
def inclusion_proof(d, index, size=None):
    size = d.size if size is None else size
    e = d.entries[index]
    p = {"format": INCL_FORMAT, "origin": d.origin, "index": index, "tree_size": size, "path": [_hx(x) for x in d.tree.inclusion(index, size)], "entry": e}
    if d.head is not None and d.head["body"]["size"] == size:
        p["checkpoint"] = {"body": d.head["body"], "log": d.head["log"], "witnesses": head_witnesses(d, d.head["body"])}
    return p


def consistency_proof(d, old, new=None):
    new = d.size if new is None else new
    return {"format": CONS_FORMAT, "origin": d.origin, "old_size": old, "new_size": new, "old_root": _hx(d.tree.root(old)), "new_root": _hx(d.tree.root(new)),
            "path": [_hx(x) for x in d.tree.consistency(old, new)]}


def check_inclusion(proof, cert_bytes=None, log_pubkey=None, trusted=(), min_witnesses=0):
    """Everything a stranger needs to check, from one file: -> {"ok", "checks"}."""
    out = []
    try:
        if not isinstance(proof, dict) or proof.get("format") != INCL_FORMAT:
            raise ValueError(f"not a {INCL_FORMAT} file")
        e, idx, size = proof["entry"], proof["index"], proof["tree_size"]
        if not _valid_entry(e, idx) or not _isint(size):
            raise ValueError("the entry is malformed")
        path = [_unhex(x) for x in proof["path"]]
        cp = proof.get("checkpoint")
        if not isinstance(cp, dict) or not _valid_body(cp.get("body")):
            raise ValueError("the proof carries no signed head (ask the log for one at this size)")
    except (KeyError, TypeError, ValueError) as e:
        _chk(out, "format", "fail", str(e))
        return {"ok": False, "checks": out}
    leaf = leaf_hash(K.canon(e).encode())
    body = cp["body"]
    if (body["origin"], body["size"]) != (proof.get("origin"), size):
        _chk(out, "head", "fail", "the head is for another log or another size than the proof")
    elif verify_inclusion(leaf, idx, size, path, bytes.fromhex(body["root"])):
        _chk(out, "inclusion", "pass", f"entry {idx} (a leaf of {_hx(leaf)[:16]}...) is in the tree of {size} entries with root {body['root'][:16]}...")
    else:
        _chk(out, "inclusion", "fail", "the path does not lead from this entry to the head's root")
    hc = check_checkpoint(cp, log_pubkey, trusted, min_witnesses)
    out.extend(hc["checks"])
    if cert_bytes is not None:
        _chk(out, "file", "pass" if K.sha256(cert_bytes) == entry_file_sha(e) else "fail",
             "the file is the one this entry names" if K.sha256(cert_bytes) == entry_file_sha(e) else "the file does not hash to the sha256 the entry names")
    return {"ok": all(c["status"] != "fail" for c in out), "checks": out, "entry": e}


def check_consistency(proof, old_cp=None, new_cp=None, log_pubkey=None):
    out = []
    try:
        if not isinstance(proof, dict) or proof.get("format") != CONS_FORMAT:
            raise ValueError(f"not a {CONS_FORMAT} file")
        old, new = proof["old_size"], proof["new_size"]
        r1, r2, path = _unhex(proof["old_root"]), _unhex(proof["new_root"]), [_unhex(x) for x in proof["path"]]
        if not _isint(old) or not _isint(new):
            raise ValueError("sizes are not integers")
    except (KeyError, TypeError, ValueError) as e:
        _chk(out, "format", "fail", str(e))
        return {"ok": False, "checks": out}
    _chk(out, "consistency", "pass" if verify_consistency(old, new, r1, r2, path) else "fail",
         f"the tree of {old} entries ({proof['old_root'][:16]}...) is a prefix of the tree of {new} ({proof['new_root'][:16]}...)" if verify_consistency(old, new, r1, r2, path)
         else "the path does not show the older tree to be a prefix of the newer one")
    for label, cp, (size, root) in (("older head", old_cp, (old, proof["old_root"])), ("newer head", new_cp, (new, proof["new_root"]))):
        if cp is None:
            continue
        r = check_checkpoint(cp, log_pubkey)
        for c in r["checks"]:
            if c["check"] in ("log signature", "signatures"):
                _chk(out, f"{label}: {c['check']}", c["status"], c["detail"])
        b = r["body"]
        _chk(out, f"{label}", "pass" if b and (b["size"], b["root"]) == (size, root) else "fail", "matches the proof" if b and (b["size"], b["root"]) == (size, root) else "is not the head the proof is about")
    return {"ok": all(c["status"] != "fail" for c in out), "checks": out}


# ------------------------------------------------------------------ frontier and absence
TIERS = ("logged", "reexecuted", "run")


def evidence(entries):
    """{certificate seq: {"attestation": [entries], "run": [entries]}} from the attestation and run entries among `entries` (a prefix of the log: statements after a head are not covered by it)."""
    ev = {}
    for e in entries:
        if e["kind"] != "certificate":
            ev.setdefault(e["target_seq"], {"attestation": [], "run": []})[e["kind"]].append(e)
    return ev


def is_reexecution(a):
    """An attestation by someone who RE-RAN instances (not merely re-checked the arithmetic) and whose own checks all passed, including the re-run: exact counts for a step-counted
    certificate, a timing within tolerance otherwise. It is still that person's statement about their own machine."""
    return a["verified"] and a["executed"] and (a["exact"] is not None or a["gap"] is not None)


def meets_tier(ev, seq, tier, keys):
    """Does certificate entry `seq` carry evidence of `tier` from a key in `keys`? The KEYS are the reader's: this log cannot say whom to trust."""
    if tier in (None, "logged"):
        return True
    mine = ev.get(seq)
    if tier not in TIERS:
        raise ValueError(f"tier must be one of {TIERS}")
    if not mine:
        return False
    if tier == "reexecuted":
        return any(a["attester"] in keys and is_reexecution(a) for a in mine["attestation"])
    return any(r["attester"] in keys for r in mine["run"])


def frontier(entries, family=None, counted_only=False, tier=None, keys=()):
    """{family: {"entries", "best_credit", "best_seq"}} over the certificate entries among `entries`.
    counted_only keeps step-counted certificates. tier "reexecuted" / "run" keeps only certificates that a key in `keys` re-executed / ran in the sandbox (see is_reexecution,
    runattest.py). There is deliberately no "official only" filter: OFFICIAL is metadata a certificate declares about itself, and a self-built certificate verifies as OFFICIAL;
    "run" is what makes a sandbox claim attributable, to a key the reader pinned."""
    out, keys = {}, {k.lower() for k in keys}
    ev = evidence(entries)
    for e in entries:
        if e["kind"] != "certificate":
            continue
        if family and e["family"] != family:
            continue
        if counted_only and not e["counted"]:
            continue
        if not meets_tier(ev, e["seq"], tier, keys):
            continue
        f = out.setdefault(e["family"], {"entries": 0, "best_credit": None, "best_seq": None})
        f["entries"] += 1
        if e["credit_bits"] is not None and (f["best_credit"] is None or e["credit_bits"] > f["best_credit"]):
            f["best_credit"], f["best_seq"] = e["credit_bits"], e["seq"]
    return out


SCOPE = ("This covers only certificates SUBMITTED to this log and accepted by it: it does not say no better result exists, only that none was put on this record by the head's size. "
         "A logged credit is what its certificate recomputes to, not a verified speed. In a timed certificate the clock readings are the submitter's own, and OFFICIAL is a label "
         "the certificate declares about itself (a self-built certificate verifies as OFFICIAL), so the log vouches for neither. A tier above 'logged' means a key the READER pinned signed a "
         "statement that it re-executed the certificate (attestation) or that its own sandbox records are the certificate's ladders (run): exactly as trustworthy as that key and that machine.")


def absence_claim(d, family, threshold, counted_only=False, tier="logged", keys=()):
    if d.head is None:
        raise LogError("the log has no signed head")
    if tier not in TIERS:
        raise LogError(f"tier must be one of {TIERS}")
    keys = sorted({k.lower() for k in keys})
    if tier != "logged" and not keys:
        raise LogError(f"tier {tier!r} needs the attester keys you pin (--trusted): without them no certificate qualifies and the claim would be empty")
    n = d.head["body"]["size"]
    best = frontier(d.entries[:n], family, counted_only, tier, keys).get(family, {"entries": 0, "best_credit": None, "best_seq": None})
    top = best["best_credit"]
    return {"format": ABSENCE_FORMAT, "origin": d.origin, "family": family, "threshold_bits": threshold, "counted_only": counted_only, "tier": tier, "keys": keys, "entries_scanned": n,
            "best_credit_bits": top, "holds": top is None or top < threshold,
            "checkpoint": {"body": d.head["body"], "log": d.head["log"], "witnesses": head_witnesses(d, d.head["body"])}, "scope": SCOPE}


def check_absence(claim, entry_lines, log_pubkey=None, trusted=(), min_witnesses=0):
    """Recompute a claim from the log's own entries: the root of the supplied entries must be the signed head's root, and the scan is redone here."""
    out = []
    try:
        if not isinstance(claim, dict) or claim.get("format") != ABSENCE_FORMAT:
            raise ValueError(f"not a {ABSENCE_FORMAT} file")
        body, n, thr, fam = claim["checkpoint"]["body"], claim["entries_scanned"], claim["threshold_bits"], claim["family"]
        tier, keys = claim.get("tier", "logged"), claim.get("keys", [])
        if (not _valid_body(body) or body["size"] != n or not isinstance(thr, (int, float)) or isinstance(thr, bool) or not isinstance(fam, str)
                or tier not in TIERS or not isinstance(keys, list) or len(keys) > 200 or not all(_hexstr(k) for k in keys)):
            raise ValueError("the claim is malformed")
        if len(entry_lines) < n:
            raise ValueError(f"the supplied log has {len(entry_lines)} entries, the claim covers {n}")
    except (KeyError, TypeError, ValueError) as e:
        _chk(out, "format", "fail", str(e))
        return {"ok": False, "holds": None, "checks": out}
    t = Tree(leaf_hash(ln) for ln in entry_lines[:n])
    hc = check_checkpoint(claim["checkpoint"], log_pubkey, trusted, min_witnesses, tree_root=_hx(t.root()))
    out.extend(hc["checks"])
    try:
        ents = [json.loads(ln.decode("utf-8"), parse_constant=_bad_constant) for ln in entry_lines[:n]]
        if not all(_valid_entry(e, i) for i, e in enumerate(ents)):
            raise ValueError("an entry is malformed")
    except (ValueError, UnicodeDecodeError) as e:
        _chk(out, "entries", "fail", str(e))
        return {"ok": False, "holds": None, "checks": out}
    best = frontier(ents, fam, claim.get("counted_only") is True, tier, keys).get(fam, {"best_credit": None})["best_credit"]
    holds = best is None or best < thr
    _chk(out, "scan", "pass" if (best == claim.get("best_credit_bits") and holds == claim.get("holds")) else "fail",
         f"best logged credit for {fam}: {best} bits; {'no entry reaches' if holds else 'an entry reaches'} {thr} bits; matches the claim" if (best == claim.get("best_credit_bits") and holds == claim.get("holds"))
         else f"recomputed best {best} bits and holds={holds}, but the claim says {claim.get('best_credit_bits')} and {claim.get('holds')}")
    return {"ok": all(c["status"] != "fail" for c in out), "holds": holds, "checks": out}


# ------------------------------------------------------------------ anchors
def anchor_line(body):
    return f"guldo-tlog {body['origin']} {body['size']} {body['root']} {body['time']}"


def anchor_check(text, body):
    """Does text published somewhere else contain this head's origin, size and root?"""
    want = f"{body['origin']} {body['size']} {body['root']}"
    return want in re.sub(r"\s+", " ", text)


# ------------------------------------------------------------------ the operator's side
@contextlib.contextmanager
def _locked(path):
    fd = os.open(os.path.join(path, ".lock"), os.O_RDWR | os.O_CREAT, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)


def _atomic_write(path, data):
    d = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tmp-")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def _append(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        view = memoryview(data)
        while view:
            view = view[os.write(fd, view):]
        os.fsync(fd)
    finally:
        os.close(fd)


class Log:
    """The operator's handle on a log directory. Everything in the directory is public except .lock; the signing key lives elsewhere."""

    def __init__(self, path):
        self.path = os.path.abspath(path)

    def data(self):
        d = parse_log(dir_reader(self.path))
        if d.problems:
            raise LogError("the log is damaged: " + "; ".join(d.problems[:4]))
        return d

    @classmethod
    def init(cls, path, origin, key_path, now=None):
        if not _ORIGIN.fullmatch(origin):
            raise LogError("origin must look like guldo.org/log (lowercase, digits, . - and up to three /parts)")
        path = os.path.abspath(path)
        if os.path.exists(path) and os.listdir(path):
            raise LogError(f"{path} exists and is not empty")
        kp = os.path.abspath(key_path)
        if kp.startswith(path + os.sep):
            raise LogError("the signing key must live outside the log directory: everything in it is published")
        os.makedirs(path, exist_ok=True)
        priv, ser = A._load_key(key_path)
        pub = A._pub_hex(priv, ser)
        meta = {"format": LOG_FORMAT, "origin": origin, "pubkey": pub, "created": now or now_iso(), "tree": "RFC 9162 Merkle tree, SHA-256",
                "leaf": "SHA-256(0x00 || one line of entries.jsonl, without its newline)", "node": "SHA-256(0x01 || left || right)"}
        for name in ("entries.jsonl", "checkpoints.jsonl", "cosigs.jsonl", "anchors.jsonl"):
            _atomic_write(os.path.join(path, name), b"")
        _atomic_write(os.path.join(path, "log.json"), (json.dumps(meta, indent=1, sort_keys=True) + "\n").encode())
        log = cls(path)
        with _locked(path):
            log._sign_head(log.data(), key_path, now)
        return log

    @staticmethod
    def _check_key(d, key_path):
        """Refuse a wrong key BEFORE anything is appended: an entry added and then left unsigned would be a half-finished state."""
        priv, ser = A._load_key(key_path)
        pub = A._pub_hex(priv, ser)
        if pub != d.meta["pubkey"]:
            raise LogError(f"this key ({pub[:16]}...) is not the log's key ({d.meta['pubkey'][:16]}...)")

    def _sign_head(self, d, key_path, now=None):
        self._check_key(d, key_path)
        t = now or now_iso()
        if d.checkpoints and t < d.checkpoints[-1]["body"]["time"]:
            t = d.checkpoints[-1]["body"]["time"]    # a clock stepped backwards (NTP, a VM restore) must never make heads go backwards: that would make the whole log read as damaged
        body = {"format": CP_FORMAT, "origin": d.origin, "size": d.size, "root": _hx(d.tree.root()), "time": t}
        pub, sig = _sign(key_path, _cp_msg(body))
        cp = {"body": body, "log": {"pubkey": pub, "sig": sig}}
        _append(os.path.join(self.path, "checkpoints.jsonl"), (json.dumps(cp, sort_keys=True, separators=(",", ":")) + "\n").encode())
        self._publish(self.data())

    def _publish(self, d):
        """Write checkpoint.json (the newest head with every witness who co-signed it) and one inclusion proof per entry against it."""
        if not d.checkpoints:
            return
        last = d.checkpoints[-1]
        bundle = {"body": last["body"], "log": last["log"], "witnesses": head_witnesses(d, last["body"])}
        _atomic_write(os.path.join(self.path, "checkpoint.json"), (json.dumps(bundle, indent=1, sort_keys=True) + "\n").encode())
        pdir = os.path.join(self.path, "proofs")
        if d.size > STATIC_PROOF_LIMIT:
            return
        os.makedirs(pdir, exist_ok=True)
        d.head = bundle
        for i in range(min(last["body"]["size"], d.size)):
            _atomic_write(os.path.join(pdir, f"{i}.json"), (json.dumps(inclusion_proof(d, i, last["body"]["size"]), indent=1, sort_keys=True) + "\n").encode())

    def _admit_batch(self, blobs, key_path, now, one, sign=True):
        """The one way anything enters the log. one(d, raw) -> the entry to append (or raises Rejected); every rule BETWEEN entries is `relation_problems`, the same function a reader
        runs, so the operator cannot admit what a witness would refuse. One head is signed for the batch, whatever happens part-way."""
        results = []
        with _locked(self.path):
            d = self.data()
            self._check_key(d, key_path)
            added = False
            try:
                for raw in blobs:
                    try:
                        entry = one(d, raw)
                        mine = [p for p in relation_problems(d.entries + [entry]) if p.startswith(f"entry {entry['seq']} ") or p.startswith(f"entry {entry['seq']}:")]
                        if mine:
                            raise Rejected(mine[0].split(" ", 2)[2] if mine[0].startswith(f"entry {entry['seq']} ") else mine[0])
                    except Rejected as e:
                        results.append((None, str(e)))
                        continue
                    except Exception as e:  # noqa: BLE001 one pathological input (a recursion limit, a full disk in the verifier) must not abort a batch or leave it half-done
                        results.append((None, f"could not be checked ({type(e).__name__}): not admitted"))
                        continue
                    path = os.path.join(self.path, entry_path(entry))
                    os.makedirs(os.path.dirname(path), exist_ok=True)
                    _atomic_write(path, raw)           # the file first: an entry never names a file the log cannot serve
                    line = K.canon(entry).encode()
                    _append(os.path.join(self.path, "entries.jsonl"), line + b"\n")
                    d.entries.append(entry)
                    d.lines.append(line)
                    d.tree.append(leaf_hash(line))
                    results.append((entry, None))
                    added = True
            finally:
                if added and sign:      # whatever happened above, entries that reached the file are covered by a signed head before the lock is released
                    self._sign_head(self.data(), key_path, now)
        return results

    def add(self, blobs, key_path, now=None, verify=None, sign=True):
        """Admit each certificate (bytes) in turn, then sign ONE new head. -> [(entry | None, reason | None)] in the order given."""
        def one(d, raw):
            cert, res = admit(raw, verify)
            sha = K.sha256(raw)
            for e in d.entries:
                if e["kind"] == "certificate" and e["cert_sha256"] == sha:
                    raise Rejected(f"already in the log as entry {e['seq']}")
            entry = build_entry(len(d.entries), now or now_iso(), raw, cert, res)
            if not _valid_entry(entry, entry["seq"]):
                raise Rejected("the entry built from this certificate is malformed")
            return entry
        return self._admit_batch(blobs, key_path, now, one, sign)

    def add_attestations(self, blobs, key_path, now=None, sign=True):
        """Log signed statements about certificates already in the log: an attest.py statement (a re-check or a re-execution by someone) or a runattest.py statement (the
        operator's own sandbox records match). The statement is recorded as signed; what it is worth depends on whether a reader pinned the signer's key."""
        def one(d, raw):
            certs = {}
            for e in d.entries:
                if e["kind"] == "certificate":
                    certs.setdefault(e["cert_canon_sha256"], e)

            def load_cert(t):
                try:
                    with open(os.path.join(self.path, entry_path(t)), "rb") as f:
                        return json.loads(f.read().decode("utf-8"))
                except (OSError, ValueError):
                    return None
            kind, f, target = admit_attestation(raw, certs, load_cert)
            sha = K.sha256(raw)
            for e in d.entries:
                if e["kind"] != "certificate" and e["att_sha256"] == sha:
                    raise Rejected(f"already in the log as entry {e['seq']}")
            entry = build_att_entry(len(d.entries), now or now_iso(), raw, kind, f, target)
            if not _valid_entry(entry, entry["seq"]):
                raise Rejected("the entry built from this attestation is malformed")
            return entry
        return self._admit_batch(blobs, key_path, now, one, sign)

    def sign(self, key_path, now=None):
        with _locked(self.path):
            self._sign_head(self.data(), key_path, now)
        return self.data().checkpoints[-1]

    def add_cosig(self, cosig):
        if not A.have_crypto():
            raise A.NeedsCryptography("checking a co-signature needs the `cryptography` package")
        if not _valid_cosig(cosig):
            raise Rejected("not a well-formed co-signature")
        if not _sig_ok(cosig["pubkey"], cosig["sig"], _cosig_msg(cosig["origin"], cosig["log_key"], cosig["size"], cosig["root"], cosig["time"])):
            raise Rejected("the signature does not verify")
        with _locked(self.path):
            d = self.data()
            if cosig["origin"] != d.origin:
                raise Rejected(f"it is for another log ({cosig['origin']})")
            if cosig["log_key"] != d.meta["pubkey"]:
                raise Rejected(f"it endorses a log signed by another key ({cosig['log_key'][:16]}...), not this one")
            if cosig["pubkey"] == d.meta["pubkey"]:
                raise Rejected("the log's own key cannot witness itself")
            if cosig["size"] > d.size or cosig["root"] != _hx(d.tree.root(cosig["size"])):
                raise Rejected("its head is not one this log's entries produce")
            if any(c["pubkey"] == cosig["pubkey"] and (c["size"], c["root"], c["time"]) == (cosig["size"], cosig["root"], cosig["time"]) for c in d.cosigs):
                raise Rejected("already merged")
            _append(os.path.join(self.path, "cosigs.jsonl"), (json.dumps(cosig, sort_keys=True, separators=(",", ":")) + "\n").encode())
            self._publish(self.data())

    def record_anchor(self, kind, ref, now=None):
        with _locked(self.path):
            d = self.data()
            b = d.checkpoints[-1]["body"]
            rec = {"kind": _clean(kind, 40), "ref": _clean(ref, 300), "time": now or now_iso(), "origin": b["origin"], "size": b["size"], "root": b["root"]}
            _append(os.path.join(self.path, "anchors.jsonl"), (json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n").encode())
            return rec

    def repair(self):
        """Drop a torn (unterminated) last line of entries.jsonl. Refuses if any signed head could cover it."""
        with _locked(self.path):
            p = os.path.join(self.path, "entries.jsonl")
            with open(p, "rb") as f:
                raw = f.read()
            if not raw or raw.endswith(b"\n"):
                return 0
            keep = raw[:raw.rfind(b"\n") + 1]
            d = parse_log(dir_reader(self.path))
            if d.checkpoints and d.checkpoints[-1]["body"]["size"] > keep.count(b"\n"):
                raise LogError("a signed head covers the partial line: this is not a torn write, it is damage; restore from backup")
            _atomic_write(p, keep)
            return len(raw) - len(keep)


# ------------------------------------------------------------------ the submission worker
def run_group(cmd, timeout, **kw):
    """subprocess.run with a wall-clock limit that reaches the WHOLE process tree. The plain version kills only its direct child: `certificate.verify` runs extrapolate.py in a
    child of its own, so a verification that hangs there kept running after the "limit" fired (found by the fourth audit). The command runs in its own session and the whole
    process group is killed on timeout (and on any other exit path)."""
    import signal
    import subprocess
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True, **kw)
    # The group is only ever signalled while the leader is still UNREAPED (a zombie keeps its pid, so the group id cannot have been recycled). After a normal exit the leader is
    # reaped, and killing "its group" would be a kill of whatever now owns that number: the original version did that for no benefit (translog never leaves children behind).
    try:
        out, err = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        with contextlib.suppress(ProcessLookupError, PermissionError):
            os.killpg(p.pid, signal.SIGKILL)
        try:
            p.communicate(timeout=10)
        except subprocess.TimeoutExpired:      # something left the group (setsid) and still holds our pipes: stop waiting for it, never hang the worker
            p.kill()
            for f in (p.stdout, p.stderr):
                with contextlib.suppress(OSError, ValueError):
                    f.close()
            p.wait()
        raise subprocess.TimeoutExpired(cmd, timeout)
    except BaseException:
        with contextlib.suppress(ProcessLookupError, PermissionError):
            os.killpg(p.pid, signal.SIGKILL)
        raise
    return subprocess.CompletedProcess(cmd, p.returncode, out, err)


def _sign_run(run, tool, log_dir, key_path, timeout):
    """The worker's one `sign` per run. A failure (a timeout, no python) must not take the run down: results are already written and the next run signs the unsigned tail first."""
    import subprocess
    try:
        r = run([sys.executable, tool, "sign", log_dir, "--key", key_path], timeout=timeout, cwd=HERE)
    except (subprocess.TimeoutExpired, OSError):
        print("translog: the head could not be signed this run; the next run signs it", file=sys.stderr)
        return False
    if r is None or r.returncode != 0:
        lines = ((r.stderr or "") if r is not None else "").strip().splitlines()
        tail = _clean(_scrub(lines[-1]), 200) if lines else ""
        print(f"translog: signing the head failed (exit {getattr(r, 'returncode', '?')}{': ' + tail if tail else ''}); the next run tries again", file=sys.stderr)
        return False
    return True


def ingest(log_dir, queue_dir, key_path, max_files=20, timeout=300, run=None, now=None):
    """Drain up to `max_files` files from the web tier's queue (logqueue.py). Each is admitted by `translog.py add` / `add-attestation` in its OWN subprocess with a wall-clock
    limit, so a certificate that makes the verifier crawl or hang costs exactly `timeout` seconds and nothing else, and one file's crash cannot affect another's.
    -> [(id, result dict)]. A result is written for every file (admitted or rejected, with the reason scrubbed of server paths) and the queued file is removed. If the LOG itself
    is unusable (exit status other than 0/1) the worker stops and leaves the rest queued: that is the operator's problem, not a verdict on the submissions.
    Only ONE worker drains a queue at a time (an exclusive lock, not waited for): two workers listing the same file would otherwise both process it, and the second, finding it
    already in the log, wrote a `rejected` result over the first's `admitted` one (found by the fifth audit)."""
    os.makedirs(queue_dir, exist_ok=True)
    fd = os.open(os.path.join(queue_dir, ".worker.lock"), os.O_RDWR | os.O_CREAT, 0o660)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return []                  # another worker is already draining this queue
        return _ingest(log_dir, queue_dir, key_path, max_files, timeout, run, now)
    finally:
        os.close(fd)


def _ingest(log_dir, queue_dir, key_path, max_files, timeout, run, now):
    import subprocess
    run = run or run_group
    incoming, results = logqueue.dirs(queue_dir)
    os.makedirs(results, exist_ok=True)
    tool = os.path.join(HERE, "translog.py")
    try:
        d0 = Log(log_dir).data()
    except LogError:
        return []                      # the log is unusable: leave everything queued
    # One head per RUN, not per file: a head per admitted file would bloat checkpoints.jsonl and rewrite every proof file each time under a flood. Entries admitted with
    # --no-sign are covered by the single `sign` at the end; if a previous run died before signing, the unsigned tail is signed first.
    unsigned = bool(d0.checkpoints) and d0.size > d0.checkpoints[-1]["body"]["size"]
    out = []
    for path, sha, kind in logqueue.pending(queue_dir)[:max_files]:
        prior = logqueue.status(queue_dir, sha)
        if prior is not None and prior["state"] != "queued":      # already decided (a stale listing, a submission racing a result): a decision is never made twice
            with contextlib.suppress(OSError):
                os.unlink(path)
            continue
        try:
            with open(path, "rb") as f:
                raw = f.read(MAX_CERT_BYTES + 1)
        except OSError:
            continue
        result = {"state": "rejected", "kind": kind, "at": now or now_iso()}
        if K.sha256(raw) != sha:
            result["reason"] = "the queued file changed after it was accepted"
        else:
            fd, rj = tempfile.mkstemp(dir=results, prefix=".r-", suffix=".json")
            os.close(fd)
            cmd = [sys.executable, tool, "add" if kind == "certificate" else "add-attestation", log_dir, path, "--key", key_path, "--no-sign", "--results-json", rj]
            try:
                try:
                    r = run(cmd, timeout=timeout, cwd=HERE)
                except subprocess.TimeoutExpired:
                    r = None
                    result["reason"] = f"could not be checked within {timeout} seconds"
                except (OSError, MemoryError):
                    # the command could not even be started (a fork limit, no interpreter) or the worker ran out of memory: the MACHINE's problem, not this file's, and a transient one. A recorded
                    # decision cannot be retried, so decide nothing: stop, leave everything queued.
                    if unsigned or any(x["state"] == "admitted" for _, x in out):
                        _sign_run(run, tool, log_dir, key_path, timeout)
                    return out
                except Exception as e:  # noqa: BLE001 anything else is deterministic for THIS file (undecodable output, say). One such file must never wedge an oldest-first queue.
                    r = None
                    result["reason"] = f"the worker could not process this file ({type(e).__name__})"
                if r is not None:
                    if r.returncode not in (0, 1):
                        if unsigned or any(x["state"] == "admitted" for _, x in out):
                            _sign_run(run, tool, log_dir, key_path, timeout)
                        return out      # the log is damaged or unreadable: stop, leave everything queued, let the operator look
                    try:
                        with open(rj, encoding="utf-8") as f:
                            one = json.load(f)[0]
                        if one.get("ok") is True and isinstance(one.get("seq"), int):
                            result.update(state="admitted", seq=one["seq"])
                        else:
                            result["reason"] = _clean(_scrub(one.get("reason") or "not admitted"), 300)
                    except (OSError, ValueError, IndexError, TypeError, AttributeError):
                        result["reason"] = "the worker produced no readable result for this file"
            finally:
                with contextlib.suppress(OSError):
                    os.unlink(rj)
        _atomic_write(os.path.join(results, sha + ".json"), (json.dumps(result, sort_keys=True) + "\n").encode())
        with contextlib.suppress(OSError):
            os.unlink(path)
        out.append((sha, result))
    if unsigned or any(x["state"] == "admitted" for _, x in out):
        _sign_run(run, tool, log_dir, key_path, timeout)
    logqueue.prune_results(queue_dir)
    return out


# ------------------------------------------------------------------ the witness
def witness_run(read, state_path, key_path=None, pinned_log_key=None, recheck=False, cert_read=None, now=None, verify=None, allow_unknown=False):
    """One witnessing pass over a log. -> {"ok", "checks", "cosig"}. The state file holds the last head this witness saw; the new head is signed only if the log
    is exactly the old log plus more entries, every head it ever signed is the root of its own prefix, and (with recheck) every new entry is what its certificate recomputes to.
    An entry whose certificate cannot be re-checked here (another protocol version) is NOT vouched for by default: a co-signature means "I checked this", and an operator who can
    log an entry no witness can check could otherwise log any credit it likes. allow_unknown signs anyway and says so.
    The state is written only after every check passed, so a bad log can never move the witness forward."""
    out = []
    res = {"ok": False, "checks": out, "cosig": None}
    d = parse_log(read)
    if d.problems or d.meta is None:
        _chk(out, "structure", "fail", "; ".join(d.problems[:4]) or "unreadable")
        return res
    _chk(out, "structure", "pass", f"{d.size} entries, {len(d.checkpoints)} signed heads, entries canonical and in order")
    state = None
    if os.path.exists(state_path):
        with open(state_path) as f:
            state = json.load(f)
        if state.get("format") != STATE_FORMAT:
            _chk(out, "state", "fail", f"{state_path} is not a witness state file")
            return res
    if state and pinned_log_key and state.get("log_pubkey") and pinned_log_key.lower() != state["log_pubkey"]:
        _chk(out, "log key", "fail", f"this state follows the log key {state['log_pubkey'][:16]}...; you passed {pinned_log_key[:16]}... A witness never silently re-pins: use a new state file for a different key")
        return res
    pin = (pinned_log_key or (state or {}).get("log_pubkey") or d.meta["pubkey"]).lower()
    if not A.have_crypto():
        _chk(out, "signatures", "fail", "the `cryptography` package is not installed: a witness that cannot check signatures must not sign")
        return res
    bad = verify_signatures(d, pin)
    if bad:
        _chk(out, "signatures", "fail", "; ".join(bad[:3]))
        return res
    _chk(out, "signatures", "pass" if (pinned_log_key or state) else "warn",
         f"every head and co-signature verifies under key {pin[:16]}..." + ("" if (pinned_log_key or state) else " (first sight: this key is trusted on first use; pass --log-key to pin it)"))
    if d.head is None:
        _chk(out, "head", "fail", "the log publishes no checkpoint.json")
        return res
    b = d.head["body"]
    if state:
        if state["origin"] != d.origin:
            _chk(out, "log", "fail", f"this state follows {state['origin']}, not {d.origin}")
            return res
        if d.size < state["size"] or b["size"] < state["size"]:
            _chk(out, "append-only", "fail", f"ROLLBACK: you last saw {state['size']} entries, the log now shows {min(d.size, b['size'])}")
            return res
        if _hx(d.tree.root(state["size"])) != state["root"]:
            res["evidence"] = equivocation_evidence(state.get("head"), d, b)
            _chk(out, "append-only", "fail", f"HISTORY CHANGED: the first {state['size']} entries no longer have the root you saw ({state['root'][:16]}...). "
                 + ("The operator signed both histories: the evidence file (--evidence FILE) proves it to anyone, offline." if res["evidence"] else
                    "This state file holds no signed head from before, so there is no transferable proof; keep the output."))
            return res
        _chk(out, "append-only", "pass", f"the {state['size']} entries you saw are exactly the first {state['size']} of the {d.size} now shown")
    else:
        _chk(out, "append-only", "skip", "first sight of this log: there is nothing earlier to compare")
    checked = (state or {}).get("checked", 0)
    tolerated = {s for s in (state or {}).get("tolerated", []) if isinstance(s, int) and not isinstance(s, bool)}
    if recheck:
        cert_read = cert_read or read
        counts = {"match": 0, "unknown": 0}
        fresh_unknown, tolerated_before = [], set(tolerated)    # tolerated is the witness's RECORD of what it chose not to vouch for (kept in its state file)
        for e in d.entries[checked:b["size"]]:
            got = recheck_served(d, e, cert_read, verify)
            if got is None:
                _chk(out, "recheck", "fail", f"entry {e['seq']}: the log does not serve {entry_path(e)[:40]}...")
                return res
            v, why = got
            if v == "mismatch":
                _chk(out, "recheck", "fail", f"entry {e['seq']}: {why}")
                return res
            counts[v] += 1
            if v == "unknown":
                if allow_unknown:
                    tolerated.add(e["seq"])      # tolerance is per ENTRY and explicit. `checked` then moves past it, so it is never re-examined (and the flag never needed for it again);
                else:                            # a later entry nobody can check is a different entry and is refused until the flag is passed for it
                    fresh_unknown.append(e["seq"])
        if fresh_unknown:
            _chk(out, "recheck", "fail", f"{len(fresh_unknown)} entries (first: {fresh_unknown[0]}) cannot be re-checked under this checkout's protocol code, so this witness will not vouch for them "
                 "(--allow-unknown tolerates exactly these entries and signs, vouching only for append-only behaviour; or check out the protocol code those certificates name)")
            return res
        newly = len(tolerated - tolerated_before)
        _chk(out, "recheck", "pass" if not counts["unknown"] else "warn",
             f"{counts['match']} new entries recomputed from their certificates and identical"
             + (f"; {counts['unknown']} could not be re-checked and are NOT vouched for ({newly} newly tolerated by --allow-unknown, the rest tolerated earlier)" if counts["unknown"] else ""))
        checked = b["size"]
    else:
        _chk(out, "recheck", "skip", "not requested (--recheck): the entries' credits and statuses are taken from the log as written")
    if key_path:
        res["cosig"] = make_cosig(d.origin, pin, b["size"], b["root"], key_path, now)
        _chk(out, "cosign", "pass", f"signed head {b['size']} entries, root {b['root'][:16]}...")
    new_state = {"format": STATE_FORMAT, "origin": d.origin, "log_pubkey": pin, "size": b["size"], "root": b["root"], "time": now or now_iso(), "checked": checked,
                 "tolerated": sorted(tolerated),
                 "head": {"body": b, "log": d.head["log"]}}    # the operator's own signature on what this witness saw: it is what makes a later contradiction provable
    _atomic_write(state_path, (json.dumps(new_state, indent=1, sort_keys=True) + "\n").encode())
    res["ok"] = all(c["status"] != "fail" for c in out)
    return res


def equivocation_evidence(old_head, d, new_body):
    """Two heads the operator signed that cannot both belong to one append-only history, with the leaf hashes that show it. None if the witness kept no signed old head.
    Self-contained: a stranger needs only the operator's public key to check it (`check_evidence`)."""
    if not (isinstance(old_head, dict) and _valid_body(old_head.get("body")) and _valid_sigfield(old_head.get("log"))) or d.head is None:
        return None
    n = new_body["size"]
    return {"format": EVID_FORMAT, "origin": d.origin, "old_head": {"body": old_head["body"], "log": old_head["log"]},
            "new_head": {"body": d.head["body"], "log": d.head["log"]}, "leaves": [_hx(x) for x in d.tree.leaves[:n]]}


def check_evidence(ev, log_pubkey=None):
    """-> {"ok", "equivocation", "checks"}. ok: the file is well formed and every signature verifies. equivocation: the two signed heads provably contradict each other
    (the older head's root is not the root of its own size's prefix of the history the newer head signs). A valid file that shows NO contradiction says so and is not evidence."""
    out = []
    res = {"ok": False, "equivocation": False, "checks": out}
    try:
        if not isinstance(ev, dict) or ev.get("format") != EVID_FORMAT:
            raise ValueError(f"not a {EVID_FORMAT} file")
        oh, nh, leaves = ev["old_head"], ev["new_head"], ev["leaves"]
        for h in (oh, nh):
            if not isinstance(h, dict) or not _valid_body(h.get("body")) or not _valid_sigfield(h.get("log")):
                raise ValueError("a head is malformed")
        ob, nb = oh["body"], nh["body"]
        if not isinstance(leaves, list) or len(leaves) != nb["size"] or nb["size"] > 5_000_000:
            raise ValueError("the leaf list does not have the newer head's size")
        lv = [_unhex(x) for x in leaves]
    except (KeyError, TypeError, ValueError) as e:
        _chk(out, "format", "fail", str(e))
        return res
    if not A.have_crypto():
        _chk(out, "signatures", "warn", "the `cryptography` package is not installed: nothing was verified")
        return res
    if ob["origin"] != nb["origin"] or ob["origin"] != ev.get("origin"):
        _chk(out, "heads", "fail", "the heads are for different logs")
        return res
    if oh["log"]["pubkey"] != nh["log"]["pubkey"]:
        _chk(out, "key", "fail", "the two heads are signed by different keys: that is two logs, not one log contradicting itself")
        return res
    if log_pubkey is not None and oh["log"]["pubkey"] != log_pubkey.lower():
        _chk(out, "key", "fail", f"signed by {oh['log']['pubkey'][:16]}..., not the key you pinned ({log_pubkey[:16]}...)")
        return res
    bad = [w for w, h in (("older", oh), ("newer", nh)) if not _sig_ok(h["log"]["pubkey"], h["log"]["sig"], _cp_msg(h["body"]))]
    if bad:
        _chk(out, "signatures", "fail", f"the {' and '.join(bad)} head's signature does not verify")
        return res
    _chk(out, "signatures", "pass" if log_pubkey else "warn", f"both heads are signed by key {oh['log']['pubkey'][:16]}..." + ("" if log_pubkey else " (you did not pin it, so this shows one key contradicted itself, not whose key it is)"))
    t = Tree(lv)
    if _hx(t.root()) != nb["root"]:
        _chk(out, "leaves", "fail", "the leaf list is not the history the newer head signs")
        return res
    if ob["size"] > nb["size"]:
        _chk(out, "order", "fail", "the 'older' head covers more entries than the 'newer' one: this is a rollback, which this file cannot prove")
        return res
    _chk(out, "leaves", "pass", f"the {nb['size']} leaf hashes are exactly the history the newer head signs (root {nb['root'][:16]}...)")
    prefix = _hx(t.root(ob["size"]))
    res["ok"] = True
    if prefix == ob["root"]:
        _chk(out, "contradiction", "skip", f"the older head's root IS the root of the first {ob['size']} entries of the newer history: the two heads are consistent")
    else:
        res["equivocation"] = True
        _chk(out, "contradiction", "pass", f"EQUIVOCATION: the operator signed root {ob['root'][:16]}... for {ob['size']} entries, and later signed a history whose first {ob['size']} entries "
             f"have root {prefix[:16]}...: both cannot be true of one append-only log")
    return res


# ------------------------------------------------------------------ anchors: Bitcoin timestamps and Internet Archive copies
# Neither is a witness: nobody checks the log. Each fixes WHEN a head existed with something the operator does not control, so rewriting history before that time is provable.
# Records in anchors.jsonl are the operator's notes and are never believed: a reader re-derives everything from the proof file / from the Archive's own index.
ANCHOR_REF = re.compile(r"anchors/ots-[0-9]{1,9}-[0-9a-f]{16}\.ots")
MAX_ANCHORS_CHECKED = 30
ARCHIVE_MAX_HEAD_BYTES = 65536


def _head_digest(body):
    return hashlib.sha256(anchor_line(body).encode()).digest()


def _ts14(epoch):
    return time.strftime("%Y%m%d%H%M%S", time.gmtime(epoch))


def _record_anchor(log, kind, ref, body, **extra):
    with _locked(log.path):
        rec = {"kind": _clean(kind, 40), "ref": _clean(ref, 300), "time": now_iso(), "origin": body["origin"], "size": body["size"], "root": body["root"], "head_time": body["time"]}
        rec.update({k: (_clean(v, 300) if isinstance(v, str) else v) for k, v in extra.items()})
        _append(os.path.join(log.path, "anchors.jsonl"), (json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n").encode())
        return rec


def ots_stamp(log, http=None, calendars=None):
    """Stamp the newest signed head with the public OpenTimestamps calendars (once per distinct size+root). -> {"state": "stamped"|"exists", "ref", "report"}.
    The network calls happen outside the log's lock: a slow calendar never blocks an ingest."""
    http, calendars = http or O.default_http, calendars or O.CALENDARS
    d = log.data()
    if d.problems or not d.checkpoints:
        raise LogError("the log has no clean signed head to stamp: " + ("; ".join(d.problems[:2]) or "none yet"))
    body = d.checkpoints[-1]["body"]

    def have(dd):
        return next((a for a in dd.anchors if isinstance(a, dict) and a.get("kind") == "bitcoin-ots" and a.get("size") == body["size"] and a.get("root") == body["root"]), None)
    if have(d):
        return {"state": "exists", "ref": str(have(d).get("ref", "")), "report": {}, "body": body}
    # at least two calendars must hold the stamp (the reference client's default too): a proof only one calendar holds is lost if that one is. With fewer reachable, nothing is written
    # and the next refresh tries again.
    proof, report = O.stamp(_head_digest(body), calendars, http, min_ok=min(2, len(calendars)))
    ref = f"anchors/ots-{body['size']}-{body['root'][:16]}.ots"
    with _locked(log.path):
        if have(log.data()):
            return {"state": "exists", "ref": ref, "report": report, "body": body}
        os.makedirs(os.path.join(log.path, "anchors"), exist_ok=True)
        _atomic_write(os.path.join(log.path, ref), proof)
    _record_anchor(log, "bitcoin-ots", ref, body)
    return {"state": "stamped", "ref": ref, "report": report, "body": body}


def ots_upgrade(log, http=None, calendars=None):
    """Ask the calendars whether each pending proof is now in a Bitcoin block; rewrite a proof only when it gained something. -> [{"ref", "state", "notes", "bitcoin"}]."""
    http, calendars = http or O.default_http, calendars or O.CALENDARS
    out = []
    for a in log.data().anchors:
        if not (isinstance(a, dict) and a.get("kind") == "bitcoin-ots" and isinstance(a.get("ref"), str) and ANCHOR_REF.fullmatch(a["ref"])):
            continue
        path = os.path.join(log.path, a["ref"])
        if not os.path.isfile(path):
            out.append({"ref": a["ref"], "state": "missing", "notes": {}, "bitcoin": []})
            continue
        with open(path, "rb") as f:
            raw = f.read(O.MAX_BYTES + 1)
        try:
            new, notes = O.upgrade(raw, http, calendars)
            if new is not None:
                with _locked(log.path):
                    _atomic_write(path, new)
                raw = new
            info = O.describe(raw)
            out.append({"ref": a["ref"], "state": "confirmed-in-file" if info["bitcoin"] else "pending", "notes": notes, "bitcoin": info["bitcoin"]})
        except O.OtsError as e:
            out.append({"ref": a["ref"], "state": "error", "notes": {"": str(e)[:150]}, "bitcoin": []})
    return out


def anchors_audit(d, read, pin, http=None, explorers=None, min_sources=2, limit=MAX_ANCHORS_CHECKED, upgrade=True, calendar_http=None, calendars=None):
    """Check every Bitcoin-timestamp anchor of a log, re-deriving everything: the head the anchor names must be one the operator signed, its root must be the root of the log's own
    prefix (so history before that head has not been rewritten), the proof file must stamp sha256 of that head's anchor line, and Bitcoin must say what the proof claims.
    -> [check]. A proof still waiting for its Bitcoin block is `skip`, never a failure."""
    http, explorers = http or O.default_http, explorers or O.EXPLORERS
    out = []
    recs = [a for a in d.anchors if isinstance(a, dict) and a.get("kind") == "bitcoin-ots"]
    if not recs:
        _chk(out, "bitcoin anchors", "skip", "this log records no Bitcoin timestamps")
        return out
    bad = verify_signatures(d, pin)
    if bad:
        _chk(out, "bitcoin anchors", "fail", "the heads do not verify, so no anchor can be tied to them: " + "; ".join(bad[:2]))
        return out
    skipped = max(0, len(recs) - limit)
    for rec in recs[-limit:]:
        size, root, ht, ref = rec.get("size"), rec.get("root"), rec.get("head_time"), rec.get("ref")
        name = f"bitcoin anchor {size}"
        if not (isinstance(size, int) and not isinstance(size, bool) and isinstance(root, str) and _HEX64.fullmatch(root) and isinstance(ht, str) and _TIME.fullmatch(ht)
                and isinstance(ref, str) and ANCHOR_REF.fullmatch(ref)):
            _chk(out, "bitcoin anchor", "fail", "a record in anchors.jsonl is malformed")
            continue
        head = next((c for c in d.checkpoints if c["body"]["size"] == size and c["body"]["root"] == root and c["body"]["time"] == ht), None)
        if head is None:
            _chk(out, name, "fail", f"the anchor names a head ({size} entries, {root[:16]}..., {ht}) that the log never signed")
            continue
        if size > d.size or _hx(d.tree.root(size)) != root:
            _chk(out, name, "fail", f"HISTORY CHANGED: this head was anchored, yet the first {size} entries of the log as served now do not have its root")
            continue
        raw = read(ref)
        if raw is None:
            _chk(out, name, "fail", f"the proof file {ref} is not served")
            continue
        digest = _head_digest(head["body"])
        v = O.verify(raw, digest, explorers, http, min_sources)
        collected = ""
        if v["status"] == "pending" and upgrade:
            # The proof file on the log's server may say pending long after Bitcoin has confirmed it: the calendars hold the finished proof and anyone may fetch it. Adopt it ONLY if it
            # verifies completely; a calendar that answers with something wrong must not make a sound log look broken, so anything else leaves the honest "pending" in place.
            try:
                finished, _ = O.upgrade(raw, calendar_http or http, calendars or O.CALENDARS)
            except O.OtsError:
                finished = None
            if finished is not None:
                v2 = O.verify(finished, digest, explorers, http, min_sources)
                if v2["status"] in ("confirmed", "single-source"):
                    v, collected = v2, " The log's own copy of the proof still says pending: this reader collected the finished proof from the public calendars."
        st = v["status"]
        when = f" (block time {now_iso(v['time'])})" if v.get("time") else ""
        if st == "confirmed":
            _chk(out, name, "pass", f"Bitcoin block {v['height']}{when} commits to the head of {size} entries; the log's first {size} entries still have that root. Seen at {len(v['sources'])} independent explorers." + collected)
        elif st == "single-source":
            _chk(out, name, "warn", f"Bitcoin block {v['height']}{when} matches, but only one explorer could be asked: confirmed by fewer sources than requested." + collected)
        elif st == "pending":
            _chk(out, name, "skip", v["detail"])
        elif st == "unverifiable":
            _chk(out, name, "warn", v["detail"] + " (nothing was concluded: try again, or ask a Bitcoin node)")
        else:
            _chk(out, name, "fail", f"{st.upper()}: {v['detail']}")
    if skipped:
        _chk(out, "bitcoin anchors", "skip", f"{skipped} older anchors were not checked (the newest {limit} are)")
    return out


def _archive_stamps(d, now=None):
    """Timestamps at which to ask the Archive for its nearest snapshot: the log's creation, evenly spaced points up to now, and now."""
    end = now if now is not None else time.time()
    try:
        start = calendar.timegm(time.strptime(d.meta.get("created", ""), "%Y-%m-%dT%H:%M:%SZ"))
    except (ValueError, TypeError):
        start = end - 30 * 86400
    start = min(start, end)
    steps = 6
    return list(dict.fromkeys(_ts14(start + (end - start) * i / steps) for i in range(steps + 1)))     # a new log makes them all equal: one question to a throttling service, not seven


def archive_audit(d, checkpoint_url, pin, http=None, now=None, limit=8):
    """The Internet Archive's own copies of checkpoint.json, found through the Archive's index (not through anything the operator says). Each must be a head the operator really
    signed and must be consistent with the log as served now. -> (checks, evidence or None). Evidence is the same transferable file `witness --evidence` writes."""
    http = http or W.default_http
    out, evidence = [], None
    caps, notes = W.captures(checkpoint_url, _archive_stamps(d, now), http, limit)
    for n in notes:
        _chk(out, "internet archive", "warn", n)
    if not caps:
        if not notes:
            _chk(out, "internet archive", "skip", "the Archive holds no copy of this log's head yet")
        return out, None
    bad = verify_signatures(d, pin)
    if bad:
        _chk(out, "internet archive", "fail", "the log's own heads do not verify: " + "; ".join(bad[:2]))
        return out, None
    for c in caps:
        ts, name = c["timestamp"], f"archive copy {c['timestamp']}"
        try:
            if len(c["raw"]) > ARCHIVE_MAX_HEAD_BYTES:
                raise ValueError("far too large to be a head")
            bundle = json.loads(c["raw"].decode("utf-8"), parse_constant=_bad_constant)
            if not isinstance(bundle, dict) or not _valid_body(bundle.get("body")) or not _valid_sigfield(bundle.get("log")):
                raise ValueError("not a signed head")
        except (ValueError, UnicodeDecodeError, RecursionError) as e:
            _chk(out, name, "fail", f"the Archive's copy is not a head: {_clean(e, 80)}")
            continue
        b, lg = bundle["body"], bundle["log"]
        if lg["pubkey"] != pin:
            _chk(out, name, "fail", f"signed by {lg['pubkey'][:16]}..., not the key you pinned")
        elif not _sig_ok(lg["pubkey"], lg["sig"], _cp_msg(b)):
            _chk(out, name, "fail", "the operator's signature on the Archive's copy does not verify")
        elif b["origin"] != d.origin:
            _chk(out, name, "fail", f"it is a head of {b['origin']}, not {d.origin}")
        elif b["size"] > d.size:
            _chk(out, name, "fail", f"ROLLBACK: the Archive holds a head of {b['size']} entries signed {b['time']}; the log now serves only {d.size}")
        elif _hx(d.tree.root(b["size"])) != b["root"]:
            evidence = evidence or equivocation_evidence({"body": b, "log": lg}, d, d.head["body"] if d.head else b)
            _chk(out, name, "fail", f"HISTORY CHANGED: the Archive's copy (taken {ts}) is a head of {b['size']} entries whose root is not the root of the log's first {b['size']} entries now. "
                 + ("Both are signed by the operator: --evidence FILE writes the proof." if evidence else ""))
        else:
            _chk(out, name, "pass", f"a head of {b['size']} entries signed {b['time']}, held by the Archive since {ts}, is exactly the first {b['size']} entries of the log as served now")
    return out, evidence


def archive_save(log, checkpoint_url, http=None, sleep=None, polls=6, interval=10):
    """Ask the Archive to capture checkpoint.json and record the snapshot only if its bytes are exactly this log's published head. -> {"state", "detail", ...}.
    Throttling is normal (the Archive limits anonymous clients) and is reported, never raised: this is best effort and never blocks a refresh."""
    http = http or W.default_http
    with open(os.path.join(log.path, "checkpoint.json"), "rb") as f:
        expected = f.read(ARCHIVE_MAX_HEAD_BYTES + 1)
    d = log.data()
    since = _ts14(time.time() - 120)
    try:
        W.request_save(checkpoint_url, http)
    except W.Throttled as e:
        return {"state": "throttled", "detail": str(e)}
    except W.ArchiveError as e:
        return {"state": "unreachable", "detail": str(e)}
    r = W.confirm_saved(checkpoint_url, expected, http, since, polls, sleep, interval)
    if r["state"] == "saved" and d.checkpoints:
        body = d.head["body"] if d.head else d.checkpoints[-1]["body"]
        _record_anchor(log, "web-archive", r["url"], body, snapshot=r["timestamp"], address=checkpoint_url)
    return r


def remember(read, state_path, pin, recheck=False):
    """A reader keeps the last head they saw. This is `witness` without a signing key: a rollback or a changed history is caught the next time THIS reader looks, and a changed
    history yields the same transferable evidence. -> witness_run's result."""
    return witness_run(read, state_path, None, pin, recheck)


def _age_hours(iso, now=None):
    return ((now if now is not None else time.time()) - calendar.timegm(time.strptime(iso, "%Y-%m-%dT%H:%M:%SZ"))) / 3600.0


STALE_HOURS = 48     # a log that signs a heartbeat daily is "stale" after two days without one
FUTURE_SLACK_HOURS = 1.0     # clock skew tolerated between the operator's clock and the reader's


def audit(read, pinned=None, recheck=False, cert_read=None, verify=None, max_age_hours=None, now=None):
    """Everything a reader can check about a log without anyone's help -> {"ok", "checks", "data"}."""
    out = []
    d = parse_log(read)
    if d.problems or d.meta is None:
        _chk(out, "structure", "fail", "; ".join(d.problems[:5]) or "unreadable")
        return {"ok": False, "checks": out, "data": d}
    if d.head is not None:
        age = _age_hours(d.head["body"]["time"], now)
        limit = max_age_hours if max_age_hours is not None else STALE_HOURS
        if age < -FUTURE_SLACK_HOURS:
            # a head dated ahead of the reader's clock tells you nothing about freshness, and (heads never go backwards) every later head of this log is stuck at or after it
            _chk(out, "freshness", "fail", f"the newest head is dated {-age:.1f} hours in the FUTURE (the operator's clock is wrong, or the head is forged ahead): its age says nothing about whether the log is alive")
        else:
            _chk(out, "freshness", "fail" if (max_age_hours is not None and age > limit) else ("warn" if age > limit else "pass"),
                 f"the newest head was signed {max(age, 0):.1f} hours ago (the operator's clock)" + ("" if age <= limit else
                 f", which is longer than {limit:g}: a stopped log, or a stale mirror of one, looks exactly like this. A head's age cannot be forged forward, but a valid old head can be replayed"))
    _chk(out, "structure", "pass", f"{d.size} entries in canonical order; every signed head ({len(d.checkpoints)}) is the root of its own prefix of them; nothing was removed or rewritten")
    if A.have_crypto():
        bad = verify_signatures(d, pinned)
        _chk(out, "signatures", "fail" if bad else ("pass" if pinned else "warn"),
             "; ".join(bad[:3]) if bad else f"every head and co-signature verifies" + ("" if pinned else " under the key log.json names; you did not pin it (--log-key), so this shows consistency, not identity"))
    else:
        _chk(out, "signatures", "warn", "the `cryptography` package is not installed: no signature was checked")
    if d.head is None:
        _chk(out, "head", "fail", "no checkpoint.json")
    elif d.head["body"]["size"] < d.size:
        _chk(out, "head", "warn", f"{d.size - d.head['body']['size']} entries are newer than the newest signed head (unsigned)")
    else:
        _chk(out, "head", "pass", f"the newest head covers all {d.size} entries")
    if recheck:
        cert_read = cert_read or read
        counts, unknown, bad = {"match": 0, "unknown": 0}, 0, []
        for e in d.entries:
            got = recheck_served(d, e, cert_read, verify)
            if got is None:
                bad.append(f"entry {e['seq']}: its file is not served")
                continue
            v, why = got
            if v == "mismatch":
                bad.append(f"entry {e['seq']}: {why}")
            else:
                counts[v] += 1
        _chk(out, "recheck", "fail" if bad else ("warn" if counts["unknown"] else "pass"),
             "; ".join(bad[:3]) if bad else f"{counts['match']} entries recomputed from their certificates and identical" + (f"; {counts['unknown']} not re-checkable under this checkout" if counts["unknown"] else ""))
    return {"ok": all(c["status"] != "fail" for c in out), "checks": out, "data": d}


# ------------------------------------------------------------------ command line
def _show(checks):
    for c in checks:
        print(f"  {c['status'].upper():5s} {c['check']}: {c['detail']}")


def _write_results(path, results):
    """For a program that drives this CLI (the submission worker): one {ok, seq, reason} object per input file, in order. Parsing the human output was fragile (a path with a space
    lost every reason), and this is the contract the worker depends on."""
    if path:
        rows = [{"ok": e is not None, "seq": e["seq"] if e else None, "reason": None if e else _clean(_scrub(why), 300)} for e, why in results]
        _atomic_write(os.path.abspath(path), (json.dumps(rows) + "\n").encode())


def _need_key(a):
    """A verdict about a log is worth nothing unless the reader said WHICH key is the log's: anyone can start a log under their own key and every check on it passes."""
    if not a.log_key and not a.unpinned:
        raise LogError("pass --log-key HEX, the key you obtained from a source other than the log itself, or --unpinned to accept whatever key signed it "
                       "(which proves consistency, never identity)")


def _verdict(ok, a):
    if not ok:
        return "NOT VERIFIED"
    return "VERIFIED" if a.log_key else "VERIFIED, BUT THE LOG'S KEY IS NOT PINNED: a key signed this, which says nothing about whose key it is"


def _load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f, parse_constant=_bad_constant)


def _trusted(path):
    return list(A.read_trusted(path)) if path else []


def _out(obj, path):
    text = json.dumps(obj, indent=1, sort_keys=True) + "\n"
    if path:
        _atomic_write(os.path.abspath(path), text.encode())
        print(f"wrote {path}")
    else:
        sys.stdout.write(text)


def build_parser():
    ap = argparse.ArgumentParser(prog="translog.py", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)

    def p(name, **kw):
        return sub.add_parser(name, **kw)
    s = p("init", help="start a new log")
    s.add_argument("dir")
    s.add_argument("--origin", required=True)
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--key")
    g.add_argument("--new-key")
    s = p("add", help="verify certificates and append them")
    s.add_argument("dir")
    s.add_argument("certs", nargs="+")
    s.add_argument("--key", required=True)
    s.add_argument("--no-sign", action="store_true", help="append but do not sign a head (the submission worker signs once per run); `translog.py sign` covers them later")
    s.add_argument("--results-json", help="write one {ok, seq, reason} object per input file here, for a program to read (the worker does)")
    s = p("sign", help="a fresh signed head at the current size")
    s.add_argument("dir")
    s.add_argument("--key", required=True)
    s = p("repair", help="drop a torn last line of entries.jsonl")
    s.add_argument("dir")
    s = p("add-cosig", help="merge witness co-signatures into the published head")
    s.add_argument("dir")
    s.add_argument("cosigs", nargs="+")
    s = p("prove", help="an inclusion proof for one certificate")
    s.add_argument("--log", required=True)
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--cert")
    g.add_argument("--seq", type=int)
    s.add_argument("--out")
    s = p("verify-inclusion")
    s.add_argument("proof")
    s.add_argument("--cert")
    s.add_argument("--log-key")
    s.add_argument("--unpinned", action="store_true", help="accept whatever key signed the head (shows consistency, not identity)")
    s.add_argument("--trusted")
    s.add_argument("--min-witnesses", type=int, default=0)
    s = p("consistency", help="a proof that an older size is a prefix of a newer one")
    s.add_argument("--log", required=True)
    s.add_argument("--old", type=int, required=True)
    s.add_argument("--new", type=int)
    s.add_argument("--out")
    s = p("verify-consistency")
    s.add_argument("proof")
    s.add_argument("--old-head")
    s.add_argument("--new-head")
    s.add_argument("--log-key")
    s.add_argument("--unpinned", action="store_true", help="accept whatever key signed the heads (shows consistency, not identity)")
    s = p("witness", help="check a log only grew since you last looked; with --key, co-sign its head")
    s.add_argument("--log", required=True)
    s.add_argument("--state", required=True)
    s.add_argument("--key")
    s.add_argument("--log-key")
    s.add_argument("--recheck", action="store_true")
    s.add_argument("--allow-unknown", action="store_true", help="with --recheck: still co-sign when some entries cannot be re-checked under this checkout's protocol code (default: refuse)")
    s.add_argument("--out")
    s.add_argument("--evidence", help="if the operator is caught signing two histories, write the proof here")
    s = p("check-evidence", help="verify an equivocation-evidence file: two signed heads that contradict each other")
    s.add_argument("evidence")
    s.add_argument("--log-key")
    s.add_argument("--unpinned", action="store_true", help="accept whatever key signed the heads (shows one key contradicted itself, not whose key it is)")
    s = p("check", help="audit a whole log")
    s.add_argument("--log", required=True)
    s.add_argument("--log-key")
    s.add_argument("--unpinned", action="store_true", help="accept whatever key signed the heads (shows the log is self-consistent, not whose it is)")
    s.add_argument("--trusted")
    s.add_argument("--min-witnesses", type=int, default=0)
    s.add_argument("--recheck", action="store_true")
    s.add_argument("--max-age-hours", type=float, help="fail if the newest head was signed longer ago than this (a stopped log, or a stale mirror, looks fine otherwise)")
    s.add_argument("--remember", metavar="FILE", help="keep the last head you saw in FILE and check the log only ever grew since: a rollback or a rewritten history is caught the next time YOU look, "
                   "and a rewritten history writes transferable evidence to FILE.evidence.json. Needs the log's key pinned (--log-key).")
    s.add_argument("--anchors", action="store_true", help="also check the log's Bitcoin timestamps (asks two public block explorers)")
    s = p("frontier", help="the best credit per problem, at a chosen strength of evidence")
    s.add_argument("--log", required=True)
    s.add_argument("--family")
    s.add_argument("--counted-only", action="store_true")
    s.add_argument("--tier", choices=TIERS, default="logged", help="logged: as the entries say. reexecuted: a key you pin re-ran instances and its checks passed. run: a key you pin signed that its own sandbox records are the certificate's")
    s.add_argument("--trusted", help="a file of the attester public keys YOU pin (one 64-hex key per line); required for --tier reexecuted or run")
    s = p("absence", help="a claim that no logged certificate reaches a threshold")
    s.add_argument("--log", required=True)
    s.add_argument("--family", required=True)
    s.add_argument("--threshold", type=float, required=True)
    s.add_argument("--counted-only", action="store_true")
    s.add_argument("--tier", choices=TIERS, default="logged")
    s.add_argument("--trusted", help="the attester keys you pin (required for --tier reexecuted or run); recorded in the claim")
    s.add_argument("--out")
    s = p("ingest", help="drain the web tier's submission queue: verify and admit each file in its own subprocess with a time limit")
    s.add_argument("dir")
    s.add_argument("--queue", required=True)
    s.add_argument("--key", required=True)
    s.add_argument("--max", type=int, default=20, help="files per run")
    s.add_argument("--timeout", type=int, default=300, help="seconds allowed per file")
    s = p("add-attestation", help="log signed statements about certificates already in the log: attest.py re-checks/re-executions, runattest.py sandbox attestations")
    s.add_argument("dir")
    s.add_argument("attestations", nargs="+")
    s.add_argument("--key", required=True)
    s.add_argument("--no-sign", action="store_true", help="append but do not sign a head")
    s.add_argument("--results-json", help="write one {ok, seq, reason} object per input file here, for a program to read")
    s = p("check-absence")
    s.add_argument("claim")
    s.add_argument("--log", required=True, help="a copy of the log (directory or URL): the claim is recomputed from its entries")
    s.add_argument("--log-key")
    s.add_argument("--unpinned", action="store_true", help="accept whatever key signed the head (shows consistency, not identity)")
    s.add_argument("--trusted")
    s.add_argument("--min-witnesses", type=int, default=0)
    s.add_argument("--recheck", action="store_true", help="also recompute every entry from its certificate: the claim reads the entries' credits, so this is what makes them trustworthy")
    s = p("anchor", help="the line to publish elsewhere")
    s.add_argument("dir")
    s.add_argument("--record", nargs=2, metavar=("KIND", "REF"))
    s = p("anchor-check", help="does this URL show the log's current head?")
    s.add_argument("url")
    s.add_argument("--log", required=True)
    s = p("anchor-ots", help="timestamp the newest head in Bitcoin through the public OpenTimestamps calendars (operator)")
    s.add_argument("dir")
    s = p("anchor-upgrade", help="ask the calendars whether pending Bitcoin timestamps are now in a block (operator; run it from time to time)")
    s.add_argument("dir")
    s = p("anchor-verify", help="check a log's Bitcoin timestamps against the blockchain (reader)")
    s.add_argument("--log", required=True)
    s.add_argument("--log-key")
    s.add_argument("--unpinned", action="store_true", help="accept whatever key signed the heads")
    s.add_argument("--min-sources", type=int, default=2, help="how many independent block explorers must agree (default 2)")
    s.add_argument("--no-calendars", action="store_true", help="do not ask the public calendars for a finished proof when the log's copy still says pending (default: ask)")
    s = p("archive-save", help="ask the Internet Archive to keep a copy of the log's head and record it only if the copy is exactly the published head (operator)")
    s.add_argument("dir")
    s.add_argument("--url", required=True, help="the address the head is published at, e.g. https://guldo.org/log/checkpoint.json")
    s = p("archive-check", help="check the Internet Archive's own copies of a log's head against the log as served now (reader)")
    s.add_argument("--log", required=True, help="the log's URL (the Archive holds web pages, so a directory cannot be checked)")
    s.add_argument("--log-key")
    s.add_argument("--unpinned", action="store_true", help="accept whatever key signed the heads")
    s.add_argument("--evidence", help="if a copy proves the operator signed two histories, write the proof here")
    return ap


def main(argv=None):
    a = build_parser().parse_args(argv)
    try:
        return _main(a)
    except A.NeedsCryptography as e:
        print(f"translog: {e}", file=sys.stderr)
        return 2
    except (LogError, Rejected, ValueError, OSError, KeyError, TypeError, O.OtsError, W.ArchiveError) as e:     # the last two: a calendar or the Archive being down is a message, not a traceback
        print(f"translog: {_clean(e, 400)}", file=sys.stderr)
        return 2


def _main(a):
    c = a.cmd
    if c == "init":
        key = a.key or a.new_key
        if a.new_key:
            print(f"new operator key {A.keygen(a.new_key)} written to {a.new_key} (mode 600, never overwritten). Back it up; do NOT put it in the log directory.")
        log = Log.init(a.dir, a.origin, key)
        d = log.data()
        print(f"log {d.origin} started in {log.path}; log key {d.meta['pubkey']}\nPublish that key somewhere a reader can pin it out of band (the site's Log page, the README, a DNS TXT record).")
        return 0
    if c == "add":
        blobs = []
        for p in a.certs:
            with open(p, "rb") as f:
                blobs.append(f.read(MAX_CERT_BYTES + 1))
        log = Log(a.dir)
        results = log.add(blobs, a.key, sign=not a.no_sign)
        for p, (e, why) in zip(a.certs, results):
            print(f"  entry {e['seq']}: {p} ({e['family']}, {e['credit_bits']} bits, {e['status']})" if e else f"  REJECTED {p}: {why}")
        _write_results(a.results_json, results)
        d = log.data()
        print(f"head: {d.checkpoints[-1]['body']['size']} entries, root {d.checkpoints[-1]['body']['root']}" + (f" ({d.size - d.checkpoints[-1]['body']['size']} entries not yet signed)" if d.size > d.checkpoints[-1]["body"]["size"] else ""))
        return 0 if all(e for e, _ in results) else 1
    if c == "ingest":
        done = ingest(a.dir, a.queue, a.key, a.max, a.timeout)
        for sha, r in done:
            print(f"  {sha[:12]}... {r['state']}" + (f" as entry {r['seq']}" if r["state"] == "admitted" else f": {r.get('reason', '')}"))
        left = len(logqueue.pending(a.queue))
        print(f"{len(done)} processed, {left} still queued")
        return 0
    if c == "add-attestation":
        blobs = []
        for p in a.attestations:
            with open(p, "rb") as f:
                blobs.append(f.read(MAX_ATT_BYTES + 1))
        log = Log(a.dir)
        results = log.add_attestations(blobs, a.key, sign=not a.no_sign)
        _write_results(a.results_json, results)
        for p, (e, why) in zip(a.attestations, results):
            if not e:
                print(f"  REJECTED {p}: {why}")
            elif e["kind"] == "run":
                print(f"  entry {e['seq']}: {p} (RUN statement by {e['attester'][:16]}... for entry {e['target_seq']}: {e['sandbox']}, {e['image'][:24]})")
            else:
                print(f"  entry {e['seq']}: {p} (attestation by {e['attester'][:16]}... for entry {e['target_seq']}: verified={e['verified']}, executed={e['executed']}, exact={e['exact']}, gap={e['gap']})")
        d = log.data()
        print(f"head: {d.checkpoints[-1]['body']['size']} entries, root {d.checkpoints[-1]['body']['root']}")
        return 0 if all(e for e, _ in results) else 1
    if c == "sign":
        cp = Log(a.dir).sign(a.key)
        print(f"signed head: {cp['body']['size']} entries, root {cp['body']['root']}, {cp['body']['time']}")
        return 0
    if c == "repair":
        n = Log(a.dir).repair()
        print(f"dropped {n} bytes of a torn last line" if n else "nothing to repair")
        return 0
    if c == "add-cosig":
        log, bad = Log(a.dir), 0
        for p in a.cosigs:
            try:
                log.add_cosig(_load_json(p))
                print(f"  merged {p}")
            except Rejected as e:
                bad += 1
                print(f"  REJECTED {p}: {e}")
        return 1 if bad else 0
    if c == "prove":
        d = parse_log(reader_for(a.log))
        if d.problems:
            raise LogError("; ".join(d.problems[:3]))
        if a.cert:
            with open(a.cert, "rb") as f:
                sha = K.sha256(f.read())
            hit = [e["seq"] for e in d.entries if entry_file_sha(e) == sha]
            if not hit:
                print("that file (a certificate or an attestation) is not in this log")
                return 1
            seq = hit[0]
        else:
            seq = a.seq
        if not 0 <= seq < d.size:
            raise LogError(f"the log has entries 0..{d.size - 1}")
        if d.head is None or d.head["body"]["size"] != d.size:
            raise LogError("the newest signed head does not cover every entry: ask the operator to `sign`")
        _out(inclusion_proof(d, seq), a.out)
        return 0
    if c == "verify-inclusion":
        raw = None
        if a.cert:
            with open(a.cert, "rb") as f:
                raw = f.read()
        _need_key(a)
        r = check_inclusion(_load_json(a.proof), raw, a.log_key, _trusted(a.trusted), a.min_witnesses)
        _show(r["checks"])
        print(_verdict(r["ok"], a))
        return 0 if r["ok"] else 1
    if c == "consistency":
        d = parse_log(reader_for(a.log))
        if d.problems:
            raise LogError("; ".join(d.problems[:3]))
        _out(consistency_proof(d, a.old, a.new), a.out)
        return 0
    if c == "verify-consistency":
        if a.old_head or a.new_head:
            _need_key(a)
        r = check_consistency(_load_json(a.proof), _load_json(a.old_head) if a.old_head else None, _load_json(a.new_head) if a.new_head else None, a.log_key)
        _show(r["checks"])
        print(_verdict(r["ok"], a) if (a.old_head or a.new_head) else ("VERIFIED (the arithmetic only: no signed heads were supplied, so nothing says these roots belong to any log)" if r["ok"] else "NOT VERIFIED"))
        return 0 if r["ok"] else 1
    if c == "witness":
        read = reader_for(a.log)
        r = witness_run(read, a.state, a.key, a.log_key, a.recheck, allow_unknown=a.allow_unknown)
        _show(r["checks"])
        if r["cosig"]:
            _out(r["cosig"], a.out)
        if r.get("evidence") and a.evidence:
            _out(r["evidence"], a.evidence)
        print("OK" if r["ok"] else "REFUSED (state not updated)")
        return 0 if r["ok"] else 1
    if c == "check-evidence":
        _need_key(a)
        r = check_evidence(_load_json(a.evidence), a.log_key)
        _show(r["checks"])
        note = "" if a.log_key else " (you did not pin the key: this shows ONE key contradicted itself, not that the key is the log's)"
        print(("EQUIVOCATION PROVEN: this operator key signed two incompatible histories" + note) if r["equivocation"] else ("VALID, BUT SHOWS NO CONTRADICTION" if r["ok"] else "NOT VALID"))
        return 0 if r["equivocation"] else 1
    if c == "check":
        _need_key(a)
        if a.remember and not a.log_key:
            raise LogError("--remember needs --log-key: a head you remember from a key you never pinned proves nothing")
        read = reader_for(a.log)
        r = audit(read, a.log_key, a.recheck, max_age_hours=a.max_age_hours)
        _show(r["checks"])
        d = r["data"]
        if d.head is not None:
            h = check_checkpoint({"body": d.head["body"], "log": d.head["log"], "witnesses": head_witnesses(d, d.head["body"])}, a.log_key, _trusted(a.trusted), a.min_witnesses)
            _show([x for x in h["checks"] if x["check"] in ("witnesses", "log signature")])
            r["ok"] = r["ok"] and h["ok"]
        if a.anchors and not d.problems:
            an = anchors_audit(d, read, (a.log_key or d.meta["pubkey"]).lower(), min_sources=2)
            _show(an)
            r["ok"] = r["ok"] and all(x["status"] != "fail" for x in an)
        if a.remember:
            m = remember(read, a.remember, a.log_key, a.recheck)
            _show([x for x in m["checks"] if x["check"] in ("append-only", "state", "log key", "log")])
            if m.get("evidence"):
                _out(m["evidence"], a.remember + ".evidence.json")
                print(f"  the operator signed both histories: {a.remember}.evidence.json proves it to anyone (translog.py check-evidence FILE --log-key KEY)")
            r["ok"] = r["ok"] and m["ok"]
        print(("OK" if a.log_key else "OK, BUT THE LOG'S KEY IS NOT PINNED: it is self-consistent, which says nothing about whose log it is") if r["ok"] else "PROBLEMS FOUND")
        return 0 if r["ok"] else 1
    if c == "frontier":
        d = parse_log(reader_for(a.log))
        if d.problems:
            raise LogError("; ".join(d.problems[:3]))
        if a.tier != "logged" and not a.trusted:
            raise LogError(f"--tier {a.tier} needs --trusted FILE: the attester keys YOU pin. This log cannot say whom to trust")
        fr = frontier(d.entries, a.family, a.counted_only, a.tier, _trusted(a.trusted))
        for fam, f in sorted(fr.items()):
            print(f"  {fam:16s} {f['entries']:4d} entries   best {f['best_credit']} bits (entry {f['best_seq']})   [{a.tier}]")
        if not fr:
            print("  no matching entries")
        print(f"as of {d.size} entries. {SCOPE}")
        return 0
    if c == "absence":
        d = parse_log(reader_for(a.log))
        if d.problems:
            raise LogError("; ".join(d.problems[:3]))
        claim = absence_claim(d, a.family, a.threshold, a.counted_only, a.tier, _trusted(a.trusted))
        print(("HOLDS: no logged certificate for " if claim["holds"] else "DOES NOT HOLD: an entry for ") + f"{a.family} " + (f"reaches {a.threshold} bits" if claim["holds"] else f"reaches {a.threshold} bits (best {claim['best_credit_bits']})")
              + f" among {claim['entries_scanned']} entries at head {claim['checkpoint']['body']['root'][:16]}...", file=sys.stderr)
        _out(claim, a.out)
        return 0 if claim["holds"] else 1
    if c == "check-absence":
        _need_key(a)
        read = reader_for(a.log)
        raw = read("entries.jsonl") or b""
        r = check_absence(_load_json(a.claim), raw.split(b"\n")[:-1] if raw.endswith(b"\n") else raw.split(b"\n"), a.log_key, _trusted(a.trusted), a.min_witnesses)
        _show(r["checks"])
        if a.recheck:
            au = audit(read, a.log_key, recheck=True)
            _show(au["checks"])
            r["ok"] = r["ok"] and au["ok"]
        else:
            print("  NOTE  the credits read here are the entries' own fields; pass --recheck to recompute every entry from its certificate")
        print((_verdict(True, a) + (" The claim holds. " if r["holds"] else " The claim recomputes, and it does NOT hold. ") + SCOPE) if r["ok"] else "NOT VERIFIED")
        return 0 if r["ok"] else 1
    if c == "anchor":
        log = Log(a.dir)
        d = log.data()
        body = d.checkpoints[-1]["body"]
        print(anchor_line(body))
        if a.record:
            log.record_anchor(*a.record)
            print(f"recorded: {a.record[0]} {a.record[1]} (the operator's own note of where it was published; check it with anchor-check)")
        return 0
    if c == "anchor-check":
        if urllib.parse.urlparse(a.url).scheme not in ("http", "https"):
            raise LogError("an anchor URL must be http or https")
        req = urllib.request.Request(a.url, headers={"User-Agent": "guldo-translog"})
        with _OPENER.open(req, timeout=30) as r:
            text = r.read(1 << 20).decode("utf-8", "replace")
        d = parse_log(reader_for(a.log))
        body = (d.head or d.checkpoints[-1])["body"] if (d.head or d.checkpoints) else None
        if body is None:
            raise LogError("the log has no head")
        ok = anchor_check(text, body)
        print(("FOUND: " if ok else "NOT FOUND: ") + f"{body['origin']} {body['size']} {body['root']} " + ("appears at " if ok else "does not appear at ") + a.url)
        return 0 if ok else 1
    if c == "anchor-ots":
        r = ots_stamp(Log(a.dir))
        b = r["body"]
        if r["state"] == "exists":
            print(f"already stamped: the head of {b['size']} entries is in {r['ref']}")
            return 0
        held = [k for k, v in r["report"].items() if v is None]
        for k, v in r["report"].items():
            print(f"  {'held by ' if v is None else 'FAILED  '}{k}" + (f": {v}" if v else ""))
        print(f"stamped the head of {b['size']} entries ({r['ref']}), held by {len(held)} of {len(r['report'])} calendars. It is pending until the calendars' Bitcoin transaction is mined "
              "(usually a few hours): run anchor-upgrade later.")
        return 0
    if c == "anchor-upgrade":
        res = ots_upgrade(Log(a.dir))
        for x in res:
            print(f"  {x['ref']}: {x['state']}" + (f" (Bitcoin block {', '.join(map(str, x['bitcoin']))})" if x["bitcoin"] else "") + "".join(f"\n      {k or 'note'}: {v}" for k, v in x["notes"].items()))
        if not res:
            print("  no Bitcoin timestamps recorded")
        return 1 if any(x["state"] in ("error", "missing") for x in res) else 0
    if c == "anchor-verify":
        _need_key(a)
        read = reader_for(a.log)
        d = parse_log(read)
        if d.problems or d.meta is None:
            raise LogError("; ".join(d.problems[:3]) or "unreadable log")
        out = anchors_audit(d, read, (a.log_key or d.meta["pubkey"]).lower(), min_sources=a.min_sources, upgrade=not a.no_calendars)
        _show(out)
        ok = all(x["status"] != "fail" for x in out)
        confirmed = any(x["status"] == "pass" for x in out)
        print(("VERIFIED" if confirmed else "NOTHING CONFIRMED YET (the timestamps are pending or could not be checked)") + ("" if a.log_key else " (the log's key is not pinned)") if ok else "NOT VERIFIED")
        return 0 if ok and confirmed else 1
    if c == "archive-save":
        r = archive_save(Log(a.dir), a.url)
        print(f"  {r['state']}: {r.get('detail', '')}" + (f"\n  snapshot {r['url']}" if r.get("url") else ""))
        return 0 if r["state"] == "saved" else 1
    if c == "archive-check":
        _need_key(a)
        if not re.match(r"https?://", a.log):
            raise LogError("the Internet Archive holds web pages: --log must be the log's URL")
        read = reader_for(a.log)
        d = parse_log(read)
        if d.problems or d.meta is None:
            raise LogError("; ".join(d.problems[:3]) or "unreadable log")
        out, ev = archive_audit(d, a.log.rstrip("/") + "/checkpoint.json", (a.log_key or d.meta["pubkey"]).lower())
        _show(out)
        if ev and a.evidence:
            _out(ev, a.evidence)
        ok = all(x["status"] != "fail" for x in out)
        held = any(x["status"] == "pass" for x in out)
        print(("VERIFIED" if held else "NO ARCHIVE COPY COULD BE CHECKED (none held yet, or the Archive is throttling)") if ok else "NOT VERIFIED")
        return 0 if ok and held else 1
    return 2


if __name__ == "__main__":
    sys.exit(main())
