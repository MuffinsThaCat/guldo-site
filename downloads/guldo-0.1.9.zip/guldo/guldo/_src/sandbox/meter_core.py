"""Pure control logic of the judge's meter, with every OS interaction injected so it can be tested on any machine against
a simulated process table and clock (see test_meter_core.py). meter.py supplies the real /proc, kill, waitpid and clock."""


def kill_until_done(kill_all, try_finish):
    """After the wall deadline: keep killing every solver process until the pipe is closed and the result is collected.
    try_finish() returns the result, or None if something still holds the pipe. Re-killing each round matters: a solver
    that keeps forking can add a pipe holder after any single snapshot of the process table."""
    while True:
        kill_all()
        res = try_finish()
        if res is not None:
            return res


def drain(solver_pids, kill_all, reap, now, sleep, deadline, poll=0.02):
    """Wait until no solver process is left, reaping as we go so their CPU is billed. At/after `deadline` kill whatever
    is alive (every round, so kill-resistant or respawning processes are still caught). Returns True if the deadline had
    to be enforced (an overrun)."""
    overrun = False
    while True:
        reap()
        if not solver_pids():
            return overrun
        if now() > deadline:
            overrun = True
            kill_all()
        sleep(poll)
