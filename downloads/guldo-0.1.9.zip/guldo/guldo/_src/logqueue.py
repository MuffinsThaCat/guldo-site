"""The submission queue for the certificate log: all the WEB tier gets to do.

The public portal accepts a file, checks only that it is the right SHAPE and SIZE, and parks it here. It never verifies a certificate, never runs anything, and never holds the
log's signing key: `certificate.verify` recomputes credit in a subprocess per seed, which is exactly what a web process must not do on a stranger's behalf. A separate worker
(`translog.py ingest`, on a timer, as a different user, with a wall-clock limit per file) does the verifying and signing, and writes a result file the web tier can serve.

  QUEUE/incoming/<sha256>.<certificate|attestation>.json     waiting
  QUEUE/results/<sha256>.json                                what the worker decided: {"state": "admitted", "seq": n} or {"state": "rejected", "reason": "..."}

This module has no heavy imports on purpose: the web tier should not even load the verifier.
"""
import contextlib
import hashlib
import json
import os
import re
import tempfile

QUEUE_NAME = re.compile(r"([0-9a-f]{64})\.(certificate|attestation)\.json")
ID = re.compile(r"[0-9a-f]{64}")
CERT_FORMAT = "svp-certificate-v1"       # certificate.FORMAT; repeated here so the web tier never imports the verifier
MAX_ATTESTATION_BYTES = 64 << 10         # translog.MAX_ATT_BYTES (a test keeps them equal): the door refuses what the worker would


class Refused(ValueError):
    """The file is not something this queue accepts (the message is safe to show the submitter)."""


class QueueFull(Exception):
    """Too many files are waiting: try again later."""


def _bad_constant(name):
    raise ValueError(f"{name} is not valid JSON")


def classify(raw):
    """'certificate' | 'attestation' from the shape alone: nothing is verified. Raises Refused."""
    try:
        obj = json.loads(raw.decode("utf-8"), parse_constant=_bad_constant)
    except (UnicodeDecodeError, ValueError, RecursionError):
        raise Refused("not JSON")
    if not isinstance(obj, dict):
        raise Refused("not a certificate or an attestation")
    if isinstance(obj.get("statement"), dict) and isinstance(obj.get("signature"), str):
        return "attestation"
    if obj.get("format") == CERT_FORMAT:
        return "certificate"
    raise Refused("not a certificate or an attestation")


def _atomic_write(path, data):
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".tmp-")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o640)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def dirs(queue):
    return os.path.join(queue, "incoming"), os.path.join(queue, "results")


def submit(queue, raw, max_bytes=4 << 20, max_pending=200):
    """Park a file. -> (id, state) with state 'queued' or 'known' (already decided: look at its result). Raises Refused or QueueFull."""
    if not isinstance(raw, bytes):
        raise TypeError("a submission is bytes")
    if len(raw) > max_bytes:
        raise Refused(f"larger than the {max_bytes >> 20} MB limit")
    kind = classify(raw)
    if kind == "attestation" and len(raw) > MAX_ATTESTATION_BYTES:
        raise Refused(f"an attestation is larger than {MAX_ATTESTATION_BYTES >> 10} KB: it carries something a signed statement never has")
    sha = hashlib.sha256(raw).hexdigest()
    incoming, results = dirs(queue)
    os.makedirs(incoming, exist_ok=True)
    os.makedirs(results, exist_ok=True)
    if os.path.exists(os.path.join(results, sha + ".json")):
        return sha, "known"
    path = os.path.join(incoming, f"{sha}.{kind}.json")
    if os.path.exists(path):
        return sha, "queued"
    if sum(1 for n in os.listdir(incoming) if QUEUE_NAME.fullmatch(n)) >= max_pending:
        raise QueueFull("the queue is full")
    _atomic_write(path, raw)
    return sha, "queued"


def status(queue, sha):
    """What the worker decided, or {"state": "queued"}, or None if this queue has never seen the id."""
    if not ID.fullmatch(sha):
        return None
    incoming, results = dirs(queue)
    try:
        with open(os.path.join(results, sha + ".json"), encoding="utf-8") as f:
            r = json.load(f)
        if isinstance(r, dict) and r.get("state") in ("admitted", "rejected"):
            return {k: r[k] for k in ("state", "kind", "seq", "reason", "at") if k in r}
    except (OSError, ValueError):
        pass
    if any(os.path.exists(os.path.join(incoming, f"{sha}.{k}.json")) for k in ("certificate", "attestation")):
        return {"state": "queued"}
    return None


def prune_results(queue, keep_days=30, now=None):
    """Delete decided results older than `keep_days`, so the directory a stranger can add to (one small file per distinct submission) is bounded in time. -> how many were removed.
    A file whose result was pruned and is submitted again is simply decided again (an admitted certificate is then refused as a duplicate)."""
    import time
    _, results = dirs(queue)
    if not os.path.isdir(results):
        return 0
    cutoff, n = (now if now is not None else time.time()) - keep_days * 86400, 0
    for name in os.listdir(results):
        if re.fullmatch(r"[0-9a-f]{64}\.json", name):
            p = os.path.join(results, name)
            try:
                if os.path.getmtime(p) < cutoff:
                    os.unlink(p)
                    n += 1
            except OSError:
                pass
    return n


def pending(queue):
    """[(path, id, kind)] waiting, oldest first."""
    incoming, _ = dirs(queue)
    if not os.path.isdir(incoming):
        return []
    out = []
    for n in os.listdir(incoming):
        m = QUEUE_NAME.fullmatch(n)
        if m:
            p = os.path.join(incoming, n)
            out.append((os.path.getmtime(p), p, m.group(1), m.group(2)))
    return [(p, i, k) for _, p, i, k in sorted(out)]
