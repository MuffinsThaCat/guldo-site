"""Reference for aikfac: plain full-batch gradient descent on the L2-regularised softmax loss, step 1/L with L = |X|_F^2 / (2N) + lambda, a fixed number of steps, float64."""
import math

import numpy as np

K = 8
RHO = 0.9
LAMBDA = 1e-3
STEPS = 20000


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, n, N, labels):
    k = np.arange(n)
    U = np.triu(RHO ** np.clip(k[None, :] - k[:, None], 0, None))
    X = (_uniform(seed, 0, N * n).reshape(N, n) @ U) * math.sqrt(1.0 - RHO * RHO)
    Y = np.eye(K)[np.asarray(labels)]
    lr = 1.0 / ((X * X).sum() / (2.0 * N) + LAMBDA)
    W = np.zeros((n, K))
    for _ in range(STEPS):
        S = X @ W
        P = np.exp(S - S.max(axis=1, keepdims=True))
        W = W - lr * (X.T @ (P / P.sum(axis=1, keepdims=True) - Y) / N + LAMBDA * W)
    return [int(v) for v in np.rint(W.ravel() * 2 ** 20)]
