"""Reference for aiprune: the dense two-layer ReLU network on the whole batch, float64, one batched product per layer."""
import math

import numpy as np

ZETA = 3.0


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, Q):
    H = 4 * d
    W1 = _uniform(seed, 0, H * d).reshape(H, d) * math.sqrt(3.0 / d)
    gain = 10.0 ** (-ZETA * (_uniform(seed, H * d, H) + 1.0))
    W2 = _uniform(seed, H * d + H, 10 * H).reshape(10, H) * math.sqrt(3.0 / H) * gain
    X = _uniform(seed, H * d + H + 10 * H, Q * d).reshape(Q, d)
    return [int(v) for v in np.argmax(np.maximum(X @ W1.T, 0.0) @ W2.T, axis=1)]
