"""aipipe in the cluster-counted API, TECHNIQUE: PIPELINE parallelism with 1 microbatch(es). One layer per device (each device regenerates its own layer's weights, once). The batch is split into 1 microbatches of
B/1 rows; at step t stage s works on microbatch t - s, then ONE tp.exchange hands every active stage's result to the next stage. Steps: 1 + 8 - 1, each costing one microbatch's work on the busiest stage and one
message round; with ONE microbatch nothing overlaps (a stage idles while the others work): the bubble is the whole run, the pipeline does 8 steps of full-batch work and is slower than one device by the messages."""
import math

import tensorops as tp

M = 1


def solve(seed, d, B, P):
    mb = B // M
    W = []
    for s in range(P):
        tp.use(s)
        W.append(tp.reshape(tp.stream(seed, B * d + s * d * d, d * d), (d, d)) * math.sqrt(6.0 / d))
    inbox = {}
    outs = []
    for t in range(M + P - 1):
        res = {}
        for s in range(P):
            j = t - s
            if 0 <= j < M:
                tp.use(s)
                x = tp.reshape(tp.stream(seed, j * mb * d, mb * d), (mb, d)) if s == 0 else inbox[s]
                res[s] = tp.relu(x @ W[s])
        sends = [(res[s], s + 1) for s in sorted(res) if s < P - 1]
        if sends:
            got = tp.exchange(sends)
            for (src, dst), r in zip([(s, s + 1) for s in sorted(res) if s < P - 1], got):
                inbox[dst] = r
        if P - 1 in res:
            outs.append(res[P - 1])
    return list(map(int, (tp.reshape(tp.concat(outs, 0), (B * d,)) * 1073741824.0).tolist()))
