"""Build the red-team lookup table by solving the public practice instances once (run only when no timing ladder is running)."""
import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "solvers"))
import families
import instances
import tuned_bkz

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=families.OFFICIAL["gm"]["n"], help="instances per dimension (default: the official n)")
    ap.add_argument("--force", action="store_true", help="overwrite an existing table")
    a = ap.parse_args()
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "solvers", "cheat_table.json")
    if os.path.exists(out) and not a.force:
        raise SystemExit(f"REFUSED: {out} exists (pass --force to overwrite)")
    table = {}
    for dim in families.DEFAULT_DIMS["gm"]:
        for idx in range(a.n):
            inst = families.derive("gm", instances.PRACTICE_SEED, dim, idx)
            v = tuned_bkz.solve(inst["basis"], inst["bound2"])
            if v is None:  # the cheater is allowed to know the judge-side planted answer for PUBLIC practice instances
                v = inst["planted"]
            assert instances.verify(inst, v), (dim, idx)
            table[hashlib.sha256(json.dumps(inst["basis"]).encode()).hexdigest()] = v
            print(dim, idx, flush=True)
    with open(out, "w") as f:
        json.dump(table, f)


if __name__ == "__main__":
    main()
