"""Multi-file bug fixing: a generated Python package with seeded bugs, public example tests, hidden tests.

size = the number of injected bugs (1..4); the package has size + 3 functions spread over several modules, each with a docstring that is its specification. The functions, their parameters, which
ones are broken, and how, are a pure function of the instance seed. Every injected bug is checked at derive time to CHANGE BEHAVIOUR (no equivalent mutants) and to be exposed by at least one PUBLIC
example, so the task is always solvable from what the agent can see.

Tools: `list_files`, `read_file(path)`, `run_tests(module?)` (runs the PUBLIC examples against the agent's current working copy and prints failures with expected and actual values),
`edit_file(path, old, new, occurrence?)` (an exact text replacement; `old` must occur once unless `occurrence` picks one). The answer is the word `done`; it is ignored. The judge does NOT trust the
agent's own test runs or its final message: it REPLAYS the recorded edits on a fresh copy of the package and runs the HIDDEN tests (25 per function) in a child process. Solving means every hidden
test passes, so replacing a function by a table of the public examples fails.

SECURITY NOTE. This domain EXECUTES AGENT-WRITTEN CODE (RUNS_CODE = True): on `run_tests` calls during a run and again when a ladder is verified. The child process has CPU and memory limits, a cleared
environment, a throwaway directory and no stdin beyond its payload; the expected outputs never enter it. It is NOT a security sandbox. Real rounds refuse to start without --accept-unsandboxed-code,
exactly as for the coding domain: run untrusted agents inside a container or VM that cannot read the seed file.
"""
import json
import math
import os
import re
import subprocess
import sys
import tempfile

import agent_core

NAME = "bugfix"
VERSION = "bugfix-v1"
SIZE_RANGE = (1, 4)
SIZE_STEP = 1
DOC = "Fix the seeded bugs in a small Python package by editing its files; the judge runs hidden tests. Submit the word done."
RUNS_CODE = True
N_HIDDEN = 25
N_PUBLIC = 3
TIMEOUT_S = 30
MEM_LIMIT = 768 * 1024 * 1024
MAX_FILE = 20000

# ---- the function templates ---------------------------------------------------------------------------------------------------------------------------------
# Each: source text with {name} and parameters, an input generator, and BUGS = [(correct snippet, buggy snippet)] over the same parameters. The correct snippet occurs in the source.

SRC_CLAMP = '''def {name}(xs):
    """Sum of the values of xs, each clamped into [{lo}, {hi}]."""
    total = 0
    for x in xs:
        if x < {lo}:
            total += {lo}
        elif x > {hi}:
            total += {hi}
        else:
            total += x
    return total
'''
SRC_RUNS = '''def {name}(xs):
    """Number of maximal runs of equal consecutive values in xs (0 for an empty list)."""
    runs = 0
    prev = None
    for i, x in enumerate(xs):
        if i == 0 or x != prev:
            runs += 1
        prev = x
    return runs
'''
SRC_WINMAX = '''def {name}(xs):
    """For each window of {k} consecutive items, the largest item; [] if xs is shorter than {k}."""
    out = []
    for i in range(len(xs) - {k} + 1):
        out.append(max(xs[i:i + {k}]))
    return out
'''
SRC_DEDUPE = '''def {name}(xs):
    """Remove repeated values from xs, keeping the LAST occurrence of each, in their original order."""
    seen = set()
    out = []
    for x in reversed(xs):
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out[::-1]
'''
SRC_ROTATE = '''def {name}(xs):
    """xs rotated right by {k} places (the last {k} items move to the front); a list shorter than 2 is unchanged."""
    if len(xs) < 2:
        return list(xs)
    k = {k} % len(xs)
    return xs[len(xs) - k:] + xs[:len(xs) - k]
'''
SRC_TOPK = '''def {name}(xs):
    """The {k} largest values of xs in descending order (all of them if there are fewer)."""
    idx = sorted(range(len(xs)), key=lambda i: (-xs[i], i))
    return [xs[i] for i in idx[:{k}]]
'''
SRC_LEDGER = '''def {name}(ops):
    """Apply (account, delta) operations in order to balances that start at 0. An operation that would make a balance negative is skipped. Return the balances as a sorted list of (account, balance)."""
    bal = {{}}
    for acct, d in ops:
        new = bal.get(acct, 0) + d
        if new < 0:
            continue
        bal[acct] = new
    return sorted(bal.items())
'''


def _ints(r, lo=-6, hi=9, n_max=9):
    return [r.randint(lo, hi) for _ in range(r.randint(0, n_max))]


def _runs_input(r, ctx):
    out, v = [], r.randint(0, 3)
    for _ in range(r.randint(0, 9)):
        if r.randint(0, 2) == 0:
            v = r.randint(0, 3)
        out.append(v)
    return out


def _ledger_input(r, ctx):
    return [[r.choice(ctx["accounts"]), r.randint(-5, 5)] for _ in range(r.randint(0, 8))]


TEMPLATES = {
    "clamp": {"src": SRC_CLAMP, "params": lambda r, c: {"lo": r.randint(-3, 1) + c["cshift"], "hi": r.randint(3, 7) + c["cshift"]}, "input": lambda r, c: _ints(r, hi=9 + c["vshift"]),
              "bugs": [("            total += {hi}\n", "            total += {hi} - 1\n"), ("        if x < {lo}:\n", "        if x < {lo} - 1:\n")], "prefix": "csum"},
    "runs": {"src": SRC_RUNS, "params": lambda r, c: {}, "input": _runs_input,
             "bugs": [("        if i == 0 or x != prev:\n", "        if i == 0 or x > prev:\n"), ("    runs = 0\n", "    runs = 1\n")], "prefix": "nruns"},
    "winmax": {"src": SRC_WINMAX, "params": lambda r, c: {"k": r.randint(2, 4) + c["kshift"]}, "input": lambda r, c: _ints(r, hi=9 + c["vshift"], n_max=10),
               "bugs": [("range(len(xs) - {k} + 1)", "range(len(xs) - {k})"), ("max(xs[i:i + {k}])", "max(xs[i:i + {k} - 1])")], "prefix": "wmax"},
    "dedupe": {"src": SRC_DEDUPE, "params": lambda r, c: {}, "input": lambda r, c: _ints(r, -3, 4 + c["vshift"], 10),
               "bugs": [("    for x in reversed(xs):\n", "    for x in xs:\n"), ("    return out[::-1]\n", "    return out\n")], "prefix": "dlast"},
    "rotate": {"src": SRC_ROTATE, "params": lambda r, c: {"k": r.randint(1, 7) + c["kshift"]}, "input": lambda r, c: _ints(r, hi=9 + c["vshift"], n_max=8),
               "bugs": [("    k = {k} % len(xs)\n", "    k = {k}\n"), ("xs[:len(xs) - k]\n", "xs[:len(xs) - k - 1]\n")], "prefix": "rotr"},
    "topk": {"src": SRC_TOPK, "params": lambda r, c: {"k": r.randint(2, 4) + c["kshift"]}, "input": lambda r, c: _ints(r, hi=9 + c["vshift"], n_max=8),
             "bugs": [("idx[:{k}]", "idx[:{k} - 1]"), ("key=lambda i: (-xs[i], i)", "key=lambda i: (xs[i], i)")], "prefix": "topn"},
    "ledger": {"src": SRC_LEDGER, "params": lambda r, c: {}, "input": _ledger_input,
               "bugs": [("        if new < 0:\n", "        if new <= 0:\n"), ("bal.get(acct, 0) + d", "bal.get(acct, 0) - d")], "prefix": "bal"},
}
KINDS = tuple(TEMPLATES)
POOL_TAGS = ("ka", "vel", "or", "tan", "mi", "ra", "sol", "den", "ur", "lis", "bre", "qua", "zen", "fa", "gor", "hel", "pi", "nox", "yu", "ash", "dun", "eri", "fal", "gan", "hir", "iko", "jor",
             "kel", "lam", "mor", "nai", "ost", "pra", "rin", "sab", "tev", "ulm", "vor", "wen", "xal")
POOL_ACCOUNTS = ("a", "b", "c", "x", "y", "z", "m", "n", "p", "q", "r", "s")
SEALED_DRAWS = [("function name tags", agent_core.sample_bits(len(POOL_TAGS), 20)), ("ledger account names", agent_core.sample_bits(len(POOL_ACCOUNTS), 3)), ("value range shift", math.log2(5)),
                ("window size shift", math.log2(4)), ("clamp bounds shift", math.log2(6))]
# A moderate seal: names and numeric ranges. The TEMPLATES, the bug CATALOG and the way a bug is injected are the public generator's, so a model that learned the catalog benefits fully.


def _fmt(snippet, params):
    return snippet.format(**params)


def _call(source, name, arg):
    """Run one function of generated (trusted, our own) source in-process; used only at derive time on our templates."""
    ns = {}
    exec(compile(source, "<generated>", "exec"), ns)
    return json.loads(json.dumps(ns[name](json.loads(json.dumps(arg)))))


def derive(seed, size, style=None):
    st = style or agent_core.CANONICAL
    tags = st.sample("function name tags", POOL_TAGS, 20)
    ctx = {"accounts": st.sample("account names", POOL_ACCOUNTS, 3), "vshift": st.between("value range shift", 0, 4), "kshift": st.between("window size shift", 0, 3),
           "cshift": st.between("clamp bounds shift", 0, 5)}
    r = agent_core.Rng(seed)
    n_funcs = size + 3
    for _attempt in range(200):
        funcs = []
        used = set()
        for _ in range(n_funcs):
            kind = r.choice(KINDS)
            tpl = TEMPLATES[kind]
            params = tpl["params"](r, ctx)
            name = "%s_%s%s" % (tpl["prefix"], r.choice(tags), r.choice(tags))
            if name in used:
                break
            used.add(name)
            funcs.append({"kind": kind, "name": name, "params": params, "correct": _fmt(tpl["src"], dict(params, name=name))})
        else:
            broken = r.sample(range(n_funcs), size)
            ok = True
            for fi in broken:
                f = funcs[fi]
                good, bad = TEMPLATES[f["kind"]]["bugs"][r.randint(0, 1)]
                good, bad = _fmt(good, f["params"]), _fmt(bad, f["params"])
                if f["correct"].count(good) != 1:
                    ok = False
                    break
                f["bug"] = {"good": good, "bad": bad}
                f["buggy"] = f["correct"].replace(good, bad)
            if not ok:
                continue
            tests = {}
            for f in funcs:
                tpl = TEMPLATES[f["kind"]]
                cands = [tpl["input"](r, ctx) for _ in range(N_HIDDEN * 3)]
                if "bug" in f:
                    diff = [c for c in cands if _call(f["correct"], f["name"], c) != _call(f["buggy"], f["name"], c)]
                    if len(diff) < 3:
                        ok = False
                        break
                    public = diff[:1] + [c for c in cands if c not in diff[:1]][:N_PUBLIC - 1]
                    hidden = diff[:4] + [c for c in cands if c not in diff[:4]][:N_HIDDEN - 4]
                else:
                    public, hidden = cands[:N_PUBLIC], cands[:N_HIDDEN]
                tests[f["name"]] = {"public": public, "hidden": hidden, "public_expected": [_call(f["correct"], f["name"], c) for c in public],
                                    "hidden_expected": [_call(f["correct"], f["name"], c) for c in hidden]}
            if not ok:
                continue
            break
    else:
        raise RuntimeError("could not derive a bugfix instance")
    order = r.sample(range(n_funcs), n_funcs)
    n_mod = (n_funcs + 1) // 2
    mods = [[] for _ in range(n_mod)]
    for pos, fi in enumerate(order):
        mods[pos % n_mod].append(funcs[fi])
    files, where = {}, {}
    for mi, fs in enumerate(mods):
        path = "pkg/m%d.py" % mi
        header = '"""Module m%d of the package."""\n\n\n' % mi
        files[path] = header + "\n\n".join(f.get("buggy", f["correct"]) for f in fs)
        for f in fs:
            where[f["name"]] = "m%d" % mi
    correct = {}
    for mi, fs in enumerate(mods):
        correct["pkg/m%d.py" % mi] = header_for(mi) + "\n\n".join(f["correct"] for f in fs)
    n_bugs = sum(1 for f in funcs if "bug" in f)
    ticket = r.randint(1000, 9999)
    names = sorted(f["name"] for f in funcs)
    public = {"task": ("Ticket %d. A small Python package (files under pkg/) has %d bugs, in some of its %d functions across %d modules: %s. Each function's docstring says what it must do. "
                       "Public example tests are available through the `run_tests` tool; the judge also runs hidden tests. Fix the bugs by editing the files with `edit_file`, then submit the word done."
                       % (ticket, size, n_funcs, n_mod, ", ".join(names))),
              "files": sorted(files), "n_functions": n_funcs}
    return {"public": public, "private": {"files": files, "correct_files": correct, "suites": tests, "where": where, "bugs": [{"function": f["name"], "module": where[f["name"]], "good": f["bug"]["good"], "bad": f["bug"]["bad"]}
                                                                                                                              for f in funcs if "bug" in f], "n_bugs": n_bugs}}


def header_for(mi):
    return '"""Module m%d of the package."""\n\n\n' % mi


def prompt(public):
    return public["task"]


def tool_specs(public):
    return [
        {"name": "list_files", "description": "The files of the package.", "input_schema": {"type": "object", "properties": {}}},
        {"name": "read_file", "description": "The full text of one file.", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}},
        {"name": "run_tests", "description": "Run the PUBLIC example tests against the current files. Optionally only one module (e.g. m1). Shows failures with expected and actual values.",
         "input_schema": {"type": "object", "properties": {"module": {"type": "string"}}}},
        {"name": "edit_file", "description": "Replace the exact text `old` by `new` in a file. `old` must occur exactly once, unless `occurrence` (1-based) picks which occurrence to replace.",
         "input_schema": {"type": "object", "properties": {"path": {"type": "string"}, "old": {"type": "string"}, "new": {"type": "string"}, "occurrence": {"type": "integer"}}, "required": ["path", "old", "new"]}},
    ]


def apply_edit(files, args):
    """Apply one edit_file call to `files` (a dict) in place. Returns a message; 'error: ...' means nothing changed."""
    if not isinstance(args, dict):
        return "error: arguments must be an object"
    path, old, new, occ = args.get("path"), args.get("old"), args.get("new"), args.get("occurrence")
    if not isinstance(path, str) or path not in files:
        return "error: no such file"
    if not isinstance(old, str) or not old or not isinstance(new, str):
        return "error: old must be non-empty text and new must be text"
    text = files[path]
    n = text.count(old)
    if n == 0:
        return "error: the text to replace does not occur in %s" % path
    if occ is None:
        if n > 1:
            return "error: the text occurs %d times in %s; give `occurrence` (1-based) to pick one" % (n, path)
        k = 0
    else:
        if not isinstance(occ, int) or isinstance(occ, bool) or not 1 <= occ <= n:
            return "error: occurrence must be between 1 and %d" % n
        k = occ - 1
    pos = -1
    for _ in range(k + 1):
        pos = text.index(old, pos + 1)
    updated = text[:pos] + new + text[pos + len(old):]
    if len(updated) > MAX_FILE:
        return "error: the file would exceed %d characters" % MAX_FILE
    files[path] = updated
    return "ok: edited %s" % path


# ---- running tests in a child process ---------------------------------------------------------------------------------------------------------------------------

CHILD = r'''
import sys, json, os
real = sys.stdout
try:
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
    try:
        resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
    except (ValueError, OSError):
        pass
except ImportError:
    pass
sys.setrecursionlimit(2000)
head = json.loads(sys.stdin.readline())
import threading, time, importlib
def _watch(limit):
    scale = 1 if sys.platform == "darwin" else 1024
    while True:
        time.sleep(0.02)
        try:
            if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * scale > limit:
                os._exit(97)
        except Exception:
            return
threading.Thread(target=_watch, args=(head["mem_bytes"],), daemon=True).start()
sys.path.insert(0, os.getcwd())
sys.stdout = open(os.devnull, "w")
mods = {}
for line in sys.stdin:
    mod, fn, arg = json.loads(line)
    try:
        if mod not in mods:
            mods[mod] = importlib.import_module("pkg." + mod)
        out = getattr(mods[mod], fn)(arg)
        json.dumps(out)
        res = {"out": out}
    except BaseException as e:
        res = {"error": "%s: %s" % (type(e).__name__, str(e)[:160])}
    real.write(json.dumps(res) + "\n")
    real.flush()
'''


def run_calls(files, calls):
    """Write `files` to a throwaway directory and run [(module, function, arg)] in a child process. Returns one {"out":..} or {"error":..} per call."""
    payload = json.dumps({"mem_bytes": MEM_LIMIT}) + "\n" + "".join(json.dumps(list(c)) + "\n" for c in calls)
    with tempfile.TemporaryDirectory(prefix="guldo-bugfix-") as tmp:
        os.makedirs(os.path.join(tmp, "pkg"))
        with open(os.path.join(tmp, "pkg", "__init__.py"), "w") as f:
            f.write("")
        for path, text in files.items():
            dest = os.path.normpath(os.path.join(tmp, path))
            if not dest.startswith(tmp + os.sep):
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "w", encoding="utf-8") as f:
                f.write(text)
        import agent_sandbox                  # local subprocess by default; a container (package mounted read-only, no network, no seed) with GULDO_SANDBOX=docker
        rc, out = agent_sandbox.run_python(CHILD, payload, tmp, TIMEOUT_S)
    if rc is None:
        return [{"error": "timeout"}] * len(calls)

    class p:
        returncode, stdout = rc, out
    res = []
    for ln in [x for x in p.stdout.split("\n") if x.strip()][:len(calls)]:
        try:
            v = json.loads(ln)
            res.append(v if isinstance(v, dict) and ("out" in v or "error" in v) else {"error": "malformed reply"})
        except ValueError:
            res.append({"error": "malformed reply"})
    while len(res) < len(calls):
        res.append({"error": "child ended early" if p.returncode else "no reply"})
    return res


def _norm(o):
    return json.loads(json.dumps(o))


def _suite(instance, files, which, module=None):
    """Run the public or hidden examples; returns [(function, module, input, expected, got-or-error)] for every example."""
    where = instance["private"]["where"]
    cases = []
    for fn, t in sorted(instance["private"]["suites"].items()):
        if module is not None and where[fn] != module:
            continue
        for arg, want in zip(t[which], t[which + "_expected"]):
            cases.append((fn, where[fn], arg, want))
    res = run_calls(files, [(m, fn, a) for fn, m, a, _w in cases])
    return [(fn, m, a, w, r) for (fn, m, a, w), r in zip(cases, res)]


class Env:
    def __init__(self, instance):
        self.instance = instance
        self.files = dict(instance["private"]["files"])

    def call(self, name, args):
        if not isinstance(args, dict):
            return "error: arguments must be an object"
        if name == "list_files":
            return "\n".join("%s (%d lines)" % (p, t.count("\n") + 1) for p, t in sorted(self.files.items()))
        if name == "read_file":
            p = args.get("path")
            return self.files[p] if isinstance(p, str) and p in self.files else "error: no such file"
        if name == "edit_file":
            return apply_edit(self.files, args)
        if name == "run_tests":
            mod = args.get("module")
            if mod is not None and (not isinstance(mod, str) or mod not in set(self.instance["private"]["where"].values())):
                return "error: unknown module"
            rows = _suite(self.instance, self.files, "public", mod)
            fails = [(fn, m, a, w, r) for fn, m, a, w, r in rows if r.get("out") is None or _norm(r["out"]) != _norm(w)]
            lines = ["%d of %d public examples pass" % (len(rows) - len(fails), len(rows))]
            seen = {}                       # one line per failing FUNCTION (its first failing example), so no buggy function is ever hidden behind another's failures
            for fn, m, a, w, r in fails:
                seen.setdefault((m, fn), []).append((a, w, r))
            for (m, fn), items in sorted(seen.items()):
                a, w, r = items[0]
                lines.append("FAIL %s.%s: %d of %d examples fail; e.g. input %s expected %s got %s" % (
                    m, fn, len(items), sum(1 for x in rows if x[0] == fn), json.dumps(a), json.dumps(w), json.dumps(r["out"]) if "out" in r else r.get("error")))
            return "\n".join(lines)
        return "error: unknown tool %r" % name


def make_env(instance):
    return Env(instance)


def reference_answer(instance):
    return "done"


def reference_calls(instance):
    """The judge-side fix: one edit_file call per injected bug (with the right occurrence). Used by the domain checks and the scripted agents' reference."""
    calls, files = [], dict(instance["private"]["files"])
    for b in instance["private"]["bugs"]:
        path = "pkg/%s.py" % b["module"]
        text = files[path]
        fstart = text.index("def %s(" % b["function"])
        k = text[:fstart].count(b["bad"]) + 1
        n = text.count(b["bad"])
        args = {"path": path, "old": b["bad"], "new": b["good"]}
        if n > 1:
            args["occurrence"] = k
        calls.append({"name": "edit_file", "args": args})
        apply_edit(files, args)
    return calls


def verify(instance, answer, calls):
    files = dict(instance["private"]["files"])
    for c in calls:
        if c.get("name") == "edit_file":
            apply_edit(files, c.get("args", {}))
    rows = _suite(instance, files, "hidden")
    bad = [r for r in rows if r[4].get("out") is None or _norm(r[4]["out"]) != _norm(r[3])]
    if bad:
        fn, m, a, w, r = bad[0]
        return False, "%d of %d hidden tests fail (first: %s.%s)" % (len(bad), len(rows), m, fn)
    return True, "ok"


# ---- the scripted stand-ins' knowledge of the bug catalog (NOT available to a real model except by reading the code) ----------------------------------------------------

def repairs(text, function):
    """[(old, new, occurrence, position)] edits that undo a catalogued bug in the body of `function`. Only the bug patterns of THAT function's template are tried (its name prefix says which): some patterns
    are ordinary correct code in another template (`for x in xs:` is the dedupe bug and a line of clamp)."""
    out = []
    s = text.find("def %s(" % function)
    if s < 0:
        return out
    e = text.find("\ndef ", s + 1)
    offset, region = s, text[s:e if e >= 0 else len(text)]
    for kind, tpl in TEMPLATES.items():
        if not function.startswith(tpl["prefix"] + "_"):
            continue
        for good, bad in tpl["bugs"]:
            pat = re.escape(bad)
            pat = re.sub(r"\\\{(\w+)\\\}", r"(?P<\1>-?\\d+)", pat)
            for m in re.finditer(pat, region):
                gd = dict(m.groupdict())
                try:
                    old_txt, new_txt = m.group(0), good.format(**gd) if gd else good
                except (KeyError, IndexError):
                    continue
                before = text[:offset + m.start()].count(old_txt) + 1
                out.append((old_txt, new_txt, before, offset + m.start()))
    return sorted(out, key=lambda t: -t[3])       # last position first: applying them in this order never shifts an earlier occurrence's index
