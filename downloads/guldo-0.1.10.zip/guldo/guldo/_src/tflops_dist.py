"""Counted ladders for a simulated CLUSTER: critical-path work, message rounds and bytes per device, exactly (tflops.py's sibling; tensorops_dist.py defines the machine and the accounting).

  python3 tflops_dist.py practice SOLVER --baseline REF --family aidist --dims 16 24 32 --n 4 --cap 800 [--seed SEEDFILE] [--reuse-baseline]
  python3 tflops_dist.py verify LADDER [LADDER ...] [--rerun K|all] [--seed SEEDFILE] [--solvers DIR]
  python3 tflops_dist.py selfcheck SOLVER --family aidist --dim 16          does the same instance count the same twice (operations, work, rounds and bytes)?

A solver is written as for tflops.py (the restricted subset plus `import tensorops as tp`) and, for a family with several devices, uses tp.use(k) and the collectives (tp.all_reduce, reduce_scatter,
all_gather, broadcast). The ladder records per instance `steps` and `flops` (all the arithmetic of all the devices: the WORK), `wcrit` (the busiest device's flops summed over the phases between barriers),
`rounds` and `comm` (bytes per device on the critical path, times L = lcm(1..ranks)), all exact integers, and `time` = wcrit + steps + ALPHA0 * rounds + BETA0 * comm / L on the DEFAULT machine written in
the header. `verify` redoes the arithmetic of every record and, with --rerun, re-executes records and demands IDENTICAL counts.

THE POINT is the other machines. On a machine with latency alpha (flop-times per message round) and inverse bandwidth beta (flop-times per byte) the time of a run is EXACTLY
    T(alpha, beta) = wcrit + steps + alpha * rounds + beta * comm / L
so two runs compare on every interconnect at once: `dominates(A, B)` says A is no worse in all three of (wcrit + steps), rounds and comm (then A is at least as fast on EVERY machine), and `grid(A, B)` gives the
winner at each point of a grid of machines. A solver that does less arithmetic per device but talks more wins on a fast network and loses on a slow one, and the crossover is a computation.

It is NOT a measurement and NOT a topology model: identical links, ring and tree collectives, a barrier at every collective (so no overlap of compute and communication is credited), no congestion, no
reduction arithmetic, no memory. It needs Python 3.12+ and the same unprivileged-throwaway-user care as tflops.py.
"""
import argparse
import hashlib
import json
import os
import random
import secrets
import sys
import tempfile
import time
from fractions import Fraction

import instances
import runwatch
import tensorops_dist
import tflops

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(HERE, "tflops_dist_runner.py")
COST_MODEL = "tflops-dist"
COUNTER_FILES = ("tflops_dist_runner.py", "tensorops_dist.py", "tensorops.py", "count_runner.py")
UNIT_OPS = tflops.UNIT_OPS
MIN_PYTHON = tflops.MIN_PYTHON
ALPHA0, BETA0 = 10_000, 10          # the DEFAULT machine of the scalar `time`: a round costs 10000 flop-times, a byte 10 (an arbitrary mid-grid point: the grid, not this, is the evidence)
ALPHAS = (100, 10_000, 1_000_000)
BETAS = (1, 10, 100, 1000)
NEXT_HINT = "next: compare two solvers on any cost with: python3 tflops_compare.py compare BASELINE A B --metric ops|time"
CLAIM_LIMITS = ("A count is not a time. Work, rounds and bytes are an accounting convention over a simulated cluster of identical devices on identical links (ring and tree collectives, a barrier at every collective, no "
                "overlap of compute and communication, no congestion, no reduction arithmetic, no memory), exactly reproducible by anyone, so they can show 'A is faster than B on every machine with these "
                "latencies and bandwidths' and cannot show how fast either runs on any real cluster. The solver's Python is charged in full as serial time. The ladder is the prover's unless it was fixed in advance.")


def counter_sha256():
    h = hashlib.sha256()
    for name in COUNTER_FILES:
        with open(os.path.join(HERE, name), "rb") as f:
            h.update(name.encode() + b"\0" + hashlib.sha256(f.read()).digest())
    return h.hexdigest()


def lcm_upto(n):
    return tensorops_dist.lcm_upto(n)


def time_exact(counts, alpha, beta, L):
    """counts = (wcrit, steps, rounds, comm). The run's time on a machine (alpha, beta), as an exact fraction."""
    wcrit, steps, rounds, comm = counts
    return Fraction(wcrit + steps) + Fraction(alpha) * rounds + Fraction(beta) * Fraction(comm, L)


def dominates(a, b):
    """True iff A is no worse than B in (wcrit + steps), rounds and comm: then A is at least as fast on EVERY machine."""
    return a[0] + a[1] <= b[0] + b[1] and a[2] <= b[2] and a[3] <= b[3]


def grid(a, b, L):
    """-> {"alpha,beta": "A" | "B" | "tie"}: who is faster, exactly, at each point of the grid of machines."""
    out = {}
    for al in ALPHAS:
        for be in BETAS:
            ta, tb = time_exact(a, al, be, L), time_exact(b, al, be, L)
            out[f"{al},{be}"] = "A" if ta < tb else "B" if tb < ta else "tie"
    return out


def device_cap(mod, dim):
    """The most bytes one device may hold on instances of this size, from the declaration (a function `device_cap(size)`), or None."""
    fn = getattr(mod, "device_cap", None)
    return None if fn is None else int(fn(dim))


def count_instance(solver, inst, verify, cap, ranks, cap_bytes=None, max_rss_mb=tflops.MAX_RSS_MB):
    """Run `solver` on `inst` under counting. -> a ladder record: id, dim, status, steps, flops, wcrit, rounds, comm, time, cpu, cpu_net, wall."""
    limit = int(cap * UNIT_OPS)
    rec = {"id": inst["id"], "dim": inst["dim"]}
    payload = json.dumps({"args": inst["args"], "limit": limit, "ranks": ranks, "cap_bytes": cap_bytes}).encode()
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "1", "PATH": os.environ.get("PATH", "")}
    t0 = time.time()
    with tempfile.TemporaryDirectory() as empty:
        stdout, stderr, killed = runwatch.run_watched([sys.executable, "-B", RUNNER, os.path.abspath(solver)], payload, env, empty, limit / tflops.SLOW_OPS_PER_SECOND + 120, max_rss_mb)
    rec["wall"] = time.time() - t0
    none = {"steps": None, "flops": None, "wcrit": None, "rounds": None, "comm": None, "peak_bytes": None, "time": None}
    if killed == "wall":
        rec.update({"status": "timeout", **none, "wall_timeout": True, "cpu": cap, "cpu_net": cap})
        return rec
    if killed == "memory":
        rec.update({"status": "crash", **none, "cpu": cap, "cpu_net": cap, "err": f"killed: resident memory passed {max_rss_mb} MB"})
        return rec
    lines = [ln for ln in stdout.decode(errors="replace").splitlines() if ln.strip()]
    try:
        out = json.loads(lines[-1])
        steps, flops, wcrit, rounds, comm, peak = (int(out[k]) for k in ("steps", "flops", "wcrit", "rounds", "comm", "peak"))
        status = out["status"]
    except (IndexError, ValueError, KeyError, TypeError):
        rec.update({"status": "crash", **none, "cpu": cap, "cpu_net": cap, "err": "the counter produced no result: " + stderr.decode(errors="replace")[-300:]})
        return rec
    L = lcm_upto(ranks)
    rec.update({"steps": steps, "flops": flops, "wcrit": wcrit, "rounds": rounds, "comm": comm, "peak_bytes": peak, "time": float(time_exact((wcrit, steps, rounds, comm), ALPHA0, BETA0, L))})
    if status == "limit":
        rec.update({"status": "timeout", "cpu": cap, "cpu_net": cap})
    elif status == "error":
        rec.update({"status": "crash", "cpu": cap, "cpu_net": cap, "err": str(out.get("err", ""))[-1500:]})
    else:
        ans = out.get("ans")
        try:
            ok = bool(verify(inst, ans))
        except Exception as e:     # a verifier that RAISES is the operator's bug, not a wrong answer: say so in the record
            ok = False
            rec["verify_error"] = f"{type(e).__name__}: {str(e)[:200]}"
        rec["status"] = "solved" if ok else ("failed" if ans is None else "wrong")
        rec["cpu"] = (steps + flops) / UNIT_OPS
        rec["cpu_net"] = max(rec["cpu"], 1e-3)
        if rec["status"] != "solved":
            rec["cpu"] = rec["cpu_net"] = cap
    return rec


def ladder_header(solver, family, mod, decl_dir, master, cap):
    ranks = int(mod.RANKS)
    return {"meta": True, "solver": os.path.basename(solver), "commit": instances.commit(master), "overhead": 0.0, "budget": cap, "family": family,
            "sandbox": COST_MODEL, "instance_version": mod.VERSION, "image": None, "host": "analytic operation and cluster counting (no machine timing)",
            "cpu": "none: counts", "ncpu": 1, "jobs": 1, "solver_sha256": tflops.sha256_file(solver),
            "cost_model": COST_MODEL, "unit_ops": UNIT_OPS, "python": tflops.python_version(), "counter_sha256": counter_sha256(),
            "decl_sha256": tflops.sha256_file(os.path.join(decl_dir, "decl.py")), "ranks": ranks, "alpha0": ALPHA0, "beta0": BETA0,
            "device_cap": hasattr(mod, "device_cap")}


def evaluate_ladder(solver, family, master, dims, n, cap, out_path, progress=None):
    if os.path.exists(out_path):
        raise FileExistsError(out_path)
    mod, derive, verify, d = tflops.load_family(family)
    fd = os.open(out_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    recs = []
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps(ladder_header(solver, family, mod, d, master, cap)) + "\n")
        for dim in dims:
            for idx in range(n):
                rec = count_instance(solver, derive(master, dim, idx), verify, cap, int(mod.RANKS), device_cap(mod, dim))
                f.write(json.dumps(rec) + "\n")
                f.flush()
                recs.append(rec)
                if progress:
                    progress(os.path.basename(solver), rec)
    return recs


def baseline_reusable(path, solver, family, master, dims, n, cap):
    """-> (ok, why): an existing baseline ladder may be reused only if its header is exactly the one that would be written now and it holds exactly the expected instances."""
    try:
        meta, recs = tflops.read_ladder(path)
    except (OSError, ValueError) as e:
        return False, f"unreadable ({type(e).__name__})"
    mod, derive, verify, d = tflops.load_family(family)
    if meta != ladder_header(solver, family, mod, d, master, cap):
        return False, "its header differs from the one this run would write (different seed, solver, declaration, budget, interpreter or counter)"
    want = {f"{dim}:{i}" for dim in dims for i in range(n)}
    got = [r.get("id") for r in recs]
    if len(got) != len(set(got)) or set(got) != want:
        return False, f"it holds {len(set(got) & want)} of the {len(want)} expected instances"
    return True, ""


def verify_ladder(path, rerun=0, master=None, solver_path=None, sample_seed=None):
    """-> (ok, [lines]): the cost model of every record; with rerun > 0 also the exact re-execution of that many records (or all of them): status, work, rounds and bytes must be IDENTICAL."""
    lines, ok = [], True
    meta, recs = tflops.read_ladder(path)
    name = os.path.basename(path)
    if meta is None or meta.get("cost_model") != COST_MODEL:
        return False, [f"FAIL {name}: not a {COST_MODEL} ladder"]
    cap, unit = meta.get("budget"), meta.get("unit_ops")
    ranks = meta.get("ranks")
    if isinstance(cap, bool) or not isinstance(cap, (int, float)) or cap <= 0 or "solver_sha256" not in meta or "commit" not in meta or isinstance(ranks, bool) or not isinstance(ranks, int) or ranks < 1:
        return False, [f"FAIL {name}: the header lacks a positive budget, a seed commitment, a solver hash or a device count"]
    if meta.get("alpha0") != ALPHA0 or meta.get("beta0") != BETA0:
        return False, [f"FAIL {name}: the ladder's default machine is not this checkout's"]
    if not recs:
        return False, [f"FAIL {name}: the ladder holds no records (an empty ladder certifies nothing)"]
    if unit != UNIT_OPS:
        ok = False
        lines.append(f"FAIL unit: the ladder's unit is {unit}, this checkout's is {UNIT_OPS}")
    if meta.get("counter_sha256") != counter_sha256():
        ok = False
        lines.append("FAIL counter: the ladder was counted by a different counting program (hash differs from this checkout's): re-measure with this one")
    L = lcm_upto(ranks)
    bad = 0
    isint = lambda v: isinstance(v, int) and not isinstance(v, bool) and v >= 0
    for r in recs:
        try:
            if r["status"] == "solved":
                if not all(isint(r[k]) for k in ("steps", "flops", "wcrit", "rounds", "comm", "peak_bytes")):
                    bad += 1
                    continue
                exp = (r["steps"] + r["flops"]) / UNIT_OPS
                tm = float(time_exact((r["wcrit"], r["steps"], r["rounds"], r["comm"]), ALPHA0, BETA0, L))
                if abs(r["cpu"] - exp) > 1e-12 or abs(r["cpu_net"] - max(exp, 1e-3)) > 1e-12 or r["time"] != tm or r["wcrit"] > r["flops"]:
                    bad += 1
            elif r["cpu_net"] != cap:
                bad += 1
        except (KeyError, TypeError):
            bad += 1
    lines.append(f"{'PASS' if not bad else 'FAIL'} cost model: every solved cost = (flops + steps) / {UNIT_OPS:g}, the critical-path work never exceeds the total work, `time` is exactly wcrit + steps + {ALPHA0} * rounds + {BETA0} * comm / L, and every unsolved instance is charged the cap" + (f" ({bad} records disagree)" if bad else ""))
    ok = ok and not bad
    if rerun:
        if meta.get("python") != tflops.python_version():
            lines.append(f"SKIP re-run: ladder counted on {meta.get('python')}, this interpreter is {tflops.python_version()} (counts are only comparable on the same one)")
            return False, lines
        if solver_path is None and (not isinstance(meta["solver"], str) or meta["solver"] != os.path.basename(meta["solver"]) or meta["solver"] in ("", ".", "..")):
            lines.append(f"FAIL re-run: the ladder names its solver {meta['solver']!r}, which is not a plain file name: it will not be looked up on disk")
            return False, lines
        solver = solver_path or os.path.join(HERE, "solvers", meta["solver"])
        if not os.path.exists(solver) or tflops.sha256_file(solver) != meta["solver_sha256"]:
            lines.append(f"FAIL re-run: the solver file {meta['solver']} is missing here or its hash differs from the ladder's")
            return False, lines
        mod, derive, verify, d = tflops.load_family(meta["family"])
        if tflops.sha256_file(os.path.join(d, "decl.py")) != meta.get("decl_sha256") or int(mod.RANKS) != ranks:
            lines.append("FAIL re-run: this checkout's decl.py differs from the one the ladder was made with")
            return False, lines
        if master is None or instances.commit(master) != meta["commit"]:
            lines.append("SKIP re-run: the seed given does not match the ladder's commitment (pass the revealed seed with --seed)")
            return False, lines
        k = len(recs) if rerun == "all" else min(int(rerun), len(recs))
        if k >= len(recs):
            pick = list(recs)
            lines.append(f"FULL AUDIT: all {len(recs)} records are re-executed")
        else:
            seed = secrets.randbits(64) if sample_seed is None else sample_seed
            pick = random.Random(seed).sample(recs, k)
            lines.append(f"sample: {k} of {len(recs)} records drawn at random (sample seed {seed})")
        same = 0
        key = lambda x: (x.get("status"), x.get("steps"), x.get("flops"), x.get("wcrit"), x.get("rounds"), x.get("comm"), x.get("peak_bytes"))
        for r in pick:
            dim, idx = r["id"].split(":")
            again = count_instance(solver, derive(master, int(dim), int(idx)), verify, cap, ranks, device_cap(mod, int(dim)))
            if key(again) == key(r):
                same += 1
            else:
                lines.append(f"  differs at {r['id']}: recorded {key(r)}, re-run {key(again)}")
        good = same == len(pick)
        lines.append(f"{'PASS' if good else 'FAIL'} re-run: {same}/{len(pick)} instances re-executed with identical status, work, rounds and bytes")
        ok = ok and good
    return ok, lines


def _master(a):
    if a.seed:
        with open(a.seed, "rb") as f:
            return f.read().strip()
    return instances.PRACTICE_SEED


def cmd_practice(a):
    master = _master(a)
    tag = instances.commit(master)[:8]
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    paths = []
    for role, solver in (("baseline", a.baseline), ("submission", a.solver)):
        p = os.path.join(HERE, "results", f"tflopsdist_{a.family}_{tag}_{role}_{os.path.basename(solver)}.jsonl")
        if os.path.exists(p) and role == "baseline" and a.reuse_baseline:
            ok, why = baseline_reusable(p, solver, a.family, master, a.dims, a.n, a.cap)
            if not ok:
                sys.exit(f"{p} exists but cannot be reused: {why}. Move it aside and run again.")
            paths.append(p)
            continue
        evaluate_ladder(solver, a.family, master, a.dims, a.n, a.cap, p, progress=lambda name, rec: print(f"  {name} {rec['id']}: {rec['status']} work {rec.get('flops')}, critical {rec.get('wcrit')}, rounds {rec.get('rounds')}, comm {rec.get('comm')}", flush=True))
        paths.append(p)
    print("ladders:\n  " + "\n  ".join(paths))
    print(NEXT_HINT)


def cmd_verify(a):
    master = _master(a)
    allok = True
    for p in a.ladders:
        ok, lines = verify_ladder(p, a.rerun, master, sample_seed=a.sample_seed)
        print(p)
        for ln in lines:
            print("  " + ln)
        allok = allok and ok
    print(("\nVERIFIED (costs consistent and re-executed as requested)" if a.rerun else "\nCONSISTENT ONLY: the cost arithmetic checks out, but nothing was re-executed (use --rerun K or --rerun all)") if allok else "\nNOT VERIFIED")
    print("What this does NOT show: " + CLAIM_LIMITS)
    sys.exit(0 if allok else 1)


def cmd_selfcheck(a):
    mod, derive, verify, d = tflops.load_family(a.family)
    inst = derive(instances.PRACTICE_SEED, a.dim, 0)
    inst.setdefault("id", f"{a.dim}:0")
    inst.setdefault("dim", a.dim)
    x, y = (count_instance(a.solver, inst, verify, a.cap, int(mod.RANKS), device_cap(mod, a.dim)) for _ in range(2))
    key = lambda r: (r["status"], r.get("steps"), r.get("flops"), r.get("wcrit"), r.get("rounds"), r.get("comm"), r.get("peak_bytes"))
    print(f"run 1: {x['status']} work {x.get('flops')} critical {x.get('wcrit')} rounds {x.get('rounds')} comm {x.get('comm')}\n"
          f"run 2: {y['status']} work {y.get('flops')} critical {y.get('wcrit')} rounds {y.get('rounds')} comm {y.get('comm')}\n" + ("IDENTICAL" if key(x) == key(y) else "DIFFERENT: not countable"))
    sys.exit(0 if key(x) == key(y) and x["status"] == "solved" else 1)


def main(argv=None):
    if sys.version_info < MIN_PYTHON:
        sys.exit("tflops_dist needs Python 3.12 or newer")
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        sys.exit("tflops_dist refuses to run as root: the solver is contained by a restricted subset, not a sandbox. Use an unprivileged throwaway user.")
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("practice")
    p.add_argument("solver")
    p.add_argument("--baseline", required=True)
    p.add_argument("--family", required=True)
    p.add_argument("--dims", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, default=8)
    p.add_argument("--cap", type=float, default=2000, help="budget in counted seconds (1 = 1e7 operations)")
    p.add_argument("--seed")
    p.add_argument("--reuse-baseline", action="store_true")
    p = sub.add_parser("verify")
    p.add_argument("ladders", nargs="+")
    p.add_argument("--rerun", type=lambda s: s if s == "all" else int(s), default=0, help="K random records to re-execute, or `all` for a full audit")
    p.add_argument("--sample-seed", type=int)
    p.add_argument("--seed")
    p = sub.add_parser("selfcheck")
    p.add_argument("solver")
    p.add_argument("--family", required=True)
    p.add_argument("--dim", type=int, required=True)
    p.add_argument("--cap", type=float, default=2000)
    a = ap.parse_args(argv)
    return {"practice": cmd_practice, "verify": cmd_verify, "selfcheck": cmd_selfcheck}[a.cmd](a)


if __name__ == "__main__":
    main()
