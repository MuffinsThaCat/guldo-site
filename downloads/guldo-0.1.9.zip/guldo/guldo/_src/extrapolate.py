"""Turn two ladders (baseline, submission) into conservative, falsifiable speedup claims. Prints, in order of authority:

1. MEASURED claim (THE CREDIT, difficulty-stratified): instances are grouped by how hard the BASELINE found them (octaves of
   its cost from 0.5 s); pool the paired log2 speedup of the 3 hardest usable bins; report a one-sided 95% joint-bootstrap lower
   bound. No model, no extrapolation. See measured_by_difficulty().
2. hard-pool claim (exploratory): every instance the baseline solved at >= 4 s, plain bootstrap.
3. dimension-pooled claim (informational, the older credit) and
4. EXTRAPOLATED claim (information only): four growth models (constant, linear, power-law, log-decay) fit to per-dimension
   medians, each tested out-of-sample on the largest dimension; the minimum over surviving models, capped at 2x the largest
   measured speedup. Statistically weak at realistic noise; never the credit.

Refuses (exit 1) to compare ladders that differ in seed commitment, instance version/family, budget, sandbox, image, --jobs,
CPU, or that do not cover exactly the same instances (a truncated run would otherwise give a credit on a biased subset).
"""
import argparse
import json
import math
import random
import statistics
from collections import defaultdict

import numpy as np

TOL = 1.0  # bits of out-of-sample prediction error tolerated


def load(path):
    meta, by_dim = None, defaultdict(dict)
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            if r.get("meta"):
                meta = r
            else:
                by_dim[r["dim"]][r["id"]] = r
    return meta, by_dim


CENSOR_MAX = 0.5  # drop a dimension if more than this fraction of BASELINE instances timed out
CAP = 2.0  # credited bits never exceed CAP x the largest speedup actually measured


def coverage_mismatch(base, sub):
    """(ids only in the baseline, ids only in the submission) for two {dim: {id: record}} ladders. Both empty = the ladders
    cover exactly the same instances. A truncated or mismatched pair must never be turned into a credit."""
    ids_b = {(d, i) for d in base for i in base[d]}
    ids_s = {(d, i) for d in sub for i in sub[d]}
    return ids_b - ids_s, ids_s - ids_b


def per_dim_times(by_dim, budget):
    """CPU time per instance; failures are censored at the budget (they count against the solver)."""
    times, cens = {}, {}
    for d, recs in by_dim.items():
        times[d] = {i: (r["cpu_net"] if r["status"] == "solved" else budget) for i, r in recs.items()}
        cens[d] = {i: r["status"] != "solved" for i, r in recs.items()}
    return times, cens


FLOOR_ABS = 0.5  # seconds. A dimension counts only if BOTH solvers' median cost is at least this

def usable_dims(bc, sc, tb, ts):
    """Drop dimensions where (a) the BASELINE timed out on too many instances (its cost there is unmeasured), or (b)
    either solver costs less than FLOOR_ABS.
    (a) is deliberately one-sided. Dropping a dimension because the SUBMISSION failed there would remove its failures
    from the claim: a solver that fails every large instance would earn the same credit as one that solves them (this was
    a real defect). Submission failures stay in, costing the budget, which pulls the pooled speedup down.
    (b) is the fixed-cost guard: interpreter/import/setup costs (harness ~0.1 s, a solver loading its tables ~0.1 s)
    fade as work grows and would otherwise masquerade as a speedup that grows with n. The floor is absolute, not
    relative to the solver's cheapest point, so a genuinely very fast solver is not penalized for being fast."""
    common = sorted(d for d in set(bc) & set(sc) if set(bc[d]) & set(sc[d]))
    ok, dropped = [], {}
    for d in common:
        ids = sorted(set(bc[d]) & set(sc[d]))
        frac = sum(bc[d][i] for i in ids) / len(ids)
        cheapest = min(statistics.median(tb[d].values()), statistics.median(ts[d].values()))
        if frac > CENSOR_MAX:
            dropped[d] = f"baseline timeouts {frac:.2f}"
        elif cheapest < FLOOR_ABS:
            dropped[d] = f"cost {cheapest:.3f}s < {FLOOR_ABS:g}s floor"
        else:
            ok.append(d)
    return ok, dropped


def speedup_table(base, sub, dims, rng=None):
    """Paired: median over instances of log2(baseline cost / submission cost) on the SAME instance."""
    s = {}
    for d in dims:
        ids = sorted(set(base[d]) & set(sub[d]))
        if not ids:
            continue
        if rng:
            ids = [rng.choice(ids) for _ in ids]
        s[d] = statistics.median(math.log2(base[d][i] / sub[d][i]) for i in ids)
    return s


def fit(model, ns, ss):
    ns, ss = np.array(ns, float), np.array(ss, float)
    if model == "constant":
        a = ss.mean()
        return lambda n: a
    if model == "linear":
        b, a = np.polyfit(ns, ss, 1)
        return lambda n: a + b * n
    if model == "logdecay":
        b, a = np.polyfit(np.log(ns), ss, 1)
        return lambda n: a + b * math.log(n)
    if model == "power":
        if (ss <= 0).any():
            return None
        b, la = np.polyfit(np.log(ns), np.log(ss), 1)
        return lambda n: math.exp(la) * n ** b
    raise ValueError(model)


MODELS = ["constant", "linear", "power", "logdecay"]


def credited(s, target):
    ds = sorted(s)
    verdict = {}
    for m in MODELS:
        if len(ds) < 4:
            verdict[m] = {"status": "too few dimensions"}
            continue
        f_in = fit(m, ds[:-1], [s[d] for d in ds[:-1]])
        if f_in is None:
            verdict[m] = {"status": "unfittable"}
            continue
        err = f_in(ds[-1]) - s[ds[-1]]
        f_all = fit(m, ds, [s[d] for d in ds])
        verdict[m] = {"holdout_err_bits": round(err, 2), "status": "ok" if abs(err) <= TOL else "rejected",
                      "at_target": round(f_all(target), 2) if f_all else None}
    ok = [v["at_target"] for v in verdict.values() if v["status"] == "ok" and v["at_target"] is not None]
    if not ok:
        return verdict, None
    return verdict, min(min(ok), CAP * max(s.values()))


TOP_K = 3  # the measured claim pools the K largest usable dimensions


def measured_lower(base, sub, dims, rng, boot=400, pct=5):
    """Tier 1, no extrapolation: pooled paired speedup over the largest usable dimensions, with a one-sided bootstrap
    lower bound (resampling instances within each dimension). Needs >= 2 usable dimensions."""
    top = sorted(dims)[-TOP_K:]
    if len(top) < 2:
        return None, top

    def stat(resample):
        vals = []
        for d in top:
            ids = sorted(set(base[d]) & set(sub[d]))
            if resample:
                ids = [rng.choice(ids) for _ in ids]
            vals += [math.log2(base[d][i] / sub[d][i]) for i in ids]
        return statistics.median(vals)

    return (stat(False), float(np.percentile([stat(True) for _ in range(boot)], pct))), top


MIN_BIN = 5  # instances needed in a difficulty bin for it to count


def difficulty_bins(tb, ts, bc):
    """Group instances by how hard the BASELINE found them: octaves of baseline cost starting at the 0.5 s floor.
    Selection depends on the reference solver only, so it cannot bias the submission's side, and it is immune to the
    non-monotone, heavy-tailed cost-vs-dimension behaviour that made dimension-based selection erratic. Instances where
    the baseline timed out are excluded (their true cost is unknown: conservative); submission failures stay in at the
    budget cost. Returns {octave index: [(baseline cost, submission cost), ...]}."""
    bins = {}
    for d in tb:
        for i, cb in tb[d].items():
            if i in ts.get(d, {}) and not bc[d][i] and cb >= FLOOR_ABS:
                bins.setdefault(int(math.floor(math.log2(cb / FLOOR_ABS))), []).append((cb, ts[d][i]))
    return bins


def _group(points):
    """[(baseline cost, submission cost)] -> {octave index: [points]} (octaves of baseline cost above the floor)."""
    bins = {}
    for cb, cs in points:
        bins.setdefault(int(math.floor(math.log2(cb / FLOOR_ABS))), []).append((cb, cs))
    return bins


def _usable_top(bins):
    info = {k: {"lo": FLOOR_ABS * 2 ** k, "hi": FLOOR_ABS * 2 ** (k + 1), "n": len(v),
                "median_sub_cost": round(statistics.median(c for _, c in v), 3),
                "median_bits": round(statistics.median(math.log2(b / c) for b, c in v), 2),
                "usable": len(v) >= MIN_BIN and statistics.median(c for _, c in v) >= FLOOR_ABS}
            for k, v in bins.items()}
    return info, sorted(k for k, x in info.items() if x["usable"])[-TOP_K:]


def _pooled_median(bins, top):
    return statistics.median(math.log2(b / c) for k in top for b, c in bins[k])


def measured_by_difficulty(tb, ts, bc, rng, boot=400, pct=5):
    """Tier 1 (THE credit). Pooled median of the paired log2 speedup over the TOP_K hardest usable bins, with a one-sided
    JOINT bootstrap lower bound: each resample redraws instances from the whole eligible pool and RE-SELECTS which bins are
    usable and hardest, so the uncertainty of that selection is inside the bound (a resample with < 2 usable bins counts as 0
    bits). A bin is usable when it holds >= MIN_BIN instances and the submission's median cost there is >= FLOOR_ABS
    (fixed-cost guard). Needs >= 2 usable bins in the real data. (The earlier version resampled within fixed bins; by
    simulation its bound exceeded the truth 5-9% of the time instead of <= 5%.)"""
    pts = [p for k in difficulty_bins(tb, ts, bc).values() for p in k]
    bins = _group(pts)
    info, top = _usable_top(bins)
    if len(top) < 2:
        return None, top, info

    def resampled():
        b2 = _group([rng.choice(pts) for _ in pts])
        _, t2 = _usable_top(b2)
        return _pooled_median(b2, t2) if len(t2) >= 2 else 0.0

    return (_pooled_median(bins, top), float(np.percentile([resampled() for _ in range(boot)], pct))), top, info


HARD_POOL_MIN_COST = 4.0  # seconds of baseline cost; fixed in advance (8 x the 0.5 s floor), never tuned to data
HARD_POOL_MIN_N = 12


def hard_pool_claim(tb, ts, bc, rng, boot=400, pct=5):
    """EXPLORATORY second claim with no selection step at all: pool every instance the baseline solved at a cost >=
    HARD_POOL_MIN_COST and report the one-sided bootstrap lower bound of the median paired log2 speedup. Inconclusive if
    there are < HARD_POOL_MIN_N such instances or the submission's median cost on them is under the 0.5 s floor.
    Returns ((median, lower bound) or None, n, median submission cost)."""
    pts = [(cb, ts[d][i]) for d in tb for i, cb in tb[d].items()
           if i in ts.get(d, {}) and not bc[d][i] and cb >= HARD_POOL_MIN_COST]
    if len(pts) < HARD_POOL_MIN_N:
        return None, len(pts), None
    med_sub = statistics.median(c for _, c in pts)
    if med_sub < FLOOR_ABS:
        return None, len(pts), med_sub
    vals = [math.log2(b / c) for b, c in pts]
    boots = [statistics.median(rng.choice(vals) for _ in vals) for _ in range(boot)]
    return (statistics.median(vals), float(np.percentile(boots, pct))), len(pts), med_sub


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", required=True)
    ap.add_argument("--submission", required=True)
    ap.add_argument("--target-dim", type=int, default=512)
    ap.add_argument("--boot", type=int, default=300)
    a = ap.parse_args()
    mb, base = load(a.baseline)
    ms, sub = load(a.submission)
    if mb["commit"] != ms["commit"]:
        raise SystemExit("REFUSED: ladders were run on different instance sets (commitments differ)")
    if mb.get("family", "gm") != ms.get("family", "gm") or mb.get("sandbox") != ms.get("sandbox"):
        raise SystemExit("REFUSED: ladders differ in instance family or sandbox mode")
    if mb.get("instance_version") != ms.get("instance_version") or mb.get("instance_version") is None:
        raise SystemExit("REFUSED: ladders have different (or missing) instance_version: same seed, different "
                         "instances. Re-run both ladders with the current harness.")
    if mb["budget"] != ms["budget"]:
        raise SystemExit("REFUSED: ladders ran with different CPU budgets (censoring would not be comparable)")
    if mb.get("image") != ms.get("image"):
        raise SystemExit("REFUSED: ladders ran in different sandbox images")
    if mb.get("jobs", 1) != ms.get("jobs", 1):  # a uniform concurrency slowdown cancels in the ratio only if shared
        raise SystemExit("REFUSED: ladders ran with different --jobs (concurrency changes absolute timings)")
    if mb.get("cpu") != ms.get("cpu"):  # both absent (older files) compare equal; one absent is a mismatch
        raise SystemExit(f"REFUSED: ladders ran on different CPUs ({mb.get('cpu')!r} vs {ms.get('cpu')!r}); cost "
                         "ratios across machines are meaningless")
    only_b, only_s = coverage_mismatch(base, sub)
    if only_b or only_s:
        raise SystemExit(f"REFUSED: the ladders do not cover the same instances ({len(only_b)} only in the baseline, "
                         f"{len(only_s)} only in the submission): a truncated or mismatched run would give a credit computed "
                         "on a biased subset (typically the early, easier instances)")
    budget = mb["budget"]
    (tb, bc), (ts, sc) = per_dim_times(base, budget), per_dim_times(sub, budget)
    dims, dropped = usable_dims(bc, sc, tb, ts)
    if dropped:
        print(f"dimensions dropped from fitting: {dropped}")
    s = speedup_table(tb, ts, dims)
    verdict, point = credited(s, a.target_dim)
    boots = []
    rng = random.Random(0)
    for _ in range(a.boot):
        _, p = credited(speedup_table(tb, ts, dims, rng), a.target_dim)
        boots.append(p)
    lo = float(np.percentile([b if b is not None else 0.0 for b in boots], 5))  # a resample with no surviving model earns 0
    solved = {d: sum(r["status"] == "solved" for r in sub[d].values()) for d in sorted(sub)}
    wrong = sum(r["status"] == "wrong" for d in sub for r in sub[d].values())
    print(f"submission={ms['solver']}  baseline={mb['solver']}  commit={ms['commit'][:12]}")
    print("measured speedup (bits) per dim:", {d: round(v, 2) for d, v in s.items()})
    print("submission solved per dim:", solved, f" wrong answers: {wrong}")
    for m, v in verdict.items():
        print(f"  {m:9s} " + str({k: (float(x) if hasattr(x, 'item') else x) for k, x in v.items()}))
    dmeas, dtop = measured_lower(tb, ts, dims, random.Random(1))
    dim_bits = None if dmeas is None else max(0.0, dmeas[1])
    print("dimension-pooled claim (informational): " + ("INCONCLUSIVE" if dim_bits is None else
          f">= {dim_bits:.1f} bits over dims {dtop} (median {dmeas[0]:.1f})"))
    meas, top, info = measured_by_difficulty(tb, ts, bc, random.Random(1))
    print("difficulty bins (baseline cost octave): " + "; ".join(
        f"[{x['lo']:g},{x['hi']:g})s n={x['n']} sub-median {x['median_sub_cost']}s {x['median_bits']:+} bits"
        f"{'' if x['usable'] else ' (unusable)'}" for _, x in sorted(info.items())))
    if meas is None:
        print(f"MEASURED claim (credit): INCONCLUSIVE (needs >= 2 usable difficulty bins; usable: {top})")
        measured_bits = None
    else:
        measured_bits = max(0.0, meas[1])
        spans = [f"[{info[k]['lo']:g},{info[k]['hi']:g})s" for k in top]
        print(f"MEASURED claim (credit): >= {measured_bits:.1f} bits pooled over the hardest usable baseline-cost bins "
              f"{', '.join(spans)} (median {meas[0]:.1f}, one-sided 95% lower bound {meas[1]:.1f}); no extrapolation")
    hp, hp_n, hp_sub = hard_pool_claim(tb, ts, bc, random.Random(1))
    print(f"hard-pool claim (EXPLORATORY, baseline cost >= {HARD_POOL_MIN_COST:g}s, n={hp_n}): " + (
        f"INCONCLUSIVE (needs >= {HARD_POOL_MIN_N} instances and submission median cost >= {FLOOR_ABS:g}s; got median "
        f"{hp_sub if hp_sub is None else round(hp_sub, 2)})" if hp is None else
        f">= {max(0.0, hp[1]):.1f} bits (median {hp[0]:.1f}, submission median cost {hp_sub:.2f}s)"))
    if point is None or lo is None:
        print(f"EXTRAPOLATED @ n={a.target_dim}: INCONCLUSIVE (no model survived out-of-sample + bootstrap)")
    else:
        print(f"EXTRAPOLATED @ n={a.target_dim} (model-dependent, not credit): >= {max(0.0, min(point, lo)):.1f} bits "
              f"(min over surviving models {point:.1f}; bootstrap p5 {lo:.1f})")
    json.dump({"measured": measured_bits, "measured_bins": [[info[k]["lo"], info[k]["hi"]] for k in top],
               "hard_pool": None if hp is None else {"median": hp[0], "lower": hp[1], "n": hp_n},
               "measured_by_dim": dim_bits, "measured_dims": dtop, "s": s, "dropped": dropped, "verdict": {m: {k: (float(x) if hasattr(x, "item") else x) for k, x in v.items()} for m, v in verdict.items()}, "point": point, "p5": lo}, open(a.submission + ".claim.json", "w"), indent=1)


if __name__ == "__main__":
    main()
