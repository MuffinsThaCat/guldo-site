"""A public, append-only, witnessed LOG of agent-evaluation certificates: findable, permanent, ordered. A separate log from translog.py (which is pinned and strict about its leaf kinds), built on
the same tested Merkle primitives (RFC 9162 trees, inclusion and consistency proofs; translog.Tree / verify_inclusion / verify_consistency, imported read-only) and on agent_sig for signatures.

  python3 agent_log.py init LOGDIR --origin NAME
  python3 agent_log.py add LOGDIR CERT.json --round-base DIR [--allow-practice] [--proxy-log LOG --proxy-trusted KEYS]
                                                                                        admit a certificate ONLY if every check of agent_cert.verify_certificate passes against its round
                                                                                        (one that claims a proxy attestation needs --proxy-log and the proxy keys YOU pinned)
  python3 agent_log.py checkpoint LOGDIR --key K                                       sign the current tree head
  python3 agent_log.py prove LOGDIR INDEX --out PROOF.json                             an inclusion proof for one entry, against the latest signed checkpoint
  python3 agent_log.py verify-proof PROOF.json --trusted KEYS                          offline: entry is in a tree whose root a pinned key signed
  python3 agent_log.py check LOGDIR --trusted KEYS [--remember FILE]                   the log is internally consistent, every checkpoint matches, and (with --remember) only grew since you last looked
  python3 agent_log.py cosign LOGDIR --key K --remember FILE --out COSIG.json          a witness: check the log only grew since the last head you saw, then co-sign the latest checkpoint
  python3 agent_log.py check-cosigs LOGDIR COSIG... --trusted KEYS [--min N]           how many pinned witnesses vouch for the latest checkpoint

What it gives. (1) A certificate in the log has an INCLUSION PROOF a reader checks offline against a signed head. (2) The log can only grow: a CONSISTENCY check between two heads, which a reader who kept
the earlier head (`--remember`) runs, catches a rewrite even when the rewritten file is self-consistent. (3) Witnesses you pinned co-sign heads, so one operator cannot show different histories to
different readers without two signed heads that are not consistent: transferable proof. What it does NOT give: that a certificate's claim is true in the world (the log admits only certificates that
RECOMPUTE from their round's files, which shows internal correctness, not that a model produced the trajectories); that anything absent from the log does not exist (absence means 'not submitted');
and nothing at all unless readers keep heads and pin witness keys: a log nobody watches proves little.
"""
import argparse
import json
import os
import shutil
import sys
import time

import agent_core
import agent_sig
import translog
from agent_core import canon, sha256_hex

LOG_FORMAT = "guldo-agent-log-v1"
CHECKPOINT_FORMAT = "guldo-agent-log-checkpoint-v1"
COSIG_FORMAT = "guldo-agent-log-cosig-v1"
ENTRY_VERSION = 1
MAX_CERT_BYTES = 512 * 1024


class LogError(Exception):
    pass


def _paths(d):
    return {"meta": os.path.join(d, "log.json"), "entries": os.path.join(d, "entries.jsonl"), "checkpoints": os.path.join(d, "checkpoints.jsonl"), "certs": os.path.join(d, "certs"), "proxy_logs": os.path.join(d, "proxy_logs")}


def init(d, origin):
    if os.path.exists(_paths(d)["meta"]):
        raise LogError("%s already holds a log" % d)
    if not isinstance(origin, str) or not 1 <= len(origin) <= 80 or any(ord(c) < 32 for c in origin):
        raise LogError("the origin is a short printable name")
    os.makedirs(_paths(d)["certs"], exist_ok=True)
    with open(_paths(d)["meta"], "w", encoding="utf-8") as f:
        f.write(canon({"format": LOG_FORMAT, "origin": origin}) + "\n")
    for k in ("entries", "checkpoints"):
        open(_paths(d)[k], "a").close()


def _jsonl(path):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        try:
            rows = [json.loads(ln) for ln in f.read().split("\n") if ln.strip()]
        except ValueError:
            raise LogError("%s is not JSON lines" % path)
    if not all(isinstance(r, dict) for r in rows):
        raise LogError("%s holds a line that is not an object" % path)
    return rows


def origin(d):
    try:
        with open(_paths(d)["meta"], "r", encoding="utf-8") as f:
            m = json.loads(f.read())
        if not isinstance(m, dict) or m.get("format") != LOG_FORMAT or not isinstance(m.get("origin"), str):
            raise ValueError
        return m["origin"]
    except (OSError, ValueError, KeyError):
        raise LogError("%s is not an agent log (run `init`)" % d)


def entries(d):
    return _jsonl(_paths(d)["entries"])


def leaf(entry):
    return translog.leaf_hash(canon(entry).encode("utf-8"))


def tree(d):
    return translog.Tree([leaf(e) for e in entries(d)])


def _body(doc):
    """The certificate statement itself (a signed certificate wraps it with a key and signature)."""
    if isinstance(doc, dict) and "statement" in doc and "signature" in doc and isinstance(doc["statement"], dict):
        return {k: v for k, v in doc["statement"].items() if k != "pubkey"}, doc["statement"].get("pubkey")
    return doc, None


def build_entry(seq, doc, now=None):
    cert, signer = _body(doc)
    if not isinstance(cert, dict) or cert.get("format") != "guldo-agent-certificate-v1":
        raise LogError("not a guldo-agent-certificate-v1 document")
    try:
        return {"v": ENTRY_VERSION, "seq": seq, "logged": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "kind": "agent-certificate", "cert_sha256": sha256_hex(canon(doc)),
                "round_id": cert["round"]["id"], "domain": cert["round"]["domain"], "plan_hash": cert["round"]["plan_hash"], "commitment": cert["round"]["commitment"],
                "practice": bool(cert["round"]["practice"]), "round_log_head": cert["round"]["log_head"], "candidate_label": cert["candidate"]["label"], "handle": cert["candidate"]["handle"],
                "claims": [{"text": str(c["text"])[:300], "confirmed": bool(c["confirmed"])} for c in cert["claims"]][:10], "signed_by": signer,
                # derived from the certificate alone (so `check` can rebuild it): does it CLAIM that a recording proxy attested every model call, and with which proxy keys and log hash?
                # `admit` records such an entry only after re-checking the claim against a proxy log and keys the LOG'S OPERATOR pinned.
                "attested": isinstance(cert.get("attestation"), dict),
                "attestation_proxy_keys": sorted(str(k) for k in cert["attestation"].get("proxy_keys", [])) if isinstance(cert.get("attestation"), dict) else [],
                "attestation_proxy_log_sha256": cert["attestation"].get("proxy_log_sha256") if isinstance(cert.get("attestation"), dict) else None}
    except (KeyError, TypeError, AttributeError) as e:
        raise LogError("the certificate lacks a field the log records (%s)" % e)


def admit(d, doc, round_base, allow_practice=False, now=None, proxy_log=None, proxy_trusted=None):
    """Verify the certificate against its round (every check of agent_cert.verify_certificate), then append it. Returns the entry.
    A certificate that CLAIMS an attestation (a recording proxy signed every model call) is admitted only with `proxy_log` (the proxy's log file) and `proxy_trusted` (the proxy public keys, hex,
    that the LOG'S OPERATOR pinned out of band): the whole round is re-attested against them first, and a copy of the proxy log is kept next to the certificate so the claim stays checkable. An
    attestation-claiming certificate without them is REFUSED, not logged as if it were unattested."""
    import agent_cert
    import agent_rounds as AR
    origin(d)
    raw = canon(doc)
    if len(raw) > MAX_CERT_BYTES:
        raise LogError("the certificate is larger than %d bytes" % MAX_CERT_BYTES)
    cert, _ = _body(doc)
    entry_probe = build_entry(0, doc, now)
    if entry_probe["practice"] and not allow_practice:
        raise LogError("a practice-seed certificate shows the method only: refused (pass allow_practice to log a demonstration)")
    if any(e["cert_sha256"] == entry_probe["cert_sha256"] for e in entries(d)):
        raise LogError("this certificate is already in the log")
    if entry_probe["attested"] and not (proxy_log and proxy_trusted):
        raise LogError("this certificate claims that a recording proxy attested every model call: give the proxy log and the proxy public key(s) YOU pinned (proxy_log, proxy_trusted); it is not logged as if it were unattested")
    if not entry_probe["attested"] and (proxy_log or proxy_trusted):
        raise LogError("a proxy log was given but the certificate claims no attestation: refusing rather than implying an attestation that is not there")
    try:
        rid, eid = cert["round"]["id"], cert["candidate"]["eid"]
        rd = AR.rdir(round_base, rid)
        master = AR._revealed_master(rd)
        rows = agent_cert.verify_certificate(doc, os.path.join(rd, "ladders", "baseline.jsonl"), os.path.join(rd, "ladders", str(eid) + ".jsonl"), master, round_base=round_base,
                                             proxy_log=proxy_log, proxy_trusted=set(proxy_trusted) if proxy_trusted else None)
    except (AR.Rejected, KeyError, TypeError, AttributeError, ValueError, OSError, agent_core.AgentEvalError) as e:
        raise LogError("the certificate's round could not be opened here (%s: %s): refusing to log it" % (type(e).__name__, str(e)[:100]))
    failed = [n for n, ok, _d in rows if not ok]
    if failed:
        raise LogError("the certificate does not recompute from its round (%d failed checks, first: %s): refusing to log it" % (len(failed), failed[0]))
    entry = build_entry(len(entries(d)), doc, now)
    with open(_paths(d)["entries"], "a", encoding="utf-8") as f:
        f.write(canon(entry) + "\n")
    with open(os.path.join(_paths(d)["certs"], entry["cert_sha256"] + ".json"), "w", encoding="utf-8") as f:
        f.write(raw)
    if entry["attested"]:                                   # keep the proxy log that attested it, named by its own hash, so the claim stays checkable from this directory
        os.makedirs(_paths(d)["proxy_logs"], exist_ok=True)
        shutil.copyfile(proxy_log, os.path.join(_paths(d)["proxy_logs"], entry["attestation_proxy_log_sha256"] + ".jsonl"))
    return entry


def checkpoint_statement(d, now=None):
    t = tree(d)
    return {"format": CHECKPOINT_FORMAT, "origin": origin(d), "size": len(t), "root": t.root().hex(), "at": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}


def checkpoint(d, secret, now=None):
    """Sign the current tree head and append it to checkpoints.jsonl."""
    signed = agent_sig.sign_statement(checkpoint_statement(d, now), secret)
    with open(_paths(d)["checkpoints"], "a", encoding="utf-8") as f:
        f.write(canon(signed) + "\n")
    return signed


def checkpoints(d):
    return _jsonl(_paths(d)["checkpoints"])


def prove(d, index):
    es = entries(d)
    cps = checkpoints(d)
    if not cps:
        raise LogError("no signed checkpoint yet: run `checkpoint`")
    cp = cps[-1]
    st = cp.get("statement") if isinstance(cp, dict) else None
    if not isinstance(st, dict) or not isinstance(st.get("size"), int) or isinstance(st.get("size"), bool):
        raise LogError("the latest checkpoint is malformed")
    size = st["size"]
    if not (isinstance(index, int) and not isinstance(index, bool) and 0 <= index < size <= len(es)):
        raise LogError("entry %s is not covered by the latest checkpoint (size %d)" % (index, size))
    t = translog.Tree([leaf(e) for e in es[:size]])
    return {"format": "guldo-agent-log-proof-v1", "entry": es[index], "index": index, "path": [p.hex() for p in t.inclusion(index, size)], "checkpoint": cp}


def verify_proof(proof, trusted):
    """(ok, message). Offline: the entry is in a tree whose root a key you pinned signed."""
    try:
        if proof.get("format") != "guldo-agent-log-proof-v1":
            return False, "not an agent-log proof"
        cp, st = proof["checkpoint"], proof["checkpoint"]["statement"]
        if st.get("format") != CHECKPOINT_FORMAT or not agent_sig.statement_ok(cp):
            return False, "the checkpoint's signature is bad"
        if st.get("pubkey") not in set(trusted or []):
            return False, "the checkpoint is signed by a key you did not pin"
        ok = translog.verify_inclusion(leaf(proof["entry"]), proof["index"], st["size"], [bytes.fromhex(p) for p in proof["path"]], bytes.fromhex(st["root"]))
        if not ok:
            return False, "the inclusion path does not lead to the signed root"
        if proof["entry"].get("seq") != proof["index"]:
            return False, "the entry's sequence number is not its position"
        return True, "ok: entry %d (%s) is in the tree of size %d signed by %s..." % (proof["index"], proof["entry"].get("candidate_label"), st["size"], st["pubkey"][:12])
    except (KeyError, TypeError, ValueError, AttributeError):
        return False, "the proof is malformed"


def check(d, trusted, remembered=None):
    """(problems, latest checkpoint or None). The log's own files: every entry well-formed and numbered, every stored certificate hashes to its entry, every signed checkpoint matches the tree of its
    size and is signed by a pinned key, consecutive checkpoints are CONSISTENT. With `remembered` (a checkpoint you kept): the log still contains that head."""
    probs = []
    es, cps = entries(d), checkpoints(d)
    t = tree(d)
    for i, e in enumerate(es):
        if e.get("seq") != i or e.get("kind") != "agent-certificate":
            probs.append("entry %d is out of order or of the wrong kind" % i)
        p = os.path.join(_paths(d)["certs"], str(e.get("cert_sha256")) + ".json")
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                try:
                    stored = json.loads(f.read())
                    if sha256_hex(canon(stored)) != e.get("cert_sha256"):
                        probs.append("entry %d: the stored certificate does not hash to the entry" % i)
                    else:
                        # the entry's own fields (label, claims, practice flag, round, signer) must be exactly what its certificate says: an entry edited AFTER the last signed checkpoint is otherwise unnoticed
                        try:
                            if canon(build_entry(i, stored, e.get("logged"))) != canon(e):
                                probs.append("entry %d: its fields do not match its certificate" % i)
                        except LogError:
                            probs.append("entry %d: its stored certificate is not a valid agent certificate" % i)
                except ValueError:
                    probs.append("entry %d: the stored certificate is not JSON" % i)
        else:
            probs.append("entry %d: its certificate file is missing" % i)
    prev = None
    for j, cp in enumerate(cps):
        st = cp.get("statement", {}) if isinstance(cp, dict) else {}
        if not agent_sig.statement_ok(cp) or st.get("format") != CHECKPOINT_FORMAT:
            probs.append("checkpoint %d has a bad signature" % j)
            continue
        if st.get("pubkey") not in set(trusted or []):
            probs.append("checkpoint %d is signed by a key you did not pin" % j)
        n = st.get("size")
        if not (isinstance(n, int) and 0 <= n <= len(es)) or t.root(n).hex() != st.get("root"):
            probs.append("checkpoint %d does not match the log's entries (the history was rewritten, or entries removed)" % j)
            continue
        if st.get("origin") != origin(d):
            probs.append("checkpoint %d names another origin" % j)
        if prev is not None and prev[0] <= n and not translog.verify_consistency(prev[0], n, bytes.fromhex(prev[1]), bytes.fromhex(st["root"]), t.consistency(prev[0], n)):
            probs.append("checkpoint %d is not consistent with the one before" % j)
        if prev is not None and n < prev[0]:
            probs.append("checkpoint %d is SMALLER than the one before: the log shrank" % j)
        prev = (n, st["root"])
    if remembered is not None:
        rs = remembered.get("statement", {}) if isinstance(remembered, dict) else {}
        n = rs.get("size")
        if not (agent_sig.statement_ok(remembered) and isinstance(n, int) and 0 <= n <= len(es) and t.root(n).hex() == rs.get("root")):
            probs.append("the log does NOT contain the head you remembered (size %s): it was rewritten or shortened since you looked" % n)
    return probs, (cps[-1] if cps else None)


def cosign(d, secret, remembered=None):
    """A witness co-signs the latest checkpoint, but only after checking the log only grew since the head they last saw."""
    probs, latest = check(d, trusted=_checkpoint_signers(d), remembered=remembered)
    if probs:
        raise LogError("not co-signing: " + "; ".join(probs[:3]))
    if latest is None:
        raise LogError("no checkpoint to co-sign")
    st = latest["statement"]
    return agent_sig.sign_statement({"format": COSIG_FORMAT, "origin": st["origin"], "size": st["size"], "root": st["root"], "checkpoint_signer": st["pubkey"],
                                     "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, secret)


def _checkpoint_signers(d):
    return set(cp["statement"].get("pubkey") for cp in checkpoints(d) if isinstance(cp, dict) and isinstance(cp.get("statement"), dict))


def check_cosigs(d, cosigs, trusted, min_witnesses=1):
    """{ok, witnesses, lines}: how many DISTINCT pinned keys co-signed exactly the latest checkpoint."""
    cps = checkpoints(d)
    if not cps or not isinstance(cps[-1].get("statement"), dict) or not all(k in cps[-1]["statement"] for k in ("size", "root", "origin")):
        return {"ok": False, "witnesses": [], "lines": ["no usable checkpoint"]}
    st = cps[-1]["statement"]
    good, lines = set(), []
    for c in cosigs:
        s = c.get("statement", {}) if isinstance(c, dict) else {}
        if not agent_sig.statement_ok(c) or s.get("format") != COSIG_FORMAT:
            lines.append("a co-signature has a bad signature (ignored)")
        elif (s.get("size"), s.get("root"), s.get("origin")) != (st["size"], st["root"], st["origin"]):
            lines.append("a co-signature from %s... is for a different head (ignored)" % str(s.get("pubkey"))[:12])
        elif s.get("pubkey") in set(trusted or []):
            good.add(s["pubkey"])
        else:
            lines.append("a co-signature from %s... is from a key you did not pin (not counted)" % str(s.get("pubkey"))[:12])
    ok = len(good) >= min_witnesses
    lines.append("%s: %d pinned witness(es) co-signed the head at size %d (%d needed)" % ("OK" if ok else "NOT ENOUGH", len(good), st["size"], min_witnesses))
    return {"ok": ok, "witnesses": sorted(good), "lines": lines}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.add_argument("dir"); p.add_argument("--origin", required=True)
    p = sub.add_parser("add"); p.add_argument("dir"); p.add_argument("cert"); p.add_argument("--round-base", required=True); p.add_argument("--allow-practice", action="store_true")
    p.add_argument("--proxy-log", help="the recording proxy's log: REQUIRED when the certificate claims an attestation"); p.add_argument("--proxy-trusted", help="file of the proxy public keys YOU pinned (one hex per line): REQUIRED with --proxy-log")
    p = sub.add_parser("checkpoint"); p.add_argument("dir"); p.add_argument("--key", required=True)
    p = sub.add_parser("prove"); p.add_argument("dir"); p.add_argument("index", type=int); p.add_argument("--out")
    p = sub.add_parser("verify-proof"); p.add_argument("proof"); p.add_argument("--trusted", required=True)
    p = sub.add_parser("check"); p.add_argument("dir"); p.add_argument("--trusted", required=True); p.add_argument("--remember")
    p = sub.add_parser("cosign"); p.add_argument("dir"); p.add_argument("--key", required=True); p.add_argument("--remember"); p.add_argument("--out")
    p = sub.add_parser("check-cosigs"); p.add_argument("dir"); p.add_argument("cosigs", nargs="+"); p.add_argument("--trusted", required=True); p.add_argument("--min", type=int, default=1)
    a = ap.parse_args(argv)

    def load(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    try:
        if a.cmd == "init":
            init(a.dir, a.origin)
            print("initialised %s" % a.dir)
        elif a.cmd == "add":
            e = admit(a.dir, load(a.cert), a.round_base, a.allow_practice, proxy_log=a.proxy_log, proxy_trusted=agent_sig.read_trusted(a.proxy_trusted) if a.proxy_trusted else None)
            print("logged entry %d (%s, round %s)" % (e["seq"], e["candidate_label"], e["round_id"]))
        elif a.cmd == "checkpoint":
            cp = checkpoint(a.dir, agent_sig.load_secret(a.key))
            print("checkpoint: size %d, root %s" % (cp["statement"]["size"], cp["statement"]["root"]))
        elif a.cmd == "prove":
            text = json.dumps(prove(a.dir, a.index), indent=1, sort_keys=True) + "\n"
            if a.out:
                with open(a.out, "w", encoding="utf-8") as f:
                    f.write(text)
                print("wrote " + a.out)
            else:
                print(text)
        elif a.cmd == "verify-proof":
            ok, msg = verify_proof(load(a.proof), agent_sig.read_trusted(a.trusted))
            print(("OK: " if ok else "FAIL: ") + msg)
            return 0 if ok else 1
        elif a.cmd == "check":
            probs, latest = check(a.dir, agent_sig.read_trusted(a.trusted), load(a.remember) if a.remember and os.path.exists(a.remember) else None)
            for p in probs:
                print("FAIL: " + p)
            if not probs and latest is not None:
                if a.remember:
                    with open(a.remember, "w", encoding="utf-8") as f:
                        f.write(json.dumps(latest, sort_keys=True) + "\n")
                print("OK: %d entries, latest checkpoint size %d%s" % (len(entries(a.dir)), latest["statement"]["size"], " (remembered for next time)" if a.remember else ""))
            elif not probs:
                print("OK: %d entries, no signed checkpoint yet" % len(entries(a.dir)))
            return 0 if not probs else 1
        elif a.cmd == "cosign":
            st = cosign(a.dir, agent_sig.load_secret(a.key), load(a.remember) if a.remember and os.path.exists(a.remember) else None)
            text = json.dumps(st, indent=1, sort_keys=True) + "\n"
            if a.out:
                with open(a.out, "w", encoding="utf-8") as f:
                    f.write(text)
            print("co-signed the head at size %d%s" % (st["statement"]["size"], (" -> " + a.out) if a.out else "\n" + text))
        elif a.cmd == "check-cosigs":
            res = check_cosigs(a.dir, [load(p) for p in a.cosigs], agent_sig.read_trusted(a.trusted), a.min)
            print("\n".join(res["lines"]))
            return 0 if res["ok"] else 1
    except (LogError, agent_core.AgentEvalError, OSError, ValueError, KeyError, TypeError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
