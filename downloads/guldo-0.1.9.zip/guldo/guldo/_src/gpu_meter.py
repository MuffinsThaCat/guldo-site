"""GPU timing for the speedup protocol: a DEVICE-PINNED, PARENT-TIMED wall-clock meter. Written without a GPU (this machine has none): everything on the parent side is tested
against a fake device and a fake transport (test_gpu_meter.py); the child (gpu_runner.py) and every torch solver are UNRUN until someone runs them on an NVIDIA box.

  python3 gpu_meter.py smoke                                                   FIRST RUN ON A NEW MACHINE: tests each layer on its own (device, idle, child + torch + CUDA, one instance through two solvers)
  python3 gpu_meter.py info                                                    what device, driver, memory; is it idle; is it throttling
  python3 gpu_meter.py plan --family aiinfer --dims 2048 3072 --n 6 --cap 60 --out PLAN.json      fix the ladder in advance; prints the hash to publish
  python3 gpu_meter.py practice SOLVER --baseline REF --family aiinfer --dims 2048 3072 --n 6 --cap 60 [--plan PLAN.json] [--seed SEEDFILE]
  python3 gpu_meter.py claim BASELINE_LADDER SUBMISSION_LADDER                the estimator's credit (extrapolate.py, unchanged)
  python3 gpu_meter.py verify LADDER [--rerun K|all] [--plan PLAN.json --plan-hash HEX]       consistency; --rerun RE-MEASURES records on this very device model

HOW IT MEASURES. One child process per size loads the solver and warms up on PUBLIC instances (never ladder instances). Then, for each ladder instance, the PARENT writes a
request line to the child and reads the reply line, and the time is the elapsed time on the PARENT's own clock between the two (the child brackets the solve with a device
synchronize). The child supplies no timing at all, so it cannot under-report; every timed run is a different instance, so nothing can be cached across repetitions; the answer
must come back, correct, inside the measured interval. One-time setup (imports, module-level work, loading a model) happens before the child says `ready` and is not measured,
exactly as loading weights is not part of an inference time; per-instance work must happen in solve(). Ladders are the ordinary format with `cpu` = the device model + driver, so
extrapolate.py REFUSES to compare ladders from different devices. One run per instance: noise is the estimator's job, as on the CPU path.

WHAT MAKES A MEASUREMENT INVALID (a crash charged the cap, flagged `invalid`, to be re-measured, never silently kept): another process is using the measured GPU; the GPU reported
a hardware or thermal slowdown while the solver ran. Hardware or driver trouble the parent cannot see is not covered.

TRUST: still the weakest evidence in the protocol, and every verdict says so. The parent's clock replaces the child's claim, but the solver runs unsandboxed in a process the
operator started: nothing here proves WHICH device it ran on beyond nvidia-smi, that clocks were not locked or raised, or that nobody tuned the box for one solver. Nobody else can
reproduce a time without the same device model: `verify --rerun` re-measures and agrees only within RERUN_TOLERANCE. A GPU speedup is a claim about one device model, certified
by an operator you trust, not a proof.
"""
import argparse
import json
import os
import queue
import random
import secrets
import shutil
import statistics
import subprocess
import sys
import tempfile
import threading
import time

import instances
import tflops

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(HERE, "gpu_runner.py")
NOOP = os.path.join(HERE, "solvers", "gpu_noop.py")
GPU_INDEX = os.environ.get("SVP_GPU_INDEX", "0")   # the one GPU measured: nvidia-smi is asked about it alone (-i), and the child only sees it (CUDA_VISIBLE_DEVICES)
THROTTLE_BAD = 0x8 | 0x20 | 0x40 | 0x80      # hardware slowdown, software thermal, hardware thermal, hardware power brake: the measurement is not the device's normal speed
THROTTLE_NOTE = 0x4                           # software power cap: routine under load on many data-centre parts, recorded but not fatal
WARM_INSTANCES = 2                            # public warm-up instances run (untimed) per size before the ladder instances
CALIBRATION_CALLS = 5
RERUN_TOLERANCE = 1.3                         # `verify --rerun` accepts a single re-measured run within this factor of the recorded one
POLL_S = 1.0                                  # background throttle sampling while a run is in progress: nvidia-smi queries inside a timed interval are interference, so only 1 Hz (plus a poll just before and just after every run)
GPU_MAX_RSS_MB = 16384                        # host memory a GPU solver may reach: a torch + CUDA process alone holds a few GB resident, so the CPU path's 4 GB would kill honest ones
WARMUP_SEED = b"gpu-warmup-public-seed"       # PUBLIC: warm-up instances come from this seed and are never ladder instances
CLAIM_LIMITS = ("A GPU time is a wall-clock measurement on ONE device model, taken by an operator's process on the operator's clock: nobody else can re-execute it exactly, "
                "the solver runs unsandboxed, clocks, thermal state and other tenants move it, and nothing proves which device ran it beyond nvidia-smi. It supports 'faster on this "
                "device, as measured by this operator', not a proof, and says nothing about other devices.")


class GpuUnavailable(Exception):
    pass


class SessionError(Exception):
    pass


# ----------------------------------------------------------------------------------------------------------------- nvidia-smi and its parsers (pure, tested)
def smi(kind, query):
    """Run nvidia-smi for the measured GPU and return its stdout, or None when it is absent or fails. kind: "gpu" or "compute-apps"."""
    try:
        r = subprocess.run(["nvidia-smi", "-i", GPU_INDEX, f"--query-{kind}={query}", "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.SubprocessError):
        return None
    return r.stdout if r.returncode == 0 else None


def device_info(smi_fn=smi):
    text = smi_fn("gpu", "name,driver_version,memory.total")
    if not text or not text.strip():
        raise GpuUnavailable("nvidia-smi reported no GPU (or is not installed)")
    first = text.strip().splitlines()[0]
    parts = [p.strip() for p in first.split(",")]
    if len(parts) != 3 or not parts[2].replace(".", "").isdigit():
        raise GpuUnavailable(f"could not read nvidia-smi output: {first!r}")
    return {"name": parts[0], "driver": parts[1], "memory_mib": int(float(parts[2]))}


def device_key(info):
    return f"{info['name']} | driver {info['driver']} | {info['memory_mib']} MiB"


def parse_mask(text):
    """The throttle-reason bitmask nvidia-smi prints (hex like 0x0000000000000004, or decimal). None when unreadable."""
    try:
        t = text.strip().splitlines()[0].strip()
        return int(t, 16) if t.lower().startswith("0x") else int(t)
    except (ValueError, IndexError, AttributeError):
        return None


def _compute_app_lines(text):
    return [ln for ln in (text or "").strip().splitlines() if ln.strip() and "no running" not in ln.lower()]


def listed_pids(text):
    """The process ids nvidia-smi lists (csv `pid, used_memory` lines)."""
    out = set()
    for ln in _compute_app_lines(text):
        first = ln.split(",")[0].strip()
        if first.isdigit():
            out.add(int(first))
    return out


def other_gpu_processes(text, ignore_pids=()):
    """How many compute processes are on the GPU besides `ignore_pids` (csv `pid, used_memory` lines; empty or 'No running ...' means none). The measuring child itself holds a CUDA
    context and IS listed, so the caller must pass its pid or every measurement would look contended."""
    ignore = set(ignore_pids or ())
    n = 0
    for ln in _compute_app_lines(text):
        first = ln.split(",")[0].strip()
        if first.isdigit() and int(first) in ignore:
            continue
        n += 1
    return n


def throttle_mask(smi_fn=smi):
    for field in ("clocks_throttle_reasons.active", "clocks_event_reasons.active"):   # the field was renamed in newer drivers
        m = parse_mask(smi_fn("gpu", field) or "")
        if m is not None:
            return m
    return None


class Sampler(threading.Thread):
    """Polls the throttle mask in the background (the parent is a separate process from the solver, so the solver's GIL cannot starve it). take() polls once more and returns
    the union of the bits seen since the previous take, then starts a fresh window: one window per measured instance."""
    def __init__(self, smi_fn, poll=POLL_S):
        super().__init__(daemon=True)
        self.smi_fn, self.poll, self._mask, self._lock, self._stop_evt = smi_fn, poll, 0, threading.Lock(), threading.Event()

    def _add(self, m):
        if m is not None:
            with self._lock:
                self._mask |= m

    def run(self):
        while not self._stop_evt.is_set():
            self._add(throttle_mask(self.smi_fn))
            self._stop_evt.wait(self.poll)

    def take(self):
        self._add(throttle_mask(self.smi_fn))
        with self._lock:
            out, self._mask = self._mask, 0
        return out

    def stop(self):
        self._stop_evt.set()
        self.join(timeout=5)


def invalid_reason(mask, busy):
    """None when the measurement stands; otherwise why it must be re-measured."""
    if busy:
        return f"another process was using the GPU ({busy} compute process(es) present)"
    if mask is not None and mask & THROTTLE_BAD:
        return f"the GPU reported a slowdown while the solver ran (throttle mask {mask:#x})"
    return None


# ----------------------------------------------------------------------------------------------------------------- the child session (parent side)
class ProcTransport:
    """The real transport: a child process spoken to line by line. A reader thread turns its stdout into a queue so the parent can wait with a timeout and keep watching memory."""
    def __init__(self, argv, env, cwd, cleanup_dir=None):
        self._err = tempfile.TemporaryFile()
        self._cleanup_dir = cleanup_dir
        self.p = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self._err, env=env, cwd=cwd)
        self.q = queue.Queue()
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        for line in self.p.stdout:
            line = line.strip()
            if line:
                self.q.put(line)
        self.q.put(b"")                      # end of output

    def send(self, data):
        try:
            self.p.stdin.write(data + b"\n")
            self.p.stdin.flush()
        except (BrokenPipeError, OSError, ValueError):
            raise SessionError("the child is gone (its input pipe is closed)")

    def recv(self, timeout):
        """A reply line (bytes), b"" at the end of the child's output, or None if nothing arrived within `timeout`."""
        try:
            return self.q.get(timeout=timeout)
        except queue.Empty:
            return None

    def rss_mb(self):
        return tflops._rss_mb(self.p.pid)

    def pid(self):
        return self.p.pid

    def stderr_tail(self):
        try:
            self._err.seek(0)
            return self._err.read()[-400:].decode(errors="replace")
        except (OSError, ValueError):
            return ""

    def _close_pipes(self):
        for pipe in (self.p.stdin, self.p.stdout):
            try:
                pipe.close()
            except (OSError, ValueError):
                pass                              # a pipe whose peer is already gone (BrokenPipeError on flush) is closed regardless

    def kill(self):
        try:
            self.p.kill()
            self.p.wait(timeout=10)
        except (OSError, subprocess.SubprocessError):
            pass
        self._close_pipes()

    def close(self):
        try:
            self.p.stdin.write(b'{"op": "quit"}\n')
            self.p.stdin.flush()
            self.p.wait(timeout=5)
        except (OSError, ValueError, subprocess.SubprocessError):
            self.kill()
        finally:
            self._close_pipes()
            if self._cleanup_dir:
                shutil.rmtree(self._cleanup_dir, ignore_errors=True)
            self._err.close()


class Session:
    """One child, one solver, many requests. run() returns the answer AND the time the PARENT saw pass between writing the request and reading the reply."""
    RSS_EVERY_S = 0.5     # resident memory is sampled this often, not at every poll: spawning `ps` inside a timed interval would put host-CPU noise into the measurement

    def __init__(self, transport, clock=time.perf_counter, max_rss_mb=GPU_MAX_RSS_MB, poll=0.05, ready_timeout=900):
        self.t, self.clock, self.max_rss_mb, self.poll, self.ready_timeout = transport, clock, max_rss_mb, poll, ready_timeout
        self._last_rss = None

    def _guard(self, started, limit):
        """None while all is well; "memory" or "timeout" (the child is killed first) when a limit is passed."""
        now = self.clock()
        if self._last_rss is None or now - self._last_rss >= self.RSS_EVERY_S:
            self._last_rss = now
            if self.t.rss_mb() > self.max_rss_mb:
                self.t.kill()
                return "memory"
        if self.clock() - started > limit:
            self.t.kill()
            return "timeout"
        return None

    def wait_ready(self):
        started = self.clock()
        while True:
            line = self.t.recv(self.poll)
            if line is None:
                why = self._guard(started, self.ready_timeout)
                if why:
                    raise SessionError(f"the child was killed before it was ready ({why})")
                continue
            if line == b"":
                raise SessionError("the child exited before it was ready: " + self.t.stderr_tail())
            try:
                msg = json.loads(line)
            except ValueError:
                raise SessionError(f"the child's first line was not JSON: {line[:100]!r}")
            if msg.get("status") != "ready":
                raise SessionError(str(msg.get("err", "the child did not become ready"))[-300:])
            return msg

    def run(self, args, timeout):
        """-> {"status": "ok"|"error"|"dead"|"memory"|"timeout", "elapsed": seconds on the parent's clock, "answer": ..., "err": ...}"""
        t0 = self.clock()
        try:
            self.t.send(json.dumps({"op": "run", "args": args}).encode())
        except SessionError as e:
            return {"status": "dead", "elapsed": 0.0, "err": str(e)}
        while True:
            line = self.t.recv(self.poll)
            if line is not None:
                elapsed = self.clock() - t0               # taken at the moment the reply arrives, before anything is parsed
                if line == b"":
                    return {"status": "dead", "elapsed": elapsed, "err": "the child exited: " + self.t.stderr_tail()}
                try:
                    msg = json.loads(line)
                except ValueError:
                    return {"status": "error", "elapsed": elapsed, "err": f"unparseable reply {line[:100]!r}"}
                if msg.get("status") == "ok":
                    return {"status": "ok", "elapsed": elapsed, "answer": msg.get("answer")}
                return {"status": "error", "elapsed": elapsed, "err": str(msg.get("err", ""))[-1500:]}
            why = self._guard(t0, timeout)
            if why:
                return {"status": why, "elapsed": self.clock() - t0, "err": f"killed: {why} limit"}

    def pid(self):
        """The child's process id (None if the transport has none): needed to tell our own CUDA context from a foreign one in nvidia-smi's list."""
        f = getattr(self.t, "pid", None)
        return f() if callable(f) else None

    def close(self):
        self.t.close()


def child_env():
    """A minimal environment for the solver child, plus exactly the variables a CUDA process needs to find its libraries (a system CUDA install is found through LD_LIBRARY_PATH,
    and torch reads HOME and TMPDIR for its caches). The solver runs with the operator's rights anyway, so nothing here widens what it can do."""
    env = {"PATH": os.environ.get("PATH", ""), "PYTHONHASHSEED": "0", "CUDA_VISIBLE_DEVICES": GPU_INDEX, "OMP_NUM_THREADS": "1",
           "CUBLAS_WORKSPACE_CONFIG": ":4096:8"}        # cuBLAS is only deterministic with this set; the runner asks torch for deterministic algorithms
    for k in ("LD_LIBRARY_PATH", "CUDA_HOME", "CUDA_PATH", "HOME", "TMPDIR", "VIRTUAL_ENV", "CONDA_PREFIX"):
        if os.environ.get(k):
            env[k] = os.environ[k]
    return env


def default_session_factory(solver, max_rss_mb=GPU_MAX_RSS_MB):
    empty = tempfile.mkdtemp(prefix="svp-gpu-")      # an empty working directory: the solver cannot find the judge's files by a relative path
    env = child_env()
    return Session(ProcTransport([sys.executable, "-B", RUNNER, os.path.abspath(solver)], env, empty, cleanup_dir=empty), max_rss_mb=max_rss_mb)


def _open_warm(session_factory, solver, derive, dim, warm, cap):
    """A ready child that has run `warm` public instances of this size. Raises SessionError (and closes the child) if anything fails."""
    s = session_factory(solver)
    try:
        s.wait_ready()
        for i in range(warm):
            r = s.run(derive(WARMUP_SEED, dim, i)["args"], cap)
            if r["status"] != "ok":
                raise SessionError(f"warm-up failed ({r['status']}): {str(r.get('err', ''))[-200:]}")
    except BaseException:
        s.close()
        raise
    return s


def calibrate_call_overhead(session_factory, calls=CALIBRATION_CALLS):
    """The fixed cost of one request through the parent/child pipe plus two device synchronizes, measured on the empty solver. Recorded in the ladder header for transparency; NOT
    subtracted (that keeps every time a conservative one)."""
    s = session_factory(NOOP)
    try:
        s.wait_ready()
        times = []
        for _ in range(calls):
            r = s.run([], 60)
            if r["status"] != "ok":
                raise SessionError(f"calibration failed ({r['status']}): {str(r.get('err', ''))[-200:]}")
            times.append(r["elapsed"])
        return statistics.median(times)
    finally:
        s.close()


# ----------------------------------------------------------------------------------------------------------------- measuring instances
def finish_record(rec, res, busy, mask, verify, inst, cap):
    """Turn one session result into a ladder record. Kept separate from the I/O so every branch is testable."""
    st = res["status"]
    rec["elapsed"] = res.get("elapsed")
    rec["throttle_mask"] = mask
    if st == "timeout":
        rec.update({"status": "timeout", "cpu": cap, "cpu_net": cap, "err": res.get("err", "")})
        return rec
    if st != "ok":
        rec.update({"status": "crash", "cpu": cap, "cpu_net": cap, "err": f"{st}: {res.get('err', '')}"[-1500:]})
        return rec
    why = invalid_reason(mask, busy)
    if why:
        rec.update({"status": "crash", "invalid": True, "cpu": cap, "cpu_net": cap, "err": "measurement invalid: " + why})
        return rec
    elapsed, ans = res["elapsed"], res.get("answer")
    if elapsed > cap:
        rec.update({"status": "timeout", "cpu": cap, "cpu_net": cap})
        return rec
    try:
        ok = bool(verify(inst, ans))
    except Exception as e:     # a verifier that RAISES is the operator's bug, not a wrong answer: say so
        ok = False
        rec["verify_error"] = f"{type(e).__name__}: {str(e)[:200]}"
    if not ok:
        rec.update({"status": "failed" if ans is None else "wrong", "cpu": cap, "cpu_net": cap})
    else:
        rec.update({"status": "solved", "cpu": elapsed, "cpu_net": max(elapsed, 1e-3)})
    return rec


def measure_one(session, inst, verify, cap, info, smi_fn, sampler):
    rec = {"id": inst["id"], "dim": inst["dim"], "device": device_key(info)}
    own = session.pid()
    ignore = {own} if own else set()                 # our own child holds a CUDA context and is listed by nvidia-smi: it is not "another process"
    busy_before = other_gpu_processes(smi_fn("compute-apps", "pid,used_memory"), ignore)
    sampler.take()                                   # a clean throttle window for exactly this run
    res = session.run(inst["args"], cap)
    mask = sampler.take()
    busy = max(busy_before, other_gpu_processes(smi_fn("compute-apps", "pid,used_memory"), ignore))     # a process that arrived DURING the run counts too
    return finish_record(rec, res, busy, mask, verify, inst, cap)


def ladder_header(solver, family, mod, decl_dir, master, cap, info, warm, call_overhead):
    return {"meta": True, "solver": os.path.basename(solver), "commit": instances.commit(master), "overhead": 0.0, "budget": cap, "family": family,
            "sandbox": "gpu-local", "instance_version": mod.VERSION, "image": None, "host": "NVIDIA GPU, parent clock (operator-trusted; see gpu_meter.py)",
            "cpu": device_key(info), "ncpu": 1, "jobs": 1, "solver_sha256": tflops.sha256_file(solver), "cost_model": "gpu_time", "warm": warm,
            "timing": "parent clock around a request/reply; one run per instance; warm-up on public instances", "call_overhead_s": call_overhead,
            "decl_sha256": tflops.sha256_file(os.path.join(decl_dir, "decl.py"))}


def evaluate_ladder(solver, family, master, dims, n, cap, out_path, warm=WARM_INSTANCES, progress=None, smi_fn=smi, session_factory=None):
    session_factory = session_factory or default_session_factory
    if os.path.exists(out_path):
        raise FileExistsError(out_path)
    mod, derive, verify, d = tflops.load_family(family)
    info = device_info(smi_fn)
    call_overhead = calibrate_call_overhead(session_factory)
    fd = os.open(out_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    recs = []
    sampler = Sampler(smi_fn)
    sampler.start()
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps(ladder_header(solver, family, mod, d, master, cap, info, warm, call_overhead)) + "\n")
            for dim in dims:
                session, start_error = None, None
                try:
                    for idx in range(n):
                        inst = derive(master, dim, idx)
                        if session is None:
                            if start_error is None:
                                try:
                                    session = _open_warm(session_factory, solver, derive, dim, warm, cap)
                                except SessionError as e:
                                    start_error = f"could not start: {e}"[-1500:]      # one failed start per size: the rest of the size is charged without waiting out more start-up timeouts
                            if session is None:
                                rec = {"id": inst["id"], "dim": inst["dim"], "device": device_key(info), "status": "crash", "cpu": cap, "cpu_net": cap, "err": start_error}
                                f.write(json.dumps(rec) + "\n")
                                f.flush()
                                recs.append(rec)
                                if progress:
                                    progress(os.path.basename(solver), rec)
                                continue
                        rec = measure_one(session, inst, verify, cap, info, smi_fn, sampler)
                        f.write(json.dumps(rec) + "\n")
                        f.flush()
                        recs.append(rec)
                        if progress:
                            progress(os.path.basename(solver), rec)
                        if rec["status"] in ("timeout", "crash") and not rec.get("invalid"):
                            session.close()          # killed or dead: the next instance gets a fresh, re-warmed child
                            session = None
                finally:
                    if session is not None:
                        session.close()
    finally:
        sampler.stop()
    return recs


def verify_ladder(path, rerun=0, master=None, solver_path=None, sample_seed=None, smi_fn=smi, session_factory=None):
    """-> (ok, [lines]). Consistency of every record; no record flagged invalid; with rerun, K random solved records re-MEASURED once each on this device (same model only), each
    within RERUN_TOLERANCE of the recorded time."""
    session_factory = session_factory or default_session_factory
    lines, ok = [], True
    meta, recs = tflops.read_ladder(path)
    if meta is None or meta.get("cost_model") != "gpu_time":
        return False, [f"FAIL {os.path.basename(path)}: not a gpu_time ladder"]
    cap = meta.get("budget")
    if isinstance(cap, bool) or not isinstance(cap, (int, float)) or cap <= 0 or not isinstance(meta.get("cpu"), str) or "solver_sha256" not in meta:
        return False, [f"FAIL {os.path.basename(path)}: the header lacks a positive budget, a device or a solver hash"]
    if not recs:
        return False, [f"FAIL {os.path.basename(path)}: the ladder holds no records (an empty ladder certifies nothing)"]
    bad = 0
    for r in recs:
        try:
            if r.get("device", meta["cpu"]) != meta["cpu"]:
                bad += 1                          # a record measured on a different device than the ladder claims
            elif r["status"] == "solved":
                if not (isinstance(r["cpu"], (int, float)) and abs(r["cpu_net"] - max(r["cpu"], 1e-3)) < 1e-12 and 0 <= r["cpu"] <= cap):
                    bad += 1
            elif r["cpu_net"] != cap:
                bad += 1
        except (KeyError, TypeError):
            bad += 1
    lines.append(f"{'PASS' if not bad else 'FAIL'} cost model: solved cost = the parent-measured time (floored at 1e-3 s), every other record charged the cap" + (f" ({bad} disagree)" if bad else ""))
    ok = ok and not bad
    invalid = [r.get("id") for r in recs if r.get("invalid")]
    lines.append(f"{'FAIL' if invalid else 'PASS'} no invalid measurements" + (f": {len(invalid)} record(s) flagged invalid ({', '.join(map(str, invalid[:5]))}): re-measure them" if invalid else ""))
    ok = ok and not invalid
    if rerun:
        try:
            now = device_key(device_info(smi_fn))
        except GpuUnavailable as e:
            lines.append(f"SKIP re-measure: {e}")
            return False, lines                       # asked for, not done: not a pass
        if now != meta.get("cpu"):
            lines.append(f"SKIP re-measure: this machine's device is {now!r}, the ladder's is {meta.get('cpu')!r} (a time means nothing on another device)")
            return False, lines
        solver = solver_path or os.path.join(HERE, "solvers", meta["solver"])
        if not os.path.exists(solver) or tflops.sha256_file(solver) != meta["solver_sha256"]:
            lines.append(f"FAIL re-measure: the solver file {meta['solver']} is missing here or differs from the ladder's")
            return False, lines
        mod, derive, verify, d = tflops.load_family(meta["family"])
        if tflops.sha256_file(os.path.join(d, "decl.py")) != meta.get("decl_sha256"):
            lines.append("FAIL re-measure: this checkout's decl.py differs from the ladder's")
            return False, lines
        if instances.commit(master) != meta["commit"]:
            lines.append("SKIP re-measure: the seed given does not match the ladder's commitment")
            return False, lines
        solved = [r for r in recs if r["status"] == "solved"]
        if not solved:
            lines.append("FAIL re-measure: the ladder has no solved record to re-measure")
            return False, lines
        k = len(solved) if rerun == "all" else min(int(rerun), len(solved))
        seed = secrets.randbits(64) if sample_seed is None else sample_seed
        pick = random.Random(seed).sample(solved, k) if k < len(solved) else solved
        lines.append(f"re-measure: {len(pick)} of {len(solved)} solved records, once each (sample seed {seed}); agreement means within a factor of {RERUN_TOLERANCE}, not identical")
        info = device_info(smi_fn)
        warm = meta.get("warm", WARM_INSTANCES)
        agree = 0
        sampler = Sampler(smi_fn)
        sampler.start()
        try:
            for r in pick:
                dim, idx = r["id"].split(":")
                inst = derive(master, int(dim), int(idx))
                try:
                    session = _open_warm(session_factory, solver, derive, int(dim), warm, cap)
                except SessionError as e:
                    lines.append(f"  could not re-measure {r['id']}: {e}")
                    continue
                try:
                    again = measure_one(session, inst, verify, cap, info, smi_fn, sampler)
                finally:
                    session.close()
                if again["status"] == "solved" and 1 / RERUN_TOLERANCE <= again["cpu_net"] / r["cpu_net"] <= RERUN_TOLERANCE:      # cpu_net: floored at 1e-3 s, never zero
                    agree += 1
                else:
                    lines.append(f"  differs at {r['id']}: recorded {r['cpu']:.4f} s, re-measured {again['status']} {again.get('cpu')}")
        finally:
            sampler.stop()
        good = agree == len(pick)
        lines.append(f"{'PASS' if good else 'FAIL'} re-measure: {agree}/{len(pick)} agree")
        ok = ok and good
    return ok, lines


# ----------------------------------------------------------------------------------------------------------------- the first-run smoke test
SMOKE_SOLVERS = (("reference (one sample at a time)", "aiinfer_gpu_ref.py"), ("batched", "aiinfer_gpu_batched.py"))


def smoke(smi_fn=smi, session_factory=None, solvers=None, dim=256, family="aiinfer"):
    """-> (ok, [lines]). Every layer the meter depends on, in order, each reported on its own, so a first run on a real GPU says exactly which layer fails: the device and driver, an idle
    GPU, a child that starts (torch, CUDA, the request/reply pipe), our own process being recognised in nvidia-smi's list, and one real instance through two real solvers with the
    answer verified. It measures one instance each: the times are informational and prove nothing about speed."""
    session_factory = session_factory or default_session_factory
    solvers = solvers or [(label, os.path.join(HERE, "solvers", fn)) for label, fn in SMOKE_SOLVERS]
    lines, state = [], {"ok": True}

    def say(status, text):
        lines.append(f"{status:5s} {text}")
        if status == "FAIL":
            state["ok"] = False
    try:
        info = device_info(smi_fn)
    except GpuUnavailable as e:
        say("FAIL", f"device: {e}")
        return False, lines
    say("PASS", f"device: {device_key(info)} (GPU index {GPU_INDEX})")
    n = other_gpu_processes(smi_fn("compute-apps", "pid,used_memory"))
    say("PASS" if n == 0 else "WARN", f"idle: {n} compute process(es) on the GPU before we start" + ("" if n == 0 else " (a real measurement would be refused while they run)"))
    mask = throttle_mask(smi_fn)
    say("PASS" if mask is None or not mask & THROTTLE_BAD else "WARN", f"throttle mask now: {'unreadable' if mask is None else hex(mask)}")
    try:
        overhead = calibrate_call_overhead(session_factory)
    except SessionError as e:
        say("FAIL", f"child: {e}")
        return False, lines
    say("PASS", f"child: torch and CUDA start, the child says ready, {CALIBRATION_CALLS} empty round trips work; per-call overhead {overhead * 1e3:.2f} ms")
    mod, derive, verify, d = tflops.load_family(family)
    sampler = Sampler(smi_fn)
    sampler.start()
    times = {}
    try:
        for label, path in solvers:
            try:
                session = _open_warm(session_factory, path, derive, dim, WARM_INSTANCES, 60)
            except SessionError as e:
                say("FAIL", f"{label}: could not start or warm up: {e}")
                continue
            try:
                own = session.pid()
                visible = own in listed_pids(smi_fn("compute-apps", "pid,used_memory"))
                say("PASS" if visible else "WARN", f"{label}: our own process {'is' if visible else 'is NOT'} in nvidia-smi's process list"
                    + ("" if visible else " (inside a container the host's PIDs are listed instead: then the busy check cannot exclude our own process; run on the host or with --pid=host)"))
                rec = measure_one(session, derive(instances.PRACTICE_SEED, dim, 0), verify, 60, info, smi_fn, sampler)
            finally:
                session.close()
            if rec["status"] == "solved":
                times[label] = rec["cpu_net"]
                say("PASS", f"{label}: solved and verified correct in {rec['cpu_net'] * 1e3:.1f} ms on the parent's clock")
            else:
                say("FAIL", f"{label}: {rec['status']}: {str(rec.get('err', ''))[:240]}")
    finally:
        sampler.stop()
    if len(times) == len(solvers) and all(t > 0 for t in times.values()):
        a, b = list(times.values())[0], list(times.values())[-1]
        say("INFO", f"one instance at d={dim}: {a / b:.2f}x between the first and last solver (informational only: one run, a tiny size, host-side model generation included)")
    return state["ok"], lines


# ----------------------------------------------------------------------------------------------------------------- command line
def cmd_smoke(a):
    ok, lines = smoke(dim=a.dim)
    print("\n".join(lines))
    print("\nSMOKE TEST " + ("PASSED: every layer works on this machine (this proves the plumbing, not any speedup)" if ok else "FAILED: the first FAIL line above is the layer to fix; send it together with the lines above it"))
    sys.exit(0 if ok else 1)


def cmd_info(a):
    try:
        info = device_info()
    except GpuUnavailable as e:
        sys.exit(f"no usable GPU: {e}")
    busy = other_gpu_processes(smi("compute-apps", "pid,used_memory"))
    mask = throttle_mask()
    print(f"device : {device_key(info)} (GPU index {GPU_INDEX})\nidle   : {'yes' if not busy else f'NO ({busy} compute process(es))'}\nthrottle mask now: {mask if mask is None else hex(mask)} "
          f"({'slowdown active' if mask and mask & THROTTLE_BAD else 'none that invalidates a measurement'})")


def cmd_plan(a):
    master = tflops._master(a)
    try:
        key = device_key(device_info())
    except GpuUnavailable as e:
        sys.exit(f"cannot plan: the plan pins this machine's GPU, and {e}")
    plan = tflops.plan_new("gpu_time", a.family, a.dims, a.n, a.cap, master, {"cpu": key})
    fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)       # never overwrites a plan
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(plan, f, indent=1, sort_keys=True)
    print(f"plan written to {a.out}\nplan hash: {tflops.plan_hash(plan)}\nPublish this hash (somewhere the operator cannot edit) BEFORE any solver is submitted.")


def cmd_practice(a):
    master = tflops._master(a)
    tag = instances.commit(master)[:8]
    if a.plan:
        plan = tflops.load_plan(a.plan)
        if (plan.get("family"), sorted(set(a.dims)), a.n, a.cap, plan.get("commit")) != (a.family, plan.get("dims"), plan.get("n"), plan.get("cap"), instances.commit(master)):
            sys.exit("refused: the dims, n, budget, family or seed on the command line are not the plan's. A planned ladder is run exactly as planned.")
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    paths = []
    for role, solver in (("baseline", a.baseline), ("submission", a.solver)):
        p = os.path.join(HERE, "results", f"gpu_{a.family}_{tag}_{role}_{os.path.basename(solver)}.jsonl")
        try:
            evaluate_ladder(solver, a.family, master, a.dims, a.n, a.cap, p, a.warm,
                            progress=lambda name, rec: print(f"  {name} {rec['id']}: {rec['status']} {rec.get('cpu_net', 0):.4f}s" + (f" INVALID: {rec['err']}" if rec.get("invalid") else ""), flush=True))
        except (GpuUnavailable, SessionError) as e:
            sys.exit(f"cannot measure: {e}")
        paths.append(p)
    print("ladders:\n  " + "\n  ".join(paths) + "\nnext: python3 gpu_meter.py claim " + " ".join(paths))


def cmd_claim(a):
    r = subprocess.run([sys.executable, os.path.join(HERE, "extrapolate.py"), "--baseline", a.baseline, "--submission", a.submission], capture_output=True, text=True, cwd=HERE)
    print(r.stdout + r.stderr)
    if r.returncode:
        sys.exit(r.returncode)
    with open(a.submission + ".claim.json", encoding="utf-8") as f:
        c = json.load(f)
    print(f"credit (difficulty-stratified lower bound): {c.get('measured')} bits\n\nWhat this does NOT show: {CLAIM_LIMITS}")


def cmd_verify(a):
    master = tflops._master(a)
    plan = tflops.load_plan(a.plan) if a.plan else None
    if a.plan_hash and not plan:
        sys.exit("--plan-hash needs --plan")
    allok = True
    for p in a.ladders:
        ok, lines = verify_ladder(p, a.rerun, master, sample_seed=a.sample_seed)
        if plan is not None:
            meta, recs = tflops.read_ladder(p)
            problems = tflops.check_plan(plan, meta or {}, recs, a.plan_hash)
            lines.append(("FAIL plan: " + "; ".join(problems)) if problems else "PASS plan: the ladder is exactly the committed plan" + ("" if a.plan_hash else " (no --plan-hash given: the plan file itself was not checked against a published hash)"))
            ok = ok and not problems
        print(p)
        for ln in lines:
            print("  " + ln)
        allok = allok and ok
    print(("\nVERIFIED (consistent and re-measured on this device as requested)" if a.rerun else "\nCONSISTENT ONLY: nothing was re-measured (use --rerun K or --rerun all on the same device model)") if allok else "\nNOT VERIFIED")
    print("What this does NOT show: " + CLAIM_LIMITS)
    sys.exit(0 if allok else 1)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("info").set_defaults(fn=cmd_info)
    p = sub.add_parser("smoke", help="the first-run test: each layer reported separately")
    p.add_argument("--dim", type=int, default=256)
    p.set_defaults(fn=cmd_smoke)
    p = sub.add_parser("plan")
    p.add_argument("--family", required=True)
    p.add_argument("--dims", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, required=True)
    p.add_argument("--cap", type=float, required=True)
    p.add_argument("--seed")
    p.add_argument("--out", required=True)
    p.set_defaults(fn=cmd_plan)
    p = sub.add_parser("practice")
    p.add_argument("solver")
    p.add_argument("--baseline", required=True)
    p.add_argument("--family", required=True)
    p.add_argument("--dims", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, default=6)
    p.add_argument("--cap", type=float, default=60)
    p.add_argument("--warm", type=int, default=WARM_INSTANCES)
    p.add_argument("--plan")
    p.add_argument("--seed")
    p.set_defaults(fn=cmd_practice)
    p = sub.add_parser("claim")
    p.add_argument("baseline")
    p.add_argument("submission")
    p.set_defaults(fn=cmd_claim)
    p = sub.add_parser("verify")
    p.add_argument("ladders", nargs="+")
    p.add_argument("--rerun", type=lambda s: s if s == "all" else int(s), default=0)
    p.add_argument("--sample-seed", type=int)
    p.add_argument("--plan")
    p.add_argument("--plan-hash")
    p.add_argument("--seed")
    p.set_defaults(fn=cmd_verify)
    a = ap.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
