def solve(q, A, b):
    return sum(b) % 2
