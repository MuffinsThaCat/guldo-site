# guldo

Command-line client and tools for verifiable speedup claims. One command, `guldo`.

    pipx install ./guldo               # or, in a virtual environment: pip install ./guldo
    guldo --help                       # the client: practice, submit, status, verify, certificate, rounds, receipts
    guldo tools                        # the other tools: claims, counted, attest, cert, compile, ops, lint, judge

    guldo lint my_solver.py --family factor
    guldo practice my_solver.py --family factor --count --dims 38 40 42        # prints the plan; add --yes to run it (exact step counting, Python 3.12+)
    guldo verify my.cert.json --rerun all --execute                            # re-execute everything: runs the certificate's solvers, use a throwaway VM
    guldo claims correctness my.cert.json

Needs Python 3.9+ (step counting needs 3.12+) and numpy. `pip install "guldo[attest]"` adds signatures; `[lattice]` adds fpylll for the lattice problems.
Install with pipx or in a virtual environment: some commands write under the package directory.

Nothing in this package is official, and parts of it (step counting, counted rounds, claims) pass their own tests but have not been used in a real round: read
`COMPILER.md` and `SUBMIT.md` in the package (`guldo/_src/`) for what each result does and does not show.
