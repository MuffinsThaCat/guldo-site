"""Factoring baseline: plain trial division over odd candidates in a Python loop. Deterministic; cost ~ the smaller factor."""


def solve(n):
    if n % 2 == 0:
        return 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return d
        d += 2
    return n  # n is prime: no nontrivial divisor (the verifier rejects this, which is correct)
