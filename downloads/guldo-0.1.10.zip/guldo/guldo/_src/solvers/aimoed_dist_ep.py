"""aimoed in the cluster-counted API, TECHNIQUE: EXPERT parallelism. Tokens start sharded (T/8 per device); each device routes its own, then ONE all-to-all dispatches every token to the device holding its expert; each device runs its expert on what arrived; a SECOND all-to-all returns the results, which are put back in token order and gathered. The messages are the tokens, not the weights; the busiest expert's device sets the compute and the busiest device's traffic sets the bytes (load imbalance)."""
import math

import tensorops as tp

E = 8
BIAS = (0.0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9, 1.05)


def ints(Y):
    return list(map(int, (Y * 1073741824.0).tolist()))


def expert_weights(seed, d, T, e):
    o = T * d + d * E + e * 4 * d * d
    W1 = tp.reshape(tp.stream(seed, o, 2 * d * d), (d, 2 * d)) * math.sqrt(6.0 / d)
    W2 = tp.reshape(tp.stream(seed, o + 2 * d * d, 2 * d * d), (2 * d, d)) * math.sqrt(3.0 / (2 * d))
    return W1, W2


def route_ids(x, R, bias):
    """The expert of each row of x: argmax of the scores plus the bias (lowest index on ties), as a Python list."""
    rows = (x @ R + bias).tolist()
    return [row.index(max(row)) for row in rows]


def solve(seed, d, T, P):
    shard = T // P
    xs, ids, chunks, orders = [], [], [], []
    for i in range(P):
        tp.use(i)
        x = tp.reshape(tp.stream(seed, i * shard * d, shard * d), (shard, d))
        R = tp.reshape(tp.stream(seed, T * d, d * E), (d, E)) * math.sqrt(3.0 / d)
        e_of = route_ids(x, R, tp.reshape(tp.tensor(list(BIAS)), (1, E)))
        xs.append(x)
        row, order = [], []
        for j in range(P):
            idx = [t for t in range(shard) if e_of[t] == j]
            if False:
                idx = idx[:CAPACITY]
            row.append(tp.take(x, idx))
            order += idx
        chunks.append(row)
        orders.append(order)
    arrived = tp.all_to_all(chunks)
    results = []
    for j in range(P):
        tp.use(j)
        W1, W2 = expert_weights(seed, d, T, j)
        Xj = tp.concat(arrived[j], 0)
        Yj = tp.relu(Xj @ W1) @ W2
        parts, a = [], 0
        for i in range(P):
            n = arrived[j][i].shape[0]
            parts.append(Yj[a:a + n])
            a += n
        results.append(parts)
    back = tp.all_to_all(results)
    shards = []
    for i in range(P):
        tp.use(i)
        got = tp.concat(back[i], 0)
        order = orders[i]
        inv = [0] * shard
        for pos, t in enumerate(order):
            inv[t] = pos
        if len(order) < shard:
            got = tp.concat([got, tp.zeros((1, d))], 0)
            kept = set(order)
            inv = [inv[t] if t in kept else len(order) for t in range(shard)]
        shards.append(tp.reshape(tp.take(got, inv), (shard * d,)))
    return ints(tp.all_gather(shards)[0])
