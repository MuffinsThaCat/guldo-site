"""aimoe in the counted-operations API, REFERENCE: dense. Every token goes through all 8 experts, and the gate matrix (zero on the six experts a token does not use) combines them."""
import math

import tensorops as tp

D, F, E = 32, 64, 8
ROUTER = 3.0


def solve(seed, n):
    o = n * D
    X = tp.stream(seed, 0, o, (n, D))
    Wg = tp.stream(seed, o, D * E, (D, E)) * (ROUTER * math.sqrt(3.0 / D))
    o += D * E
    W1 = tp.stream(seed, o, E * D * F, (E, D, F)) * math.sqrt(3.0 / D)
    o += E * D * F
    W2 = tp.stream(seed, o, E * F * D, (E, F, D)) * math.sqrt(3.0 / F)
    S = (X @ Wg).tolist()
    G = []
    for row in S:
        a = 0
        for e in range(1, E):
            if row[e] > row[a]:
                a = e
        b = 1 if a == 0 else 0
        for e in range(E):
            if e != a and row[e] > row[b]:
                b = e
        pa = 1.0 / (1.0 + math.exp(row[b] - row[a]))
        g = [0.0] * E
        g[a] = pa
        g[b] = 1.0 - pa
        G.append(g)
    G = tp.tensor(G)
    H = tp.relu(tp.einsum("nd,edf->enf", X, W1))
    Y = tp.einsum("enf,efd->end", H, W2)
    out = tp.einsum("ne,end->nd", G, Y)
    return [int(x * 65536.0) for x in tp.reshape(out, (n * D,)).tolist()]
