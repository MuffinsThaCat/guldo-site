"""Run `solve(*args)` of one solver file under EXACT operation counting and report the count. Child process of tflops.py; not meant to be run by hand. Needs Python 3.12+.

  argv[1]   the solver file (a top-level `solve`), written in the restricted subset PLUS `import tensorops`
  stdin     {"args": [...], "limit": N}      N = the most operations the solver may spend (tensor ops + Python bytecode instructions)
  stdout    the LAST line is {"status": "ok" | "limit" | "error", "steps": int, "flops": int, "ans": ..., "err": "..."}

Cost = flops + steps.
  flops   the analytic tensor-operation charges of tensorops.py (shapes only: see its docstring for the table)
  steps   Python bytecode instructions executed in the SOLVER'S OWN CODE (its module body and everything it defines), exactly as count_runner.py counts them.
Library code (tensorops, numpy, the interpreter's own Python) is never counted: its instruction locations are disabled the first time they fire. Without the steps
term a solver could do real arithmetic in plain-float Python loops where no tensor op charges it; with it, such work costs at least one unit per instruction.

The restricted subset is count_runner.py's (no frames, getattr, open, dunders, str.format, eval/exec, ...), imported and reused unchanged, with one change made at run
time in THIS process only: the module allowlist is math, itertools and tensorops (no fractions/collections/heapq/bisect/functools: parts of those are pure Python
whose instructions would not be counted under the solver-code rule). count_runner.py itself is not modified, so existing counted certificates are unaffected.

Limits, stated in every verdict: it is not a time; work inside ONE C call other than the tensor ops (a giant big-int power, say) is one instruction; and it is blind to
memory traffic, cache and kernel quality (see tensorops.py).
"""
import gc
import json
import os
import resource
import sys

import count_runner as cr
import tensorops

TOOL_ID = 4

cr.ALLOWED_MODULES = {"math": None, "itertools": None, "tensorops": tuple(tensorops.EXPORTS)}   # this process only


class _StepLimit(BaseException):
    pass


def _emit(obj):
    sys.__stdout__.write("\n" + json.dumps(obj) + "\n")
    sys.__stdout__.flush()


def main():
    if len(sys.argv) != 2:
        _emit({"status": "error", "steps": 0, "flops": 0, "err": "usage: tflops_runner.py SOLVER"})
        return
    try:
        payload = json.loads(sys.stdin.read())
        args, limit = payload["args"], int(payload["limit"])
    except (ValueError, KeyError, TypeError) as e:
        _emit({"status": "error", "steps": 0, "flops": 0, "err": f"bad payload: {type(e).__name__}"})
        return
    if sys.version_info < (3, 12):
        _emit({"status": "error", "steps": 0, "flops": 0, "err": "counting needs Python 3.12 or newer (sys.monitoring)"})
        return
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path[:] = [p for p in sys.path if p and os.path.abspath(p) != here]   # everything needed is imported already; a solver must not reach the judge's modules
    mon = sys.monitoring
    try:
        delattr(sys, "monitoring")
    except (AttributeError, TypeError):
        pass
    sys.modules.pop("sys.monitoring", None)
    if sys.platform.startswith("linux"):
        try:
            resource.setrlimit(resource.RLIMIT_AS, (4 << 30, 4 << 30))
        except (ValueError, OSError):
            pass
    solver_name = sys.argv[1]
    try:
        code, namespace = cr._prepare(solver_name)
    except BaseException as e:
        _emit({"status": "error", "steps": 0, "flops": 0, "err": f"could not load the solver: {type(e).__name__}: {str(e)[:200]}"})
        return
    count = [0]
    tripped = [False]
    tensorops._FLOPS[0] = 0
    tensorops._LIMIT[0] = limit

    def on_instruction(c, offset):
        if c.co_filename != solver_name:
            return mon.DISABLE            # library code: never counted, and not asked about again at this location
        if tripped[0]:
            return None
        n = count[0] + 1
        count[0] = n
        if n + tensorops._FLOPS[0] > limit:
            tripped[0] = True
            raise _StepLimit()
        return None

    status, ans, err = "ok", None, ""
    real_stdout = sys.stdout
    sys.stdout = sys.stderr
    gc.collect()
    gc.disable()
    mon.use_tool_id(TOOL_ID, "svp-tflops")
    mon.register_callback(TOOL_ID, mon.events.INSTRUCTION, on_instruction)
    try:
        mon.set_events(TOOL_ID, mon.events.INSTRUCTION)
        exec(code, namespace)
        ans = namespace["solve"](*args)
    except (_StepLimit, tensorops.BudgetExceeded):
        status = "limit"
    except BaseException as e:
        status, err = "error", f"{type(e).__name__}: {str(e)[:200]}"
    finally:
        try:
            intact = mon.get_events(TOOL_ID) == mon.events.INSTRUCTION
        except ValueError:
            intact = False
        try:
            mon.set_events(TOOL_ID, mon.events.NO_EVENTS)
            mon.register_callback(TOOL_ID, mon.events.INSTRUCTION, None)
            mon.free_tool_id(TOOL_ID)
        except ValueError:
            intact = False
        gc.enable()
        sys.stdout = real_stdout
    steps, flops = count[0], tensorops._FLOPS[0]
    if tripped[0] or flops > limit:
        status, ans, err = "limit", None, ""
    elif status == "ok" and not intact:
        status, ans, err = "error", None, "the solver reconfigured the counter: its count means nothing"
    if status == "ok":
        try:
            json.dumps(ans)
        except (TypeError, ValueError):
            status, err, ans = "error", "the answer is not JSON-serialisable (an int, a list of ints or None is expected)", None
    _emit({"status": status, "steps": steps, "flops": flops, "ans": ans if status == "ok" else None, "err": err})


if __name__ == "__main__":
    main()
