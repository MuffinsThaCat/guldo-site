"""OpenTimestamps proofs for the certificate log's heads: stamp, upgrade, verify. Standard library only. Run the tests: python3 -m unittest test_otsanchor -v

What this gives and what it does not. A head's anchor line is hashed and sent to the public OpenTimestamps calendar servers, which fold it into a Bitcoin transaction. Once that
transaction is mined, the proof file shows the head existed no later than that block, a time and a commitment the operator does not control. It is NOT a co-signature and NOT a witness:
nobody checked the log. It makes a later rewrite of the history before that block detectable by anyone who holds the proof, with no one having to watch.

The file format is the reference one (`ots` client, opentimestamps-client): a detached timestamp of a sha256 digest. test_otsanchor cross-checks this module against the reference
library when it is installed. A proof is hostile input on the reader's side: the parser bounds depth, size and every field, and an unknown operation or attestation is kept or refused, never
guessed at. Network access is injected (`http=`) so every code path is testable offline."""
import hashlib
import json
import os
import urllib.error
import urllib.request

MAGIC = b"\x00OpenTimestamps\x00\x00Proof\x00\xbf\x89\xe2\xe8\x84\xe8\x92\x94"
MAJOR = 1
TAG_PENDING = bytes.fromhex("83dfe30d2ef90c8e")
TAG_BITCOIN = bytes.fromhex("0588960d73d71901")
OP_SHA256, OP_SHA1, OP_RIPEMD160, OP_KECCAK256 = 0x08, 0x02, 0x03, 0x67
OP_APPEND, OP_PREPEND, OP_REVERSE, OP_HEXLIFY = 0xF0, 0xF1, 0xF2, 0xF3
UNARY = {OP_SHA256, OP_SHA1, OP_RIPEMD160, OP_KECCAK256, OP_REVERSE, OP_HEXLIFY}
BINARY = {OP_APPEND, OP_PREPEND}
MAX_DEPTH = 300           # the reference library allows 256 nested operations; real proofs are around 100
MAX_NODES = 20000
MAX_BYTES = 1_000_000
MAX_ARG = 4096
MAX_PAYLOAD = 8192
MAX_URI = 1000
MAX_MSG = 1 << 20

CALENDARS = ("https://alice.btc.calendar.opentimestamps.org", "https://bob.btc.calendar.opentimestamps.org", "https://finney.calendar.eternitywall.com")
EXPLORERS = ("https://blockstream.info/api", "https://mempool.space/api")
USER_AGENT = "guldo-ots/1 (+https://guldo.org/log)"


class OtsError(Exception):
    pass


# ------------------------------------------------------------------ the proof tree
class Node:
    """One message in the proof and what is committed from it: attestations (kind, payload) and operations (op, arg, child Node)."""

    def __init__(self, msg):
        self.msg = msg
        self.atts = []        # [(tag8, payload bytes)]
        self.ops = []         # [(opcode, arg or None, Node)]

    def walk(self):
        stack = [self]
        while stack:
            n = stack.pop()
            yield n
            stack.extend(c for _, _, c in n.ops)

    def merge(self, other):
        """Add everything `other` (the same message) commits to. Iterative: a hostile deep tree cannot exhaust the stack."""
        todo = [(self, other)]
        while todo:
            a, b = todo.pop()
            if a.msg != b.msg:
                raise OtsError("cannot merge timestamps of different messages")
            for att in b.atts:
                if att not in a.atts:
                    a.atts.append(att)
            for op, arg, child in b.ops:
                mine = next((c for o, g, c in a.ops if (o, g) == (op, arg)), None)
                if mine is None:
                    a.ops.append((op, arg, child))
                else:
                    todo.append((mine, child))


def _apply(op, arg, msg):
    if op == OP_SHA256:
        out = hashlib.sha256(msg).digest()
    elif op == OP_SHA1:
        out = hashlib.sha1(msg).digest()
    elif op == OP_RIPEMD160:
        try:
            out = hashlib.new("ripemd160", msg).digest()
        except ValueError:
            raise OtsError("this Python's OpenSSL has no ripemd160: the proof cannot be followed here")
    elif op == OP_APPEND:
        out = msg + arg
    elif op == OP_PREPEND:
        out = arg + msg
    elif op == OP_REVERSE:
        if not msg:
            raise OtsError("reverse of an empty message")
        out = msg[::-1]
    elif op == OP_HEXLIFY:
        out = msg.hex().encode()
    else:
        raise OtsError(f"unsupported operation 0x{op:02x}: the proof cannot be followed here")
    if len(out) > MAX_MSG:
        raise OtsError("a message in the proof grows beyond its bound")
    return out


class _Reader:
    def __init__(self, data):
        self.d, self.i = data, 0

    def read(self, n):
        if n < 0 or self.i + n > len(self.d):
            raise OtsError("the proof ends in the middle of a field")
        v = self.d[self.i:self.i + n]
        self.i += n
        return v

    def byte(self):
        return self.read(1)[0]

    def varuint(self):
        value, shift = 0, 0
        while True:
            b = self.byte()
            value |= (b & 0x7F) << shift
            if not b & 0x80:
                return value
            shift += 7
            if shift > 63:
                raise OtsError("a number in the proof is too large")

    def varbytes(self, limit):
        n = self.varuint()
        if n > limit:
            raise OtsError(f"a field in the proof is {n} bytes, over the {limit} allowed")
        return self.read(n)


def _parse_node(r, msg, state, depth):
    if depth > MAX_DEPTH:
        raise OtsError(f"the proof nests deeper than {MAX_DEPTH} operations")
    node = Node(msg)
    state["nodes"] += 1
    if state["nodes"] > MAX_NODES:
        raise OtsError("the proof has too many nodes")
    while True:
        tag = r.byte()
        more = tag == 0xFF
        if more:
            tag = r.byte()
        if tag == 0x00:
            kind = r.read(8)
            payload = r.varbytes(MAX_PAYLOAD)
            node.atts.append((kind, payload))
        else:
            if tag in UNARY:
                arg = None
            elif tag in BINARY:
                arg = r.varbytes(MAX_ARG)
                if not arg:
                    raise OtsError("an append/prepend operation has an empty argument")
            else:
                raise OtsError(f"unknown operation 0x{tag:02x} in the proof")
            child = _parse_node(r, _apply(tag, arg, msg), state, depth + 1)
            node.ops.append((tag, arg, child))
        if not more:
            return node


def parse(data):
    """bytes -> (digest, root Node). Raises OtsError on anything malformed, oversized or not a sha256 detached timestamp."""
    if not isinstance(data, (bytes, bytearray)):
        raise OtsError("a proof is bytes")
    if len(data) > MAX_BYTES:
        raise OtsError(f"the proof is over {MAX_BYTES} bytes")
    r = _Reader(bytes(data))
    if r.read(len(MAGIC)) != MAGIC:
        raise OtsError("not an OpenTimestamps proof (wrong magic)")
    if r.varuint() != MAJOR:
        raise OtsError("an OpenTimestamps proof of an unsupported major version")
    if r.byte() != OP_SHA256:
        raise OtsError("this proof stamps something other than a sha256 digest")
    digest = r.read(32)
    root = _parse_node(r, digest, {"nodes": 0}, 0)
    if r.i != len(r.d):
        raise OtsError("trailing bytes after the proof")
    return digest, root


def _varuint(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def _varbytes(b):
    return _varuint(len(b)) + b


def _att_key(att):
    """The reference library orders attestations by kind, then by VALUE (a pending note by its address, a Bitcoin one by height), not by the length-prefixed bytes on the wire."""
    kind, payload = att
    try:
        if kind == TAG_PENDING:
            return (kind, 0, pending_uri(payload), 0)
        if kind == TAG_BITCOIN:
            return (kind, 0, "", bitcoin_height(payload))
    except OtsError:
        pass
    return (kind, 1, payload.hex(), 0)


def _ser_node(node, out, depth=0):
    if depth > MAX_DEPTH:
        raise OtsError("the proof nests too deeply to serialize")
    atts = sorted(node.atts, key=_att_key)
    ops = sorted(node.ops, key=lambda o: (o[0], o[1] or b""))
    if not atts and not ops:
        raise OtsError("an empty timestamp cannot be serialized")
    for kind, payload in atts[:-1] if ops == [] else atts:
        out += b"\xff\x00" + kind + _varbytes(payload)
    if not ops:
        kind, payload = atts[-1]
        out += b"\x00" + kind + _varbytes(payload)
        return
    for op, arg, child in ops[:-1]:
        out += b"\xff" + bytes([op]) + (_varbytes(arg) if op in BINARY else b"")
        _ser_node(child, out, depth + 1)
    op, arg, child = ops[-1]
    out += bytes([op]) + (_varbytes(arg) if op in BINARY else b"")
    _ser_node(child, out, depth + 1)


def serialize(digest, root):
    out = bytearray(MAGIC) + _varuint(MAJOR) + bytes([OP_SHA256]) + digest
    _ser_node(root, out)
    return bytes(out)


# ------------------------------------------------------------------ attestations
def pending_uri(payload):
    r = _Reader(payload)
    uri = r.varbytes(MAX_URI)
    if r.i != len(payload):
        raise OtsError("trailing bytes in a pending attestation")
    try:
        return uri.decode("ascii")
    except UnicodeDecodeError:
        raise OtsError("a pending attestation's address is not ASCII")


def bitcoin_height(payload):
    r = _Reader(payload)
    h = r.varuint()
    if r.i != len(payload):
        raise OtsError("trailing bytes in a Bitcoin attestation")
    return h


def describe(data):
    """-> {"digest", "pending": [uri], "bitcoin": [height], "unknown": n}: what the file claims, WITHOUT checking any of it against Bitcoin."""
    digest, root = parse(data)
    pend, btc, unk = set(), set(), 0
    for n in root.walk():
        for kind, payload in n.atts:
            if kind == TAG_PENDING:
                pend.add(pending_uri(payload))
            elif kind == TAG_BITCOIN:
                btc.add(bitcoin_height(payload))
            else:
                unk += 1
    return {"digest": digest.hex(), "pending": sorted(pend), "bitcoin": sorted(btc), "unknown": unk}


# ------------------------------------------------------------------ network (injected)
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def default_http(method, url, data=None, headers=None, timeout=25):
    """-> (status, body). https only, no redirects, body capped. Never raises for an HTTP status; raises OtsError for a network failure."""
    if not url.startswith("https://"):
        raise OtsError(f"refusing a non-https address: {url[:60]}")
    req = urllib.request.Request(url, data=data, method=method, headers=dict(headers or {}, **{"User-Agent": USER_AGENT}))
    opener = urllib.request.build_opener(_NoRedirect)
    try:
        with opener.open(req, timeout=timeout) as resp:
            return resp.status, resp.read(MAX_BYTES + 1)[:MAX_BYTES]
    except urllib.error.HTTPError as e:
        try:
            return e.code, e.read(2000)
        except OSError:
            return e.code, b""
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise OtsError(f"network failure: {type(e).__name__}")


CAL_HEADERS = {"Accept": "application/vnd.opentimestamps.v1"}


def stamp(digest, calendars=CALENDARS, http=default_http, nonce=None, min_ok=1):
    """Stamp a 32-byte sha256 digest with the calendars. -> (proof bytes, {calendar: error or None}). A random nonce hides the digest from the calendars, as the reference client does.
    At least min_ok calendars must accept or OtsError is raised (nothing is written for a stamp no calendar holds)."""
    if len(digest) != 32:
        raise OtsError("the digest is 32 bytes")
    root = Node(digest)
    nonce = nonce if nonce is not None else os.urandom(16)
    n1 = Node(_apply(OP_APPEND, nonce, digest))
    n2 = Node(_apply(OP_SHA256, None, n1.msg))
    root.ops.append((OP_APPEND, nonce, n1))
    n1.ops.append((OP_SHA256, None, n2))
    report = {}
    for cal in calendars:
        try:
            status, body = http("POST", cal + "/digest", n2.msg, dict(CAL_HEADERS, **{"Content-Type": "application/x-www-form-urlencoded"}))
            if status != 200:
                raise OtsError(f"HTTP {status}")
            got = _parse_node(_Reader(body), n2.msg, {"nodes": 0}, 0)
            n2.merge(got)
            report[cal] = None
        except OtsError as e:
            report[cal] = str(e)[:200]
    if sum(1 for v in report.values() if v is None) < min_ok:
        raise OtsError("no calendar accepted the stamp: " + "; ".join(f"{c}: {e}" for c, e in report.items()))
    return serialize(digest, root), report


def upgrade(data, http=default_http, calendars=CALENDARS):
    """Ask each pending attestation's calendar whether it now has a Bitcoin proof. -> (new proof bytes or None if nothing changed, {uri: note}).
    Only the known public calendars are contacted: a proof is untrusted input, and an address inside it is not a place to send requests."""
    digest, root = parse(data)
    notes = {}
    before = serialize(digest, root)
    for node in list(root.walk()):
        for kind, payload in list(node.atts):
            if kind != TAG_PENDING:
                continue
            uri = pending_uri(payload)
            if uri not in calendars:
                notes[uri] = "not a known calendar: not contacted"
                continue
            try:
                status, body = http("GET", uri + "/timestamp/" + node.msg.hex(), None, CAL_HEADERS)
            except OtsError as e:
                notes[uri] = str(e)[:120]
                continue
            if status == 404:
                notes[uri] = "not yet in a Bitcoin block"
                continue
            if status != 200:
                notes[uri] = f"HTTP {status}"
                continue
            try:
                got = _parse_node(_Reader(body), node.msg, {"nodes": 0}, 0)
            except OtsError as e:
                notes[uri] = f"unusable answer: {e}"
                continue
            node.merge(got)
            done = any(k == TAG_BITCOIN for n in got.walk() for k, _ in n.atts)
            if done:
                node.atts = [a for a in node.atts if a != (kind, payload)]     # the pending note is superseded
            notes[uri] = "upgraded" if done else "answered, still pending"
    after = serialize(digest, root)
    return (after if after != before else None), notes


# ------------------------------------------------------------------ verification
def bitcoin_claims(data):
    """-> [(height, expected merkle root in Bitcoin's internal byte order)] for every Bitcoin attestation, with the digest it commits."""
    digest, root = parse(data)
    out = []
    for n in root.walk():
        for kind, payload in n.atts:
            if kind == TAG_BITCOIN:
                out.append((bitcoin_height(payload), n.msg))
    return digest, out


def block_info(height, explorers=EXPLORERS, http=default_http):
    """-> [(explorer, merkle_root_display_hex, block_time) or (explorer, None, why)] from each independent explorer."""
    res = []
    for base in explorers:
        try:
            st, body = http("GET", f"{base}/block-height/{height}", None, {})
            if st != 200:
                raise OtsError(f"HTTP {st}")
            h = body.decode("ascii").strip()
            if len(h) != 64 or any(c not in "0123456789abcdef" for c in h):
                raise OtsError("not a block hash")
            st, body = http("GET", f"{base}/block/{h}", None, {})
            if st != 200:
                raise OtsError(f"HTTP {st}")
            j = json.loads(body.decode("utf-8"))
            mr, ts = j["merkle_root"], j["timestamp"]
            if not (isinstance(mr, str) and len(mr) == 64 and isinstance(ts, int) and not isinstance(ts, bool)):
                raise OtsError("unexpected block record")
            bytes.fromhex(mr)
            res.append((base, mr, ts))
        except (OtsError, ValueError, KeyError, TypeError, AttributeError, RecursionError, UnicodeDecodeError) as e:      # an explorer's answer is untrusted: a list, a deep nest, a number
            res.append((base, None, str(e)[:100] or type(e).__name__))
    return res


def verify(data, expected_digest, explorers=EXPLORERS, http=default_http, min_sources=2):
    """Check a proof against the digest the reader computed AND against Bitcoin. -> {"status", "detail", "time", "height"}.
    status: "confirmed" (a block's merkle root matches, seen by >= min_sources independent explorers), "single-source" (matches at fewer explorers than asked),
    "pending" (calendars hold it; no Bitcoin attestation yet), "mismatch" (the proof is not for this digest, or a block's merkle root differs: a forged or wrong proof),
    "unverifiable" (explorers unreachable/disagreeing), "invalid" (not a proof)."""
    try:
        digest, claims = bitcoin_claims(data)
        info = describe(data)
    except OtsError as e:
        return {"status": "invalid", "detail": str(e), "time": None, "height": None}
    if digest != expected_digest:
        return {"status": "mismatch", "detail": "this proof stamps a different digest than the head's anchor line", "time": None, "height": None}
    if not claims:
        return {"status": "pending", "detail": "held by " + ", ".join(info["pending"] or ["no calendar"]) + "; no Bitcoin block yet (usually within a few hours)", "time": None, "height": None}
    best = None
    seen_wrong = []
    for height, msg in sorted(set(claims)):
        want = msg[::-1].hex()          # Bitcoin shows a merkle root reversed relative to its internal order
        seen = block_info(height, explorers, http)
        ok = [(b, ts) for b, mr, ts in seen if mr is not None and mr == want]
        bad = [b for b, mr, ts in seen if mr is not None and mr != want]
        if bad:
            seen_wrong.append(f"block {height}: merkle root differs at {', '.join(bad)}")
            continue
        if ok:
            t = min(ts for _, ts in ok)
            cand = {"status": "confirmed" if len(ok) >= min_sources else "single-source", "height": height, "time": t, "sources": [b for b, _ in ok]}
            if best is None or (cand["status"] == "confirmed", -cand["time"]) > (best["status"] == "confirmed", -best["time"]):
                best = cand
    if best:
        best["detail"] = f"Bitcoin block {best['height']} (block time {best['time']}) commits to this head; seen at {len(best['sources'])} independent explorer(s)"
        return best
    if seen_wrong:
        return {"status": "mismatch", "detail": "; ".join(seen_wrong), "time": None, "height": None}
    return {"status": "unverifiable", "detail": "no explorer could confirm the block (unreachable or not found)", "time": None, "height": None}
