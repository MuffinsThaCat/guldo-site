"""aikfac in the counted-operations API, TECHNIQUE: Newton-CG WITHOUT a preconditioner: solve H step = gradient approximately by conjugate gradient on the exact Hessian-vector product (two passes over X), truncated at a relative residual of 1e-3. The correlated features make H ill-conditioned, so the inner solve needs many iterations; the point of this solver is to show what K-FAC saves."""
import math

import tensorops as tp

K = 8
RHO = 0.9
LAM = 1e-3
GRAD2 = 2e-13          # gap <= |g|^2 / (2 lambda) <= 1e-10 (a margin of 100 under the judge's 1e-8)


def features(seed, n, N):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(n)] for k in range(n)])
    return (tp.reshape(tp.stream(seed, 0, N * n), (N, n)) @ U) * math.sqrt(1.0 - RHO * RHO)


def onehot(labels, N):
    return tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(N)])


def softmax(S):
    E = tp.exp(S - tp.max(S, 1, True))
    return E / tp.sum(E, 1, True)


def answer(W, n):
    return [int(v * 1048576.0) for v in tp.reshape(W, (n * K,)).tolist()]
MAXITER = 40
INNER = 400
TOL = 1e-3             # relative residual (norm) of the inner solve


def hvp(X, Xt, P, V, N):
    """The exact Hessian-vector product: X^T (T - P * rowsum(T)) / N + lambda V with T = P * (X V)."""
    T = P * (X @ V)
    return Xt @ (T - P * tp.sum(T, 1, True)) * (1.0 / N) + V * LAM


def solve(seed, n, N, labels):
    X = features(seed, n, N)
    Y = onehot(labels, N)
    Xt = tp.transpose(X, (1, 0))
    W = tp.zeros((n, K))
    for it in range(MAXITER):
        P = softmax(X @ W)
        g = Xt @ (P - Y) * (1.0 / N) + W * LAM
        g2 = tp.sum(g * g).item()
        if g2 <= GRAD2:
            break
        x = tp.zeros((n, K))
        r = g
        z = r
        p = z
        rz = tp.sum(r * z).item()
        for j in range(INNER):
            Hp = hvp(X, Xt, P, p, N)
            a = rz / tp.sum(p * Hp).item()
            x = x + p * a
            r = r - Hp * a
            if tp.sum(r * r).item() <= TOL * TOL * g2:
                break
            z = r
            rz2 = tp.sum(r * z).item()
            p = z + p * (rz2 / rz)
            rz = rz2
        W = W - x
    return answer(W, n)
