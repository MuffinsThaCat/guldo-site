"""Independent attestations of a speedup certificate: signed statements from people who checked it themselves.

  python3 attest.py keygen --out my.key                      a new Ed25519 key (never overwritten); prints the public key to publish
  python3 attest.py sign x.cert.json --key my.key --out x.my.att.json [--rerun 5 --execute] [--tolerance 1.0]
  python3 attest.py check x.cert.json a1.json a2.json [--trusted keys.txt]

`sign` runs certificate.verify on YOUR machine (and, with --rerun --execute, re-measures K instances you pick at random) and signs the outcome,
the machine it ran on and a hash of the certificate. `check` reads attestation files, verifies each signature and that it is about THIS certificate,
and reports how many distinct keys agree.

What an attestation is worth is exactly what the verifier's identity is worth. A key proves "the same party signed these", never "this party is
independent of the operator": an operator can mint five keys. So `check` separates attestations by keys listed in --trusted (a file of public
keys, one hex per line, `# name` allowed, that YOU obtained out of band from people you chose) from all others, which are reported as unvouched
and never counted as independent. The machine description inside a statement is self-reported. A signed statement that the certificate does NOT
verify (a dissent) makes `check` fail whoever signed it.
"""
import argparse
import json
import math
import os
import platform
import re
import secrets
import sys
import time

import certificate as K

FORMAT = "svp-attestation-v1"


class NeedsCryptography(Exception):
    """The `cryptography` package is not installed. Signing cannot work; checking reports that signatures could not be verified."""


def _ed():
    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519
        from cryptography.hazmat.primitives import serialization
    except ImportError:
        raise NeedsCryptography("attest.py needs the `cryptography` package (pip install cryptography) for Ed25519 signatures")
    return ed25519, serialization


def have_crypto():
    try:
        _ed()
        return True
    except NeedsCryptography:
        return False


def cert_digest(cert):
    return K.sha256(K.canon(cert))


def _pub_hex(priv, serialization):
    return priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()


def keygen(path):
    ed25519, ser = _ed()
    priv = ed25519.Ed25519PrivateKey.generate()
    raw = priv.private_bytes(ser.Encoding.Raw, ser.PrivateFormat.Raw, ser.NoEncryption())
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)  # a key is never overwritten
    with os.fdopen(fd, "w") as f:
        f.write(raw.hex() + "\n")
    return _pub_hex(priv, ser)


def _load_key(path):
    ed25519, ser = _ed()
    with open(path) as f:
        return ed25519.Ed25519PrivateKey.from_private_bytes(bytes.fromhex(f.read().strip())), ser


def sign(cert, key_path, rerun=0, execute=False, tolerance=K.RERUN_TOLERANCE, sample_seed=None, note="", now=None):
    priv, ser = _load_key(key_path)
    if rerun and sample_seed is None:
        sample_seed = secrets.randbelow(2 ** 31)  # the verifier's own draw: the operator cannot know which instances will be re-measured
    res = K.verify(cert, rerun=rerun, execute=execute, tolerance=tolerance, sample_seed=sample_seed or 0)
    rr = next((c.get("data") for c in res["checks"] if c["check"] == "rerun" and c.get("data")), None)
    stmt = {"format": FORMAT, "cert_sha256": cert_digest(cert), "claim": cert.get("claim"), "verified": res["ok"],
            "checks": [{"check": c["check"], "status": c["status"]} for c in res["checks"]], "rerun": rr, "private_solver": bool(res.get("private")) and not res.get("source_revealed"), "rerun_requested": rerun, "sample_seed": sample_seed if rerun else None, "executed": bool(execute),
            "machine": {"platform": platform.platform(), "machine": platform.machine(), "python": platform.python_version(), "self_reported": True},
            "at": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "note": note, "pubkey": _pub_hex(priv, ser)}
    return {"statement": stmt, "signature": priv.sign(K.canon(stmt).encode()).hex()}


def _valid_signature(att):
    ed25519, _ = _ed()
    try:
        pub = ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(att["statement"]["pubkey"]))
        pub.verify(bytes.fromhex(att["signature"]), K.canon(att["statement"]).encode())
        return True
    except Exception:
        return False


_NAME_OK = re.compile(r"[A-Za-z0-9 _.:,()/+-]{1,60}")   # used with fullmatch: `$` would also accept a trailing newline


def _wellformed(st):
    """A validly SIGNED statement is still attacker-controlled data (anyone can mint a key). Accept only the exact shape sign() writes and return a
    cleaned copy: verified is a real bool, check names are short plain text (they are printed to terminals), the gap is a finite number or None.
    Anything else raises ValueError and the attestation is ignored, so a hostile one can neither crash a caller nor count as an attestation."""
    if st.get("verified") is not True and st.get("verified") is not False:
        raise ValueError("verified is not a boolean")
    checks = st.get("checks")
    if not isinstance(checks, list) or len(checks) > 200:
        raise ValueError("checks is not a short list")
    cleaned = []
    for c in checks:
        if not isinstance(c, dict) or not isinstance(c.get("check"), str) or not _NAME_OK.fullmatch(c["check"]) or c.get("status") not in ("pass", "fail", "skip", "warn"):
            raise ValueError("a check entry is malformed")
        cleaned.append((c["check"], c["status"]))
    gap, exact = None, None
    rr = st.get("rerun")
    if rr is not None:
        if not isinstance(rr, dict):
            raise ValueError("rerun is malformed")
        if rr.get("exact") is True:   # a re-run under STEP COUNTING (counted.py): identical counts, not a timing gap
            nums = [rr.get("k"), rr.get("of"), rr.get("mismatches")]
            if not all(isinstance(x, int) and not isinstance(x, bool) and 0 <= x <= 10 ** 9 for x in nums):
                raise ValueError("rerun is malformed")
            exact = {"k": nums[0], "of": nums[1], "mismatches": nums[2]}
        elif isinstance(rr.get("median_gap_bits"), bool) or not isinstance(rr.get("median_gap_bits"), (int, float)) or not math.isfinite(rr["median_gap_bits"]):
            raise ValueError("rerun is malformed")
        else:
            gap = round(float(rr["median_gap_bits"]), 3)
    return {"verified": st["verified"], "checks": cleaned, "gap": gap, "exact": exact, "private": st.get("private_solver") is True}


def read_trusted(path):
    """Pinned public keys: one 64-hex Ed25519 key per line, `# name` allowed. A malformed line is refused, never skipped: a typo would silently
    leave a reviewer unpinned and the count of independent attestations would read 0 with no explanation."""
    keys = {}
    with open(path) as f:
        for n, line in enumerate(f, 1):
            line = line.split("#")[0].strip()
            if not line:
                continue
            if len(line) != 64 or any(c not in "0123456789abcdefABCDEF" for c in line):
                raise SystemExit(f"REFUSED: {path} line {n} is not a 64-hex public key: {line[:40]!r}")
            keys[line.lower()] = True
    return keys


def check(cert, attestations, trusted=None):
    """-> {"ok": bool, "checks": [...]}. `attestations` are parsed attestation dicts; `trusted` a set of public-key hex strings pinned by the reader."""
    trusted = {k.lower() for k in (trusted or [])}
    if attestations and not have_crypto():
        # never treat an unverifiable signature as either valid or invalid, and never abort a caller (the site build) over it.
        # ok is False: nothing was verified, so a caller (CI, the CLI exit status) must not read this as a pass
        return {"ok": False, "pinned": 0, "unvouched": 0, "checks": [{"check": "attestations", "status": "warn",
                "detail": f"{len(attestations)} attestation file(s) NOT checked: the `cryptography` package is not installed, so no signature could be verified (none is counted, and a dissent among them would not be seen)"}]}
    digest, out = cert_digest(cert), []
    good, dissent, ignored = {}, {}, []
    for i, att in enumerate(attestations):
        label = f"attestation {i + 1}"
        try:
            st = att["statement"]
            if st.get("format") != FORMAT:
                raise ValueError("not an " + FORMAT)
            if not _valid_signature(att):
                ignored.append(f"{label}: signature does not verify")
                continue
            if st["cert_sha256"] != digest:
                ignored.append(f"{label}: signed for a different certificate")
                continue
            key = st["pubkey"].lower()
            clean = _wellformed(st)       # a valid signature only proves WHO signed: the contents are still untrusted input
        except (KeyError, TypeError, ValueError, AttributeError) as e:
            ignored.append(f"{label}: unreadable ({type(e).__name__})")
            continue
        (good if clean["verified"] else dissent).setdefault(key, clean)  # one vote per key: a key attesting twice is still one party
    for msg in ignored:
        out.append({"check": "attestation ignored", "status": "warn", "detail": msg})
    for key, cl in dissent.items():
        fails = [name for name, status in cl["checks"] if status == "fail"]
        out.append({"check": "dissent", "status": "fail", "detail": f"key {key[:12]}... signed that this certificate does NOT verify (failed: {', '.join(fails) or 'unspecified'})"
                    + (" [pinned key]" if key in trusted else " [unvouched key: anyone can mint one, and the claim is checkable: run `certificate.py verify` yourself]")})
    pinned = [k for k in good if k in trusted]
    other = [k for k in good if k not in trusted]
    gaps = [cl["gap"] for cl in good.values() if cl["gap"] is not None]
    detail = (f"{len(good)} distinct key(s) attest that it verifies: {len(pinned)} from pinned keys (independent by YOUR choice), {len(other)} unvouched "
              "(a key proves nothing about independence from the operator)")
    if gaps:
        detail += f"; {len(gaps)} re-measured the speedup on their own machine, median gaps {gaps} bits (self-reported)"
    exacts = [cl["exact"] for cl in good.values() if cl["exact"] is not None and cl["exact"]["mismatches"] == 0]
    if exacts:
        detail += ("; " + str(len(exacts)) + " re-EXECUTED instances under step counting and got IDENTICAL counts ("
                   + ", ".join(f"{e['k']} of {e['of']}" for e in exacts) + " instances re-run; self-reported by each signer, but anyone can repeat it)")
    blind = sum(1 for cl in good.values() if cl["private"])
    if blind:
        detail += f"; {blind} verified a PRIVATE-SOLVER certificate: they could not inspect or re-run the solver, so that is weaker evidence about the timings"
    status = "pass" if pinned else ("warn" if good else "skip")
    out.append({"check": "attestations", "status": status, "detail": detail if good else "no valid attestation that it verifies"})
    return {"ok": all(c["status"] != "fail" for c in out), "checks": out, "pinned": len(pinned), "unvouched": len(other)}


def main(argv=None):
    try:
        return _main(argv)
    except NeedsCryptography as e:
        raise SystemExit(f"REFUSED: {e}")


def build_parser():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("keygen")
    p.add_argument("--out", required=True)
    p = sub.add_parser("sign")
    p.add_argument("cert")
    p.add_argument("--key", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--rerun", type=K.rerun_count, default=0, metavar="K|all")
    p.add_argument("--execute", action="store_true", help="runs the certificate's code on this machine, unsandboxed (see certificate.py)")
    p.add_argument("--tolerance", type=float, default=K.RERUN_TOLERANCE)
    p.add_argument("--note", default="")
    p = sub.add_parser("check")
    p.add_argument("cert")
    p.add_argument("attestations", nargs="+")
    p.add_argument("--trusted", help="file of public keys (hex, one per line) you obtained out of band")
    return ap


def _main(argv=None):
    a = build_parser().parse_args(argv)
    if a.cmd == "keygen":
        try:
            pub = keygen(a.out)
        except FileExistsError:
            raise SystemExit(f"REFUSED: {a.out} exists; a key is never overwritten")
        print(f"wrote {a.out} (keep it private). Publish this public key:\n{pub}")
        return
    with open(a.cert, encoding="utf-8") as f:
        cert = json.load(f)
    if a.cmd == "sign":
        if os.path.exists(a.out):
            raise SystemExit(f"REFUSED: {a.out} exists")
        att = sign(cert, a.key, a.rerun, a.execute, a.tolerance, note=a.note)
        fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(att, f, indent=1, sort_keys=True)
        s = att["statement"]
        print(f"wrote {a.out}: certificate {'VERIFIES' if s['verified'] else 'does NOT verify'} on this machine" + (f"; re-measured gap {s['rerun']['median_gap_bits']} bits" if s["rerun"] else ""))
        return
    atts = []
    for path in a.attestations:
        with open(path, encoding="utf-8") as f:
            atts.append(json.load(f))
    res = check(cert, atts, list(read_trusted(a.trusted)) if a.trusted else None)
    for c in res["checks"]:
        print(f"  {c['status'].upper():4s} {c['check']}: {c['detail']}")
    sys.exit(0 if res["ok"] else 1)


if __name__ == "__main__":
    main()
