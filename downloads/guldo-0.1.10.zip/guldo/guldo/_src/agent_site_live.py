"""The "First runs against a live model API" section of the Agents page, generated from the saved evidence so it cannot say more than the files show.

  live_runs()          recompute everything from agent_eval/real_runs_2026-11-27/anthropic_live: per ladder the trial and solve counts, mean proxy tokens, the cost at LIVE_PRICES from the usage the
                       harness recorded, and whether every trial re-verifies from the public seed; the paired comparison's verdicts; and what the recording proxy said about the genuine ladder and about a
                       hand-edited copy. None if the evidence is absent.
  live_section(live, cmd)   the HTML fragment (the site's markup; every string HTML-escaped; no script, no external resource, no timestamp: the same files give the same bytes).
  live_files()         every evidence file, relative to LIVE_DIR: the site publishes them under data/agent_live/.

Nothing numeric is typed in. The wording says what the files show: a DEMONSTRATION on a public practice seed, with the limits stated beside it.
"""
import html
import json
import os

import agent_core
import agent_domains_plus                                                            # noqa: F401  this module loads a ladder's domain by name: the extra domains must be registered

LIVE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "agent_eval", "real_runs_2026-11-27", "anthropic_live")
LIVE_PRICES = {"haiku": (1.0, 5.0), "sonnet": (2.0, 10.0)}      # USD per million tokens (input, output): the list prices on 2026-11-27; the page says so
LIVE_RUNS = [("pilot/ladder_haiku45.jsonl", "Pilot: one trial"),
             ("study/haiku45.jsonl", "Study, first arm"),
             ("study/sonnet55_pilot_size3.jsonl", "Pilot: one trial at the hardest size"),
             ("study/sonnet55.jsonl", "Study, second arm"),
             ("attested/ladder.jsonl", "Run through the recording proxy")]
BASE = "data/agent_live/"
LIVE_COMMANDS = ["guldo agent verify haiku45.jsonl --practice --plan plan.json", "guldo agent check claim.json haiku45.jsonl sonnet55.jsonl",
                 "guldo agent-proxy verify ladder.jsonl proxy_log.jsonl --trusted verifier.pub --practice"]


def _e(x):
    return html.escape(str(x), quote=True)


def live_files():
    out = []
    for root, _, files in os.walk(LIVE_DIR):
        for f in files:
            out.append(os.path.relpath(os.path.join(root, f), LIVE_DIR))
    return sorted(out)


def live_runs():
    need = [rel for rel, _ in LIVE_RUNS] + ["study/claim.json", "attested/proxy_log.jsonl", "attested/verifier.pub", "NOT_A_RESULT_forged_negative_control/careful_forgery.jsonl"]
    if not all(os.path.exists(os.path.join(LIVE_DIR, r)) for r in need):
        return None
    import agent_harness
    import agent_proxy
    master = agent_core.PRACTICE_SEED

    def ordinary(header, recs):
        return [p for rec in recs for p in agent_harness.check_trial(rec, agent_core.load_domain(rec["domain"]), master, header)]
    rows, total = [], 0.0
    for rel, label in LIVE_RUNS:
        h, recs = agent_core.read_ladder(os.path.join(LIVE_DIR, rel))
        model = str((h.get("agent") or {}).get("model") or "")
        pin, pout = next((v for k, v in LIVE_PRICES.items() if k in model), (None, None))
        cost = None
        billed = sum(t["usage"]["input_tokens"] + t["usage"]["output_tokens"] for r in recs for t in r["turns"] if t.get("role") == "assistant" and t.get("usage"))
        if pin is not None:
            cost = sum(t["usage"]["input_tokens"] * pin + t["usage"]["output_tokens"] * pout for r in recs for t in r["turns"] if t.get("role") == "assistant" and t.get("usage")) / 1e6
            total += cost
        rows.append({"label": label, "file": rel, "model": model, "trials": len(recs), "solved": sum(1 for r in recs if r["solved"]), "tokens": sum(r["tokens"] for r in recs) / max(len(recs), 1),
                     "cost": cost, "billed": billed, "proxy_total": sum(r["tokens"] for r in recs), "sizes": sorted({r["size"] for r in recs}),
                     "domains": sorted({r["domain"] for r in recs}), "verified": not ordinary(h, recs)})
    with open(os.path.join(LIVE_DIR, "study", "claim.json"), "r", encoding="utf-8") as f:
        claim = json.load(f)
    h, recs = agent_core.read_ladder(os.path.join(LIVE_DIR, "attested", "ladder.jsonl"))
    log = agent_proxy.read_log(os.path.join(LIVE_DIR, "attested", "proxy_log.jsonl"))
    with open(os.path.join(LIVE_DIR, "attested", "verifier.pub"), "r", encoding="utf-8") as f:
        trusted = {ln.strip() for ln in f if ln.strip()}
    genuine, _ = agent_proxy.verify_http(h, recs, log, trusted, master)
    fh, frecs = agent_core.read_ladder(os.path.join(LIVE_DIR, "NOT_A_RESULT_forged_negative_control", "careful_forgery.jsonl"))
    forged, _ = agent_proxy.verify_http(fh, frecs, log, trusted, master)
    ratio = sum(r["billed"] for r in rows) / max(sum(r["proxy_total"] for r in rows), 1)
    return {"rows": rows, "total": total, "unpriced": [r["file"] for r in rows if r["cost"] is None], "ratio": ratio, "attested_trials": len(recs),
            "study_n": rows[1]["trials"], "study_sizes": sorted(set(rows[1]["sizes"]) | set(rows[3]["sizes"])), "study_domains": sorted(set(rows[1]["domains"]) | set(rows[3]["domains"])), "claim": claim, "exchanges": len(log), "genuine_problems": genuine, "forgery_ordinary_problems": ordinary(fh, frecs), "forgery_proxy_problems": forged}


def live_section(live, cmd):
    """-> list of HTML strings. `cmd(text)` renders one copy-able command the way the site does."""
    trs = "".join('<tr><td>%s<br><a class="fine" href="%s%s">%s</a></td><td class="mono">%s</td><td class="num mono">%d / %d</td><td class="num mono">%.0f</td><td class="num mono">%s</td><td>%s</td></tr>'
                  % (_e(r["label"]), BASE, _e(r["file"]), _e(r["file"]), _e(r["model"]), r["solved"], r["trials"], r["tokens"], ("$%.4f" % r["cost"]) if r["cost"] is not None else "n/a",
                     "yes" if r["verified"] else "NO") for r in live["rows"])
    c = live["claim"]
    verdict_s, verdict_c = (c.get("success") or {}).get("verdict", ""), (c.get("cost") or {}).get("verdict", "")
    passes = not live["forgery_ordinary_problems"]
    return [
        '<section class="block" id="live-runs"><h2>First runs against a live model API</h2>',
        '<p class="fine">Run on 27 November 2026 with the official Anthropic SDK, on the <strong>public practice seed</strong>: anyone can derive every instance, so these show that the machinery works on a hosted '
        'model, <strong>not</strong> a certified number about either model. Every figure in this section is recomputed from the files linked below when this page is built.</p>',
        '<div class="scroll"><table class="lb"><thead><tr><th>Run</th><th>Model</th><th class="num">Solved</th><th class="num">Mean proxy tokens</th><th class="num">Cost</th><th>Re-verifies from the seed</th>'
        '</tr></thead><tbody>', trs, '</tbody></table></div>',
        '<p class="fine">Cost is the usage the harness recorded for each model call, at list prices of $1 / $5 (haiku-4-5) and $2 / $10 (sonnet-5-5) per million input / output tokens: <strong>$%.2f in total</strong>%s. '
        'Proxy tokens are this project\'s own count (bytes / 4 of what was sent); across these runs the provider\'s recorded usage was %.1f times as many tokens.</p>'
        % (live["total"], (" (PARTIAL: no price known for %s)" % _e(", ".join(live["unpriced"]))) if live["unpriced"] else "", live["ratio"]),
        '<div class="card"><h3>The two models on the same %d instances</h3><p class="fine">claude-haiku-4-5 as the baseline, claude-sonnet-5-5 as the candidate. Solve rate: %s. Cost in proxy tokens: %s. '
        '%d instances cannot rank two models, and the rules refuse to claim more than the data support.</p></div>'
        % (live["study_n"], _e(verdict_s), _e(verdict_c), live["study_n"]),
        '<div class="card"><h3>What the recording proxy did</h3><p class="fine">%d trials went through a recording proxy (a separate process that forwards each request unchanged and signs a receipt for it): '
        '<strong>%d signed exchanges, one per model call</strong>. The genuine ladder is %s. A hand-edited copy (one reply rewritten, and every token count and hash repaired so that it %s ordinary ladder '
        'verification) is %s by the proxy log: %s. That is the check that closes the gap in the limits above: a ladder that is internally flawless can still be invented, and only a record kept by someone else '
        'can show it.</p></div>'
        % (live["attested_trials"], live["exchanges"], "<strong>ATTESTED</strong>" if not live["genuine_problems"] else "NOT attested (%d problems)" % len(live["genuine_problems"]),
           "passes" if passes else "does NOT pass", "<strong>rejected</strong>" if live["forgery_proxy_problems"] else "NOT rejected", _e((live["forgery_proxy_problems"] or ["no problem found"])[0])),
        '<h3>What these runs do not show</h3><ul>',
        '<li>Anything about a model on a hidden seed: every instance here can be derived by anyone.</li>',
        "<li>Independence: the same person ran the proxy and the agent. This shows the mechanism works against the real provider, not that an independent verifier was involved. The guarantee needs a proxy "
        "and key outside the operator's control.</li>",
        '<li>A ranking of the two models: %d instances, domain %s, sizes %s, one trial each.</li>' % (live["study_n"], _e(", ".join(live["study_domains"])), _e(", ".join(str(x) for x in live["study_sizes"]))),
        '<li>Anything about answer quality beyond solve rate, other domains, or larger sizes.</li></ul>',
        '<h3>Check it yourself</h3><p class="fine">Download the files (every one is linked in the table above and listed in <a href="%sREADME.md">the folder\'s README</a>; the proxy\'s signed log is '
        '<a href="%sattested/proxy_log.jsonl">here</a> and the public key to pin is <a href="%sattested/verifier.pub">here</a>). The signing key and the API key are not published. Then, with the tool '
        'installed:</p>' % (BASE, BASE, BASE),
        *[cmd(c) for c in LIVE_COMMANDS],
        '<p class="fine">The hand-edited ladder is published only as a labelled negative control, in <a href="%sNOT_A_RESULT_forged_negative_control/careful_forgery.jsonl">a folder named NOT_A_RESULT</a>: it is '
        'not a result and must not be indexed or cited as one. Run the third command on it with the same proxy log to see it rejected.</p></section>' % BASE]
