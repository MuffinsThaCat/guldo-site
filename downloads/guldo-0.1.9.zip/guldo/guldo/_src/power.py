"""Empirical power of the Tier-1 claim using REAL per-instance noise instead of an assumed Gaussian.

Given a baseline ladder and one or more "reference pair" ladders (a solver measured against that same baseline on the
same instances), this takes the real paired log2-ratios, removes each dimension's median (leaving the real noise
residuals, heavy tails included), then synthesises a submission whose true speedup is exactly `e` bits:

    sub_cost(i) = baseline_cost(i) * 2 ** -(e + residual drawn from that dimension's real residuals)

and runs the actual usable_dims + measured_lower pipeline on it. Output: P(credit >= threshold) per effect size, plus
the zero-effect false-credit rate. Baseline timeouts stay censored exactly as in the real data, so the effect of the
timeout cap on power is included (the Gaussian simulation in PROTOCOL.md ignores it).

  python3 power.py --baseline B.jsonl --pair S.jsonl [--pair S2.jsonl ...] [--effects 0 1 2 3 4] [--trials 200]
"""
import argparse
import json
import math
import random
import statistics
from collections import defaultdict

import numpy as np

import extrapolate as E


def load(path):
    meta, by_dim = None, defaultdict(dict)
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            if r.get("meta"):
                meta = r
            else:
                by_dim[r["dim"]][r["id"]] = r
    return meta, by_dim


def residuals(base, sub, budget):
    """Real noise: paired log2 ratios minus the median of their baseline-difficulty octave (both solved, so no
    censoring artefact). Returns {octave: [residuals]} for octaves with >= 4 instances."""
    by_bin = defaultdict(list)
    for d in base:
        for i in base[d]:
            if i in sub.get(d, {}) and base[d][i]["status"] == "solved" and sub[d][i]["status"] == "solved":
                cb = base[d][i]["cpu_net"]
                if cb >= E.FLOOR_ABS:
                    by_bin[int(math.floor(math.log2(cb / E.FLOOR_ABS)))].append(
                        math.log2(cb / sub[d][i]["cpu_net"]))
    return {k: [x - statistics.median(v) for x in v] for k, v in by_bin.items() if len(v) >= 4}


def synth_trial(base, budget, resid_pool, effect, rng, boot, copies=1, resample=False):
    """Synthetic submission with a TRUE constant speedup `effect` over the real baseline costs. Baseline-censored
    instances stay censored (and are excluded by the estimator, exactly as in a real run).
    copies > 1 replicates the real baseline ladder that many times (same cost distribution, copies x the instances per dimension, each copy
    with its own noise draw): the answer to "what would a ladder with more instances per dimension certify?" without running one.
    The copies are IDENTICAL baseline costs, so a larger ladder always has exactly `copies` x the observed hard instances. resample=True draws
    each dimension's instances (copies x as many) at random WITH REPLACEMENT from the real ones instead, so the number of hard instances varies
    from ladder to ladder, as it would for a genuinely larger ladder of fresh instances: the honest version of the question."""
    tb, ts, bc = {}, {}, {}
    for d, recs in base.items():
        tb[d], ts[d], bc[d] = {}, {}, {}
        if resample:
            ids = list(recs)
            chosen = [(f"{j}", recs[rng.choice(ids)]) for j in range(len(ids) * copies)]
        else:
            chosen = [((i if copies == 1 else f"{i}#{c}"), r) for i, r in recs.items() for c in range(copies)]
        for key, r in chosen:
            censored = r["status"] != "solved"
            cost = budget if censored else r["cpu_net"]
            k = int(math.floor(math.log2(max(cost, E.FLOOR_ABS) / E.FLOOR_ABS)))
            pool = resid_pool.get(k) or resid_pool["__all__"]
            tb[d][key], bc[d][key] = cost, censored
            ts[d][key] = min(max(cost * 2 ** -(effect + rng.choice(pool)), 1e-3), budget)
    m, top, _ = E.measured_by_difficulty(tb, ts, bc, rng, boot=boot)
    return None if m is None else max(0.0, m[1]), top


def real_pair_credits(base, sub, budget, rng, trials, boot, copies=1):
    """Credits of `trials` ladders built by resampling the REAL paired instances (baseline record + the submission's record on the SAME
    instance) with replacement, copies x as many per dimension. No synthetic effect: the solver's real, instance-dependent speedup and its
    real failures (charged the cap, exactly as in a run) are what is resampled. None = inconclusive."""
    tb0, bc0 = E.per_dim_times(base, budget)
    ts0, _ = E.per_dim_times(sub, budget)
    out = []
    for _ in range(trials):
        tb, ts, bc = {}, {}, {}
        for d in tb0:
            ids = sorted(set(tb0[d]) & set(ts0.get(d, {})))
            tb[d], ts[d], bc[d] = {}, {}, {}
            for j in range(len(ids) * copies):
                i = rng.choice(ids)
                tb[d][j], ts[d][j], bc[d][j] = tb0[d][i], ts0[d][i], bc0[d][i]
        m, _, _ = E.measured_by_difficulty(tb, ts, bc, rng, boot=boot)
        out.append(None if m is None else max(0.0, m[1]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", required=True)
    ap.add_argument("--pair", action="append", required=True, help="a submission ladder measured against --baseline")
    ap.add_argument("--effects", type=float, nargs="+", default=[0, 1, 1.5, 2, 2.5, 3, 4])
    ap.add_argument("--threshold", type=float, default=1.0)
    ap.add_argument("--trials", type=int, default=200)
    ap.add_argument("--boot", type=int, default=150)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--copies", type=int, default=1, help="replicate the real baseline ladder this many times: the power of a ladder with "
                    "copies x the instances per dimension (same cost distribution)")
    ap.add_argument("--real-pairs", action="store_true", help="no synthetic effect: bootstrap the REAL paired instances of each --pair (its real, "
                    "instance-dependent speedup and real failures) and report P(credit >= threshold) for one seed and for ALL THREE seeds (the board credit "
                    "is the minimum over seeds); --copies scales the ladder")
    ap.add_argument("--resample", action="store_true", help="with --copies: draw each synthetic ladder's instances at random from the real ones "
                    "(the number of hard instances then varies from ladder to ladder, as for a genuinely larger ladder) instead of repeating them exactly")
    a = ap.parse_args()
    if a.real_pairs and a.copies > 1:
        raise SystemExit("REFUSED: --real-pairs with --copies > 1 would DUPLICATE the real submission costs (and their noise), so the bootstrap would "
                         "believe it has copies x the information and report an artificially tight bound and an inflated credit. Larger-ladder power needs "
                         "a noise model: use the synthetic mode with --copies and --resample.")
    mb, base = load(a.baseline)
    budget = mb["budget"]
    pool = defaultdict(list)
    for p in a.pair:
        ms, sub = load(p)
        if ms["commit"] != mb["commit"]:
            raise SystemExit(f"{p}: different instance set than the baseline")
        only_b, only_s = E.coverage_mismatch(base, sub)
        if only_b or only_s:
            raise SystemExit(f"{p}: does not cover the same instances as the baseline ({len(only_b)} only in the baseline, "
                             f"{len(only_s)} only in the pair); residuals from a truncated run would be biased")
        if a.real_pairs:
            rng = random.Random(a.seed)
            credits = real_pair_credits(base, sub, budget, rng, 3 * a.trials, a.boot, a.copies)
            ok = sorted(c for c in credits if c is not None)
            single = sum(c is not None and c >= a.threshold for c in credits) / len(credits)
            triples = [min(0.0 if c is None else c for c in credits[i:i + 3]) for i in range(0, len(credits) - 2, 3)]
            all3 = sum(c >= a.threshold for c in triples) / len(triples)
            pct = lambda q: ok[min(len(ok) - 1, int(q * len(ok)))] if ok else float("nan")
            n_real = max(len(v) for v in base.values())
            print(f"REAL pair {p.rsplit('/', 1)[-1]} bootstrapped: {n_real * a.copies} instances per size (x{a.copies}), {len(credits)} ladders, "
                  f"boot {a.boot}, threshold {a.threshold} bit(s)")
            print(f"  credit per ladder: median {pct(0.5):.2f}, 5th percentile {pct(0.05):.2f}, 95th {pct(0.95):.2f}, inconclusive "
                  f"{100 * (len(credits) - len(ok)) / len(credits):.0f}%")
            print(f"  P(one seed's credit >= {a.threshold}) = {100 * single:.1f}%")
            print(f"  P(ALL THREE seeds >= {a.threshold}) = {100 * all3:.1f}%   ({len(triples)} independent triples; the board credit is the minimum over seeds)")
    if a.real_pairs:
        return
        for k, v in residuals(base, sub, budget).items():
            pool[k] += v
            pool["__all__"] += v
    if not pool["__all__"]:
        raise SystemExit("no difficulty bin has >= 4 instances solved by both solvers; cannot estimate real noise")
    sd = {k: statistics.pstdev(v) for k, v in pool.items() if k != "__all__"}
    print("real per-instance noise (sd of paired log2 ratio, bits) by baseline-cost octave "
          f"[0.5*2^k s]: { {k: round(s, 2) for k, s in sorted(sd.items())} }")
    print(f"pooled residuals: {len(pool['__all__'])}; baseline timeouts kept censored; budget {budget}s")
    if a.copies > 1:
        n_real = max(len(v) for v in base.values())
        print(f"ladder replicated {a.copies}x: {n_real} -> {n_real * a.copies} instances per dimension, same cost distribution"
              + ("; instances RESAMPLED at random with replacement (hard-instance count varies per ladder)" if a.resample else ""))
    rng = random.Random(a.seed)
    print(f"\nP(Tier-1 credit >= {a.threshold} bit) by true effect ({a.trials} trials each):")
    for e in a.effects:
        credits = [synth_trial(base, budget, pool, e, rng, a.boot, a.copies, a.resample)[0] for _ in range(a.trials)]
        hit = sum(c is not None and c >= a.threshold for c in credits)
        incon = sum(c is None for c in credits)
        ok = [c for c in credits if c is not None]
        print(f"  true effect {e:4.1f} bits: {100 * hit / a.trials:5.1f}%   "
              f"(inconclusive {100 * incon / a.trials:3.0f}%, mean credit {np.mean(ok) if ok else 0:.2f})")


if __name__ == "__main__":
    main()
