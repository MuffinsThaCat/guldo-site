def solve(oracle, bits):
    q = 1
    while oracle(q):
        q += 1
    return q - 1
