"""aiprune in the counted-operations API, REFERENCE: the dense network, every hidden unit, one batched product per layer."""
import math

import tensorops as tp

C = 10
ZETA = 3.0


def solve(seed, d, Q):
    H = 4 * d
    W1 = tp.reshape(tp.stream(seed, 0, H * d), (H, d)) * math.sqrt(3.0 / d)
    gain = tp.exp((tp.stream(seed, H * d, H) + 1.0) * (-ZETA * math.log(10.0)))
    W2 = tp.reshape(tp.stream(seed, H * d + H, C * H), (C, H)) * math.sqrt(3.0 / H) * tp.reshape(gain, (1, H))
    X = tp.reshape(tp.stream(seed, H * d + H + C * H, Q * d), (Q, d))
    rows = (tp.relu(X @ tp.transpose(W1, (1, 0))) @ tp.transpose(W2, (1, 0))).tolist()
    return [row.index(max(row)) for row in rows]
