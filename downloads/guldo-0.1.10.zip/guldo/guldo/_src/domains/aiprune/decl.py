"""Declaration of a structured-pruning domain: classify a committed batch with a committed two-layer ReLU network, as cheaply as you can, at equivalent output, by removing the hidden units that do not matter.

size = d, the input dimension. The model has H = 4 d hidden units and 10 classes: W1 (H x d, scaled by sqrt(3/d)), a gain per hidden unit and W2 (10 x H, scaled by sqrt(3/H)), with NO biases, and the
batch holds Q = 8 d inputs of dimension d. They are NOT shipped as data: they are a pure function of one 63-bit seed through the pinned SplitMix64 stream that `aiinfer` and `aitrain` use (u in [-1, 1)):
    W1 = u[0 : H d] as H x d, times sqrt(3/d);    v = u[H d : H d + H];    gain_i = 10^(-3 (v_i + 1));
    W2 = u[H d + H : H d + H + 10 H] as 10 x H (row-major), times sqrt(3/H), with column i multiplied by gain_i;    X = the next Q d floats as Q x d (row-major).
Logits are W2 relu(W1 x). The gains span six orders of magnitude (1 down to 1e-6), so a minority of the hidden units carries almost all of the output: the network is PRUNABLE, and which units those are is
hidden in the weights (the gains are mixed into W2's columns, and the unit order is random), so a solver has to measure it.

The answer is the list of Q class labels (ints 0-9). The judge recomputes the float64 logits and accepts an answer in which every label is within 0.1 standard deviations (of all the instance's logits) of the best
logit of its sample, for at least 99% of the samples. That is the "equivalent result" the saving is conditional on: removing the units that matter, or too many of the ones that matter a little, fails the check
(solvers/aiprune_flops_hard.py).

STRUCTURED pruning only: dropping whole hidden units shrinks the matrix products, which the operation count sees. Zeroing individual weights (unstructured sparsity) does not shrink a dense product and earns
nothing here, as on most hardware; there is no sparse kernel in the counted API. The cost is counted operations (tflops.py): the arithmetic asked for, exactly reproducible, not a time; it cannot see memory
traffic, kernel quality or device speed.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aiprune"
VERSION = "aiprune-v1"        # bump whenever derive() or the model definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (32, 80)
SIZE_STEP = 16
REFERENCE_SOLVER = "reference.py"
CLASSES = 10
ZETA = 3.0                    # log10 spread of the hidden-unit gains
TOL_SIGMA = 0.1               # a label is acceptable if its logit >= max logit - TOL_SIGMA * std(all logits of the instance)
MAX_BAD_FRACTION = 0.01       # at most floor(0.01 * Q) labels may be unacceptable
DOC = ("solve(seed, d, Q): regenerate the model and the batch from `seed` with the SplitMix64 stream (tensorops.stream; u in [-1, 1)): H = 4d; W1 = u[0:H*d] as H x d times sqrt(3/d); "
       "v = u[H*d : H*d+H]; gain_i = 10^(-3 (v_i+1)); W2 = u[H*d+H : H*d+H+10*H] as 10 x H, times sqrt(3/H), column i times gain_i; X = u[H*d+H+10*H : +Q*d] as Q x d, Q = 8d. "
       "Logits = W2 relu(W1 x) (no biases). Return the list of Q class labels (ints 0-9). A label counts if its logit is within 0.1 standard deviations of the sample's best logit; "
       "at most 1% of labels may miss. Return None for no answer.")
REFERENCE_NOTE = ("The dense network: every hidden unit, both layers, one batched product each (float64). Known to be beaten by structured pruning: measure each unit's importance from its weights and "
                  "drop the ones whose output is a small fraction of the largest, which shrinks both products.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def model(seed, d):
    H, Q = 4 * d, 8 * d
    W1 = _uniform(seed, 0, H * d).reshape(H, d) * math.sqrt(3.0 / d)
    gain = 10.0 ** (-ZETA * (_uniform(seed, H * d, H) + 1.0))
    W2 = _uniform(seed, H * d + H, CLASSES * H).reshape(CLASSES, H) * math.sqrt(3.0 / H) * gain
    X = _uniform(seed, H * d + H + CLASSES * H, Q * d).reshape(Q, d)
    return W1, W2, X


def logits(seed, d):
    W1, W2, X = model(seed, d)
    return np.maximum(X @ W1.T, 0.0) @ W2.T


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aiprune-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, 8 * size], "planted": [int(v) for v in np.argmax(logits(seed, size), axis=1)]}


def verify(inst: dict, ans) -> bool:
    seed, d, Q = inst["args"]
    if not isinstance(ans, list) or len(ans) != Q:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or not 0 <= v < CLASSES for v in ans):
        return False
    L = logits(seed, d)
    ok = L[np.arange(Q), np.asarray(ans)] >= L.max(axis=1) - TOL_SIGMA * L.std()
    return bool(int((~ok).sum()) <= int(MAX_BAD_FRACTION * Q))
