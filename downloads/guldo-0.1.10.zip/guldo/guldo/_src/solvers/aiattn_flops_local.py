"""aiattn in the counted-operations API, LOSSY CHEAT: each query attends only to its own block of 32 positions, not to the previous block that the window also reaches. Cheaper; the judge's output check must reject it."""
import math

import tensorops as tp

D = 16
WINDOW = 32
QK = 3.0


def solve(seed, n):
    m = n * D
    W = WINDOW
    Q = tp.stream(seed, 0, m, (n, D)) * QK
    K = tp.stream(seed, m, m, (n, D)) * QK
    V = tp.stream(seed, 2 * m, m, (n, D))
    M = tp.causal_mask(W)
    parts = []
    for b in range(n // W):
        S = tp.einsum("id,jd->ij", Q[b * W:(b + 1) * W], K[b * W:(b + 1) * W]) / math.sqrt(D) + M
        E = tp.exp(S - tp.max(S, 1, True))
        parts.append((E / tp.sum(E, 1, True)) @ V[b * W:(b + 1) * W])
    return [int(x * 65536.0) for x in tp.reshape(tp.concat(parts, 0), (n * D,)).tolist()]
