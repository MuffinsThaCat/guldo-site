"""Does the roofline form predict REAL kernel times on THIS device? A calibration anyone can run in a few minutes, on any device PyTorch supports (Apple GPU, NVIDIA GPU, or the CPU).

  python3 gpu_roofline.py calibrate [--device mps|cuda|cpu] [--dtypes fp32,fp16] [--quick] [--out F.json]
  python3 gpu_roofline.py check F.json                                     recompute every prediction and error in a saved calibration from its own measured times

Why it exists. roofline.py turns exact counted flops and bytes into exact statements about speed on ANY device (dominance, crossover). That is hardware-free but it is a MODEL; a skeptic's question is whether
the model's form, time ~ launch overhead + max(flops / F, bytes / B), describes real hardware. This measures it. It times simple kernels, fits the three constants (the launch overhead c, the memory
bandwidth B, the compute rate F per precision) from them ALONE, and then asks how well those constants predict kernels that were NOT used to fit them: a matrix-vector product, an unfused softmax, an MLP block.
It also checks the quantity the project actually claims, a RATIO between two techniques: fp16 against fp32 on the same shape, predicted from counts against measured.

Timing note: each kernel is timed as a batch of back-to-back calls with the device synchronised only around the batch, so the figure is the throughput of a stream of launches (launch latency is overlapped
by the queue, which is why the fitted launch overhead can come out near zero) and not the latency of one isolated call.

Counts follow tensorops_mem.py's convention (every operation reads its operands and writes its result, no cache, no fusion, flops from the tensorops cost table), and every kernel here is a chain of separate
framework operations so the unfused convention is the right one to compare with. A test pins these formulas to the real counter.

What a good result means and does not: it shows the roofline form fits THIS device on THESE kernels. It does not show it fits other devices (run it on them), real fused kernels (a fused kernel moves fewer bytes
than the unfused count, so the model overstates its time), or tiny sizes (launch overhead dominates; the fitted c absorbs it). The error table says exactly where it fails.
"""
import argparse
import json
import math
import os
import platform
import statistics
import subprocess
import sys
import time

import numpy as np

WIDTH = {"fp32": 4, "fp16": 2}


def ops_add(n, w):
    return [(n, 3 * n * w)]


def ops_matmul(n, w):
    return [(2 * n ** 3, 3 * n * n * w)]


def ops_gemv(d, w):
    return [(2 * d * d, (d * d + 2 * d) * w)]


def ops_softmax(r, c, w):
    """max, subtract, exp, sum, divide as five separate operations, exactly as tensorops_mem counts them."""
    rc = r * c
    return [(rc, (rc + r) * w), (rc, (2 * rc + r) * w), (rc, 2 * rc * w), (rc, (rc + r) * w), (rc, (2 * rc + r) * w)]


def ops_train_step(n, d, k, w):
    """One step of the aitrain scaled-gradient-descent technique as ten separate operations: Z = X @ W, max, subtract, exp, sum, divide, subtract the labels, X^T @ G, scale, subtract from W."""
    nk, dk = n * k, d * k
    return [(2 * n * d * k, (n * d + d * k + n * k) * w), (nk, (nk + n) * w), (nk, (2 * nk + n) * w), (nk, 2 * nk * w), (nk, (nk + n) * w), (nk, (2 * nk + n) * w), (nk, 3 * nk * w),
            (2 * d * n * k, (d * n + n * k + d * k) * w), (dk, 2 * dk * w), (dk, 3 * dk * w)]


def ops_mlp(b, d, h, w):
    """x @ W1, relu, @ W2."""
    return [(2 * b * d * h, (b * d + d * h + b * h) * w), (b * h, 2 * b * h * w), (2 * b * h * d, (b * h + h * d + b * d) * w)]


def kernel_specs(dtypes, quick):
    """-> [(name, group, dtype, ops)] where ops = [(flops, bytes), ...] is the counted work of each framework operation in the chain. group 'fit' is used to fit the constants, 'holdout' only to test them."""
    out = []
    adds = [1 << k for k in ((20, 22, 24) if quick else range(16, 26))]
    mms = (512, 1024, 2048) if quick else (128, 256, 512, 1024, 2048, 4096)
    gemvs = (2048, 4096) if quick else (1024, 2048, 4096, 8192)
    sm_cols = (512, 2048) if quick else (128, 256, 512, 1024, 2048)
    mlp_b = (64, 1024)
    for dt in dtypes:
        w = WIDTH[dt]
        for n in adds:
            out.append((f"add n={n}", "fit", dt, ops_add(n, w)))
        for n in mms:
            out.append((f"matmul {n}^3", "fit", dt, ops_matmul(n, w)))
        for d in gemvs:
            out.append((f"gemv d={d}", "holdout", dt, ops_gemv(d, w)))
        r = 8192
        for c in sm_cols:
            out.append((f"softmax {r}x{c} (5 ops)", "holdout", dt, ops_softmax(r, c, w)))
        for n, d_ in (((16384, 1024),) if quick else ((16384, 1024), (32768, 512))):
            out.append((f"train step n={n} d={d_} k=3 (10 ops)", "holdout", dt, ops_train_step(n, d_, 3, w)))
        d, h = 2048, 8192
        for b in mlp_b:
            out.append((f"mlp b={b} d={d} h={h} (3 ops)", "holdout", dt, ops_mlp(b, d, h, w)))
    return out


def make_runner(torch, device, dtype_name, name):
    dt = {"fp32": torch.float32, "fp16": torch.float16}[dtype_name]
    g = lambda *shape: torch.randn(*shape, device=device, dtype=dt)
    if name.startswith("add"):
        n = int(name.split("n=")[1])
        a, b = g(n), g(n)
        return lambda: a + b
    if name.startswith("matmul"):
        n = int(name.split()[1].split("^")[0])
        a, b = g(n, n), g(n, n)
        return lambda: a @ b
    if name.startswith("gemv"):
        d = int(name.split("d=")[1])
        W, x = g(d, d), g(d)
        return lambda: W @ x
    if name.startswith("softmax"):
        r, c = (int(v) for v in name.split()[1].split("x"))
        x = g(r, c)

        def run():
            m = x.max(1, keepdim=True).values
            s = x - m
            e = s.exp()
            z = e.sum(1, keepdim=True)
            return e / z
        return run
    if name.startswith("train"):
        n, d = (int(v.split("=")[1]) for v in name.split()[2:4])
        Xs, W, Y = g(n, d), g(d, 3), g(n, 3)

        def step():
            Z = Xs @ W
            m = Z.max(1, keepdim=True).values
            E = (Z - m).exp()
            G = E / E.sum(1, keepdim=True) - Y
            return W - (Xs.t() @ G) * 0.01
        return step
    if name.startswith("mlp"):
        b = int(name.split("b=")[1].split()[0])
        d, h = 2048, 8192
        x, W1, W2 = g(b, d), g(d, h), g(h, d)
        return lambda: torch.relu(x @ W1) @ W2
    raise ValueError(name)


def measure(run, sync, min_time=0.03, trials=7):
    """Median seconds per call over `trials` batches, each long enough to swamp timer noise; the device is synchronised around every batch."""
    for _ in range(3):
        run()
    sync()
    reps = 1
    while True:
        t = time.perf_counter()
        for _ in range(reps):
            run()
        sync()
        if time.perf_counter() - t >= min_time or reps >= 1 << 14:
            break
        reps *= 2
    per = []
    for _ in range(trials):
        t = time.perf_counter()
        for _ in range(reps):
            run()
        sync()
        per.append((time.perf_counter() - t) / reps)
    return statistics.median(per)


def fit(rows):
    """Fit (c, B, F per precision) from the 'fit' rows ONLY. Memory-bound adds give c and B (a line through bytes vs time); large compute-bound matmuls give each precision's F."""
    adds = [r for r in rows if r["group"] == "fit" and r["name"].startswith("add") and r["bytes"] >= (1 << 22)]
    slope, c = np.polyfit([r["bytes"] for r in adds], [r["measured"] for r in adds], 1)
    c = max(float(c), 0.0)
    B = 1.0 / float(slope)
    F = {}
    for dt in sorted({r["dtype"] for r in rows}):
        mm = [r for r in rows if r["group"] == "fit" and r["dtype"] == dt and r["name"].startswith("matmul") and r["flops"] >= 2 * 1024 ** 3]
        num = sum(r["flops"] * max(r["measured"] - c, 1e-12) for r in mm)
        den = sum(r["flops"] ** 2 for r in mm)
        F[dt] = den / num
    return {"launch_overhead_s": c, "bandwidth_Bps": B, "compute_flops": F}


def predict(consts, dtype, ops):
    c, B, F = consts["launch_overhead_s"], consts["bandwidth_Bps"], consts["compute_flops"][dtype]
    return sum(c + max(f / F, b / B) for f, b in ops)


def summarise(rows):
    def stats(sel):
        errs = [abs(r["predicted"] / r["measured"] - 1.0) for r in sel]
        if not errs:
            return None
        errs.sort()
        return {"n": len(errs), "median_abs_error": errs[len(errs) // 2], "p90_abs_error": errs[min(len(errs) - 1, int(0.9 * len(errs)))], "max_abs_error": errs[-1],
                "within_25_percent": sum(e <= 0.25 for e in errs) / len(errs)}
    out = {"fit_set": stats([r for r in rows if r["group"] == "fit"]), "holdout_set": stats([r for r in rows if r["group"] == "holdout"])}
    by_group = {}
    for r in rows:
        if r["group"] == "holdout":
            by_group.setdefault(r["name"].split()[0], []).append(r)
    out["holdout_by_kernel"] = {k: stats(v) for k, v in sorted(by_group.items())}
    ratios = []                       # the project's own quantity: a ratio between two techniques (fp16 against fp32 on the same shape), predicted from counts against measured
    by_name = {}
    for r in rows:
        by_name.setdefault(r["name"], {})[r["dtype"]] = r
    for name, d in sorted(by_name.items()):
        if "fp32" in d and "fp16" in d:
            meas = d["fp32"]["measured"] / d["fp16"]["measured"]
            pred = d["fp32"]["predicted"] / d["fp16"]["predicted"]
            ratios.append({"kernel": name, "group": d["fp32"]["group"], "measured_fp32_over_fp16": meas, "predicted_fp32_over_fp16": pred, "ratio_error": pred / meas - 1.0})
    out["fp16_vs_fp32_ratios"] = ratios

    def ratio_stats(sel):
        errs = sorted(abs(x["ratio_error"]) for x in sel)
        return {"n": len(errs), "median_abs_error": errs[len(errs) // 2], "max_abs_error": errs[-1],
                "same_side_of_one": sum((x["measured_fp32_over_fp16"] > 1) == (x["predicted_fp32_over_fp16"] > 1) for x in sel) / len(sel)}
    if ratios:
        out["fp16_vs_fp32_ratio_summary"] = ratio_stats(ratios)
        hold = [x for x in ratios if x["group"] == "holdout"]
        if hold:                                          # only kernels that were NEVER used to fit the constants: the fair test
            out["fp16_vs_fp32_ratio_summary_holdout"] = ratio_stats(hold)
    return out


def device_info(torch, device):
    info = {"device": device, "torch": torch.__version__, "platform": platform.platform(), "python": platform.python_version()}
    try:
        if device == "cuda":
            info["name"] = torch.cuda.get_device_name(0)
        elif sys.platform == "darwin":
            txt = subprocess.run(["system_profiler", "SPDisplaysDataType"], capture_output=True, text=True, timeout=30).stdout
            info["name"] = next((ln.split(":", 1)[1].strip() for ln in txt.splitlines() if "Chipset Model" in ln), "unknown")
        else:
            info["name"] = platform.processor() or "unknown"
    except Exception as e:             # best effort: a missing name must not stop a calibration
        info["name"] = f"unknown ({type(e).__name__})"
    return info


def cmd_calibrate(a):
    import torch
    device = a.device or ("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    dtypes = [d for d in a.dtypes.split(",") if d]
    if any(d not in WIDTH for d in dtypes):
        sys.exit("--dtypes: fp32 and/or fp16")
    sync = {"cuda": torch.cuda.synchronize, "mps": torch.mps.synchronize if hasattr(torch, "mps") else (lambda: None)}.get(device, lambda: None)
    torch.manual_seed(0)
    rows = []
    for name, group, dt, ops in kernel_specs(dtypes, a.quick):
        runner = make_runner(torch, device, dt, name)
        t = measure(runner, sync)
        rows.append({"name": name, "group": group, "dtype": dt, "flops": sum(f for f, _ in ops), "bytes": sum(b for _, b in ops), "ops": ops, "measured": t})
        print(f"  {name:38s} {dt}  {t * 1e3:9.4f} ms", flush=True)
    consts = fit(rows)
    for r in rows:
        r["predicted"] = predict(consts, r["dtype"], r["ops"])
        r["rel_error"] = r["predicted"] / r["measured"] - 1.0
    result = {"format": "svp-gpu-roofline-calibration-v1", "device": device_info(torch, device), "dtypes": dtypes, "quick": bool(a.quick), "constants": consts, "kernels": rows, "summary": summarise(rows),
              "limits": ["a fit of the roofline form to THIS device on THESE kernels: it says nothing about other devices (run it on them) or about fused kernels, which move fewer bytes than the unfused count",
                         "the constants are fitted from the 'fit' kernels only; the 'holdout' kernels were never used to fit them, which is what makes their error informative",
                         "timings are one operator's measurements on one machine: this checks a MODEL's form, it does not make any time independently verifiable"]}
    print(render(result))
    if a.out:
        if os.path.exists(a.out):
            sys.exit(f"{a.out} exists; a calibration is never overwritten")
        fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=1)
        print(f"wrote {a.out}")


def render(r):
    c = r["constants"]
    s = r["summary"]
    lines = [f"\nDEVICE {r['device'].get('name')} ({r['device']['device']}), torch {r['device']['torch']}",
             f"fitted: launch overhead {c['launch_overhead_s'] * 1e6:.1f} us per operation, bandwidth {c['bandwidth_Bps'] / 1e9:.0f} GB/s, compute " + ", ".join(f"{k} {v / 1e12:.2f} TFLOP/s" for k, v in c["compute_flops"].items())]
    for key, label in (("fit_set", "kernels used to fit"), ("holdout_set", "HOLDOUT kernels (never used to fit)")):
        st = s[key]
        if st:
            lines.append(f"  {label}: {st['n']} kernels, median |error| {st['median_abs_error'] * 100:.0f}%, 90th percentile {st['p90_abs_error'] * 100:.0f}%, worst {st['max_abs_error'] * 100:.0f}%, within 25%: {st['within_25_percent'] * 100:.0f}%")
    for k, st in s["holdout_by_kernel"].items():
        lines.append(f"      holdout {k:8s}: median |error| {st['median_abs_error'] * 100:.0f}%, worst {st['max_abs_error'] * 100:.0f}% over {st['n']}")
    for key, label in (("fp16_vs_fp32_ratio_summary_holdout", "HOLDOUT shapes"), ("fp16_vs_fp32_ratio_summary", "all shapes")):
        q = s.get(key)
        if q:
            lines.append(f"  the claim that matters, fp32 time / fp16 time on the same shape, predicted vs measured ({label}): median |error| {q['median_abs_error'] * 100:.0f}%, worst {q['max_abs_error'] * 100:.0f}%, "
                         f"same side of 1 in {q['same_side_of_one'] * 100:.0f}% of {q['n']}")
    return "\n".join(lines)


def cmd_check(a):
    with open(a.file, encoding="utf-8") as f:
        r = json.load(f)
    if r.get("format") != "svp-gpu-roofline-calibration-v1":
        sys.exit("not a calibration file")
    rows = r["kernels"]
    consts = fit(rows)
    ok = all(math.isclose(consts["bandwidth_Bps"], r["constants"]["bandwidth_Bps"], rel_tol=1e-9) for _ in (0,))
    for dt, v in consts["compute_flops"].items():
        ok = ok and math.isclose(v, r["constants"]["compute_flops"][dt], rel_tol=1e-9)
    for row in rows:
        ok = ok and math.isclose(predict(consts, row["dtype"], row["ops"]), row["predicted"], rel_tol=1e-9)
    print(("CONFIRMED: every constant and prediction follows from the recorded measurements" if ok else "NOT CONFIRMED: the recorded constants or predictions do not follow from the recorded measurements"))
    print("(this checks the arithmetic of the fit, not that the timings were honest: they are one operator's measurements)")
    sys.exit(0 if ok else 1)


def cmd_agree(a):
    """Do two calibrations of (nominally) the same device agree? The independent-party check that needs no trust in either operator's submissions, only two runs of the same small script."""
    docs = []
    for path in (a.file_a, a.file_b):
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        if d.get("format") != "svp-gpu-roofline-calibration-v1":
            sys.exit(f"{path}: not a calibration file")
        docs.append(d)
    A, B = docs
    problems = []
    if (A["device"].get("name"), A["device"].get("device")) != (B["device"].get("name"), B["device"].get("device")):
        problems.append(f"different devices: {A['device'].get('name')} ({A['device'].get('device')}) against {B['device'].get('name')} ({B['device'].get('device')})")
    rows = []
    pairs = [("bandwidth", A["constants"]["bandwidth_Bps"], B["constants"]["bandwidth_Bps"])]
    for dt in sorted(set(A["constants"]["compute_flops"]) & set(B["constants"]["compute_flops"])):
        pairs.append((f"compute {dt}", A["constants"]["compute_flops"][dt], B["constants"]["compute_flops"][dt]))
    for label, x, y in pairs:
        diff = abs(x / y - 1.0)
        rows.append((label, x, y, diff))
        if diff > a.tolerance:
            problems.append(f"{label} differs by {diff * 100:.0f}% (tolerance {a.tolerance * 100:.0f}%)")
    for label, x, y, diff in rows:
        print(f"  {label:14s} {x:.4g} vs {y:.4g}  ({diff * 100:.1f}% apart)")
    print(("DISAGREE: " + "; ".join(problems)) if problems else f"AGREE: same device and every fitted constant within {a.tolerance * 100:.0f}%")
    print("(two operators' measurements of one device model; agreement makes a fluke or a doctored run less likely, it is not a proof)")
    sys.exit(1 if problems else 0)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("calibrate")
    p.add_argument("--device", choices=("mps", "cuda", "cpu"))
    p.add_argument("--dtypes", default="fp32,fp16")
    p.add_argument("--quick", action="store_true", help="fewer and smaller kernels (about a minute)")
    p.add_argument("--out")
    p = sub.add_parser("check")
    p.add_argument("file")
    p = sub.add_parser("agree", help="do two calibrations of the same device model agree?")
    p.add_argument("file_a")
    p.add_argument("file_b")
    p.add_argument("--tolerance", type=float, default=0.15, help="the largest relative difference allowed in any fitted constant (default 0.15)")
    a = ap.parse_args(argv)
    return {"calibrate": cmd_calibrate, "check": cmd_check, "agree": cmd_agree}[a.cmd](a)


if __name__ == "__main__":
    main()
