"""INTERACTIVE challenges: an attack that needs an oracle (decryption-failure, chosen-ciphertext, side-channel or fault ATTACK MODELS, a signing or leakage oracle, a bit-leak).
New files only (oracle_core.py, oracle_runner.py): nothing in rounds.CODE_FILES or COUNT_FILES changes.

The solver is `solve(oracle, *args)`. `oracle(query)` takes and returns JSON values; every call is one QUERY and is counted. What is scored is the QUERY COUNT, a cost anyone can recompute
exactly: the full transcript (query, reply) is recorded and hashed, and a verifier replays it (`replay`) through the same solver under the same step counter, demanding the identical
query sequence, answer and step count, and, with the declaration, that every reply is what the oracle really says.

Declaration (operator code, extra names beside NAME/VERSION/SIZE_RANGE/REFERENCE_SOLVER/derive/verify):
    oracle_open(inst) -> state          a plain object built from the instance (the secret is in inst["planted"] or derived from it); deterministic
    oracle(state, query) -> reply       a JSON value. Pure in (state, query history). May raise: that query is charged and the reply is null
    QUERY_BUDGET        the most queries per instance (default 1000)         QUERY_UNIT   queries that count as one "second" of cost (default 100)

What this is NOT: a measurement of any real device. The oracle is the declaration's MODEL of the leak or the decryption service; a claim is "an attacker with THIS oracle needs this many
queries", and it is exactly as good as the model (the operator READS decl.py, as for every declaration). Time is not scored here: a solver is bounded by the step limit only. Quantum, timing and
power side channels are not measured; a model of one is a declared oracle.
"""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(HERE, "oracle_runner.py")
MAX_LINE = 1 << 16
MAX_TRANSCRIPT = 4 << 20   # bytes of queries + replies one instance may produce: a record carries its transcript, so this bounds every ladder file and every replay
DEFAULT_BUDGET = 1000
DEFAULT_UNIT = 100
STEP_LIMIT = 200_000_000


def settings(mod):
    b, u = getattr(mod, "QUERY_BUDGET", DEFAULT_BUDGET), getattr(mod, "QUERY_UNIT", DEFAULT_UNIT)
    ok = lambda v, hi: isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= hi   # noqa: E731
    if not (ok(b, 10 ** 6) and ok(u, 10 ** 6)):
        raise ValueError("QUERY_BUDGET and QUERY_UNIT must be integers from 1 to 1000000")
    return b, u


def is_oracle(mod):
    return callable(getattr(mod, "oracle", None)) and callable(getattr(mod, "oracle_open", None))


def transcript_sha256(transcript):
    return hashlib.sha256(json.dumps(transcript, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def live_oracle(mod, inst):
    """-> oracle_fn(query) -> reply, answering from the declaration. Replies are round-tripped through JSON so a mutable object of the declaration never reaches the solver's side."""
    state = mod.oracle_open(inst)

    def fn(query):
        try:
            return json.loads(json.dumps(mod.oracle(state, query), allow_nan=False))
        except Exception:
            return None
    return fn


def transcript_oracle(transcript):
    """-> oracle_fn serving a recorded transcript; raises ReplayMismatch the moment the solver asks something the record does not hold."""
    it = iter(transcript)

    def fn(query):
        try:
            q, r = next(it)
        except StopIteration:
            raise ReplayMismatch("the solver asked more queries than the record holds")
        if json.dumps(q, sort_keys=True) != json.dumps(query, sort_keys=True):
            raise ReplayMismatch("the solver asked a different query than the record holds")
        return r
    return fn


class ReplayMismatch(Exception):
    pass


def run(solver, args, oracle_fn, budget=DEFAULT_BUDGET, step_limit=STEP_LIMIT, wall=120):
    """Run one solver on one instance against `oracle_fn`. -> {"status": ok|limit|error|queries|timeout|replay, "steps", "ans", "queries", "transcript", "err"}.
    `queries` is over-budget -> the child is killed and the run is "queries" (it did not finish within the budget)."""
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "PATH": os.environ.get("PATH", "")}
    transcript, size, res = [], 0, {"status": "error", "steps": 0, "ans": None, "err": "no result"}
    deadline = time.time() + wall
    with tempfile.TemporaryDirectory() as empty:
        p = subprocess.Popen([sys.executable, "-B", RUNNER, os.path.abspath(solver)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env, cwd=empty)
        timer = threading.Timer(wall, p.kill)   # the deadline check below runs only between lines: a solver stuck inside ONE long C call would block readline for ever
        timer.daemon = True
        timer.start()
        try:
            p.stdin.write((json.dumps({"args": args, "limit": step_limit}, allow_nan=False) + "\n").encode())
            p.stdin.flush()
            while True:
                if time.time() > deadline:
                    res = {"status": "timeout", "steps": None, "ans": None, "err": "wall-clock backstop"}
                    break
                line = p.stdout.readline(MAX_LINE + 2)
                if not line:
                    timed_out = time.time() >= deadline
                    res = ({"status": "timeout", "steps": None, "ans": None, "err": "wall-clock backstop"} if timed_out
                           else {"status": "error", "steps": None, "ans": None, "err": "the solver process ended without a result"})
                    break
                if len(line) > MAX_LINE:
                    res = {"status": "error", "steps": None, "ans": None, "err": "a query is too long"}
                    break
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue   # stray output on the real stdout is not a message
                if isinstance(msg, dict) and "q" in msg:
                    if len(transcript) >= budget:
                        res = {"status": "queries", "steps": None, "ans": None, "err": f"more than {budget} queries"}
                        break
                    try:
                        reply = oracle_fn(msg["q"])
                    except ReplayMismatch as e:
                        res = {"status": "replay", "steps": None, "ans": None, "err": str(e)}
                        break
                    wire = json.dumps({"r": reply}, allow_nan=False)
                    if len(wire) > MAX_LINE:
                        reply, wire = None, '{"r": null}'   # an over-long reply is refused like a malformed query, never sent
                    size += len(line) + len(wire)
                    if size > MAX_TRANSCRIPT:
                        res = {"status": "queries", "steps": None, "ans": None, "err": "the transcript is larger than the limit"}
                        break
                    transcript.append([msg["q"], reply])
                    p.stdin.write((wire + "\n").encode())
                    p.stdin.flush()
                elif isinstance(msg, dict) and "status" in msg:
                    res = {"status": msg["status"], "steps": msg.get("steps"), "ans": msg.get("ans"), "err": str(msg.get("err", ""))[-300:]}
                    break
        except (OSError, ValueError, TypeError, RecursionError):   # OSError includes BrokenPipeError; ValueError: a reply that is not strict JSON (NaN) cannot be sent
            res = {"status": "error", "steps": None, "ans": None, "err": "the solver process closed its pipe, or a reply could not be sent"}
        finally:
            timer.cancel()
            p.kill()
            p.wait()
            for pipe in (p.stdin, p.stdout):   # close() on a pipe with unflushed data re-raises the BrokenPipeError that brought us here, and would escape this function
                try:
                    pipe.close()
                except OSError:
                    pass
    res.update({"queries": len(transcript), "transcript": transcript})
    return res


def evaluate(mod, solver, inst, budget=None, step_limit=STEP_LIMIT):
    """One ladder record for `inst` (a dict from derive() with "id" and "dim"). status: solved / wrong / failed / crash / timeout (timeout = over the query budget or the step limit)."""
    b, unit = settings(mod)
    budget = b if budget is None else budget
    r = run(solver, inst["args"], live_oracle(mod, inst), budget, step_limit)
    rec = {"id": inst["id"], "dim": inst["dim"], "queries": r["queries"], "steps": r["steps"], "transcript_sha256": transcript_sha256(r["transcript"]), "transcript": r["transcript"]}
    if r["status"] == "ok":
        try:
            ok = bool(mod.verify(inst, r["ans"]))
        except Exception:
            ok = False
        rec["status"] = "solved" if ok else ("failed" if r["ans"] is None else "wrong")
        rec["ans"] = r["ans"]
    elif r["status"] in ("queries", "limit", "timeout"):
        rec["status"] = "timeout"
    else:
        rec["status"], rec["err"] = "crash", r["err"]
    # the cost the estimator reads: queries in units, floored like every ladder; an unsolved instance is charged the full budget
    q = rec["queries"] if rec["status"] == "solved" else budget
    rec["cpu"] = rec["cpu_net"] = max(q / unit, 1e-3)
    return rec


def replay(mod, solver, inst, rec, step_limit=STEP_LIMIT):
    """Independent check of one record. -> (ok, [reasons]). Demands: the transcript hash is the record's; the solver, fed ONLY the recorded replies, asks the identical queries, gives the
    recorded answer in the recorded step count; every reply is what the declaration's oracle says now; and a record claimed solved has an answer verify() accepts."""
    why = []
    t = rec.get("transcript")
    if not isinstance(t, list) or len(t) > settings(mod)[0] or not all(isinstance(e, list) and len(e) == 2 for e in t) or len(json.dumps(t)) > MAX_TRANSCRIPT:
        return False, ["the transcript is not a list of [query, reply] pairs within the budget and size limits"]   # a hostile record must not make the verifier allocate or loop without bound
    try:
        if transcript_sha256(rec["transcript"]) != rec.get("transcript_sha256"):
            why.append("the transcript does not hash to the recorded value")
    except (ValueError, TypeError, RecursionError):   # NaN or a non-JSON shape in a hostile record
        return False, ["the transcript is not strict JSON"]
    live = live_oracle(mod, inst)
    for i, (q, r) in enumerate(rec["transcript"]):
        if json.dumps(live(q), sort_keys=True) != json.dumps(r, sort_keys=True):
            why.append(f"reply {i} differs from the oracle's")
            break
    r = run(solver, inst["args"], transcript_oracle(rec["transcript"]), max(len(rec["transcript"]), 1), step_limit)
    if r["status"] == "replay":
        why.append(r["err"])
    elif r["status"] == "ok":
        if r["queries"] != len(rec["transcript"]):
            why.append("the solver asked fewer queries than the record holds")
        if r["steps"] != rec.get("steps"):
            why.append(f"step count {r['steps']} != recorded {rec.get('steps')}")
        if rec.get("status") == "solved":
            if r["ans"] != rec.get("ans"):
                why.append("the replayed answer differs from the recorded one")
            elif not mod.verify(inst, r["ans"]):
                why.append("the answer is not accepted by verify()")
    elif rec.get("status") == "solved":
        why.append(f"the replay did not finish ({r['status']})")
    return (not why), why
