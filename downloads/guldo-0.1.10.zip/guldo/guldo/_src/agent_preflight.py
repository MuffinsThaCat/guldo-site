"""Preflight for a REAL agent run: every check that can be made WITHOUT calling a model, so the first live run does not waste money or produce a result nobody can use.

  python3 agent_tools.py preflight --plan PLAN.json --agent anthropic:MODEL[:EFFORT] (--seed FILE | --practice) --out LADDER.jsonl [--price-in P --price-out P] [--pilot-done] [--resume]

Nothing here sends a request, prints a key, or runs an agent (it BUILDS the agent object, which constructs the SDK client locally). MEASURED against the real `anthropic` SDK 2.14.0 with every socket
blocked: the constructor makes no network call and does NOT raise without a credential; the credential check here is the SDK's own offline validation (`credentials_resolve`), which also sees a stored
login. Other SDK versions may differ: then the answer is 'cannot tell' and the environment is the fallback. It mirrors the guards `agent_eval.py run` applies and adds the ones that only matter before spending: is the seed where hostile
code cannot read it, will the result be attested, how much could this cost at most, is there a one-instance pilot first. Each line is OK, NOTE (worth knowing), WARN (a real risk you may accept)
or FAIL (do not run); the exit status is 0 unless something FAILs. It ends by printing the exact command to run next, never running it.

What it cannot know: whether the provider will accept the key, that the model name exists, or what the run will cost (the figure it prints is a CEILING built from the plan's token cap and the
prices YOU give; none is built in). A first run with `--n 1` plan is the check for those.
"""
import json
import os
import stat

import agent_core
import agent_eval
import agent_providers

HERE = os.path.dirname(os.path.abspath(__file__))
OK, NOTE, WARN, FAIL = "OK", "NOTE", "WARN", "FAIL"
# CALIBRATION of provider-billed tokens against this project's proxy token counts, fitted by least squares on the 155 real model calls of the 27 Nov live runs (agent_eval/real_runs_2026-11-27/
# anthropic_live; 14 trials; practice seed; research domain, sizes 1-3). Per call: billed_input = A * proxy_in + B, and billed_output = R * proxy_out. The slope A is the crude bytes/4 counter's
# undercount of JSON-dense text; B is a fixed per-call overhead (about what the API's own injected tool-use prompt would be). Held out: the model fitted WITHOUT one trial predicted that trial's billed
# input to +0.6%. Output is model-dependent (the Sonnet figure includes hidden thinking tokens). NOT calibrated: other models, other domains, long contexts, anything with prompt caching or retries.
# model substring -> (A, B, R_out, n calls, R^2 of the input fit)
CALIBRATION = {"haiku": (1.477, 387.2, 2.13, 92, 0.9970), "sonnet": (1.589, 250.6, 3.55, 63, 0.9854)}
CAL_FALLBACK = (1.6, 390.0, 3.7)           # a model nobody measured: the worst of each measured value, rounded up
OUTPUT_SHARE = 0.056                       # share of a trial's proxy tokens that are the model's output (4,624 of 82,664 in the live runs)
BILLED_PER_PROXY_WORST = 4.2               # the largest per-call billed/proxy ratio seen (4.15, haiku output): the pessimistic bound's multiplier


def calibration_for(agent_spec):
    """-> ((A, B, R_out), note). The measured calibration for the model named in `agent_spec`, or the pessimistic fallback with a note saying it is borrowed."""
    name = str(agent_spec).lower()
    try:                                                                              # calibrations recorded by `agent_calibrate.py write` (a specific model id beats the families below)
        import agent_calibrate
        recorded, problem = agent_calibrate.load_table()
    except ImportError:
        recorded, problem = {}, None
    key = agent_calibrate.match_key(recorded, name) if recorded else None
    if key:
        a, b, r, n, r2 = recorded[key]
        return (a, b, r), "calibrated on %d real %s calls recorded in agent_calibration.json (input fit R^2 %.3f)" % (n, key, r2)
    for key, (a, b, r, n, r2) in CALIBRATION.items():
        if key in name:
            return (a, b, r), "calibrated on %d real %s calls (input fit R^2 %.3f)" % (n, key, r2)
    return CAL_FALLBACK, "NOT calibrated for this model: the worst measured values are borrowed" + ("; the recorded calibration file was IGNORED (%s)" % problem if problem else "")


def estimate_trial_cost(cap, max_turns, price_in, price_out, agent_spec):
    """Money for ONE trial that runs to its proxy-token cap over `max_turns` calls, from the calibration. billed input is linear in the proxy count (A per token, B per call), so summing over calls
    gives A * (input share of cap) + B * calls exactly; output is R * its share."""
    (a, b, r), note = calibration_for(agent_spec)
    billed_in = a * cap * (1 - OUTPUT_SHARE) + b * max_turns
    billed_out = r * cap * OUTPUT_SHARE
    return (billed_in * price_in + billed_out * price_out) / 1e6, billed_in, billed_out, note
PILOT_TRIALS = 6         # a plan with more trials than this should have had a one-instance pilot first


def _inside(path, root):
    path, root = os.path.realpath(path), os.path.realpath(root)
    return path == root or path.startswith(root + os.sep)


def _in_a_git_checkout(path):
    d = os.path.dirname(os.path.realpath(path))
    while True:
        if os.path.exists(os.path.join(d, ".git")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return None
        d = parent


def _looks_like_a_container():
    if os.path.exists("/.dockerenv") or os.environ.get("container"):
        return True
    try:
        with open("/proc/1/cgroup", "r", encoding="utf-8") as f:
            txt = f.read()
        return any(w in txt for w in ("docker", "containerd", "kubepods", "lxc"))
    except OSError:
        return False


def pilot_cost_stats(ladder_paths, price_in, price_out):
    """Measured cost per trial from pilot ladders that carry the PROVIDER's own usage numbers (a real run records them per turn): {"n", "mean", "max"} in the currency of the prices, or None if no trial has
    usage (a scripted agent reports none). This is the number a go/no-go decision needs: trials usually stop far short of their cap, and the cap-based estimates cannot know that."""
    costs, models = [], set()
    for path in ladder_paths or []:
        try:
            header, recs = agent_core.read_ladder(path)
        except (agent_core.AgentEvalError, OSError, ValueError):
            continue
        agent = header.get("agent") if isinstance(header, dict) else None
        models.add(agent.get("model") if isinstance(agent, dict) else None)
        for rec in recs:
            usage = [t.get("usage") for t in rec.get("turns", []) if t.get("role") == "assistant"]
            if usage and all(isinstance(u, dict) and isinstance(u.get("input_tokens"), int) and isinstance(u.get("output_tokens"), int) for u in usage):
                costs.append(sum(u["input_tokens"] * price_in + u["output_tokens"] * price_out for u in usage) / 1e6)
    if not costs:
        return None
    return {"n": len(costs), "mean": sum(costs) / len(costs), "max": max(costs), "models": sorted(m for m in models if m)}


def preflight(plan_path, agent_spec, seed_path=None, practice=False, out=None, price_in=None, price_out=None, pilot_done=False, resume=False, accept_unsandboxed_code=False, label=None, env=None, pilot_ladders=None):
    """-> [(level, text)]. `env` is the environment to read (default os.environ), so a test can set it without touching the process."""
    env = os.environ if env is None else env
    res = []

    def add(level, text):
        res.append((level, text))
    # ---- the plan and the seed ------------------------------------------------------------------------------------------------------------------------------
    try:
        with open(plan_path, "r", encoding="utf-8") as f:
            plan = json.load(f)
    except (OSError, ValueError) as e:
        add(FAIL, "the plan cannot be read (%s)" % type(e).__name__)
        return res
    if not isinstance(plan, dict) or plan.get("format") != agent_eval.PLAN_FORMAT:
        add(FAIL, "the plan is not a %s file" % agent_eval.PLAN_FORMAT)
        return res
    try:
        master = agent_core.read_master(seed_path, practice)
    except (agent_core.AgentEvalError, OSError) as e:
        add(FAIL, "the seed cannot be read (%s)" % str(e)[:120])
        return res
    if plan.get("commit") != agent_core.commitment(master):
        add(FAIL, "the plan was made for a different seed (its commitment does not match this one)")
    else:
        add(OK, "the plan's seed commitment matches this seed")
    try:
        mod = agent_core.load_domain(plan["domain"])
        if plan.get("version") != mod.VERSION or plan.get("source_hashes") != agent_core.source_hashes(mod.NAME):
            add(FAIL, "the plan's pinned files differ from the files here (the domain, core or harness changed since the plan was made): make a new plan")
        else:
            add(OK, "the domain, core and harness files are the ones the plan pinned")
    except (agent_core.AgentEvalError, KeyError, TypeError) as e:
        add(FAIL, "the plan's domain cannot be loaded (%s)" % str(e)[:100])
        return res
    add(NOTE, "plan hash %s: PUBLISH IT (with the seed commitment) somewhere you cannot edit BEFORE any entry runs, or a result can be tailored to its own questions" % agent_eval.plan_hash(plan))
    if plan.get("practice"):
        add(WARN, "this is the PRACTICE seed: anyone can derive every instance, so the result shows the method, not a certified number")
    elif seed_path:
        try:
            mode = stat.S_IMODE(os.stat(seed_path).st_mode)
        except OSError:
            mode = 0
        if mode & 0o077:
            add(WARN, "the seed file is readable by other users (mode %o): chmod 600 it" % mode)
        if _inside(seed_path, HERE):
            add(FAIL, "the seed file is inside this checkout: keep it OUTSIDE any repository (it would be committed or shipped, and the answer to every hidden question is derived from it)")
        else:
            repo = _in_a_git_checkout(seed_path)
            if repo:
                add(FAIL, "the seed file is inside a git checkout (%s): keep it outside any repository" % repo)
            else:
                add(OK, "the seed file is outside any repository")
    # ---- the agent ------------------------------------------------------------------------------------------------------------------------------------------
    is_real = agent_providers.is_real_model(agent_spec)
    is_compat = str(agent_spec).startswith("compat")
    try:
        agent = agent_providers.make_agent(agent_spec, plan["domain"])
        if is_compat:
            add(OK, "OpenAI-compatible endpoint %s (nothing was sent; whether the server is up, knows the model and accepts the key is only known on the first call)" % agent.endpoint)
            add(NOTE, "tools are sent as OpenAI function definitions: a model or server without tool-calling support will answer in prose and every trial will end as 'no submit'")
        elif is_real:
            add(OK, "the Anthropic SDK is installed and the agent was built locally (nothing was sent: measured with SDK 2.14.0, whose constructor makes no network call)")
            resolved = agent_providers.credentials_resolve(getattr(agent, "client", None))
            if resolved is True:
                add(OK, "the SDK's own offline check says a credential will be sent, from the environment or a stored login (its value was not read or printed; whether the provider accepts it is "
                        "only known on the first call)")
            elif resolved is False:
                add(FAIL, "the SDK says it would send NO credential: the first request would be refused locally. Set ANTHROPIC_API_KEY (or ANTHROPIC_AUTH_TOKEN) or run `ant auth login`")
            elif env.get("ANTHROPIC_API_KEY") or env.get("ANTHROPIC_AUTH_TOKEN"):
                add(OK, "a credential is set in the environment (this SDK offers no offline check, so nothing beyond that is known; the value is never printed or sent by this check)")
            else:
                add(WARN, "this SDK offers no offline credential check and no ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN is in the environment: a login profile cannot be seen from here, and the "
                          "first request fails if there is none (the pilot is where that shows up)")
        else:
            add(NOTE, "%s is a scripted stand-in, not a model: the result says nothing about any model" % agent_spec)
    except agent_core.AgentEvalError as e:
        agent = None
        add(FAIL, str(e)[:240] if is_real else "the agent spec is not valid: %s" % str(e)[:160])
    except Exception as e:                                         # an SDK that fails to construct for a reason of its own
        agent = None
        add(FAIL, "the agent cannot be built (%s: %s)" % (type(e).__name__, str(e)[:120]))
    if is_compat:
        add(WARN, "the recording proxy (agent_proxy.py) signs ANTHROPIC-format traffic only: a compat run is operator-trusted unless every call is wrapped in agent_attest.AttestingAgent under a key "
                  "the verifier holds")
    elif is_real:
        base = env.get("ANTHROPIC_BASE_URL")
        if base:
            add(NOTE, "calls will go to ANTHROPIC_BASE_URL=%s: that is only an attestation if it is a recording proxy the VERIFIER runs (agent_proxy.py)" % base)
        else:
            add(WARN, "no recording proxy: the trajectories will be operator-trusted (a ladder proves its records are internally true and correct, not that a model produced them); "
                      "run agent_proxy.py under a key the verifier holds and point ANTHROPIC_BASE_URL at it for an attested result")
    # ---- what it can cost -----------------------------------------------------------------------------------------------------------------------------------
    try:
        trials = len(plan["sizes"]) * plan["n_per_size"] * plan["trials"]
        cap = plan["budget"]["max_tokens"]
        turns = plan["budget"]["max_turns"]
    except (KeyError, TypeError):
        add(FAIL, "the plan has no sizes, trials or budget")
        return res
    add(NOTE, "%d trials (%d sizes x %d instances x %d trials), each capped at %d proxy tokens and %d turns" % (trials, len(plan["sizes"]), plan["n_per_size"], plan["trials"], cap, turns))
    if is_real:
        if price_in is not None and price_out is not None:
            per_trial, b_in, b_out, note = estimate_trial_cost(cap, turns, price_in, price_out, agent_spec)
            add(NOTE, "estimated cost IF EVERY TRIAL RAN TO ITS CAP: %d trials x (%.0f billed input + %.0f billed output tokens) = %.2f at your prices (%g in / %g out per million). From a calibration (%s); "
                      "trials normally stop well short of the cap, so this is an upper estimate for the model's usual behaviour, not a guarantee" % (trials, b_in, b_out, trials * per_trial, price_in, price_out, note))
            worst = trials * cap * BILLED_PER_PROXY_WORST * max(price_in, price_out) / 1e6
            add(NOTE, "pessimistic bound: %d trials x %d proxy tokens x %.1f (the largest billed/proxy ratio seen on any single call) at your higher price (%g per million) = %.2f. Far above any observed run "
                      "(the 9-trial live study cost 0.10 against a pessimistic figure of 3.78); it exists so a surprise cannot be larger" % (trials, cap, BILLED_PER_PROXY_WORST, max(price_in, price_out), worst))
            stats = pilot_cost_stats(pilot_ladders, price_in, price_out)
            if stats:
                this_model = str(agent_spec).split(":", 1)[1].split(":")[0] if ":" in str(agent_spec) else None
                if this_model and any(m != this_model for m in stats["models"]):
                    add(WARN, "a pilot ladder you gave was made with %s but this arm is %s: its cost per trial is not this model's, so the EXPECTED cost below is not trustworthy" % (", ".join(stats["models"]) or "an unknown model", this_model))
                add(NOTE, "EXPECTED cost from your pilot: %d trials x %.4f (the mean of %d real trials, from the provider usage numbers the harness RECORDED in the pilot ladder: the operator's copy, evidence only if checked against a proxy log with `agent_proxy.py verify`) = %.2f; if every trial cost what the dearest pilot trial did "
                          "(%.4f): %.2f. This is the figure to decide on: trials stop well short of their cap. It assumes the plan's sizes are mixed like the pilot's, and larger sizes cost more"
                          % (trials, stats["mean"], stats["n"], trials * stats["mean"], stats["max"], trials * stats["max"]))
            elif pilot_ladders:
                add(WARN, "the pilot ladder(s) you gave carry no provider usage numbers (a scripted agent reports none), so no measured expected cost could be computed")
        else:
            add(NOTE, "no prices given (--price-in and --price-out, per million tokens; none are built in), so no money figure: only the token cap above")
        if trials > PILOT_TRIALS and not pilot_done:
            add(WARN, "this plan makes %d trials and you have not said a one-instance pilot was run: make a plan with --n 1 and one trial first (it finds a wrong key, an unavailable model or a prompt "
                      "that cannot work for a few dollars rather than the whole bill); pass --pilot-done once you have" % trials)
    # ---- code execution -------------------------------------------------------------------------------------------------------------------------------------
    if agent_core.runs_code(plan["domain"]) and not plan.get("practice"):
        if _looks_like_a_container():
            add(OK, "this looks like a container: the agent's code does not run as your own user on the host")
        else:
            add(FAIL if not accept_unsandboxed_code else WARN,
                "the %s domain runs the agent's code as THIS user on THIS machine, where a secret seed file is readable: hostile code could read it and derive every hidden test. Run in a container or VM "
                "that does not hold the seed file%s" % (plan["domain"], "" if not accept_unsandboxed_code else " (you passed --accept-unsandboxed-code: your risk)"))
    # ---- the output -----------------------------------------------------------------------------------------------------------------------------------------
    if out:
        part = out + ".part"
        if os.path.exists(out):
            add(FAIL, "%s already exists: refusing to overwrite a ladder" % out)
        elif os.path.exists(part) and not resume:
            add(FAIL, "%s exists: use --resume to continue it, or delete it" % part)
        else:
            add(OK, "the output path is free")
    else:
        add(NOTE, "no --out given: nothing checked about the output path")
    return res


def next_command(plan_path, agent_spec, seed_path, practice, out, label):
    seed = "--practice" if practice else "--seed %s" % (seed_path or "SEED")
    return ("python3 agent_eval.py run --plan %s --agent %s --label %s %s --out %s%s"
            % (plan_path, agent_spec, label or "LABEL", seed, out or "LADDER.jsonl", " --confirm-api-spend" if agent_providers.is_real_model(agent_spec) else ""))


def render(res, command, spends=True):
    order = {FAIL: 0, WARN: 1, NOTE: 2, OK: 3}
    lines = ["%-4s %s" % (lvl, txt) for lvl, txt in sorted(res, key=lambda r: order[r[0]])]
    fails = sum(1 for lvl, _ in res if lvl == FAIL)
    warns = sum(1 for lvl, _ in res if lvl == WARN)
    lines.append("")
    if fails:
        lines.append("NOT READY: %d thing(s) to fix before running. Nothing was sent to any provider." % fails)
    else:
        lines.append("READY%s. Nothing was sent to any provider; this check cannot know that the key works or what the run costs." % (" (with %d warning(s) you are accepting)" % warns if warns else ""))
        lines.append("Next, NOT run for you%s:" % (" (it spends money)" if spends else ""))
        lines.append("  " + command)
    return "\n".join(lines)
