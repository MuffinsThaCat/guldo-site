"""Local submission portal: upload a solver, see its lint result and queue status, see the leaderboard.

  python3 portal.py serve [--port 8765] [--data portal_data]      (binds 127.0.0.1 only)
  python3 portal.py verify-sandbox                                  run the sandbox tests; writes the marker only if they PASS
  python3 portal.py worker --seed-dir ~/judge-seeds [--once]        evaluate queued submissions IN THE SANDBOX

SAFETY RULES (each has a test):
  * The portal never executes an upload. It only parses the source with `ast` (submit_check.lint).
  * The worker refuses to evaluate anything until `verify-sandbox` has written <data>/SANDBOX_VERIFIED, and that marker is
    only written when the sandbox tests ran and passed with nothing skipped. Evaluation is always `--sandbox docker`;
    there is deliberately no way to evaluate an upload in a bare local process.
  * Uploads are size-limited, stored under a random id (never the client's filename), and every dynamic string in a page
    is HTML-escaped. There are no user accounts: this is a local tool, not a public service.
"""
import argparse
import html
import json
import os
import re
import subprocess
import sys
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import families
import judge
import report_html
import submit_check

HERE = os.path.dirname(os.path.abspath(__file__))
MAX_UPLOAD = 200_000          # bytes of Python source
MAX_PENDING = 50
MAX_STORED = 500              # every stored submission, including rejected ones (each can be up to MAX_UPLOAD bytes)
NAME_RE = re.compile(r"[^A-Za-z0-9_.-]")


def data_dir(base=None):
    d = os.path.abspath(base or os.path.join(HERE, "portal_data"))
    os.makedirs(os.path.join(d, "submissions"), exist_ok=True)
    return d


def clean_name(s):
    return (NAME_RE.sub("_", s.strip())[:40] or "unnamed")


# the sandbox gate and the multipart parser live in portal_core.py (standard library only) and are re-exported here unchanged
from portal_core import (MARKER, SANDBOX_FILES, parse_multipart, sandbox_fingerprint, sandbox_verified,  # noqa: E402,F401
                         write_marker)


def list_submissions(base):
    out = []
    root = os.path.join(base, "submissions")
    for sid in sorted(os.listdir(root)):
        p = os.path.join(root, sid, "meta.json")
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                out.append(json.load(f))
    return sorted(out, key=lambda m: m["submitted_at"], reverse=True)


def save_meta(base, meta):
    d = os.path.join(base, "submissions", meta["id"])
    with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=1)


def accept_submission(base, name, family, source_bytes):
    """Validate and store an upload WITHOUT running it. Returns the meta dict (state 'queued' or 'rejected')."""
    meta = {"id": uuid.uuid4().hex[:12], "name": clean_name(name), "family": family, "submitted_at": time.time(),
            "warnings": [], "state": "queued", "reason": ""}
    # unique file name: judge.py names a board entry after the file, so a shared name would merge every contestant's results
    meta["file"] = f"{meta['name']}-{meta['id']}.py"
    existing = list_submissions(base)
    if family not in families.FAMILIES:
        meta.update(state="rejected", reason=f"unknown family {family!r}")
    elif len(source_bytes) == 0:
        meta.update(state="rejected", reason="empty file")
    elif len(source_bytes) > MAX_UPLOAD:
        meta.update(state="rejected", reason=f"file is {len(source_bytes)} bytes; the limit is {MAX_UPLOAD}")
    elif len(existing) >= MAX_STORED:
        meta.update(state="rejected", reason="the portal has reached its storage limit; ask the owner to clear old submissions")
    elif sum(1 for m in existing if m["state"] == "queued") >= MAX_PENDING:
        meta.update(state="rejected", reason="the queue is full; try again later")
    else:
        try:
            text = source_bytes.decode("utf-8")
        except UnicodeDecodeError:
            meta.update(state="rejected", reason="the file is not UTF-8 text")
            text = None
        if text is not None:
            d = os.path.join(base, "submissions", meta["id"])
            os.makedirs(d, exist_ok=True)
            path = os.path.join(d, meta["file"])
            with open(path, "wb") as f:
                f.write(source_bytes)  # the exact uploaded bytes, whatever the locale's text encoding is
            try:
                warnings, fatal = submit_check.lint(path)  # ast only: never imports or runs the file
            except SyntaxError as e:
                warnings, fatal = [], [f"syntax error: {e.msg} (line {e.lineno})"]
            meta["warnings"] = warnings
            if fatal:
                meta.update(state="rejected", reason="; ".join(fatal))
    if meta["state"] == "rejected" and "storage limit" in meta["reason"]:
        return meta  # at the limit a rejection must leave NO trace, or the limit itself would still permit unbounded growth
    os.makedirs(os.path.join(base, "submissions", meta["id"]), exist_ok=True)
    save_meta(base, meta)
    return meta


# ------------------------------------------------------------------ pages
def e(x):
    return html.escape(str(x), quote=True)


STATE_NOTE = {"queued": "Waiting for the sandbox", "rejected": "Rejected", "evaluating": "Being evaluated",
              "done": "Evaluated", "failed": "Evaluation failed"}


def _row(m):
    """One table row. Built with plain concatenation: a backslash inside an f-string expression is a SyntaxError before Python 3.12,
    and the public service and the operator tool both import this module, so it must parse on every supported Python."""
    note = ("<div class='small muted'>" + e(m["reason"]) + "</div>") if m.get("reason") else ""
    warns = "".join("<div class='small muted'>warning: " + e(w) + "</div>" for w in m.get("warnings", []))
    when = e(time.strftime("%Y-%m-%d %H:%M", time.localtime(m["submitted_at"])))
    return (f'<tr><td class="strong">{e(m["name"])}</td><td>{e(m["family"])}</td><td>{e(STATE_NOTE.get(m["state"], m["state"]))}'
            f'{note}{warns}</td><td class="mono small">{when}</td></tr>')


def page(base, flash=""):
    subs = list_submissions(base)
    verified = sandbox_verified(base)
    rows = "".join(_row(m) for m in subs)
    fam_opts = "".join(f'<option value="{e(f)}">{e(f)}</option>' for f in sorted(families.FAMILIES))
    gate = ('<p class="ok-note">The sandbox is verified: queued submissions can be evaluated by the worker.</p>' if verified else
            '<p class="warn-note"><strong>Evaluation is switched off.</strong> The sandbox has not passed its tests on this machine '
            '(<code>portal.py verify-sandbox</code>), so uploads are checked and queued but nothing is run.</p>')
    board = []
    if os.path.exists(judge.BOARD):
        with open(judge.BOARD, encoding="utf-8") as f:
            board = json.load(f)
    lb = report_html.leaderboard(board)
    body = f"""<title>Solver Portal</title>
<style>{report_html.CSS}
form.up{{display:grid;gap:12px;max-width:520px}} label{{font-weight:600;font-size:13.5px;display:grid;gap:5px}}
input[type=text],select,input[type=file]{{font:inherit;padding:8px 10px;border:1px solid var(--line);border-radius:7px;background:var(--card);color:var(--ink);min-width:0}}
button{{font:600 14px var(--body);padding:10px 16px;border-radius:8px;border:0;background:var(--accent);color:#fff;cursor:pointer;justify-self:start}}
button:focus-visible,input:focus-visible,select:focus-visible{{outline:2px solid var(--ink);outline-offset:2px}}
.warn-note{{background:var(--warn-bg);color:var(--ink);padding:10px 12px;border-radius:8px}} .ok-note{{background:var(--ok-bg);color:var(--ink);padding:10px 12px;border-radius:8px}}
.flash{{background:var(--idle-bg);padding:10px 12px;border-radius:8px}}</style>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600&family=Instrument+Sans:wght@400;600&family=JetBrains+Mono:wght@400;600&display=swap">
<main class="wrap">
<header><h1>Solver Portal</h1><p class="lede">Send in a lattice solver and see how it is checked. Your file is read, never run, until the sandbox is verified.</p></header>
{f'<div class="flash" role="status">{e(flash)}</div>' if flash else ''}
<section class="card"><h2>Submit a solver</h2>{gate}
<form class="up" method="post" action="/submit" enctype="multipart/form-data">
<label for="name">Name<input id="name" name="name" type="text" maxlength="40" required placeholder="my_solver"></label>
<label for="family">Instance family<select id="family" name="family">{fam_opts}</select></label>
<label for="file">Python file<input id="file" name="file" type="file" accept=".py" required></label>
<button type="submit">Check and queue</button></form>
<p class="small muted">One file exposing <code>solve(basis, bound2)</code>; only fpylll and numpy exist in the sandbox. Rules: COMPETITORS.md.</p></section>
<section class="card"><h2>Submissions</h2>{'<div class="scroll"><table class="lb"><thead><tr><th>Name</th><th>Family</th><th>Status</th><th>Sent</th></tr></thead><tbody>' + rows + '</tbody></table></div>' if rows else '<p class="muted">Nothing submitted yet.</p>'}</section>
<section class="card"><h2>Leaderboard</h2>{lb}<p class="small muted">Full charts and limits: results/report.html (python3 report_html.py).</p></section>
</main>"""
    return body.encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    base = None
    timeout = 10  # seconds a client may stall on any read; without it one idle connection pins a thread forever

    def log_message(self, *a):
        pass

    def _guard(self):
        """Reject requests a browser on another site (or a rebinding attacker) could make against a loopback service.
        Host must be this server's own loopback name:port; a POST's Origin, when sent, must be exactly this server."""
        port = self.server.server_address[1]
        host = (self.headers.get("Host") or "").lower()
        if host not in (f"127.0.0.1:{port}", f"localhost:{port}"):
            self._send(403, b"forbidden: unexpected Host header", "text/plain")
            return False
        origin = self.headers.get("Origin")
        if self.command == "POST" and origin is not None and origin.lower() not in (f"http://127.0.0.1:{port}", f"http://localhost:{port}"):
            self._send(403, b"forbidden: cross-site request", "text/plain")
            return False
        if self.command == "POST" and self.headers.get("Sec-Fetch-Site") == "cross-site":
            self._send(403, b"forbidden: cross-site request", "text/plain")
            return False
        return True

    def _send(self, code, payload, ctype="text/html; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline' https://fonts.googleapis.com; "
                         "font-src https://fonts.gstatic.com; form-action 'self'; base-uri 'none'")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        if not self._guard():
            return
        if self.path.split("?")[0] == "/":
            self._send(200, page(self.base))
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self):
        if not self._guard():
            return
        if self.path != "/submit":
            return self._send(404, b"not found", "text/plain")
        raw_len = self.headers.get("Content-Length") or ""
        if not re.fullmatch(r"[0-9]{1,9}", raw_len):  # rejects negative, empty and non-numeric lengths
            return self._send(400, page(self.base, "The request had no valid Content-Length."), "text/html; charset=utf-8")
        n = int(raw_len)
        if n > MAX_UPLOAD + 20_000:
            return self._send(413, page(self.base, "That upload is too large."))
        try:
            body = self.rfile.read(n)
        except OSError:  # includes socket.timeout: the client stalled, so drop it rather than hold a thread
            self.close_connection = True
            return
        if len(body) < n:
            return self._send(400, page(self.base, "The upload ended early."))
        form = parse_multipart(self.headers.get("Content-Type", ""), body)
        if "file" not in form or "name" not in form:
            return self._send(400, page(self.base, "Missing name or file."))
        meta = accept_submission(self.base, form["name"][1].decode("utf-8", "replace"),
                                 form.get("family", (None, b"gm"))[1].decode("utf-8", "replace"), form["file"][1])
        msg = (f"{meta['name']}: rejected. {meta['reason']}" if meta["state"] == "rejected" else
               f"{meta['name']}: passed the static check and is queued." + (f" {len(meta['warnings'])} warning(s) listed below." if meta["warnings"] else ""))
        self._send(200 if meta["state"] != "rejected" else 422, page(self.base, msg))


def make_server(base, port=0):
    handler = type("H", (Handler,), {"base": data_dir(base)})
    srv = ThreadingHTTPServer(("127.0.0.1", port), handler)  # loopback only
    srv.daemon_threads = True
    return srv


# ------------------------------------------------------------------ worker + sandbox gate
def verify_sandbox(base):
    """Run the sandbox tests; write the marker ONLY if they ran, passed, and none were skipped."""
    r = subprocess.run([sys.executable, "-m", "unittest", "test_sandbox", "-v"], cwd=HERE, capture_output=True, text=True)
    out = r.stdout + r.stderr
    ok = r.returncode == 0 and "skipped" not in out and "Ran 0 tests" not in out and re.search(r"Ran [1-9]\d* tests?", out)
    path = os.path.join(base, MARKER)
    if ok:
        write_marker(base)
    elif os.path.exists(path):
        os.remove(path)
    return bool(ok), out


def run_worker(base, seed_dir, once=True, runner=subprocess.run):
    """Evaluate queued submissions in the sandbox. Refuses outright if the sandbox is not verified."""
    if not sandbox_verified(base):
        return ("REFUSED: the sandbox is not verified, or its files changed since it was (run `portal.py verify-sandbox`); "
                "nothing was evaluated.")
    done = 0
    for m in list_submissions(base):
        if m["state"] != "queued":
            continue
        m["state"] = "evaluating"
        save_meta(base, m)
        path = os.path.join(base, "submissions", m["id"], m.get("file", "solver.py"))
        r = runner([sys.executable, os.path.join(HERE, "official.py"), "evaluate", "--family", m["family"], "--submission", path,
                    "--seed-dir", seed_dir, "--sandbox", "docker"], cwd=HERE, capture_output=True, text=True)
        m["state"] = "done" if r.returncode == 0 else "failed"
        m["reason"] = "" if r.returncode == 0 else (r.stdout + r.stderr)[-300:]
        save_meta(base, m)
        done += 1
        if once and done >= 1:
            break
    return f"evaluated {done} submission(s)"


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("serve")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--data")
    p = sub.add_parser("verify-sandbox")
    p.add_argument("--data")
    p = sub.add_parser("worker")
    p.add_argument("--data")
    p.add_argument("--seed-dir", required=True)
    p.add_argument("--all", action="store_true", help="evaluate every queued submission, not just the oldest-first one")
    a = ap.parse_args()
    base = data_dir(a.data)
    if a.cmd == "serve":
        srv = make_server(base, a.port)
        print(f"portal on http://127.0.0.1:{srv.server_address[1]}  (data: {base}; evaluation "
              f"{'ENABLED' if sandbox_verified(base) else 'DISABLED until the sandbox is verified'})")
        srv.serve_forever()
    elif a.cmd == "verify-sandbox":
        ok, out = verify_sandbox(base)
        print(out[-1200:])
        print("SANDBOX VERIFIED: marker written" if ok else "NOT VERIFIED: the sandbox tests did not all run and pass")
        sys.exit(0 if ok else 1)
    else:
        print(run_worker(base, a.seed_dir, once=not a.all))


if __name__ == "__main__":
    main()
