"""aidistill in the counted-operations API, REFERENCE: the whole 4-member teacher on the whole batch, one batched product per layer per member."""
import math

import tensorops as tp

C = 10
E = 4


def solve(seed, d, Q):
    H = 4 * d
    o = 0
    L = tp.zeros((Q, C))
    for e in range(E):
        W1 = tp.reshape(tp.stream(seed, o, H * d), (H, d)) * math.sqrt(3.0 / d)
        o += H * d
        b = tp.stream(seed, o, H) + 1.0
        o += H
        W2 = tp.reshape(tp.stream(seed, o, C * H), (C, H)) * (math.sqrt(3.0 / H) / E)
        o += C * H
        W1t = tp.transpose(W1, (1, 0))
        W2t = tp.transpose(W2, (1, 0))
        if e == 0:
            X = tp.reshape(tp.stream(seed, E * (H * d + H + C * H), Q * d), (Q, d))
        L = L + tp.relu(X @ W1t + tp.reshape(b, (1, H))) @ W2t
    rows = L.tolist()
    return [row.index(max(row)) for row in rows]
