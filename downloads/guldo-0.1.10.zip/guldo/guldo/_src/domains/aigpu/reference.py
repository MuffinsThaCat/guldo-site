"""Reference for aigpu: multi-head attention in float64 on the CPU, one head at a time (the timed CPU protocol's baseline; the GPU baseline is solvers/aigpu_gpu_ref.py)."""
import math

import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, n, H, dk):
    m, d = H * n * dk, H * dk
    Q = (_uniform(seed, 0, m) * 3.0).reshape(H, n, dk)
    K = _uniform(seed, m, m).reshape(H, n, dk)
    V = _uniform(seed, 2 * m, m).reshape(H, n, dk)
    Wout = _uniform(seed, 3 * m, d * 16).reshape(d, 16) * math.sqrt(3.0 / d)
    O = np.empty((n, d))
    for h in range(H):
        S = Q[h] @ K[h].T / math.sqrt(dk)
        S -= S.max(axis=1, keepdims=True)
        P = np.exp(S)
        P /= P.sum(axis=1, keepdims=True)
        O[:, h * dk:(h + 1) * dk] = P @ V[h]
    return [int(v) for v in np.argmax(O @ Wout, axis=1)]
