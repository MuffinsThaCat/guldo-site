"""A dry run of everything a verifier does, on THIS machine, with throwaway keys and a scripted vendor: `python3 agent_verifier.py selfcheck`.

It runs, for real and in this order: a three-party joint-seed ceremony (signed commitments, then the combined seed); a round on that seed with a white-box baseline and one black-box entry; registration of the
round in a signed registry (and the same entry in the round's own log); the tool service over a real HTTP socket with a vendor client driving it; evaluation, reveal and a signed certificate; an
evidence transparency log with a witness co-signature; the bundle; and the independent AUDIT with only the pinned keys. A verifier who sees `SELFCHECK PASSED` knows that Python, the file system, sockets
and signing all work here, and what the finished product looks like. Nothing leaves the machine; nothing it creates outlives it (unless `keep` names a directory).

What it does NOT show: that YOUR real keys are safe, that your network is reachable by vendors (it uses localhost), or anything about a real vendor. The vendor here cheats by knowing the seed: the point is the machinery.
"""
import os
import shutil
import sys
import tempfile
import threading
import time

import agent_cert
import agent_core
import agent_joint as J
import agent_registry as REG
import agent_rounds as AR
import agent_service as SV
import agent_sig
import agent_translog as TL
import agent_vendor_example as VE
import agent_verifier as V
import rounds as R


class Stage(object):
    def __init__(self, say):
        self.say, self.t0, self.n = say, time.time(), 0

    def __call__(self, name):
        self.n += 1
        self.say("  [%d] %s" % (self.n, name))


def run(say=print, keep=None, n=3):
    """Returns (ok, audit rows). `say` receives progress lines."""
    stage = Stage(say)
    root = keep or tempfile.mkdtemp(prefix="guldo-selfcheck-")
    own = keep is None
    t0 = time.time()
    try:
        say("agent_verifier selfcheck: Python %s, signing backend: %s" % (sys.version.split()[0], agent_sig.backend()))
        os.makedirs(root, exist_ok=True)
        keys = {}
        for name in ("operator", "verifier", "vendor", "log", "witness"):
            p = os.path.join(root, name + ".key")
            agent_sig.keygen(p)
            keys[name] = (p, agent_sig.load_secret(p), agent_sig.public_key(agent_sig.load_secret(p)).hex())
        rid = "selfcheck1"
        stage("joint-seed ceremony: three parties sign commitments, then their shares are combined")
        shares, commits = {}, []
        for party, kname in (("operator", "operator"), ("verifier", "verifier"), ("vendor-demo", "vendor")):
            shares[party] = J.new_share()
            commits.append(J.make_commit(rid, party, shares[party], keys[kname][1]))
        master_hex, joint, revealed = J.combine(rid, commits, shares)
        master = master_hex.encode("ascii")
        seed = os.path.join(root, "seed.hex")
        with open(seed, "w", encoding="utf-8") as f:
            f.write(master_hex + "\n")
        stage("round: a white-box baseline and one black-box entry, closed to entries")
        now = time.time()
        AR.create_round(root, rid, "selfcheck", "dataanalysis", seed, [200], n, 1, now + 3600, {"agent": "scripted:bare", "label": "bare"}, practice=False, now=now)
        AR.enter(root, rid, "vendor-demo", {"agent": "blackbox:demo", "label": "demo"}, now=now + 1)
        AR.close_round(root, rid, now=now + 2, force=True)
        registry = os.path.join(root, "registry.jsonl")
        stage("the verifier's registry: identity with a pre-committed next key, then the round registered BEFORE it runs")
        nextkey = agent_sig.new_secret()
        REG.init_identity(registry, keys["verifier"][1], agent_sig.public_key(nextkey).hex())
        REG.open_round(registry, keys["verifier"][1], root, rid, joint)
        stage("the tool service on a real socket; a vendor client works every task over HTTP")
        mod = agent_core.load_domain("dataanalysis")
        table = {}
        for i in range(n):
            inst = agent_core.make_instance(mod, master, 200, i)
            table[mod.prompt(inst["public"])] = inst["private"]["answer"]
        arm = SV.Arm(root, rid, "e001", master, keys["verifier"][1])
        token = arm.set_arm_token()
        srv = SV.make_server(arm)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            client = VE.TspClient("http://127.0.0.1:%d" % srv.server_address[1], token)

            def solve(session):
                session.call("describe")
                session.submit(table[session.task])
            VE.run_arm(client, solve)
            arm.finish_arm()
        finally:
            srv.shutdown()
            srv.server_close()
            arm.close()
        stage("evaluate the baseline, reveal the seed, verify the round, sign a certificate, register the outcome")
        AR.evaluate_round(root, rid, seed)
        AR.reveal(root, rid, seed)
        AR.result(root, rid)
        problems = AR.verify_round(root, rid)
        if problems:
            raise RuntimeError("the round does not verify: %s" % problems[0])
        cert = agent_cert.build(root, rid, "e001", key_path=keys["verifier"][0])
        cert_path = os.path.join(root, "certificate.json")
        import json
        with open(cert_path, "w", encoding="utf-8") as f:
            json.dump(cert, f, indent=1, sort_keys=True)
        REG.close_round(registry, keys["verifier"][1], root, rid)
        jp, jrp = os.path.join(root, "joint.json"), os.path.join(root, "joint.revealed.json")
        for p, doc in ((jp, joint), (jrp, revealed)):
            with open(p, "w", encoding="utf-8") as f:
                json.dump(doc, f, indent=1, sort_keys=True)
        stage("the evidence transparency log: commitments and registry entries logged, a witness co-signs")
        logdir = os.path.join(root, "log")
        TL.init(logdir, "selfcheck.local/evidence", keys["log"][1])
        rows = REG.read(registry)
        info = REG.rounds(rows)[rid]
        for c in joint["parties"]:
            TL.append(logdir, keys["log"][1], "commitment", c)
        co = TL.witness(TL.load(logdir), os.path.join(root, "witness.state"), keys["log"][2], keys["witness"][1])
        TL.add_cosigs(logdir, [co])
        for ent in (info["open"], info["end"]):
            TL.append(logdir, keys["log"][1], "registry_entry", TL.registry_entry_data(rows, ent["seq"]))
        stage("the bundle, then the AUDIT with only the keys a reader would pin")
        bundle = os.path.join(root, "bundle")
        V.make_bundle(root, rid, bundle, [cert_path], registry, jp, jrp, log_dir=logdir)
        pins = {keys["verifier"][2]}
        party_pins = {keys[k][2] for k in ("operator", "verifier", "vendor")}
        audit = V.audit(bundle, pins, party_pins, "verifier", require_registry=True, require_joint=True, log_key=keys["log"][2], log_witnesses={keys["witness"][2]}, min_witnesses=1,
                        require_log=True)
        ok = all(good for _n, good, _d in audit)
        for name, good, detail in audit:
            say("      %s  %s%s" % ("INFO" if V.n_info(name) else ("PASS" if good else "FAIL"), name[5:] if V.n_info(name) else name, ("  (" + detail + ")") if detail else ""))
        say("SELFCHECK %s in %.1fs: %s" % ("PASSED" if ok else "FAILED", time.time() - t0,
                                          "this machine can run a round, and the audit accepts what it produced" if ok else "something above failed: fix it before running a real round"))
        return ok, audit
    finally:
        if own:
            shutil.rmtree(root, ignore_errors=True)
