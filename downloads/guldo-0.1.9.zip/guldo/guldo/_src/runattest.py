"""Run attestations: the sandbox operator signs that THEIR OWN records of a run are the ladders inside a certificate.

  runattest.py make CERT --results DIR --key K [--round-data DIR] --out run.att.json
  runattest.py check run.att.json CERT [--key HEX]

WHY. certificate.verify takes the run metadata that decides OFFICIAL (sandbox, image, cpu, n, budget) from inside the certificate, so anyone can write it: a self-built
certificate whose ladder headers say `docker` verifies as OFFICIAL. Nothing about the certificate format can fix that, because the claim is about an event only the party that
ran the sandbox witnessed. What can be done is make that party SAY SO, in a way tied to a key readers pin:

  `make` refuses unless the operator's own result files (the ones `judge.py evaluate` wrote, `judged_<family>_<seed>_<role>_<solver>.jsonl`) are byte-for-byte the ladders in
  the certificate (after the same private-solver redaction), their own headers say the run was in a sandbox, and (if the certificate carries a round log) that log is the
  operator's own. Only then does it sign: certificate digest, ladder digest, sandbox, image, round and round-log head.

A forger who rewrites ladder headers produces ladders that do not match any file the operator holds, so `make` refuses; a forger who signs with their own key produces an
attestation by a key nobody pinned. What this does NOT do: it does not prove the sandbox is sound (that is the sandbox's own, still unverified, test suite), and it vouches only
that the operator's records match. A reader who pins the operator's key trusts the operator exactly as far as they trust the sandbox.
"""
import argparse
import json
import os
import re
import sys
import time

import attest as A
import certificate as K

FORMAT = "guldo-run-attestation-v1"
_TIME = re.compile(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ")
_HEX64 = re.compile(r"[0-9a-f]{64}")
_SANDBOX = re.compile(r"[a-z0-9_.-]{1,30}")
_IMAGE = re.compile(r"[A-Za-z0-9_.:@+/-]{1,128}")
_ROUNDID = re.compile(r"[A-Za-z0-9_.-]{1,64}")
_NAME = re.compile(r"[A-Za-z0-9_.:+/ -]{0,60}")


class RunAttestError(Exception):
    """The operator's records do not support the attestation (or the attestation is malformed)."""


def _msg(stmt):
    return b"guldo-run-attestation-v1\n" + K.canon(stmt).encode()


def ladders_sha256(cert):
    return K.sha256(K.canon(cert["ladders"]))


def _read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def _redact(tag, base, sub):
    """The ladders as a PRIVATE-SOLVER certificate carries them (certificate.make_private): the operator's text is compared after the same redaction."""
    lad = K.make_private({"submission": {}, "ladders": {tag: {"baseline": base, "submission": sub}}})["ladders"][tag]
    return lad["baseline"], lad["submission"]


_PLAIN = re.compile(r"[A-Za-z0-9_.-]{1,80}")


def _plain(x, what):
    """Names inside a certificate end up in file paths on the OPERATOR's machine: refuse anything but plain text before a path is built from it."""
    if not isinstance(x, str) or not _PLAIN.fullmatch(x) or x in (".", "..") or ".." in x:
        raise RunAttestError(f"the certificate's {what} is not plain text: refusing to build a file path from it")
    return x


def operator_ladders(cert, results_dir):
    """{tag: (baseline_text, submission_text)} from the operator's own files, exactly as certificate.build names them."""
    fam, out = _plain(cert["family"], "problem name"), {}
    bname, sname = _plain(cert["baseline"]["name"], "baseline name"), _plain(cert["submission"]["name"], "solver name") + ".py"
    for tag in sorted(cert["ladders"]):
        _plain(tag, "seed tag")
        files = (os.path.join(results_dir, f"judged_{fam}_{tag}_baseline_{bname}.jsonl"), os.path.join(results_dir, f"judged_{fam}_{tag}_submission_{sname}.jsonl"))
        for f in files:
            if not os.path.isfile(f):
                raise RunAttestError(f"the operator holds no record {os.path.basename(f)}: this certificate was not produced from these results")
        out[tag] = (_read(files[0]), _read(files[1]))
    return out


def make(cert, results_dir, key_path, round_data=None, now=None, verify=None):
    """-> the attestation (a dict). Raises RunAttestError unless every claim in it is backed by the operator's own records."""
    res = (verify or (lambda c: K.verify(c, log=lambda *a, **k: None)))(cert)
    if not res.get("ok"):
        raise RunAttestError("the certificate does not verify, so there is nothing to attest: " + "; ".join(c["check"] for c in res.get("checks", []) if c.get("status") == "fail"))
    mine = operator_ladders(cert, results_dir)
    bad = []
    for tag, (base, sub) in sorted(mine.items()):
        if cert.get("private") is True:
            base, sub = _redact(tag, base, sub)
        if cert["ladders"][tag]["baseline"] != base:
            bad.append(f"{tag} baseline")
        if cert["ladders"][tag]["submission"] != sub:
            bad.append(f"{tag} submission")
    if bad:
        raise RunAttestError("the ladders in this certificate are NOT the operator's own records (" + ", ".join(bad) + "): it was edited or built from other results. Not attested")
    heads = [json.loads(line) for line in next(iter(mine.values()))[1].splitlines() if line.strip()][:1]
    meta = heads[0] if heads and heads[0].get("meta") else {}
    sandbox, image, version = meta.get("sandbox"), meta.get("image"), meta.get("instance_version")
    if not isinstance(sandbox, str) or not sandbox or not isinstance(image, str) or not image:
        raise RunAttestError("the operator's own records say this run was not in a sandbox (sandbox/image are empty): there is nothing to attest")
    round_id = head = None
    if cert.get("log"):
        round_id = _plain((cert["log"][0].get("data") or {}).get("id"), "round id")
        if not round_data:
            raise RunAttestError("this certificate carries a round log: pass round_data so it can be compared with the operator's own")
        import rounds
        d = rounds.rdir(round_data, round_id)
        if rounds.read_log(d) != cert["log"]:
            raise RunAttestError("the round log in this certificate is not the operator's own log of that round")
        ok, _, head, err = rounds.verify_log(d)
        if not ok:
            raise RunAttestError(f"the operator's own round log does not verify: {err}")
    priv, ser = A._load_key(key_path)
    stmt = {"format": FORMAT, "cert_sha256": A.cert_digest(cert), "ladders_sha256": ladders_sha256(cert), "family": cert["family"], "sandbox": sandbox, "image": image,
            "instance_version": version if isinstance(version, str) else "", "round_id": round_id, "round_log_head": head,
            "at": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "pubkey": A._pub_hex(priv, ser)}
    try:
        parse({"statement": stmt, "signature": "0" * 128}, verify_signature=False)
    except ValueError as e:      # never sign something this module's own parser would refuse (an odd character in the operator's own image name, say)
        raise RunAttestError(f"refusing to sign a statement that would not parse: {e}")
    return {"statement": stmt, "signature": priv.sign(_msg(stmt)).hex()}


def parse(att, verify_signature=True):
    """-> the cleaned fields of an attestation. Raises ValueError for anything malformed, forged or unsigned. Every field is plain and bounded: it ends up in a log entry."""
    if (not isinstance(att, dict) or set(att) != {"statement", "signature"} or not isinstance(att["statement"], dict) or not isinstance(att["signature"], str)
            or not re.fullmatch(r"[0-9a-f]{128}", att["signature"])):
        raise ValueError("not an attestation")
    st = att["statement"]
    if st.get("format") != FORMAT or set(st) != {"format", "cert_sha256", "ladders_sha256", "family", "sandbox", "image", "instance_version", "round_id", "round_log_head", "at", "pubkey"}:
        raise ValueError(f"not a {FORMAT} statement")
    for k in ("cert_sha256", "ladders_sha256", "pubkey"):
        if not isinstance(st[k], str) or not _HEX64.fullmatch(st[k]):
            raise ValueError(f"{k} is not a 64-hex value")
    if not isinstance(st["at"], str) or not _TIME.fullmatch(st["at"]):
        raise ValueError("at is not a UTC time")
    if not isinstance(st["family"], str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,60}", st["family"]):
        raise ValueError("family is not plain text")
    if not isinstance(st["sandbox"], str) or not _SANDBOX.fullmatch(st["sandbox"]) or not isinstance(st["image"], str) or not _IMAGE.fullmatch(st["image"]):
        raise ValueError("sandbox or image is not plain text")
    if not isinstance(st["instance_version"], str) or not _NAME.fullmatch(st["instance_version"]):
        raise ValueError("instance_version is not plain text")
    if st["round_id"] is not None and (not isinstance(st["round_id"], str) or not _ROUNDID.fullmatch(st["round_id"])):
        raise ValueError("round_id is not plain text")
    if st["round_log_head"] is not None and (not isinstance(st["round_log_head"], str) or not _HEX64.fullmatch(st["round_log_head"])):
        raise ValueError("round_log_head is not a 64-hex value")
    if verify_signature:
        if not A.have_crypto():
            raise ValueError("the `cryptography` package is not installed: a signature cannot be verified")
        ed, _ = A._ed()
        try:
            ed.Ed25519PublicKey.from_public_bytes(bytes.fromhex(st["pubkey"])).verify(bytes.fromhex(att["signature"]), _msg(st))
        except Exception:
            raise ValueError("the signature does not verify")
    return {"attester": st["pubkey"], "cert_canon": st["cert_sha256"], "ladders_sha256": st["ladders_sha256"], "family": st["family"], "sandbox": st["sandbox"], "image": st["image"],
            "instance_version": st["instance_version"], "round_id": st["round_id"], "round_log_head": st["round_log_head"], "signed_at": st["at"]}


def check(att, cert, pinned_key=None):
    """-> {"ok", "checks"}: the attestation is genuine, and it is about THIS certificate's ladders. The pinned key says whose it is; without one it only says a key signed it."""
    out = []

    def chk(name, status, detail):
        out.append({"check": name, "status": status, "detail": detail})
    try:
        f = parse(att)
    except ValueError as e:
        chk("attestation", "fail", str(e))
        return {"ok": False, "checks": out}
    chk("signature", "pass", f"signed by {f['attester'][:16]}... for the {f['sandbox']} sandbox, image {f['image'][:30]}")
    if pinned_key is None:
        chk("key", "warn", "you did not pin the operator's key (--key): this shows a key signed it, not whose key it is")
    elif pinned_key.lower() != f["attester"]:
        chk("key", "fail", f"signed by {f['attester'][:16]}..., not the key you pinned ({pinned_key[:16]}...)")
    else:
        chk("key", "pass", "signed by the key you pinned")
    try:
        same_cert, same_lad = f["cert_canon"] == A.cert_digest(cert), f["ladders_sha256"] == ladders_sha256(cert) and f["family"] == cert.get("family")
    except (KeyError, TypeError):
        same_cert = same_lad = False
    chk("certificate", "pass" if same_cert else "fail", "it names this certificate" if same_cert else "it names a different certificate")
    chk("ladders", "pass" if same_lad else "fail", "its ladder digest is this certificate's" if same_lad else "its ladder digest is not this certificate's ladders")
    return {"ok": all(c["status"] != "fail" for c in out), "checks": out}


def build_parser():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("make")
    m.add_argument("cert")
    m.add_argument("--results", required=True, help="the operator's results directory (the files judge.py evaluate wrote)")
    m.add_argument("--key", required=True)
    m.add_argument("--round-data", help="the operator's rounds data directory (needed when the certificate carries a round log)")
    m.add_argument("--out", required=True)
    c = sub.add_parser("check")
    c.add_argument("attestation")
    c.add_argument("cert")
    c.add_argument("--key", help="the operator's public key, from a source other than the attestation")
    return ap


def main(argv=None):
    a = build_parser().parse_args(argv)
    try:
        if a.cmd == "make":
            att = make(_load(a.cert), a.results, a.key, a.round_data)
            with open(a.out, "x") as f:
                json.dump(att, f, indent=1, sort_keys=True)
                f.write("\n")
            print(f"attested: the ladders in {a.cert} are this operator's own records ({att['statement']['sandbox']}, {att['statement']['image'][:40]}). Wrote {a.out}")
            return 0
        r = check(_load(a.attestation), _load(a.cert), a.key)
        for c in r["checks"]:
            print(f"  {c['status'].upper():5s} {c['check']}: {c['detail']}")
        print("VERIFIED" if r["ok"] and a.key else ("VERIFIED, BUT THE OPERATOR'S KEY IS NOT PINNED" if r["ok"] else "NOT VERIFIED"))
        return 0 if r["ok"] else 1
    except (RunAttestError, OSError, ValueError, KeyError, TypeError) as e:
        print(f"runattest: {e}", file=sys.stderr)
        return 2


def _load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


if __name__ == "__main__":
    sys.exit(main())
