"""Summaries and PAIRED comparison of agent ladders: the "prove the uplift" tool.

  summarize(header, records)        success per size, an exact one-sided lower bound on the solve rate, cost on solved trials
  compare(base, cand)               the same committed instances, side by side: who solved more (exact sign test on the discordant instances) and how many bits (log2 of the
                                    token ratio) cheaper on the instances BOTH solved (deterministic bootstrap), with the verdict rule below

UNIT OF ANALYSIS. The instance, not the trial. With K trials per instance an instance counts as SOLVED when MORE THAN HALF of its trials pass, so two instances are two draws and the
exact tests below are honest about their n; the per-trial pass rate is reported alongside, descriptively only (trials of one instance are not independent). Cost of an instance is the
mean proxy tokens over its SOLVED trials: the price of getting it right. Instances a side did not solve are never charged a made-up cost: they are excluded from the cost gap and
counted separately, which understates that side's true cost, as in the speed protocol's comparison tools.

VERDICT RULE. A side "solves more" only if the exact one-sided sign test on the discordant instances gives p <= 0.05. A side is "cheaper" only if BOTH hold: the one-sided 95% bootstrap
lower bound of the mean gap in bits is above zero in its favour AND the exact sign test on the per-instance gaps gives p <= 0.05. Winning often by a hair while losing rarely by a lot is
not shown cheaper. Otherwise the answer is "neither is shown".
TAIL CORRECTION. The cost bound is computed after adding ONE pessimistic pseudo-observation (agent_core.pessimistic_gap: a loss as large as the worst loss seen, at least 1 bit), because the plain
bootstrap bound of a mean is invalid when rare large losses exist but none is in the sample: with a true mean gap of zero it said "candidate uses fewer tokens" 10-35% of the time. The unadjusted
bound is reported as `lower95_bits_unadjusted`, and `worst_gap_bits` and `dearer_by_1_bit_or_more_on` show the tail. A small but perfectly consistent gain therefore needs many instances to certify.
ERROR RATE. Each verdict is a ONE-SIDED test at 5%. The comparison reports whichever direction occurs, so the chance of calling a difference when there is none is about 10% (two
directions), and there are two separate verdicts (success, cost). A claim fixed in advance, with its direction, is tested at 5% by `claim`; quote that, not an after-the-fact verdict.

What this shows: on THESE instances (derived from a seed committed before the run), under THESE caps and THIS proxy token unit, which agent solved more and which cost fewer tokens.
What it does not show: that a rerun of a model reproduces the trajectory; a provider's billed tokens; anything outside the tested domain and sizes; that the agent behaved safely.
"""
import math

import agent_core
import agent_strata as strat
from agent_core import canon, sha256_hex

FORMAT = "guldo-agent-comparison-v1"
SAME_KEYS = ("domain", "version", "commit", "plan_hash", "budget", "sizes", "n_per_size", "trials", "counter", "practice", "python_major_minor")
HASH_KEYS = ("agent_core.py", "agent_harness.py")


class CompareError(Exception):
    pass


def instances_of(header, records):
    """Group records by instance; validate that the ladder holds exactly the planned (size, idx, trial) set. Returns {(size, idx): [records by trial]}."""
    agent_core.require_shape(header, records)
    by = {}
    for r in records:
        by.setdefault((r["size"], r["idx"]), []).append(r)
    expect = [(s, i) for s in header["sizes"] for i in range(header["n_per_size"])]
    if sorted(by) != sorted(expect):
        raise CompareError("the ladder does not hold exactly the planned instances (%d found, %d planned)" % (len(by), len(expect)))
    for key, rs in by.items():
        trials = sorted(r["trial"] for r in rs)
        if trials != list(range(header["trials"])):
            raise CompareError("instance %s has trials %s, expected 0..%d" % (str(key), trials, header["trials"] - 1))
        rs.sort(key=lambda r: r["trial"])
    return by


def per_instance(header, records):
    out = {}
    for key, rs in instances_of(header, records).items():
        k = sum(1 for r in rs if r["solved"])
        good = [r for r in rs if r["solved"]]
        out[key] = {"solved": 2 * k > len(rs), "k": k, "K": len(rs),
                    "tokens": (sum(r["tokens"] for r in good) / float(len(good))) if good else None,
                    "tool_calls": (sum(r["tool_calls"] for r in good) / float(len(good))) if good else None}
    return out


def summarize(header, records):
    inst = per_instance(header, records)
    n = len(inst)
    solved = sum(1 for v in inst.values() if v["solved"])
    trials = sum(v["K"] for v in inst.values())
    passed = sum(v["k"] for v in inst.values())
    sizes = []
    for s in header["sizes"]:
        vs = [v for (sz, _), v in inst.items() if sz == s]
        toks = [v["tokens"] for v in vs if v["tokens"] is not None]
        sizes.append({"size": s, "instances": len(vs), "solved": sum(1 for v in vs if v["solved"]), "median_tokens_on_solved": agent_core.median(toks)})
    all_tokens = [v["tokens"] for v in inst.values() if v["tokens"] is not None]
    sts = strat.strata_from_summary(sizes)
    prov = [(r["provider_tokens"], r["tokens"]) for r in records if r.get("provider_tokens") and r["tokens"]]
    ratio = agent_core.median([p / float(t) for p, t in prov]) if prov else None
    out = {"agent": header.get("agent", {}).get("label"), "instances": n, "solved_instances": solved, "solve_rate": solved / float(n) if n else None,
            "solve_rate_lower95": round(agent_core.cp_lower(solved, n), 6), "trials": trials, "trial_pass_rate": passed / float(trials) if trials else None,
            "solve_rate_stratified_lower95": round(strat.stratified_lower(sts), 6), "worst_size_lower95": round(strat.worst_stratum_lower(sts), 6),
            "median_tokens_on_solved": agent_core.median(all_tokens), "by_size": sizes,
            "agent_error_trials": sum(1 for r in records if str(r.get("reason", "")).startswith("agent error")),
            "provider_over_proxy_tokens_median": ratio,
            "provider_over_proxy_tokens_min": min(p / float(t) for p, t in prov) if prov else None}
    if header.get("mode"):                                   # present only for a black-box ladder, so every white-box summary (and every certificate built from one) is unchanged
        out["mode"], out["cost_unit"] = header["mode"], header.get("cost_unit")
    return out


def ladder_digest(header, records):
    agent_core.require_shape(header, records)
    parts = [canon(header)]
    for r in sorted(records, key=lambda r: (r["size"], r["idx"], r["trial"])):
        parts.append("%s|%d|%s|%d" % (r["instance"], r["trial"], r["head"], 1 if r["solved"] else 0))
    return sha256_hex("\n".join(parts))


def _same(base_h, cand_h):
    for h in (base_h, cand_h):
        ph = h.get("plan_hash")
        if not (isinstance(ph, str) and len(ph) == 64):
            raise CompareError("a ladder has no plan hash: it cannot be bound to a committed plan")
    for k in SAME_KEYS:
        if base_h.get(k) != cand_h.get(k):
            raise CompareError("the ladders differ in %r (%r vs %r): not the same test" % (k, base_h.get(k), cand_h.get(k)))
    sb, sc = base_h.get("source_hashes", {}), cand_h.get("source_hashes", {})
    dom = [k for k in sb if k.startswith("agent_domains/")]
    for k in list(HASH_KEYS) + dom:
        if sb.get(k) != sc.get(k):
            raise CompareError("the ladders were made by different %s: not the same test" % k)
    if base_h.get("agent", {}).get("label") == cand_h.get("agent", {}).get("label"):
        raise CompareError("both ladders have the same agent label; compare two different agents (or relabel)")


def compare(base_h, base_recs, cand_h, cand_recs):
    _same(base_h, cand_h)
    b, c = per_instance(base_h, base_recs), per_instance(cand_h, cand_recs)
    keys = sorted(b)
    wins = sum(1 for k in keys if c[k]["solved"] and not b[k]["solved"])
    losses = sum(1 for k in keys if b[k]["solved"] and not c[k]["solved"])
    both = [k for k in keys if b[k]["solved"] and c[k]["solved"]]
    neither = sum(1 for k in keys if not b[k]["solved"] and not c[k]["solved"])
    p_cand = agent_core.sign_test_p(wins, losses)
    p_base = agent_core.sign_test_p(losses, wins)
    if wins > losses and p_cand <= agent_core.ALPHA:
        success = "candidate solves more"
    elif losses > wins and p_base <= agent_core.ALPHA:
        success = "baseline solves more"
    else:
        success = "no difference in solve rate shown"
    material = (ladder_digest(base_h, base_recs) + ladder_digest(cand_h, cand_recs)).encode("ascii")
    out = {"format": FORMAT, "domain": base_h["domain"], "version": base_h["version"], "commit": base_h["commit"], "plan_hash": base_h["plan_hash"], "practice": base_h["practice"],
           "baseline": {"agent": base_h["agent"], "digest": ladder_digest(base_h, base_recs), "summary": summarize(base_h, base_recs)},
           "candidate": {"agent": cand_h["agent"], "digest": ladder_digest(cand_h, cand_recs), "summary": summarize(cand_h, cand_recs)},
           "success": {"candidate_only": wins, "baseline_only": losses, "both": len(both), "neither": neither, "sign_p_candidate_better": round(p_cand, 8),
                       "sign_p_baseline_better": round(p_base, 8), "verdict": success}}
    cost = {"both_solved": len(both), "excluded_unsolved_by_a_side": len(keys) - len(both)}
    bu, cu = base_h.get("cost_unit", PROXY_UNIT), cand_h.get("cost_unit", PROXY_UNIT)
    if bu != cu:
        # a black-box arm's cost is INTERACTION tokens (what crossed the tool service), a white-box arm's is PROXY tokens of the re-read context: different quantities, never compared
        tb = [math.log2(b[k]["tool_calls"] / c[k]["tool_calls"]) for k in both if b[k]["tool_calls"] and c[k]["tool_calls"]]
        cost["verdict"] = "not comparable: the arms' cost units differ (%s vs %s); only tool-call counts are common" % (bu, cu)
        cost["mean_tool_call_bits"] = round(sum(tb) / len(tb), 6) if tb else None
    elif not both:
        cost["verdict"] = "no instance solved by both: no cost comparison"
    else:
        bits = [math.log2(b[k]["tokens"] / c[k]["tokens"]) for k in both]
        mean, lo_raw, ci = agent_core.bootstrap_mean(bits, material)
        neg = [-x for x in bits]
        # one pseudo-observation AGAINST EACH CLAIMED DIRECTION (agent_core.pessimistic_gap): for the reverse claim ("baseline is cheaper") the worst loss is the candidate's biggest WIN, so it
        # is computed from the negated gaps, not reused from the forward claim (the first version reused it, and was a little more lenient on mirrored data)
        _, lo, _ = agent_core.bootstrap_mean(bits + [agent_core.pessimistic_gap(bits)], material)
        _, nlo, _ = agent_core.bootstrap_mean(neg + [agent_core.pessimistic_gap(neg)], material)
        cw = sum(1 for x in bits if x > 1e-12)
        cl = sum(1 for x in bits if x < -1e-12)
        p_c, p_b = agent_core.sign_test_p(cw, cl), agent_core.sign_test_p(cl, cw)
        if lo > 0 and p_c <= agent_core.ALPHA:
            verdict = "candidate uses fewer tokens"
        elif nlo > 0 and p_b <= agent_core.ALPHA:
            verdict = "baseline uses fewer tokens"
        else:
            verdict = "neither is shown cheaper"
        tb = [math.log2(b[k]["tool_calls"] / c[k]["tool_calls"]) for k in both if b[k]["tool_calls"] and c[k]["tool_calls"]]
        cost.update({"mean_bits": round(mean, 6), "lower95_bits_one_sided": round(lo, 6), "ci95_bits": [round(ci[0], 6), round(ci[1], 6)],
                     "geometric_mean_factor": round(2 ** mean, 6), "factor_lower95": round(2 ** lo, 6), "lower95_bits_unadjusted": round(lo_raw, 6),
                     "worst_gap_bits": round(min(bits), 6), "dearer_by_1_bit_or_more_on": sum(1 for x in bits if x <= -1.0),
                     "candidate_cheaper_on": cw, "baseline_cheaper_on": cl, "sign_p_candidate_cheaper": round(p_c, 8), "sign_p_baseline_cheaper": round(p_b, 8),
                     "mean_tool_call_bits": round(sum(tb) / len(tb), 6) if tb else None, "verdict": verdict})
    out["cost"] = cost
    out["limits"] = LIMITS
    if base_h.get("mode") or cand_h.get("mode"):             # only when a black-box arm is involved: a white-box comparison's output is unchanged, byte for byte
        out["limits"] = LIMITS + BLACKBOX_LIMITS
        out["modes"] = {"baseline": base_h.get("mode", "whitebox"), "candidate": cand_h.get("mode", "whitebox"), "baseline_cost_unit": bu, "candidate_cost_unit": cu}
        if base_h.get("enforced_budget") != cand_h.get("enforced_budget"):
            out["budget_note"] = ("the arms were NOT held to the same budget: a black-box arm is held only to %s, a white-box arm to the whole plan budget; a success difference may partly reflect that"
                                  % ", ".join(sorted((base_h.get("enforced_budget") or cand_h.get("enforced_budget") or {}).keys())))
    return out


LIMITS = ["Tokens are PROXY tokens (ceil(utf-8 bytes / 4) of the exact context sent each turn plus the output): recomputable from the stored trajectories, not a provider's billed count.",
          "A language-model agent cannot be re-run to the same trajectory: verification checks that each recorded output passes the exact verifier and that each recorded cost follows from its trajectory.",
          "An instance counts as solved when more than half of its trials pass; cost is the mean over solved trials; unsolved instances are excluded from the cost gap, which understates that side's cost.",
          "The tasks come from a public generator: commit-reveal means no JUDGED instance could have been seen, not that the skill could not be trained for.",
          "Results hold for this domain, these sizes and caps, and these two agent configurations; nothing is claimed about safety or about other tasks."]


PROXY_UNIT = "proxy-tokens"
BLACKBOX_LIMITS = ["BLACK-BOX arm: the evaluator saw only the calls the vendor's agent made to the hosted tools and what they returned, never its model, prompts or reasoning. Its cost is INTERACTION tokens "
                   "(what crossed the tool service), not the model's cost, and is never compared with proxy tokens.",
                   "A black-box result shows what the agent's OUTPUT was on instances it could not have seen: not that the agent worked alone (a human, another service or a different model than the one "
                   "advertised could have produced the calls), nor what it cost the vendor to run.",
                   "A black-box arm is held only to max_tool_calls and max_wall_s; the plan's token and turn caps cannot be enforced on an agent the evaluator cannot see."]


def claim_check(result, min_factor=None, min_solve_rate=None, min_stratified_rate=None):
    """Evaluate stated claims against a comparison result. Returns [(claim text, True/False)]."""
    out = []
    if min_factor is not None:
        got = result["cost"].get("factor_lower95")
        out.append(("candidate uses at least %gx fewer tokens on tasks both solve (95%% one-sided)" % min_factor, got is not None and got >= min_factor and result["cost"].get("verdict") == "candidate uses fewer tokens"))
    if min_solve_rate is not None:
        lb = result["candidate"]["summary"]["solve_rate_lower95"]
        out.append(("candidate solves at least %g of instances (95%% one-sided lower bound)" % min_solve_rate, lb >= min_solve_rate))
    if min_stratified_rate is not None:
        lb = result["candidate"]["summary"].get("solve_rate_stratified_lower95")
        out.append(("candidate solves at least %g of instances, equal weight per difficulty size (95%% simultaneous stratified lower bound)" % min_stratified_rate, lb is not None and lb >= min_stratified_rate))
    return out
