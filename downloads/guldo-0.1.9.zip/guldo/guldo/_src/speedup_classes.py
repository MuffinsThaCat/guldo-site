"""The fixed list of speedup classes: what kind of speedup a problem or proposal is testing.

One list, owned by the operator, used everywhere a problem is grouped: a declaration names its class with `SPEEDUP = "lattice"`, intake screens and groups the
queue by it, and the Domains page groups the problems by it. A proposer picks from this list instead of inventing a label, so "factoring", "integer
factorisation" and "RSA breaking" cannot become three groups. A class is added here, by the operator, when a real proposal fits none of them.

Declarations already in domains/ are NOT edited to add the line (a registered declaration must match its compiled record byte for byte), so their class is
looked up from KNOWN below. A new proposal states its own; an absent line is shown as "unsorted" until the operator adds one to domains/NAME/decl.py
(before it is compiled; `intake.py accept` says so).
"""

CLASSES = {
    "lattice": ("Lattice problems",
                "Short vectors, learning with errors, NTRU and SIS: finding structure in a lattice. A faster lattice reduction or sieve is a real security result."),
    "number-theory": ("Factoring and discrete logarithms",
                      "Integer factoring, discrete logarithms, and partial-information attacks on them. A faster method here breaks deployed public-key systems."),
    "combinatorial": ("Search and optimisation",
                      "Subset sum, graph cuts, satisfiability and similar: a better exact or heuristic search, judged on answers that can be checked or scored."),
    "ai-inference": ("AI inference and decoding",
                     "Running a fixed model faster at equivalent output: caching, batching, pruning, lower precision. Measured as time, operation counts or GPU time."),
    "ai-training": ("AI training",
                    "Training a model to a target accuracy with fewer operations: optimisers, momentum, feature scaling, learning-rate choices, early stopping. Judged on a hidden test set and measured as exact operation counts."),
    "quantum": ("Quantum circuits",
                "Circuit-level claims: fewer gates or lower depth for the same unitary or distribution."),
    "other": ("Other",
              "Fits none of the above. Say in NOTES.md what is being sped up; if several proposals land here the operator adds a class."),
}

UNSORTED = "unsorted"   # a proposal that did not name a class: shown as such, never guessed

# Existing families and domains. Built-ins (gm, mlwe, factor) are set up by hand; the rest are under domains/.
KNOWN = {
    "gm": "lattice", "mlwe": "lattice", "lwe": "lattice", "rlwe": "lattice", "ntru": "lattice", "sis": "lattice",
    "factor": "number-theory", "dlog": "number-theory", "copper": "number-theory", "hnp": "number-theory",
    "knap": "combinatorial", "maxcut": "combinatorial",
    "aiinfer": "ai-inference", "aidecode": "ai-inference", "aifactor": "ai-inference", "aitrain": "ai-training", "aimlp": "ai-training",
}


def valid(value):
    return isinstance(value, str) and value in CLASSES


def of(name, declared=None):
    """The class of a problem: its own SPEEDUP line if it has a valid one, else the table above, else UNSORTED."""
    if valid(declared):
        return declared
    return KNOWN.get(name, UNSORTED)


def order_key(name, declared=None):
    """Sort key that puts problems in the order of CLASSES (unsorted last), then by name."""
    c = of(name, declared)
    return (list(CLASSES).index(c) if c in CLASSES else len(CLASSES), name)


def title(cls):
    return CLASSES[cls][0] if cls in CLASSES else "Unsorted"


def group(items):
    """items: iterable of (name, declared_class_or_None). Returns {class: [names]} in CLASSES order, with UNSORTED last and empty classes left out."""
    out = {}
    for name, declared in items:
        out.setdefault(of(name, declared), []).append(name)
    ordered = {c: sorted(out[c]) for c in list(CLASSES) + [UNSORTED] if c in out}
    return ordered


def listing():
    return "\n".join(f"  {c:14s} {t}\n  {'':14s} {d}" for c, (t, d) in CLASSES.items())
