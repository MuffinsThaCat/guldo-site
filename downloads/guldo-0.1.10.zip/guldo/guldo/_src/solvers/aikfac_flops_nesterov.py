"""aikfac in the counted-operations API, TECHNIQUE (the best FIRST-order method, for fairness): Nesterov's accelerated gradient with the strongly-convex momentum beta = (sqrt(k)-1)/(sqrt(k)+1), k = L/lambda, step 1/L, stopping when |g|^2 is small enough (checked every 25 steps)."""
import math

import tensorops as tp

K = 8
RHO = 0.9
LAM = 1e-3
GRAD2 = 2e-13          # gap <= |g|^2 / (2 lambda) <= 1e-10 (a margin of 100 under the judge's 1e-8)


def features(seed, n, N):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(n)] for k in range(n)])
    return (tp.reshape(tp.stream(seed, 0, N * n), (N, n)) @ U) * math.sqrt(1.0 - RHO * RHO)


def onehot(labels, N):
    return tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(N)])


def softmax(S):
    E = tp.exp(S - tp.max(S, 1, True))
    return E / tp.sum(E, 1, True)


def answer(W, n):
    return [int(v * 1048576.0) for v in tp.reshape(W, (n * K,)).tolist()]
MAXSTEPS = 20000
CHECK = 25


def solve(seed, n, N, labels):
    X = features(seed, n, N)
    Y = onehot(labels, N)
    Xt = tp.transpose(X, (1, 0))
    L = tp.sum(X * X).item() / (2.0 * N) + LAM
    beta = (math.sqrt(L / LAM) - 1.0) / (math.sqrt(L / LAM) + 1.0)
    W = tp.zeros((n, K))
    V = W
    for step in range(MAXSTEPS):
        Wn = V - (Xt @ (softmax(X @ V) - Y) * (1.0 / N) + V * LAM) * (1.0 / L)
        V = Wn + (Wn - W) * beta
        W = Wn
        if step % CHECK == CHECK - 1:
            g = Xt @ (softmax(X @ W) - Y) * (1.0 / N) + W * LAM
            if tp.sum(g * g).item() <= GRAD2:
                break
    return answer(W, n)
