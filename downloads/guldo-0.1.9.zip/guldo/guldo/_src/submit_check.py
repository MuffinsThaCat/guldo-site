"""Pre-flight check for a submission. Run this before sending a solver in.

  python3 submit_check.py solvers/my_solver.py [--family gm|mlwe] [--n 3]

It (1) lints the source for things the judge's sandbox will block or treat as an attempt to evade metering, (2) runs the
solver in a bare local process on small PUBLIC practice instances, checks every answer with the real verifier, checks
the solver is deterministic, and reports CPU cost. A pass here means "well-formed", not "fast enough to certify".
Exit code: 0 = ok (warnings allowed), 1 = a fatal problem.
"""
import argparse
import ast
import os
import sys

import families
import harness
import instances

# (name or dotted prefix, why it matters). These are warnings: the sandbox enforces; the point is to avoid surprises.
SUSPECT_CALLS = {
    "os.fork": "forking: all descendants are billed and orphans are killed at the deadline; detached daemons are an evasion attempt",
    "os.setsid": "detaching from the process group looks like an attempt to hide CPU from the meter",
    "os.system": "spawns a shell; descendants are billed, and there is no shell or network in the sandbox",
    "subprocess": "spawning processes: descendants are billed; most tools will not exist in the sandbox image",
    "multiprocessing": "extra processes are billed in total CPU, and the sandbox is limited to one CPU and 64 pids",
    "threading": "threads are billed in total CPU; the sandbox is limited to one CPU",
    "socket": "there is no network in the sandbox",
    "urllib": "there is no network in the sandbox",
    "requests": "there is no network in the sandbox",
    "glob": "the sandbox filesystem is read-only and contains nothing of the judge's; reading seeds or judge code is disqualifying",
    "open": "files: only /work/submission.py and the Python stdlib/site-packages are readable; do not read judge files or seeds",
    "importlib": "dynamic imports: everything you need must be importable in the sandbox image (fpylll, numpy only)",
    "__import__": "dynamic imports: everything you need must be importable in the sandbox image (fpylll, numpy only)",
    "sys.path": "path tricks: the judge's modules are not importable in the sandbox, and trying to import them is disqualifying",
    "os.environ": "the sandbox passes only PATH, OMP_NUM_THREADS and PYTHONHASHSEED",
    "time.sleep": "sleeping costs no CPU but counts toward the wall-clock deadline",
}
ALLOWED_THIRD_PARTY = {"fpylll", "numpy", "cysignals"}


def stdlib_names():
    """Top-level standard-library module names. sys.stdlib_module_names exists from Python 3.10; on 3.9 build the same set from the
    interpreter's own library directory (a missing name would only mis-label a stdlib import in a WARNING, never reject a file)."""
    names = getattr(sys, "stdlib_module_names", None)
    if names is not None:
        return names
    import sysconfig
    found = set(sys.builtin_module_names)
    root = sysconfig.get_paths()["stdlib"]
    for d in (root, os.path.join(root, "lib-dynload")):
        try:
            for n in os.listdir(d):
                found.add(n[:-3] if n.endswith(".py") else n.split(".")[0])
        except OSError:
            pass
    return found


def dotted(node):
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    return ".".join(reversed(parts))


def lint(path):
    try:
        with open(path, "rb") as f:
            tree = ast.parse(f.read())  # BYTES, so a PEP 263 coding cookie is honoured exactly as the interpreter will: lint sees what runs
    except SyntaxError as e:  # includes NUL bytes, unknown encodings, invalid UTF-8 and over-deep nesting: a clean FATAL, never a traceback
        return [], [f"syntax error: {e.msg} (line {e.lineno})"]
    except (ValueError, RecursionError, MemoryError) as e:
        return [], [f"could not parse the file ({type(e).__name__})"]
    warnings, fatal = [], []
    def defines_solve(n):
        if isinstance(n, ast.AsyncFunctionDef) and n.name == "solve":
            fatal.append("`async def solve` is not supported: the runner calls solve() synchronously, so an async solver "
                         "would return an un-awaited coroutine and crash")
            return True  # defined, but already reported as fatal
        if isinstance(n, ast.FunctionDef):
            return n.name == "solve"
        if isinstance(n, ast.Assign):  # solve = some_function / solve = lambda ...
            return any(isinstance(t, ast.Name) and t.id == "solve" for t in n.targets)
        if isinstance(n, ast.ImportFrom):  # from helper import solve
            return any((a.asname or a.name) == "solve" for a in n.names)
        return False

    if not any(defines_solve(n) for n in tree.body):
        fatal.append("no top-level `solve` (a function, an assignment, or an import named solve)")
    seen = set()
    for node in ast.walk(tree):
        names = []
        if isinstance(node, ast.Call):
            names.append(dotted(node.func))
        elif isinstance(node, (ast.Attribute, ast.Name)):
            names.append(dotted(node))
        elif isinstance(node, ast.Import):
            names += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.append(node.module)
        for nm in names:
            for key, why in SUSPECT_CALLS.items():
                if (nm == key or nm.startswith(key + ".")) and key not in seen:
                    seen.add(key)
                    warnings.append(f"line {getattr(node, 'lineno', '?')}: `{key}` - {why}")
    stdlib = stdlib_names()
    for node in ast.walk(tree):
        mods = [a.name for a in node.names] if isinstance(node, ast.Import) else \
            [node.module] if isinstance(node, ast.ImportFrom) and node.module and node.level == 0 else []
        for m in mods:
            top = m.split(".")[0]
            if top not in stdlib and top not in ALLOWED_THIRD_PARTY:
                warnings.append(f"line {node.lineno}: imports `{top}`, which is not in the sandbox image "
                                f"(only fpylll, numpy, cysignals); it will crash there")
    return warnings, fatal


def check(path, family="gm", n=3, dims=None, budget=30):
    """Returns (ok, report_lines)."""
    lines = []
    warnings, fatal = lint(path)
    for w in warnings:
        lines.append(f"WARN  {w}")
    for f in fatal:
        lines.append(f"FATAL {f}")
    if fatal:
        lines.append("RESULT: FIX THE FATAL ITEMS ABOVE")  # the same closing line every other outcome ends with
        return False, lines
    dims = dims or families.PRACTICE_DIMS[family]
    path = os.path.abspath(path)
    bad = 0
    for d in dims:
        for i in range(n):
            inst = families.derive(family, instances.PRACTICE_SEED, d, i)
            r1 = harness.run_one(path, inst, budget)
            r2 = harness.run_one(path, inst, budget)
            tag = f"{family} dim {d} #{i}: {r1['status']:8s} cpu {r1['cpu']:6.2f}s"
            if r1["status"] in ("wrong", "crash"):
                bad += 1
                tag += "   <-- " + (r1.get("err", "")[-160:].replace("\n", " ") or "invalid vector")
                lines.append(f"FATAL {tag}")
                continue
            lines.append(f"ok    {tag}")
            if r1["status"] != r2["status"]:
                lines.append(f"WARN  not deterministic: status {r1['status']} then {r2['status']} on the same instance")
    ok = bad == 0
    lines.append("RESULT: " + ("well-formed (this says nothing about speed)" if ok else "FIX THE FATAL ITEMS ABOVE"))
    return ok, lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("solver")
    ap.add_argument("--family", default="gm", choices=sorted(families.FAMILIES))
    ap.add_argument("--n", type=int, default=3)
    a = ap.parse_args()
    ok, lines = check(a.solver, a.family, a.n)
    print("\n".join(lines))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
