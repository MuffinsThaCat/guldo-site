"""Declaration of a distributed-training domain WITH A TOPOLOGY: the exact gradient of a two-layer network over a batch, on a cluster of 8 devices in TWO NODES of four, with as little TIME as the machine allows.

The task is the one of `aidist` (same network, same gradient, same judge): size = d, hidden h = 4 d (ReLU), output c = 8, a batch of B = 8 d; squared loss; x, W1T, W2 and Y are the SplitMix64 stream under `seed` (tensorops.stream,
the same floats as domains/aiinfer), in that order; the answer is the flat gradient [dL/dW1T, dL/dW2] as integers in units of 2^-40, accepted within 1e-6 of its norm.

What is new is the machine. The devices are in two nodes (devices 0-3, devices 4-7): a message inside a node is cheap and a message between nodes is not, and the cost of a run (tflops_dist3.py, tensorops_dist3.py) is
counted per kind of link: T = wcrit + steps + a_i * ri + b_i * ci/L + a_x * rx + b_x * cx/L, EXACT on every machine (a, b the latency and inverse bandwidth of the intra-node and inter-node links). A collective over a group
inside a node uses the intra link; one that spans the nodes pays the inter link for all of it. That is what makes LAYOUT matter: data parallelism over all 8 devices all-reduces the whole gradient across the slow link;
tensor parallelism over all 8 all-reduces the activations across it at every layer; a 2D layout puts the frequent, large traffic (the tensor-parallel reductions) inside a node and only the rare, small traffic (each
node's slice of the gradient) between nodes. Whether that wins, on which machines, and by how much, is computed (the grid is 12 intra-node machines times an inter link 1, 10 or 100 times slower), not argued.

It is an accounting convention, not a measurement (see tensorops_dist3.py): two link classes, a barrier at every collective, no overlap of compute and communication, no congestion.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aitopo"
VERSION = "aitopo-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 48)
SIZE_STEP = 8
REFERENCE_SOLVER = "reference.py"
RANKS = 8                     # devices the instance has
NODE = 4                      # devices per node: devices 0-3 are node 0, devices 4-7 node 1
C = 8                         # output width
SCALE = 2 ** 40
LIMIT = 2 ** 62
REL_TOL = 1e-6
DOC = ("solve(seed, d, B, P): x (B x d), W1T (h x d, h = 4d, times sqrt(3/d)), W2 (h x 8, times sqrt(3/h)) and Y (B x 8) are the SplitMix64 stream under `seed` (tensorops.stream, u in [-1, 1), row-major, in that order; "
       "B = 8d); loss = 0.5 * mean over the B*8 entries of (relu(x W1T^T) W2 - Y)^2. P = 8 devices are available, in two nodes of four (tp.use(k), tp.all_reduce / reduce_scatter / all_gather with an optional group, or a list of disjoint groups run at once, tp.broadcast, tp.exchange, tp.all_to_all). Return the gradient "
       "[dL/dW1T (h x d row-major), dL/dW2 (h x 8 row-major)] as one flat list of h*d + h*8 integers in units of 2^-40, within 1e-6 of its norm. Return None for no answer.")
REFERENCE_NOTE = ("One device does everything: no communication, all the arithmetic on device 0. Known to be beaten, on a machine whose links are fast enough relative to its compute, by data parallelism, tensor parallelism "
                  "and 2D layouts of them; which layout wins depends on how much slower the link between the nodes is.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def parts(seed, d):
    B, h = 8 * d, 4 * d
    x = _uniform(seed, 0, B * d).reshape(B, d)
    W1T = _uniform(seed, B * d, h * d).reshape(h, d) * math.sqrt(3.0 / d)
    W2 = _uniform(seed, B * d + h * d, h * C).reshape(h, C) * math.sqrt(3.0 / h)
    Y = _uniform(seed, B * d + h * d + h * C, B * C).reshape(B, C)
    return x, W1T, W2, Y


def gradient(seed, d):
    x, W1T, W2, Y = parts(seed, d)
    B = len(x)
    a = x @ W1T.T
    h1 = np.maximum(a, 0.0)
    dy = (h1 @ W2 - Y) / (B * C)
    dW2 = h1.T @ dy
    dh = (dy @ W2.T) * (a > 0)
    dW1T = dh.T @ x
    return np.concatenate([dW1T.ravel(), dW2.ravel()])


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aitopo-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, 8 * size, RANKS], "planted": [int(v) for v in np.rint(gradient(seed, size) * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, d, B, P = inst["args"]
    n = 4 * d * d + 4 * d * C
    if not isinstance(ans, list) or len(ans) != n:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    true = gradient(seed, d)
    got = np.array(ans, dtype=np.float64) / SCALE
    return bool(np.linalg.norm(got - true) <= REL_TOL * np.linalg.norm(true) + n * 2.0 ** -40)
