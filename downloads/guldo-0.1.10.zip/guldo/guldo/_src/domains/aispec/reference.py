"""Reference for aispec: the full model, float64, one token at a time.

The model definition (the contract a submission must reproduce): SplitMix64 counter stream under `seed`, element k = finalise((k+1)*GOLD + seed), mapped to [-1, 1) as
(z >> 11) * 2^-52 - 1. Stream layout, in order, each row-major: E (64 x 128, scale sqrt 3), pos (T x 128, scale 3 sqrt 3), A1 (128 x 8), B1 (8 x 1024), A2 (1024 x 8), B2 (8 x 128) (all scale 1),
N1 (128 x 1024, scale 4/sqrt(128)), N2 (1024 x 128, scale 4/sqrt(1024)), then one float for the prompt token = min(int((u + 1) / 2 * 64), 63). With c1 = 4/sqrt(128) * 3/sqrt(8) and
c2 = 4/sqrt(1024) * 3/sqrt(8): W1 = c1 A1 B1 + 0.15 N1, W2 = c2 A2 B2 + 0.15 N2. Step t: x = E[prev] + pos[t]; y = x + relu(rms(x) W1) W2; logits = rms(y) E^T; the token is the argmax
(rms(v) = v / sqrt(mean(v^2) + 1e-6)). The draft model is c1 A1 B1 and c2 A2 B2 alone (rank 8).
"""
import math

import numpy as np

_V, _D, _H, _R = 64, 128, 1024, 8


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def solve(seed, T):
    o = 0

    def take(shape, scale):
        nonlocal o
        n = int(np.prod(shape))
        a = (_uniform(seed, o, n) * scale).reshape(shape)
        o += n
        return a
    E = take((_V, _D), math.sqrt(3.0))
    pos = take((T, _D), 3.0 * math.sqrt(3.0))
    A1, B1, A2, B2 = take((_D, _R), 1.0), take((_R, _H), 1.0), take((_H, _R), 1.0), take((_R, _D), 1.0)
    N1, N2 = take((_D, _H), 4.0 / math.sqrt(_D)), take((_H, _D), 4.0 / math.sqrt(_H))
    W1 = 4.0 / math.sqrt(_D) * 3.0 / math.sqrt(_R) * (A1 @ B1) + 0.15 * N1
    W2 = 4.0 / math.sqrt(_H) * 3.0 / math.sqrt(_R) * (A2 @ B2) + 0.15 * N2
    tok = min(int((_uniform(seed, o, 1)[0] + 1.0) * 0.5 * _V), _V - 1)
    out = []
    for t in range(T):
        x = E[tok] + pos[t]
        y = x + np.maximum(_rms(x) @ W1, 0.0) @ W2
        tok = int(np.argmax(_rms(y) @ E.T))
        out.append(tok)
    return out
