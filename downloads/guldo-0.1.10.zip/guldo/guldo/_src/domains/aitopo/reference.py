"""Reference for aitopo: one device does everything (float64), as in aidist."""
import math

import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, B, P):
    h, c = 4 * d, 8
    x = _uniform(seed, 0, B * d).reshape(B, d)
    W1T = _uniform(seed, B * d, h * d).reshape(h, d) * math.sqrt(3.0 / d)
    W2 = _uniform(seed, B * d + h * d, h * c).reshape(h, c) * math.sqrt(3.0 / h)
    Y = _uniform(seed, B * d + h * d + h * c, B * c).reshape(B, c)
    a = x @ W1T.T
    h1 = np.maximum(a, 0.0)
    dy = (h1 @ W2 - Y) / (B * c)
    g = np.concatenate([(((dy @ W2.T) * (a > 0)).T @ x).ravel(), (h1.T @ dy).ravel()])
    return [int(v) for v in np.rint(g * 2 ** 40)]
