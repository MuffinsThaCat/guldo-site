#!/usr/bin/env bash
# Provision a DISPOSABLE evaluation machine for timed rounds, from a fresh Ubuntu (22.04 or newer) or Debian server, in one command.
# Run it AS ROOT, from a copy of this project that is on the machine (rsync the project there first; EVAL_BOX.md has the exact command):
#
#   sudo bash deploy/provision_eval.sh [--no-firewall] [--no-ssh-hardening] [--skip-gates]
#
# What it does, in order (every step is safe to repeat):
#   packages (Docker, Python, numpy, cryptography, rsync) -> swap if the machine has little memory -> the unprivileged operator user `ledger-ops`
#   (in the docker group on a disposable machine; with --shared-with-web never) -> the data and seed directories ->
#   the code under /opt/speedup-verification (root-owned, not writable by others) -> the firewall (only ssh) and key-only ssh ->
#   the sandbox image -> the Linux meter self-test -> the whole sandbox test suite and the SANDBOX_VERIFIED marker the worker requires.
# It stops at the first failure and says which step failed. It never touches seeds, DNS, or any other machine.
set -euo pipefail

FIREWALL=1; HARDEN_SSH=1; GATES=1; SHARED=0
for a in "$@"; do
  case "$a" in
    --shared-with-web) SHARED=1 ;;   # this machine ALSO runs the web portal: keep its users, data-directory permissions and seeds exactly as they are
    --no-firewall) FIREWALL=0 ;;
    --no-ssh-hardening) HARDEN_SSH=0 ;;
    --skip-gates) GATES=0 ;;
    -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
    *) echo "unknown option: $a"; exit 2 ;;
  esac
done

step() { printf '\n== %s\n' "$*"; }
die() { printf '\nFAILED at: %s\n' "$*" >&2; exit 1; }
trap 'die "${STEP:-startup} (line $LINENO)"' ERR

[ "$(id -u)" = 0 ] || { echo "run as root (sudo bash deploy/provision_eval.sh)"; exit 1; }
command -v apt-get >/dev/null || { echo "this script supports apt-based systems (Ubuntu, Debian)"; exit 1; }
SRC="$(cd "$(dirname "$0")/.." && pwd)"
DEST=/opt/speedup-verification
DATA=/srv/ledger/data
[ -f "$SRC/harness.py" ] && [ -f "$SRC/sandbox/Dockerfile.v2" ] || { echo "run it from a copy of the project (harness.py and sandbox/ not found in $SRC)"; exit 1; }

STEP="packages"; step "$STEP"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq python3 python3-numpy python3-cryptography rsync ca-certificates curl >/dev/null
if ! command -v docker >/dev/null; then apt-get install -y -qq docker.io >/dev/null; fi
systemctl enable --now docker >/dev/null 2>&1 || true
docker version --format 'docker {{.Server.Version}}' || die "docker is not answering"

STEP="swap"; step "$STEP"
mem_mb=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
if [ "$mem_mb" -lt 3500 ] && ! swapon --show | grep -q .; then
  fallocate -l 4G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  echo "added 4 GB of swap (RAM is ${mem_mb} MB)"
else
  echo "no swap needed (RAM ${mem_mb} MB, or swap already present)"
fi

STEP="users and directories"; step "$STEP"
id ledger-ops >/dev/null 2>&1 || useradd -m -s /bin/bash ledger-ops
# Membership of the docker group is root-equivalent. On a disposable evaluation machine that is acceptable. On a machine that also serves the portal it is
# NOT: ledger-ops is the account that evaluates strangers' counted solvers, so it is never put in the group there. Docker is reached instead by running a
# command as root with `sudo -u ledger-ops -g docker ...`, which gives that one process the docker group as its primary group and nothing persistent.
if [ "$SHARED" = 0 ]; then usermod -aG docker ledger-ops; fi
if [ "$SHARED" = 1 ]; then
  # the web tier writes this directory through the group `ledger` (setgid, 2770): do not tighten it, or submissions stop working
  [ -d "$DATA/rounds" ] || { echo "--shared-with-web expects the web layout from DEPLOY.md already in place ($DATA/rounds missing)"; exit 1; }
  install -d -o ledger-ops -g ledger-ops -m 0755 /srv/ledger/results
  echo "shared machine: left $DATA and /srv/ledger/seeds exactly as they are"
else
  install -d -o ledger-ops -g ledger-ops -m 0755 /srv/ledger
  install -d -o ledger-ops -g ledger-ops -m 0750 "$DATA" "$DATA/rounds"
  install -d -o ledger-ops -g ledger-ops -m 0700 /srv/ledger/seeds
  install -d -o ledger-ops -g ledger-ops -m 0755 /srv/ledger/results
fi
echo "operator user ledger-ops; data $DATA; seeds /srv/ledger/seeds (0700)"
# round_sync.py logs in as ledger-ops (not root) so that copied files get the right owner; it uses the same key you used for root
if [ -s /root/.ssh/authorized_keys ]; then
  install -d -o ledger-ops -g ledger-ops -m 0700 /home/ledger-ops/.ssh
  install -o ledger-ops -g ledger-ops -m 0600 /root/.ssh/authorized_keys /home/ledger-ops/.ssh/authorized_keys
  echo "ssh key installed for ledger-ops"
fi

STEP="code"; step "$STEP"
mkdir -p "$DEST"
if [ "$SRC" != "$DEST" ]; then
  rsync -a --delete --exclude .git --exclude __pycache__ --exclude /site --exclude /dist --exclude /ledger --exclude /ledger-seeds \
        --exclude /ledger-submissions --exclude /results --exclude .vercel "$SRC"/ "$DEST"/
fi
install -d -o ledger-ops -g ledger-ops -m 0755 "$DEST/results"
chown -R root:root "$DEST"; chown ledger-ops:ledger-ops "$DEST/results"; chmod -R go-w "$DEST"
echo "code installed in $DEST"

if [ "$FIREWALL" = 1 ]; then
  STEP="firewall"; step "$STEP"
  apt-get install -y -qq ufw fail2ban >/dev/null
  ufw allow OpenSSH >/dev/null; ufw --force enable >/dev/null
  ufw status | head -4
fi

if [ "$HARDEN_SSH" = 1 ]; then
  STEP="ssh hardening"; step "$STEP"
  if [ -s /root/.ssh/authorized_keys ]; then
    printf 'PasswordAuthentication no\nPermitRootLogin prohibit-password\n' > /etc/ssh/sshd_config.d/10-hardening.conf
    sshd -t && (systemctl reload ssh 2>/dev/null || systemctl reload sshd)
    echo "password logins are off; root may log in with a key only"
  else
    echo "SKIPPED: /root/.ssh/authorized_keys is empty, and turning passwords off now would lock you out. Add your key, then rerun."
  fi
fi

STEP="sandbox image"; step "$STEP"
cd "$DEST"
BUILD="docker build"; docker buildx version >/dev/null 2>&1 && BUILD="docker build --load"   # Ubuntu's docker.io has no buildx and no --load flag
$BUILD -t svp-solver -f sandbox/Dockerfile.v2 . >/tmp/provision-build.log 2>&1 || { tail -20 /tmp/provision-build.log; die "docker build (log above)"; }
docker image inspect svp-solver --format 'image {{.Id}}' | cut -c1-40

if [ "$GATES" = 1 ]; then
  STEP="Linux meter self-test"; step "$STEP"
  python3 sandbox/linux_selftest.py
  STEP="sandbox tests and marker"; step "$STEP"
  mkdir -p "$DATA"; [ "$SHARED" = 1 ] || chown ledger-ops:ledger-ops "$DATA"
  sudo -u ledger-ops -g docker python3 launch_gates.py --only env,docker --with-docker --data "$DATA"
  sudo -u ledger-ops python3 -c "import portal_core, sys; sys.exit(0 if portal_core.sandbox_verified('$DATA') else 1)" || die "the SANDBOX_VERIFIED marker is missing or stale"
  echo "sandbox VERIFIED on this machine: the worker will now evaluate timed rounds here"
fi

if [ "$SHARED" = 1 ]; then
  printf '\nNote: ledger-ops is NOT in the docker group on this shared machine, on purpose. Run the timed worker as root with\n  sudo -u ledger-ops -g docker python3 ops.py worker ...\nso that only that process has Docker access (EVAL_BOX.md).\n'
fi
printf '\nDone. Next (EVAL_BOX.md): push a closed round here with round_sync.py, run ops.py worker as ledger-ops, then pull it back.\n'
