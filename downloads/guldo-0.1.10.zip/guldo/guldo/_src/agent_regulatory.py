"""Regulatory packaging: map what a verified agent-evaluation package actually evidences onto the language of the frameworks people cite, and say what it does NOT cover.

THIS IS NOT A COMPLIANCE ASSESSMENT AND NOT LEGAL ADVICE. No certificate makes a provider compliant with anything. The output is an evidence index: for each provision, a short paraphrase of what it asks,
what the package supplies toward it, and what it leaves to the provider. The paraphrases are mine, not the legal text; read the source before relying on a line.

CHECKED against the primary or official pages in this session (see SOURCES): EU AI Act Article 55(1)(a) (providers of general-purpose AI models WITH SYSTEMIC RISK must perform model evaluation in
accordance with standardised protocols and tools reflecting the state of the art, including conducting and documenting adversarial testing; obligations apply from 2 August 2025; codes of practice can be
relied on until harmonised standards exist), NIST AI RMF 1.0 MEASURE 2.3 (performance or assurance criteria measured quantitatively or qualitatively under conditions similar to deployment, differences
documented), NIST AI 800-1 (a voluntary draft on managing misuse risk of dual-use foundation models; a search on 11-27 found it still at its SECOND PUBLIC DRAFT, January 2025, comments closed March 2025,
no final version; its text itself was not read). Also checked on 11-27: EU AI Act Article 15 (applies ONLY to high-risk AI systems; requires an appropriate level of accuracy, robustness and cybersecurity,
the Commission to foster benchmarks and measurement methodologies, and the levels of accuracy and the relevant accuracy metrics to be declared in the instructions of use), and the Commission's General-Purpose
AI Code of Practice (final 10 July 2025, voluntary; its Safety and Security chapter, for the few most advanced models, expects state-of-the-art model evaluations per identified risk, such as benchmarks,
red teaming and human uplift studies, with inputs and outputs recorded so that others can interpret the results). The Code is known here from the Commission's page and secondary summaries, NOT from its
own text. NOT checked: harmonised standards (none read), Annex XIII, the Code's full text. Regulatory text changes; verify before use.

What the package can supply: a pre-registered, seed-committed test; exact output verification; recomputable results with bounds; cost; for safety domains, separately counted unsafe outcomes and a timestamped
register; optionally attested or witnessed provenance. What it cannot: that a model is safe, a systemic-risk assessment, incident reporting, cybersecurity of the model or infrastructure, anything about
conditions unlike the generator, or the benchmark-validity question (whether these tasks represent real use).
"""
import agent_core

SOURCES = [("EU AI Act, Article 55 (AI Act Service Desk)", "https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-55"),
           ("EU AI Act Article 55 text (artificialintelligenceact.eu)", "https://artificialintelligenceact.eu/article/55/"),
           ("NIST AI RMF Playbook, MEASURE", "https://airc.nist.gov/airmf-resources/playbook/measure/"),
           ("NIST AI 800-1 (second public draft)", "https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.800-1.ipd2.pdf"),
           ("EU AI Act, Article 15 (AI Act Service Desk)", "https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-15"),
           ("European Commission, General-Purpose AI Code of Practice (now available)", "https://digital-strategy.ec.europa.eu/en/news/general-purpose-ai-code-practice-now-available"),
           ("European Commission, contents of the GPAI Code of Practice", "https://digital-strategy.ec.europa.eu/en/policies/contents-code-gpai")]


def _rows(f):
    """f: facts about the package. Returns [(framework, provision, asks, supplies, leaves, status)]; status is one of 'supplies in part', 'supplies nothing'."""
    prov = []
    if f["attested"]:
        prov.append("receipts signed by a pinned key vouch that each recorded model call was made and its token usage relayed unmodified")
    elif f["witnesses"]:
        prov.append("%d independent witness(es) re-verified the ladder (a key you pinned)" % f["witnesses"])
    else:
        prov.append("NO attestation or witness: the records are internally consistent, but nothing shows a model produced them beyond the operator's word")
    practice = " This package was made on the PUBLIC PRACTICE seed: it demonstrates the method and certifies nothing." if f["practice"] else ""
    rows = [
        ("EU AI Act", "Art. 55(1)(a): model evaluation with standardised protocols and state-of-the-art tools, incl. documented adversarial testing (GPAI models with systemic risk)",
         "A documented, repeatable evaluation protocol. Adversarial testing is named.",
         "A fully specified protocol (plan hash fixed before any entry, seed committed, caps recorded, exact verifiers, recomputable comparison with exact bounds). Provenance: " + "; ".join(prov) + "." + practice
         + (" The injection domain is an adversarial test of one property (obeying instructions planted in data); the toyctf domain is a multi-step capability stand-in." if f["safety_domain"] else " No safety/adversarial domain was run."),
         "That the protocol is 'standardised' in the regulatory sense (it is not a harmonised standard or the Code of Practice); the evaluation of systemic risks themselves; red-teaming by humans; elicitation at the provider's best effort.",
         "supplies in part"),
        ("EU AI Act", "Art. 55(1)(a)/(b): systemic-risk assessment and mitigation (paraphrase; (b) not re-read in detail)",
         "An assessment of systemic risks at Union level and measures to mitigate them.", "Nothing directly. A capability measurement with a date can be one input to such an assessment (agent_safety register).",
         "The assessment, the mitigation, the judgement of what counts as systemic.", "supplies nothing"),
        ("EU AI Act", "Art. 55(1)(c): tracking, documenting and reporting serious incidents", "An incident process.", "Nothing. A certificate describes a test, not operations.", "All of it.", "supplies nothing"),
        ("EU AI Act", "Art. 55(1)(d): adequate cybersecurity for the model and its infrastructure", "Cybersecurity of the model and infrastructure.",
         "Nothing. toyctf is an invented puzzle and says nothing about real security.", "All of it.", "supplies nothing"),
        ("EU AI Act", "Art. 15(1),(3) (HIGH-RISK AI systems only): an appropriate level of accuracy and robustness, with the levels and relevant accuracy metrics declared in the instructions of use",
         "Measured, declared accuracy with named metrics; applies to high-risk systems, not to general-purpose models as such.",
         "Per-size solve rates with exact lower bounds and a failure-rate upper bound (agent_insurer) for the TESTED tasks, in a recomputable form that names its metric. Art. 15(2), the Commission fostering benchmarks, is not an obligation on providers.",
         "Accuracy on the deployer's real tasks and data; robustness to real distribution shift; whether the system is high-risk at all; the instructions-for-use wording; Art. 15(4)-(5) (resilience, feedback loops, cybersecurity against data and model poisoning).", "supplies in part"),
        ("EU GPAI Code of Practice (voluntary; final 10 July 2025), Safety and Security chapter: model evaluations [known from the Commission's page and secondary summaries, not the Code's text]",
         "Model evaluations", "State-of-the-art evaluations per identified systemic risk (benchmarks, red teaming, human uplift studies), with inputs and outputs recorded so that others can interpret the results.",
         "A benchmark-style evaluation whose full record is recomputable: every input derives from the committed seed, and every trajectory (inputs, tool calls, outputs) is stored and replayable, so a third party can re-interpret the result.",
         "Red teaming and human uplift studies; risk identification; the choice of which risks to evaluate; elicitation at the provider's best effort; the Code's own commitments beyond evaluation.", "supplies in part"),
        ("NIST AI RMF 1.0", "MEASURE 2.3: performance or assurance criteria measured quantitatively or qualitatively under conditions similar to deployment, with differences documented",
         "Quantitative performance measurement in conditions like deployment; document the gap.",
         "Quantitative, reproducible measurement with bounds and cost. The gap to deployment is stated in every result's LIMITS (public generator, proxy tokens, tested sizes)." + practice,
         "Conditions similar to the deployer's: the generator is not their workload. Measurement 'in collaboration with AI actors in user-interaction roles' is not covered.", "supplies in part"),
        ("NIST AI 800-1 (draft, voluntary)", "Managing misuse risk of dual-use foundation models (the draft's practices on measuring misuse risk; final text not checked)",
         "Practices for estimating and tracking misuse risk across a model's lifecycle.",
         ("Dated, hash-chained capability and unsafe-outcome records on invented stand-in domains." if f["safety_domain"] else "Nothing: no safety domain was run."),
         "Domain-specific misuse evaluations (biological, chemical, cyber with real hazard content) are deliberately not built; thresholds and decisions to deploy.", "supplies in part" if f["safety_domain"] else "supplies nothing"),
    ]
    return rows


def package_report(header, records, attested=False, witnesses=0, register_head=None, verified=False):
    """`attested` and `witnesses` should come from the actual checks (agent_attest.verify_attested passing; agent_witness.check_witnesses counting keys you pinned), never be typed in; agent_tools
    computes them from the files. `verified` means the ladder itself was re-verified from the seed. The report states each as it was passed."""
    import agent_compare
    import agent_safety
    sm = agent_compare.summarize(header, records)
    facts = {"attested": bool(attested), "witnesses": int(witnesses), "practice": bool(header["practice"]), "safety_domain": agent_safety.is_safety_domain(header["domain"])}
    rows = [dict(zip(("framework", "provision", "asks", "package_supplies", "left_to_the_provider", "status"), r)) for r in _rows(facts)]
    return {"not_legal_advice": True, "ladder_verified_from_seed": bool(verified), "attested_checked": bool(attested), "independent_witnesses_counted": int(witnesses),
            "agent": header.get("agent", {}).get("label"), "domain": header["domain"], "plan_hash": header["plan_hash"], "practice": header["practice"],
            "headline": {"solve_rate_lower95": sm["solve_rate_lower95"], "stratified_lower95": sm["solve_rate_stratified_lower95"], "instances": sm["instances"]},
            "safety_register_head": register_head, "evidence_index": rows, "sources_checked": [{"title": t, "url": u} for t, u in SOURCES],
            "not_checked": ["the Code of Practice's own text (known from the Commission's page and summaries)", "harmonised standards", "EU AI Act Annex XIII", "the text of NIST AI 800-1 (no final version existed when searched)"]}


def render(rep):
    L = ["EVIDENCE INDEX (not a compliance assessment, not legal advice)", "%s on %s, plan %s%s" % (rep["agent"], rep["domain"], rep["plan_hash"][:16], "  [PRACTICE SEED]" if rep["practice"] else ""),
         "ladder re-verified from the seed: %s; receipts verified: %s; independent witnesses counted: %d" % ("yes" if rep.get("ladder_verified_from_seed") else "NO (the figures are only as good as the file)",
                                                                                                    "yes" if rep.get("attested_checked") else "no", rep.get("independent_witnesses_counted", 0))]
    for r in rep["evidence_index"]:
        L += ["", "%s | %s" % (r["framework"], r["provision"]), "  asks     : " + r["asks"], "  supplies : " + r["package_supplies"], "  leaves   : " + r["left_to_the_provider"], "  status   : " + r["status"]]
    L += ["", "Sources read this session:"] + ["  - %s <%s>" % (t, u) for t, u in SOURCES] + ["Not checked: " + "; ".join(rep["not_checked"])]
    return "\n".join(L)
