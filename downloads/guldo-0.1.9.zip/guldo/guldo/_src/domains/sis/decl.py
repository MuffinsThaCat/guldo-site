"""Declaration of a collision-finding domain: the Short Integer Solution problem.

A solver receives (q, A): A is a 3 x m matrix over Z_q (q = 127). It returns a nonzero x in {-1, 0, 1}^m with A x = 0 (mod q). Any such x
counts; a planted one always exists, and for larger m many do. size = m; the reference is a meet-in-the-middle search (about 3^(m/2) work). This is the
hash-collision / signature-forgery side of lattice cryptography: the answer is a short vector in a q-ary lattice, but the verifier is just
the equation and the infinity norm.
"""
import hashlib
import hmac
import random

NAME = "sis"
VERSION = "sis-v2"           # bump whenever derive() changes
SIZE_RANGE = (22, 28)
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
Q = 127
ROWS = 3
DOC = ("solve(q, A): A is a list of 3 rows of m ints mod q. Return a list x of m ints in {-1, 0, 1}, not all zero, with sum_j A[i][j] * x[j] = 0 mod q "
       "for every row i. Return None for no answer.")
REFERENCE_NOTE = ("The reference is a meet-in-the-middle search over ternary vectors (about 3^(m/2) work). Lattice reduction on the q-ary lattice "
                  "and generalized-birthday methods are known to beat it; no claim is made about which "
                  "is fastest. Scope: toy parameters (3 rows, q = 127, m <= 28), NOT evidence about attacks on real SIS-based schemes, and a "
                  "certificate here must not be read as one.")


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"sis-v2:{size}:{idx}".encode(), hashlib.sha256).digest())
    m = size
    while True:
        x = [rng.choice((-1, 0, 1)) for _ in range(m)]
        if any(x):
            break
    A = [[rng.randrange(Q) for _ in range(m)] for _ in range(ROWS)]
    j = next(i for i, v in enumerate(x) if v)
    for row in A:
        # x_j = +-1 is its own inverse: set column j to -x_j * sum_{i != j} x_i * column_i so that A x = 0 exactly
        S = sum(row[i] * x[i] for i in range(m) if i != j)
        row[j] = (-x[j] * S) % Q
    return {"args": [Q, A], "planted": x}


def verify(inst: dict, ans) -> bool:
    q, A = inst["args"]
    m = len(A[0])
    if not isinstance(ans, list) or len(ans) != m:
        return False
    for c in ans:
        if isinstance(c, bool) or not isinstance(c, int) or c not in (-1, 0, 1):
            return False
    if not any(ans):
        return False
    return all(sum(a * x for a, x in zip(row, ans)) % q == 0 for row in A)
