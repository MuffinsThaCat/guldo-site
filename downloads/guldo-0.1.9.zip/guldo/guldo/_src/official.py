"""Orchestration of an OFFICIAL multi-seed run.

  official.py plan     --family gm [--seeds 3] [--calib results/<baseline ladder>.jsonl]
        How many instances, and the worst-case / expected CPU time, before you commit hours of machine time.
  official.py commit   --seed-dir ~/judge-seeds --seeds 3
        Create the seeds (mode 0600, outside the project tree) and commitments.json. PUBLISH the commitments now.
  official.py evaluate --family gm --submission solvers/x.py --seed-dir ~/judge-seeds --sandbox docker
        Run judge.py evaluate for every seed, each checked against its published commitment.
  official.py report   --family gm --submission x            Markdown report of the leaderboard row and its seeds.
"""
import argparse
import hashlib
import json
import os
import secrets
import subprocess
import sys
import time

import families
import judge

HERE = os.path.dirname(os.path.abspath(__file__))
COMMITMENTS = "commitments.json"


def plan_cost(family, seeds=3, n=None, budget=None, dims=None, calib_costs=None):
    """Worst-case and (if a baseline calibration is given) expected CPU seconds for an official run.
    calib_costs: {dim: mean baseline cost in s} from an earlier baseline ladder (timeouts counted at the cap)."""
    cfg = families.OFFICIAL[family]
    n = n or cfg["n"]
    budget = budget or cfg["budget"]
    dims = dims or families.DEFAULT_DIMS[family]
    per_ladder = len(dims) * n
    out = {"family": family, "seeds": seeds, "n": n, "budget": budget, "dims": dims,
           "instances_per_ladder": per_ladder, "ladders": 2 * seeds,
           "worst_case_cpu_hours": per_ladder * 2 * seeds * budget / 3600.0, "expected_cpu_hours": None}
    if calib_costs and all(d in calib_costs for d in dims):
        base_h = sum(calib_costs[d] * n for d in dims) * seeds / 3600.0
        out["expected_cpu_hours"] = base_h * 2  # submission assumed no slower than the baseline: an upper-ish guess
        out["expected_baseline_cpu_hours"] = base_h
    return out


def calib_from_ladder(path):
    costs, count = {}, {}
    with open(path) as f:
        meta = json.loads(f.readline())
        for line in f:
            r = json.loads(line)
            costs[r["dim"]] = costs.get(r["dim"], 0.0) + (r["cpu_net"] if r["status"] == "solved" else meta["budget"])
            count[r["dim"]] = count.get(r["dim"], 0) + 1
    return {d: costs[d] / count[d] for d in costs}


def make_commitments(seed_dir, k):
    seed_dir = os.path.abspath(os.path.expanduser(seed_dir))
    if seed_dir.startswith(HERE + os.sep) or seed_dir == HERE:
        raise SystemExit("REFUSED: the seed directory must be outside the project tree")
    os.makedirs(seed_dir, exist_ok=True)
    cfile = os.path.join(seed_dir, COMMITMENTS)
    if os.path.exists(cfile):
        raise SystemExit(f"REFUSED: {cfile} already exists; commitments are created once and never replaced")
    commits = []
    for i in range(k):
        seed = secrets.token_hex(32).encode()
        fd = os.open(os.path.join(seed_dir, f"seed{i + 1}.seed"), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.write(fd, seed)
        os.close(fd)
        commits.append(hashlib.sha256(seed).hexdigest())
    with open(cfile, "w") as f:
        json.dump({"created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "commitments": commits}, f, indent=1)
    return commits


def verified_seeds(seed_dir):
    """[(seed file, full sha256)] for every seed whose hash appears in commitments.json; raises on any mismatch."""
    seed_dir = os.path.abspath(os.path.expanduser(seed_dir))
    with open(os.path.join(seed_dir, COMMITMENTS)) as f:
        commits = json.load(f)["commitments"]
    seeds = sorted(fn for fn in os.listdir(seed_dir) if fn.endswith(".seed"))
    out = []
    for fn in seeds:
        with open(os.path.join(seed_dir, fn), "rb") as f:
            h = hashlib.sha256(f.read().strip()).hexdigest()
        if h not in commits:
            raise SystemExit(f"REFUSED: {fn} hashes to {h}, which is not in the published commitments")
        out.append((os.path.join(seed_dir, fn), h))
    if len(out) < len(commits):
        raise SystemExit(f"REFUSED: {len(commits)} commitments published but only {len(out)} seed files present")
    return out


def render_report(board, family, submission):
    rows = [r for r in judge.leaderboard_rows(board) if r["name"] == submission and r["family"] == family]
    lines = [f"# Result: {submission} on {family}", ""]
    if not rows:
        return "\n".join(lines + ["No board entries for this submission."])
    r = rows[0]
    lines += [f"**Credit: {r['credit']:.1f} bits  ({r['status']})**", "",
              f"Credit is the MIN over seeds of the difficulty-stratified lower bound; an inconclusive seed counts as 0.", "",
              "| seed | credit (bits) | n/dim | cap | sandbox | commitment checked | bins used |", "|---|---|---|---|---|---|---|"]
    for e in sorted((e for e in board if e["submission"] == submission and e["family"] == family),
                    key=lambda e: e["seed_tag"]):
        bits = "inconclusive" if e["bits"] is None else f"{e['bits']:.1f}"
        bins = ", ".join(f"[{lo:g},{hi:g})s" for lo, hi in (e.get("measured_bins") or [])) or "-"
        lines.append(f"| {e['seed_tag']} | {bits} | {e.get('n')} | {e.get('budget')} | {e.get('sandbox')} | "
                     f"{e.get('commit_checked')} | {bins} |")
    if r["reasons"]:
        lines += ["", "Not official because:"] + [f"- {x}" for x in r["reasons"]]
    return "\n".join(lines)


def load_board():
    return json.load(open(judge.BOARD)) if os.path.exists(judge.BOARD) else []


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("plan")
    p.add_argument("--family", default="gm", choices=sorted(families.FAMILIES))
    p.add_argument("--seeds", type=int, default=judge.MIN_SEEDS)
    p.add_argument("--calib")
    p = sub.add_parser("commit")
    p.add_argument("--seed-dir", required=True)
    p.add_argument("--seeds", type=int, default=judge.MIN_SEEDS)
    p = sub.add_parser("evaluate")
    p.add_argument("--family", default="gm", choices=sorted(families.FAMILIES))
    p.add_argument("--submission", required=True)
    p.add_argument("--seed-dir", required=True)
    p.add_argument("--baseline", help="reference solver (default: the family's own, families.DEFAULT_BASELINE)")
    p.add_argument("--sandbox", choices=["docker"])
    p.add_argument("--insecure-local", action="store_true")
    p.add_argument("--n", help="instances per size (default: the family's official value). More than the official minimum is allowed and "
                   "can still be official; FEWER is a smoke test and is never official")
    p.add_argument("--budget", help="override the CPU cap (smoke tests only)")
    p.add_argument("--dims", type=int, nargs="+", help="override the ladder (smoke tests, or a non-default baseline)")
    p.add_argument("--jobs", default="1", help="concurrent instances per ladder, local mode only (see drift_check.py)")
    p.add_argument("--reuse-baseline", action="store_true",
                   help="reuse each seed's baseline ladder when it is provably the same measurement (see judge.py); a round measures it once")
    p = sub.add_parser("report")
    p.add_argument("--family", default="gm", choices=sorted(families.FAMILIES))
    p.add_argument("--submission", required=True)
    a = ap.parse_args()

    if a.cmd == "plan":
        pl = plan_cost(a.family, a.seeds, calib_costs=calib_from_ladder(a.calib) if a.calib else None)
        print(json.dumps(pl, indent=1))
        if a.calib:
            with open(a.calib) as f:
                cal_budget = json.loads(f.readline())["budget"]
            if cal_budget < pl["budget"]:
                print(f"\nCAUTION: the calibration ladder used a {cal_budget:g} s cap but this run uses {pl['budget']} s: "
                      "instances that timed out there will take longer here, so the expected figure is an underestimate.")
        print(f"\n{pl['instances_per_ladder']} instances per ladder x {pl['ladders']} ladders. Worst case "
              f"{pl['worst_case_cpu_hours']:.1f} CPU-hours" + (f"; expected about {pl['expected_cpu_hours']:.1f} h."
                                                               if pl["expected_cpu_hours"] else "; no calibration given."))
    elif a.cmd == "commit":
        commits = make_commitments(a.seed_dir, a.seeds)
        print("PUBLISH THESE COMMITMENTS NOW (before any submission is evaluated); keep the seed files secret:")
        print("\n".join(commits))
    elif a.cmd == "evaluate":
        if not a.sandbox and not a.insecure_local:
            raise SystemExit("REFUSED: pass --sandbox docker, or --insecure-local for your own solvers")
        for seed_file, h in verified_seeds(a.seed_dir):
            cmd = [sys.executable, "judge.py", "evaluate", "--seed", seed_file, "--submission", a.submission,
                   "--family", a.family, "--published-commit", h]
            if a.baseline:  # otherwise judge.py uses the family's own default baseline
                cmd += ["--baseline", a.baseline]
            cmd += ["--sandbox", a.sandbox] if a.sandbox else ["--insecure-local", "--jobs", a.jobs]
            if a.reuse_baseline:
                cmd.append("--reuse-baseline")
            for flag, val in (("--n", a.n), ("--budget", a.budget)):
                if val:
                    cmd += [flag, val]
            if a.dims:
                cmd += ["--dims", *map(str, a.dims)]
            print(f"== seed {h[:8]}", flush=True)
            r = subprocess.run(cmd, cwd=HERE)
            if r.returncode:
                raise SystemExit(f"judge.py evaluate failed for seed {h[:8]}")
        print(render_report(load_board(), a.family, os.path.splitext(os.path.basename(a.submission))[0]))
    elif a.cmd == "report":
        print(render_report(load_board(), a.family, a.submission))


if __name__ == "__main__":
    main()
