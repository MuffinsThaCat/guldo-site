#!/usr/bin/env python3
"""Score solver ladders of a QUALITY challenge: how good are the answers, at the same CPU budget? (Python standard library only; reuses score.py's hardened readers.)

    python3 qscore.py score   --pair BASELINE.jsonl SUBMISSION.jsonl [--pair ... --pair ...]   the credit of one solver over the reference, in quality points
    python3 qscore.py compare --a A1.jsonl A2.jsonl A3.jsonl --b B1.jsonl B2.jsonl B3.jsonl    is solver A really better than solver B?
    python3 qscore.py power [--noise X] [--min-gain G]                                          what this challenge can and cannot certify (re-simulated if asked)
    python3 qscore.py recheck RESULT.json [--dir D]                                             recompute a --out result from its input ladders: same numbers or fail

A ladder is a JSON-lines file, one record per instance, id exactly "SIZE:INDEX" with INDEX running 0..n-1 for every size of the challenge (extra keys are ignored).
The first line should be {"meta": true, "commit": SHA256_OF_THE_SEED, "budget": CPU_SECONDS}: without a commitment the ladder cannot be tied to a published seed,
so `score` refuses it unless --lenient (and then the result is PROVISIONAL). `check.py`'s sibling `qcheck.py run` writes ladders in this format.

    {"id": "60:0", "dim": 60, "status": "solved", "quality": 0.873}     quality in [0, 1] for an answer the declaration's verify() accepted
    {"id": "60:1", "dim": 60, "status": "timeout"}                      statuses: solved, timeout, crash, failed, wrong; anything but "solved" scores 0

The credit is the paired difference of qualities, solver minus reference, per instance: the mean over each size, then the mean over sizes (equal weight per size), with a
conservative lower bound (the 1st percentile of a bootstrap that resamples instances WITHIN each size; calibrated on real solves, see quality_core.ALPHA). A seed's credit is max(0, lower bound); over several seeds it is the MINIMUM
(an unscorable seed counts 0). Units are quality points: 0.05 = five points of the 0..1 scale. What this does NOT know: how the answers were produced. A ladder
claims qualities; `qcheck.py qrerun` re-runs a sample of them. See README.md ("What a score does not show").
"""
import argparse
import io
import json
import math
import os
import random
import re
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import quality_core as Q  # noqa: E402
import score as S  # noqa: E402  (its safe readers, argument types and size limits)

Refused = S.Refused
STATUSES = S.STATUSES
ID_RE = S.ID_RE
MAX_BOOT, MAX_TRIALS, MAX_SIM_WORK, MAX_RECORDS = S.MAX_BOOT, S.MAX_TRIALS, S.MAX_SIM_WORK, S.MAX_RECORDS
MACHINE_RATIO = 1.25      # two ladders whose machine calibrations differ by more than this are not comparable (one machine measured twice: within a few percent)
TOP_FRACTION = 0.5       # note when this share of the baseline's answers is already at the top of the scale


def manifest():
    ch = S.manifest()
    if ch.get("metric") != "quality":
        raise Refused("this bundle is a SPEED challenge: use score.py")
    return ch


def load_ladder(path, default_budget):
    """-> (meta, {size: {id: quality}}, budget, solved counts, wrong count). Anything but a verified answer is quality 0."""
    meta, by_dim, solved, wrong = None, {}, {}, 0
    with io.StringIO(S.read_text(path, S.LIMIT_LADDER)) as f:
        for n, line in enumerate(f, 1):
            if n > MAX_RECORDS:
                raise Refused(f"{path}: more than {MAX_RECORDS} lines; this is not a ladder of this challenge and scoring it would not finish")
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except (ValueError, RecursionError):
                raise Refused(f"{path}:{n}: not JSON")
            if not isinstance(r, dict):
                raise Refused(f"{path}:{n}: not a JSON object")
            if r.get("meta"):
                if meta is not None:
                    raise Refused(f"{path}:{n}: a second meta line")
                meta = r
                continue
            for k in ("id", "dim", "status"):
                if k not in r:
                    raise Refused(f"{path}:{n}: no {k!r}")
            if not isinstance(r["status"], str) or r["status"] not in STATUSES:
                raise Refused(f"{path}:{n}: status {str(r['status'])[:30]!r} is not one of {sorted(STATUSES)}")
            dim = r["dim"]
            if isinstance(dim, bool) or not isinstance(dim, int):
                raise Refused(f"{path}:{n}: dim must be an integer")
            if not (isinstance(r["id"], str) and ID_RE.match(r["id"]) and int(r["id"].split(":")[0]) == dim):
                raise Refused(f"{path}:{n}: id {r['id']!r} must be 'SIZE:INDEX' with SIZE equal to dim ({dim})")
            q = 0.0
            if r["status"] == "solved":
                q = S.finite_float(r.get("quality"))
                if q is None or not 0.0 <= q <= 1.0:
                    raise Refused(f"{path}:{n}: a solved record needs a finite quality in [0, 1]")
            rid = r["id"]
            if rid in by_dim.setdefault(dim, {}):
                raise Refused(f"{path}:{n}: instance {rid} appears twice")
            by_dim[dim][rid] = q
            solved[dim] = solved.get(dim, 0) + (r["status"] == "solved")
            wrong += r["status"] == "wrong"
    if not by_dim:
        raise Refused(f"{path}: no records")
    meta = meta or {}
    commit = meta.get("commit")
    if commit is not None and not (isinstance(commit, str) and 0 < len(commit) <= 128):
        raise Refused(f"{path}: meta.commit must be a short string (the seed's sha256)")
    budget = S.finite_float(meta.get("budget", default_budget))
    if budget is None or budget <= 0:
        raise Refused(f"{path}: budget must be a positive, finite number")
    if "bench_cpu" in meta:
        bench = S.finite_float(meta["bench_cpu"])
        if bench is None or not 0 < bench <= 1e4:
            raise Refused(f"{path}: meta.bench_cpu must be a positive, finite number of CPU seconds (the machine calibration `qcheck.py run` records)")
    return meta, by_dim, float(budget), solved, wrong


def ladder_problems(by_dim, ch):
    want, n = set(ch["ladder"]["dims"]), ch["ladder"]["n"]
    out = []
    if set(by_dim) - want:
        out.append(f"sizes {sorted(set(by_dim) - want)} are not on the challenge ladder")
    if want - set(by_dim):
        out.append(f"ladder sizes {sorted(want - set(by_dim))} are missing")
    off = {d: len(set(recs) ^ {f"{d}:{i}" for i in range(n)}) for d, recs in by_dim.items() if d in want and set(recs) ^ {f"{d}:{i}" for i in range(n)}}
    if off:
        out.append(f"each size must hold exactly the instances SIZE:0..SIZE:{n - 1}; differing ids per size: {off}")
    return out


def load_pair(base_path, sub_path, ch, strict):
    cap = ch["ladder"]["budget_seconds"]
    mb, base, bb, _, _ = load_ladder(base_path, cap)
    ms, sub, bs, solved, wrong = load_ladder(sub_path, cap)
    if bb != bs:
        raise Refused(f"the two ladders ran with different CPU budgets ({bb} vs {bs}): the qualities would not be comparable")
    notes = []
    if bb != cap:
        notes.append(f"budget {bb} s differs from the challenge's {cap} s")
    cb, cs = mb.get("commit"), ms.get("commit")
    if cb and cs and cb != cs:
        raise Refused("the ladders were run on different seeds (commitments differ)")
    commit = cb or cs
    if not commit:
        notes.append("no seed commitment in the ladders: cannot tie them to a published seed")
    xb, xs = S.finite_float(mb.get("bench_cpu")), S.finite_float(ms.get("bench_cpu"))
    if xb and xs and max(xb, xs) / min(xb, xs) > MACHINE_RATIO:
        notes.append(f"the ladders were produced on machines of different speed (calibration {xb:g} s vs {xs:g} s of CPU for the same fixed work): an anytime solver does more per CPU "
                     "second on a faster machine, so the quality gap is not comparable; re-run both on one machine")
    only_b = {i for d in base for i in base[d]} - {i for d in sub for i in sub[d]}
    only_s = {i for d in sub for i in sub[d]} - {i for d in base for i in base[d]}
    if only_b or only_s:
        raise Refused(f"the ladders do not cover the same instances ({len(only_b)} only in the first, {len(only_s)} only in the second): "
                      "a truncated run would give a credit computed on a biased subset")
    for label, by_dim in (("baseline", base), ("submission", sub)):
        for p in ladder_problems(by_dim, ch):
            notes.append(f"{label}: {p}")
    if strict and notes:
        raise Refused("; ".join(notes) + " (use --lenient to score it anyway; the result is then PROVISIONAL)")
    return base, sub, bb, commit, notes, solved, wrong


def pair_credit(base_path, sub_path, ch, strict, boot, headroom_note=True):
    base, sub, budget, commit, notes, solved, wrong = load_pair(base_path, sub_path, ch, strict)
    r = Q.seed_credit(base, sub, random.Random(1), boot)
    head = Q.headroom(base)
    top = statistics.fmean(v["at_top"] for v in head.values())
    if headroom_note and top >= TOP_FRACTION:   # not in `compare`, where the "baseline" is whichever solver is being measured against
        notes = notes + [f"{top:.0%} of the reference's answers are already at the top of the scale: little room for any solver to show a gain"]
    r.update({"baseline": os.path.basename(base_path), "submission": os.path.basename(sub_path), "commit": commit, "budget": budget,
              "solved": {str(d): solved.get(d, 0) for d in sorted(solved)}, "wrong_answers": wrong, "notes": notes,
              "baseline_mean_quality": statistics.fmean(v["mean"] for v in head.values()),
              "submission_mean_quality": statistics.fmean(statistics.fmean(sub[d].values()) for d in sub)})
    return r


def combine(pairs, ch, strict):
    seeds = ch["protocol"]["seeds_required"]
    commits = [p["commit"] for p in pairs if p["commit"]]
    dup = len(set(commits)) != len(commits)
    if dup and strict:
        raise Refused("two pairs share a seed commitment: one seed would be counted twice")
    credits = [p["credit_quality"] for p in pairs]
    notes = sorted({n for p in pairs for n in p["notes"]}) + (["two pairs share a seed commitment"] if dup else [])
    complete = len(pairs) >= seeds and not notes
    return {"credit_quality": Q.combine(credits), "per_seed": [0.0 if c is None else c for c in credits], "seeds": len(pairs), "seeds_required": seeds,
            "status": "COMPLETE" if complete else "PROVISIONAL", "why_provisional": ([] if len(pairs) >= seeds else [f"{len(pairs)} seed(s); {seeds} required"]) + notes}


def window_note(credit, ch):
    pw = ch["power"]
    lo, hi = pw["min_certifiable"], pw["max_certifiable"]
    if lo is None:
        return "this challenge's own power analysis found NO gain it can certify: treat every credit as weak"
    if credit == 0:
        return f"0 is 'nothing certified', not 'no gain': below about {lo:g} quality points this ladder usually cannot tell"
    if credit >= hi:
        return f"at or above the top of what this ladder can certify ({hi:g}): a larger true gain would read about the same"
    if credit < lo:
        return f"below the {lo:g} lower edge of the certifiable range: weak evidence"
    return None


def simulate_table(ch, noise, gap, trials, boot, effects=None):
    sim = ch.get("simulation")
    if not sim:
        raise Refused("this bundle has no simulation block: re-export it")
    return Q.power_table(sim, ch["ladder"]["n"], noise, gap, ch["protocol"]["seeds_required"], trials, boot, effects or Q.effects_for(ch["power"]["threshold"]))


def noise_note(pairs, ch, trials=20, boot=Q.MIN_BOOT):
    """The power table assumed a per-instance noise; if these ladders show clearly more, say so and re-simulate at the observed value. (boot=40 used to be here: below Q.MIN_BOOT, so the
    re-simulation raised ValueError after the score had printed and `score` exited 1 whenever the observed noise was high.)"""
    obs = [p["pair_noise"] for p in pairs if p.get("pair_noise") is not None]
    assumed = ch["power"].get("noise")
    if not obs or assumed is None or not ch.get("simulation"):
        return None
    o = statistics.median(obs)
    if o <= 1.25 * assumed + 0.005:
        return None
    lo, hi = Q.certifiable_range(simulate_table(ch, o, ch["power"]["threshold"], trials, boot), ch["power"]["target_power"])
    where = f"from about {lo:g} to about {hi:g} points" if lo is not None else "NO gain on the grid"
    return (f"observed per-instance noise {o:.3f} is above the {assumed:g} the power table assumed: that table is optimistic here. Re-simulated at {o:.3f}, "
            f"this ladder certifies {where} (all seeds, {int(100 * ch['power']['target_power'])}% power)")


def print_score(res, pairs, ch):
    for p in pairs:
        if p["credit_quality"] is None:
            print(f"  {p['submission']} vs {p['baseline']}: NOT SCORABLE (no shared instances)")
            continue
        print(f"  {p['submission']} vs {p['baseline']}: >= {p['credit_quality']:.4f} quality points (mean gain {p['estimate']:+.4f}; reference {p['baseline_mean_quality']:.3f} "
              f"-> solver {p['submission_mean_quality']:.3f}; better on {p['improved']}, worse on {p['worse']} of {p['instances']})"
              + (f"; {p['wrong_answers']} WRONG answers" if p["wrong_answers"] else ""))
    print(f"credit = min over {res['seeds']} seed(s): {res['credit_quality']:.4f} quality points   [{res['status']}]")
    for w in res["why_provisional"]:
        print("  provisional because: " + w)
    for note in (window_note(res["credit_quality"], ch), noise_note(pairs, ch)):
        if note:
            print("  " + note)


def run_score(pairs_paths, ch, strict, boot):
    pairs = [pair_credit(b, s, ch, strict, boot) for b, s in pairs_paths]
    return combine(pairs, ch, strict), pairs


def run_compare(la, lb, ch, strict, boot, min_gap):
    if len(la) != len(lb):
        raise Refused("--a and --b need one ladder per seed, in the same seed order")
    a_over_b = [pair_credit(b, x, ch, strict, boot, headroom_note=False) for x, b in zip(la, lb)]
    b_over_a = [pair_credit(x, b, ch, strict, boot, headroom_note=False) for x, b in zip(la, lb)]
    ra, rb = combine(a_over_b, ch, strict), combine(b_over_a, ch, strict)
    ga, gb = ra["credit_quality"], rb["credit_quality"]
    if ga >= min_gap and ga > gb:
        verdict = f"A is better: >= {ga:.4f} quality points over B (lower bound, min over seeds)"
    elif gb >= min_gap and gb > ga:
        verdict = f"B is better: >= {gb:.4f} quality points over A (lower bound, min over seeds)"
    else:
        verdict = f"CANNOT SEPARATE: neither lower bound reaches {min_gap:g} points (A over B {ga:.4f}, B over A {gb:.4f}); the gap, if any, is inside the noise"
    if ra["status"] != "COMPLETE" or rb["status"] != "COMPLETE":
        verdict += "  [PROVISIONAL]"
    return {"verdict": verdict, "min_gap": min_gap, "a_over_b": ra, "b_over_a": rb}, a_over_b, b_over_a


def tool_binding():
    return {"challenge_json_sha256": S.sha256_file(os.path.join(ROOT, "challenge.json")), "quality_core_sha256": S.sha256_file(os.path.join(HERE, "quality_core.py")),
            "score_py_sha256": S.sha256_file(os.path.abspath(__file__))}


def cmd_score(a):
    ch, strict = manifest(), not a.lenient
    res, pairs = run_score(a.pair, ch, strict, a.boot)
    print_score(res, pairs, ch)
    paths = [p for pair in a.pair for p in pair]
    S.write_out(a.out, {"challenge": ch["name"], "version": ch["version"], "command": {"name": "score", "pairs": a.pair, "boot": a.boot, "lenient": a.lenient},
                        "result": res, "pairs": pairs, "binding": {**tool_binding(), "inputs": S.input_binding(paths)}})
    return 0


def cmd_compare(a):
    ch, strict = manifest(), not a.lenient
    min_gap = ch["power"]["threshold"] if a.min_gap is None else a.min_gap
    res, ab, ba = run_compare(a.a, a.b, ch, strict, a.boot, min_gap)
    print(res["verdict"])
    for w in res["a_over_b"]["why_provisional"]:
        print("  provisional because: " + w)
    obs = [p["pair_noise"] for p in ab + ba if p.get("pair_noise") is not None]
    noise = statistics.median(obs) if obs else ch["power"]["noise"]
    tab = simulate_table(ch, noise, min_gap, 20, Q.MIN_BOOT)
    lo, hi = Q.certifiable_range(tab, ch["power"]["target_power"])
    where = f"a true gap of about {lo:g} to {hi:g} points" if lo is not None else "no gap on the grid"
    print(f"  power of this comparison (simulated, {'observed' if obs else 'assumed'} noise {noise:.3f}, declared at >= {min_gap:g}): {where} is declared with >= "
          f"{int(100 * ch['power']['target_power'])}% probability; a true gap of 0 is declared {100 * tab[0]['all_seeds']:.0f}% of the time")
    nn = noise_note(ab + ba, ch)
    if nn:
        print("  " + nn)
    S.write_out(a.out, {"challenge": ch["name"], "version": ch["version"], "command": {"name": "compare", "a": a.a, "b": a.b, "boot": a.boot, "lenient": a.lenient, "min_gap": min_gap},
                        "result": res, "a_over_b_pairs": ab, "b_over_a_pairs": ba, "binding": {**tool_binding(), "inputs": S.input_binding(list(a.a) + list(a.b))}})
    return 0


def cmd_power(a):
    ch = manifest()
    pw = ch["power"]
    print(f"{ch['name']}: {ch['ladder']['n']} instances per size, sizes {ch['ladder']['dims']}, budget {ch['ladder']['budget_seconds']} s, assumed pair noise {pw['noise']:g} quality points")
    lo, hi = pw["min_certifiable"], pw["max_certifiable"]
    print(f"certifiable (all {ch['protocol']['seeds_required']} seeds credited >= {pw['threshold']:g} with >= {int(100 * pw['target_power'])}% power): "
          + (f"{lo:g} to {hi:g} quality points" if lo is not None else "NOTHING on the grid"))
    print("true gain | P(one seed credited) | P(all seeds credited)")
    for e, v in pw["curve"].items():
        print(f"{float(e):>9g} | {100 * v['single']:>19.0f}% | {100 * v['all_seeds']:>20.0f}%")
    if a.noise is not None or a.min_gain is not None:
        if a.trials * a.boot > MAX_SIM_WORK:
            raise Refused(f"--trials {a.trials} x --boot {a.boot} = {a.trials * a.boot} exceeds the limit {MAX_SIM_WORK}: the simulation would run for hours")
        noise = pw["noise"] if a.noise is None else a.noise
        gap = pw["threshold"] if a.min_gain is None else a.min_gain
        tab = simulate_table(ch, noise, gap, a.trials, a.boot, Q.effects_for(gap))
        lo, hi = Q.certifiable_range(tab, pw["target_power"])
        print(f"\nsimulated here: noise {noise:g}, a seed counts as credited at >= {gap:g}, {a.trials} trials per point "
              f"(Monte-Carlo error about +-{100 * 0.5 / math.sqrt(a.trials):.0f} points); certifiable " + (f"{lo:g} to {hi:g}" if lo is not None else "NOTHING"))
        print("true gain | P(one seed credited) | P(all seeds credited)")
        for e, v in tab.items():
            print(f"{e:>9g} | {100 * v['single']:>19.0f}% | {100 * v['all_seeds']:>20.0f}%")
    return 0


def validate_result(rec, name):
    """A result file is untrusted input: check its whole shape before anything is read from or computed with it. -> (command, binding)"""
    bad = Refused(f"{name} is not a result written by this tool")
    try:
        cmd, bind = rec["command"], rec["binding"]
        strs = lambda v: isinstance(v, list) and v and all(isinstance(p, str) for p in v)   # noqa: E731
        if not (isinstance(cmd, dict) and isinstance(bind, dict) and cmd["name"] in ("score", "compare") and isinstance(cmd["lenient"], bool)):
            raise bad
        boot = cmd["boot"]
        if isinstance(boot, bool) or not isinstance(boot, int) or not Q.MIN_BOOT <= boot <= MAX_BOOT:
            raise Refused(f"{name}: the bootstrap count must be an integer from {Q.MIN_BOOT} to {MAX_BOOT}")
        if cmd["name"] == "score":
            ok = isinstance(cmd["pairs"], list) and cmd["pairs"] and all(isinstance(p, list) and len(p) == 2 and all(isinstance(x, str) for x in p) for p in cmd["pairs"])
            paths = [x for p in cmd["pairs"] for x in p] if ok else []
        else:
            ok = strs(cmd["a"]) and strs(cmd["b"]) and S.finite_float(cmd["min_gap"]) is not None
            paths = list(cmd["a"]) + list(cmd["b"]) if ok else []
        if not ok or not all(isinstance(bind.get(k), str) for k in ("challenge_json_sha256", "quality_core_sha256", "score_py_sha256")):
            raise bad
        if not (isinstance(bind["inputs"], dict) and all(isinstance(k, str) and isinstance(v, str) for k, v in bind["inputs"].items())):
            raise bad
        if not set(paths) <= set(bind["inputs"]):
            raise Refused(f"{name} does not bind all of its input ladders by hash, so it cannot be re-checked")
    except (KeyError, TypeError, AttributeError):
        raise bad
    return cmd, bind


def cmd_recheck(a):
    """Recompute a result file from its input ladders and demand the same numbers: tamper-evidence for a published score."""
    try:
        rec = json.loads(S.read_text(a.result, S.LIMIT_JSON))
    except (ValueError, RecursionError) as e:
        raise Refused(f"{a.result} is not a result written by this tool ({type(e).__name__})")
    cmd, bind = validate_result(rec, a.result)
    ch, problems = manifest(), []
    for k, v in tool_binding().items():
        if bind.get(k) != v:
            problems.append(f"{k} differs: these numbers came from a different challenge or scorer than this one")
    paths = list(bind["inputs"])
    have = S.input_binding(paths, a.dir or "")
    problems += [f"input changed: {p}" for p in paths if have[p] != bind["inputs"][p]]
    if not problems:
        base = a.dir or ""
        fix = lambda p: os.path.join(base, p) if base and not os.path.isabs(p) else p   # noqa: E731
        strict = not cmd["lenient"]
        if cmd["name"] == "score":
            res, pairs = run_score([[fix(b), fix(s)] for b, s in cmd["pairs"]], ch, strict, cmd["boot"])
            fresh = {"result": res, "pairs": pairs}
        else:
            res, ab, ba = run_compare([fix(p) for p in cmd["a"]], [fix(p) for p in cmd["b"]], ch, strict, cmd["boot"], cmd["min_gap"])
            fresh = {"result": res, "a_over_b_pairs": ab, "b_over_a_pairs": ba}
        got = json.loads(json.dumps(fresh))
        for k, v in got.items():
            if not S.same(v, rec.get(k)):
                problems.append(f"{k}: recomputed numbers differ from the recorded ones")
    print("RECHECK OK: recomputed from the input ladders, identical" if not problems else "RECHECK FAILED:\n  " + "\n  ".join(problems))
    return 1 if problems else 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("score")
    p.add_argument("--pair", nargs=2, action="append", required=True, metavar=("BASELINE", "SUBMISSION"))
    p = sub.add_parser("compare")
    p.add_argument("--a", nargs="+", required=True, metavar="LADDER")
    p.add_argument("--b", nargs="+", required=True, metavar="LADDER")
    p.add_argument("--min-gap", type=S.float_arg(0, 1), default=None, help="quality points a lower bound must reach to call one solver better (default: the challenge's threshold; a convention, not a pre-registered test)")
    p = sub.add_parser("power", help="the compiled power table; with --noise / --min-gain it is re-simulated here")
    p.add_argument("--noise", type=S.float_arg(0, 1), help="per-instance noise (quality points) to simulate at, e.g. the value `score` observed")
    p.add_argument("--min-gain", type=S.float_arg(0, 1), help="credit threshold (quality points) to simulate at (default: the challenge's)")
    p.add_argument("--trials", type=S.int_arg(1, MAX_TRIALS), default=30, help=f"Monte-Carlo trials per point (1..{MAX_TRIALS}; trials x boot may not exceed {MAX_SIM_WORK})")
    p.add_argument("--boot", type=S.int_arg(Q.MIN_BOOT, MAX_BOOT), default=Q.MIN_BOOT)
    p = sub.add_parser("recheck", help="recompute a --out result file from its input ladders; fails if anything differs")
    p.add_argument("result")
    p.add_argument("--dir", help="directory the recorded ladder paths are relative to (default: the current one)")
    for name in ("score", "compare"):
        q = sub.choices[name]
        q.add_argument("--boot", type=S.int_arg(Q.MIN_BOOT, MAX_BOOT), default=400, help=f"bootstrap resamples ({Q.MIN_BOOT}..{MAX_BOOT}; default 400; fewer make the bound anti-conservative)")
        q.add_argument("--lenient", action="store_true", help="score ladders that do not match the challenge's ladder or lack a commitment; the result is PROVISIONAL")
        q.add_argument("--out", help="also write the full result as JSON (never overwrites)")
    a = ap.parse_args(argv)
    try:
        return {"score": cmd_score, "compare": cmd_compare, "power": cmd_power, "recheck": cmd_recheck}[a.cmd](a)
    except Refused as e:
        print("REFUSED: " + str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
