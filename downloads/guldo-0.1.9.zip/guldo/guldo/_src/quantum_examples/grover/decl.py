"""Worked QUANTUM resource example: Grover search on 3 data qubits (N = 8) with one marked item behind a phase oracle (see qcircuit_core.py). solve(n) returns a circuit as a flat list of
[op, a, b, c] gates. It is accepted if it finds the marked item with probability >= 2/3 for EVERY possible marked value; the score is its gate count (the oracle counts as one gate)."""
import hashlib
import hmac

NAME = "grover"
VERSION = "grover-v1"
KIND = "quantum"
SIZE_RANGE = (3, 4)   # one size: the reference circuit is for 3 data qubits (SIZE_STEP 2 keeps the ladder at size 3)
SIZE_STEP = 2
REFERENCE_SOLVER = "reference.py"
QUBITS = 3
SUCCESS = 2 / 3
ORACLE_GATE_COST = 1
DOC = "solve(n): return a circuit (flat list of 4-int gates) on n qubits that, with the phase oracle gate (op 8), finds the marked item with probability >= 2/3."
REFERENCE_NOTE = "Textbook Grover: Hadamards, two rounds of oracle + diffusion, with the doubly-controlled Z decomposed into H/T/CNOT (15 gates)."


def derive(master, size, idx):
    d = hmac.new(master, f"grover-v1:{size}:{idx}".encode(), hashlib.sha256).digest()
    return {"args": [QUBITS], "planted": d[0] % (1 << QUBITS)}


def verify(inst, ans):
    try:
        return QC.evaluate_circuit(ans, QUBITS, QUBITS, range(1 << QUBITS), SUCCESS, ORACLE_GATE_COST)["ok"]   # QC is supplied by the compiler (compile_kinds.load), so no import is needed
    except QC.CircuitError:
        return False
