"""aispec with bytes counted (tflops_mem.py), LOSSY CHEAT: output the DRAFT model's tokens and never verify them with the full model. Far fewer bytes; wrong on the positions where the two models disagree, so the judge must reject it."""
import math

import tensorops as tp

V, D, H, R = 64, 128, 1024, 8
W_SCALE, POS_SCALE = 4.0, 3.0


def rms(x):
    return x / tp.sqrt(tp.mean(x * x, -1, True) + 1e-6)


def solve(seed, T):
    o = V * D
    E = tp.stream(seed, 0, o, (V, D)) * math.sqrt(3.0)
    pos = tp.stream(seed, o, T * D, (T, D)) * (POS_SCALE * math.sqrt(3.0))
    o += T * D
    A1 = tp.stream(seed, o, D * R, (D, R)) * (W_SCALE / math.sqrt(D) * 3.0 / math.sqrt(R))
    o += D * R
    B1 = tp.stream(seed, o, R * H, (R, H))
    o += R * H
    A2 = tp.stream(seed, o, H * R, (H, R)) * (W_SCALE / math.sqrt(H) * 3.0 / math.sqrt(R))
    o += H * R
    B2 = tp.stream(seed, o, R * D, (R, D))
    o += R * D + D * H + H * D
    tok = min(int((tp.stream(seed, o, 1).tolist()[0] + 1.0) * 0.5 * V), V - 1)
    ET = tp.transpose(E, (1, 0))
    out = []
    for t in range(T):
        x = tp.take(E, tok) + pos[t]
        y = x + ((tp.relu((rms(x) @ A1) @ B1)) @ A2) @ B2
        tok = tp.argmax(rms(y) @ ET)
        out.append(tok)
    return out
