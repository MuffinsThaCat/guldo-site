"""Run `solve(*args)` of one solver file under EXACT Python bytecode-instruction counting, and report the count. Needs Python 3.12+ (sys.monitoring).

This is the child process of counted.py; it is not meant to be run by hand. Protocol:
  argv[1]   the solver file (a top-level `solve`)
  stdin     {"args": [...], "limit": N}      N = the most instructions the solver may execute
  stdout    the LAST line is {"status": "ok" | "limit" | "error", "steps": int, "ans": ..., "err": "..."}

The solver runs in a restricted subset of Python (see check_source below): pure computation, no sys, files, frames, getattr/type/eval/open, dunder attributes, and
imports only from a few pure modules, enforced here before and while it runs.

What is counted: every bytecode instruction executed from the start of the solver's module body through the end of `solve`, in the solver's own code and in any
pure-Python code it calls: top-level precomputation is charged too (otherwise a solver could build a lookup table at import time for free, or spin there for ever).
Validation and compilation happen before counting starts. What is NOT counted: the counter's own callback, and anything that happens
INSIDE a C function: `pow(a, b, m)` on huge integers, `sorted`, `sum`, numpy and fpylll each cost ONE instruction however long they run. That is the
honest limit of this cost model (see COMPILER.md): it measures how much Python a solver executes, which is exactly reproducible, not how long it takes.

Determinism: the cyclic garbage collector is disabled while counting (its timing would otherwise depend on allocation history), the parent fixes
PYTHONHASHSEED, and nothing about the machine (speed, load, other processes) enters the count. For a solver that is itself deterministic, the same
program on the same input under the SAME Python version and build gives the same number every time. That is a claim to CHECK, not to assume: a solver
whose behaviour depends on memory addresses (ordering by id(), say), on the clock or on randomness will count differently between runs, and so will a
different Python version. counted.py selfcheck / `practice --count` run an instance twice and refuse to certify if the counts differ.
"""
import ast
import builtins
import gc
import json
import os
import sys
import types

TOOL_ID = 3   # sys.monitoring tool ids 0-2 and 5 are taken by the debugger, coverage, profiler and optimizer: 3 and 4 are free

# ------------------------------------------------------------------------------------------------------------- the restricted subset a counted solver is written in
# A counted solver is pure computation. It runs in the SAME process as the counter, so it must not be able to reach the counter, the runner's stack frame (which holds
# it), the answer channel (the real stdout), files or processes. That is enforced here, not by trust: (1) the source is checked against a whitelist (below), (2) it runs
# with a minimal `__builtins__` (no getattr, type, open, eval, exec, import machinery, sys), (3) `import` yields proxies that expose only named functions of a few pure
# modules (a real module would leak others: `fractions.sys`). It is a sandbox for CPython-level escapes, not for bugs in CPython or for work hidden in C calls
# (see the module docstring), and the whole of it is pinned by the counter hash: a different rule set is a different counter.
ALLOWED_MODULES = {           # name -> the names it exposes (None: every public name; math and itertools are C modules and refer to no other module)
    "math": None,
    "itertools": None,
    "heapq": ("heappush", "heappop", "heapify", "heapreplace", "heappushpop", "merge", "nlargest", "nsmallest"),
    "bisect": ("bisect", "bisect_left", "bisect_right", "insort", "insort_left", "insort_right"),
    "functools": ("reduce", "partial", "lru_cache", "cache", "cmp_to_key", "total_ordering"),
    "collections": ("deque", "defaultdict", "Counter", "OrderedDict", "namedtuple"),
    "fractions": ("Fraction",),
}
_BUILTIN_NAMES = ("abs all any bin bool bytearray bytes callable chr complex dict divmod enumerate filter float frozenset hash hex int isinstance issubclass iter len list map max min "
                  "next oct ord pow print range repr reversed round set slice sorted str sum tuple zip "
                  "Exception ArithmeticError AssertionError AttributeError ImportError IndexError KeyError LookupError MemoryError NameError NotImplementedError OverflowError "
                  "RecursionError RuntimeError StopIteration TypeError ValueError ZeroDivisionError NotImplemented").split()
_BANNED_NAMES = {"eval", "exec", "compile", "open", "getattr", "setattr", "delattr", "hasattr", "vars", "globals", "locals", "dir", "type", "object", "super", "input", "breakpoint",
                 "memoryview", "id", "help", "exit", "quit", "property", "staticmethod", "classmethod", "BaseException", "SystemExit", "KeyboardInterrupt", "GeneratorExit"}
_BANNED_ATTR_PREFIXES = ("_", "gi_", "cr_", "ag_", "f_", "tb_", "co_")    # dunders, privates, and the frame / generator / traceback / code-object attributes that lead to a stack frame
_BANNED_ATTRS = {"format", "format_map", "mro"}                          # str.format reads attributes by string: "{0.__class__}"
_DUNDER_DEFS = {"__init__", "__repr__", "__str__", "__eq__", "__ne__", "__lt__", "__le__", "__gt__", "__ge__", "__hash__", "__len__", "__iter__", "__next__", "__getitem__",
                "__setitem__", "__contains__", "__add__", "__sub__", "__mul__", "__neg__", "__bool__", "__call__"}   # a solver may DEFINE these; it may not name them elsewhere


def _bad_attr(name):
    return name.startswith(_BANNED_ATTR_PREFIXES) or name in _BANNED_ATTRS


def check_source(text):
    """-> [problems] (empty: the source is inside the restricted subset). Static, on the syntax tree: no dunder or private names or attributes, no frame/generator/traceback
    attributes, no str.format, no eval/exec/getattr/type/open/..., no async code, and imports only from ALLOWED_MODULES (and only their listed names)."""
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError, RecursionError, MemoryError) as e:
        return [f"cannot be parsed ({type(e).__name__})"]
    problems = []

    def add(node, msg):
        problems.append(f"line {getattr(node, 'lineno', '?')}: {msg}")
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            if node.id.startswith("__"):
                add(node, f"the name {node.id} is not allowed")
            elif node.id in _BANNED_NAMES:
                add(node, f"the name {node.id} is not allowed")
        elif isinstance(node, ast.Attribute):
            if _bad_attr(node.attr):
                add(node, f"the attribute .{node.attr} is not allowed")
        elif isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            if node.name.startswith("__") and (isinstance(node, ast.ClassDef) or node.name not in _DUNDER_DEFS):
                add(node, f"defining {node.name} is not allowed")
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.ImportFrom) and (node.level or not node.module):
                add(node, "relative imports are not allowed")
                continue
            mods = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module]
            for m in mods:
                if m not in ALLOWED_MODULES:
                    add(node, f"import of {m} is not allowed (allowed: {', '.join(sorted(ALLOWED_MODULES))})")
            for a in node.names:
                if a.asname and a.asname.startswith("__"):
                    add(node, f"importing as {a.asname} is not allowed")
                if isinstance(node, ast.ImportFrom) and node.module in ALLOWED_MODULES and a.name != "*":
                    names = ALLOWED_MODULES[node.module]
                    if (names is not None and a.name not in names) or a.name.startswith("_"):
                        add(node, f"{a.name} is not available from {node.module}")
        elif isinstance(node, ast.ExceptHandler):
            if node.name and node.name.startswith("__"):
                add(node, f"the name {node.name} is not allowed")
        elif isinstance(node, (ast.Await, ast.AsyncFunctionDef, ast.AsyncFor, ast.AsyncWith)):
            add(node, "async code is not allowed")
        elif hasattr(ast, "MatchClass") and isinstance(node, ast.MatchClass):   # `case C(__class__=x)` reads an attribute by name
            for attr in node.kwd_attrs:
                if _bad_attr(attr):
                    add(node, f"the attribute .{attr} is not allowed")
    return problems[:20]


def _proxies():
    out = {}
    for name, exports in ALLOWED_MODULES.items():
        mod = __import__(name)
        names = [n for n in dir(mod) if not n.startswith("_")] if exports is None else [n for n in exports if hasattr(mod, n)]
        ns = types.SimpleNamespace(**{n: getattr(mod, n) for n in names})
        ns.__all__ = list(names)
        out[name] = ns
    return out


def _restricted_builtins(proxies):
    safe = {n: getattr(builtins, n) for n in _BUILTIN_NAMES if hasattr(builtins, n)}

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        if level != 0 or name not in proxies:
            raise ImportError(f"import of {name} is not allowed in a counted solver")
        return proxies[name]
    safe["__import__"] = guarded_import
    safe["__build_class__"] = builtins.__build_class__
    return safe


def _prepare(path):
    """(code, namespace) for a solver file that passed check_source: compiled, with the restricted builtins, NOT yet executed (the caller executes it under the counter).
    Raises on anything else."""
    with open(path, "rb") as f:
        text = f.read().decode("utf-8")
    problems = check_source(text)
    if problems:
        raise ValueError("not allowed in a counted solver: " + "; ".join(problems[:5]))
    return compile(text, path, "exec"), {"__builtins__": _restricted_builtins(_proxies()), "__name__": "svp_counted_solver"}


class _StepLimit(BaseException):
    """Raised from the counting callback when the budget is spent. A BaseException, so a solver's `except Exception` cannot swallow it."""


def _emit(obj):
    sys.__stdout__.write("\n" + json.dumps(obj) + "\n")
    sys.__stdout__.flush()


def main():
    if len(sys.argv) != 2:
        _emit({"status": "error", "steps": 0, "err": "usage: count_runner.py SOLVER"})
        return
    try:
        payload = json.loads(sys.stdin.read())
        args, limit = payload["args"], int(payload["limit"])
    except (ValueError, KeyError, TypeError) as e:
        _emit({"status": "error", "steps": 0, "err": f"bad payload: {type(e).__name__}"})
        return
    if sys.version_info < (3, 12):
        _emit({"status": "error", "steps": 0, "err": "step counting needs Python 3.12 or newer (sys.monitoring)"})
        return
    # running `python count_runner.py` puts THIS directory (the judge's) on sys.path: a solver could then `import instances` or `import families` and read the
    # planted answers. Take it off before the solver loads. (This is not a sandbox: an unsandboxed solver can still open files. See counted.py.)
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path[:] = [p for p in sys.path if p and os.path.abspath(p) != here]
    # a solver that could reach sys.monitoring could switch its own counting off (set_events(3, 0)) and a re-run would reproduce the same meaningless count.
    # Keep our reference and take the public ones away BEFORE the solver loads. This is a second line of defence: the restricted subset already gives the solver no way to
    # name sys, a frame, gc or ctypes. The end of the run also checks that counting was never reconfigured.
    mon = sys.monitoring
    try:
        delattr(sys, "monitoring")
    except (AttributeError, TypeError):
        pass
    sys.modules.pop("sys.monitoring", None)
    if sys.platform.startswith("linux"):   # a solver that allocates without end must fail the same way instead of taking the host down. Linux only: on macOS a process's address space
        try:                               # (shared cache included) can already exceed the limit, so setting it there would make EVERY allocation fail, not just the solver's
            import resource
            resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
        except (ImportError, ValueError, OSError):
            pass
    try:   # validated and compiled here, uncounted; the module body and solve() are executed and counted below
        code, namespace = _prepare(sys.argv[1])
    except BaseException as e:
        _emit({"status": "error", "steps": 0, "err": f"could not load the solver: {type(e).__name__}: {str(e)[:200]}"})
        return
    count = [0]
    tripped = [False]

    def on_instruction(code, offset):
        if tripped[0]:
            return                      # the budget is already spent: let the cleanup code below run, uncounted
        n = count[0] + 1
        count[0] = n
        if n > limit:
            tripped[0] = True           # raise ONCE. Raising on every later instruction would break the except/finally handlers too
            raise _StepLimit()

    status, ans, err = "ok", None, ""
    real_stdout = sys.stdout
    sys.stdout = sys.stderr          # a solver's print() must not corrupt the answer channel
    gc.collect()
    gc.disable()
    mon.use_tool_id(TOOL_ID, "svp-count")
    mon.register_callback(TOOL_ID, mon.events.INSTRUCTION, on_instruction)
    try:
        mon.set_events(TOOL_ID, mon.events.INSTRUCTION)
        exec(code, namespace)
        ans = namespace["solve"](*args)
    except _StepLimit:
        status = "limit"
    except BaseException as e:
        status, err = "error", f"{type(e).__name__}: {str(e)[:200]}"
    finally:
        try:
            intact = mon.get_events(TOOL_ID) == mon.events.INSTRUCTION
        except ValueError:              # the solver freed the tool id
            intact = False
        try:
            mon.set_events(TOOL_ID, mon.events.NO_EVENTS)
            mon.register_callback(TOOL_ID, mon.events.INSTRUCTION, None)
            mon.free_tool_id(TOOL_ID)
        except ValueError:
            intact = False
        gc.enable()
        sys.stdout = real_stdout
    steps = count[0]
    if not intact and not tripped[0]:
        status, ans, err = "error", None, "the solver reconfigured the instruction counter: its count means nothing"
    if tripped[0]:                      # a solver with a bare `except:` could swallow the limit and finish: it still spent more than its budget
        status, ans, err = "limit", None, ""
    if status == "ok":
        try:
            json.dumps(ans)
        except (TypeError, ValueError):
            status, err, ans = "error", "the answer is not JSON-serialisable (an int, a list of ints or None is expected)", None
    _emit({"status": status, "steps": steps, "ans": ans if status == "ok" else None, "err": err})


if __name__ == "__main__":
    main()
