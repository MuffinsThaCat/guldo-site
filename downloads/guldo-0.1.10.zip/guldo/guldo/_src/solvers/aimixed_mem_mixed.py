"""aimixed with bytes counted, TECHNIQUE: MIXED PRECISION. The features are held in fp16 and every step multiplies fp16 copies (X times the fp16 weights, then X^T times the fp16 residual), which
is where the bytes are. Everything that must not lose small values stays in fp32: the weights are MASTER weights in fp32 and are updated in fp32 (so a small step is not rounded away), the sigmoid and
the residual are computed in fp32, and the residual is multiplied by a LOSS SCALE of 64 before it is cast to fp16 for the gradient product (and the product divided by the scale afterwards), so that
small residuals do not underflow in fp16 and the sum of up to N scaled terms still fits below fp16's maximum of 65504."""
import math

import tensorops as tp

RHO = 0.9
LAM = 1e-3
STEPS = 10000


def features(seed, d, n):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    return (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)
SCALE = 64.0


def solve(seed, d, n, labels):
    X = features(seed, d, n)
    lr = 1.0 / (tp.sum(X * X).item() / (4.0 * n) + LAM)
    X16 = tp.cast(X, "fp16")
    X = 0
    y = tp.cast(tp.tensor([float(v) for v in labels]), "fp32")
    Xt = tp.transpose(X16, (1, 0))
    w = tp.cast(tp.zeros((d,)), "fp32")
    for step in range(STEPS):
        z = tp.cast(X16 @ tp.cast(w, "fp16"), "fp32")
        r = 1.0 / (1.0 + tp.exp(-z)) - y
        g = tp.cast(Xt @ tp.cast(r * SCALE, "fp16"), "fp32") * (1.0 / (SCALE * n)) + w * LAM
        w = w - g * lr
    return [int(v * 1048576.0) for v in w.tolist()]
