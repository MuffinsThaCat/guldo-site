"""The site card for the agent-evaluation work: ONE self-contained static HTML page, generated from the live domain registry so it cannot drift from the code.

  python3 agent_site.py --out agent.html [--status STATUS.json]

No JavaScript, no external resource of any kind (a strict Content-Security-Policy forbids them, and a test checks the page for any URL it loads), no timestamp (the same code gives the same bytes), and every
string from the registry is HTML-escaped. build_site.py now ALSO builds this card as its own `agent.html` page (nav entry "Agents", the site's layout, `site_body()` below, the same data); this standalone page is for use outside the site.

The page says what exists and what has NEVER been done, in the same words as AGENT_EVAL.md. `--status` takes a JSON object {"real_model_runs": 0, "outside_witnesses": 0, "official_rounds": 0, ...}
to state real counts; the defaults are the true ones today (all zero), and a card that claims more than the project has done is the thing this tool is built to prevent: it refuses any count it was not given
a basis for, so only these keys are accepted, and each must be a non-negative integer.
"""
import argparse
import html
import json
import os
import sys

import agent_core
import agent_domains_plus                                                            # noqa: F401  the card lists every registered domain, including the extra ones

COUNTS =("real_model_runs", "outside_witnesses", "official_rounds", "certificates_in_log")
LIMITS = ["A verified result shows that its records are consistent and correct, NOT that a particular model produced them (receipts from a proxy the verifier controls, or independent witnesses, narrow this to trust in a key).",
          "Tokens are proxy tokens (ceil of UTF-8 bytes / 4 of the exact context sent each turn plus the output) unless a ladder was attested with the provider's own usage figures.",
          "The task generators are public: committing to a secret seed hides the judged instances, and a SEALED domain also hides its names, wording and ranges, but neither hides the skill being tested.",
          "Domains that run agent-written code (coding, bugfix) execute it on the verifier's machine with resource limits, which is not a sandbox: use a throwaway VM or container."]


def _scope_sentence(st):
    """What the page may say about measurements. It claims nothing the supplied counts do not support."""
    if st["real_model_runs"] == 0:
        return "No result on this page is a measurement of any model: everything so far ran with scripted stand-in agents on a public practice seed."
    s = ("Each recorded real-model run is a statement about that configuration, on those generators, sizes and caps, on its date, and about nothing else. Runs on a public practice seed "
         "certify nothing.")
    return s + (" " + st[NOTE_KEY] if st.get(NOTE_KEY) else "")
COMMANDS = ["python3 agent_eval.py domains", "python3 agent_eval.py plan --domain research:sealed --n 20 --trials 3 --seed SEEDFILE --out PLAN.json --assume-p-cand 0.9 --solve-claim 0.8",
            "python3 agent_eval.py verify LADDER.jsonl --seed SEEDFILE --plan PLAN.json --plan-hash HASH", "python3 agent_eval.py check CLAIM.json BASELINE.jsonl CANDIDATE.jsonl",
            "python3 agent_tools.py witness-rerun LADDER.jsonl --sample 6 --key WITNESS.key --seed SEEDFILE", "python3 agent_log.py verify-proof PROOF.json --trusted KEYS.txt"]


def _e(x):
    return html.escape(str(x), quote=True)


def domain_rows():
    rows = []
    for name in agent_core.DOMAIN_NAMES:
        mod = agent_core.load_domain(name)
        sizes = agent_core.domain_sizes(mod)
        sealed = name.endswith(agent_core.SEALED_SUFFIX)
        rows.append({"name": name, "sizes": "%d to %d" % (sizes[0], sizes[-1]), "doc": mod.DOC, "safety": bool(getattr(mod, "SAFETY", False)), "runs_code": bool(getattr(mod, "RUNS_CODE", False)),
                     "bits": agent_core.sealed_entropy_bits(name[:-len(agent_core.SEALED_SUFFIX)]) if sealed else None})
    return rows


NOTE_KEY = "real_runs_note"
STATUS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "agent_status.json")


def _status(status):
    st = {k: 0 for k in COUNTS}
    for k, v in (status or {}).items():
        if k == NOTE_KEY:
            if not isinstance(v, str) or len(v) > 600 or any(ord(c) < 32 for c in v):
                raise agent_core.AgentEvalError("%s must be plain text of at most 600 characters" % NOTE_KEY)
            st[k] = v
        elif k not in COUNTS or not isinstance(v, int) or isinstance(v, bool) or v < 0:
            raise agent_core.AgentEvalError("status key %r is not accepted (allowed: %s, each a non-negative integer, and %s as text)" % (k, ", ".join(COUNTS), NOTE_KEY))
        else:
            st[k] = v
    return st


def load_status(path=None):
    """The committed status (agent_status.json): the REAL counts, edited by hand when, and only when, the thing has happened (tests tie it to the evidence directory). None if the file is absent, in
    which case the card shows zeros. The library functions default to zeros; the site build and this tool's command line read the file."""
    path = path or STATUS_FILE
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        status = json.load(f)
    _status(status)                                                                       # validated here too: a bad file fails the build, not the page
    return status


def site_body(status=None, cmd=None, live=False):
    """The same card as an HTML FRAGMENT in the markup and classes of the main site (build_site.py wraps it in its own layout, with its own header, footer and styles). `cmd(text)` renders one
    copy-able command the way the site does; without it commands are plain <code>. Same data, same escaping, same honesty rules as render()."""
    st = _status(status)
    rows = domain_rows()
    cmd = cmd or (lambda t: "<p><code>%s</code></p>" % _e(t))
    o = ['<section class="block"><p class="kicker">Agents</p><h1>Verifiable agent evaluation</h1>',
         '<p class="lede">The speedup-verification protocol (instances that are a pure function of a committed secret seed, exact verifiers, recomputable certificates) applied to AI agents: '
         'pre-registered plans, hash-chained trajectories, exact statistics, signed receipts and witnesses, and the code for a public log of certificates (none is running yet). Everything here is checkable by anyone with Python 3.9+ and a copy of the repository; '
         'only running a real model needs more (an API key and your own money).</p>',
         '<div class="card"><h3>Status, stated plainly</h3><p class="fine">Real model runs: %d. Independent witnesses outside the project: %d. Official rounds (run on the separate verified evaluation machine): %d. Certificates in the public log: %d. %s</p></div></section>'
         % (st["real_model_runs"], st["outside_witnesses"], st["official_rounds"], st["certificates_in_log"], _e(_scope_sentence(st))),
         '__LIVE_SECTION__',
         '<section class="block"><h2>Task domains</h2><div class="scroll"><table class="lb"><thead><tr><th>Domain</th><th>Sizes</th><th>What the agent does</th><th>Notes</th></tr></thead><tbody>']
    import agent_site_live
    _live = agent_site_live.live_runs() if live else None             # only when the build publishes the evidence files too (build_site decides): the page must never link to files it does not ship
    o = [x for item in o for x in ((agent_site_live.live_section(_live, cmd) if _live else []) if item == '__LIVE_SECTION__' else [item])]
    for r in rows:
        notes = []
        if r["safety"]:
            notes.append("safety domain: unsafe outcomes counted apart from failure")
        if r["runs_code"]:
            notes.append("runs agent-written code")
        if r["bits"] is not None:
            notes.append("sealed: about %.0f bits of surface variation per round" % r["bits"])
        o.append('<tr><td><span class="mono">%s</span></td><td>%s</td><td>%s</td><td class="fine">%s</td></tr>' % (_e(r["name"]), _e(r["sizes"]), _e(r["doc"]), _e("; ".join(notes))))
    o += ['</tbody></table></div></section>', '<section class="block"><h2>What a certificate does not show</h2><ul>'] + ["<li>%s</li>" % _e(x) for x in LIMITS] + ['</ul></section>',
          '<section class="block"><h2>Check a result yourself</h2>'] + [cmd(c) for c in COMMANDS] + [
          '<p class="fine">The procedure for a first outside verifier is in OUTSIDE_VERIFIER.md; the operator guide, with the audits and what remains undone, is AGENT_EVAL.md, both in the downloadable tool.</p></section>']
    return "\n".join(o)


def render(status=None):
    st = _status(status)
    rows = domain_rows()
    o = ['<!doctype html>', '<html lang="en"><head><meta charset="utf-8">',
         '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">',
         '<meta name="viewport" content="width=device-width, initial-scale=1"><title>Verifiable agent evaluation</title>',
         '<style>:root{--bg:#fff;--fg:#1a1a1a;--mut:#555;--line:#ddd;--warn:#8a4b00;--code:#f4f4f4}@media (prefers-color-scheme:dark){:root{--bg:#111;--fg:#eee;--mut:#aaa;--line:#333;--warn:#f0b060;--code:#1d1d1d}}'
         'body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.5 system-ui,sans-serif}main{max-width:62rem;margin:0 auto;padding:1rem 16px 3rem}h1{font-size:1.6rem}h2{font-size:1.15rem;margin-top:2rem}'
         'table{border-collapse:collapse;width:100%}th,td{border-bottom:1px solid var(--line);padding:.4rem .5rem;text-align:left;vertical-align:top}th{font-size:.85rem;color:var(--mut)}'
         '.wrap{overflow-x:auto}code,pre{background:var(--code);font:.85rem ui-monospace,monospace}pre{padding:.6rem;overflow-x:auto}.warn{border-left:4px solid var(--warn);padding:.2rem .8rem;margin:1rem 0}'
         '.mut{color:var(--mut)}</style></head><body><main>',
         '<h1>Verifiable agent evaluation</h1>',
         '<p>The speed-verification protocol (instances that are a pure function of a committed secret seed, exact verifiers, recomputable certificates) applied to AI agents: pre-registered plans, hash-chained '
         'trajectories, exact statistics, signed receipts and witnesses, and the code for a public log of certificates (none is running yet). Everything here is checkable by anyone with Python 3.9+ and a copy of the repository; '
         'only running a real model needs more (an API key and your own money).</p>',
         '<div class="warn"><strong>Status, stated plainly.</strong> Real model runs: %d. Independent witnesses outside the project: %d. Official rounds (run on the separate verified evaluation machine): %d. Certificates in the public log: %d. %s</div>'
         % (st["real_model_runs"], st["outside_witnesses"], st["official_rounds"], st["certificates_in_log"], _e(_scope_sentence(st))),
         '<h2>Task domains</h2><div class="wrap"><table><thead><tr><th>domain</th><th>sizes</th><th>what the agent does</th><th>notes</th></tr></thead><tbody>']
    for r in rows:
        notes = []
        if r["safety"]:
            notes.append("safety domain: unsafe outcomes counted apart from failure")
        if r["runs_code"]:
            notes.append("runs agent-written code")
        if r["bits"] is not None:
            notes.append("sealed: about %.0f bits of surface variation per round" % r["bits"])
        o.append("<tr><td><code>%s</code></td><td>%s</td><td>%s</td><td class=\"mut\">%s</td></tr>" % (_e(r["name"]), _e(r["sizes"]), _e(r["doc"]), _e("; ".join(notes))))
    o += ['</tbody></table></div>', '<h2>What a certificate does not show</h2><ul>'] + ["<li>%s</li>" % _e(x) for x in LIMITS] + ['</ul>',
          '<h2>Check a result yourself</h2><pre>%s</pre>' % _e("\n".join(COMMANDS)),
          '<p class="mut">The procedure for a first outside verifier is in OUTSIDE_VERIFIER.md; the operator guide, with the audits and what remains undone, is AGENT_EVAL.md.</p>', '</main></body></html>']
    return "\n".join(o) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", required=True)
    ap.add_argument("--status", help="JSON file with real counts (default: all zero)")
    a = ap.parse_args(argv)
    try:
        status = load_status()                                                            # the committed real counts, unless --status names another file
        if a.status:
            with open(a.status, "r", encoding="utf-8") as f:
                status = json.load(f)
        page = render(status)
    except (agent_core.AgentEvalError, OSError, ValueError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(page)
    print("wrote %s (%d bytes)" % (a.out, len(page.encode("utf-8"))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
