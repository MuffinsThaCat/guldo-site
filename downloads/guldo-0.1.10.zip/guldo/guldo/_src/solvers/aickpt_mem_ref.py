"""aickpt in the counted API, REFERENCE: store every activation and ReLU mask of the forward pass (about 2L tensors alive at the end of it), then backpropagate over them."""
import math

import tensorops as tp


def parts(seed, w, B):
    X = tp.reshape(tp.stream(seed, 0, B * w), (B, w))
    W = tp.reshape(tp.stream(seed, B * w, w * w), (w, w)) * math.sqrt(3.0 / w)
    T = tp.reshape(tp.stream(seed, B * w + w * w, B * w), (B, w))
    return X, W, T


def step(h, W, alpha):
    """One forward step; returns the next activation and the ReLU mask (1 where the pre-activation was positive)."""
    a = h @ W
    ra = tp.relu(a)
    return h + ra * alpha, ra / (tp.sqrt(a * a) + 1e-300)


def fwd(h, W, alpha):
    """One forward step without the mask (a pass that will not be backpropagated)."""
    return h + tp.relu(h @ W) * alpha


def ints(dW, w):
    return [int(v * 1099511627776.0) for v in tp.reshape(dW, (w * w,)).tolist()]


def solve(seed, L, w, B):
    X, W, T = parts(seed, w, B)
    alpha = 0.5 / L
    Wt = tp.transpose(W, (1, 0))
    hs = [X]
    ms = []
    h = X
    for t in range(L):
        h, m = step(h, W, alpha)
        hs.append(h)
        ms.append(m)
    delta = (h - T) * (1.0 / (B * w))
    dW = tp.zeros((w, w))
    for t in range(L - 1, -1, -1):
        gm = delta * ms[t]
        dW = dW + (tp.transpose(hs[t], (1, 0)) @ gm) * alpha
        delta = delta + (gm @ Wt) * alpha
    return ints(dW, w)
