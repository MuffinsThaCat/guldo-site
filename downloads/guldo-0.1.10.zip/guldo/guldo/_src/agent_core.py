"""Verifiable AGENT evaluation: the shared core (seeds, exact statistics, ladder format, trajectory checks).

An agent task domain is a module in agent_domains/ with NAME, VERSION, SIZE_RANGE, SIZE_STEP, derive(seed, size), tool_specs(public), make_env(instance),
reference_answer(instance) and verify(instance, answer, calls). `derive` turns one INSTANCE SEED into {"public": ..., "private": ...}; the agent sees only `public`
(through the prompt and the tools); `verify` is exact and judge-side. The instance seed is HMAC-SHA256(master seed, domain|version|size|idx), so a committed master
seed commits to every instance, as in the speed protocol.

What this module does NOT do: it never calls a model. agent_harness.py runs an agent; agent_eval.py is the command line.

COST. One trial costs `tokens` = proxy input tokens (the whole context re-sent each turn, as an API bills it) + proxy output tokens, `tool_calls` and `turns`. Proxy tokens are
ceil(utf-8 bytes / 4) of the exact text the harness sent and received: a unit anyone can recompute from the stored trajectory. They are NOT a provider's tokenizer counts; a
provider's own usage numbers are stored beside them and a large gap is reported, never silently used. That is the trust gap stated in the vision document, made visible.
"""
import hashlib
import hmac
import json
import math

FORMAT = "guldo-agent-ladder-v1"
COUNTER = "proxy-bytes4-v1"
PRACTICE_SEED = b"guldo-agent-practice-seed-PUBLIC"
ALPHA = 0.05


class AgentEvalError(Exception):
    pass


def sha256_hex(b):
    if isinstance(b, str):
        b = b.encode("utf-8")
    return hashlib.sha256(b).hexdigest()


def canon(obj):
    """Canonical JSON text: sorted keys, no spaces, ASCII only. Every hash in this protocol is over this form."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def count_tokens(text):
    """The proxy token unit: ceil(utf-8 bytes / 4). Deterministic and recomputable; not a model tokenizer."""
    n = len(text.encode("utf-8"))
    return (n + 3) // 4


def commitment(master):
    return sha256_hex(b"guldo-agent-commit|" + master)


def instance_seed(master, domain, version, size, idx):
    msg = ("agent|%s|%s|%d|%d" % (domain, version, size, idx)).encode("utf-8")
    return hmac.new(master, msg, hashlib.sha256).digest()


def instance_id(domain, size, idx):
    return "%s/%d/%d" % (domain, size, idx)


class Rng:
    """A tiny deterministic generator (SHA-256 in counter mode): the stream does not depend on the Python version, unlike `random`."""

    def __init__(self, seed):
        self.seed = seed
        self.ctr = 0
        self.buf = b""

    def _bytes(self, n):
        while len(self.buf) < n:
            self.buf += hashlib.sha256(self.seed + self.ctr.to_bytes(8, "big")).digest()
            self.ctr += 1
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def u64(self):
        return int.from_bytes(self._bytes(8), "big")

    def randint(self, a, b):
        """Uniform integer in [a, b] (rejection sampling, no modulo bias)."""
        span = b - a + 1
        if span <= 0:
            raise ValueError("empty range")
        limit = (1 << 64) - ((1 << 64) % span)
        while True:
            v = self.u64()
            if v < limit:
                return a + v % span

    def choice(self, seq):
        return seq[self.randint(0, len(seq) - 1)]

    def sample(self, seq, k):
        pool = list(seq)
        out = []
        for _ in range(k):
            out.append(pool.pop(self.randint(0, len(pool) - 1)))
        return out

    def random(self):
        return (self.u64() >> 11) / float(1 << 53)


def trial_coin(label, instance, trial):
    """A deterministic number in [0, 1) for scripted agents: a function of an agent label, the PUBLIC instance id and the trial, so a rerun repeats it."""
    h = hashlib.sha256(("coin|%s|%s|%d" % (label, instance, trial)).encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big") / float(1 << 64)


# ---- exact statistics (stdlib only) ----------------------------------------------------------------------------------------------------------------------

def binom_upper_tail(k, n, p):
    """P(X >= k) for X ~ Binomial(n, p), summed directly (no 1 - cdf cancellation)."""
    if k <= 0:
        return 1.0
    if k > n:
        return 0.0
    return min(1.0, sum(_term(n, i, p) for i in range(k, n + 1)))


def _term(n, i, p):
    """P(X = i). Exact integer arithmetic for n <= 1000; above that math.comb(n, i) no longer fits a float (OverflowError), so use log-gamma (relative error about 1e-13)."""
    if n <= 1000:
        return math.comb(n, i) * p ** i * (1.0 - p) ** (n - i)
    if p <= 0.0:
        return 1.0 if i == 0 else 0.0
    if p >= 1.0:
        return 1.0 if i == n else 0.0
    return math.exp(math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1) + i * math.log(p) + (n - i) * math.log(1.0 - p))


def binom_lower_tail(k, n, p):
    """P(X <= k)."""
    if k < 0:
        return 0.0
    if k >= n:
        return 1.0
    return min(1.0, sum(_term(n, i, p) for i in range(0, k + 1)))


def cp_lower(k, n, alpha=ALPHA):
    """One-sided Clopper-Pearson lower confidence bound on a success probability: the p at which P(X >= k) = alpha. Exact, conservative, assumes independent trials."""
    if n <= 0 or k <= 0:
        return 0.0
    lo, hi = 0.0, 1.0
    for _ in range(80):
        mid = (lo + hi) / 2.0
        if binom_upper_tail(k, n, mid) < alpha:
            lo = mid
        else:
            hi = mid
    return lo


def cp_upper(k, n, alpha=ALPHA):
    """One-sided Clopper-Pearson upper bound: the p at which P(X <= k) = alpha."""
    if n <= 0:
        return 1.0
    if k >= n:
        return 1.0
    lo, hi = 0.0, 1.0
    for _ in range(80):
        mid = (lo + hi) / 2.0
        if binom_lower_tail(k, n, mid) > alpha:
            lo = mid
        else:
            hi = mid
    return hi


def sign_test_p(wins, losses):
    """Exact one-sided p-value that `wins` out of wins+losses discordant pairs is this high or higher when each side is equally likely to win (McNemar's exact test)."""
    n = wins + losses
    if n == 0:
        return 1.0
    return sum(math.comb(n, i) for i in range(wins, n + 1)) / (2 ** n)     # int / int is exact-rounded for any size; float(2 ** n) overflows past n = 1023


def _resample_indices(n, reps, material):
    """SHA-256 counter-mode resampling indices (the stream does not depend on the Python version). Yields `reps` lists of n indices in [0, n)."""
    for r in range(reps):
        idx = []
        block = 0
        while len(idx) < n:
            d = hashlib.sha256(material + r.to_bytes(8, "big") + block.to_bytes(8, "big")).digest()
            block += 1
            for j in range(0, 32, 4):
                if len(idx) >= n:
                    break
                idx.append(int.from_bytes(d[j:j + 4], "big") % n)
        yield idx


def bootstrap_mean(values, material, reps=2000):
    """Deterministic percentile bootstrap of the mean. Returns (mean, lower_one_sided_95, [lo2.5, hi97.5]). `material` is bytes that fix the resampling stream."""
    n = len(values)
    if n == 0:
        return None, None, None
    reps = max(200, min(reps, 4000000 // n))
    means = []
    for idx in _resample_indices(n, reps, material):
        means.append(sum(values[i] for i in idx) / float(n))
    means.sort()

    def pct(q):
        return means[min(len(means) - 1, max(0, int(math.floor(q * len(means)))))]
    return sum(values) / float(n), pct(0.05), [pct(0.025), pct(0.975)]


def pessimistic_gap(bits):
    """The value of ONE pseudo-observation added against the claimed direction before the cost bound is computed: a loss as large as the WORST LOSS SEEN, and at least 1 bit (a 2x dearer instance).
    WHY: a percentile bootstrap of a mean is not valid when rare large losses exist but none is in the sample (an agent that is usually a little cheaper and occasionally runs away):
    measured, with a true mean gap of exactly zero the plain rule called "candidate uses fewer tokens" 10-35% of the time instead of 5%. Adding one pessimistic observation (the 'what if one
    more instance went badly' correction, like the rule of three for rare events) took that to 0% on the 90/10 and 80/20 cases (their losses are under the 1-bit floor), at little cost in
    power (0.93 -> 0.91 at n=20, 1 bit, sd 1; none for larger effects or n >= 40). Wins do NOT scale it (a first version scaled with the biggest gap of either sign and cut a consistent 14.5x
    gain to 6.1x; this one gives 9.4x). The reverse claim ("baseline is cheaper") gets its OWN pseudo-observation, computed from the negated gaps. A small but perfectly consistent gain
    still needs many instances to be certified: the honest price.
    ONLY PARTLY FIXED, measured THROUGH agent_compare.compare() (true mean gap exactly 0, 10% of instances a 12-fold blow-up, otherwise 1.3x cheaper): false 'fewer tokens' verdicts were about
    13% at n=20 and 15% at n=40 without the correction and are about 14% at n=20 and 6-8% at n=40 with it: at n=20 it does essentially nothing for that shape. For a blow-up that is rare
    AND huge (5% of instances 500x dearer) it does nothing at any n tried (about 38% at n=20): an unseen tail is unseen, and no rule fixes that. A harness that can run to the token cap needs
    a large n; `dearer_by_1_bit_or_more_on` and `worst_gap_bits` in the comparison show what the sample did see."""
    return -max(1.0, -min(0.0, min(bits)))


def median(xs):
    s = sorted(xs)
    n = len(s)
    if n == 0:
        return None
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2.0


# ---- ladder files: one JSON header line, then one JSON record per trial ------------------------------------------------------------------------------------

def read_ladder(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = [ln for ln in f.read().split("\n") if ln.strip()]
    except OSError as e:
        raise AgentEvalError("%s: unreadable (%s)" % (path, type(e).__name__))
    if not lines:
        raise AgentEvalError("%s: empty" % path)
    try:
        header = json.loads(lines[0])
        records = [json.loads(ln) for ln in lines[1:]]
    except ValueError:
        raise AgentEvalError("%s: not JSON lines" % path)
    if not isinstance(header, dict) or header.get("format") != FORMAT:
        raise AgentEvalError("%s: not a %s ladder" % (path, FORMAT))
    for r in records:
        if not isinstance(r, dict):
            raise AgentEvalError("%s: a record is not an object" % path)
    return header, records


def write_ladder(path, header, records):
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(canon(header) + "\n")
        for r in records:
            f.write(canon(r) + "\n")
    import os
    os.replace(tmp, path)


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _is_int(x, lo=None, hi=None):
    return isinstance(x, int) and not isinstance(x, bool) and (lo is None or x >= lo) and (hi is None or x <= hi)


def require_shape(header, records):
    """Raise AgentEvalError unless a ladder has the shape every consumer (summaries, comparisons, reports, witnesses, the index) assumes. This is NOT verification (verify_ladder re-derives and
    re-checks everything); it only turns a damaged file into a clear refusal instead of a crash deep in some arithmetic."""
    def bad(msg):
        raise AgentEvalError("malformed ladder: " + msg)
    if not isinstance(header, dict):
        bad("the header is not an object")
    for k, typ in (("domain", str), ("version", str), ("plan_hash", str), ("commit", str), ("counter", str), ("agent", dict), ("sizes", list), ("practice", bool)):
        if not isinstance(header.get(k), typ):
            bad("header field %r is missing or not a %s" % (k, typ.__name__))
    if not header["sizes"] or not all(_is_int(s, 0, 10 ** 9) for s in header["sizes"]):
        bad("header sizes must be a non-empty list of integers")
    if not _is_int(header.get("n_per_size"), 1, 10 ** 6) or not _is_int(header.get("trials"), 1, 10 ** 4):
        bad("header n_per_size and trials must be sensible positive integers")
    if not isinstance(records, list):
        bad("the records are not a list")
    for r in records:
        if not isinstance(r, dict):
            bad("a record is not an object")
        for k, typ in (("instance", str), ("reason", str), ("head", str)):
            if not isinstance(r.get(k), typ):
                bad("record field %r is missing or not a %s" % (k, typ.__name__))
        if not isinstance(r.get("solved"), bool):
            bad("record field 'solved' is missing or not a boolean")
        if r.get("provider_tokens") is not None and not _is_int(r["provider_tokens"], 0, 10 ** 12):
            bad("record field 'provider_tokens' must be a non-negative integer or null")
        for k in ("size", "idx", "trial", "tokens", "tool_calls"):
            if not _is_int(r.get(k), 0, 10 ** 12):
                bad("record field %r is missing or not a non-negative integer" % k)


# ---- trajectory integrity -------------------------------------------------------------------------------------------------------------------------------

CHAIN_START = "0" * 64


def chain_turns(turns):
    """Hash-chain a list of turn dicts (each WITHOUT 'prev'/'h'); returns the turns with those fields added and the final head."""
    prev = CHAIN_START
    out = []
    for t in turns:
        t = dict(t)
        t["prev"] = prev
        t["h"] = sha256_hex(prev + canon({k: v for k, v in t.items() if k not in ("h",)}))
        prev = t["h"]
        out.append(t)
    return out, prev


def check_chain(turns):
    """True if every turn's hash matches its content and the previous hash; returns (ok, head)."""
    prev = CHAIN_START
    for t in turns:
        if not isinstance(t, dict) or t.get("prev") != prev:
            return False, None
        body = {k: v for k, v in t.items() if k != "h"}
        if t.get("h") != sha256_hex(prev + canon(body)):
            return False, None
        prev = t["h"]
    return True, prev


def cost_from_turns(turns):
    """Recompute a trial's cost from its stored turns alone: (tokens, tool_calls, turns). Assistant turns carry proxy_in/proxy_out/tool_calls."""
    tokens = tool_calls = n = 0
    for t in turns:
        if t.get("role") == "assistant":
            n += 1
            tokens += int(t.get("proxy_in", 0)) + int(t.get("proxy_out", 0))
            tool_calls += len(t.get("tool_calls", []))
    return tokens, tool_calls, n


# ---- domain registry --------------------------------------------------------------------------------------------------------------------------------------

BASE_DOMAIN_NAMES = ("dataanalysis", "toolstate", "coding", "research", "injection", "toyctf", "bugfix")
SEALED_SUFFIX = ":sealed"
SEALED_CAPABLE = ("research", "injection", "toyctf", "bugfix")       # base domains whose derive(seed, size, style) takes a Style
DOMAIN_NAMES = BASE_DOMAIN_NAMES + tuple(n + SEALED_SUFFIX for n in SEALED_CAPABLE)


# ---- sealed generators ------------------------------------------------------------------------------------------------------------------------------------
# THE LIMIT THIS ADDRESSES. A generator is public, so a lab can train on the whole family of tasks it produces; commit-reveal hides only the JUDGED instances. A SEALED domain (`research:sealed`)
# keeps the public generator but draws its SURFACE parameters, the vocabulary pools, names, phrasings, address formats and numeric ranges, from a Style derived as
# HMAC(master seed, "agent-style|domain|version"). The master seed is secret until the reveal and already committed, so the Style is secret and committed with no extra machinery, and a verifier
# re-derives it from the revealed seed. A model trained on the PUBLIC generator has seen the canonical vocabulary, not the sealed one.
# WHAT IT DOES NOT DO: it does not change the SKILL tested (following links, decoding a shift, resisting an injected instruction); a model trained on that skill generally still gains. It narrows the
# memorisation of surface forms and fixed vocabularies, by the number of bits `sealed_entropy_bits(base)` reports for each domain. Canonical (unsealed) instances are byte-for-byte unchanged.

class Style:
    """Seeded choices for a sealed domain. Each label gets its own stream, so adding a draw to one label never moves another."""

    def __init__(self, seed):
        self.seed = seed

    def _rng(self, label):
        return Rng(hashlib.sha256(b"agent-style|" + self.seed + b"|" + label.encode("utf-8")).digest())

    def sample(self, label, pool, k):
        """k distinct items of `pool`, in a seeded order."""
        return self._rng(label).sample(list(pool), k)

    def pick(self, label, options):
        return self._rng(label).choice(list(options))

    def between(self, label, lo, hi):
        return self._rng(label).randint(lo, hi)


class _Canonical:
    """The public generator's own parameters: the first k of every pool, the first option, the low end of every range. Using it reproduces the unsealed instances exactly."""

    def sample(self, label, pool, k):
        return list(pool)[:k]

    def pick(self, label, options):
        return list(options)[0]

    def between(self, label, lo, hi):
        return lo


CANONICAL = _Canonical()


def sample_bits(n, k):
    """log2 of the number of ordered k-subsets of an n-pool."""
    return sum(math.log2(n - i) for i in range(k))


def sealed_style(master, domain_name, version):
    return Style(hmac.new(master, ("agent-style|%s|%s" % (domain_name, version)).encode("utf-8"), hashlib.sha256).digest())


class SealedDomain(object):
    """A base domain run with a sealed Style. Everything but NAME, VERSION and instance creation is the base domain's own."""
    SEALED = True

    def __init__(self, base):
        self._base = base
        self.NAME = base.NAME + SEALED_SUFFIX
        self.VERSION = base.VERSION + "+sealed1"
        self.DOC = base.DOC + " (sealed variant: names, wording and ranges are drawn from the secret seed)"

    def __getattr__(self, name):
        return getattr(self._base, name)

    def derive_sealed(self, seed, size, style):
        return self._base.derive(seed, size, style)

    def derive(self, seed, size):
        raise AgentEvalError("a sealed domain derives instances only through make_instance (it needs the master seed)")


def sealed_entropy_bits(base_name):
    """Approximate bits of surface entropy the Style adds to one round of this domain (the sum over its sealed draws; see each domain's SEALED_DRAWS)."""
    mod = load_domain(base_name)
    return round(sum(b for _label, b in mod.SEALED_DRAWS), 1)


def runs_code(domain_name):
    """True if verifying or running this domain EXECUTES agent-written code (coding, bugfix): real rounds then need an isolated seed, and verifying a ladder needs a throwaway machine."""
    try:
        return bool(getattr(load_domain(domain_name), "RUNS_CODE", False))
    except AgentEvalError:
        return False


def load_domain(name):
    if name not in DOMAIN_NAMES:
        raise AgentEvalError("unknown agent domain %r (known: %s)" % (name, ", ".join(DOMAIN_NAMES)))
    import importlib
    if name.endswith(SEALED_SUFFIX):
        return SealedDomain(importlib.import_module("agent_domains." + name[:-len(SEALED_SUFFIX)]))
    return importlib.import_module("agent_domains." + name)


def domain_sizes(mod):
    lo, hi = mod.SIZE_RANGE
    return list(range(lo, hi + 1, mod.SIZE_STEP))


def make_instance(mod, master, size, idx):
    seed = instance_seed(master, mod.NAME, mod.VERSION, size, idx)
    if getattr(mod, "SEALED", False):
        inst = mod.derive_sealed(seed, size, sealed_style(master, mod.NAME, mod.VERSION))
    else:
        inst = mod.derive(seed, size)
    if not isinstance(inst, dict) or "public" not in inst or "private" not in inst:
        raise AgentEvalError("%s.derive must return {'public':..., 'private':...}" % mod.NAME)
    inst = dict(inst)
    inst["id"] = instance_id(mod.NAME, size, idx)
    inst["size"] = size
    return inst


def source_hashes(domain_name):
    """Hashes of the files a result depends on: the core, the harness, the domain. Recorded in every ladder header so a changed rule is visible."""
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    base = domain_name[:-len(SEALED_SUFFIX)] if domain_name.endswith(SEALED_SUFFIX) else domain_name
    files = ["agent_core.py", "agent_harness.py", os.path.join("agent_domains", "__init__.py"), os.path.join("agent_domains", base + ".py")]
    out = {}
    for rel in files:
        p = os.path.join(here, rel)
        out[rel.replace(os.sep, "/")] = file_sha256(p) if os.path.exists(p) else None
    return out


def read_master(seed_path, practice):
    if practice:
        return PRACTICE_SEED
    try:
        with open(seed_path, "rb") as f:
            s = f.read().strip()
    except (OSError, TypeError):
        raise AgentEvalError("cannot read the seed file (use --seed FILE, or --practice for the public practice seed)")
    if len(s) < 16:
        raise AgentEvalError("seed file too short: use at least 16 bytes of randomness (python3 -c \"import secrets;print(secrets.token_hex(32))\")")
    return s
