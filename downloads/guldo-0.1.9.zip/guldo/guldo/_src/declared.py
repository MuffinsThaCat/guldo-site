"""Declared domains: how a compiled problem declaration becomes a registered family (see COMPILER.md).

A declaration is a directory  domains/<name>/  holding
    decl.py        the author's file: NAME, VERSION, SIZE_RANGE, REFERENCE_SOLVER, derive(master, size, idx), verify(inst, ans)
    reference.py   (any file name; REFERENCE_SOLVER) the baseline every submission is measured against
    compiled.json  written ONLY by compile_domain.py: the calibrated ladder, cap, official n, power analysis and self-test result

families.py calls load_all() when it is imported, so every process (harness, judge, portal, worker) sees the same registry. A domain is
registered only if compiled.json is FRESH: its recorded hashes of decl.py and the reference solver must equal the files on disk. Editing
either file un-registers the domain until it is compiled again, because a stale ladder or cap was calibrated to different instances.

decl.py is OPERATOR code and runs in the judge's process, exactly like instances.py does. Submissions never touch it: they run in the
sandbox with only runner.py and their own file.
"""
import hashlib
import importlib.util
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
NAME_RE = re.compile(r"^[a-z]{2,16}$")  # letters only: judge.py rescore and report_html recognise ladder files by this pattern
FORMAT = "svp-compiled-v1"
COMPILED = "compiled.json"
DECL = "decl.py"
REQUIRED = ("NAME", "VERSION", "SIZE_RANGE", "REFERENCE_SOLVER", "derive", "verify")


class DeclarationError(Exception):
    """A declaration or its compiled record is unusable; the message is safe to show to its author."""


def domains_dir():
    return os.environ.get("SVP_DOMAINS_DIR") or os.path.join(HERE, "domains")


def sha256_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def load_declaration(dirpath):
    """Import decl.py from `dirpath` and check its shape (not its behaviour: that is compile_domain's validate pass)."""
    dirpath = os.path.abspath(dirpath)
    path = os.path.join(dirpath, DECL)
    if not os.path.isfile(path):
        raise DeclarationError(f"{dirpath} has no {DECL}")
    spec = importlib.util.spec_from_file_location(f"svp_decl_{sha256_file(path)[:16]}", path)
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
    except Exception as e:  # the author's own code: report it, never crash the registry
        raise DeclarationError(f"{DECL} failed to import: {type(e).__name__}: {e}")
    missing = [k for k in REQUIRED if not hasattr(mod, k)]
    if missing:
        raise DeclarationError(f"{DECL} does not define {', '.join(missing)}")
    if not isinstance(mod.NAME, str) or not NAME_RE.match(mod.NAME):
        raise DeclarationError("NAME must be 2-16 lowercase letters a-z (no digits or hyphens)")
    if mod.NAME != os.path.basename(dirpath):
        raise DeclarationError(f"NAME {mod.NAME!r} must equal the directory name {os.path.basename(dirpath)!r}")
    if not isinstance(mod.VERSION, str) or not mod.VERSION.strip():
        raise DeclarationError("VERSION must be a non-empty string; bump it whenever derive() changes")
    sr = mod.SIZE_RANGE
    if not (isinstance(sr, (tuple, list)) and len(sr) == 2 and all(isinstance(x, int) and not isinstance(x, bool) for x in sr)
            and 1 <= sr[0] < sr[1]):
        raise DeclarationError("SIZE_RANGE must be (lo, hi): two integers with 1 <= lo < hi")
    step = getattr(mod, "SIZE_STEP", 1)
    if not (isinstance(step, int) and not isinstance(step, bool) and step >= 1):
        raise DeclarationError("SIZE_STEP, if given, must be a positive integer")
    if not callable(mod.derive) or not callable(mod.verify):
        raise DeclarationError("derive and verify must be functions")
    return mod


def reference_path(dirpath, mod):
    """Absolute path of the declared reference solver. It must be a file INSIDE the declaration directory."""
    dirpath = os.path.realpath(dirpath)
    rel = mod.REFERENCE_SOLVER
    if not isinstance(rel, str) or not rel or os.path.isabs(rel):
        raise DeclarationError("REFERENCE_SOLVER must be a relative path inside the declaration directory")
    p = os.path.realpath(os.path.join(dirpath, rel))
    if not p.startswith(dirpath + os.sep):
        raise DeclarationError("REFERENCE_SOLVER must stay inside the declaration directory")
    if not os.path.isfile(p):
        raise DeclarationError(f"REFERENCE_SOLVER {rel!r} does not exist")
    return p


def read_compiled(dirpath):
    try:
        with open(os.path.join(dirpath, COMPILED), encoding="utf-8") as f:
            c = json.load(f)
        return c if isinstance(c, dict) else None
    except (OSError, ValueError):
        return None


def freshness_problems(dirpath, mod, compiled):
    """Why `compiled` cannot be trusted for the declaration on disk (empty list = fresh)."""
    if compiled is None:
        return ["not compiled (no readable compiled.json)"]
    out = []
    if compiled.get("format") != FORMAT:
        out.append(f"compiled.json has format {compiled.get('format')!r}, expected {FORMAT!r}")
    if compiled.get("name") != mod.NAME:
        out.append("compiled.json is for a different NAME")
    if compiled.get("version") != mod.VERSION:
        out.append(f"VERSION changed ({compiled.get('version')!r} -> {mod.VERSION!r})")
    if compiled.get("decl_sha256") != sha256_file(os.path.join(dirpath, DECL)):
        out.append("decl.py changed since it was compiled")
    try:
        if compiled.get("reference_sha256") != sha256_file(reference_path(dirpath, mod)):
            out.append("the reference solver changed since it was compiled")
    except DeclarationError as e:
        out.append(str(e))
    for k in ("dims", "practice_dims", "official"):
        if k not in compiled:
            out.append(f"compiled.json lacks {k!r}")
    # the SHAPE of what register() will index: a hand-edited or damaged record must be refused here, not crash every process that imports families
    isint = lambda v: isinstance(v, int) and not isinstance(v, bool)
    off = compiled.get("official")
    if "official" in compiled and not (isinstance(off, dict) and isint(off.get("n")) and off["n"] >= 1
                                        and isinstance(off.get("budget"), (int, float)) and not isinstance(off.get("budget"), bool) and off["budget"] > 0):
        out.append("compiled.json: 'official' must be {n: positive int, budget: positive number}")
    for k in ("dims", "practice_dims"):
        v = compiled.get(k)
        if k in compiled and not (isinstance(v, list) and v and all(isint(x) for x in v)):
            out.append(f"compiled.json: {k!r} must be a non-empty list of integers")
    return out


def make_spec(mod):
    """(derive, verify) in the form families.FAMILIES expects. derive adds id/dim/idx so a declaration need not."""
    def derive(master, size, idx):
        inst = dict(mod.derive(master, size, idx))
        inst.setdefault("id", f"{size}:{idx}")
        inst.setdefault("dim", size)
        inst.setdefault("idx", idx)
        return inst
    return derive, mod.verify


def register(fam, dirpath, mod, compiled):
    """Fill the six tables of the `families` module for this domain. Raises DeclarationError on a name clash."""
    name = mod.NAME
    if name in fam.FAMILIES and name not in fam.DECLARED:
        raise DeclarationError(f"{name!r} is a built-in family; choose another NAME")
    real_here = os.path.realpath(fam.HERE)
    ref = os.path.relpath(reference_path(dirpath, mod), real_here) if os.path.realpath(dirpath).startswith(real_here + os.sep) \
        else reference_path(dirpath, mod)  # outside the project (tests): judge.py joins with HERE, and join(HERE, absolute) is the absolute path
    # compute everything first, then assign: a bad record must leave the registry untouched, never half a domain
    spec, official = make_spec(mod), {"n": int(compiled["official"]["n"]), "budget": compiled["official"]["budget"]}
    dims, practice = [int(d) for d in compiled["dims"]], [int(d) for d in compiled["practice_dims"]]
    info = {"dir": os.path.abspath(dirpath), "compiled": compiled, "decl_sha256": compiled["decl_sha256"]}
    fam.FAMILIES[name] = spec
    fam.VERSIONS[name] = mod.VERSION
    fam.OFFICIAL[name] = official
    fam.DEFAULT_DIMS[name] = dims
    fam.DEFAULT_BASELINE[name] = ref
    fam.PRACTICE_DIMS[name] = practice
    fam.DECLARED[name] = info


BUILTIN = ("gm", "mlwe", "factor")


def unregister(fam, name):
    if name in BUILTIN:  # never remove a built-in family, whatever calls this
        return
    for table in (fam.FAMILIES, fam.VERSIONS, fam.OFFICIAL, fam.DEFAULT_DIMS, fam.DEFAULT_BASELINE, fam.PRACTICE_DIMS, fam.DECLARED):
        table.pop(name, None)


def load_all(fam, root=None):
    """Register every fresh compiled declaration under `root` (default domains/). Anything unusable is recorded in fam.DECLARED_ERRORS,
    never raised: one broken declaration must not stop the judge, the portal or the other domains from starting."""
    root = os.path.abspath(root or domains_dir())
    loaded = []
    try:
        names = sorted(os.listdir(root))
    except OSError:
        return loaded
    for entry in names:
        d = os.path.join(root, entry)
        if not os.path.isfile(os.path.join(d, DECL)):
            continue
        try:
            mod = load_declaration(d)
            problems = freshness_problems(d, mod, read_compiled(d))
            if problems:
                raise DeclarationError("; ".join(problems) + " (run compile_domain.py compile again)")
            register(fam, d, mod, read_compiled(d))
            fam.DECLARED_ERRORS.pop(entry, None)
            loaded.append(mod.NAME)
        except DeclarationError as e:
            fam.DECLARED_ERRORS[entry] = str(e)
        except Exception as e:  # a damaged compiled.json or odd declaration must never stop `import families` (the judge, portal and worker all import it)
            fam.DECLARED_ERRORS[entry] = f"unusable: {type(e).__name__}: {e}"
    return loaded


def domain_files(fam, name):
    """{repo-relative or absolute path: sha256} of the files a declared domain's rules rest on. rounds.code_fingerprint records them in
    entry 0 of a round's log, so a declaration or its compiled ladder cannot change under a running round unnoticed."""
    info = fam.DECLARED.get(name)
    if not info:
        return {}
    d = info["dir"]
    mod = load_declaration(d)
    files = [os.path.join(d, DECL), os.path.join(d, COMPILED), reference_path(d, mod)]
    real_here = os.path.realpath(fam.HERE)
    return {(os.path.relpath(p, real_here) if os.path.realpath(p).startswith(real_here + os.sep) else p): sha256_file(p) for p in files}
