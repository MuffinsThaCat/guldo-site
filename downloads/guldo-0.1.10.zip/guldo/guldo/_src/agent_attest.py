"""Attested token counts and trajectories: signed receipts from a recording shim, and the checks that use them.

THE PROBLEM. A ladder proves its records are internally consistent and correct, not that a model produced them, and its token counts are proxies. Both gaps close the same way: a party the
VERIFIER trusts sits between the harness and the model, sees every request and response, and signs a receipt for each. A trajectory then verifies only if a signed receipt exists for every
model call in it, with the same request, the same response and the same provider usage numbers. An operator cannot hand-write a trajectory (no receipt for it), cannot raise or lower a token count
(the usage is inside the signed receipt), and cannot splice calls from another run (receipts chain per session and name the instance and trial).

  AttestingAgent(inner, secret, session)   wraps any agent. Each respond() signs a receipt over (sha256 of the exact request the harness sent, sha256 of the exact reply, the provider's usage
                                           numbers if any). receipts() returns them in order. Run it under the verifier's key, in a process the operator cannot reach, to get the guarantee.
  verify_attested(header, records, receipts, trusted_keys)   problems list (empty = every model call in the ladder is covered by a valid, chained, matching receipt from a trusted key).
  attested_counts(records, receipts)   per trial: provider-reported input/output tokens AS SIGNED, so cost can be stated in a unit the provider produced, vouched for by the shim.
  convert(header, records, receipts, trusted_keys, master)   (verifies the receipts first) the same ladder with `tokens` replaced by the attested provider tokens and the header's counter changed to ATTESTED_COUNTER, which agent_compare then
                                       compares like any other (both ladders must use it).

WHAT THIS DOES AND DOES NOT PROVE. It moves trust, it does not remove it: the shim's key holder is trusted not to forge receipts, the provider's usage numbers are the provider's own (the shim
vouches only that it relayed them unmodified), and a model call routed around the shim is invisible. If the shim runs on the OPERATOR's machine under the operator's key it proves nothing about
the operator; the check therefore counts only keys the verifier pinned (`trusted_keys`) and says so. It has been tested with fake agents; no real provider call went through it. The provider
does not sign its responses today (to my knowledge), which would be the stronger design: then no shim is needed.
"""
import hashlib

import agent_core
import agent_domains_plus                                                            # noqa: F401  this module loads a ladder's domain by name: the extra domains must be registered
import agent_harness
import agent_sig
from agent_core import canon, sha256_hex

RECEIPT_FORMAT = "guldo-agent-receipt-v1"
ATTESTED_COUNTER = "attested-provider-usage-v1"


def request_hash(system, tools, messages):
    return sha256_hex(canon({"system": system, "tools": tools, "messages": messages}))


def reply_view(text, tool_calls):
    """The reply as the harness stores it, minus the harness's own ids, so the shim and the verifier hash the same thing."""
    return {"text": text, "tool_calls": [{"name": c["name"], "args": c.get("args", {})} for c in tool_calls]}


def reply_hash(text, tool_calls):
    return sha256_hex(canon(reply_view(text, tool_calls)))


class AttestingAgent:
    def __init__(self, inner, secret, session="s0", registry=None, plan_hash=""):
        """With a `registry` (a SessionRegistry) the session id is assigned by it, not by the caller, and `close()` records how the session ended: see SessionRegistry."""
        self.registry = registry
        if registry is not None:
            session = registry.open(plan_hash)
        self.inner, self.secret, self.session = inner, secret, session
        self.label = getattr(inner, "label", "attested")
        self._receipts = []
        self._prev = agent_core.CHAIN_START
        self._iid, self._trial, self._turn = "", 0, 0

    def begin(self, instance_id, trial):
        self._iid, self._trial, self._turn = instance_id, trial, 0
        if hasattr(self.inner, "begin"):
            self.inner.begin(instance_id, trial)

    def respond(self, system, tools, messages):
        reply = self.inner.respond(system, tools, messages)
        text = reply.get("text", "")
        calls = reply.get("tool_calls", [])
        usage = reply.get("usage")
        if usage is not None and not (isinstance(usage, dict) and isinstance(usage.get("input_tokens"), int) and isinstance(usage.get("output_tokens"), int)):
            usage = None
        body = {"format": RECEIPT_FORMAT, "session": self.session, "instance": self._iid, "trial": self._trial, "turn": self._turn, "seq": len(self._receipts),
                "req": request_hash(system, tools, messages), "resp": reply_hash(text, calls),
                "usage": {"input_tokens": usage["input_tokens"], "output_tokens": usage["output_tokens"]} if usage else None, "prev": self._prev}
        signed = agent_sig.sign_statement(body, self.secret)
        self._prev = sha256_hex(canon(signed))
        self._receipts.append(signed)
        self._turn += 1
        return reply

    def receipts(self):
        return list(self._receipts)

    def close(self):
        """End the session and record its length and last receipt in the registry (a no-op without one). Call it once, when the ladder run is over."""
        if self.registry is not None:
            self.registry.close(self.session, self._receipts)


def write_receipts(path, receipts):
    with open(path, "w", encoding="utf-8") as f:
        for r in receipts:
            f.write(canon(r) + "\n")


def read_receipts(path):
    import json
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(ln) for ln in f.read().split("\n") if ln.strip()]


REGISTRY_FORMAT = "guldo-agent-session-registry-v1"
HEAD_FORMAT = "guldo-agent-session-registry-head-v1"


class SessionRegistry:
    """Who ran how many sessions. Kept by the party that runs the shim (the verifier), under the shim's key.

    THE HOLE IT CLOSES. Receipts chain only WITHIN a session, so an operator who can run the shim as often as they like can run the whole ladder several times and present only the best session: the
    dropped sessions leave no trace in the receipts. The registry is an append-only, hash-chained, SIGNED file of events: `open` (a session starts, for a plan hash; the shim, not the operator, picks the
    session number) and `close` (the session ended, with the number of receipts and the hash of the last one). `check_sessions` then tells a verifier how many sessions were opened for a plan, and whether
    the receipts presented are the complete closed chain of one of them. A session opened and never closed counts as an attempt.

    WHAT IT DOES NOT DO. It moves trust to whoever holds the shim's key and file, like the receipts themselves. It cannot see a model call routed around the shim. And a registry file with its LAST events
    removed looks shorter, not wrong: the verifier must hold a head published earlier (`head()`, checked with `expected_head`), exactly as for the round logs."""

    def __init__(self, path, secret=None):
        self.path, self.secret = path, secret             # reading needs no key; only open/close sign

    def read_events(self):
        return self._read()

    def _parse(self, text):
        import json
        out = []
        for n, ln in enumerate(text.split("\n"), 1):
            if ln.strip():
                try:
                    out.append(json.loads(ln))
                except ValueError:
                    raise ValueError("the session registry %s is damaged at line %d (a torn write or an edit): it cannot be extended or trusted as it is" % (self.path, n))
        return out

    def _read(self):
        import json
        import os
        if not os.path.exists(self.path):
            return []
        with open(self.path, "r", encoding="utf-8") as f:
            return self._parse(f.read())

    def _append(self, body):
        import os
        try:
            import fcntl
        except ImportError:                                             # no flock on this platform: single-writer use only
            fcntl = None
        fd = os.open(self.path, os.O_RDWR | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            if fcntl:
                fcntl.flock(fd, fcntl.LOCK_EX)
            with os.fdopen(os.dup(fd), "r", encoding="utf-8") as f:
                entries = self._parse(f.read())
            if callable(body):                                         # decided under the lock, from the entries as they are NOW (two shims opening at once must not be handed one id)
                body = body(entries)
            prev = sha256_hex(canon(entries[-1])) if entries else agent_core.CHAIN_START
            signed = agent_sig.sign_statement(dict(body, format=REGISTRY_FORMAT, seq=len(entries), prev=prev), self.secret)
            data = (canon(signed) + "\n").encode("utf-8")
            while data:                                                # os.write may write less than asked: finish the line, or the registry would hold a torn event
                data = data[os.write(fd, data):]
            os.fsync(fd)
        finally:
            os.close(fd)                                                # closing the descriptor releases the lock
        return signed

    def open(self, plan_hash):
        """Register a new session for `plan_hash` and return its id. The number is the count of sessions ever opened here, so it cannot be chosen or reused."""
        chosen = []

        def make(entries):
            sid = "s%d" % sum(1 for e in entries if e.get("statement", {}).get("kind") == "open")
            chosen.append(sid)
            return {"kind": "open", "session": sid, "plan_hash": plan_hash}
        self._append(make)
        return chosen[0]

    def close(self, session, receipts):
        head = sha256_hex(canon(receipts[-1])) if receipts else agent_core.CHAIN_START
        return self._append({"kind": "close", "session": session, "n_receipts": len(receipts), "head": head})

    def head(self):
        """The hash of the last event: publish it when a ladder is closed, and give it back as `expected_head` when verifying."""
        e = self._read()
        return sha256_hex(canon(e[-1])) if e else agent_core.CHAIN_START

    def signed_head(self):
        """A statement, signed by the shim's key, that "the registry had N events and its last hash was H". Unlike a bare hash it is portable evidence: anyone who has EVER seen one (published in a
        log, emailed, pinned) can later hand it to `check_sessions(signed_heads=[...])`, which refuses a registry that is shorter than N (events removed) or whose Nth event differs (events rewritten),
        without trusting the person who produced the registry file. Someone still has to have kept one."""
        if self.secret is None:
            raise ValueError("a signed head needs the shim's key")
        e = self._read()
        return agent_sig.sign_statement({"format": HEAD_FORMAT, "length": len(e), "head": sha256_hex(canon(e[-1])) if e else agent_core.CHAIN_START}, self.secret)


def _check_signed_heads(registry, signed_heads, trusted):
    """Problems from signed heads (`SessionRegistry.signed_head`): each must be a valid statement from a pinned key, and the registry must still contain exactly what it said (length and the hash of its
    last event at that time)."""
    probs = []
    for k, h in enumerate(signed_heads or []):
        st = h.get("statement") if isinstance(h, dict) else None
        if not isinstance(st, dict) or st.get("format") != HEAD_FORMAT or not agent_sig.statement_ok(h):
            probs.append("signed head %d is malformed or its signature is bad" % k)
            continue
        if st.get("pubkey") not in trusted:
            probs.append("signed head %d is signed by a key you did not pin" % k)
            continue
        n = st.get("length")
        if not isinstance(n, int) or isinstance(n, bool) or n < 0:
            probs.append("signed head %d has no valid length" % k)
        elif len(registry) < n:
            probs.append("the registry has %d events but a signed head you hold says it had %d: events were REMOVED" % (len(registry), n))
        else:
            actual = sha256_hex(canon(registry[n - 1])) if n else agent_core.CHAIN_START
            if actual != st.get("head"):
                probs.append("the registry's event %d differs from what a signed head you hold recorded: events were REWRITTEN" % n)
    return probs


def check_sessions(registry, receipts, plan_hash, trusted_keys, allow_multiple=False, expected_head=None, signed_heads=None):
    """-> (problems, info). `registry` is the list of signed events (SessionRegistry's file). Problems: a broken or unsigned or untrusted registry; no session registered for this plan; receipts that
    come from more than one session or from an unregistered one; a session that was never closed or whose close does not match the presented receipts (a truncated, extended or substituted chain);
    and, unless `allow_multiple`, MORE THAN ONE session opened for this plan (the presented ladder may be the best of several). `info` carries the counts so a claim can state how many attempts there were.
    Never raises on damaged input."""
    probs, info = [], {"sessions_opened": None, "presented": None, "abandoned": []}
    try:
        trusted = set(trusted_keys or [])
        if not trusted:
            return ["no trusted keys given: pin the key of the shim that wrote the registry"], info
        prev, opens, closes = agent_core.CHAIN_START, {}, {}
        for i, e in enumerate(registry):
            st = e.get("statement") if isinstance(e, dict) else None
            if not isinstance(st, dict) or st.get("format") != REGISTRY_FORMAT or not agent_sig.statement_ok(e):
                probs.append("registry entry %d is malformed or its signature is bad" % i)
                continue
            if st.get("pubkey") not in trusted:
                probs.append("registry entry %d is signed by a key you did not pin" % i)
            if st.get("seq") != i or st.get("prev") != prev:
                probs.append("registry entry %d: the chain or sequence is broken (an event was removed or reordered)" % i)
            prev = sha256_hex(canon(e))
            if st.get("kind") == "open":
                if st.get("session") in opens:
                    probs.append("registry entry %d: session %s opened twice" % (i, st.get("session")))
                opens[st.get("session")] = st.get("plan_hash")
            elif st.get("kind") == "close":
                if st.get("session") in closes:
                    probs.append("registry entry %d: session %s closed twice" % (i, st.get("session")))
                closes[st.get("session")] = st
        if expected_head is not None and prev != expected_head:
            probs.append("the registry's head is not the one you were given: events were added or removed since")
        probs.extend(_check_signed_heads(registry, signed_heads, trusted))
        mine = sorted(s for s, p in opens.items() if p == plan_hash)
        info["sessions_opened"] = len(mine)
        if not mine:
            probs.append("no session was registered for this plan hash")
        sessions = {(r.get("statement") or {}).get("session") for r in receipts if isinstance(r, dict)}
        if len(sessions) != 1:
            probs.append("the receipts come from %d sessions (a ladder's receipts must be ONE session's chain)" % len(sessions))
        else:
            sid = next(iter(sessions))
            info["presented"] = sid
            info["abandoned"] = [s for s in mine if s != sid]
            if sid not in mine:
                probs.append("the receipts' session %r is not a session registered for this plan" % (sid,))
            elif sid not in closes:
                probs.append("session %s was never closed: its receipts may be incomplete" % sid)
            else:
                c = closes[sid]
                last = sha256_hex(canon(receipts[-1])) if receipts else agent_core.CHAIN_START
                if c.get("n_receipts") != len(receipts) or c.get("head") != last:
                    probs.append("the presented receipts are not session %s's complete closed chain (registered %s receipts, head %s...; presented %d, head %s...)"
                                 % (sid, c.get("n_receipts"), str(c.get("head"))[:12], len(receipts), last[:12]))
        if len(mine) > 1 and not allow_multiple:
            probs.append("%d sessions were opened for this plan (%s abandoned): the presented ladder may be the best of several attempts; state the attempt count or re-run once"
                         % (len(mine), ", ".join(info["abandoned"]) or "none"))
    except (KeyError, TypeError, ValueError, AttributeError) as e:
        probs.append("malformed registry or receipts (%s: %s)" % (type(e).__name__, str(e)[:100]))
    return probs, info


def _chain_problems(receipts, trusted, fmt=RECEIPT_FORMAT):
    probs, prev, seen_keys = [], agent_core.CHAIN_START, set()
    for i, r in enumerate(receipts):
        st = r.get("statement") if isinstance(r, dict) else None
        if not isinstance(st, dict) or st.get("format") != fmt:
            probs.append("receipt %d is malformed" % i)
            continue
        if not agent_sig.statement_ok(r):
            probs.append("receipt %d: bad signature" % i)
        if st.get("prev") != prev or st.get("seq") != i:
            probs.append("receipt %d: chain or sequence broken" % i)
        prev = sha256_hex(canon(r))
        seen_keys.add(st.get("pubkey"))
    for k in seen_keys:
        if trusted is not None and k not in trusted:
            probs.append("receipt key %s... is not a key you pinned as trusted" % str(k)[:12])
    return probs


def verify_attested(header, records, receipts, trusted_keys, master, registry=None, allow_multiple_sessions=False, expected_registry_head=None, registry_signed_heads=None):
    """Every model call in every trial must be covered by a valid, chained, matching receipt from a pinned key. `master` is the revealed seed (the tool list in a request depends on the instance).
    With a session `registry` (the shim's signed record of every session it opened) it ALSO checks that the receipts are one registered session's complete closed chain and that no other session
    was opened for this plan, which is what stops an operator presenting the best of several runs; without one, selection among sessions cannot be ruled out and the problems list says nothing about it.
    Returns a list of problems. Never raises on damaged input: a malformed file is a problem, not a crash."""
    try:
        agent_core.require_shape(header, records)
        if not isinstance(receipts, list):
            return ["the receipts are not a list"]
        probs = _verify_attested(header, records, receipts, trusted_keys, master)
        if registry is not None:
            if not isinstance(registry, list):
                return probs + ["the session registry is not a list"]
            more, _ = check_sessions(registry, receipts, header.get("plan_hash"), trusted_keys, allow_multiple_sessions, expected_registry_head, registry_signed_heads)
            probs = probs + more
        return probs
    except agent_core.AgentEvalError as e:
        return [str(e)]
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, OverflowError) as e:
        return ["malformed input (%s: %s)" % (type(e).__name__, str(e)[:100])]


def _verify_attested(header, records, receipts, trusted_keys, master):
    if not trusted_keys:
        return ["no trusted keys given: signatures prove only that SOME key signed; pin the verifier's key"]
    probs = _chain_problems(receipts, set(trusted_keys))
    by = {}
    for r in receipts:
        st = r.get("statement", {}) if isinstance(r, dict) else {}
        by.setdefault((st.get("instance"), st.get("trial"), st.get("turn")), []).append(st)
    for rec in records:
        turns = rec.get("turns", [])
        tools = None
        k = 0
        for i, t in enumerate(turns):
            if t.get("role") != "assistant":
                continue
            key = (rec["instance"], rec["trial"], k)
            k += 1
            got = by.get(key, [])
            if len(got) != 1:
                probs.append("%s trial %s turn %d: %d receipts (need exactly 1)" % (rec["instance"], rec["trial"], k - 1, len(got)))
                continue
            st = got[0]
            if tools is None:
                mod = agent_core.load_domain(rec["domain"])
                tools = agent_harness.effective_tools(mod, agent_core.make_instance(mod, master, int(rec["size"]), int(rec["idx"])), header.get("allow_tools"))
            req = request_hash(header.get("system", agent_harness.SYSTEM), tools, [agent_harness.wire(x) for x in turns[:i]])
            if st["req"] != req:
                probs.append("%s trial %s turn %d: the signed request differs from the recorded context" % (rec["instance"], rec["trial"], k - 1))
            if st["resp"] != reply_hash(t.get("text", ""), t.get("tool_calls", [])):
                probs.append("%s trial %s turn %d: the signed reply differs from the recorded reply" % (rec["instance"], rec["trial"], k - 1))
            if st["usage"] != t.get("usage"):
                probs.append("%s trial %s turn %d: the signed usage differs from the recorded usage" % (rec["instance"], rec["trial"], k - 1))
    used = set((rec["instance"], rec["trial"], k) for rec in records for k in range(sum(1 for t in rec.get("turns", []) if t.get("role") == "assistant")))
    extra = [k for k in by if k not in used]
    if extra:
        probs.append("%d receipts belong to no recorded turn (a discarded or hidden run?)" % len(extra))
    return probs


def attested_counts(records, receipts):
    """{(instance, trial): (input_tokens, output_tokens) or None if any call lacked usage}"""
    out = {}
    by = {}
    if not isinstance(records, list) or not all(isinstance(r, dict) and isinstance(r.get("instance"), str) and isinstance(r.get("trial"), int) for r in records):
        raise agent_core.AgentEvalError("malformed ladder records")
    for r in receipts:
        st = r.get("statement") if isinstance(r, dict) else None
        if isinstance(st, dict) and isinstance(st.get("instance"), str) and isinstance(st.get("trial"), int):
            by.setdefault((st["instance"], st["trial"]), []).append(st)
    for rec in records:
        sts = by.get((rec["instance"], rec["trial"]), [])
        u = [s.get("usage") for s in sts]
        if not sts or any(not (isinstance(x, dict) and isinstance(x.get("input_tokens"), int) and isinstance(x.get("output_tokens"), int)) for x in u):
            out[(rec["instance"], rec["trial"])] = None
        else:
            out[(rec["instance"], rec["trial"])] = (sum(x["input_tokens"] for x in u), sum(x["output_tokens"] for x in u))
    return out


def convert(header, records, receipts, trusted_keys, master, registry=None, allow_multiple_sessions=False, expected_registry_head=None, registry_signed_heads=None):
    """Header and records with tokens replaced by attested provider tokens. Refuses unless verify_attested passes (every call covered by a pinned key's receipt, no stray receipts, so nothing is
    counted twice) and every trial has signed usage. With a session registry the session checks of verify_attested apply too."""
    probs = verify_attested(header, records, receipts, trusted_keys, master, registry, allow_multiple_sessions, expected_registry_head, registry_signed_heads)
    if probs:
        raise agent_core.AgentEvalError("the receipts do not attest this ladder (%d problems, first: %s): refusing to convert" % (len(probs), probs[0]))
    counts = attested_counts(records, receipts)
    if any(v is None for v in counts.values()):
        raise agent_core.AgentEvalError("some trial has no signed provider usage (a scripted agent reports none): nothing to attest")
    h = dict(header, counter=ATTESTED_COUNTER)
    out = []
    for rec in records:
        i, o = counts[(rec["instance"], rec["trial"])]
        out.append(dict(rec, tokens=i + o, proxy_tokens=rec["tokens"]))
    return h, out
