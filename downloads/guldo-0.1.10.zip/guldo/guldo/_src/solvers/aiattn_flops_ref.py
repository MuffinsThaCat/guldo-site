"""aiattn in the counted-operations API, REFERENCE: dense attention. The whole n x n score matrix, the window mask added, a softmax over every row, then the product with V."""
import math

import tensorops as tp

D = 16
WINDOW = 32
QK = 3.0


def solve(seed, n):
    m = n * D
    Q = tp.stream(seed, 0, m, (n, D)) * QK
    K = tp.stream(seed, m, m, (n, D)) * QK
    V = tp.stream(seed, 2 * m, m, (n, D))
    S = tp.einsum("id,jd->ij", Q, K) / math.sqrt(D)
    S = S + tp.causal_mask(n) + tp.transpose(tp.causal_mask(n + WINDOW), (1, 0))[0:n, WINDOW - 1:WINDOW - 1 + n]
    E = tp.exp(S - tp.max(S, 1, True))
    A = E / tp.sum(E, 1, True)
    return [int(x * 65536.0) for x in tp.reshape(A @ V, (n * D,)).tolist()]
