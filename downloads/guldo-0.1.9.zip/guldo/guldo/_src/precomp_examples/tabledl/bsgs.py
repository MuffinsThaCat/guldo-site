def preprocess(public):
    p, g = public
    m = 1
    while m * m < p:
        m += 1
    table, cur = [], 1
    for j in range(m):
        table.append([cur, j])
        cur = cur * g % p
    return {"p": p, "g": g, "m": m, "table": table}


def solve(state, h):
    p, g, m = state["p"], state["g"], state["m"]
    table = {v: j for v, j in state["table"]}
    step = pow(g, p - 1 - m, p)       # g^-m
    cur = h
    for i in range(m + 1):
        if cur in table:
            return (i * m + table[cur]) % (p - 1)
        cur = cur * step % p
    return None
