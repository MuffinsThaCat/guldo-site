"""The tensor API a FLOP-counted solver is written in (see tflops.py). Every operation charges an analytic cost computed from SHAPES ONLY, so the total is exactly
reproducible on any machine: it does not depend on the clock, the CPU, BLAS, threads, numpy's version or the dtype.

Cost table (one unit = one scalar operation; this is a convention, stated in every verdict, not a measurement):
  elementwise  + - * / neg exp sqrt relu          size of the result
  matmul / @   (..., m, k) @ (k, n)               2 * size(result) * k
  einsum       two operands                       2 * product of every index's extent
  sum max mean argmax                             size of the input
  stream       SplitMix64 floats                  10 per element (the integer hash of the model-regeneration step)
  tolist       size of the tensor (at most 2**22 elements)
  FREE         reshape transpose take concat slicing item-assignment zeros tensor causal_mask   (data movement and constants)
Memory: no tensor above 2**27 elements and no more than 2**28 elements alive at once (views counted as copies); a request past either fails like an exhausted budget,
BEFORE anything is allocated. Python-level memory (a list made with `[0.0] * 10**9`) is not covered here: tflops.py's parent-side resident-memory watchdog stops that.

What this is blind to, on purpose: memory traffic, cache behaviour, kernel quality, dtype and vectorisation. It certifies how much ARITHMETIC a solver asks for, so it
can certify "N times fewer operations" (a KV cache, pruning, early exit, a smaller model at equal output) and cannot certify "faster at the same arithmetic".
The solver's own Python is charged separately, one unit per bytecode instruction, so work cannot be hidden in plain-float loops (tflops_runner.py).

A solver sees only the functions in EXPORTS and the Tensor objects they return. Tensor keeps its array in a private attribute the restricted subset forbids naming.
"""
import re

import numpy as np

_FLOPS = [0]       # total tensor operations charged so far (the runner reads this; a solver cannot name this module, only the EXPORTS)
_LIMIT = [None]     # the runner sets the budget; charging past it raises BudgetExceeded
MAX_ELEMENTS = 1 << 27   # no tensor may have more elements than this (1 GiB of float64): a bigger one is the same failure as an exhausted budget
MAX_LIVE = 1 << 28       # nor may the tensors alive at once (2 GiB): views count as copies, which only over-counts. Without it, memory would be bounded only by the op budget
MAX_TOLIST = 1 << 22     # tolist() makes a Python list (about 32 bytes per float): the one way out of the tensor world, so it is small
_LIVE = [0]


class BudgetExceeded(BaseException):
    """A BaseException, so a solver's `except Exception` cannot swallow it."""


def _charge(n):
    _FLOPS[0] += int(n)
    if _LIMIT[0] is not None and _FLOPS[0] > _LIMIT[0]:
        raise BudgetExceeded()


def _size(n):
    """The size check, made BEFORE anything is allocated: a request over MAX_ELEMENTS fails without ever existing in memory. (Callers charge separately, also before allocating.)"""
    if n > MAX_ELEMENTS or _LIVE[0] + n > MAX_LIVE:
        raise BudgetExceeded()
    return n


def _dims(s):
    """A shape or axes argument: a list or tuple of at most 32 entries. Any other iterable (a range, itertools.repeat) could be made to build a huge sequence here."""
    if not isinstance(s, (list, tuple)) or len(s) > 32:
        raise TypeError("a shape or axes argument is a list or tuple of at most 32 ints")
    return tuple(s)


def _shape(s):
    s = _dims(s)
    if not all(isinstance(d, int) and not isinstance(d, bool) and d >= 0 for d in s):
        raise ValueError("a shape is a tuple of non-negative ints")
    return s


def _numbers(x, budget):
    """Count the numbers in a nested list/tuple of ints and floats, refusing anything else (and anything bigger than `budget`) before numpy builds an array from it."""
    if isinstance(x, bool) or not isinstance(x, (int, float, list, tuple)):
        raise TypeError("tensor(): nested lists or tuples of ints and floats only")
    if not isinstance(x, (list, tuple)):
        return 1
    n = 0
    for e in x:
        n += _numbers(e, budget - n)
        if n > budget:
            raise BudgetExceeded()
    return n


def _prod(shape):
    n = 1
    for d in shape:
        n *= int(d)
    return n


def _matmul_shape(sa, sb):
    if not sa or not sb:
        raise ValueError("@ needs tensors of at least one dimension")
    k = sa[-1]
    if k != (sb[0] if len(sb) == 1 else sb[-2]):
        raise ValueError("matmul: the inner dimensions differ")
    batch = np.broadcast_shapes(sa[:-2] if len(sa) >= 2 else (), sb[:-2] if len(sb) >= 2 else ())
    return tuple(batch) + (() if len(sa) == 1 else (sa[-2],)) + (() if len(sb) == 1 else (sb[-1],)), k


def _raw(v):
    if isinstance(v, Tensor):
        return v._a
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise TypeError("a tensor operand must be a Tensor or a number")
    return v


def _key(k):
    ks = k if isinstance(k, tuple) else (k,)
    for e in ks:
        if not (e is None or e is Ellipsis or isinstance(e, slice) or (isinstance(e, int) and not isinstance(e, bool))):
            raise TypeError("an index must be an int, a slice, None or ...")
    return k


class Tensor:
    __slots__ = ("_a",)

    def __init__(self, a):
        self._a = np.asarray(a, dtype=np.float64)
        _LIVE[0] += self._a.size

    def __del__(self):
        try:
            _LIVE[0] -= self._a.size
        except (AttributeError, TypeError):      # __init__ failed before the array was set, or the interpreter is shutting down and the module globals are gone
            pass

    @property
    def shape(self):
        return tuple(int(s) for s in self._a.shape)

    def item(self):
        return float(self._a.item())      # a one-element tensor of any rank; numpy raises ValueError for anything else (float(array) is deprecated for ndim > 0)

    def tolist(self):
        n = self._a.size
        if n > MAX_TOLIST:
            raise BudgetExceeded()
        _charge(n)
        return self._a.tolist()

    def __getitem__(self, k):
        return Tensor(self._a[_key(k)])

    def __setitem__(self, k, v):
        self._a[_key(k)] = _raw(v)

    def _bin(self, other, fn, flip=False):
        a, b = (_raw(other), self._a) if flip else (self._a, _raw(other))
        n = _size(_prod(np.broadcast_shapes(np.shape(a), np.shape(b))))
        _charge(n)
        return Tensor(fn(a, b))

    def __add__(self, o): return self._bin(o, np.add)
    def __radd__(self, o): return self._bin(o, np.add, True)
    def __sub__(self, o): return self._bin(o, np.subtract)
    def __rsub__(self, o): return self._bin(o, np.subtract, True)
    def __mul__(self, o): return self._bin(o, np.multiply)
    def __rmul__(self, o): return self._bin(o, np.multiply, True)
    def __truediv__(self, o): return self._bin(o, np.true_divide)
    def __rtruediv__(self, o): return self._bin(o, np.true_divide, True)

    def __neg__(self):
        _charge(self._a.size)
        return Tensor(-self._a)

    def __matmul__(self, o):
        if not isinstance(o, Tensor):
            raise TypeError("@ needs two Tensors")
        shape, k = _matmul_shape(self._a.shape, o._a.shape)
        n = _size(_prod(shape))
        _charge(2 * n * k)
        return Tensor(np.asarray(self._a @ o._a))


def stream(seed, start, n, shape=None):
    """n floats in [-1, 1) from the pinned SplitMix64 stream (the model-regeneration step), optionally reshaped."""
    if not all(isinstance(v, int) and not isinstance(v, bool) for v in (seed, start, n)) or n < 0 or seed < 0 or start < 0 or seed >= 1 << 64 or start + n >= 1 << 64:
        raise ValueError("stream(seed, start, n): non-negative ints below 2**64")
    shape = None if shape is None else _shape(shape)
    if shape is not None and _prod(shape) != n:
        raise ValueError("stream: the shape does not hold n elements")
    _size(n)
    _charge(10 * n)
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    a = (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0
    return Tensor(a if shape is None else a.reshape(shape))


def tensor(x):
    _numbers(x, MAX_ELEMENTS)
    return Tensor(np.array(x, dtype=np.float64))


def zeros(shape):
    shape = _shape(shape)
    _size(_prod(shape))
    return Tensor(np.zeros(shape))


def take(table, idx):
    """Rows of `table`: idx is an int or a list of ints. Data movement: free."""
    if isinstance(idx, int) and not isinstance(idx, bool):
        return Tensor(table._a[idx])
    if not isinstance(idx, (list, tuple)):
        raise TypeError("take: an int or a list of ints")
    _size(len(idx) * _prod(table._a.shape[1:]))
    idx = list(idx)
    if not all(isinstance(i, int) and not isinstance(i, bool) for i in idx):
        raise TypeError("take: indices are ints")
    _size(len(idx) * _prod(table._a.shape[1:]))
    return Tensor(table._a[idx])


def concat(ts, axis=0):
    if not isinstance(ts, (list, tuple)) or not all(isinstance(t, Tensor) for t in ts):
        raise TypeError("concat: a list or tuple of Tensors")
    total = 0                      # (no builtin sum: this module defines its own `sum`)
    for t in ts:
        total += t._a.size
    _size(total)
    return Tensor(np.concatenate([t._a for t in ts], axis=axis))


def reshape(x, shape):
    return Tensor(x._a.reshape(_dims(shape)))


def transpose(x, axes):
    return Tensor(x._a.transpose(_dims(axes)))


def causal_mask(n):
    """(n, n): 0 on and below the diagonal, -1e30 above. A constant of the shape: free."""
    if not isinstance(n, int) or isinstance(n, bool) or n < 0:
        raise ValueError("causal_mask(n): a non-negative int")
    _size(n * n)
    return Tensor(np.triu(np.full((n, n), -1e30), 1))


_EINSUM = re.compile(r"^([a-z]+),([a-z]+)->([a-z]*)$")


def einsum(spec, a, b):
    """Two-operand einsum with plain lowercase indices (no `...`, no repeated index inside one operand): the cost is read off the index extents, so a spec the parser
    could misread (an ellipsis, a repeated letter) is refused rather than undercharged."""
    m = _EINSUM.match(spec) if isinstance(spec, str) else None
    if not m:
        raise ValueError("einsum: a spec like 'ij,jk->ik' (lowercase letters only)")
    sa, sb, out = m.groups()
    if len(set(sa)) != len(sa) or len(set(sb)) != len(sb) or len(set(out)) != len(out) or not set(out) <= set(sa) | set(sb):
        raise ValueError("einsum: repeated or unknown output index")
    if len(sa) != a._a.ndim or len(sb) != b._a.ndim:
        raise ValueError("einsum: an operand's rank does not match its subscripts")
    ext = {}
    for sub, t in ((sa, a), (sb, b)):
        for ch, d in zip(sub, t._a.shape):
            if ext.setdefault(ch, d) != d:
                raise ValueError("einsum: an index has two different extents")
    _size(_prod([ext[c] for c in out]))
    _charge(2 * _prod(ext.values()))
    return Tensor(np.einsum(spec, a._a, b._a))


def exp(x):
    _charge(x._a.size)
    return Tensor(np.exp(x._a))


def sqrt(x):
    _charge(x._a.size)
    return Tensor(np.sqrt(x._a))


def relu(x):
    _charge(x._a.size)
    return Tensor(np.maximum(x._a, 0.0))


def sum(x, axis=None, keepdims=False):
    _charge(x._a.size)
    return Tensor(x._a.sum(axis=axis, keepdims=keepdims))


def max(x, axis=None, keepdims=False):
    _charge(x._a.size)
    return Tensor(x._a.max(axis=axis, keepdims=keepdims))


def mean(x, axis=None, keepdims=False):
    _charge(x._a.size)
    return Tensor(x._a.mean(axis=axis, keepdims=keepdims))


def argmax(x):
    """Index of the largest element of a 1-D tensor, as a Python int (lowest index on ties)."""
    if x._a.ndim != 1:
        raise ValueError("argmax takes a 1-D tensor")
    _charge(x._a.size)
    return int(np.argmax(x._a))


EXPORTS = ("stream", "tensor", "zeros", "take", "concat", "reshape", "transpose", "causal_mask", "einsum", "exp", "sqrt", "relu", "sum", "max", "mean", "argmax")
