"""The site's section for the AI-SYSTEMS studies (AI_SYSTEMS_SPEEDUPS.md): the domains of second-order optimisation, mixed precision, checkpointing, parallelism, distillation, pruning, a GPU, a simulated cluster
(with and without a topology), sparsity, low-precision formats, K-FAC and Shampoo, and real data. Used by build_site.py; it imports nothing from it.

EVERYTHING on the page is read from files in the results directory and from the domains' own declarations: the comparison files (svp-tflops-comparison-v1) give the gaps, the verdicts and the exact machine / processor
statements; the frontier files give how many instances each technique passed on the real-data domains; a domain's one-line description is the first sentence of its decl.py docstring, read as text (nothing is
executed). Nothing here is typed by hand, so a rebuilt site cannot say what the saved files do not. A file that is missing or unreadable is left out, never guessed."""
import ast
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
FAMILIES = ("aisecond", "aimixed", "aickpt", "aipar", "aidistill", "aiprune", "aigpu", "aireal", "aidist", "aipipe", "aimoed", "aizero", "aikfac", "airealm", "aitopo", "aipipetrain", "airealc", "airealt")
COMPARISON_FORMAT = "svp-tflops-comparison-v1"
FRONTIERS = (("aireal_frontier.json", "aireal", "operations", "8x8 digits, a small MLP, pruning and distillation (counted operations)"),
             ("aireal_frontier_mem3.json", "aireal", "bytes", "8x8 digits, sparsity and low precision (bytes, version-3 counter)"),
             ("airealm_frontier.json", "airealm", "bytes", "MNIST, an MLP up to 1024 hidden units (bytes, version-3 counter)"),
             ("airealc_frontier.json", "airealc", "bytes", "MNIST, a convolutional network (bytes, version-3 counter)"),
             ("airealt_frontier.json", "airealt", "bytes", "real text, a small transformer language model (bytes, version-3 counter)"))
LADDER = re.compile(r"^tflops(?:par|mem3|dist3|dist|mem2|mem)?_([a-z0-9]+)_[0-9a-f]{8}_(baseline|submission)_(.+)\.py\.jsonl$")
METRIC_WORDS = {"ops": "operations", "bytes": "bytes moved", "peak": "peak memory per device", "span": "critical path (span)", "time": "time on the default machine"}
GPU_BENCH = "gpubench_aigpu_mps_practice"
VALIDATION_FORMAT = "svp-validate-counts-v1"


def _read_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def comparison_files(results_dir):
    """[(file name, parsed comparison)] for every saved comparison of one of the systems domains, in a stable order."""
    out = []
    if not results_dir or not os.path.isdir(results_dir):
        return out
    for fn in sorted(os.listdir(results_dir)):
        if not (fn.startswith("compare_") and fn.endswith(".json")):
            continue
        c = _read_json(os.path.join(results_dir, fn))
        if isinstance(c, dict) and c.get("format") == COMPARISON_FORMAT and c.get("family") in FAMILIES:
            out.append((fn, c))
    return out


def ladder_files(results_dir):
    """The saved ladders of the systems domains (any counter), by file name."""
    if not results_dir or not os.path.isdir(results_dir):
        return []
    out = []
    for fn in sorted(os.listdir(results_dir)):
        m = LADDER.match(fn)
        if m and m.group(1) in FAMILIES:
            out.append(fn)
    return out


def frontier_files(results_dir):
    return [(fn, fam, unit, label) for fn, fam, unit, label in FRONTIERS if results_dir and os.path.exists(os.path.join(results_dir, fn))]


def validation_files(results_dir):
    """[(file name, parsed)] for every saved validation of the counts against measured times (validate_counts.py), one per device."""
    out = []
    if results_dir and os.path.isdir(results_dir):
        for fn in sorted(os.listdir(results_dir)):
            if fn.startswith("validate_counts_") and fn.endswith(".json"):
                d = _read_json(os.path.join(results_dir, fn))
                if isinstance(d, dict) and d.get("format") == VALIDATION_FORMAT and isinstance(d.get("pairs"), list):
                    out.append((fn, d))
    return out


def _validation_table(fn, d, esc, quote):
    rows = ""
    for r in d["pairs"]:
        v = r.get("verdict") or {}
        status = str(v.get("status", "?"))
        pred, meas, rng = v.get("predicted_ratio_b_over_a"), v.get("measured_ratio_b_over_a"), v.get("measured_range")
        rows += (f'<tr><td>{esc(r.get("pair", "?"))}</td><td class="num mono">{"-" if pred is None else f"{pred:.2f}"}</td>'
                 f'<td class="num mono">{"-" if meas is None else (f"{meas:.3g}" + (f" <span class=fine>({rng[0]:.3g} to {rng[1]:.3g})</span>" if isinstance(rng, list) and len(rng) == 2 else ""))}</td>'
                 f'<td>{esc(status)}</td><td class="fine">{esc(v.get("why", "") or (r.get("prediction") or {}).get("note", ""))}</td></tr>')
    sm = d.get("summary") or {}
    return (f'<h4 style="margin-bottom:4px">{esc(d.get("device", "?"))} (torch {esc(d.get("torch", "?"))}, {esc(d.get("repeats", "?"))} runs per side)</h4>'
            f'<div class="scroll"><table class="lb"><thead><tr><th>Technique pair</th><th class="num">Counted ratio (B / A)</th><th class="num">Measured ratio (B / A)</th><th>Same direction?</th><th>Note</th></tr></thead><tbody>{rows}</tbody></table></div>'
            f'<p class="fine">{esc(sm.get("agrees", 0))} agree, {esc(sm.get("DISAGREES", 0))} disagree, {esc(sm.get("not measured", 0))} not measured. <a href="data/{quote(fn)}">{esc(fn)}</a></p>')


def data_files(results_dir):
    """Every file the section links to: the build copies them to data/."""
    files = [fn for fn, _c in comparison_files(results_dir)] + ladder_files(results_dir) + [fn for fn, *_ in frontier_files(results_dir)] + [fn for fn, _d in validation_files(results_dir)]
    if results_dir and os.path.isdir(results_dir):
        files += sorted(fn for fn in os.listdir(results_dir) if fn.startswith(GPU_BENCH) and fn.endswith(".json"))
    return files


def families_with_results(results_dir):
    """The systems domains that have at least one saved ladder, comparison or frontier file (so the 'kinds of speedup' overview can link them)."""
    fams = {LADDER.match(fn).group(1) for fn in ladder_files(results_dir)} | {c["family"] for _fn, c in comparison_files(results_dir)} | {fam for _fn, fam, *_ in frontier_files(results_dir)}
    return {f for f in fams if f in FAMILIES}


def _short(solver):
    """aitopo_dist3_tp4dp2.py -> tp4dp2; aimixed_mem3_bf16.py -> bf16"""
    name = solver[:-3] if solver.endswith(".py") else solver
    return re.sub(r"^[a-z0-9]+?_(?:flops|mem3|mem2|mem|par|dist3|dist)_", "", name)


def comparison_label(c):
    return f"{c['family']}: {_short(c['a'])} against {_short(c['b'])}, {METRIC_WORDS.get(c.get('metric'), c.get('metric'))}"


def exact_statement(c, roofline_cell):
    """The exact, machine-free sentence stored in the file: the machine grid (cluster ladders), the processor-count statement (span ladders), or the roofline relation (byte ladders)."""
    for key in ("distributed", "parallel"):
        block = c.get(key)
        if isinstance(block, dict) and isinstance(block.get("statement"), str):
            return block["statement"]
    return roofline_cell(c)


def domain_line(name):
    """The first sentence of a domain's declaration docstring, read as text."""
    try:
        with open(os.path.join(HERE, "domains", name, "decl.py"), encoding="utf-8") as f:
            doc = ast.get_docstring(ast.parse(f.read())) or ""
    except (OSError, SyntaxError, ValueError):
        return ""
    first = " ".join(doc.strip().split("\n\n")[0].split())
    m = re.match(r"Declaration of an? ([^:]{3,120}):\s*(.*)", first)
    kind, body = (m.group(1), m.group(2)) if m else ("", first)
    s = re.match(r"(.{20,420}?[.!?])(\s|$)", body)
    sentence = (s.group(1) if s else body[:300]).strip()
    return (kind[:1].upper() + kind[1:] + ": " if kind else "") + sentence


def _frontier_table(results_dir, fn, fam, unit, label, esc, quote):
    d = _read_json(os.path.join(results_dir, fn))
    res = d.get("results") if isinstance(d, dict) else None
    if not isinstance(res, dict) or not res:
        return ""
    techniques, sizes = [], []
    for key in res:
        t, _, s = key.partition(":")
        if t not in techniques:
            techniques.append(t)
        if s.isdigit() and int(s) not in sizes:
            sizes.append(int(s))
    sizes.sort()
    head = "".join(f'<th class="num">size {s}</th>' for s in sizes)
    rows = ""
    for t in techniques:
        cells = ""
        for s in sizes:
            r = res.get(f"{t}:{s}")
            cells += (f'<td class="num mono">{r["cleared"]}/{r["n"]} <span class="fine">({r["agree_mean"] * 100:.0f}%)</span></td>' if isinstance(r, dict) and "cleared" in r and "n" in r and "agree_mean" in r else '<td class="num mono">-</td>')
        rows += f'<tr><td class="mono">{esc(t)}</td>{cells}</tr>'
    return (f'<h4 style="margin-bottom:4px"><span class="mono">{esc(fam)}</span>: {esc(label)}</h4>'
            f'<div class="scroll"><table class="lb"><thead><tr><th>Technique</th>{head}</tr></thead><tbody>{rows}</tbody></table></div>'
            f'<p class="fine">Instances that cleared the {d.get("agreement_bar", 0.98) * 100:.0f}% agreement bar / instances run (mean agreement with the network), {d.get("n", "?")} per size and technique. '
            f'<a href="data/{quote(fn)}">{esc(fn)}</a></p>')


def systems_block(results_dir, esc, quote, cmd, roofline_cell):
    """The <details> blocks for the AI section: the head-to-head comparisons, the real-data frontiers, the domains, the ladders. Returns '' when nothing is saved."""
    comps = comparison_files(results_dir)
    fronts = frontier_files(results_dir)
    fams = sorted(families_with_results(results_dir))
    vals = validation_files(results_dir)
    if not comps and not fronts and not fams and not vals:
        return ""
    out = []
    if fams:
        rows = "".join(f'<tr><td class="mono" id="{esc(n)}">{esc(n)}</td><td class="fine">{esc(domain_line(n))}</td></tr>' for n in fams)
        out.append('<details class="more"><summary>The AI-systems domains: what each one measures</summary>'
                   '<div class="scroll"><table class="lb"><thead><tr><th>Domain</th><th>The task, from its declaration</th></tr></thead><tbody>' + rows + '</tbody></table></div>'
                   '<p class="fine">Counted, not timed: each is judged on an equivalent result fixed in advance, and each has deliberately wrong or careless solvers that its judge must reject. They are not compiled for the timed '
                   'protocol, so they have no certificate and no official round; see AI_SYSTEMS_SPEEDUPS.md in the package for what each count can and cannot say.</p></details>')
    if comps:
        rows = ""
        for fn, c in comps:
            gap = c.get("median_bits_a_below_b")
            verdict = str(c.get("verdict") or "")
            rows += (f'<tr><td>{esc(comparison_label(c))}</td><td class="num mono">{"%+.3f" % gap if isinstance(gap, (int, float)) else "none paired"}</td><td>{esc(verdict[:1].upper() + verdict[1:])}</td>'
                     f'<td class="fine">{esc(exact_statement(c, roofline_cell))}</td><td class="fine"><a href="data/{quote(fn)}">comparison file</a></td></tr>')
        out.append('<details class="more"><summary>Systems comparisons: ' + str(len(comps)) + ' head-to-head files (parallelism, clusters and topology, pipelines, memory, formats, second-order methods)</summary>'
                   '<div class="scroll"><table class="lb"><thead><tr><th>Comparison (A against B)</th><th class="num">Gap, A below B (bits)</th><th>Verdict</th><th>Exact statement, no machine needed</th><th>File</th></tr></thead><tbody>' + rows + '</tbody></table></div>'
                   '<p class="fine">Every figure and sentence is read from the saved file. A positive gap means A used less on that metric; a bit is a factor of two. The sentence in the fourth column is exact arithmetic on the saved counts: '
                   'on a simulated cluster, who is faster on each machine of a grid of latencies, bandwidths and (with a topology) inter-node slow-downs; on a span ladder, from how many processors up one is certainly faster; '
                   'on a byte ladder, the roofline relation on every device. Every record behind each file was re-executed in full when it was made, and each file can be recomputed from its three ladders. '
                   'They are practice runs on the public practice seed: not certified results, and an accounting convention, not a time.</p>'
                   + cmd("guldo tflops-compare check FILE BASELINE_LADDER A_LADDER B_LADDER") + '</details>')
    if fronts:
        tables = "".join(_frontier_table(results_dir, fn, fam, unit, label, esc, quote) for fn, fam, unit, label in fronts)
        out.append('<details class="more"><summary>Real data: which compression techniques survive on trained networks?</summary>' + tables +
                   '<p class="fine">Nothing is planted in these networks: the images are real handwritten digits and the networks are what training produced. The planted domains show techniques working on models built to be '
                   'compressible; these ask the same question of models nobody built for the purpose. Queries carry a seed-keyed noise, so a table of the network\'s answers on the clean images (the attack that a fixed public pool allows) '
                   'is rejected, and the noise scale rises with the network width because wider networks are more noise-robust. They are exact counts on practice instances, not certified results.</p></details>')
    if vals:
        out.append('<details class="more"><summary>Do the counts predict real times? A validation against this machine\'s clock</summary>' + "".join(_validation_table(fn, d, esc, quote) for fn, d in vals) +
                   '<p class="fine">For each pair, the counted ratio B / A (operations, bytes or peak memory, run under the counter on the same program shapes) is set beside the measured ratio of an independent torch implementation of the same two programs, '
                   'median of repeated runs after warm-up. "Same direction" is the only claim tested, and a disagreement is a finding about the counting convention: a count cannot see a fused kernel, and it credits a sparse product with arithmetic that real '
                   'sparse kernels do not turn into speed. Peak memory is not measured where the device has no reliable per-program peak. The topology and pipeline counters are NOT validated here: they need a real multi-device machine. '
                   'One operator, one machine, shapes fixed in advance in the script.</p>' + cmd("python3 validate_counts.py --out results/validate_counts_DEVICE.json") + '</details>')
    ladders = ladder_files(results_dir)
    gpu = sorted(fn for fn in os.listdir(results_dir) if fn.startswith(GPU_BENCH) and fn.endswith(".json")) if os.path.isdir(results_dir) else []
    if ladders or gpu:
        links = " &middot; ".join(f'<a href="data/{quote(fn)}">{esc(fn.split("_", 3)[-1].replace(".py.jsonl", ""))}</a>' for fn in ladders)
        gpu_text = (' The two GPU timings of the fused attention kernel on one Apple GPU: ' + " &middot; ".join(f'<a href="data/{quote(fn)}">{esc(fn)}</a>' for fn in gpu) +
                    '. A time on one device model is one operator\'s measurement; it says nothing about other hardware, and nothing about a CUDA device, on which these tools have not been run.') if gpu else ""
        out.append('<details class="more"><summary>The saved ladders of the AI-systems domains (' + str(len(ladders)) + ' files)</summary>'
                   '<p class="fine">Each ladder is one solver\'s exact counts on every instance; <span class="mono">verify --rerun all</span> re-executes every record and demands identical counts (the solvers and the tools ship in the installable package).</p>'
                   + cmd("guldo tflops-dist3 verify LADDER --rerun all") + f'<p class="fine">{links}.{gpu_text}</p></details>')
    return "".join(out)
