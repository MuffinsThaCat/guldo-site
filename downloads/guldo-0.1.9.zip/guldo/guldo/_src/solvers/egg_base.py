"""The egg's code with every claimed optimization switched off (the matching baseline for egg_eightaxis.py)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import egg_eightaxis  # noqa: E402


def solve(basis, bound2):
    os.environ["EGG_AXES"] = ""
    return egg_eightaxis.solve(basis, bound2)
