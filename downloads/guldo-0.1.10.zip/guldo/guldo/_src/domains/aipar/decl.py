"""Declaration of a parallelism domain: compute a long LINEAR RECURRENCE (the core of state-space and linear-attention sequence models) with as short a critical path as you can.

size = T, the sequence length; C = 16 independent channels. For each channel c:   h_t = a_t * h_{t-1} + b_t   (t = 0 .. T-1, h_{-1} = 0).
The decays a (T x C) are 0.95 + 0.049 u and the inputs b (T x C) are u, with u the SplitMix64 stream under `seed` (tensorops.stream, the same floats as domains/aiinfer: a first, then b; u in [-1, 1),
so every a lies in [0.901, 0.999) and the memory of a channel is long: a window of 8 steps is nowhere near enough). The answer is every h_t, row-major (T x C), as a flat list of T*C INTEGERS in units of
2^-30. The judge recomputes the recurrence in float64 and accepts an answer within 2e-9 in every entry. That is the "equivalent result" the saving is conditional on: a truncated memory window, a
wrong combine rule or a dropped step fails the check.

The obvious program is a loop over t: every step needs the one before, so T steps in a row however many processors there are. The recurrence is ASSOCIATIVE: composing two steps,
(a2, b2) o (a1, b1) = (a2 a1, a2 b1 + b2), gives another step of the same form, so all T prefixes can be computed by a parallel prefix scan in about 2 log2 T layers of operations. A scan does some extra work
(measured at T = 64 to 512: the Hillis-Steele scan about 1.8 times the loop's operations, the work-efficient Blelloch-style scan about 1.15 times; asymptotically log2 T and a constant), so it is slower on one processor and faster on many: how many is exactly computable.

The cost compared is the SPAN of tflops_par.py: the depth of the tensor operations (the longest chain in which each needs the one before) plus the solver's own sequential Python instructions, with the
operation count shown beside it and the processor counts at which one solver is CERTAINLY faster than another (exact bounds from the work and the span, on an idealised machine of identical processors
with no communication cost). It is an accounting convention anyone can recompute, not a thread count and not a measurement of any device.
"""
import hashlib
import hmac

import numpy as np

NAME = "aipar"
VERSION = "aipar-v1"          # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (64, 512)
SIZE_STEP = 64
REFERENCE_SOLVER = "reference.py"
CHANNELS = 16
SCALE = 2 ** 30               # the answer's integers are values of h in units of 1/SCALE
LIMIT = 2 ** 62
TOL = 2e-9                    # largest absolute error per entry the judge accepts
DOC = ("solve(seed, T, C): a (T x C) is 0.95 + 0.049 u and b (T x C) is u, where u is the SplitMix64 stream under `seed` (tensorops.stream(seed, 0, T*C) for a, then tensorops.stream(seed, T*C, T*C) for b; "
       "u in [-1, 1), row-major). For each of the C channels run h_t = a_t * h_{t-1} + b_t from h_{-1} = 0 and return every h_t, row-major (T x C), as a flat list of T*C integers in units of 2^-30, "
       "each within 2e-9 of the true value. Return None for no answer.")
REFERENCE_NOTE = ("A loop over t, one multiply-add on a vector of C channels per step: T steps in a row (depth proportional to T). Known to be beaten on span by a parallel prefix scan "
                  "(logarithmic depth), at the price of more total work.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def recurrence(seed, T, C=CHANNELS):
    """The exact h (T x C) in float64, by the sequential loop."""
    a = _uniform(seed, 0, T * C).reshape(T, C) * 0.049 + 0.95
    b = _uniform(seed, T * C, T * C).reshape(T, C)
    h, out = np.zeros(C), np.empty((T, C))
    for t in range(T):
        h = a[t] * h + b[t]
        out[t] = h
    return out


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aipar-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, CHANNELS], "planted": [int(v) for v in np.rint(recurrence(seed, size).ravel() * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, T, C = inst["args"]
    if not isinstance(ans, list) or len(ans) != T * C:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    got = np.array(ans, dtype=np.float64).reshape(T, C) / SCALE
    return bool(np.max(np.abs(got - recurrence(seed, T, C))) <= TOL)
