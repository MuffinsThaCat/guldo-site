"""A cross-problem record of verified progress, and the empirical hardness evidence it throws off.

  python3 progress_tracker.py scan CERT_DIR [--index AGENT_INDEX.json] [--out PROGRESS.json] [--md PROGRESS.md]

Reads every speed-protocol certificate (`*.cert.json`, format svp-certificate-v1) in a directory and, optionally, an agent index (agent_index.py), and writes:

  PROGRESS: per problem family, the dated list of certified claims (credit in bits, status: PROVISIONAL or official, which solver, which device, private or revealed source) and the best claim so far.
            Provisional claims (not run on official seeds) are listed but never counted as the best; the status is printed beside every number.
  HARDNESS: per family and size, from the BASELINE ladders inside the certificates: how many instances, the median baseline cost, the share that hit the budget cap, and the slope of
            log2(median cost) per size step. This is evidence about how fast the BEST KNOWN-TO-THE-BASELINE cost grows on these instances, nothing more. It is the baseline's cost, not the problem's
            hardness: a better algorithm moves it (that is the point of the whole protocol), timeouts censor the largest sizes (the slope is then a floor), and three sizes make a poor line.
  AGENTS:   from the agent index, per domain and size, the best certified solve-rate lower bound so far and who holds it (practice and scripted entries excluded).

What this is not: a ranking of solvers, a record of what is possible, or a statement that no faster algorithm exists. Every cell is a measurement by this protocol on this hardware at this date.
"""
import argparse
import glob
import json
import math
import os
import sys

import agent_core


def _ladder_records(text):
    rows = [json.loads(ln) for ln in text.split("\n") if ln.strip()]
    return (rows[0] if rows and rows[0].get("meta") else {}), [r for r in rows if not r.get("meta")]


def read_cert(path):
    with open(path, "r", encoding="utf-8") as f:
        c = json.load(f)
    if c.get("format") != "svp-certificate-v1":
        raise agent_core.AgentEvalError("%s is not an svp-certificate-v1 file" % path)
    return c


def tier_of(status):
    """'official' only for a status that says OFFICIAL; 'counted' only for exactly COUNTED (exact, re-executable operation counts); everything else, including 'COUNTED, PROVISIONAL' and any status
    this code does not know, is 'provisional'. (An earlier version treated every non-PROVISIONAL-prefixed status as official, which promoted 'COUNTED, PROVISIONAL'.)"""
    if status.startswith("OFFICIAL"):
        return "official"
    if status == "COUNTED":
        return "counted"
    return "provisional"


def claim_rows(cert, path, verification=None):
    """`verification` = None (skipped), or {"ok": bool, "failed": [check names]} from certificate.verify. A claim is only ever counted toward a best when verification passed (or was skipped by request)."""
    sub = cert.get("submission", {})
    per = [e.get("per_dim", {}) for e in cert.get("entries", []) if isinstance(e, dict)]
    devices = sorted(set(str(e.get("cpu")) for e in cert.get("entries", []) if isinstance(e, dict)))
    cl = cert.get("claim", {})
    status = str(cl.get("status", ""))
    credit = cl.get("credit_bits")
    return {"file": os.path.basename(path), "family": cert.get("family"), "created": cert.get("created"), "solver": sub.get("name"), "solver_sha256": sub.get("sha256"),
            "credit_bits": credit if isinstance(credit, (int, float)) and not isinstance(credit, bool) else None, "status": status, "tier": tier_of(status),
            "verification": verification, "private_solver": bool(cert.get("private")), "devices": devices, "per_dim_bits": per[0] if per else {}}


def verify_cert(cert):
    """Recompute the certificate with certificate.verify (nothing in it is executed). Returns {"ok", "failed"}."""
    import certificate
    r = certificate.verify(cert, log=lambda *a, **k: None)
    return {"ok": bool(r.get("ok")), "failed": [c["check"] for c in r.get("checks", []) if c.get("status") == "fail"]}


def hardness_rows(cert):
    """Baseline cost per size from the certificate's baseline ladders (one per seed)."""
    out = {}
    cap = None
    for lad in cert.get("ladders", {}).values():
        meta, recs = _ladder_records(lad["baseline"])
        cap = meta.get("budget", cap)
        for r in recs:
            e = out.setdefault(r["dim"], {"costs": [], "timeouts": 0, "n": 0})
            e["n"] += 1
            e["costs"].append(float(r.get("cpu_net", r.get("cpu", 0.0))))
            if r.get("status") == "timeout":
                e["timeouts"] += 1
    return out, cap, cert.get("family"), (cert.get("baseline") or {}).get("sha256")


def slope_bits_per_size(points):
    """Least-squares slope of log2(cost) against size; None with fewer than 2 positive points."""
    pts = [(x, math.log2(y)) for x, y in points if y and y > 0]
    if len(pts) < 2:
        return None
    mx = sum(x for x, _ in pts) / len(pts)
    my = sum(y for _, y in pts) / len(pts)
    den = sum((x - mx) ** 2 for x, _ in pts)
    return None if den == 0 else sum((x - mx) * (y - my) for x, y in pts) / den


def scan(cert_dir, index_path=None, verify=True):
    """verify=True recomputes every certificate (certificate.verify) and counts a claim toward a best only if that passes; verify=False trusts the certificates' own fields and the output says
    so. Damaged certificates are skipped and listed under `skipped`."""
    claims, hard, skipped = [], {}, []
    seen_baselines = set()
    for path in sorted(glob.glob(os.path.join(cert_dir, "*.cert.json"))):
        try:
            cert = read_cert(path)
            ver = verify_cert(cert) if verify else None
            claims.append(claim_rows(cert, path, ver))
            rows, cap, fam, bsha = hardness_rows(cert)
        except (agent_core.AgentEvalError, ValueError, KeyError, TypeError, AttributeError, IndexError, OverflowError):
            skipped.append(os.path.basename(path))
            if claims and claims[-1]["file"] == os.path.basename(path):
                claims.pop()
            continue
        key = (fam, bsha, json.dumps(sorted(cert.get("commitments", []))))
        if key in seen_baselines:
            continue           # the same baseline ladders appear in several certificates: count them once
        seen_baselines.add(key)
        for d, e in rows.items():
            h = hard.setdefault(fam, {}).setdefault(d, {"costs": [], "timeouts": 0, "n": 0, "cap": cap})
            h["costs"] += e["costs"]
            h["timeouts"] += e["timeouts"]
            h["n"] += e["n"]
    families = {}
    for c in sorted(claims, key=lambda c: (str(c["family"]), str(c["created"]))):
        f = families.setdefault(c["family"], {"claims": [], "best_official": None, "best_counted": None, "best_provisional": None})
        f["claims"].append(c)
        # a failed recomputation demotes the claim to provisional whatever its status field says
        tier = c["tier"] if (c["verification"] is None or c["verification"]["ok"]) else "provisional"
        slot = "best_" + tier
        if c["credit_bits"] is not None and (f[slot] is None or c["credit_bits"] > f[slot]["credit_bits"]):
            f[slot] = c
    hardness = {}
    for fam, dims in hard.items():
        rows = []
        for d in sorted(dims):
            e = dims[d]
            rows.append({"size": d, "instances": e["n"], "median_baseline_cost": agent_core.median(e["costs"]), "timeout_share": e["timeouts"] / float(e["n"]), "budget_cap": e["cap"]})
        hardness[fam] = {"rows": rows, "slope_log2_cost_per_size_step": slope_bits_per_size([(r["size"], r["median_baseline_cost"]) for r in rows]),
                         "caveat": "baseline cost, not problem hardness; timeouts censor the top sizes so the slope is a floor when any timeout_share > 0; few sizes make a weak line"}
    out = {"format": "guldo-progress-v1", "certificates_recomputed": bool(verify), "skipped": skipped, "families": families, "hardness": hardness, "agents": agent_progress(index_path) if index_path else None,
           "limits": ["Every number is this protocol's measurement on its hardware at its date.", "PROVISIONAL claims (not on official seeds) are listed but never counted as best.",
                      "Hardness rows describe the baseline's cost on these instances, not the problem."]}
    return out


def agent_progress(index_path):
    import agent_index
    idx = agent_index.Index.load(index_path)
    best = {}
    for e in idx.query():
        for r in e["by_size"]:
            k = (e["domain"], r["size"])
            if k not in best or r["lower95"] > best[k]["lower95"]:
                best[k] = {"domain": e["domain"], "size": r["size"], "lower95": r["lower95"], "solved": r["solved"], "instances": r["instances"], "agent": e["agent"].get("label"),
                           "median_tokens_on_solved": r["median_tokens_on_solved"], "plan_hash": e["plan_hash"]}
    return [best[k] for k in sorted(best)]


def render_md(p):
    L = ["# Verified progress record", "", "Generated by `progress_tracker.py`. Every figure is a measurement by this protocol; PROVISIONAL means not on official seeds.",
         "Certificates recomputed: %s." % ("yes (certificate.verify; a claim whose recomputation fails is demoted to provisional)" if p.get("certificates_recomputed") else "NO: the certificates' own status fields are trusted"),
         ("Skipped (damaged): %s." % ", ".join(p["skipped"])) if p.get("skipped") else "", ""]
    for fam, f in sorted(p["families"].items(), key=lambda kv: str(kv[0])):
        L += ["## %s" % fam, "", "| date | solver | credit (bits) | status | private source | device |", "|---|---|---|---|---|---|"]
        for c in f["claims"]:
            L.append("| %s | %s | %s | %s | %s | %s |" % (c["created"], c["solver"], c["credit_bits"], c["status"], "yes" if c["private_solver"] else "no", ", ".join(c["devices"])))
        L.append("")
        show = lambda c: ("%s (%s bits)" % (c["solver"], c["credit_bits"])) if c else "none yet"
        L.append("best official: %s; best counted (exact, re-executable): %s; best provisional: %s" % (show(f["best_official"]), show(f["best_counted"]), show(f["best_provisional"])))
        bad = [c["file"] for c in f["claims"] if c["verification"] is not None and not c["verification"]["ok"]]
        if bad:
            L.append("recomputation FAILED for: %s (failed checks: %s); those are listed but demoted to provisional" % (", ".join(bad), ", ".join(sorted(set(x for c in f["claims"] if c["verification"] and not c["verification"]["ok"] for x in c["verification"]["failed"])))))
        h = p["hardness"].get(fam)
        if h:
            L += ["", "Baseline cost by size (hardness evidence; %s):" % h["caveat"], "", "| size | instances | median cost (s) | share at cap |", "|---|---|---|---|"]
            for r in h["rows"]:
                L.append("| %s | %d | %.3f | %.2f |" % (r["size"], r["instances"], r["median_baseline_cost"], r["timeout_share"]))
            if h["slope_log2_cost_per_size_step"] is not None:
                L.append("")
                L.append("slope: log2(cost) grows by %.4f per unit of size (sizes are in the family's own units)" % h["slope_log2_cost_per_size_step"])
        L.append("")
    if p.get("agents"):
        L += ["## Agent evaluation", "", "| domain | size | best 95% lower bound | solved | agent | median tokens |", "|---|---|---|---|---|---|"]
        for r in p["agents"]:
            L.append("| %s | %d | %.3f | %d/%d | %s | %s |" % (r["domain"], r["size"], r["lower95"], r["solved"], r["instances"], r["agent"], r["median_tokens_on_solved"]))
        L.append("")
    L += ["## Limits", ""] + ["- " + x for x in p["limits"]]
    return "\n".join(L) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan")
    s.add_argument("cert_dir")
    s.add_argument("--index")
    s.add_argument("--out", default="PROGRESS.json")
    s.add_argument("--md")
    s.add_argument("--no-verify", action="store_true", help="trust the certificates' own status fields (default: recompute each with certificate.verify)")
    a = ap.parse_args(argv)
    p = scan(a.cert_dir, a.index, verify=not a.no_verify)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(json.dumps(p, indent=1, sort_keys=True) + "\n")
    if a.md:
        with open(a.md, "w", encoding="utf-8") as f:
            f.write(render_md(p))
    print("wrote %s (%d families)" % (a.out, len(p["families"])))


if __name__ == "__main__":
    main()
