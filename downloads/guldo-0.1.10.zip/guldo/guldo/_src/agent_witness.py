"""Independent witnesses for agent ladders: signed statements from people who checked a ladder themselves, and what a reader may count.

A witness does up to two things, with the revealed seed and their own machine:

  1. VERIFY: run the whole ladder verification (re-derive every instance, re-run every verifier, replay every tool call, recompute every proxy token count, check every hash chain) and sign the
     outcome with the digest of the ladder, the plan hash, and how many problems were found. Anyone can do this; the point is that someone OTHER than the operator did.
  2. RERUN a sample: run the SAME agent configuration themselves on a sample of instances THEY draw (the operator cannot know which), K trials each, and sign the result. This is the only check
     that tests the claim "this agent does this well" rather than "this record is consistent". `rerun_consistent` asks whether the witness's pass count is compatible with the operator's recorded
     per-trial pass rate: it is flagged inconsistent when the witness did far worse than the operator's 95% lower bound allows (one-sided exact binomial, p < 0.01). Model non-determinism, a
     different date, or a changed model version can also cause a gap: a flag means "ask", not "fraud", and is signed as a dissent either way.

  check_witnesses(ladder_digest, statements, trusted)  which statements count. Only keys in `trusted` (public keys YOU obtained out of band, as in attest.py) are counted as independent; others are
                                                       listed as unvouched. A signed statement that the ladder does NOT verify, or a rerun flagged inconsistent, makes the check fail when it comes from a key
                                                       you pinned. From a key you did not pin it cannot veto: "does not verify" blocks only until you recompute (`own_problems`) and is
                                                       refuted if you find nothing; a rerun flag is listed and does not block (a key costs nothing, so a free veto would let anyone freeze a ladder).

Same honesty as attest.py: a key proves "the same party signed these", never "this party is independent of the operator"; the machine description is self-reported; and a witness who reruns a model
is paying real API money and trusting the same provider as the operator.
"""
import time

import agent_compare
import agent_core
import agent_domains_plus                                                            # noqa: F401  this module loads a ladder's domain by name: the extra domains must be registered
import agent_sig

FORMAT = "guldo-agent-witness-v1"
INCONSISTENT_P = 0.01


def trial_pass_stats(header, records, instances=None):
    """(passed, trials) over the given set of (size, idx) instances (all of them by default)."""
    k = n = 0
    for r in records:
        if instances is None or (r["size"], r["idx"]) in instances:
            n += 1
            k += 1 if r["solved"] else 0
    return k, n


def draw_sample(header, m, material):
    """The witness's own random draw of m planned instances; `material` is bytes only the witness knows (never reused)."""
    keys = [(s, i) for s in header["sizes"] for i in range(header["n_per_size"])]
    if not 1 <= m <= len(keys):
        raise agent_core.AgentEvalError("sample size must be between 1 and %d" % len(keys))
    rng = agent_core.Rng(agent_core.sha256_hex(b"witness-sample|" + material).encode("ascii"))
    return sorted(rng.sample(keys, m))


def run_sample(header, master, sample, agent, progress=None):
    """Run `agent` on the sampled (size, idx) instances with the ladder's own system prompt, tool list and caps, `header['trials']` trials each. Returns the witness's trial records. The witness
    runs the agent on THEIR machine with THEIR key: nothing the operator holds is involved."""
    import agent_harness
    if header.get("mode"):
        raise agent_core.AgentEvalError("a black-box ladder cannot be rerun through this harness: its agent is the vendor's, and running another agent under the vendor's caps would compare different things. "
                                        "Verify it, or run your own round with `agent_service.py serve-arm` and your own seed (`agent_verifier.py quorum`)")
    mod = agent_core.load_domain(header["domain"])
    out = []
    for (s, i) in sample:
        inst = agent_core.make_instance(mod, master, s, i)
        for t in range(header["trials"]):
            rec = agent_harness.run_trial(agent, mod, inst, header["budget"], t, header.get("allow_tools"), header.get("system", agent_harness.SYSTEM))
            out.append(rec)
            if progress:
                progress(rec)
    return out


def witness_rerun(header, records, master, m, material, agent, secret, problems=(), note="", progress=None, now=None):
    """The whole witness path in one call: draw the witness's OWN secret sample (the operator cannot know which instances), run the agent on it, test the witness's pass count against the operator's
    recorded rate, and sign the result. Returns (signed statement, witness records, rerun block)."""
    sample = draw_sample(header, m, material)
    wrecs = run_sample(header, master, sample, agent, progress)
    block = rerun_block(header, records, sample, wrecs, material)
    return make_statement(header, records, list(problems), secret, rerun=block, note=note, now=now), wrecs, block


def rerun_consistent(operator_k, operator_n, witness_k, witness_n):
    """(consistent, p, bound). Is the witness's pass count compatible with the operator's recorded pass rate (via its one-sided 95% lower bound)?
    Both counts are TRIAL counts and the test treats trials as independent, which they are not (an instance an agent finds hard is hard every time). Checked by simulation in the audit (40
    instances with per-instance solve probabilities drawn from {0.1, 0.5, 0.95, 0.99}, 3 trials each, a witness rerunning 10): an honest witness was flagged 1.0% of the time against the nominal 1%,
    because the operator's lower bound is itself conservative. That is one setting, not a proof; read a flag as "ask", not "fraud"."""
    if operator_n <= 0 or witness_n <= 0:
        raise agent_core.AgentEvalError("empty counts")
    bound = agent_core.cp_lower(operator_k, operator_n)
    p = agent_core.binom_lower_tail(witness_k, witness_n, bound)
    return p >= INCONSISTENT_P, p, bound


def make_statement(header, records, problems, secret, rerun=None, note="", now=None):
    st = {"format": FORMAT, "ladder_digest": agent_compare.ladder_digest(header, records), "plan_hash": header["plan_hash"], "agent": header.get("agent", {}).get("label"),
          "domain": header["domain"], "verified": not problems, "n_problems": len(problems), "problems_first": [str(p)[:200] for p in problems[:5]], "rerun": rerun,
          "at": now or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "note": note[:300], "machine_self_reported": True}
    return agent_sig.sign_statement(st, secret)


def rerun_block(header, records, sample, witness_records, material):
    """Summarise a witness's own rerun against the operator's records on the same sampled instances. witness_records are the witness's ladder records for exactly those instances."""
    ok_n = [(r["size"], r["idx"]) for r in witness_records]
    if set(ok_n) != set(sample):
        raise agent_core.AgentEvalError("the witness records do not cover exactly the sampled instances")
    ok, p, bound = rerun_consistent(*trial_pass_stats(header, records), *trial_pass_stats(header, witness_records))
    wk, wn = trial_pass_stats(header, witness_records)
    return {"sample": [list(x) for x in sample], "witness_passed": wk, "witness_trials": wn, "operator_pass_rate_lower95": round(bound, 6), "p_witness_this_low": round(p, 8),
            "consistent": ok, "sample_material_sha256": agent_core.sha256_hex(material)}


def check_witnesses(ladder_digest, statements, trusted=None, min_independent=1, own_problems=None):
    """Returns {ok, independent, unvouched, dissent, unvouched_dissent, lines}. ok needs >= min_independent distinct trusted keys that signed a passing statement about THIS ladder, and no
    blocking dissent. Who can block:

      * DISSENT FROM A KEY YOU PINNED blocks, as before (you chose to trust that witness).
      * DISSENT FROM A KEY YOU DID NOT PIN no longer blocks by itself: a key costs nothing, so letting any key veto a ladder would let anyone freeze it. What such a statement CLAIMS is, for "this ladder does
        not verify", checkable: pass `own_problems` (the list of problems from running the ladder verification yourself, [] if there were none). Then an unvouched "does not verify" is REFUTED when
        your own check found nothing (listed, not blocking) and CONFIRMED when it found something (you already fail). Without `own_problems` it blocks until you recompute (the line says so). An unvouched
        rerun-inconsistency flag cannot be checked without paying to run the model: it is listed and does not block."""
    trusted = set(trusted or [])
    good, unvouched, dissent, lines = set(), set(), [], []
    unvouched_dissent = []
    for s in statements:
        if not agent_sig.statement_ok(s):
            lines.append("FAIL: a statement has a bad signature (ignored)")
            continue
        st = s["statement"]
        try:
            if st.get("format") != FORMAT or st.get("ladder_digest") != ladder_digest:
                lines.append("FAIL: a statement from %s... is about a different ladder (ignored)" % st.get("pubkey", "")[:12])
                continue
            rr = st.get("rerun")
            # anything that is not a plainly passing statement is a dissent: a malformed 'rerun' block must not read as "no rerun"
            bad = (st.get("verified") is not True) or (rr is not None and not (isinstance(rr, dict) and rr.get("consistent") is True))
            if bad:
                desc = "verified=%s, rerun consistent=%s, problems: %s" % (st.get("verified"), rr.get("consistent") if isinstance(rr, dict) else rr,
                                                                           "; ".join(str(x) for x in st.get("problems_first", []) if isinstance(x, str))[:300])
                if st["pubkey"] in trusted:
                    dissent.append(st["pubkey"])
                    lines.append("DISSENT from %s... (a key you pinned; blocks): %s" % (st["pubkey"][:12], desc))
                    continue
                claims_unverifiable = st.get("verified") is not True            # "this ladder does not verify" (or malformed): something the caller can recompute
                if not claims_unverifiable:
                    unvouched_dissent.append(st["pubkey"])
                    lines.append("DISSENT from %s... (a key you did not pin; a rerun-consistency flag cannot be checked without running the model: listed, does not block): %s" % (st["pubkey"][:12], desc))
                elif own_problems is None:
                    dissent.append(st["pubkey"])
                    lines.append("DISSENT from %s... (a key you did not pin) says the ladder does not verify: it blocks until you recompute (pass your own verification result) - %s" % (st["pubkey"][:12], desc))
                elif not own_problems:
                    unvouched_dissent.append(st["pubkey"])
                    lines.append("REFUTED: %s... (a key you did not pin) says the ladder does not verify, but your own verification found no problems: listed, does not block" % st["pubkey"][:12])
                else:
                    dissent.append(st["pubkey"])
                    lines.append("CONFIRMED by your own verification (%d problem(s)): %s... says the ladder does not verify" % (len(own_problems), st["pubkey"][:12]))
                continue
            (good if st["pubkey"] in trusted else unvouched).add(st["pubkey"])
        except (TypeError, AttributeError, KeyError):
            lines.append("FAIL: a signed statement is malformed (ignored)")
    if unvouched:
        lines.append("%d passing statement(s) from keys you did not pin: reported, NOT counted as independent" % len(unvouched))
    ok = len(good) >= min_independent and not dissent
    lines.append("%s: %d independent witness(es) (%d needed), %d dissent" % ("OK" if ok else "NOT ENOUGH", len(good), min_independent, len(dissent)))
    return {"ok": ok, "independent": sorted(good), "unvouched": sorted(unvouched), "dissent": sorted(dissent), "unvouched_dissent": sorted(unvouched_dissent), "lines": lines}
