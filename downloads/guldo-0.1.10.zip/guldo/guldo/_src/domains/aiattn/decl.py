"""Declaration of an AI-attention domain: causal sliding-window attention over one head, as cheaply as you can, to the same output.

size = n, the sequence length. Q, K and V are n x 16 matrices, a pure function of one seed through the pinned SplitMix64 stream the other AI domains use (layout in reference.py), so a
counted solver regenerates them with tensorops.stream and the instance stays a few bytes. Position i attends to the positions j with i - 32 < j <= i (the 32 most recent positions,
itself included) with softmax weights of q_i . k_j / 4: that is the model's definition, a "sliding-window" attention as in Longformer or Mistral, not a pruning of a dense one.

The reference is the unoptimised way to run it: build the whole n x n score matrix, add the window mask, softmax every row, multiply by V. The window means only about 32 of the n
columns of each row can matter, so a solver that computes just the band (one block of 32 queries against the 64 keys that can reach it) does the same arithmetic on a fraction of the
data and its saving grows with n. A solver that only drops the upper triangle (causal skipping) gets about a factor of two. The speedup is in OPERATIONS, so the counted mode
(tflops.py) certifies it on any machine; memory traffic and the peak size of the score matrix show up under tflops_mem.py (the banded solver never holds an n x n matrix).

The answer is the n x 16 output matrix as a flat list of n*16 INTEGERS, row-major, in units of 2^-16. The judge recomputes the float64 output and accepts iff every entry is within
TOL (1e-3) of it. A solver that attends to fewer keys than the window (only its own block, say) changes the softmax and fails the check; one that computes the right band cannot.
That is the "equivalent output" the saving is conditional on. What this cannot show: a fused kernel that does the same arithmetic in less time (FlashAttention's real gain is memory
traffic and kernel quality, which an operation count does not see; the bytes and peak accounting of tflops_mem.py sees only the data the solver names).
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aiattn"
VERSION = "aiattn-v1"         # bump whenever derive() or the model definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (512, 2048)      # below ~512 the dense reference costs under the estimator's 0.5 s floor (5e6 operations)
SIZE_STEP = 256
REFERENCE_SOLVER = "reference.py"
D = 16                        # head dimension
WINDOW = 32                   # position i sees j in (i - WINDOW, i]
QK_SCALE = 3.0                # q and k are scaled so the attention is peaked, not near-uniform (with unit scale a mean over the window would pass for it)
SCALE = 2 ** 16               # the answer's integers are outputs in units of 1/SCALE
TOL = 1e-3
LIMIT = 2 ** 40
DOC = ("solve(seed, n): Q, K, V are n x 16 matrices from the SplitMix64 stream under `seed` (Q = QK_SCALE * stream[0 : n*16], K = QK_SCALE * stream[n*16 : 2*n*16], "
       "V = stream[2*n*16 : 3*n*16], all with tensorops.stream, QK_SCALE = 3; layout in domains/aiattn/reference.py). Row i of the output is softmax over j in (i-32, i] of "
       "q_i . k_j / 4, applied to the rows v_j. Return the n x 16 output matrix as a flat list of n*16 integers, row-major, in units of 2^-16; every entry must be within 1e-3 "
       "of the exact value. Return None for no answer.")
REFERENCE_NOTE = ("Dense: the full n x n score matrix, the window mask added to it, a softmax over every row, then the product with V, in float64. Known to be beaten by computing "
                  "only the band (blocks of 32 queries against the 64 keys that can reach them): about n/64 times fewer operations, so the saving grows with n.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _qkv(seed, n):
    m = n * D
    Q = (_uniform(seed, 0, m) * QK_SCALE).reshape(n, D)
    K = (_uniform(seed, m, m) * QK_SCALE).reshape(n, D)
    V = _uniform(seed, 2 * m, m).reshape(n, D)
    return Q, K, V


def _truth(seed, n):
    """The exact output, float64, computed band by band (the judge's definition of the model)."""
    Q, K, V = _qkv(seed, n)
    out = np.zeros((n, D))
    for i in range(n):
        lo = max(0, i - WINDOW + 1)
        s = K[lo:i + 1] @ Q[i] / math.sqrt(D)
        s -= s.max()
        a = np.exp(s)
        out[i] = (a / a.sum()) @ V[lo:i + 1]
    return out


_CACHE = {}


def _cached_truth(seed, n):
    key = (seed, n)
    if key not in _CACHE:
        if len(_CACHE) >= 4:
            _CACHE.clear()
        _CACHE[key] = _truth(seed, n)
    return _CACHE[key]


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aiattn-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    return {"args": [seed, size], "planted": [int(v) for v in np.rint(_cached_truth(seed, size) * SCALE).ravel()]}


def verify(inst: dict, ans) -> bool:
    seed, n = inst["args"]
    if not isinstance(ans, list) or len(ans) != n * D:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    got = np.array(ans, dtype=np.float64).reshape(n, D) / SCALE
    return bool(np.max(np.abs(got - _cached_truth(seed, n))) <= TOL)
