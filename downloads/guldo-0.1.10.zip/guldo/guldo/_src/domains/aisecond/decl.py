"""Declaration of a second-order-optimisation domain: minimise a CORRELATED-feature logistic-regression loss to within 1e-8 of its exact minimum, using as few operations as you can.

size = d, the number of features. The training set holds N = 16 d points. Feature j is an exponentially smoothed sum of the first j+1 independent uniform columns Z (the SplitMix64
stream that `aiinfer` and `aitrain` use):  X[i][j] = sqrt(1 - 0.97^2) * sum_{k <= j} 0.97^(j-k) * Z[i][k].  The columns are strongly CORRELATED, which rescaling each feature cannot undo
(rescaling is diagonal; the correlation is not), so the Hessian of the loss is ill-conditioned along directions that no per-feature step size fixes. Gradient descent crawls down those
directions; a method that uses curvature (Newton, Newton-CG, a quasi-Newton method) does not. That gap is what this domain exists to measure.

The labels are noisy (y = 1 with probability sigmoid(2 x . w*) for a hidden w* nobody needs), so the data are not separable and the loss has a finite minimiser. The loss is
    L(w) = (1/N) sum_i log(1 + exp(-(2 y_i - 1) x_i . w)) + (LAMBDA / 2) |w|^2,         LAMBDA = 1e-4,
strictly convex, fully determined by the instance's arguments: nothing is hidden, so there is no held-out set and nothing to overfit. The judge computes the exact minimiser L* itself
(damped Newton in float64) and accepts an answer w iff  L(w) - L* <= EPS = 1e-8. That is the "equivalent result" the saving is conditional on: stopping early or taking a loose step fails
the check; solving it more precisely than needed only costs operations.

The answer is the d weights as a flat list of d INTEGERS in units of 2^-20 (the counted and timed runners accept only integers; a rounding error of 5e-7 per weight moves the loss by
about 1e-11). The cost is counted operations (tflops.py): the arithmetic the optimisation asked for, exactly reproducible, not a time. It cannot see memory traffic, kernel quality or GPU speed.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aisecond"
VERSION = "aisecond-v1"       # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 40)
SIZE_STEP = 8
REFERENCE_SOLVER = "reference.py"
RHO = 0.97                    # smoothing of the feature columns: the source of the correlation
LAMBDA = 1e-4                 # L2 regularisation: makes the loss strictly convex
N_PER_D = 16                  # training points per feature
EPS = 1e-8                    # the largest loss gap L(w) - L* the judge accepts
SCALE = 2 ** 20               # the answer's integers are weights in units of 1/SCALE
LIMIT = 2 ** 62               # no weight integer may exceed this in size
DOC = ("solve(seed, d, N, labels): the N = 16 d features are X[i][j] = sqrt(1-0.97^2) * sum_{k<=j} 0.97^(j-k) * Z[i][k] where Z[i][k] is the (i*d+k)-th float of the SplitMix64 stream under "
       "`seed` (tensorops.stream(seed, 0, N*d), the same floats as domains/aiinfer); labels is the list of N classes (ints 0 or 1). Return the d weights of the L2-regularised logistic "
       "regression L(w) = mean_i log(1+exp(-(2y_i-1) x_i.w)) + 0.5e-4 |w|^2 as a flat list of d integers in units of 2^-20, whose loss is within 1e-8 of the exact minimum. "
       "Return None for no answer.")
REFERENCE_NOTE = ("Plain full-batch gradient descent with the safe step 1/L, L = |X|_F^2 / (4N) + lambda (an upper bound on the largest curvature), 35000 steps. The slowest of "
                  "150 calibration instances (30 at each size 16, 24, 32, 40, 48) at sizes up to 40 needed 27400 steps to reach the target, so 35000 passes with margin (size 48 needed 38800 and is outside the range). Known to be beaten by momentum (the square root of the condition number in steps) and by "
                  "Newton, Newton-CG and quasi-Newton methods, which use the curvature the correlated features create.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _mixing(d):
    """U[k][j] = RHO^(j-k) for k <= j, else 0 (so X = sqrt(1-RHO^2) * Z @ U)."""
    k = np.arange(d)
    return np.triu(RHO ** np.clip(k[None, :] - k[:, None], 0, None))


def _features(seed, d, n):
    return (_uniform(seed, 0, n * d).reshape(n, d) @ _mixing(d)) * math.sqrt(1.0 - RHO * RHO)


def _seed(master, tag, size, idx):
    return int.from_bytes(hmac.new(master, f"aisecond-v1:{tag}:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def loss(X, y, w):
    return float(np.mean(np.logaddexp(0.0, -(2.0 * y - 1.0) * (X @ w))) + 0.5 * LAMBDA * (w @ w))


def minimiser(X, y):
    """The exact minimiser: damped Newton in float64 (the Hessian is positive definite because LAMBDA > 0). -> (w, L*)."""
    n, d = X.shape
    w = np.zeros(d)
    cur = loss(X, y, w)
    for _ in range(100):
        p = 1.0 / (1.0 + np.exp(-(X @ w)))
        g = X.T @ (p - y) / n + LAMBDA * w
        H = (X.T * (p * (1.0 - p))) @ X / n + LAMBDA * np.eye(d)
        step = np.linalg.solve(H, g)
        t = 1.0
        while t > 1e-12:
            nxt = loss(X, y, w - t * step)
            if nxt <= cur:
                break
            t *= 0.5
        w, done = w - t * step, cur - nxt < 1e-16
        cur = min(cur, nxt)
        if done and np.linalg.norm(g) < 1e-9:
            break
    return w, loss(X, y, w)


def derive(master: bytes, size: int, idx: int) -> dict:
    d = size
    n = N_PER_D * d
    seed, wseed, lseed = (_seed(master, t, size, idx) for t in ("train", "teacher", "noise"))
    X = _features(seed, d, n)
    wstar = _uniform(wseed, 0, d) * 3.0 / math.sqrt(d)
    y = ((_uniform(lseed, 0, n) + 1.0) / 2.0 < 1.0 / (1.0 + np.exp(-2.0 * (X @ wstar)))).astype(np.int64)
    w, _ = minimiser(X, y.astype(np.float64))
    return {"args": [seed, d, n, [int(v) for v in y]], "planted": [int(v) for v in np.rint(w * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, d, n, labels = inst["args"]
    if not isinstance(ans, list) or len(ans) != d:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    X, y = _features(seed, d, n), np.asarray(labels, dtype=np.float64)
    _, best = minimiser(X, y)
    return bool(loss(X, y, np.array(ans, dtype=np.float64) / SCALE) - best <= EPS)
