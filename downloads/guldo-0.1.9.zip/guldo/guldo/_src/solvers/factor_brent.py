"""Factoring submission: Brent's variant of Pollard's rho with BATCHED gcds (one gcd per `batch` steps, on a running product).
Same asymptotics as the baseline (about sqrt of the smaller factor); the gain is a constant factor from fewer gcds and fewer
multiplications per step. Deterministic."""
from math import gcd


def solve(n, batch=128):
    if n % 2 == 0:
        return 2
    c = 1
    while True:
        y, r, q, g = 2, 1, 1, 1
        x = ys = 2
        while g == 1:
            x = y
            for _ in range(r):
                y = (y * y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(batch, r - k)):
                    y = (y * y + c) % n
                    q = q * abs(x - y) % n
                g = gcd(q, n)
                k += batch
            r *= 2
        if g == n:  # the batch overshot: redo it one step at a time
            g = 1
            while g == 1:
                ys = (ys * ys + c) % n
                g = gcd(abs(x - ys), n)
        if g != n:
            return g
        c += 1
