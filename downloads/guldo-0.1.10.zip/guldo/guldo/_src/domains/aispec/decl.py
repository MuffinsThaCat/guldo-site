"""Declaration of an AI speculative-decoding domain: greedy generation from a small language model, token for token correct, with as few BYTES moved as you can.

size = T, the number of tokens to generate after a 1-token prompt. The model is the one of `aiquant` (vocabulary 64, width 128, hidden 1024, tied output embedding, learned positions, one residual ReLU
block; every new token depends on the previous one) with one difference that makes a speculative decoder possible: the two big matrices are LOW-RANK PLUS NOISE, W = c A B + 0.15 N with A, B of rank 8 and
N a full noise matrix, all from the pinned SplitMix64 stream (layout in reference.py). The rank-8 part alone, c A B, is a cheap DRAFT model: it is not given as a separate model, the solver builds it from the
same stream, and (measured over 8 instances) it agrees with the full model's argmax on about nine tokens in ten, so a round of 4 drafted tokens yields about 3.5.

The reference decodes one token per step, every step reading both full matrices (2 x 128 x 1024 values). Speculative decoding drafts k tokens with the cheap factors, then has the full model check all k in ONE
batched pass that reads the matrices once, keeps the longest prefix on which the two agree, and takes the full model's own token after it: the output is exactly the full model's greedy output, but the
big matrices are read once per round instead of once per token. That is a saving in BYTES (the regime where a model is memory-bound), not in operations: the verify pass does extra arithmetic, so the
operation count goes UP. This is the point of the domain: only tflops_mem.py's bytes (tflops_compare.py --metric bytes) can see it, and an operation count would call it a slowdown.

Verification is TEACHER-FORCED, as in aiquant: the judge runs the full float64 model once, in parallel, over the prompt and the submitted tokens, and accepts iff every submitted token's logit is within
TOL_SIGMA (0.05) standard deviations of the best logit at its position. A correct speculative decoder passes (it IS the full model's output); the draft model's own tokens, which are cheaper still, fail at
the positions where the two models disagree.

What this cannot show: latency. Real speculative decoding wins by turning many sequential memory-bound steps into fewer; this accounting counts the bytes those steps move, under a convention with no cache and no
fusion. It certifies "N times fewer bytes under these rules", not "N times faster"; and the acceptance rate here is a property of this synthetic model pair, not of any real one.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aispec"
VERSION = "aispec-v1"         # bump whenever derive() or the model definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (64, 384)
SIZE_STEP = 64
REFERENCE_SOLVER = "reference.py"
V, D, H, R = 64, 128, 1024, 8
W_SCALE, POS_SCALE = 4.0, 3.0
DELTA = 0.15                  # the noise on top of the low-rank part: sets how often the draft agrees with the full model
TOL_SIGMA = 0.05
DOC = ("solve(seed, T): rebuild the model from `seed` (SplitMix64 stream via tensorops.stream, layout in domains/aispec/reference.py): embeddings E (64 x 128), positions, low-rank factors "
       "A1 (128 x 8), B1 (8 x 1024), A2 (1024 x 8), B2 (8 x 128) and noise N1 (128 x 1024), N2 (1024 x 128). The full model has W1 = c1 A1 B1 + 0.15 N1 and W2 = c2 A2 B2 + 0.15 N2; step t "
       "(from the 1-token prompt): x = E[prev] + pos[t]; y = x + relu(rms(x) W1) W2; logits = rms(y) E^T; the token is the argmax. Generate T tokens greedily and return their ids; every one "
       "must be, at its position, within 0.05 standard deviations of the best logit of the FULL model given your own earlier tokens. Return None for no answer.")
REFERENCE_NOTE = ("Full model, float64, one token per step: every step reads both big matrices. Known to be beaten, on bytes, by speculative decoding: draft k tokens with the rank-8 factors, verify "
                  "all k in one batched pass that reads the full matrices once, keep the agreeing prefix. The output is identical; the saving is the average tokens accepted per round, roughly 2 to 3 times.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _params(seed, T):
    o = [0]

    def take(shape, scale):
        n = int(np.prod(shape))
        a = (_uniform(seed, o[0], n) * scale).reshape(shape)
        o[0] += n
        return a
    P = {"E": take((V, D), math.sqrt(3.0)), "pos": take((T, D), POS_SCALE * math.sqrt(3.0))}
    A1, B1, A2, B2 = take((D, R), 1.0), take((R, H), 1.0), take((H, R), 1.0), take((R, D), 1.0)
    N1, N2 = take((D, H), W_SCALE / math.sqrt(D)), take((H, D), W_SCALE / math.sqrt(H))
    c1, c2 = W_SCALE / math.sqrt(D) * 3.0 / math.sqrt(R), W_SCALE / math.sqrt(H) * 3.0 / math.sqrt(R)
    P["W1"], P["W2"] = c1 * (A1 @ B1) + DELTA * N1, c2 * (A2 @ B2) + DELTA * N2
    P["first"] = min(int((_uniform(seed, o[0], 1)[0] + 1.0) * 0.5 * V), V - 1)
    return P


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def _logits(P, toks):
    """Logits at every position at once: toks[t] is the INPUT token of position t. The judge's definition of the full model."""
    x = P["E"][toks] + P["pos"][:len(toks)]
    y = x + np.maximum(_rms(x) @ P["W1"], 0.0) @ P["W2"]
    return _rms(y) @ P["E"].T


def _greedy(P, T):
    toks, out = [P["first"]], []
    for t in range(T):
        tok = int(np.argmax(_logits(P, toks)[t]))
        out.append(tok)
        toks.append(tok)
    return out


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aispec-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    return {"args": [seed, size], "planted": _greedy(_params(seed, size), size)}


def verify(inst: dict, ans) -> bool:
    seed, T = inst["args"]
    if not isinstance(ans, list) or len(ans) != T:
        return False
    if any(isinstance(c, bool) or not isinstance(c, int) or not 0 <= c < V for c in ans):
        return False
    P = _params(seed, T)
    L = _logits(P, [P["first"]] + [int(c) for c in ans[:-1]])
    tol = TOL_SIGMA * float(L.std())
    return bool(np.all(L[np.arange(T), np.asarray(ans)] >= L.max(axis=1) - tol))
