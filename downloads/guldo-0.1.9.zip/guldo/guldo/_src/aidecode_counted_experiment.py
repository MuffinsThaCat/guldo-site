"""Judge the pre-registered counted-operations experiment (results/PREREGISTERED_aidecode_counted.txt) mechanically, with no reinterpretation.

  python3 aidecode_counted_experiment.py [--seed SEEDFILE]    each criterion as PASS / FAIL / PENDING, and the numbers behind it

Reads only saved files: the committed plan, the four ladders (the reference, then the KV-cache solver, the lossy solver and the reference again, each against the one reference
ladder) and the estimator's claim file next to each submission ladder. It also re-hashes every file the registration pins and says so if any changed since, because a result
measured with different code is not the registered experiment. With --seed it re-executes EVERY record of every ladder (a full audit) and demands identical counts; without it
that criterion is PENDING, never assumed.

Definitions fixed here, in code, before any ladder existed: the credit is extrapolate.py's difficulty-stratified lower bound (its claim file); the operation ratio at a size is the
median baseline cost over the median submission cost on that size's solved instances; a ladder "matches the plan" exactly as tflops.check_plan defines it.
"""
import hashlib
import json
import math
import os
import re
import statistics
import sys

import tflops

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(HERE, "results")
PREREG, PLAN = "PREREGISTERED_aidecode_counted.txt", "PLAN_aidecode_counted.json"
BASELINE = "aidecode_flops_ref"
SUBS = {"kv": "aidecode_flops_kv", "lossy": "aidecode_flops_lossy", "self": BASELINE}
KV_MIN_CREDIT = 4.0               # bits
KV_RATIO_RANGE = (15.0, 60.0)     # operations saved at every size
SELF_MAX_CREDIT = 0.1             # bits


def _read(name):
    with open(os.path.join(RESULTS, name), encoding="utf-8") as f:
        return f.read()


def registered():
    text = _read(PREREG)
    plan_hash = re.search(r"^plan hash: ([0-9a-f]{64})$", text, re.M).group(1)
    pins = re.findall(r"^([0-9a-f]{64})  (\S+)$", text, re.M)
    return plan_hash, pins


def code_changed(pins):
    bad = []
    for want, rel in pins:
        p = os.path.join(HERE, rel)
        got = hashlib.sha256(open(p, "rb").read()).hexdigest() if os.path.exists(p) else None
        if got != want:
            bad.append(rel)
    return bad


def ladder_path(tag, role, name):
    return os.path.join(RESULTS, f"tflops_aidecode_{tag}_{role}_{name}.py.jsonl")


def claim(path):
    p = path + ".claim.json"
    if not os.path.exists(p):
        return "missing"
    with open(p, encoding="utf-8") as f:
        return json.load(f)["measured"]          # None = inconclusive


def ratios(base_recs, sub_recs):
    by = {}
    for role, recs in (("b", base_recs), ("s", sub_recs)):
        for r in recs:
            if r.get("status") == "solved":
                by.setdefault(r["dim"], {}).setdefault(role, []).append(r["cpu_net"])
    return {d: statistics.median(v["b"]) / statistics.median(v["s"]) for d, v in sorted(by.items()) if "b" in v and "s" in v}


def judge(seed_path=None):
    out = []
    plan_hash, pins = registered()
    changed = code_changed(pins)
    out.append({"criterion": "code unchanged", "status": "fail" if changed else "pass",
                "detail": ("changed since registration: " + ", ".join(changed)) if changed else f"all {len(pins)} pinned files still hash as registered"})
    plan = json.load(open(os.path.join(RESULTS, PLAN), encoding="utf-8"))
    tag = plan["commit"][:8]
    paths = {"base": ladder_path(tag, "baseline", BASELINE), **{k: ladder_path(tag, "submission", v) for k, v in SUBS.items()}}
    if not all(os.path.exists(p) for p in paths.values()):
        out.append({"criterion": "all ladders exist", "status": "pending", "detail": "missing: " + ", ".join(k for k, p in paths.items() if not os.path.exists(p))})
        return out
    recs = {k: tflops.read_ladder(p) for k, p in paths.items()}
    # P1: every ladder is exactly the committed plan
    probs = {k: tflops.check_plan(plan, recs[k][0] or {}, recs[k][1], plan_hash) for k in recs}
    out.append({"criterion": "P1: every ladder is exactly the committed plan (and the plan file hashes to the registered value)", "status": "pass" if not any(probs.values()) else "fail",
                "detail": "all four match" if not any(probs.values()) else "; ".join(f"{k}: {v[0]}" for k, v in probs.items() if v)})
    solved = lambda k: sum(r["status"] == "solved" for r in recs[k][1])
    wrong = lambda k: sum(r["status"] == "wrong" for r in recs[k][1])
    total = len(recs["base"][1])
    # K1-K3: the KV-cache solver
    out.append({"criterion": "K1: the KV-cache solver answers every question correctly", "status": "pass" if solved("kv") == total else "fail", "detail": f"{solved('kv')}/{len(recs['kv'][1])} solved, {wrong('kv')} wrong"})
    c = claim(paths["kv"])
    out.append({"criterion": f"K2: its credit is at least {KV_MIN_CREDIT} bits", "status": "pass" if isinstance(c, float) and c >= KV_MIN_CREDIT else "fail",
                "detail": f"credit {c if not isinstance(c, float) else round(c, 2)}"})
    rt = ratios(recs["base"][1], recs["kv"][1])
    ok = bool(rt) and all(KV_RATIO_RANGE[0] <= v <= KV_RATIO_RANGE[1] for v in rt.values())
    out.append({"criterion": f"K3: operations saved are within {KV_RATIO_RANGE[0]:g}x to {KV_RATIO_RANGE[1]:g}x at every size", "status": "pass" if ok else "fail",
                "detail": ", ".join(f"{v:.1f}x at {d}" for d, v in rt.items()) or "no size had both solved"})
    # L1: the lossy solver earns nothing
    c = claim(paths["lossy"])
    out.append({"criterion": "L1: the lossy solver solves nothing and earns exactly 0 bits", "status": "pass" if solved("lossy") == 0 and c == 0.0 else "fail",
                "detail": f"{solved('lossy')} solved, {wrong('lossy')} wrong, credit {c}"})
    # R1: the reference against itself earns about nothing
    c = claim(paths["self"])
    out.append({"criterion": f"R1: the reference against itself solves everything and earns at most {SELF_MAX_CREDIT} bits", "status": "pass" if solved("self") == total and isinstance(c, float) and c <= SELF_MAX_CREDIT else "fail",
                "detail": f"{solved('self')}/{len(recs['self'][1])} solved, credit {c}"})
    # V1: a full re-execution of every record of every ladder
    if seed_path is None:
        out.append({"criterion": "V1: every record of every ladder re-executes with identical status, flops and steps", "status": "pending", "detail": "run with --seed SEEDFILE (the seed is not kept in the tree)"})
    else:
        master = open(seed_path, "rb").read().strip()
        res = {k: tflops.verify_ladder(paths[k], rerun="all", master=master) for k in paths}
        out.append({"criterion": "V1: every record of every ladder re-executes with identical status, flops and steps", "status": "pass" if all(v[0] for v in res.values()) else "fail",
                    "detail": "; ".join(f"{k}: {'ok' if v[0] else 'FAILED'}" for k, v in res.items())})
    return out


def overall(res):
    st = {r["status"] for r in res}
    return "FAIL" if "fail" in st else "PENDING" if "pending" in st else "PASS"


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    seed = argv[argv.index("--seed") + 1] if "--seed" in argv else None
    res = judge(seed)
    for r in res:
        print(f"  {r['status'].upper():7s} {r['criterion']}: {r['detail']}")
    print(f"\noverall: {overall(res)}")
    sys.exit(0 if overall(res) == "PASS" else 1)


if __name__ == "__main__":
    main()
