"""Declaration of an AI-inference domain: classify a committed batch with a committed 3-layer ReLU MLP, as fast as you can, at equivalent accuracy.

size = d, the hidden width; the batch holds `size` inputs of dimension d. The model (W1 d x d, W2 d x d, W3 10 x d, no biases) and the batch are NOT
shipped as data: they are a pure function of one 63-bit seed through a pinned integer hash stream (SplitMix64, below), so a solver regenerates the
exact same floats with numpy alone and the instance stays a few bytes. Regenerating the model stands in for loading it from disk; that cost is
shared by the reference and every submission.

The answer is the list of `size` class labels. Judge-side, the verifier recomputes the float64 logits and accepts an answer in which at least
99% of the labels are within TOL_SIGMA * (standard deviation of the instance's logits) of the best logit of their sample. That is the "equivalent
accuracy" the speedup is conditional on: a float32 or well-quantised model passes, a pruned or truncated one fails (solvers/aiinfer_lossy.py).

The reference is the unoptimised way to run it: float64, one sample at a time. Batching (a BLAS matmul), float32 and fused kernels are the
speedups this domain exists to certify. CPU only, one thread (the harness and the sandbox both set OMP_NUM_THREADS=1): see PROTOCOL.md for why a
GPU speedup is not certifiable by this protocol yet.
"""
import functools
import hashlib
import hmac
import math

import numpy as np

NAME = "aiinfer"
VERSION = "aiinfer-v1"        # bump whenever derive() or the model definition changes
SIZE_RANGE = (1024, 6144)     # d=6144 peaks near 2.5 GB (weights + batch + hash-stream temporaries); the sandbox allows 4 GB
SIZE_STEP = 64
REFERENCE_SOLVER = "reference.py"
CLASSES = 10
TOL_SIGMA = 0.1               # a label is acceptable if its logit >= max logit - TOL_SIGMA * std(all logits of the instance)
MAX_BAD_FRACTION = 0.01       # at most floor(0.01 * batch) labels may be unacceptable
DOC = ("solve(seed, d, batch): regenerate the model and inputs from `seed` with the SplitMix64 stream documented in domains/aiinfer/reference.py "
       "(W1, W2: d x d, W3: 10 x d, scaled by sqrt(3/d); batch inputs of dimension d), run h=relu(W1 x), h=relu(W2 h), logits=W3 h, and return the list of "
       "`batch` class labels (ints 0-9). A label counts if its logit is within 0.1 standard deviations of the sample's best logit; "
       "at most 1% of labels may miss. Return None for no answer.")
REFERENCE_NOTE = ("Float64, one sample at a time (a numpy matrix-vector product per input). Known to be beaten by batching the whole input "
                  "matrix into one BLAS matmul and by float32; the speedup grows with d because the model regeneration is O(d^2) and the inference O(d^3).")

_GOLD = 0x9E3779B97F4A7C15
_C1 = 0xBF58476D1CE4E5B9
_C2 = 0x94D049BB133111EB


def _uniform(seed, start, n):
    """n floats in [-1, 1): SplitMix64 of the counter start..start+n-1 under `seed`. Integer arithmetic wraps mod 2^64, so it is exact on every machine."""
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _model(seed, d, batch):
    s = math.sqrt(3.0 / d)
    o = 0
    W1 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W2 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W3 = (_uniform(seed, o, CLASSES * d) * s).reshape(CLASSES, d)
    o += CLASSES * d
    X = _uniform(seed, o, batch * d).reshape(batch, d)
    return W1, W2, W3, X


@functools.lru_cache(maxsize=4)
def _logits(seed, d, batch):
    W1, W2, W3, X = _model(seed, d, batch)
    h = np.maximum(X @ W1.T, 0.0)
    h = np.maximum(h @ W2.T, 0.0)
    return h @ W3.T


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aiinfer-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    L = _logits(seed, size, size)
    return {"args": [seed, size, size], "planted": [int(c) for c in L.argmax(axis=1)]}


def verify(inst: dict, ans) -> bool:
    seed, d, batch = inst["args"]
    if not isinstance(ans, list) or len(ans) != batch:
        return False
    if any(isinstance(c, bool) or not isinstance(c, int) or not 0 <= c < CLASSES for c in ans):
        return False
    L = _logits(seed, d, batch)
    tol = TOL_SIGMA * float(L.std())
    got = L[np.arange(batch), np.asarray(ans)]
    bad = int(np.count_nonzero(got < L.max(axis=1) - tol))
    return bad <= int(MAX_BAD_FRACTION * batch)
