"""Child process of oracle_core.py: run `solve(oracle, *args)` of one solver file under exact instruction counting, with a QUERY oracle that lives in the PARENT.

It reuses count_runner.py's restricted subset and counter (imported, not edited: count_runner.py is pinned by counted rounds). The secret never enters this process: `oracle(query)`
writes {"q": query} as one JSON line on the real stdout and reads one JSON line {"r": reply} from the real stdin; the parent (the judge) answers from the declaration. The solver can
reach neither the pipes (they are closure cells, behind dunder names the subset bans) nor the declaration. A reply is parsed from text, so it is a fresh object every time.

  argv[1]   the solver file (top-level `solve(oracle, *args)`)
  stdin     first line {"args": [...], "limit": N}; then one reply line per query
  stdout    one {"q": ...} line per query, then LAST {"status": "ok" | "limit" | "error", "steps": int, "ans": ..., "err": "..."}

Steps are counted exactly as in count_runner.py (the oracle's own few instructions included, deterministically); time spent waiting for the parent is not an instruction.
"""
import gc
import json
import os
import sys

import count_runner as CR

MAX_LINE = 1 << 16   # a query or reply longer than this is an error (the parent enforces the same)


def main():
    if len(sys.argv) != 2:
        CR._emit({"status": "error", "steps": 0, "err": "usage: oracle_runner.py SOLVER"})
        return
    rin, rout = sys.stdin, sys.__stdout__
    try:
        payload = json.loads(rin.readline())
        args, limit = payload["args"], int(payload["limit"])
    except (ValueError, KeyError, TypeError) as e:
        CR._emit({"status": "error", "steps": 0, "err": f"bad payload: {type(e).__name__}"})
        return
    if sys.version_info < (3, 12):
        CR._emit({"status": "error", "steps": 0, "err": "step counting needs Python 3.12 or newer (sys.monitoring)"})
        return
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path[:] = [p for p in sys.path if p and os.path.abspath(p) != here]
    mon = sys.monitoring
    try:
        delattr(sys, "monitoring")
    except (AttributeError, TypeError):
        pass
    sys.modules.pop("sys.monitoring", None)
    if sys.platform.startswith("linux"):
        try:
            import resource
            resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
        except (ImportError, ValueError, OSError):
            pass
    try:
        code, namespace = CR._prepare(sys.argv[1])
    except BaseException as e:
        CR._emit({"status": "error", "steps": 0, "err": f"could not load the solver: {type(e).__name__}: {str(e)[:200]}"})
        return

    dumps, loads, readline, write, flush = json.dumps, json.loads, rin.readline, rout.write, rout.flush

    def oracle(query):
        write(dumps({"q": query}, allow_nan=False) + "\n")
        flush()
        line = readline(MAX_LINE + 2)
        if not line or len(line) > MAX_LINE:   # a cut-off line would leave its tail on the pipe and desynchronise every later reply
            raise RuntimeError("the oracle is closed or its reply is too long")
        return loads(line)["r"]

    count = [0]
    tripped = [False]

    def on_instruction(code, offset):
        if tripped[0]:
            return
        n = count[0] + 1
        count[0] = n
        if n > limit:
            tripped[0] = True
            raise CR._StepLimit()

    status, ans, err = "ok", None, ""
    real_stdout = sys.stdout
    sys.stdout = sys.stderr
    gc.collect()
    gc.disable()
    mon.use_tool_id(CR.TOOL_ID, "svp-count")
    mon.register_callback(CR.TOOL_ID, mon.events.INSTRUCTION, on_instruction)
    try:
        mon.set_events(CR.TOOL_ID, mon.events.INSTRUCTION)
        exec(code, namespace)
        ans = namespace["solve"](oracle, *args)
    except CR._StepLimit:
        status = "limit"
    except BaseException as e:
        status, err = "error", f"{type(e).__name__}: {str(e)[:200]}"
    finally:
        try:
            intact = mon.get_events(CR.TOOL_ID) == mon.events.INSTRUCTION
        except ValueError:
            intact = False
        try:
            mon.set_events(CR.TOOL_ID, mon.events.NO_EVENTS)
            mon.register_callback(CR.TOOL_ID, mon.events.INSTRUCTION, None)
            mon.free_tool_id(CR.TOOL_ID)
        except ValueError:
            intact = False
        gc.enable()
        sys.stdout = real_stdout
    steps = count[0]
    if not intact and not tripped[0]:
        status, ans, err = "error", None, "the solver reconfigured the instruction counter: its count means nothing"
    if tripped[0]:
        status, ans, err = "limit", None, ""
    if status == "ok":
        try:
            json.dumps(ans)
        except (TypeError, ValueError):
            status, err, ans = "error", "the answer is not JSON-serialisable (an int, a list of ints or None is expected)", None
    CR._emit({"status": status, "steps": steps, "ans": ans if status == "ok" else None, "err": err})


if __name__ == "__main__":
    main()
