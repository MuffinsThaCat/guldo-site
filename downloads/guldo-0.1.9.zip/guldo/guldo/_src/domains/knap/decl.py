"""Declaration of a knapsack / subset-sum domain at LOW density (the Lagarias-Odlyzko / Coster et al. lattice attack regime).

A solver receives (a, s): m weights a_i, each a random integer below 2^(2m) (density about 1/2), and s = sum of a_i over a hidden nonempty subset.
It returns x in {0,1}^m with sum a_i x_i = s. At this density the subset is unique with overwhelming probability. size = m; the reference is
the classic meet in the middle (two lists of 2^(m/2) subset sums). Lattice reduction solves low-density instances in polynomial time (heuristically).
"""
import hashlib
import hmac
import random

NAME = "knap"
VERSION = "knap-v2"           # bump whenever derive() changes
SIZE_RANGE = (38, 48)
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
DOC = "solve(a, s): a is a list of m positive ints, s an int. Return a list x of m ints in {0, 1} with sum(a[i] * x[i]) == s. Return None for no answer."
REFERENCE_NOTE = ("The reference is the classic meet in the middle (about 2^(m/2) time and memory). Schroeppel-Shamir (less memory) and lattice reduction "
                  "(low density) are known to beat it at scale; no claim is made about which is fastest. Scope: toy sizes (m <= 48) at density 1/2, NOT evidence about "
                  "attacks on knapsack cryptosystems at real parameters, and a certificate here must not be read as one.")


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"knap-v2:{size}:{idx}".encode(), hashlib.sha256).digest())
    m = size
    a = [rng.randrange(1, 1 << (2 * m)) for _ in range(m)]
    while True:
        x = [rng.randrange(2) for _ in range(m)]
        if any(x):
            break
    return {"args": [a, sum(ai for ai, xi in zip(a, x) if xi)], "planted": x}


def verify(inst: dict, ans) -> bool:
    a, s = inst["args"]
    if not isinstance(ans, list) or len(ans) != len(a):
        return False
    for c in ans:
        if isinstance(c, bool) or not isinstance(c, int) or c not in (0, 1):
            return False
    return sum(ai for ai, xi in zip(a, ans) if xi) == s
