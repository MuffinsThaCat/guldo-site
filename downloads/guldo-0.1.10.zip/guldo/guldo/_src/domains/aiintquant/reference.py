"""Reference for aiintquant: float64, one token at a time.

The model definition (the contract a submission must reproduce): SplitMix64 counter stream under `seed`, element k = finalise((k+1)*GOLD + seed), mapped to [-1, 1) as
(z >> 11) * 2^-52 - 1. Stream layout: E (64 x 128, scale sqrt 3), W1 (128 x 512, scale 4 sqrt(3/128)), W2 (512 x 128, scale 4 sqrt(3/512)), pos (T x 128, scale 3 sqrt 3), then H = 512 floats u_j
(channel multipliers g_j = 30^((u_j + 1) / 2): W1's column j is multiplied by g_j and W2's row j divided by it), then one float for the prompt token = min(int((u + 1) / 2 * 64), 63). Step t: x = E[prev] + pos[t]; y = x + relu(rms(x) W1) W2; logits = rms(y) E^T; the token is the argmax (rms(v) = v / sqrt(mean(v^2) + 1e-6)).
"""
import math

import numpy as np

_V, _D, _H = 64, 128, 512


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def solve(seed, T):
    o = 0

    def take(shape, scale):
        nonlocal o
        n = int(np.prod(shape))
        a = (_uniform(seed, o, n) * scale).reshape(shape)
        o += n
        return a
    E = take((_V, _D), math.sqrt(3.0))
    W1 = take((_D, _H), 4.0 * math.sqrt(3.0 / _D))
    W2 = take((_H, _D), 4.0 * math.sqrt(3.0 / _H))
    pos = take((T, _D), 3.0 * math.sqrt(3.0))
    g = 30.0 ** ((_uniform(seed, o, _H) + 1.0) * 0.5)
    o += _H
    W1, W2 = W1 * g[None, :], W2 / g[:, None]
    tok = min(int((_uniform(seed, o, 1)[0] + 1.0) * 0.5 * _V), _V - 1)
    out = []
    for t in range(T):
        x = E[tok] + pos[t]
        y = x + np.maximum(_rms(x) @ W1, 0.0) @ W2
        tok = int(np.argmax(_rms(y) @ E.T))
        out.append(tok)
    return out
