"""Reference for aireal: the dense network on the noisy batch, float64, one batched product per layer. Reads the weights and images from this directory (the counted solvers carry them as constants)."""
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(H, Q, seed, idx):
    d = np.load(os.path.join(HERE, "digits.npz"))
    m = np.load(os.path.join(HERE, f"model_{H}.npz"))
    v = d["X"][1000:1400][np.asarray(idx)].astype(np.float64) + 6.0 * _uniform(seed, 0, Q * 64).reshape(Q, 64)
    X = (np.maximum(v, 0.0) - np.maximum(v - 16.0, 0.0)) / 16.0
    return [int(v) for v in np.argmax(np.maximum(X @ m["W1"].T + m["b1"], 0.0) @ m["W2"].T + m["b2"], axis=1)]
