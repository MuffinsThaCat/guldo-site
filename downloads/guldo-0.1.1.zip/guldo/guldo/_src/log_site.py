"""The site's Log page data: a transparency-log directory (translog.py), re-verified when the site is built.

Nothing is trusted from the files. The entries are re-read and re-hashed, every signed head is checked against the entries, every certificate the log serves is re-verified
(with nothing from it executed) and compared with its entry, and the witnesses that count are only those whose keys the operator pinned in trusted.txt, as for attestations.
A damaged log is shown as damaged: this module never raises over a log's contents and never repairs one.
"""
import os
import re
import shutil

import attest
import translog as T

RECHECK_LIMIT = 300          # certificates re-verified per build; the rest are listed as not re-checked here (anyone can re-check them with `guldo log check --recheck`)
_PROOF = re.compile(r"\d{1,9}\.json")
_CERT = re.compile(r"[0-9a-f]{64}\.cert\.json")
_ATT = re.compile(r"[0-9a-f]{64}\.att\.json")


def collect(log_dir):
    """-> None when there is no log directory, else a dict with everything the page shows."""
    if not log_dir or not os.path.isdir(log_dir):
        return None
    d = T.parse_log(T.dir_reader(log_dir))
    info = {"data": d, "problems": list(d.problems), "sig_problems": [], "head": None, "head_check": None, "trusted": [], "rechecks": {}, "frontier": {}, "recheck_skipped": 0,
            "crypto": attest.have_crypto()}
    if d.meta is None:
        return info
    tpath = os.path.join(log_dir, "trusted.txt")
    info["has_trusted"] = os.path.isfile(tpath) and not os.path.islink(tpath)
    if os.path.isfile(tpath):
        try:
            info["trusted"] = sorted(attest.read_trusted(tpath))
        except SystemExit as e:
            info["problems"].append(f"trusted.txt is malformed: {e}")
    if info["crypto"]:
        try:
            info["sig_problems"] = T.verify_signatures(d)
        except Exception as e:  # a hostile file must never cost the whole page
            info["sig_problems"] = [f"signatures could not be checked ({type(e).__name__})"]
    if d.head is not None:
        info["head"] = {"body": d.head["body"], "log": d.head["log"], "witnesses": T.head_witnesses(d, d.head["body"])}
        try:
            info["head_check"] = T.check_checkpoint(info["head"], d.meta["pubkey"], info["trusted"])
        except Exception as e:
            info["problems"].append(f"the head could not be checked ({type(e).__name__})")
    n = d.head["body"]["size"] if d.head else 0
    info["frontier"] = T.frontier(d.entries[:n])
    pdir = os.path.join(log_dir, "proofs")
    info["proofs"] = {int(f[:-5]) for f in os.listdir(pdir) if _PROOF.fullmatch(f)} if os.path.isdir(pdir) else set()
    serve = T.dir_reader(log_dir)
    for i, e in enumerate(d.entries):
        if i >= RECHECK_LIMIT:
            info["recheck_skipped"] += 1
            continue
        try:
            got = T.recheck_served(d, e, serve)
            info["rechecks"][e["seq"]] = got if got is not None else ("mismatch", "the log does not serve this file")
        except Exception as ex:
            info["rechecks"][e["seq"]] = ("unknown", f"could not be re-checked ({type(ex).__name__})")
    # Four answers to "what is the best result?", from weakest evidence to strongest. An entry nobody has re-checked can carry any credit its operator wrote, so it
    # must never be the only number a reader sees. The attester keys are the ones the OPERATOR lists in trusted.txt: a reader must pin their own.
    covered = d.entries[:n]
    matched = {e["seq"] for e in covered if info["rechecks"].get(e["seq"], ("", ""))[0] == "match"}
    keep = [e for e in covered if e["kind"] != "certificate" or e["seq"] in matched]      # every statement stays (it is evidence); only re-checked certificates count
    info["frontier_rechecked"] = T.frontier(keep)
    info["frontier_reexecuted"] = T.frontier(keep, tier="reexecuted", keys=info["trusted"])
    info["frontier_run"] = T.frontier(keep, tier="run", keys=info["trusted"])
    info["evidence"] = T.evidence(covered)
    info["not_rechecked"] = sum(1 for e in covered if e["kind"] == "certificate" and e["seq"] not in matched)
    return info


def ok(info):
    """True only if every check that could run passed. A log that does not verify must never look fine on the page."""
    if info is None or info["data"].meta is None:
        return False
    return (not info["problems"] and not info["sig_problems"] and info["head"] is not None and (info["head_check"] or {}).get("ok", False)
            and all(v[0] != "mismatch" for v in info["rechecks"].values()))


def copy_files(log_dir, out_dir):
    """Copy the log's public files into out_dir/log: exactly the files translog.py writes for readers, nothing else (a stray key or note in the directory is never published)."""
    if not log_dir or not os.path.isdir(log_dir):
        return
    dest = os.path.join(out_dir, "log")
    os.makedirs(dest, exist_ok=True)

    def put(src, rel):
        if os.path.isfile(src) and not os.path.islink(src):
            os.makedirs(os.path.dirname(os.path.join(dest, rel)), exist_ok=True)
            shutil.copy(src, os.path.join(dest, rel))
    for name in T.PUBLIC_FILES:
        put(os.path.join(log_dir, name), name)
    for sub, pat in (("certs", _CERT), ("attestations", _ATT), ("proofs", _PROOF)):
        base = os.path.join(log_dir, sub)
        if os.path.isdir(base):
            for fn in sorted(os.listdir(base)):
                if pat.fullmatch(fn):
                    put(os.path.join(base, fn), f"{sub}/{fn}")
