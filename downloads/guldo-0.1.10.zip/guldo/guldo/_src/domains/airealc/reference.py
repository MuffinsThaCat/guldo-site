"""Reference for airealc: the dense CNN on the noisy batch in float64 (the images cut into patches, one matrix product per layer)."""
import numpy as np

NOISE = {16: 76.0, 32: 92.0, 48: 108.0}     # per width, as in decl.py


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _patches(x, n, side, c):
    t = x.reshape(n, side // 2, 2, side // 2, 2, c).transpose(0, 1, 3, 2, 4, 5)
    return t.reshape(n * (side // 2) ** 2, 4 * c)


def solve(F, Q, seed, X, K1, b1, K2, b2, Wf, bf):
    v = np.asarray(X, dtype=np.float64) + NOISE[F] * _uniform(seed, 0, Q * 784).reshape(Q, 784)
    x = (np.maximum(v, 0.0) - np.maximum(v - 255.0, 0.0)) / 255.0
    a1 = np.maximum(_patches(x, Q, 28, 1) @ np.asarray(K1) + np.asarray(b1), 0.0)
    a2 = np.maximum(_patches(a1.reshape(Q, -1), Q, 14, F // 2) @ np.asarray(K2) + np.asarray(b2), 0.0)
    return [int(t) for t in np.argmax(a2.reshape(Q, -1) @ np.asarray(Wf) + np.asarray(bf), axis=1)]
