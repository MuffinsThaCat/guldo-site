"""Rounds, the transparency log and the submission store of a PUBLIC competition. Storage and rules only: no HTTP here, and
nothing in this module ever imports or executes an uploaded file (it is parsed with `ast` by submit_check.lint, nothing more).

A ROUND is one commit-reveal event: a family, k >= 3 seed commitments published at creation, a deadline, and a state
    open -> closed -> evaluating -> evaluated -> revealed
Each round has an append-only, hash-chained LOG (rounds/<id>/log.jsonl). Entry 0 contains the commitments, so they are
public before any submission; every accepted submission is an entry carrying its file hash. Anyone holding a copy of the
log can detect a dropped, reordered, altered or back-dated entry (`verify_log`), and publishing the head hash somewhere the
operator cannot edit anchors it. Seeds are revealed only after evaluation, and only if they hash to the commitments.

There are no accounts. A handle is bound to a secret token issued with its first submission (only the token's hash is stored),
so nobody else can submit under a handle you hold. Contact details and IP addresses are never stored here.
"""
import contextlib
import fcntl
import hashlib
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

import declared
import families
import judge
import official
import submit_check

HERE = os.path.dirname(os.path.abspath(__file__))
ROUND_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,40}$")
HANDLE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{1,31}$")
RESERVED = {"baseline", "judge", "admin", "operator", "reference", "system", "solver", "unnamed", "root", "official"}
MAX_UPLOAD = 200_000
MAX_PER_HANDLE = 3
MAX_PER_ROUND = 200
MAX_N = 200  # instances per size a round may ask for (the official minimum is families.OFFICIAL[family]["n"])
STATES = ("open", "closed", "evaluating", "evaluated", "revealed")


MIN_PYTHON = (3, 9)


def require_python():
    """Refuse to start on an interpreter older than the supported minimum, with a message, instead of failing later with a SyntaxError
    or an AttributeError in the middle of a submission. Called by both entry points (public_portal.py serve, ops.py)."""
    if tuple(sys.version_info[:2]) < MIN_PYTHON:
        raise SystemExit(f"REFUSED: Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer is required (this is "
                         f"{sys.version_info[0]}.{sys.version_info[1]}).")


class Rejected(Exception):
    """A submission or operation refused for a reason the caller may show to the user."""


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256(data):
    return hashlib.sha256(data if isinstance(data, bytes) else data.encode()).hexdigest()


@contextlib.contextmanager
def locked(path):
    """Cross-process exclusive lock (the web tier and the operator CLI both write a round). It never creates the round's directory:
    a lock on a round that does not exist must fail, or a request for any valid id would create it (and squat the id)."""
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o660)  # group-writable (subject to umask): the web tier and the operator are different users
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def rdir(base, rid):
    if not ROUND_ID_RE.match(rid or ""):
        raise KeyError(rid)
    return os.path.join(base, "rounds", rid)


def _require(base, rid):
    """KeyError unless the round exists. Called before any lock is taken, so nothing is created for a round that does not exist."""
    if not os.path.exists(os.path.join(rdir(base, rid), "round.json")):
        raise KeyError(rid)


def _read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, sort_keys=True)
    os.replace(tmp, path)  # atomic: a reader never sees half a file


# ---------------------------------------------------------------- the transparency log
def _entry_hash(entry):
    body = {k: v for k, v in entry.items() if k != "hash"}
    return sha256(entry["prev"] + canonical(body))


def read_log(d):
    out = []
    try:
        with open(os.path.join(d, "log.jsonl"), encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    out.append(json.loads(line))
    except OSError:
        pass
    return out


def append_log(d, kind, data, now):
    """Caller holds the round lock. Refuses to extend a chain that does not verify: appending to a damaged log would bury the damage."""
    log = read_log(d)
    if log:
        ok, _, _, err = verify_log(d)
        if not ok:
            raise Rejected(f"REFUSED: this round's log does not verify ({err}); run `ops.py verify-log` and restore it from a backup before anything else is added")
    prev = log[-1]["hash"] if log else sha256("genesis:" + os.path.basename(d))
    # never write a timestamp earlier than the previous entry: a clock that steps backwards (NTP) must not make the log fail its own
    # back-dating check and freeze the round. The clamp only ever moves a timestamp forward, so it cannot hide a late submission.
    ts = max(round(now, 3), log[-1]["ts"]) if log else round(now, 3)
    entry = {"seq": len(log), "ts": ts, "kind": kind, "data": data, "prev": prev}
    entry["hash"] = _entry_hash(entry)
    with open(os.path.join(d, "log.jsonl"), "a", encoding="utf-8") as f:
        f.write(canonical(entry) + "\n")
        f.flush()
        os.fsync(f.fileno())
    return entry


def verify_log(d, expected_commitments=None):
    """(ok, entries, head_hash, error). Checks sequence, the hash chain, and that entry 0 carries the commitments."""
    log = read_log(d)
    if not log:
        return False, 0, None, "empty log"
    prev = sha256("genesis:" + os.path.basename(d))
    for i, e in enumerate(log):
        if e.get("seq") != i:
            return False, len(log), None, f"entry {i}: sequence number {e.get('seq')} (an entry was dropped, duplicated or reordered)"
        if e.get("prev") != prev:
            return False, len(log), None, f"entry {i}: does not chain to the previous entry"
        if _entry_hash(e) != e.get("hash"):
            return False, len(log), None, f"entry {i}: contents do not match their hash (altered)"
        if i > 0 and e["ts"] < log[i - 1]["ts"] - 1:
            return False, len(log), None, f"entry {i}: timestamp earlier than the previous entry (back-dated)"
        prev = e["hash"]
    if log[0]["kind"] != "round_created":
        return False, len(log), None, "the first entry is not round_created"
    if expected_commitments is not None and log[0]["data"].get("commitments") != expected_commitments:
        return False, len(log), None, "the logged commitments differ from the round's commitments"
    return True, len(log), log[-1]["hash"], ""


# ---------------------------------------------------------------- the rules a round commits to
# Everything that decides how an instance is generated, run, metered and scored. The hashes go into entry 0 of the log, so the
# operator cannot change the ladder, the baseline or the scoring code after seeing submissions without it being visible.
CODE_FILES = ["extrapolate.py", "families.py", "declared.py", "instances.py", "instances_mlwe.py", "instances_factor.py", "harness.py", "runner.py",
              "judge.py", "official.py", "sandbox/meter.py", "sandbox/meter_core.py", "sandbox/Dockerfile.v2"]


COUNT_FILES = ["count_runner.py", "counted.py"]   # the counting program and its driver: rules of a COUNTED round, pinned in its fingerprint (not in CODE_FILES, so timed rounds are unchanged)


def code_fingerprint(family, count=None):
    """`count` (a round's counted configuration, see count_config) makes this the fingerprint of a COUNTED round: its own size ladder, and the counting code pinned."""
    def h(rel):
        with open(os.path.join(HERE, rel), "rb") as f:  # join(HERE, absolute path) is the absolute path (a declared domain outside the project)
            return sha256(f.read())
    baseline = families.DEFAULT_BASELINE[family]
    fp = {"dims": list(families.DEFAULT_DIMS[family]), "instance_version": families.VERSIONS[family], "baseline": baseline,
          "baseline_sha256": h(baseline), "code": {rel: h(rel) for rel in CODE_FILES}}
    fp["code"].update(declared.domain_files(families, family))  # a declared domain: its decl.py, compiled.json and reference are rules too
    if count is not None:
        fp["dims"] = list(count["dims"])
        fp["cost_model"] = "count"
        fp["code"].update({rel: h(rel) for rel in COUNT_FILES})
    return fp


def count_config(family, dims, n, cap):
    """Validate and complete the counted configuration of a round: -> {dims, n, cap, steps_per_second, python, counter_sha256}. Rejected if the family cannot be
    counted, this interpreter cannot count, or a value is out of range. The interpreter and counter are recorded because instruction counts are only comparable
    on the same Python and the same counting program."""
    import certificate   # (lazily: certificate imports this module)
    import counted
    if not counted.supported():
        raise Rejected(f"a counted round needs Python {counted.MIN_PYTHON[0]}.{counted.MIN_PYTHON[1]} or newer on the operator's machine (this is {counted.python_version()})")
    why = counted.family_problem(family)
    if why:
        raise Rejected("this family cannot be counted: " + why)
    if not (isinstance(dims, (list, tuple)) and dims and all(isinstance(d, int) and not isinstance(d, bool) and 1 <= d <= 512 for d in dims) and len(set(dims)) == len(dims)):
        raise Rejected("the counted sizes must be a non-empty list of distinct integers from 1 to 512")
    for d in dims:   # a size the family cannot generate would fail every instance of every submission AFTER the seeds were committed: find out now
        try:
            families.derive(family, b"svp-count-config-probe", d, 0)
        except Exception as e:   # (any derive() failure: a bad size, a family-specific limit)
            raise Rejected(f"the family {family!r} cannot generate a question of size {d}: {str(e)[:120]}")
    if not (isinstance(n, int) and not isinstance(n, bool) and 1 <= n <= MAX_N):
        raise Rejected(f"the counted n must be an integer from 1 to {MAX_N} (instances per size)")
    if not (isinstance(cap, (int, float)) and not isinstance(cap, bool) and 0 < cap <= certificate.MAX_COUNTED_CAP):   # `not (...)` also rejects NaN
        raise Rejected(f"the counted cap must be a number between 0 and {certificate.MAX_COUNTED_CAP:g} counted seconds")
    return {"dims": sorted(dims), "n": n, "cap": float(cap), "steps_per_second": counted.STEPS_PER_SECOND, "python": counted.python_version(),
            "counter_sha256": counted.counter_sha256()}


def fingerprint_changes(old, new):
    """{label: (old, new)} for everything that differs; empty if the rules are as the round committed to."""
    out = {}
    for k in ("dims", "instance_version", "baseline", "baseline_sha256", "cost_model"):
        if old.get(k) != new.get(k):
            out[k] = (old.get(k), new.get(k))
    for rel in sorted(set(old.get("code", {})) | set(new.get("code", {}))):
        if old.get("code", {}).get(rel) != new.get("code", {}).get(rel):
            out["code/" + rel] = (old.get("code", {}).get(rel), new.get("code", {}).get(rel))
    return out


# ---------------------------------------------------------------- rounds
def create_round(base, rid, title, family, commitments, closes_at, opens_at=None, now=None, allow_few_seeds=False, max_submissions=None, n=None, allow_private=True, count=None):
    """allow_private=False makes it a public, LOGGED rule of the round that every submission must publish its source (after the reveal): a private solver
    cannot be re-run by anyone but the operator, and some rounds will not accept results that rest on the operator alone.
    count={"dims": [...], "n": N, "cap": C} makes it a COUNTED round: every submission and the baseline are measured by deterministic step counting (counted.py) on
    THIS ladder, which is committed in log entry 0 (with the Python version and the counting program) before any submission. Anyone can then re-execute any
    instance and must get identical counts, so the result does not rest on the operator's machine or sandbox. Source publication is mandatory (the proof is
    re-execution) and n and the cap are the round's own; `n` is ignored."""
    now = now or time.time()
    if not ROUND_ID_RE.match(rid or ""):
        raise Rejected("round id must be 2-41 characters of a-z, 0-9 and '-'")
    if family not in families.FAMILIES:
        raise Rejected(f"unknown family {family!r}")
    if family in families.DECLARED:  # a compiled domain is official only if the compiler's own end-to-end controls passed
        st = (families.DECLARED[family]["compiled"].get("selftest") or {}).get("status")
        if st != "pass" and not allow_few_seeds:
            raise Rejected(f"family {family!r} has not passed its compiler self-test (status {st!r}); run compile_domain.py selftest {family}")
    if len(set(commitments)) != len(commitments) or not all(re.fullmatch(r"[0-9a-f]{64}", c) for c in commitments):
        raise Rejected("commitments must be distinct 64-hex sha256 values")
    if len(commitments) < judge.MIN_SEEDS and not allow_few_seeds:
        raise Rejected(f"an official round needs at least {judge.MIN_SEEDS} seed commitments (got {len(commitments)})")
    opens_at = opens_at if opens_at is not None else now
    if closes_at <= opens_at:
        raise Rejected("the deadline must be after the opening time")
    max_submissions = MAX_PER_ROUND if max_submissions is None else max_submissions
    if not (isinstance(max_submissions, int) and 1 <= max_submissions <= MAX_PER_ROUND):
        raise Rejected(f"max_submissions must be an integer from 1 to {MAX_PER_ROUND}")
    cfg = families.OFFICIAL[family]
    if count is not None:
        if not isinstance(count, dict):
            raise Rejected("count must be a dict with dims, n and cap")
        count = count_config(family, count.get("dims"), count.get("n"), count.get("cap"))   # validated BEFORE anything is created
        n, allow_private = count["n"], False
    else:
        n = cfg["n"] if n is None else n
        # instances per size: at least the official minimum (the board already requires n >= it), at most MAX_N. More than the minimum is how a
        # round certifies larger speedups: at the official n a 4-bit effect is certified 0% of the time, at 2x the instances 100%.
        if not (isinstance(n, int) and not isinstance(n, bool) and cfg["n"] <= n <= MAX_N):
            raise Rejected(f"n must be an integer from {cfg['n']} to {MAX_N} (instances per size)")
    d = rdir(base, rid)
    if os.path.exists(d):
        raise Rejected(f"round {rid!r} already exists")
    os.makedirs(os.path.join(d, "submissions"))
    r = {"id": rid, "title": title[:120], "family": family, "commitments": sorted(commitments), "opens_at": opens_at,
         # n is the round's own (logged) value and is what the worker evaluates with; the CPU cap is always the family's official one (a counted round's own cap)
         "closes_at": closes_at, "state": "open", "n": n, "budget": cfg["budget"] if count is None else count["cap"], "created_at": now,
         "max_submissions": max_submissions, "fingerprint": code_fingerprint(family, count) if count is not None else code_fingerprint(family), "allow_private": bool(allow_private)}
    logged = ["id", "title", "family", "commitments", "opens_at", "closes_at", "n", "budget", "max_submissions", "fingerprint", "allow_private"]
    if count is not None:
        r["cost_model"], r["count"] = "count", count
        logged += ["cost_model", "count"]   # a public rule of the round, in log entry 0: the ladder every participant is counted on
    with locked(os.path.join(d, ".lock")):
        _write_json(os.path.join(d, "round.json"), r)
        _write_json(os.path.join(d, "handles.json"), {})
        append_log(d, "round_created", {k: r[k] for k in logged}, now)
    return r


def get_round(base, rid):
    r = _read_json(os.path.join(rdir(base, rid), "round.json"))
    if r is None:
        raise KeyError(rid)
    return r


def list_rounds(base):
    root = os.path.join(base, "rounds")
    out = []
    for rid in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        r = _read_json(os.path.join(root, rid, "round.json"))
        if r:
            out.append(r)
    return sorted(out, key=lambda r: r["created_at"], reverse=True)


def _set_state(d, r, state, now, kind, data=None):
    # LOG FIRST. append_log refuses (and changes nothing) if the chain does not verify; writing round.json first used to leave a
    # round "closed" with no log entry, and every later call then skipped the closure because the state already said so.
    append_log(d, kind, data or {}, now)
    r["state"] = state
    _write_json(os.path.join(d, "round.json"), r)


def close_round(base, rid, now=None, force=False):
    """Close a round at its deadline (or earlier with force=True, an operator action that is logged)."""
    now = now or time.time()
    _require(base, rid)
    d = rdir(base, rid)
    with locked(os.path.join(d, ".lock")):
        r = get_round(base, rid)
        if r["state"] != "open":
            return r
        if now < r["closes_at"] and not force:
            raise Rejected("the deadline has not passed")
        _set_state(d, r, "closed", now, "round_closed", {"forced": bool(force and now < r["closes_at"])})
    return r


def close_due(base, now=None):
    """Close every overdue round. One round whose log is damaged must not stop the others (or, since the web tier calls this on
    every page view, take the whole site down): it is left unchanged, and its own page reports the log problem."""
    now = now or time.time()
    for r in list_rounds(base):
        if r["state"] == "open" and now >= r["closes_at"]:
            try:
                close_round(base, r["id"], now)
            except Rejected:
                continue


# ---------------------------------------------------------------- submissions
def list_submissions(base, rid):
    root = os.path.join(rdir(base, rid), "submissions")
    out = []
    for sid in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        m = _read_json(os.path.join(root, sid, "meta.json"))
        if m:
            out.append(m)
    return sorted(out, key=lambda m: m["seq"])


def submit(base, rid, handle, token, source, publish_source=False, now=None):
    """Validate and store a submission WITHOUT running it. Returns a dict with id, seq, hash, warnings and, only when the handle
    is new, the secret token (shown once). Raises Rejected with a message that is safe to show. Rejections store nothing."""
    now = now or time.time()
    handle = (handle or "").strip()
    if not HANDLE_RE.match(handle) or handle.lower() in RESERVED:
        raise Rejected("handle must be 2-32 characters: letters, digits, '.', '_' or '-', starting with a letter or digit (some names are reserved)")
    if not isinstance(source, (bytes, bytearray)) or len(source) == 0:
        raise Rejected("empty file")
    _require(base, rid)
    if len(source) > MAX_UPLOAD:
        raise Rejected(f"the file is {len(source)} bytes; the limit is {MAX_UPLOAD}")
    try:
        text = bytes(source).decode("utf-8")
    except UnicodeDecodeError:
        raise Rejected("the file is not UTF-8 text")
    if "\x00" in text:
        raise Rejected("the file contains NUL bytes")
    d = rdir(base, rid)
    with locked(os.path.join(d, ".lock")):
        r = get_round(base, rid)
        if r["state"] == "open" and now >= r["closes_at"]:
            _set_state(d, r, "closed", now, "round_closed", {"forced": False})
        if r["state"] != "open":
            raise Rejected("this round is closed")
        if now < r["opens_at"]:
            raise Rejected("this round has not opened yet")
        if not publish_source and not r.get("allow_private", True):   # a rule logged in the round's first entry; rounds made before it existed allow private solvers
            raise Rejected("this round requires every solver to be published: tick 'publish source' (your source becomes public only after the seeds are revealed)")
        subs = list_submissions(base, rid)
        if len(subs) >= r.get("max_submissions", MAX_PER_ROUND):
            raise Rejected("this round has reached its submission limit")
        digest = sha256(bytes(source))
        if any(m["sha256"] == digest for m in subs):
            raise Rejected("an identical file was already submitted in this round")
        handles = _read_json(os.path.join(d, "handles.json"), {})
        key = handle.lower()
        new_token = None
        if key in handles:
            if not token or not secrets.compare_digest(sha256(token), handles[key]):
                raise Rejected("that handle is already taken in this round; supply its token, or pick another handle")
            if sum(1 for m in subs if m["handle"].lower() == key) >= MAX_PER_HANDLE:
                raise Rejected(f"a handle may make at most {MAX_PER_HANDLE} submissions per round")
        else:
            new_token = secrets.token_urlsafe(24)
        sid = uuid.uuid4().hex[:12]
        fname = f"{handle}-{sid}.py"  # judge.py names a board entry after the file, so every submission needs a unique name
        sdir = os.path.join(d, "submissions", sid)
        os.makedirs(sdir)
        path = os.path.join(sdir, fname)
        try:
            with open(path, "wb") as f:
                f.write(bytes(source))  # the EXACT uploaded bytes (never a re-encoded string): the log committed to their hash
            try:
                warnings, fatal = submit_check.lint(path)  # ast only: never imports or runs the file
            except (SyntaxError, ValueError, RecursionError) as e:
                warnings, fatal = [], [f"could not parse: {type(e).__name__}"]
            if fatal:
                raise Rejected("; ".join(fatal))
            if r.get("cost_model") == "count":
                import counted
                problems = counted.source_problems(bytes(source).decode("utf-8", "replace"))
                if problems:   # the counter enforces the same rules when it loads the solver: a source outside the subset could not be counted at all
                    raise Rejected("a counted round runs solvers in a restricted subset of Python (pure computation: no sys, files, frames, getattr/type/eval, dunder attributes) "
                                   "and this source is outside it: " + "; ".join(problems[:5]))
            entry = append_log(d, "submission", {"id": sid, "handle": handle, "sha256": digest, "size": len(source),
                                                 "publish_source": bool(publish_source)}, now)
            meta = {"id": sid, "handle": handle, "family": r["family"], "file": fname, "sha256": digest, "size": len(source),
                    "submitted_at": now, "publish_source": bool(publish_source), "warnings": warnings, "state": "queued",
                    "seq": entry["seq"], "log_hash": entry["hash"], "result": None, "reason": ""}
            _write_json(os.path.join(sdir, "meta.json"), meta)
            if new_token:
                handles[key] = sha256(new_token)
                _write_json(os.path.join(d, "handles.json"), handles)
        except BaseException:
            shutil.rmtree(sdir, ignore_errors=True)  # a rejected or failed submission leaves nothing behind
            raise
    out = {"id": sid, "seq": meta["seq"], "hash": meta["log_hash"], "sha256": digest, "warnings": warnings, "round": rid}
    if new_token:
        out["token"] = new_token
    return out


def _logged_submissions(d):
    """{submission id: log entry} for every well-formed submission entry; malformed entries (a damaged log) are skipped, never fatal."""
    out = {}
    for e in read_log(d):
        data = e.get("data") if isinstance(e, dict) else None
        if e.get("kind") == "submission" and isinstance(data, dict) and data.get("id") and data.get("sha256"):
            out[data["id"]] = e
    return out


def check_consistency(base, rid, hash_files=False):
    """Cross-check the log against what is stored. Returns a list of problems (empty = consistent). The log commits to every accepted
    file's hash, so: a logged submission with nothing stored (a crash between the log append and the metadata write), a stored
    submission with no matching log entry, and (hash_files=True, which reads every file) a file that no longer matches its logged hash."""
    d = rdir(base, rid)
    logged = _logged_submissions(d)
    stored = {m["id"]: m for m in list_submissions(base, rid)}
    problems = []
    for sid, e in sorted(logged.items()):
        if sid not in stored:
            problems.append(f"log entry #{e['seq']} (submission {sid}) has no stored submission")
    for sid, m in sorted(stored.items()):
        e = logged.get(sid)
        if e is None or e["hash"] != m["log_hash"] or e["data"]["sha256"] != m["sha256"]:
            problems.append(f"stored submission {sid} has no matching log entry")
        elif hash_files:
            try:
                with open(os.path.join(d, "submissions", sid, m["file"]), "rb") as f:
                    actual = sha256(f.read())
            except OSError:
                actual = None
            if actual != e["data"]["sha256"]:
                problems.append(f"submission {sid}: the stored file does not match its logged hash (swapped or missing after acceptance)")
    return problems


def get_submission(base, rid, sid):
    if not re.fullmatch(r"[0-9a-f]{12}", sid or ""):
        raise KeyError(sid)
    m = _read_json(os.path.join(rdir(base, rid), "submissions", sid, "meta.json"))
    if m is None:
        raise KeyError(sid)
    return m


# ---------------------------------------------------------------- evaluation and reveal (operator side)
def _save_meta(base, rid, m):
    _write_json(os.path.join(rdir(base, rid), "submissions", m["id"], "meta.json"), m)


def evaluate_round(base, rid, seed_dir, sandbox_ok, now=None, runner=subprocess.run, only_one=False, allow_code_change=False, results_dir=None, allow_unsandboxed=False):
    """Evaluate every queued submission of a CLOSED round in the docker sandbox, against exactly the round's committed seeds.
    sandbox_ok: callable returning True only if the sandbox is verified (portal.sandbox_verified). Refuses otherwise.
    Also refuses if the ladder, baseline or scoring code differ from what entry 0 of the log committed to; allow_code_change
    proceeds anyway but writes a public `code_changed` entry with the old and new hashes.
    A COUNTED round (create_round(count=...)) is not evaluated in the sandbox: its submissions are run, UNSANDBOXED, under step counting, so the operator must say
    so (allow_unsandboxed) and should do it as a throwaway user or VM that cannot read anything of value. What stops a solver from cheating there is that its
    source is public and every count can be re-executed by anyone: a solver that behaves differently on the operator's machine (reading a seed file, say) is exposed
    by the first re-run. The interpreter and the counting program must be the ones the round committed to, whatever allow_code_change says: other ones count differently."""
    now = now or time.time()
    _require(base, rid)
    r0 = get_round(base, rid)
    if r0.get("cost_model") == "count":
        import counted
        c = r0["count"]
        if not allow_unsandboxed:
            raise Rejected("REFUSED: this is a COUNTED round: its submissions run unsandboxed under step counting (anyone re-executes the counts to check them). Run the worker as a "
                           "throwaway user or VM that holds nothing of value, then pass --unsandboxed")
        if os.geteuid() == 0:
            raise Rejected("REFUSED: a counted round runs submitted code as the user running the worker, and that user is root. Use an unprivileged throwaway user")
        if not counted.supported() or counted.python_version() != c["python"]:
            raise Rejected(f"REFUSED: this round counts on {c['python']} and this machine runs {counted.python_version()}: counts from another interpreter would not reproduce")
        if counted.counter_sha256() != c["counter_sha256"]:
            raise Rejected("REFUSED: count_runner.py is not the counting program this round committed to; another counter would count the same program differently")
    elif not sandbox_ok():
        raise Rejected("REFUSED: the sandbox is not verified (or its files changed since it was); nothing was evaluated")
    d = rdir(base, rid)
    # ONE worker for the whole data directory, not one per round: every evaluation writes the same global leaderboard file, and two
    # rounds evaluating at once would race on it. The lock dies with its process, so a crashed worker never blocks a restart.
    wfd = os.open(os.path.join(base, ".worker.lock"), os.O_CREAT | os.O_RDWR, 0o660)
    try:
        fcntl.flock(wfd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(wfd)
        raise Rejected("another worker is already evaluating this round")
    try:
        return _evaluate_locked(base, rid, seed_dir, now, runner, only_one, allow_code_change, results_dir)
    finally:
        fcntl.flock(wfd, fcntl.LOCK_UN)
        os.close(wfd)


def _evaluate_counted_submission(base, rid, r, m, path, seed_dir, results_dir, now):
    """Count one submission (and, once per seed, the baseline) on the round's declared ladder, then score it exactly as a certificate would. Sets m's state, result
    and reason; never raises for a failure of the evaluation itself (that is a failed submission, with the details in a file the export never touches)."""
    import certificate
    import counted
    d = rdir(base, rid)
    results_dir = os.path.abspath(results_dir or os.path.join(HERE, "results"))
    c = r["count"]
    baseline = judge.default_baseline(r["family"])
    try:
        os.makedirs(results_dir, exist_ok=True)
        for seed_file, h in official.verified_seeds(seed_dir):
            stale = os.path.join(results_dir, f"judged_{r['family']}_{h[:8]}_submission_{os.path.basename(path)}.jsonl")
            if os.path.exists(stale):   # a worker that died mid-ladder: keep what it wrote (moved aside, not deleted) and count again
                os.replace(stale, f"{stale}.stale-{int(now)}")
            counted.evaluate_seed(r["family"], seed_file, path, baseline, c["dims"], c["n"], c["cap"], results_dir, reuse_baseline=True)
        cert = certificate.build(r["family"], path, seed_dir, reveal_seeds=False, results_dir=results_dir, round_data=base, round_id=rid)
        got = cert.get("count") or {}
        if any(got.get(k) != c.get(k) for k in ("dims", "n", "cap", "steps_per_second", "python", "counter_sha256")):
            raise certificate.CertificateError("the ladders just written do not match the round's declared counted configuration")
        claim = cert["claim"]
    except (OSError, SystemExit, certificate.CertificateError, KeyError, ValueError, TypeError) as e:
        m["state"], m["reason"] = "failed", "evaluation failed; the operator has the details"
        with open(os.path.join(d, "submissions", m["id"], "eval_error.log"), "w", encoding="utf-8", errors="replace") as f:
            f.write(f"{type(e).__name__}: {str(e)[-300:]}\n")
        return
    m["result"] = {"credit": claim["credit_bits"], "status": claim["status"], "per_seed": claim["per_seed"], "reasons": claim["reasons"]}
    m["state"], m["reason"] = "done", ""


def _evaluate_locked(base, rid, seed_dir, now, runner, only_one, allow_code_change, results_dir=None):
    d = rdir(base, rid)
    with locked(os.path.join(d, ".lock")):
        r = get_round(base, rid)
        if r["state"] == "open":
            raise Rejected("the round is still open; close it first")
        if r["state"] in ("evaluated", "revealed"):
            return 0
        cfile = _read_json(os.path.join(os.path.abspath(os.path.expanduser(seed_dir)), official.COMMITMENTS), {})
        if sorted(cfile.get("commitments", [])) != r["commitments"]:
            raise Rejected("the seed directory's commitments are not this round's commitments")
        now_fp = code_fingerprint(r["family"], r["count"]) if r.get("count") else code_fingerprint(r["family"])   # (one argument for a timed round, as it always was)
        changes = fingerprint_changes(r.get("fingerprint") or {}, now_fp)
        if changes:
            names = ", ".join(sorted(changes))
            if not allow_code_change:
                raise Rejected(f"REFUSED: the rules changed since the round was created ({names}). Evaluating would score submissions under "
                               "rules they were not submitted under. Create a new round, or pass --accept-code-change to proceed with a public log entry.")
            already = {k for e in read_log(d) if e["kind"] == "code_changed" for k in e["data"]["changed"]}
            if not set(changes) <= already:
                append_log(d, "code_changed", {"changed": sorted(changes), "old": {k: v[0] for k, v in changes.items()},
                                               "new": {k: v[1] for k, v in changes.items()}}, now)
        if r["state"] == "closed":
            _set_state(d, r, "evaluating", now, "evaluation_started")
    done = 0
    logged = {sid: e["data"]["sha256"] for sid, e in _logged_submissions(d).items()}
    for m in list_submissions(base, rid):
        if m["state"] not in ("queued", "evaluating"):  # "evaluating" here means a previous worker died mid-run: we hold the only lock, so retry it
            continue
        path = os.path.join(d, "submissions", m["id"], m["file"])
        # The log commits to this file's hash. Run the file ONLY if it still matches: a file swapped after acceptance (by anyone with
        # write access to the data directory) must never be evaluated while the log still verifies.
        try:
            with open(path, "rb") as f:
                actual = sha256(f.read())
        except OSError:
            actual = None
        if actual is None or actual != m["sha256"] or logged.get(m["id"]) != m["sha256"]:
            m["state"], m["reason"] = "failed", "the stored file does not match its logged hash; it was not run"
            with open(os.path.join(d, "submissions", m["id"], "eval_error.log"), "w", encoding="utf-8", errors="replace") as f:
                f.write(f"the stored file does not match its logged hash: stored file {actual}; submission record {m['sha256']}; log {logged.get(m['id'])}\n")
            _save_meta(base, rid, m)
            done += 1
            continue
        m["state"] = "evaluating"
        _save_meta(base, rid, m)
        if r.get("cost_model") == "count":
            _evaluate_counted_submission(base, rid, r, m, path, seed_dir, results_dir, now)
            _save_meta(base, rid, m)
            done += 1
            if only_one:
                break
            continue
        plan = official.plan_cost(r["family"], len(r["commitments"]), n=r["n"], budget=r["budget"])
        try:
            p = runner([sys.executable, os.path.join(HERE, "official.py"), "evaluate", "--family", r["family"], "--submission", path,
                        "--seed-dir", seed_dir, "--sandbox", "docker", "--reuse-baseline", "--n", str(r["n"])], cwd=HERE, capture_output=True, text=True,
                       timeout=plan["worst_case_cpu_hours"] * 3600 * 1.5 + 600)
            rc, tail = p.returncode, (p.stdout + p.stderr)[-300:]
        except subprocess.TimeoutExpired:
            rc, tail = 1, "evaluation exceeded its time allowance"
        if rc == 0:
            board = _read_json(judge.BOARD, [])
            stem = os.path.splitext(m["file"])[0]
            row = next((x for x in judge.leaderboard_rows(board) if x["name"] == stem and x["family"] == r["family"]), None)
            m["result"] = ({"credit": row["credit"], "status": row["status"], "per_seed": row["per_seed"], "reasons": row["reasons"]}
                           if row else None)
            m["state"] = "done" if row else "failed"
            m["reason"] = "" if row else "evaluation finished but produced no board entry"
        else:
            # The raw output can contain the operator's seed paths or seed text (a traceback), and `reason` is shown publicly once the
            # round is evaluated, before the reveal. Keep the output in a file the export never touches; publish only a generic reason.
            m["state"], m["reason"] = "failed", "evaluation failed; the operator has the details"
            with open(os.path.join(d, "submissions", m["id"], "eval_error.log"), "w", encoding="utf-8", errors="replace") as f:
                f.write(tail)
        _save_meta(base, rid, m)
        done += 1
        if only_one:
            break
    with locked(os.path.join(d, ".lock")):
        r = get_round(base, rid)
        subs = list_submissions(base, rid)
        if r["state"] == "evaluating" and not any(m["state"] in ("queued", "evaluating") for m in subs):
            results = {m["id"]: m["result"] for m in subs}
            _set_state(d, r, "evaluated", now, "round_evaluated", {"results_sha256": sha256(canonical(results)), "count": len(subs)})
    return done


def reveal(base, rid, seed_dir, now=None):
    """Publish the seeds of an EVALUATED round, only if every one hashes to a commitment the round published at creation."""
    now = now or time.time()
    _require(base, rid)
    d = rdir(base, rid)
    with locked(os.path.join(d, ".lock")):
        r = get_round(base, rid)
        if r["state"] == "revealed":
            return _read_json(os.path.join(d, "reveal.json"))
        if r["state"] != "evaluated":
            raise Rejected("seeds are revealed only after every submission has been evaluated")
        try:
            pairs = official.verified_seeds(seed_dir)
        except SystemExit as e:
            raise Rejected(str(e))
        seeds = {}
        for path, h in pairs:
            with open(path, "rb") as f:
                seeds[h] = f.read().strip().decode()
        if sorted(seeds) != r["commitments"]:
            raise Rejected("the seed files do not match this round's commitments one for one")
        _write_json(os.path.join(d, "reveal.json"), seeds)
        _set_state(d, r, "revealed", now, "seeds_revealed", {"seeds": seeds})
        return seeds


# ---------------------------------------------------------------- public export (what the web tier and the static site show)
def public_submission(base, rid, m, r):
    out = {"id": m["id"], "handle": m["handle"], "sha256": m["sha256"], "submitted_at": m["submitted_at"], "seq": m["seq"],
           "log_hash": m["log_hash"], "state": m["state"],
           # the static-check warnings quote line numbers and the modules and calls a solver uses: for a solver its owner keeps private they are shown to its
           # owner when they submit (the receipt) and are not published
           "warnings": m["warnings"] if m["publish_source"] else []}
    if r["state"] in ("evaluated", "revealed"):
        out["result"], out["reason"] = m.get("result"), m.get("reason", "")
    if r["state"] == "revealed" and _public_cert_is_safe(base, rid, m):
        # the public certificate is always downloadable; it carries the solver's source only if the submitter opted in (otherwise it is a private-solver
        # copy and the full one, with the source, needs the handle's token)
        out["certificate"] = {"path": f"/api/cert/{rid}/{m['id']}.json", "private": not m["publish_source"]}
        if not m["publish_source"]:
            out["certificate"]["full_path"] = f"/api/cert-full/{rid}/{m['id']}.json"
    if r["state"] == "revealed" and m["publish_source"]:
        with open(os.path.join(rdir(base, rid), "submissions", m["id"], m["file"]), "rb") as f:
            raw = f.read()
        if sha256(raw) == m["sha256"]:  # publish the source only if it is still exactly what the log committed to
            out["source"] = raw.decode("utf-8", "replace")
        else:
            out["source_note"] = "the stored file does not match its logged hash, so the source is not published"
    return out


def public_round(base, rid):
    r = get_round(base, rid)
    ok, n, head, err = verify_log(rdir(base, rid), r["commitments"])
    out = {k: r[k] for k in ("id", "title", "family", "commitments", "opens_at", "closes_at", "state", "n", "budget")}
    out["max_submissions"] = r.get("max_submissions", MAX_PER_ROUND)
    out["allow_private"] = r.get("allow_private", True)
    out["cost_model"] = r.get("cost_model", "time")
    out["count"] = r.get("count")
    out["fingerprint"] = r.get("fingerprint")
    out["consistency_problems"] = check_consistency(base, rid)  # cheap mode: compares records, never reads the source files
    out.update({"log_ok": ok, "log_entries": n, "log_head": head, "log_error": err,
                "submissions": [public_submission(base, rid, m, r) for m in list_submissions(base, rid)]})
    if r["state"] == "revealed":
        out["seeds"] = _read_json(os.path.join(rdir(base, rid), "reveal.json"), {})
    return out


def export_public(base, out_dir):
    """Write rounds.json, round_<id>.json and each round's log.jsonl for the static site and for third-party verification."""
    os.makedirs(out_dir, exist_ok=True)
    index = []
    for r in list_rounds(base):
        pr = public_round(base, r["id"])
        _write_json(os.path.join(out_dir, f"round_{r['id']}.json"), pr)
        # copyfile, not copy: copy would carry over the source's group-only mode (0660) and the web server could not read the export
        shutil.copyfile(os.path.join(rdir(base, r["id"]), "log.jsonl"), os.path.join(out_dir, f"log_{r['id']}.jsonl"))
        index.append({k: pr[k] for k in ("id", "title", "family", "commitments", "opens_at", "closes_at", "state", "log_ok", "log_head")}
                     | {"submissions": len(pr["submissions"])})
        if pr["state"] == "revealed":  # the PUBLIC certificates: full ones (source published by its owner) and private-solver copies (no source). Never `.full.`
            for m in list_submissions(base, r["id"]):
                src = cert_file(base, r["id"], m["id"])
                if _public_cert_is_safe(base, r["id"], m):
                    os.makedirs(os.path.join(out_dir, f"certs_{r['id']}"), exist_ok=True)
                    shutil.copyfile(src, os.path.join(out_dir, f"certs_{r['id']}", f"{m['id']}.cert.json"))
    _write_json(os.path.join(out_dir, "rounds.json"), index)
    return index


# ---------------------------------------------------------------- certificates (operator builds them after the reveal; submitters download them)
def cert_file(base, rid, sid, full=False):
    """The PUBLIC certificate of a submission (`full` False): the full one when the owner published their source, otherwise a private-solver copy with
    no source and no failure text. `full` True: the full certificate of a submission whose source was NOT published (token-gated); it exists only then."""
    return os.path.join(rdir(base, rid), "certs", f"{sid}.full.cert.json" if full else f"{sid}.cert.json")


def _public_cert_is_safe(base, rid, m):
    """May this submission's PUBLIC certificate be served? Only if it exists and does not leak a solver its owner kept private: for a submission whose
    source was not published it must actually be a private-solver certificate (marked so, with no source). Checked on every release, not just when it is
    built, so a stale file from an older version or a mistake by the operator fails CLOSED instead of publishing someone's algorithm."""
    path = cert_file(base, rid, m["id"])
    try:
        st = os.stat(path)
    except OSError:
        return False
    if m["publish_source"]:
        return True
    key = (path, st.st_mtime_ns, st.st_size)       # the round description is polled: parse a certificate once per version of the FILE, not once per request
    if key in _SAFE_CACHE:
        return _SAFE_CACHE[key]
    try:
        with open(path, encoding="utf-8") as f:
            c = json.load(f)
        ok = isinstance(c, dict) and c.get("private") is True and isinstance(c.get("submission"), dict) and c["submission"].get("source") is None
    except (OSError, ValueError):
        ok = False
    if len(_SAFE_CACHE) > 4096:
        _SAFE_CACHE.clear()
    _SAFE_CACHE[key] = ok
    return ok


_SAFE_CACHE = {}


def _store_cert(dest, cert):
    tmp = dest + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cert, f, indent=1, sort_keys=True)
    os.chmod(tmp, 0o644)  # served by the web tier's user
    os.replace(tmp, dest)


def build_certificates(base, rid, seed_dir, results_dir=None):
    """Operator side. After the reveal, build the certificates of every evaluated submission and store them beside the round. A certificate is stored
    only if it verifies; one that does not is reported, never published. Existing certificates are left alone.
    A submission whose owner published their source gets one public full certificate. One who did not gets TWO: a public private-solver copy (no source,
    no failure text: anyone can verify everything except re-running it) and the full certificate, served only to the owner.
    -> {"built": [submission ids], "skipped": {submission id: reason}}"""
    import certificate  # certificate imports rounds, so this cannot be a module-level import
    _require(base, rid)
    r = get_round(base, rid)
    if r["state"] != "revealed":
        raise Rejected(f"round {rid} is {r['state']!r}: certificates carry the seeds, so they are built only after the reveal")
    out = {"built": [], "skipped": {}}
    cdir = os.path.join(rdir(base, rid), "certs")
    os.makedirs(cdir, exist_ok=True)
    for m in list_submissions(base, rid):
        sid, dest = m["id"], cert_file(base, rid, m["id"])
        if m["state"] != "done" or not m.get("result"):
            out["skipped"][sid] = f"not evaluated successfully (state {m['state']})"
            continue
        if os.path.exists(dest) and _public_cert_is_safe(base, rid, m):
            out["skipped"][sid] = "already built"
            continue   # (an existing public file that would leak a private solver is NOT "built": it is rebuilt, replacing it)
        path = os.path.join(rdir(base, rid), "submissions", sid, m["file"])
        try:
            with open(path, "rb") as f:
                if sha256(f.read()) != m["sha256"]:
                    out["skipped"][sid] = "the stored file does not match its logged hash"
                    continue
            cert = certificate.build(r["family"], path, seed_dir, reveal_seeds=True, results_dir=results_dir, round_data=base, round_id=rid)
            public = cert if m["publish_source"] else certificate.make_private(cert)
            bad = []
            for label, c in (("full", cert), ("public", public)) if public is not cert else (("full", cert),):
                res = certificate.verify(c)
                if not res["ok"]:
                    bad.append(f"the {label} certificate does not verify: " + "; ".join(x["check"] for x in res["checks"] if x["status"] == "fail"))
            if bad:
                out["skipped"][sid] = "; ".join(bad)
                continue
        except (certificate.CertificateError, OSError, SystemExit, KeyError, ValueError, TypeError) as e:
            out["skipped"][sid] = f"could not be built: {str(e)[:200]}"
            continue
        if public is not cert:
            _store_cert(cert_file(base, rid, sid, full=True), cert)   # first: the public copy's presence is what marks the submission as done
        _store_cert(dest, public)
        out["built"].append(sid)
    return out


def cert_for_download(base, rid, sid, token=None, full=False):
    """The path of a submission's certificate if the caller may have it. `full` False: the PUBLIC certificate, for anyone (no source unless the owner
    published it). `full` True: the full certificate with the solver's source: anyone when the owner published it, otherwise only with the handle's token.
    KeyError: no such certificate. Rejected: not allowed."""
    m = get_submission(base, rid, sid)
    public = cert_file(base, rid, sid)
    if not os.path.exists(public):
        raise KeyError(sid)
    if not full or m["publish_source"]:
        if not _public_cert_is_safe(base, rid, m):
            raise Rejected("this certificate is not ready for public release (it would show a solver its owner kept private): the operator must rebuild it with ops.py certs")
        return public
    stored = _read_json(os.path.join(rdir(base, rid), "handles.json"), {}).get(m["handle"].lower())
    if token and stored and secrets.compare_digest(sha256(token), stored):
        path = cert_file(base, rid, sid, full=True)
        if os.path.exists(path):
            return path
        raise KeyError(sid)
    raise Rejected("the full certificate contains the submitter's solver source, which was not published: it is available only with the handle's token")
