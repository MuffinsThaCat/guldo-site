"""The `guldo` command: the client, and `guldo <tool>` for the other tools. See `guldo tools`."""
import importlib
import inspect
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "_src")
TOOLS = {
    "claims": ("claims", "benchmark score, worst case, verified negative result or a comparison of two solvers from verified certificates; `claims check` recomputes a claim file"),
    "counted": ("counted", "step counting: `counted check SOLVER --family F --dim D` (is it deterministic and inside the restricted subset?), `counted evaluate`"),
    "tflops": ("tflops", "exact operation counts for AI workloads (inference, training): `tflops practice SOLVER --baseline REF --family aitrain --dims 32 40 48`, `tflops claim`, `tflops verify`"),
    "gpu-roofline": ("gpu_roofline", "does the roofline model predict real kernel times on THIS device? `gpu-roofline calibrate --out F.json` (needs PyTorch; any GPU or the CPU), `check F.json`, `agree A.json B.json`"),
    "tflops-mem": ("tflops_mem", "like tflops, and also exact bytes moved, precision (fp32/fp16 casts) and peak memory per instance: `tflops-mem practice SOLVER --baseline REF --family aitrain --dims 32 40 48`"),
    "tflops-compare": ("tflops_compare", "compare two solvers with each other on counted ladders, instance by instance: `tflops-compare compare BASELINE A B`; `tflops-compare check` recomputes the file"),
    "attest": ("attest", "sign and check independent attestations of a certificate"),
    "cert": ("certificate", "build and verify certificates (the standalone verifier). Not `guldo certificate`: that is the client's own command, which downloads one"),
    "compile": ("compile_domain", "declare a new problem and compile it into a challenge"),
    "kinds": ("compile_kinds", "run a non-speed declaration (KIND advantage / oracle / precomp / quantum): `kinds evaluate|score|compare|replay`; declare one with `compile init NAME --kind K`"),
    "intake": ("intake", "propose a problem to an operator (`intake pack`); for operators: receive, trial, accept or reject a proposal (set SVP_INTAKE_DIR first)"),
    "export": ("export_bundle", "export a compiled challenge as a platform-neutral bundle (checker, scorer, power analysis); `export verify DIR` re-checks one"),
    "ops": ("ops", "operator tools: create, close, evaluate, reveal, export rounds"),
    "lint": ("submit_check", "pre-flight check of a solver file"),
    "judge": ("judge", "the judge (seeds, evaluate, leaderboard)"),
    "log": ("translog", "the public certificate log: `log check --log URL`, `log prove`, `log verify-inclusion`, `log witness` (needs the [attest] extra for signatures)"),
    "runattest": ("runattest", "the sandbox operator's run attestation: `runattest make CERT --results DIR --key K` signs only if the operator's own records ARE the certificate's ladders; `runattest check`"),
}


def _version():
    from importlib.metadata import version
    for dist in ("guldo-cli", "guldo"):
        try:
            return version(dist)
        except Exception:
            continue
    return "unknown"


class _Hints:
    """Tools print follow-up commands as `python3 NAME.py ...`, which does not exist for someone who installed the package: say `guldo TOOL ...` instead. A text rewrite of
    the output only; the tool itself is untouched (some are pinned by hash in pre-registrations). Lines are written whole, so progress still streams."""
    def __init__(self, out):
        self.out = out
        self.names = {mod: name for name, (mod, _) in TOOLS.items()}

    def write(self, s):
        import re
        return self.out.write(re.sub(r"python3 (\w+)\.py ", lambda m: f"guldo {self.names[m.group(1)]} " if m.group(1) in self.names else m.group(0), s))

    def __getattr__(self, name):
        return getattr(self.out, name)


def _call(module, rest, prog):
    fn = importlib.import_module(module).main
    sys.argv = [prog] + rest
    try:
        takes_argv = bool(inspect.signature(fn).parameters)
    except (TypeError, ValueError):
        takes_argv = False
    real = sys.stdout
    sys.stdout = _Hints(real)
    try:
        return fn(rest) if takes_argv else fn()
    finally:
        sys.stdout = real


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if SRC not in sys.path:
        sys.path.insert(0, SRC)   # our modules first: a flat name like `judge` or `harness` must never resolve to something else installed
    if argv[:1] in (["--version"], ["-V"]):
        print(f"guldo {_version()}")
        return 0
    if argv[:1] == ["tools"]:
        print("guldo <tool> ...   (guldo --help shows the client's own commands)\n")
        for name, (_, what) in sorted(TOOLS.items()):
            print(f"  guldo {name:12s} {what}")
        return 0
    if argv and argv[0] in TOOLS:
        return _call(TOOLS[argv[0]][0], argv[1:], f"guldo {argv[0]}")
    import svp   # the client module keeps its file name; only the command a person types is `guldo`
    svp.PROG = "guldo"
    return svp.main(argv)


if __name__ == "__main__":
    sys.exit(main())
