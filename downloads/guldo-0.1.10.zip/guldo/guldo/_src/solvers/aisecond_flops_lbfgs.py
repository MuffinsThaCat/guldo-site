"""aisecond in the counted-operations API, TECHNIQUE: L-BFGS (a quasi-Newton method). It never forms the Hessian: it rebuilds an approximate inverse-Hessian product from the last M pairs of
(step, gradient change) with the two-loop recursion, then takes an EXACT line search along that direction (a few one-dimensional Newton steps on the loss's derivative, which cost O(N) each
because X times the direction is computed once). Stops when |g|^2/(2 lambda) <= 1e-9."""
import math

import tensorops as tp

RHO = 0.97
LAM = 1e-4
M = 12
MAXITER = 400
GRAD2 = 2e-13
LINE = 6


def solve(seed, d, n, labels):
    U = tp.tensor([[RHO ** (j - k) if j >= k else 0.0 for j in range(d)] for k in range(d)])
    X = (tp.reshape(tp.stream(seed, 0, n * d), (n, d)) @ U) * math.sqrt(1.0 - RHO * RHO)
    y = tp.tensor([float(v) for v in labels])
    Xt = tp.transpose(X, (1, 0))
    w = tp.zeros((d,))
    z = X @ w
    g = Xt @ (1.0 / (1.0 + tp.exp(-z)) - y) * (1.0 / n) + w * LAM
    S = []
    Y = []
    RH = []
    for it in range(MAXITER):
        g2 = tp.sum(g * g).item()
        if g2 <= GRAD2:
            break
        q = g
        al = []
        for i in range(len(S) - 1, -1, -1):
            a = RH[i] * tp.sum(S[i] * q).item()
            al.append(a)
            q = q - Y[i] * a
        if S:
            q = q * (tp.sum(S[-1] * Y[-1]).item() / tp.sum(Y[-1] * Y[-1]).item())
        else:
            q = q * (1.0 / (tp.sum(X * X).item() / (4.0 * n) + LAM))
        for i in range(len(S)):
            b = RH[i] * tp.sum(Y[i] * q).item()
            q = q + S[i] * (al[len(S) - 1 - i] - b)
        dirn = -q
        xd = X @ dirn
        t = 1.0
        wd = tp.sum(w * dirn).item()
        dd = tp.sum(dirn * dirn).item()
        for k in range(LINE):
            pt = 1.0 / (1.0 + tp.exp(-(z + xd * t)))
            f1 = tp.sum((pt - y) * xd).item() * (1.0 / n) + LAM * (wd + t * dd)
            f2 = tp.sum(pt * (1.0 - pt) * xd * xd).item() * (1.0 / n) + LAM * dd
            t = t - f1 / f2
        s = dirn * t
        w = w + s
        z = z + xd * t
        g_new = Xt @ (1.0 / (1.0 + tp.exp(-z)) - y) * (1.0 / n) + w * LAM
        yv = g_new - g
        sy = tp.sum(s * yv).item()
        if sy > 1e-30:
            S.append(s)
            Y.append(yv)
            RH.append(1.0 / sy)
            if len(S) > M:
                S.pop(0)
                Y.pop(0)
                RH.pop(0)
        g = g_new
    return [int(v * 1048576.0) for v in w.tolist()]
