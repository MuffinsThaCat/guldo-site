"""Red-team: allocates and touches memory without bound. The container's memory limit must stop it; the judge must report a crash or a timeout,
never a solve, return in bounded time, leave no container behind, and still evaluate an honest solver afterwards."""


def solve(basis, bound2):
    hog = []
    while True:
        chunk = bytearray(256 * 1024 * 1024)
        chunk[::4096] = b"\x01" * (len(chunk) // 4096)   # touch every page so the memory is really resident
        hog.append(chunk)
