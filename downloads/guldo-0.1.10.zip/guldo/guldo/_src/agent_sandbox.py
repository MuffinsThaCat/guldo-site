"""Where agent-written code runs: an optional CONTAINER backend for the code-running domains (coding, bugfix).

Both domains execute code the agent wrote, in a child process with resource limits and a cleared environment. That is NOT a security sandbox: hostile code runs as the verifier's user and can read
the secret seed file, the whole filesystem and the network. With GULDO_SANDBOX=docker the same child runs inside a container instead:

    docker run --rm -i --name guldo-<random> --network none --read-only --tmpfs /tmp:rw,noexec,nosuid,size=64m --memory 768m --memory-swap 768m --pids-limit 64 --cpus 1
               --cap-drop ALL --security-opt no-new-privileges --user 65534:65534 -e PYTHONDONTWRITEBYTECODE=1 [-v WORKDIR:/work:ro] -w /work IMAGE python -I -c CHILD

No network, a read-only root, a small noexec tmpfs, no capabilities, one CPU, bounded memory and processes, an unprivileged user, and ONLY the generated package mounted (read-only): the seed file,
the home directory and the rest of the host are simply not there. Settings: GULDO_SANDBOX=docker, GULDO_SANDBOX_IMAGE (default python:3.12-slim), GULDO_DOCKER (the docker command).

  python3 agent_sandbox.py preflight        can a container start and run Python here? (the run, rounds and witness commands call this first: a broken sandbox must never read as "every agent failed")
  python3 agent_sandbox.py selftest         a hostile probe run THROUGH the active backend: it tries the network, the filesystem, the environment, a fork bomb and a memory hog, and reports what was blocked

STATUS, plainly: the command construction, the preflight and the failure handling are tested against a FAKE docker (an executable that records its arguments and runs the child locally). They have NOT
been run against a real Docker daemon, and Docker is not used on the laptop, so `selftest` under the docker backend has never been run by anyone: run it on the Linux server before trusting a result.
A container shares the host kernel: it is far stronger than the local mode and weaker than a virtual machine. Without GULDO_SANDBOX the local mode is unchanged.
"""
import os
import secrets
import shutil
import subprocess
import sys

import agent_core

DEFAULT_IMAGE = "python:3.12-slim"
MEM_MB = 768
PIDS = 64


class SandboxError(agent_core.AgentEvalError):
    """The sandbox itself could not run (no docker, no daemon, no image): NOT a statement about the agent's code."""


def mode():
    return "docker" if os.environ.get("GULDO_SANDBOX", "").strip().lower() == "docker" else "local"


def enabled():
    return mode() == "docker"


def docker_cmd():
    return os.environ.get("GULDO_DOCKER", "docker")


def image():
    return os.environ.get("GULDO_SANDBOX_IMAGE", DEFAULT_IMAGE)


def build_command(name, child_code, workdir=None, mem_mb=MEM_MB):
    """The argv of the container run (pure: no side effects, tested directly)."""
    cmd = [docker_cmd(), "run", "--rm", "-i", "--name", name, "--network", "none", "--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m", "--memory", "%dm" % mem_mb,
           "--memory-swap", "%dm" % mem_mb, "--pids-limit", str(PIDS), "--cpus", "1", "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--user", "65534:65534",
           "-e", "PYTHONDONTWRITEBYTECODE=1"]
    if workdir is not None:
        cmd += ["-v", "%s:/work:ro" % os.path.abspath(workdir), "-w", "/work"]
    return cmd + [image(), "python", "-I", "-c", child_code]


def run_python(child_code, payload, workdir=None, timeout=30, mem_mb=MEM_MB):
    """Run `python -I -c child_code` with `payload` on stdin. Returns (returncode, stdout), or (None, "") on a timeout (the agent's code ran too long). Local mode: a subprocess with a cleared
    environment, in `workdir` (the previous behaviour). Docker mode: the container above. Raises SandboxError if the docker backend itself fails."""
    if not enabled():
        try:
            p = subprocess.run([sys.executable, "-I", "-c", child_code], input=payload, capture_output=True, text=True, timeout=timeout, cwd=workdir, env={"PATH": os.environ.get("PATH", "")})
        except subprocess.TimeoutExpired:
            return None, ""
        return p.returncode, p.stdout
    name = "guldo-%s" % secrets.token_hex(6)
    try:
        p = subprocess.run(build_command(name, child_code, workdir, mem_mb), input=payload, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        subprocess.run([docker_cmd(), "kill", name], capture_output=True, timeout=30)          # killing the docker CLI does not stop the container
        return None, ""
    except FileNotFoundError:
        raise SandboxError("GULDO_SANDBOX=docker but %r is not installed" % docker_cmd())
    if p.returncode in (125, 126, 127) or "Cannot connect to the Docker daemon" in p.stderr or "Unable to find image" in p.stderr:
        raise SandboxError("the container did not start (exit %d): %s" % (p.returncode, p.stderr.strip()[:200]))
    return p.returncode, p.stdout


def preflight():
    """Run a trivial container once. Raises SandboxError unless Python ran inside it and answered. Local mode always passes (and is NOT a sandbox)."""
    if not enabled():
        return "local"
    rc, out = run_python("print('guldo-sandbox-ok')", "", None, timeout=120)
    if rc != 0 or "guldo-sandbox-ok" not in out:
        raise SandboxError("the container ran but Python did not answer as expected (exit %s)" % rc)
    return "docker"


def isolated(domain_name):
    """True when `domain_name` runs agent-written code AND the container backend is active and working (the seed file is then not visible to that code). Runs the preflight whenever the backend is
    on, so a sandbox that cannot start raises SandboxError instead of silently making every agent fail. False for a domain that runs no code, and for local mode."""
    if not agent_core.runs_code(domain_name):
        return False
    if enabled():
        preflight()
        return True
    return False


# ---- the hostile probe ------------------------------------------------------------------------------------------------------------------------------------------

PROBE = r'''
import json, os, socket, sys, time
res = {}
def emit(obj):
    sys.__stdout__.write(json.dumps(obj) + "\n"); sys.__stdout__.flush()
def attempt(name, fn):
    emit({"start": name})                 # a process killed DURING an attempt (the memory hog, the fork bomb) leaves only this line: the parent then reports it as blocked by a limit
    try:
        r = {"blocked": False, "detail": str(fn())[:80]}
    except BaseException as e:
        r = {"blocked": True, "detail": type(e).__name__}
    emit({"name": name, "result": r})
def net():
    s = socket.create_connection(("1.1.1.1", 53), timeout=3); s.close(); return "connected"
def write_root():
    open("/guldo_probe_write", "w").write("x"); return "wrote /"
def write_work():
    open(os.path.join(os.getcwd(), "guldo_probe_write"), "w").write("x"); return "wrote the package directory"
def read_home():
    home = os.path.expanduser("~"); names = os.listdir(home); return "listed %s (%d entries)" % (home, len(names))
def read_etc():
    return "read /etc/passwd (%d bytes)" % len(open("/etc/passwd").read())
def host_secret():
    for p in json.loads(os.environ.get("PROBE_PATHS", "[]")):
        if os.path.exists(p): return "SEES " + p
    raise FileNotFoundError("no secret path visible")
def env():
    keys = [k for k in os.environ if k not in ("PATH", "PYTHONDONTWRITEBYTECODE", "HOME", "HOSTNAME", "LANG")]
    if keys: return "environment holds " + ",".join(sorted(keys))[:60]
    raise PermissionError("environment is empty")
def forks():
    kids = []
    try:
        for _ in range(200):
            pid = os.fork()
            if pid == 0:
                time.sleep(5); os._exit(0)
            kids.append(pid)
    finally:
        for k in kids:
            try: os.kill(k, 9)
            except Exception: pass
    return "forked %d children" % len(kids)
def memory():
    chunks = []
    for _ in range(40):
        chunks.append(bytearray(64 * 1024 * 1024))
    return "allocated %d MB" % (len(chunks) * 64)
for n, f in (("network", net), ("write /", write_root), ("write package dir", write_work), ("read home", read_home), ("read /etc/passwd", read_etc), ("host secret path", host_secret), ("environment", env),
             ("fork bomb (200 children)", forks), ("memory hog (2.5 GB)", memory)):
    attempt(n, f)
'''


def selftest(probe_paths=()):
    """Run the hostile probe through the ACTIVE backend. Returns (mode, {attempt: {"blocked": bool, "detail": str}})."""
    import json
    preflight()
    env_paths = json.dumps(list(probe_paths))
    code = "import os\nos.environ['PROBE_PATHS'] = %r\n" % env_paths + PROBE
    rc, out = run_python(code, "", None, timeout=120)
    if rc is None:
        raise SandboxError("the probe timed out")
    return mode(), parse_probe(out, rc)


def parse_probe(out, rc):
    """{attempt: {"blocked", "detail"}} from the probe's stream. An attempt that started and never reported (the process was killed by a limit) is BLOCKED; so is every attempt after it, because the
    process is gone: the unreached ones are listed as 'not reached' rather than counted either way."""
    import json
    res, started = {}, None
    for ln in out.split("\n"):
        try:
            o = json.loads(ln)
        except ValueError:
            continue
        if isinstance(o, dict) and "start" in o:
            started = o["start"]
        elif isinstance(o, dict) and "name" in o and isinstance(o.get("result"), dict):
            res[o["name"]] = o["result"]
            started = None
    if started is not None:
        res[started] = {"blocked": True, "detail": "the process was killed by a limit (exit %s)" % rc}
    return res


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("preflight")
    p = sub.add_parser("selftest")
    p.add_argument("--secret-path", action="append", default=[], help="a host file the probe must NOT be able to see (e.g. your seed file)")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "preflight":
            print("sandbox backend: %s%s" % (preflight(), "" if enabled() else "  (NOT a sandbox: set GULDO_SANDBOX=docker)"))
        else:
            m, res = selftest(a.secret_path)
            print("backend: %s" % m)
            leaked = 0
            for name, r in res.items():
                print("%-28s %s  (%s)" % (name, "BLOCKED" if r["blocked"] else "ALLOWED", r["detail"]))
                leaked += 0 if r["blocked"] else 1
            if m == "local":
                print("\nlocal mode: %d of %d hostile actions were ALLOWED. That is expected here and is why local mode is not a sandbox." % (leaked, len(res)))
                return 0
            print("\n%s" % ("every hostile action was blocked" if not leaked else "%d hostile action(s) were ALLOWED: do NOT trust this sandbox" % leaked))
            return 0 if not leaked else 1
    except SandboxError as e:
        print("sandbox error: %s" % e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
