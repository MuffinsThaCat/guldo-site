"""The Internet Archive as a third-party holder of the certificate log's heads. Standard library only. Run the tests: python3 -m unittest test_webarchive -v

What this gives and what it does not. Asking the Wayback Machine to save `checkpoint.json` leaves a dated copy that a third party holds and the operator cannot edit. A reader can then
fetch the copies the Archive holds (found through the Archive's own index, not through anything the operator says) and check each is a head the operator really signed and that it is
consistent with the log as served now. It is NOT a witness: nobody checked the log, and the Archive is a single organisation that throttles and can be down. Everything here is best effort
and reports `throttled` / `unreachable` honestly instead of guessing.

Nothing is believed because of a response header. After a save request the snapshot is found through the availability API and its raw bytes are compared with what we published; a
snapshot a reader fetches is hostile input until its signature and its place in the log have been checked (that part lives in translog.archive_audit). Network access is injected."""
import json
import urllib.error
import urllib.parse
import urllib.request

SAVE = "https://web.archive.org/save/"
AVAILABLE = "https://archive.org/wayback/available"
RAW = "https://web.archive.org/web/{ts}id_/{url}"
SNAPSHOT = "https://web.archive.org/web/{ts}/{url}"
MAX_BODY = 262_144           # a head is under 2 KB; anything near this is not one
USER_AGENT = "guldo-log/1 (+https://guldo.org/log)"
ARCHIVE_HOSTS = ("web.archive.org", "archive.org")


class ArchiveError(Exception):
    pass


class Throttled(ArchiveError):
    """HTTP 429 or 503: the Archive asked us to slow down. Not a failure of the log."""


class _SameHouse(urllib.request.HTTPRedirectHandler):
    """Follow a redirect only to https on the Archive's own hosts: a response is not allowed to send us elsewhere."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        u = urllib.parse.urlparse(newurl)
        if u.scheme != "https" or (u.hostname or "") not in ARCHIVE_HOSTS:
            return None
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def default_http(method, url, headers=None, timeout=90):
    """-> (status, final_url, body). https to the Archive only; never raises for an HTTP status; raises ArchiveError for a network failure."""
    u = urllib.parse.urlparse(url)
    if u.scheme != "https" or (u.hostname or "") not in ARCHIVE_HOSTS:
        raise ArchiveError(f"refusing an address that is not an https Archive address: {url[:70]}")
    req = urllib.request.Request(url, method=method, headers=dict(headers or {}, **{"User-Agent": USER_AGENT}))
    try:
        with urllib.request.build_opener(_SameHouse).open(req, timeout=timeout) as resp:
            return resp.status, resp.geturl(), resp.read(MAX_BODY + 1)[:MAX_BODY]
    except urllib.error.HTTPError as e:
        try:
            return e.code, url, e.read(2000)
        except OSError:
            return e.code, url, b""
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise ArchiveError(f"network failure: {type(e).__name__}")


def _ok(status):
    if status in (429, 503):
        raise Throttled(f"the Archive answered HTTP {status} (it throttles anonymous requests); try again later")
    return status


def snapshot_url(ts, url):
    return SNAPSHOT.format(ts=ts, url=url)


def valid_ts(ts):
    return isinstance(ts, str) and len(ts) == 14 and ts.isdigit()


def request_save(url, http=default_http):
    """Ask the Archive to capture `url` now. -> the HTTP status. Raises Throttled / ArchiveError. A 2xx does not prove a copy exists: see confirm_saved."""
    status, _, _ = http("GET", SAVE + url, None, 120)
    return _ok(status)


def closest(url, ts=None, http=default_http):
    """The snapshot the availability API names as nearest to `ts` (YYYYMMDDhhmmss, default now) -> {"timestamp", "url"} or None."""
    q = {"url": url}
    if ts:
        q["timestamp"] = ts
    status, _, body = http("GET", AVAILABLE + "?" + urllib.parse.urlencode(q), None, 40)
    _ok(status)
    if status != 200:
        raise ArchiveError(f"availability API: HTTP {status}")
    try:
        snap = json.loads(body.decode("utf-8"))["archived_snapshots"].get("closest")
    except (ValueError, KeyError, AttributeError, TypeError, UnicodeDecodeError):
        raise ArchiveError("availability API: unreadable answer")
    if not snap:
        return None
    t = snap.get("timestamp") if isinstance(snap, dict) else None
    if not valid_ts(t) or snap.get("available") is not True:
        return None
    return {"timestamp": t, "url": snapshot_url(t, url)}


def fetch_raw(url, ts, http=default_http):
    """The bytes the Archive holds for `url` at `ts`, exactly as captured (the id_ form: no rewriting, no toolbar)."""
    if not valid_ts(ts):
        raise ArchiveError("not an Archive timestamp")
    status, final, body = http("GET", RAW.format(ts=ts, url=url), None, 60)
    _ok(status)
    if status != 200:
        raise ArchiveError(f"the Archive has no raw copy at {ts} (HTTP {status})")
    return body


def confirm_saved(url, expected, http=default_http, since=None, polls=6, sleep=None, interval=10):
    """After request_save: is the nearest snapshot at or after `since` byte-identical to `expected` (what we published)? -> {"state", "timestamp", "url", "detail"}.
    state: "saved" (a snapshot at or after `since` has exactly these bytes), "stale" (the nearest snapshot holds different bytes: an older or another version),
    "absent" (no snapshot found), "throttled", "unreachable". The Archive can take a minute: `polls` tries `interval` seconds apart (`sleep` injectable)."""
    import time as _time
    sleep = sleep or _time.sleep
    last = {"state": "absent", "timestamp": None, "url": None, "detail": "the Archive names no snapshot of this address"}
    for i in range(polls):
        try:
            snap = closest(url, since, http)
            if snap is not None:
                if since and snap["timestamp"] < since:
                    last = {"state": "stale", "timestamp": snap["timestamp"], "url": snap["url"], "detail": f"the nearest snapshot ({snap['timestamp']}) is older than this save request ({since})"}
                else:
                    raw = fetch_raw(url, snap["timestamp"], http)
                    if raw == expected:
                        return {"state": "saved", "timestamp": snap["timestamp"], "url": snap["url"], "detail": "the Archive's copy is byte-identical to what was published"}
                    last = {"state": "stale", "timestamp": snap["timestamp"], "url": snap["url"], "detail": "the Archive's copy at that time differs from what was published"}
        except Throttled as e:
            return {"state": "throttled", "timestamp": None, "url": None, "detail": str(e)}
        except ArchiveError as e:
            last = {"state": "unreachable", "timestamp": None, "url": None, "detail": str(e)}
        if i + 1 < polls:
            sleep(interval)
    return last


def captures(url, stamps, http=default_http, limit=8):
    """Snapshots the Archive holds for `url`, found by asking about each timestamp in `stamps` (YYYYMMDDhhmmss) -> ([{"timestamp", "url", "raw"}], [notes]).
    Distinct snapshots only, at most `limit`. A reader uses this independently of anything the operator publishes about where copies are."""
    got, notes, seen = [], [], set()
    for st in stamps:
        if len(got) >= limit:
            break
        try:
            snap = closest(url, st, http)
            if snap is None or snap["timestamp"] in seen:
                continue
            seen.add(snap["timestamp"])
            got.append({"timestamp": snap["timestamp"], "url": snap["url"], "raw": fetch_raw(url, snap["timestamp"], http)})
        except Throttled as e:
            notes.append(str(e))
            break
        except ArchiveError as e:
            notes.append(str(e))
    return got, notes
