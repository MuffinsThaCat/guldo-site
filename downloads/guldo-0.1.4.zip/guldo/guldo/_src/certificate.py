"""Speedup certificates: one JSON file that proves a measured speedup to someone who does not trust the operator (see COMPILER.md).

  certificate.py build  --family F --submission solvers/x.py --seed-dir S [--reveal-seeds] [--round-data D --round-id R] --out x.cert.json
  certificate.py verify x.cert.json [--rerun K]

A certificate carries: the claim; the rules fingerprint (hashes of the estimator, harness, instance code and, for a declared domain, its
declaration, compiled ladder and reference solver); the seed commitments and (only with --reveal-seeds, i.e. after the reveal) the seeds;
both solvers' source; every raw per-instance record of every ladder; and the round's hash-chained log. `verify` needs nothing from the
operator. It checks, and reports each as PASS / FAIL / SKIP:

  rules      this checkout's protocol code hashes to the certificate's (a different estimator would score the same data differently)
  domain     a declared domain's files hash to what the certificate names, and load
  log        the hash chain verifies, entry 0 holds the commitments and the rules fingerprint, the submission's hash was logged
  seeds      each revealed seed hashes to a committed value
  sources    the solver sources are the ones the ladders were measured with (sha256 in every ladder header)
  coverage   re-derives every instance from the seeds; each ladder holds exactly those instances, for the same size set
  credit     recomputes every seed's credit from the raw records with this checkout's estimator and compares it with the claim
  rerun      (--rerun K, needs --execute) re-measures K instances on THIS machine: the solver must still solve them, and the speedup should reproduce

A certificate is untrusted input, so by default `verify` EXECUTES NOTHING from it: a declared domain's decl.py is hash-checked and read as data
(instance coverage of a declared domain is then SKIPPED). `--execute` imports that decl.py and, with --rerun, runs the solver sources, on this
machine, unsandboxed: use it only in a throwaway VM or container. Built-in families derive instances with this checkout's own code, no flag needed.

A certificate is as strong as its weakest link: without a log it can never be OFFICIAL (the commitment's publication cannot be shown);
a ladder measured in local mode is PROVISIONAL (only the Docker sandbox meters untrusted code); the verifier says which.

PRIVATE-SOLVER certificates. `make_private` (or `build --private`) removes the solver's source and every failure message from its ladders (a
traceback quotes the code); everything else is unchanged, including the solver's SHA-256, which the round's log committed to before the seeds were
revealed. A verifier can still check the log, the fingerprints, the questions, the rules and the credit arithmetic. What it cannot do is re-run the
solver or inspect it: the timings rest on the operator's sandbox, and the certificate says so. If the owner later publishes the file,
`verify --source FILE` checks that it hashes to the committed value and, with --rerun --execute, re-measures it: the certificate is then as strong
as a full one. A private-solver certificate hides the algorithm from the PUBLIC, not from the operator, who ran it. (Not to be confused with a
"sealed" certificate: one built before the reveal, without the seeds.)
"""
import argparse
import contextlib
import hashlib
import json
import math
import os
import random
import re
import secrets
import sys
import tempfile
import time

import declared
import extrapolate as E
import families
import harness
import judge
import official
import rounds

HERE = os.path.dirname(os.path.abspath(__file__))
FORMAT = "svp-certificate-v1"


class CertificateError(Exception):
    pass


def sha256(data):
    return hashlib.sha256(data if isinstance(data, bytes) else data.encode()).hexdigest()


def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _read(path):
    # newline="": NO translation. The harness hashes the file's raw bytes (solver_sha256 in every ladder header), so a certificate that stores the text must
    # give back the same bytes, or a solver saved with Windows line endings would fail its own `sources` check.
    with open(path, encoding="utf-8", newline="") as f:
        return f.read()


def rules_of(family):
    """The protocol-code part of the fingerprint (declared-domain files are carried separately, by role)."""
    fp = rounds.code_fingerprint(family)
    return {"dims": fp["dims"], "instance_version": fp["instance_version"],
            "code": {rel: fp["code"][rel] for rel in rounds.CODE_FILES}}


def commit_published(log_entries, commitments, round_id_hint=None):
    """(ok, why): the log's hash chain verifies and entry 0 contains every commitment. Verified in a temporary directory named for the round."""
    if not log_entries:
        return False, "no round log included"
    rid = (log_entries[0].get("data") or {}).get("id")
    if not isinstance(rid, str) or not rounds.ROUND_ID_RE.match(rid):
        return False, "the first log entry has no valid round id"
    with tempfile.TemporaryDirectory() as td:
        d = os.path.join(td, rid)
        os.makedirs(d)
        with open(os.path.join(d, "log.jsonl"), "w", encoding="utf-8") as f:
            for e in log_entries:
                f.write(rounds.canonical(e) + "\n")
        ok, n, head, err = rounds.verify_log(d)
    if not ok:
        return False, f"the log does not verify: {err}"
    if not set(commitments) <= set(log_entries[0]["data"].get("commitments", [])):
        return False, "a seed commitment is not in entry 0 of the log"
    return True, f"{n} entries, head {head[:16]}"


def score_seed(family, name, tag, published, base_text, sub_text, work):
    """The board entry for one seed, computed exactly as judge.py computes it: extrapolate.py on the two ladder files, then make_entry."""
    import subprocess
    bp, sp = os.path.join(work, f"{tag}_baseline.jsonl"), os.path.join(work, f"{tag}_submission.jsonl")
    with open(bp, "w", encoding="utf-8") as f:
        f.write(base_text)
    with open(sp, "w", encoding="utf-8") as f:
        f.write(sub_text)
    r = subprocess.run([sys.executable, os.path.join(HERE, "extrapolate.py"), "--baseline", bp, "--submission", sp], cwd=HERE, capture_output=True, text=True)
    if r.returncode:
        raise CertificateError(f"seed {tag}: the estimator refused these ladders: {(r.stdout.strip() or r.stderr.strip())[-300:]}")
    with open(sp + ".claim.json", encoding="utf-8") as f:
        claim = json.load(f)
    return judge.make_entry(name, family, tag, sp, claim, 512, published, base_file=bp)


def claim_of(entries):
    rows = judge.leaderboard_rows(sorted(entries, key=lambda e: e["seed_tag"]))  # per_seed lists follow entry order: fix it, or the same data compares unequal
    if len(rows) != 1:
        raise CertificateError("the entries do not describe exactly one submission")
    r = rows[0]
    status, reasons = r["status"], r["reasons"]
    if all(e.get("sandbox") == "count" for e in entries):
        status, reasons = _counted_status(entries)   # judge.py's OFFICIAL means "Docker sandbox, timed": a counted ladder is held to its own rules
    return {"credit_bits": r["credit"], "status": status, "reasons": reasons, "per_seed": r["per_seed"]}


def _counted_status(entries):
    """-> (status, reasons) for entries made by step counting. COUNTED = at least judge.MIN_SEEDS committed seeds whose commitments were shown to be public
    first, one solver file and one baseline file throughout, hashes and instance version recorded. Anything less is COUNTED, PROVISIONAL, with the reasons."""
    why = []
    if len(entries) < judge.MIN_SEEDS:
        why.append(f"{len(entries)} seed(s), fewer than {judge.MIN_SEEDS}")
    if not all(e.get("commit_checked") for e in entries):
        why.append("seed commitment not checked against a published value")
    for key, label in (("solver_sha256", "solver file hash"), ("baseline_sha256", "baseline file hash"), ("instance_version", "instance version")):
        if not all(e.get(key) for e in entries):
            why.append(f"no {label} recorded")
    if len({e.get("solver_sha256") for e in entries}) > 1:
        why.append("the seeds used different versions of the submission file")
    if len({e.get("baseline_sha256") for e in entries}) > 1:
        why.append("the seeds used different baseline files")
    return ("COUNTED" if not why else "COUNTED, PROVISIONAL"), why


# ------------------------------------------------------------------------------------------------------------- build
def _counted_info(ladders):
    """None for ordinary (timed) ladders. For ladders made by counted.py: {steps_per_second, python, dims, n, cap}. A mix of counted and timed ladders, or
    counted ladders that disagree about the unit, the interpreter, the cap or the sizes, is refused: they would not be comparable."""
    heads, shapes = [], set()
    for tag, lad in sorted(ladders.items()):
        for role in ("baseline", "submission"):
            lines = [ln for ln in lad[role].splitlines() if ln.strip()]
            heads.append(json.loads(lines[0]))
            recs = [json.loads(ln) for ln in lines[1:]]
            per = {}
            for r in recs:
                per[r["dim"]] = per.get(r["dim"], 0) + 1
            shapes.add(tuple(sorted(per.items())))
    flags = {h.get("cost_model") == "count" for h in heads}
    if flags == {False}:
        return None
    if flags != {True}:
        raise CertificateError("the ladders mix counted and timed cost models: they are not comparable")
    for key in ("steps_per_second", "python", "budget", "counter_sha256"):
        if len({json.dumps(h.get(key)) for h in heads}) != 1:
            raise CertificateError(f"the counted ladders disagree about {key}")
    if len(shapes) != 1:
        raise CertificateError("the counted ladders cover different sizes or numbers of instances")
    shape = dict(next(iter(shapes)))
    return {"steps_per_second": heads[0]["steps_per_second"], "python": heads[0]["python"], "dims": sorted(shape), "n": min(shape.values()), "cap": heads[0]["budget"],
            "counter_sha256": heads[0].get("counter_sha256")}


def make_private(cert):
    """A PRIVATE-SOLVER copy of a certificate: no solver source, and no failure text in the submission's ladders (a crash message is a traceback, and a
    traceback quotes the solver's own lines). Credit, claim, log, rules and hashes are untouched, so everything but re-running still verifies.
    The input is not modified."""
    import copy
    out = copy.deepcopy(cert)
    if not isinstance(out.get("submission"), dict):
        raise CertificateError("not a certificate: no submission")
    out["submission"]["source"] = None
    out["private"] = True
    for tag, lad in (out.get("ladders") or {}).items():
        lines = []
        for line in lad["submission"].splitlines():
            if not line.strip():
                continue
            rec = json.loads(line)
            if "err" in rec:                                # only per-instance records carry failure text
                rec.pop("err")
                rec["err_withheld"] = True
            lines.append(json.dumps(rec))
        lad["submission"] = "\n".join(lines) + "\n"
    return out


def build(family, submission, seed_dir, reveal_seeds=False, baseline=None, results_dir=None, round_data=None, round_id=None, now=None, private=False):
    if family not in families.FAMILIES:
        raise CertificateError(f"unknown family {family!r}")
    results_dir = results_dir or os.path.join(HERE, "results")
    baseline = os.path.abspath(baseline or judge.default_baseline(family))
    submission = os.path.abspath(submission)
    name = os.path.splitext(os.path.basename(submission))[0]
    seeds = official.verified_seeds(seed_dir)
    base_text_src, sub_text_src = _read(baseline), _read(submission)
    log = None
    if round_id:
        if not round_data:
            raise CertificateError("--round-id needs --round-data")
        r = rounds.get_round(round_data, round_id)
        if r["family"] != family:
            raise CertificateError(f"round {round_id} is a {r['family']} round, not {family}")
        if reveal_seeds and r["state"] != "revealed":
            # putting the seeds in a file IS the reveal: before the round is evaluated they would let anyone precompute every instance
            raise CertificateError(f"round {round_id} is {r['state']!r}, not 'revealed': a certificate with seeds may only be built after the reveal "
                                   "(build a sealed one, without --reveal-seeds, until then)")
        log = rounds.read_log(rounds.rdir(round_data, round_id))
    commits = sorted(h for _, h in seeds)
    published, why = commit_published(log, commits)
    ladders, entries, seed_blob = {}, [], {}
    with tempfile.TemporaryDirectory() as work:
        for path, h in seeds:
            tag = h[:8]
            bfile = os.path.join(results_dir, f"judged_{family}_{tag}_baseline_{os.path.basename(baseline)}.jsonl")
            sfile = os.path.join(results_dir, f"judged_{family}_{tag}_submission_{os.path.basename(submission)}.jsonl")
            for f in (bfile, sfile):
                if not os.path.exists(f):
                    raise CertificateError(f"missing ladder {f}: evaluate this submission on seed {tag} first")
            ladders[tag] = {"baseline": _read(bfile), "submission": _read(sfile)}
            entries.append(score_seed(family, name, tag, published, ladders[tag]["baseline"], ladders[tag]["submission"], work))
            if reveal_seeds:
                with open(path, "rb") as f:
                    seed_blob[h] = f.read().strip().decode()
    cert = {"format": FORMAT, "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now or time.time())), "family": family,
            "claim": claim_of(entries), "entries": entries, "rules": rules_of(family), "commitments": commits,
            "seeds": seed_blob or None, "seeds_revealed": bool(reveal_seeds),
            "submission": {"name": name, "sha256": sha256(sub_text_src), "source": sub_text_src},
            "baseline": {"name": os.path.basename(baseline), "sha256": sha256(base_text_src), "source": base_text_src},
            "ladders": ladders, "log": log, "log_note": why}
    if family in families.DECLARED:
        d = families.DECLARED[family]["dir"]
        mod = declared.load_declaration(d)
        files = {"decl.py": os.path.join(d, declared.DECL), "compiled.json": os.path.join(d, declared.COMPILED),
                 "reference": declared.reference_path(d, mod)}
        cert["domain"] = {"name": family, "reference_name": mod.REFERENCE_SOLVER,
                          "files": {role: {"sha256": sha256(_read(p).encode()), "text": _read(p)} for role, p in files.items()}}
    cert["private"] = False
    counted = _counted_info(ladders)
    if counted:
        # counted ladders carry THEIR OWN size ladder (small: counting is slow), chosen by whoever ran them: the verifier then holds the ladder check to
        # these sizes, not to the family's official ones, and the verdict says that a counted certificate is not an official round result
        cert["count"] = counted
        cert["rules"]["dims"] = counted["dims"]
        cert["rules"]["cost_model"] = "count"
    return make_private(cert) if private else cert


# ------------------------------------------------------------------------------------------------------------- verify
def _chk(out, check, status, detail=""):
    out.append({"check": check, "status": status, "detail": detail})
    return status == "pass"


def _domain_derive(cert, family, work, out, metas, stack, execute=False):
    """(derive, verify) for the certificate's family: this checkout's registry for a built-in, the certificate's own files for a declared domain.
    A declared domain's decl.py is CODE FROM THE CERTIFICATE: it is hash-checked and read as data, and imported (executed) only with execute=True."""
    dom = cert.get("domain")
    if not dom:
        if family in families.DECLARED:
            _chk(out, "domain", "fail", f"{family!r} is a declared domain here but the certificate carries no declaration files")
            return None
        if family not in families.FAMILIES:
            _chk(out, "domain", "fail", f"{family!r} is not a family this checkout knows, and the certificate carries no declaration")
            return None
        _chk(out, "domain", "pass", f"built-in family {family}")
        return families.FAMILIES[family]
    if dom.get("name") != family or not declared.NAME_RE.match(str(dom.get("name"))):
        _chk(out, "domain", "fail", "the declaration's name is not the certificate's family")
        return None
    d = os.path.join(work, "domains", dom["name"])
    os.makedirs(d)
    ref_rel = dom["reference_name"]
    if os.path.isabs(ref_rel) or ".." in ref_rel.split("/"):
        _chk(out, "domain", "fail", "the reference path escapes the declaration directory")
        return None
    targets = {"decl.py": os.path.join(d, declared.DECL), "compiled.json": os.path.join(d, declared.COMPILED), "reference": os.path.join(d, ref_rel)}
    for role, f in dom["files"].items():
        if role not in targets:
            _chk(out, "domain", "fail", f"unexpected file role {role!r}")
            return None
        if sha256(f["text"].encode()) != f["sha256"]:
            _chk(out, "domain", "fail", f"{role} does not match its recorded hash")
            return None
        os.makedirs(os.path.dirname(targets[role]), exist_ok=True)
        with open(targets[role], "w", encoding="utf-8") as g:
            g.write(f["text"])
    compiled = declared.read_compiled(d)
    texts = {role: f["text"].encode() for role, f in dom["files"].items()}
    if (compiled is None or compiled.get("format") != declared.FORMAT or compiled.get("name") != family
            or compiled.get("decl_sha256") != sha256(texts.get("decl.py", b"")) or compiled.get("reference_sha256") != sha256(texts.get("reference", b""))
            or not all(k in compiled for k in ("dims", "practice_dims", "official", "version"))):
        _chk(out, "domain", "fail", "the compiled record does not match the declaration and reference files it sits beside")
        return None
    if execute:
        try:
            mod = declared.load_declaration(d)  # EXECUTES the certificate's decl.py
            problems = declared.freshness_problems(d, mod, compiled)
        except declared.DeclarationError as e:
            _chk(out, "domain", "fail", str(e))
            return None
        if problems:
            _chk(out, "domain", "fail", "the compiled record does not match the declaration: " + "; ".join(problems))
            return None
    if family in families.DECLARED:
        # this checkout already has a domain of that name: it must be THE certificate's declaration, or the registry (verify, OFFICIAL, rerun)
        # would silently judge the certificate by someone else's rules
        if families.DECLARED[family]["decl_sha256"] != compiled["decl_sha256"]:
            _chk(out, "domain", "fail", f"this checkout's own {family!r} declaration differs from the certificate's (decl.py hashes differ)")
            return None
    elif family in families.FAMILIES:
        _chk(out, "domain", "fail", f"{family!r} is a built-in family here, but the certificate carries a declaration for it")
        return None
    else:
        # judge.leaderboard_rows looks the family's thresholds up in the registry: register them (data from compiled.json; with execute, the whole
        # declaration) for the duration of this verification, then remove them
        if execute:
            declared.register(families, d, mod, compiled)
        else:
            families.VERSIONS[family] = compiled["version"]
            families.OFFICIAL[family] = compiled["official"]
            families.DEFAULT_DIMS[family] = compiled["dims"]
        stack.callback(declared.unregister, families, family)
    ver_ok = all(m.get("instance_version") == compiled["version"] for m in metas)
    _chk(out, "domain", "pass" if ver_ok else "fail",
         (f"declaration {compiled['version']}, decl.py {compiled['decl_sha256'][:12]}..., compiled ladder {compiled['dims']}, cap {compiled['official']['budget']}; "
          + ("declaration executed (--execute)" if execute else "files hash-checked and read as data; the declaration was NOT executed"))
         if ver_ok else "a ladder was measured with a different instance version than this declaration")
    return declared.make_spec(mod) if execute else None


ALL_INSTANCES = 10 ** 9   # what `--rerun all` means: more than any certificate holds, so every instance is re-run (the sample is then the whole pool)


def rerun_count(text):
    """argparse type for --rerun: a non-negative integer, or `all` (re-run EVERY instance: the only way to leave nothing covered merely statistically)."""
    if str(text).strip().lower() == "all":
        return ALL_INSTANCES
    try:
        k = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError("--rerun takes a number or `all`")
    if k < 0:
        raise argparse.ArgumentTypeError("--rerun cannot be negative")
    return k


MAX_COUNTED_CAP = 10_000  # counted seconds (x steps_per_second instructions): a larger per-instance budget in an untrusted certificate would make --rerun --execute run for hours
RERUN_TOLERANCE = 2.0  # bits: LOOSE on purpose until cross-machine spread has been measured (compile_domain.py recheck --measure); tighten with --tolerance


def verify(cert, rerun=0, execute=False, log=print, tolerance=RERUN_TOLERANCE, sample_seed=0, source=None):
    """-> {"ok": bool, "checks": [...], "claim": ..., "private": bool, "source_revealed": bool}. Never trusts the certificate's own claim: everything is recomputed.
    A certificate is untrusted input. By default nothing in it is executed: a declared domain's decl.py is hash-checked and read as data, so
    instance coverage of a declared domain is SKIPPED, and --rerun is refused. execute=True imports the certificate's decl.py and (with
    rerun) runs its solver sources on this machine, unsandboxed: do that only in a throwaway VM or container.
    `source` (text) is a solver the owner has revealed for a PRIVATE-SOLVER certificate: it must hash to the certificate's committed solver hash, and
    then --rerun can re-measure it."""
    try:
        return _verify(cert, rerun, execute, tolerance, sample_seed, source)
    except (KeyError, TypeError, ValueError, AttributeError, IndexError, StopIteration, OverflowError, ZeroDivisionError, OSError, RecursionError) as e:   # OSError: a hostile reference_name ("File name too long")
        return {"ok": False, "claim": None, "private": False, "source_revealed": False, "counted": False,
                "checks": [{"check": "format", "status": "fail", "detail": f"malformed certificate ({type(e).__name__}: {e})"}]}


def _verify(cert, rerun, execute, tolerance=RERUN_TOLERANCE, sample_seed=0, source=None):
    out = []
    if not isinstance(cert, dict) or cert.get("format") != FORMAT:
        return {"ok": False, "checks": [{"check": "format", "status": "fail", "detail": f"not a {FORMAT} certificate"}], "claim": None}
    family = cert["family"]
    _chk(out, "format", "pass", f"{FORMAT}, family {family}, created {cert.get('created')}")
    # rules: this checkout's protocol code against the certificate's
    def _file_sha(path):
        with open(path, "rb") as f:
            return sha256(f.read())
    mine_code = {rel: (_file_sha(os.path.join(HERE, rel)) if os.path.exists(os.path.join(HERE, rel)) else None) for rel in rounds.CODE_FILES}
    diff = sorted(rel for rel in rounds.CODE_FILES if mine_code[rel] != cert["rules"]["code"].get(rel))
    _chk(out, "rules", "fail" if diff else "pass",
         ("this checkout differs from the certificate's rules in: " + ", ".join(diff) + ". Check out the version it names; a different estimator or "
          "harness would score the same data differently") if diff else f"{len(mine_code)} protocol files hash exactly as the certificate names")
    # sources vs ladders
    metas, ladder_ok = [], True
    for tag, lad in sorted(cert["ladders"].items()):
        for role in ("baseline", "submission"):
            try:
                meta = json.loads(lad[role].splitlines()[0])
            except (ValueError, IndexError):
                ladder_ok = False
                _chk(out, "sources", "fail", f"seed {tag}: the {role} ladder has no readable header")
                continue
            metas.append(meta)
            want = cert[role]["sha256"]
            if meta.get("solver_sha256") != want:
                ladder_ok = False
                _chk(out, "sources", "fail", f"seed {tag}: the {role} ladder was measured with a solver whose hash is {str(meta.get('solver_sha256'))[:12]}, "
                                              f"not the included source ({want[:12]})")
    private = cert.get("private") is True
    sub = cert["submission"]
    revealed = None            # the solver's source, once the owner has revealed it and the caller supplied it
    if private:
        if sub.get("source") is not None:
            ladder_ok = False
            _chk(out, "sources", "fail", "a certificate marked private-solver carries the solver's source: it is malformed or was made private badly")
    elif sha256(sub["source"]) != sub["sha256"]:
        ladder_ok = False
        _chk(out, "sources", "fail", "the included solver source does not match its own recorded hash")
    if sha256(cert["baseline"]["source"]) != cert["baseline"]["sha256"]:
        ladder_ok = False
        _chk(out, "sources", "fail", "the included baseline source does not match its own recorded hash")
    in_log = " (and the round's log)" if cert.get("log") else ""    # a certificate built outside a round has no log: do not claim one committed to anything
    if private and source is not None:
        if sha256(source) != sub["sha256"]:
            ladder_ok = False
            _chk(out, "solver disclosure", "fail", f"the file supplied does not hash to the solver hash this certificate{in_log} committed to: "
                 f"it hashes to {sha256(source)[:12]}..., the certificate says {sub['sha256'][:12]}...")
        else:
            revealed = source
            _chk(out, "solver disclosure", "pass", f"the file supplied is exactly the solver this certificate measured (sha256 {sub['sha256'][:12]}...)")
    elif private:
        _chk(out, "solver disclosure", "skip", "PRIVATE SOLVER: its source is not in this certificate, so it cannot be inspected or re-run here. Its hash is the one every "
             f"ladder header names{' and the round' + chr(39) + 's log committed to' if cert.get('log') else ''}; if the owner publishes the file, check it with --source FILE")
    if ladder_ok:
        _chk(out, "sources", "pass", f"submission {sub['sha256'][:12]}...{' (private solver: source withheld)' if private else ''} and baseline {cert['baseline']['sha256'][:12]}... "
                                      "are what every ladder header names")
    metas = [m for m in metas if m.get("meta")]
    with tempfile.TemporaryDirectory() as work, contextlib.ExitStack() as stack:
        spec = _domain_derive(cert, family, work, out, metas, stack, execute)
        # log
        commits = cert["commitments"]
        published, why = commit_published(cert.get("log"), commits)
        round_declared = False   # True when the log's entry 0 declared THIS counted ladder before any submission (see rounds.create_round(count=...))
        try:
            log_count = _counted_info(cert["ladders"])   # a malformed mix is reported by the cost-model check below
        except CertificateError:
            log_count = None
        if cert.get("log"):
            if published:
                data0 = cert["log"][0]["data"]
                fp = data0.get("fingerprint") or {}
                same = fp.get("code") is not None and all(fp["code"].get(rel) == cert["rules"]["code"].get(rel) for rel in rounds.CODE_FILES)
                subs = {e["data"].get("sha256") for e in cert["log"] if e.get("kind") == "submission"}
                changed = [e for e in cert["log"] if e.get("kind") == "code_changed"]
                bad = []
                if not same or fp.get("dims") != cert["rules"]["dims"] or fp.get("instance_version") != cert["rules"]["instance_version"]:
                    bad.append("the rules fingerprint in log entry 0 (code, size ladder, instance version) differs from the certificate's rules")
                if cert["submission"]["sha256"] not in subs:
                    bad.append("the submission's hash was never logged as an accepted submission")
                if cert.get("domain"):  # the declaration, its compiled ladder and its reference were committed to in entry 0 too
                    anchored = set((fp.get("code") or {}).values())
                    off = sorted(role for role, f in cert["domain"]["files"].items() if f["sha256"] not in anchored)
                    if off:
                        bad.append("the domain file(s) " + ", ".join(off) + " are not the ones the round committed to in log entry 0")
                declared_count = data0.get("count") if data0.get("cost_model") == "count" and isinstance(data0.get("count"), dict) else None
                if declared_count is not None or log_count is not None:
                    if log_count is None:
                        bad.append("the round declared step counting in log entry 0 but this certificate's ladders are not step-counted")
                    elif declared_count is None:
                        bad.append("this certificate's ladders are step-counted but the round did not declare step counting in log entry 0: their sizes and cap would be the prover's")
                    elif any(declared_count.get(k) != log_count.get(k) for k in ("dims", "n", "cap", "steps_per_second", "python", "counter_sha256")):
                        bad.append("the counted ladder (sizes, instances per size, cap, unit, Python version or counter) is not the one the round declared in log entry 0")
                    elif (fp.get("code") or {}).get("count_runner.py") != log_count["counter_sha256"]:
                        bad.append("the counting program is not the one the round's rules fingerprint names")
                    elif private:
                        bad.append("a counted round requires every solver's source to be published (the proof is re-execution), but this certificate withholds it")
                    else:
                        round_declared = True
                        import counted
                        src = cert["submission"].get("source")
                        problems = counted.source_problems(src) if isinstance(src, str) else []
                        if problems:   # the round should have refused it at submission; a verifier must not rely on the operator having done so (the counter refuses to run it anyway)
                            bad.append("the solver's source is outside the restricted subset a counted solver is written in: " + "; ".join(problems[:3]))
                            round_declared = False
                _chk(out, "log", "fail" if bad else "pass", ("; ".join(bad)) if bad else
                     f"{why}; commitments and rules were public before submissions; submission logged" + (f"; NOTE {len(changed)} code_changed entry(ies)" if changed else ""))
            else:
                _chk(out, "log", "fail", why)
        else:
            _chk(out, "log", "skip", "no log included: the publication time of the commitments cannot be shown, so the credit is at most PROVISIONAL")
        # seeds
        seeds = cert.get("seeds") or {}
        if cert.get("seeds_revealed"):
            bad = [h for h, s in seeds.items() if sha256(s.strip().encode()) != h]
            missing = [h for h in commits if h not in seeds]
            _chk(out, "seeds", "fail" if bad or missing else "pass",
                 f"{len(bad)} seed(s) do not hash to their commitment, {len(missing)} missing" if bad or missing else f"{len(seeds)} revealed seed(s) hash to their commitments")
        else:
            _chk(out, "seeds", "skip", "seeds not revealed in this certificate: instance coverage and re-measurement cannot be checked")
        # ladders: one baseline/submission pair per committed seed (a dropped seed would raise the minimum), on the rules' own size ladder
        pair_bad = []
        if sorted(cert["ladders"]) != sorted(c[:8] for c in commits):
            pair_bad.append("the ladders are not exactly one pair per committed seed")
        for tag, lad in cert["ladders"].items():
            for role in ("baseline", "submission"):
                recs = [json.loads(line) for line in lad[role].splitlines()[1:] if line.strip()]
                if sorted({r["dim"] for r in recs}) != sorted(cert["rules"]["dims"]):
                    pair_bad.append(f"seed {tag} {role}: sizes {sorted({r['dim'] for r in recs})} are not the rules' ladder {sorted(cert['rules']['dims'])}")
                per = {}
                for r in recs:
                    per[r["dim"]] = per.get(r["dim"], 0) + 1
                if len(set(per.values())) > 1:
                    pair_bad.append(f"seed {tag} {role}: the number of instances differs between sizes")
        _chk(out, "ladders", "fail" if pair_bad else "pass",
             "; ".join(pair_bad) if pair_bad else f"{len(cert['ladders'])} seed(s), each with a baseline and a submission ladder on the rules' sizes {cert['rules']['dims']}")
        # cost model: deterministic step counting (counted.py) is a different KIND of evidence from a timed ladder, and the verdict must say so
        count = cert.get("count") if isinstance(cert.get("count"), dict) else None
        try:   # the ladders themselves say which cost model they use: a certificate may not hide that by dropping its own `count` field (instruction counts passing as seconds)
            actual = _counted_info(cert["ladders"])
        except CertificateError as e:
            _chk(out, "cost model", "fail", f"the ladders are inconsistent: {e}")
            actual, count = None, None
        else:
            if actual is None and any(m.get("sandbox") == "count" for m in metas):
                # claim_of grants the COUNTED status to entries whose sandbox is "count": a timed ladder must not be able to take it by labelling its header so
                _chk(out, "cost model", "fail", "a ladder header says sandbox \"count\" but the ladders are not step-counted: the label is only for counted ladders")
                count = None
            elif (actual is not None) != (count is not None):
                _chk(out, "cost model", "fail", "the ladders are " + ("step-COUNTED" if actual is not None else "timed") + " but the certificate says "
                     + ("they are counted" if count is not None else "nothing about step counting") + ": a counted cost must never be presented as seconds")
                count = None   # already reported: skip the detailed counted checks below
        if count is not None:
            bad = _check_counted(cert, count)
            _chk(out, "cost model", "fail" if bad else "pass", "; ".join(bad[:3]) + (f" (and {len(bad) - 3} more)" if len(bad) > 3 else "") if bad else
                 f"deterministic STEP COUNTING: every cost is a bytecode-instruction count / {count['steps_per_second']:g}, recorded on {count['python']}. It is exactly "
                 "reproducible (--rerun K --execute must give identical counts) but it is NOT a time, it is blind to work inside C functions, and the ladder "
                 f"(sizes {count['dims']}, {count['n']} per size, cap {count['cap']:g}) "
                 + ("was declared by the round in log entry 0 before any submission, the same for every participant (a ROUND-DECLARED ladder)" if round_declared else
                    "was chosen by whoever ran it: not an official round result"))
        # coverage
        if spec is not None and cert.get("seeds_revealed") and ladder_ok:
            derive = spec[0]
            cov_bad = []
            for tag, lad in sorted(cert["ladders"].items()):
                h = next((c for c in commits if c.startswith(tag)), None)
                if h is None or h not in seeds:
                    cov_bad.append(f"seed {tag}: no matching revealed seed")
                    continue
                master = seeds[h].strip().encode()
                for role in ("baseline", "submission"):
                    recs = [json.loads(line) for line in lad[role].splitlines()[1:] if line.strip()]
                    dims = sorted({r["dim"] for r in recs})
                    n = len(recs) // max(len(dims), 1)
                    want = set()
                    for dm in dims:
                        for i in range(n):
                            want.add(derive(master, dm, i)["id"])
                    have = [r["id"] for r in recs]
                    if len(have) != len(set(have)) or set(have) != want:
                        cov_bad.append(f"seed {tag} {role}: records are not exactly the {len(want)} instances the seed derives")
            _chk(out, "coverage", "fail" if cov_bad else "pass",
                 "; ".join(cov_bad) if cov_bad else "every ladder holds exactly the instances its seed derives, no more, no fewer, none repeated")
        else:
            _chk(out, "coverage", "skip", "needs the revealed seeds" + ("" if spec is not None or not cert.get("domain") else
                 " and the declaration executed (--execute: runs the certificate's decl.py on this machine)"))
        # credit
        try:
            entries = [score_seed(family, cert["submission"]["name"], tag, published, lad["baseline"], lad["submission"], work)
                       for tag, lad in sorted(cert["ladders"].items())]
            mine, theirs = canon(sorted(entries, key=lambda e: e["seed_tag"])), canon(sorted(cert["entries"], key=lambda e: e["seed_tag"]))
            claim = claim_of(entries)
            if mine != theirs or canon(claim) != canon(cert["claim"]):
                _chk(out, "credit", "fail", f"recomputed credit {claim['credit_bits']} bits ({claim['status']}) differs from the claimed "
                                             f"{cert['claim']['credit_bits']} bits ({cert['claim']['status']})")
            else:
                _chk(out, "credit", "pass", f"recomputed {claim['credit_bits']} bits, {claim['status']}, per seed {claim['per_seed']}; identical to the claim")
        except CertificateError as e:
            claim = None
            _chk(out, "credit", "fail", str(e))
        # rerun
        if rerun and private and revealed is None:
            _chk(out, "rerun", "skip", "PRIVATE solver: its source is not in the certificate, so there is nothing to re-run. If the owner publishes it, "
                 "pass it with --source FILE")
        elif rerun and execute and spec is not None and cert.get("seeds_revealed") and ladder_ok:
            _rerun(cert, spec, seeds, commits, rerun, work, out, tolerance, sample_seed, revealed)
        elif rerun:
            _chk(out, "rerun", "skip", "needs --execute (it runs the certificate's solver sources on this machine, unsandboxed), the revealed seeds and a loadable domain")
    ok = all(c["status"] != "fail" for c in out)
    return {"ok": ok, "checks": out, "claim": cert.get("claim") if ok else None, "private": private, "source_revealed": revealed is not None,
            "counted": count is not None}


def _write_sources(cert, work, solver_source=None):
    """The two solver files, written where they can be run. A revealed solver is written byte-for-byte: it is the file whose hash the log committed to."""
    paths = {}
    for role in ("baseline", "submission"):
        paths[role] = os.path.join(work, f"{role}.py")
        src = solver_source if role == "submission" and solver_source is not None else cert[role]["source"]
        if isinstance(src, bytes):
            with open(paths[role], "wb") as f:
                f.write(src)
        else:
            with open(paths[role], "w", encoding="utf-8") as f:
                f.write(src)
    return paths


def _check_counted(cert, count):
    """-> [problems]. Every record of a counted ladder must be internally consistent: a solved instance's cost is exactly its step count over the unit
    (floored like the harness), an unsolved one is charged the cap, and every header names the same unit and interpreter as the certificate."""
    bad = []
    sps = count.get("steps_per_second")
    if not (isinstance(sps, (int, float)) and not isinstance(sps, bool) and sps > 0) or not isinstance(count.get("python"), str):
        return ["the certificate's counted-cost record is malformed"]
    import counted
    csha = count.get("counter_sha256")
    if not (isinstance(csha, str) and re.fullmatch(r"[0-9a-f]{64}", csha)):
        return ["the certificate does not name the counting program that produced its counts (counter_sha256)"]
    if csha != counted.counter_sha256():
        return [f"these counts were made by a different counting program (count_runner.py hash {csha[:12]}, this checkout's is {counted.counter_sha256()[:12]}): "
                "check out the version it names; another counter would count the same program differently"]
    if sps != counted.STEPS_PER_SECOND:
        # the unit is part of what a re-run reproduces (the budget in instructions is cap x unit); the counter hash pins count_runner.py, not this constant
        return [f"the certificate's unit is {sps:g} instructions per counted second, this checkout's is {counted.STEPS_PER_SECOND:g}: check out the version it names"]
    ccap = count.get("cap")
    if not (isinstance(ccap, (int, float)) and not isinstance(ccap, bool) and 0 < ccap <= MAX_COUNTED_CAP):   # also rejects NaN and Infinity (JSON allows both)
        return [f"the certificate's counted cap is not a number between 0 and {MAX_COUNTED_CAP:g} counted seconds"]
    for tag, lad in sorted(cert["ladders"].items()):
        for role in ("baseline", "submission"):
            lines = [ln for ln in lad[role].splitlines() if ln.strip()]
            meta = json.loads(lines[0])
            if meta.get("budget") != ccap:
                bad.append(f"seed {tag} {role}: the ladder's budget is not the certificate's counted cap")
                continue
            if (meta.get("cost_model") != "count" or meta.get("sandbox") != "count" or meta.get("steps_per_second") != sps or meta.get("python") != count["python"]
                    or meta.get("counter_sha256") != csha):   # (sandbox "count": a counted ladder cannot borrow judge.py's OFFICIAL by labelling itself "docker")
                bad.append(f"seed {tag} {role}: the ladder header disagrees with the certificate's counted-cost record")
                continue
            cap = meta["budget"]
            limit = int(cap * sps)
            for ln in lines[1:]:
                r = json.loads(ln)
                s = r.get("steps")
                if isinstance(s, bool) or not isinstance(s, int) or s < 0:
                    # a wall-clock timeout or a counter failure has no count: it can never be re-executed to the same number, and "charged the cap" without a count would let a
                    # prover turn any baseline instance into a maximal cost that no re-run will ever check
                    bad.append(f"seed {tag} {role} {r['id']}: no step count, so it cannot be reproduced and is not provable")
                elif r["status"] == "solved":
                    if s > limit:
                        bad.append(f"seed {tag} {role} {r['id']}: a solved instance cannot have used more than the budget")
                    elif abs(r["cpu_net"] - max(s / sps, 1e-3)) > 1e-9 * max(1.0, r["cpu_net"]):
                        bad.append(f"seed {tag} {role} {r['id']}: the cost does not follow from the step count")
                elif r["cpu_net"] != cap:
                    bad.append(f"seed {tag} {role} {r['id']}: an unsolved instance must be charged the cap")
                elif r["status"] == "timeout":
                    if s != limit + 1:
                        # the counter stops a solver at exactly limit+1 instructions, so a timeout with any other count (a baseline "timing out" in 5 steps) is not one
                        bad.append(f"seed {tag} {role} {r['id']}: a counted timeout must have used exactly the budget plus one instruction")
                elif s > limit:
                    bad.append(f"seed {tag} {role} {r['id']}: a {r['status']} instance cannot have used more than the budget")
    return bad


def _rerun_counted(cert, spec, paths, seeds, commits, k, out, sample_seed):
    """Re-EXECUTE k instances of BOTH solvers here under step counting and require IDENTICAL counts and statuses: no tolerance, no trust in anyone's
    machine. That equality is the proof. Instruction counts are only comparable on the same interpreter, so a different Python version is a SKIP."""
    import counted
    derive, check = spec
    count = cert["count"]
    if not counted.supported() or counted.python_version() != count["python"]:
        _chk(out, "rerun", "skip", f"these counts were recorded on {count['python']} and this machine runs {counted.python_version()}: instruction counts are only "
             "comparable on the same interpreter version, so there is nothing exact to compare (use that version)")
        return
    rng = random.Random(sample_seed)
    pool = []
    for tag, lad in cert["ladders"].items():
        recs = {role: {r["id"]: r for r in map(json.loads, (ln for ln in lad[role].splitlines()[1:] if ln.strip()))} for role in ("baseline", "submission")}
        for i, rb in recs["baseline"].items():
            rs = recs["submission"].get(i)
            if rs and rb.get("steps") is not None and rs.get("steps") is not None:
                pool.append((tag, i, rb, rs))
    pool.sort(key=lambda t: (t[0], t[1]))
    picks = rng.sample(pool, min(k, len(pool)))
    if not picks:
        _chk(out, "rerun", "skip", "no instance has a recorded step count for both solvers")
        return
    mismatches = []
    for tag, iid, rb, rs in picks:
        h = next(c for c in commits if c.startswith(tag))
        master = seeds[h].strip().encode()
        dim, idx = rb["dim"], int(iid.rsplit(":", 1)[1])
        inst = derive(master, dim, idx)
        inst["family"] = cert["family"]
        if "args" not in inst:  # lattice families: the solver receives (basis, bound2), as families.derive arranges
            inst["args"] = [inst["basis"], inst["bound2"]]
        for role, rec in (("baseline", rb), ("submission", rs)):
            got = counted.count_instance(paths[role], inst, count["cap"])
            if got.get("steps") != rec.get("steps") or got.get("status") != rec.get("status"):
                mismatches.append(f"{iid} (seed {tag}) {role}: recorded {rec.get('status')} in {rec.get('steps')} steps, re-executed {got.get('status')} in {got.get('steps')}")
    _chk(out, "rerun", "fail" if mismatches else "pass",
         ("did not reproduce: " + "; ".join(mismatches[:3]) + (f" (and {len(mismatches) - 3} more)" if len(mismatches) > 3 else "")) if mismatches else
         f"re-executed {len(picks)} of {len(pool)} instance(s) of BOTH solvers here: every step count and status is IDENTICAL to the record (exact equality, not a tolerance)"
         + ("" if len(picks) == len(pool) else f". The other {len(pool) - len(picks)} are covered only statistically (a record falsified in a fraction f of the instances escapes "
                                               f"{len(picks)} random checks with probability (1-f)^{len(picks)}): re-run them all for certainty"))
    out[-1]["data"] = {"k": len(picks), "of": len(pool), "exact": True, "mismatches": len(mismatches), "sample_seed": sample_seed}


def _rerun(cert, spec, seeds, commits, k, work, out, tolerance=RERUN_TOLERANCE, sample_seed=0, solver_source=None):
    derive, check = spec
    paths = _write_sources(cert, work, solver_source)
    if isinstance(cert.get("count"), dict):
        return _rerun_counted(cert, spec, paths, seeds, commits, k, out, sample_seed)
    rng = random.Random(sample_seed)
    pool = []
    for tag, lad in cert["ladders"].items():
        recs = {role: {r["id"]: r for r in map(json.loads, lad[role].splitlines()[1:]) if r} for role in ("baseline", "submission")}
        meta = json.loads(lad["baseline"].splitlines()[0])
        for i, rb in recs["baseline"].items():
            rs = recs["submission"].get(i)
            if rs and rb["status"] == "solved" and rs["status"] == "solved" and rb["cpu_net"] >= E.FLOOR_ABS:
                pool.append((tag, i, rb, rs, meta["budget"]))
    pool.sort(key=lambda t: (t[0], t[1]))
    picks = rng.sample(pool, min(k, len(pool)))
    if not picks:
        _chk(out, "rerun", "skip", "no instance solved by both solvers at a cost above the 0.5 s floor")
        return
    dev, bad = [], []
    ov = harness.calibrate()
    for tag, iid, rb, rs, budget in picks:
        h = next(c for c in commits if c.startswith(tag))
        master = seeds[h].strip().encode()
        dim, idx = rb["dim"], int(iid.rsplit(":", 1)[1])
        inst = derive(master, dim, idx)
        inst["family"] = cert["family"]
        if "args" not in inst:  # lattice families: the solver receives (basis, bound2), as families.derive arranges
            inst["args"] = [inst["basis"], inst["bound2"]]
        a, b = (harness.run_one(paths[role], inst, budget) for role in ("baseline", "submission"))
        if a["status"] != "solved" or b["status"] != "solved":
            bad.append(f"{iid} (seed {tag}): baseline {a['status']}, submission {b['status']} here")
            continue
        ratio_here = (max(a["cpu"] - ov, 1e-3)) / max(b["cpu"] - ov, 1e-3)
        dev.append(abs(math.log2(ratio_here) - math.log2(rb["cpu_net"] / rs["cpu_net"])))
    if bad:
        _chk(out, "rerun", "fail", "did not reproduce: " + "; ".join(bad))
    else:
        med = sorted(dev)[len(dev) // 2]
        _chk(out, "rerun", "pass" if med <= tolerance else "fail",
             f"re-measured {len(dev)} instance(s) here: all solved; median |difference| in speedup {med:.2f} bits (machine and load differ; > {tolerance:g} bits fails)")
        out[-1]["data"] = {"k": len(dev), "median_gap_bits": round(med, 3), "gaps_bits": [round(d, 3) for d in dev], "tolerance_bits": tolerance, "sample_seed": sample_seed}


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("build")
    p.add_argument("--family", required=True)
    p.add_argument("--submission", required=True)
    p.add_argument("--seed-dir", required=True)
    p.add_argument("--reveal-seeds", action="store_true", help="include the seeds: this IS the reveal. Only after the round is evaluated")
    p.add_argument("--baseline")
    p.add_argument("--results-dir")
    p.add_argument("--round-data", help="the operator's data directory (to include the round's log)")
    p.add_argument("--round-id")
    p.add_argument("--private", action="store_true", help="a PRIVATE-SOLVER certificate: no solver source, no failure text (see the module docstring)")
    p.add_argument("--out", required=True)
    p = sub.add_parser("make-private", help="write a private-solver copy of a certificate (the original is untouched)")
    p.add_argument("cert")
    p.add_argument("--out", required=True)
    p = sub.add_parser("verify")
    p.add_argument("cert")
    p.add_argument("--source", metavar="FILE", help="for a private-solver certificate: the solver file its owner has published; it must hash to the committed value, "
                   "and then --rerun can re-measure it")
    p.add_argument("--rerun", type=rerun_count, default=0, metavar="K|all", help="re-measure K instances here, or `all` of them (needs --execute)")
    p.add_argument("--execute", action="store_true", help="RUN code from the certificate on this machine (a declared domain's decl.py, and with --rerun "
                   "its solver sources, unsandboxed): needed for instance coverage of a declared domain and for --rerun. Use a throwaway VM or container.")
    p.add_argument("--tolerance", type=float, default=RERUN_TOLERANCE, help="bits of disagreement --rerun accepts (default %(default)g, loose until cross-machine spread is measured)")
    p.add_argument("--sample-seed", type=int, default=None, help="which instances --rerun re-measures (default: a fresh random draw, yours alone, printed in the verdict)")
    a = ap.parse_args(argv)
    if a.cmd == "build":
        if os.path.exists(a.out):
            raise SystemExit(f"REFUSED: {a.out} exists; a certificate is never overwritten")
        try:
            cert = build(a.family, a.submission, a.seed_dir, a.reveal_seeds, a.baseline, a.results_dir, a.round_data, a.round_id, private=a.private)
        except (CertificateError, SystemExit, KeyError, OSError) as e:
            raise SystemExit(f"REFUSED: {e}")
        fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(cert, f, indent=1, sort_keys=True)
        c = cert["claim"]
        print(f"wrote {a.out}: {c['credit_bits']} bits, {c['status']}" + ("" if cert["seeds_revealed"] else "  (seeds NOT included: sealed certificate)")
              + ("  (PRIVATE SOLVER: source withheld)" if cert.get("private") else ""))
    elif a.cmd == "make-private":
        if os.path.exists(a.out):
            raise SystemExit(f"REFUSED: {a.out} exists; a certificate is never overwritten")
        with open(a.cert, encoding="utf-8") as f:
            cert = json.load(f)
        try:
            priv = make_private(cert)
        except (CertificateError, KeyError, ValueError, TypeError, AttributeError) as e:
            raise SystemExit(f"REFUSED: {e}")
        fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(priv, f, indent=1, sort_keys=True)
        print(f"wrote {a.out}: the same certificate without the solver's source (verify it: certificate.py verify {a.out})")
    else:
        with open(a.cert, encoding="utf-8") as f:
            cert = json.load(f)
        source = None
        if a.source:
            with open(a.source, "rb") as f:   # BYTES: the committed hash is of the file's exact bytes
                source = f.read()
        if a.sample_seed is None:   # the prover must not be able to predict which instances are re-run: the default is the verifier's own random draw
            a.sample_seed = secrets.randbelow(2 ** 31)
        res = verify(cert, rerun=a.rerun, execute=a.execute, tolerance=a.tolerance, sample_seed=a.sample_seed, source=source)
        for c in res["checks"]:
            print(f"  {c['status'].upper():4s} {c['check']}: {c['detail']}")
        if res["ok"]:
            print(f"VERIFIED: {res['claim']['credit_bits']} bits ({res['claim']['status']})"
                  + (" [PRIVATE SOLVER: not inspectable or re-runnable here]" if res.get("private") and not res.get("source_revealed") else ""))
        else:
            print("NOT VERIFIED")
        sys.exit(0 if res["ok"] else 1)


if __name__ == "__main__":
    main()
