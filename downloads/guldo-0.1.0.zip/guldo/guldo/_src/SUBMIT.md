# Submit a solver and verify the result, from the command line

Everything below is `svp.py`: standard library only, one file, no browser. It talks to a round's public service (`public_portal.py`) over
HTTP(S) and checks everything it can on your own machine.

    python3 svp.py --help

It needs Python 3.9 or newer on macOS or Linux (the protocol code it shares with the operator tools uses POSIX file locking; Windows is not supported).
Set the server once: `export SVP_SERVER=https://ledger.example.org` (or pass `--server` each time). Your receipts and tokens are kept in
`$SVP_HOME` (default `~/.svp`, mode 0600).

## 1. Try your solver first (no server)

    python3 submit_check.py my_solver.py --family dlog      # lint + well-formed on tiny public practice questions (seconds)
    python3 svp.py practice my_solver.py --family dlog      # prints the plan and its cost, runs nothing
    python3 svp.py practice my_solver.py --family dlog --yes --n 12 --budget 60

`practice` evaluates your solver on three seeds **of your own** in bare local mode, builds a certificate, and verifies it. The result is
PROVISIONAL by construction (you knew the seeds, and nothing ran in the sandbox), but it is a real, re-checkable file: `svp.py verify FILE`.
It writes only the certificate; the temporary ladders and seeds it creates are removed.

## 2. Submit to a round

    svp.py rounds                                  # what the server runs
    svp.py round winter-1                          # deadline, family, the seed fingerprints, who has submitted
    svp.py submit my_solver.py --round winter-1 --handle alice --accept-rules [--publish-source]

What `submit` does, in order: lints your file locally (so a rejection costs nothing), reads the round and refuses unless it is open, uploads, then
**checks the server's answer instead of trusting it**: the hash the server stored must equal the hash of your file, and your receipt must appear
in the server's public log, whose hash chain it verifies itself. It saves the receipt, and the handle's token (shown once), on your machine.

* `--accept-rules` is required: you confirm you read `RULES.md`.
* `--publish-source` makes your source public after the seeds are revealed, and your public certificate carries it, so anyone can re-run it. **Without it your
  solver stays private** (see "Private solvers" below): the public certificate carries only its hash.
* A handle already used in the round needs its token (saved automatically on the machine you first submitted from, or `--token`).
* Your file is read, never run, while the round is open. It runs only after the round closes, in the sandbox, on seeds committed before it opened.

## 3. Follow it

    svp.py status --round winter-1                 # your submissions in that round (from your receipts)
    svp.py status --round winter-1 --wait 3600     # poll until it is evaluated; prints only when something changes

## 4. Verify the result

After the operator evaluates the round and reveals the seeds, a certificate exists for each evaluated submission:

    svp.py verify --round winter-1 --id <your id>

This downloads the certificate and checks, on your machine:

| check | what it shows |
|---|---|
| server: round revealed / same seed fingerprints | the certificate is for this round and names the fingerprints the round published |
| server: log matches | the certificate's log is **the server's own published log**, so the operator is not showing different logs to different people |
| your receipt | the file that was evaluated is the file you uploaded, and your logged entry is in the certificate's log |
| rules, sources, domain, log, seeds, ladders, coverage, credit | everything `certificate.py verify` checks: the questions are exactly the seeds', the fingerprints were public before any submission, the credit follows from the recorded timings |

The last line says whether the timings were measured in **the Docker sandbox or in bare local mode (then at most PROVISIONAL)**, and what the
check does not prove. Exit status: 0 verified, 1 a check failed, 2 could not do it (not ready, network, usage). `--json` gives the same as data.

    svp.py verify cert.json                        # a certificate file you already have: no server, no network
    svp.py verify --round winter-1 --id <id> --rerun 5 --execute     # also re-measure 5 instances here (throwaway VM only!)
    svp.py certificate --round winter-1 --id <id> --out mine.cert.json
    svp.py certificate --round winter-1 --id <id> --full             # YOUR full certificate, with your source (needs your token)

`--execute` runs code from the certificate (the declaration, and with `--rerun` the solvers) on your machine, **unsandboxed**. Use a throwaway
VM. `--rerun` picks its instances from a random draw of your own, so the operator cannot know which ones you will re-measure.

## Provable costs: step counting

Seconds on someone's machine cannot be proved: they depend on the hardware, the load and a sandbox you have to trust. A **count** can. In counted mode the
cost of a question is the number of Python bytecode instructions the solver executes (`count_runner.py`, using `sys.monitoring`, Python 3.12+). A deterministic
program on the same input gives the same number on any machine running the same Python version, so a verifier does not trust anyone's hardware or clock: it
re-executes and compares, and equality is the proof. (A solver that depends on memory addresses, the clock or randomness does not count the same twice;
`practice --count` checks for that before it spends any time and refuses to certify it.)

    svp.py practice my_factorer.py --family factor --count --dims 38 40 42 --n 8 --cap 40 --yes   # a counted run on three seeds of your own
    svp.py verify my.dlog.practice.cert.json --rerun 5 --execute                           # re-execute 5 questions of BOTH solvers: counts must be IDENTICAL
    python3 counted.py check my_factorer.py --family factor --dim 38 --cap 40              # is this solver deterministic here? (run it twice)

`factor` is the family to start with: its baseline (`solvers/factor_trial_py.py`, trial division) is plain Python, so its counts mean something; the smaller factor
has about half the bits of N, so at 38-42 bits it should cost roughly 2 to 17 counted seconds per question (an estimate from reading the loop, not yet measured),
above the estimator's 0.5 floor with room to spare, and under the cap of 40; a solver a few times faster still clears the floor. (At 36 bits it is marginal.) `solvers/factor_trial_fast_py.py` is a ready-made example (6k+/-1 trial division): `make practice-count SOLVER=solvers/factor_trial_fast_py.py`. The lattice
families (`gm`, `mlwe`) are refused in counted mode, because their baseline is fpylll (work inside C).

What a counted certificate proves: the arithmetic and the fairness as before, and, for every instance you re-run, that the recorded cost is **exactly**
what that program executes (no tolerance, no clock, no sandbox). The instances you do NOT re-run are covered only statistically: someone who falsified a
fraction f of the records escapes K random checks with probability (1-f)^K, and the verdict says how many of how many you re-ran. For certainty re-run all
of them: `--rerun all` (it costs about as much as the original run, and the verdict then has no "covered only statistically" remainder). The instances
checked are your own random draw by default (printed in the verdict), so the prover cannot know which ones to make honest. `practice --count` refuses a solver or interpreter whose count changes between two identical
runs before it spends any time. A different Python version is a SKIP with the reason, because instruction counts are only comparable on the same one.

What it cannot do, and the verdict says it every time:
* **It is not a time.** Bytecode instructions are not seconds. A "counted second" is only a unit (one million instructions), chosen so the estimator's
  0.5-second floor is reachable: a size counts only if the solver's typical cost there is at least 0.5, so the baseline needs a few counted seconds
  (the default cap is 20). Pick `--dims` accordingly, or every size is dropped and the credit is inconclusive.
* **It is blind to work inside C functions.** `pow(a, b, m)` on huge integers, `sorted`, `sum`, numpy and fpylll each cost ONE instruction however long they
  run, so a solver can hide its work in a C call. A counted result means something only when the work is in Python code on both sides; do not use it to
  compare an algorithm that leans on C builtins with one that does not.
* **The ladder is the prover's, unless a round declared it.** Counting is roughly 100x slower than running, so counted ladders use small sizes and a small cap. For
  your own `practice --count` run they are chosen by you, so it is **not** an official round result. In a **counted round** (`svp.py round ID` shows
  "cost model: STEP COUNTING") the operator committed the sizes, the questions per size, the cap, the Python version and the counting program in the round's first
  log entry before any submission: everyone is counted on the same ladder, every source is public, and anyone can re-execute any count with `svp.py verify
  --round ID --id X --rerun all --execute` on that Python (throwaway VM). Its status is `COUNTED`, not `OFFICIAL`: it is not a timing in a verified sandbox.
  Test your solver first with `python3 counted.py check my_solver.py --family factor --dim 38`: a solver whose count changes between two runs, or that reads
  anything outside its arguments, will not reproduce.
* **A counted solver is written in a restricted subset of Python**: pure computation (loops, arithmetic, lists/dicts/sets, classes, generators, `print`, the common
  exceptions), with imports only from `math`, `itertools`, `heapq`, `bisect`, `functools`, `collections` and `fractions` (each exposing named functions only). No `sys`,
  `os`, files, `getattr`/`type`/`eval`/`open`, dunder or underscore attributes, `str.format` (use f-strings or `%`), frame or traceback access. The counter enforces this
  itself, and `practice --count` and `svp.py submit` tell you what is outside it before spending any time. Top-level code is counted too, so precomputing at import
  time costs what it costs. This is a sandbox for the counter's own integrity; it is still wise to run other people's certificates in a throwaway VM.

## Private solvers

Submit without `--publish-source` and your algorithm stays out of public view. After the reveal, the public certificate for your submission is a
**private-solver certificate**: it has no source and no failure messages (a crash message is a traceback, and a traceback quotes your code), and keeps
everything else, including your solver's hash, which the round's log committed to before the seeds were revealed. Anyone can download it without a
token and `svp.py verify` it: the log, the fingerprints, the questions, the rules and the credit arithmetic all check out.

An operator can make publishing mandatory for a round (`ops.py round-new --require-source`): that is a public rule in the round's first log entry, shown by
`svp.py round ID`, and `svp.py submit` then refuses to upload without `--publish-source`.

What a private solver costs, and the verdict says it every time:
* **Nobody but the operator can inspect or re-run it.** The timings therefore rest on the operator's sandbox alone (which has not been verified on a real
  host yet), not on anyone re-measuring them. `--rerun` skips with that reason.
* **It is hidden from the public, not from the operator**, who ran your file. Hiding it from the operator too would need trusted hardware or a
  zero-knowledge proof of execution; neither is feasible for solvers that run for minutes.
* **What still leaks.** Your solver's hash is public (it is in the log), so a very short or highly guessable file could be confirmed by someone guessing
  candidates: put a long random comment in the file if that matters. And the certificate carries the raw timing of every instance, so anyone can see how
  your solver's cost grows with problem size (that is what a speedup claim is), though not how it works.
* Attestations of a private-solver certificate are marked as weaker evidence.
* The static-check warnings (they name line numbers, modules and calls your file uses) are shown to you when you submit and are **not** published for a
  private solver.

If you publish your file later (a gist, a repository, anywhere), anyone can upgrade the check:

    svp.py verify --round winter-1 --id <id> --source my_solver.py                  # hash-check it against the committed value
    svp.py verify --round winter-1 --id <id> --source my_solver.py --rerun 5 --execute   # and re-measure it (throwaway VM)

`--source` must match the **exact bytes** you submitted: it hashes the file and compares it with the hash in the certificate and the log. A different
file, or the same file with different line endings, is refused. Once it matches, the certificate is as strong as one whose source was published from the
start. `svp.py practice ... --private` writes the same kind of certificate for your own local runs.

## What the client refuses to do

* send your token or source over plain `http` to a remote host (loopback is fine; `--allow-insecure-http` overrides);
* send your token anywhere except a resubmission under that handle and your own full certificate (`--full`): downloading the public certificate,
  private-solver or not, never involves it;
* follow a redirect (it would forward your token); accept more than 16 MiB from the server (64 MiB for a certificate), or wait more than 2 minutes
  (15 for a certificate) for one response; print server text unfiltered;
* upload anything if it cannot keep your receipt and token afterwards (an unwritable `--home` is refused BEFORE the upload, because the token is shown only
  once); and if saving fails after an accepted upload anyway, the receipt and token are printed to the screen so you can write them down;
* save a receipt whose fields are not exactly the shape a real receipt has, or reset a damaged `receipts.json` (it says so and changes nothing, because
  the file may hold the only copy of a token). Two `svp.py` processes at once do not overwrite each other: the store is locked;
* overwrite a certificate, or submit without `--accept-rules`.

## For operators

After `ops.py reveal`, run `ops.py certs --data D --id ROUND --seed-dir S` (DEPLOY.md, "Round lifecycle"). For a submission whose owner published their
source it builds one public certificate. For every other submission it builds two: a **public private-solver copy** (no source, no failure text) that
anyone may download, and the **full certificate**, served only to the handle's token at `/api/cert-full/`. Both are stored only if they verify, and
`ops.py export` publishes the public ones next to the round's log, never the full ones. Without a verified sandbox no round can be evaluated officially,
so every certificate a real round produces today would come from a sandbox that has never passed its self-test on a real host: say so to your users,
and be aware that for a private solver there is nothing else they can check the timings against.

## What this does and does not prove

Verification proves the arithmetic and the fairness. It does not by itself prove that the recorded timings are what a real run took: that rests on
the sandbox (never yet run on a real host) and on independent re-measurement (`--rerun`, attestations from people you trust: `attest.py`). The
certificate says which measured it.
