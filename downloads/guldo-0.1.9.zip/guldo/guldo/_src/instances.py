"""Commit-reveal planted-free SVP instances (Goldstein-Mayer lattices) with NP-checkable solutions.

Every instance is a pure function of (master_seed, dim, idx). The judge publishes
sha256(master_seed) before the submission deadline and reveals master_seed after,
so a submission cannot be tuned to, or contain answers for, the judged instances.
"""
import hashlib
import hmac
import math
import random

PRACTICE_SEED = b"practice-seed-public"
GAP = 1.05  # solution must have norm <= GAP * Gaussian heuristic (Darmstadt SVP-challenge convention)


def commit(master: bytes) -> str:
    return hashlib.sha256(master).hexdigest()


def _is_prime(n: int) -> bool:
    if n < 2:
        return False
    small = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53)
    for q in small:
        if n % q == 0:
            return n == q
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a in small:
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def _next_prime(n: int) -> int:
    n |= 1
    while not _is_prime(n):
        n += 2
    return n


def derive(master: bytes, dim: int, idx: int) -> dict:
    h = hmac.new(master, f"svp-gm-v2:{dim}:{idx}".encode(), hashlib.sha256).digest()
    rng = random.Random(h)
    p = _next_prime(rng.getrandbits(10 * dim) | (1 << (10 * dim - 1)))
    log_gh2 = (2.0 / dim) * math.lgamma(dim / 2 + 1) - math.log(math.pi) + (2.0 / dim) * math.log(p)
    gh2 = math.exp(log_gh2)
    bound2 = int(GAP * GAP * gh2)
    # Plant a typical-length (~Gaussian heuristic) vector w so every instance is guaranteed solvable. Without this,
    # roughly the shortest vector can exceed 1.05*GH at small dimension (observed at dim 40 and 45).
    sigma = math.sqrt(gh2 / dim)
    while True:
        w = [int(round(rng.gauss(0, sigma))) for _ in range(dim)]
        if w[1] != 0 and 0.8 * gh2 <= sum(c * c for c in w) <= bound2:
            break
    xs = [rng.randrange(p) for _ in range(dim - 1)]  # xs[i-1] is x_i, the first coordinate of basis row i
    rest = sum(w[i] * xs[i - 1] for i in range(2, dim))
    xs[0] = ((w[0] - rest) * pow(w[1] % p, -1, p)) % p  # forces w[0] - sum_i w[i]*x_i == 0 (mod p)
    basis = [[p] + [0] * (dim - 1)]
    for i, x in enumerate(xs, start=1):
        row = [x] + [0] * (dim - 1)
        row[i] = 1
        basis.append(row)
    return {"id": f"{dim}:{idx}", "dim": dim, "idx": idx, "p": p, "basis": basis, "bound2": bound2, "planted": w}


def verify(inst: dict, v) -> bool:
    """Solution check: nonzero lattice vector with squared norm <= bound2. Exact integer arithmetic."""
    n, p = inst["dim"], inst["p"]
    if not isinstance(v, list) or len(v) != n or not all(isinstance(c, int) and not isinstance(c, bool) for c in v):
        return False
    if all(c == 0 for c in v):
        return False
    x = inst["basis"]
    if (v[0] - sum(v[i] * x[i][0] for i in range(1, n))) % p != 0:
        return False
    return sum(c * c for c in v) <= inst["bound2"]
