"""The few helpers shared by the local portal (portal.py), the PUBLIC web tier (public_portal.py), the operator tool (ops.py) and the
site builder, kept in a module that imports only the standard library.

Why separate: portal.py imports the report generator, which imports the estimator, which imports numpy. A process that parses strangers'
uploads has no business loading a numeric library, and a server without numpy must be able to run it (test_python_compat.py checks
that public_portal, ops, rounds and submit_check import no third-party library).

  sandbox_fingerprint / write_marker / sandbox_verified   the "sandbox verified" gate (a marker file tied to the sandbox files' hashes)
  parse_multipart                                         a minimal multipart/form-data parser using the stdlib email package
"""
import hashlib
import json
import os
import time
from email.parser import BytesParser
from email.policy import default as email_policy

HERE = os.path.dirname(os.path.abspath(__file__))
MARKER = "SANDBOX_VERIFIED"
SANDBOX_FILES = ["sandbox/meter.py", "sandbox/meter_core.py", "sandbox/Dockerfile.v2", "runner.py", "harness.py"]


def sandbox_fingerprint():
    """sha256 of every file that defines the sandbox (meter, image recipe, runner, and harness.py which builds the docker
    command). The verification marker is only valid while these are unchanged."""
    out = {}
    for rel in SANDBOX_FILES:
        with open(os.path.join(HERE, rel), "rb") as f:
            out[rel] = hashlib.sha256(f.read()).hexdigest()
    return out


def write_marker(base):
    with open(os.path.join(base, MARKER), "w", encoding="utf-8") as f:
        json.dump({"verified_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "files": sandbox_fingerprint()}, f, indent=1)


def sandbox_verified(base):
    """True only if the marker exists AND the sandbox files are byte-identical to what was verified."""
    try:
        with open(os.path.join(base, MARKER), encoding="utf-8") as f:
            return json.load(f).get("files") == sandbox_fingerprint()
    except (OSError, ValueError):
        return False


def parse_multipart(content_type, body):
    """Minimal multipart/form-data parser using the stdlib email package. Returns {field: (filename or None, bytes)}."""
    msg = BytesParser(policy=email_policy).parsebytes(b"Content-Type: " + content_type.encode() + b"\r\n\r\n" + body)
    out = {}
    if not msg.is_multipart():
        return out
    for part in msg.iter_parts():
        name = part.get_param("name", header="content-disposition")
        if name:
            out[name] = (part.get_filename(), part.get_payload(decode=True) or b"")
    return out
