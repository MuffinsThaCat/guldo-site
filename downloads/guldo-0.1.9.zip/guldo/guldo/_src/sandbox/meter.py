"""Judge-controlled container entrypoint. Runs as root; the solver runs as an unprivileged uid in a child process, so it
cannot read /proc/<meter>/fd or forge the meter's result. CPU = rusage of that child (user+sys). Emits ONE JSON line."""
import ctypes
import json
import os
import resource
import signal
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import meter_core  # noqa: E402

SOLVER_UID = int(os.environ.get("SOLVER_UID", "10001"))  # overridable so the meter can be self-tested outside Docker
RUNNER = os.environ.get("RUNNER", "/work/runner.py")
budget = float(os.environ["BUDGET"])
payload = sys.stdin.buffer.read()
deadline = time.time() + budget * 3 + 10
ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)  # PR_SET_CHILD_SUBREAPER: orphans reparent to us even if we are not PID 1


def solver_pids():
    pids = []
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                with open(f"/proc/{d}/status") as f:
                    for line in f:
                        if line.startswith("Uid:"):
                            if int(line.split()[1]) == SOLVER_UID:
                                pids.append(int(d))
                            break
            except OSError:
                pass
    return pids


def drop():
    resource.setrlimit(resource.RLIMIT_CPU, (int(budget) + 1, int(budget) + 1))
    os.setgroups([])
    os.setgid(SOLVER_UID)
    os.setuid(SOLVER_UID)


p = subprocess.Popen([sys.executable, RUNNER, sys.argv[1]], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, preexec_fn=drop, cwd="/tmp",
                     env={"PATH": os.environ.get("PATH", ""), "OMP_NUM_THREADS": "1", "PYTHONHASHSEED": "0"})


def kill_all():
    for pid in solver_pids():
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass


def reap():
    try:
        while os.waitpid(-1, os.WNOHANG)[0]:
            pass
    except ChildProcessError:
        pass


def try_finish():
    try:
        return p.communicate(timeout=1)
    except subprocess.TimeoutExpired:
        return None


overrun = False
try:
    out, err = p.communicate(payload, timeout=max(deadline - time.time(), 1))
except subprocess.TimeoutExpired:
    # Kill EVERY solver process before collecting output: an orphan still holding the stdout pipe would otherwise block
    # communicate() forever (a sleeping daemon could hang the judge). Logic + tests: meter_core.py, test_meter_core.py.
    out, err = meter_core.kill_until_done(kill_all, try_finish)
    overrun = True

# Orphaned descendants (double-fork, parent exits first) reparent to us. Wait for ALL of them and reap them, so their
# CPU lands in RUSAGE_CHILDREN; kill whatever is still alive at the wall deadline.
overrun |= meter_core.drain(solver_pids, kill_all, reap, time.time, time.sleep, deadline)

r = resource.getrusage(resource.RUSAGE_CHILDREN)
sys.stdout.write(json.dumps({"cpu": r.ru_utime + r.ru_stime, "rc": p.returncode, "overrun": overrun,
                             "out": out.decode(errors="replace")[-4_000_000:], "err": err.decode(errors="replace")[-1500:]}))
