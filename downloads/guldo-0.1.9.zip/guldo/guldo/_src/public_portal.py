"""PUBLIC submission service: the web tier. Run it behind a TLS-terminating reverse proxy (deploy/Caddyfile).

  python3 public_portal.py serve --data /srv/ledger/data --host speedup.example.org [--bind 127.0.0.1] [--port 8080] [--trust-proxy]

What this process does: lists rounds, shows each round's commitments and public log, accepts an upload while a round is open,
parses it with `ast` (never imports or runs it), appends it to the round's hash-chained log, and shows its status. What it
never does: execute an upload, read a seed (seeds live in a directory this user cannot read), evaluate anything, or store
contact details or IP addresses. Evaluation is a separate process on a separate user or host (ops.py worker, sandbox-gated).

Threat model, each item with a test (test_public_portal.py):
  * hostile uploads    -> never executed; size limit; UTF-8 only; lint; identical files rejected; rejections store nothing
  * flooding           -> per-IP and global token buckets (429), a hard cap on concurrent connections (503), 10 s socket timeout
  * Host / DNS rebinding, cross-site POST -> Host must be on the allowlist; a POST's Origin, when sent, must be one of our own
  * handle squatting   -> a handle is bound to a secret token issued once; its hash is all that is stored
  * operator cheating  -> every accepted file's hash is in a public hash-chained log (rounds.py) that anyone can verify
  * emergency          -> `touch <data>/KILL_SWITCH` pauses submissions at once, reads keep working
  * certificate log    -> POST /api/log/submit (only with --log-queue) parks a size-capped, shape-checked file for translog.py's worker: this process never verifies a certificate,
                          never runs one, and never holds the log's signing key; its own rate limits and a pending cap bound what a stranger can queue (test_log_portal.py)
  * XSS / injection    -> every dynamic string is escaped, handles are validated, strict CSP (no inline script or style)
"""
import argparse
import hashlib
import html
import json
import os
import re
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import families
import logqueue
import portal_core
import rounds
import site_assets

HERE = os.path.dirname(os.path.abspath(__file__))
RULES_VERSION = "draft-1"
LOOPBACK = ("127.0.0.1", "localhost")
# the CSP forbids inline style attributes, so everything the pages need beyond the site stylesheet lives here
EXTRA_CSS = """
.brk{word-break:break-all}
.verify input[type=text],.verify input[type=file]{font:13px var(--mono);padding:10px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink);width:100%;min-width:0}
.verify label.small{display:flex;gap:8px;align-items:flex-start}
button.btn{cursor:pointer;font:600 15px var(--body)}
"""


class RateLimiter:
    """Token buckets keyed by a hash of the client address (the address itself is never kept). Memory is bounded."""

    def __init__(self, per_second, burst, max_keys=20000, clock=time.monotonic):
        self.rate, self.burst, self.max_keys, self.clock = per_second, burst, max_keys, clock
        self.buckets = {}
        self.lock = threading.Lock()

    def allow(self, key):
        now = self.clock()
        with self.lock:
            tokens, last = self.buckets.get(key, (self.burst, now))
            tokens = min(self.burst, tokens + (now - last) * self.rate)
            if tokens < 1:
                self.buckets[key] = (tokens, now)
                return False
            if len(self.buckets) >= self.max_keys and key not in self.buckets:
                oldest = sorted(self.buckets, key=lambda k: self.buckets[k][1])[: self.max_keys // 10]
                for k in oldest:  # evict the stalest tenth: an attacker spraying addresses cannot grow memory without bound
                    del self.buckets[k]
            self.buckets[key] = (tokens - 1, now)
            return True


class Config:
    def __init__(self, base, allowed_hosts=(), trust_proxy=False, max_conns=64, site_url="", clock=time.time, log_queue=None):
        self.base = os.path.abspath(base)
        self.log_queue = os.path.abspath(log_queue) if log_queue else None   # the certificate log's submission queue (logqueue.py); None = the endpoint does not exist
        self.log_submit_limiter = RateLimiter(10 / 3600, 3)                  # 10 files / hour / address, burst 3: each costs the WORKER a verification
        self.global_log_limiter = RateLimiter(200 / 3600, 20)
        self.log_max_bytes = 4 << 20
        self.log_max_pending = 200
        self.allowed_hosts = {h.lower() for h in allowed_hosts}
        self.trust_proxy = trust_proxy
        self.site_url = site_url.rstrip("/")
        self.clock = clock
        self.ip_salt = os.urandom(16)  # per-process: address hashes cannot be linked across restarts
        self.get_limiter = RateLimiter(2.0, 40)            # 120 requests / minute, burst 40
        self.submit_limiter = RateLimiter(6 / 3600, 3)     # 6 submissions / hour / address, burst 3
        self.global_submit_limiter = RateLimiter(300 / 3600, 20)
        self.max_conns = max_conns
        os.makedirs(os.path.join(self.base, "rounds"), exist_ok=True)
        if self.log_queue:
            os.makedirs(self.log_queue, exist_ok=True)

    def killed(self):
        return os.path.exists(os.path.join(self.base, "KILL_SWITCH"))


# ------------------------------------------------------------------ pages
def e(x):
    return html.escape(str(x), quote=True)


def utc(ts):
    return time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(ts))


FAVICON = ("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 28 28'%3E%3Crect width='28' height='28' rx='6' fill='%232A78D6'/%3E"
           "%3Cpath d='M6 20h4v-4h4v-4h4V8h4' fill='none' stroke='white' stroke-width='2.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")


def layout(cfg, title, body):
    back = f'<a href="{e(cfg.site_url)}/index.html">Main site</a>' if cfg.site_url else ""
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(title)} - Guldo</title><meta name="color-scheme" content="light dark"><meta name="robots" content="noindex">
<link rel="icon" href="{FAVICON}"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600&family=Instrument+Sans:wght@400;600&family=JetBrains+Mono:wght@400;600&display=swap">
<link rel="stylesheet" href="/portal-assets/site.css"></head><body><a class="skip" href="#main">Skip to content</a>
<div class="wrap"><header class="top"><a class="brand" href="/">Guldo <span class="muted small">submissions</span></a>
<nav class="main" aria-label="Main"><a href="/">Rounds</a>{back}<button class="theme" id="theme-toggle" type="button" aria-pressed="false">Dark mode</button></nav></header>
<main id="main">{body}</main>
<footer class="foot"><p>Nothing here is run until a round has closed, and then only inside a verified sandbox. Every accepted file's hash is in a public log you can check.</p></footer></div>
<div id="tip" role="tooltip"></div><script src="/portal-assets/site.js"></script></body></html>"""


def state_pill(state):
    kind = {"open": "ok", "closed": "warn", "evaluating": "warn", "evaluated": "info", "revealed": "info"}[state]
    return f'<span class="pill {kind}"><span>{e(state)}</span></span>'


def page_rounds(cfg):
    rows = []
    for r in rounds.list_rounds(cfg.base):
        n = len(rounds.list_submissions(cfg.base, r["id"]))
        rows.append(f'<tr><td class="strong"><a href="/round/{e(r["id"])}">{e(r["title"])}</a></td><td>{e(r["family"])}</td><td>{state_pill(r["state"])}</td>'
                    f'<td class="mono small">{e(utc(r["closes_at"]))}</td><td class="num mono">{n}</td></tr>')
    table = ('<div class="scroll"><table class="lb"><thead><tr><th>Round</th><th>Family</th><th>State</th><th>Closes</th><th class="num">Submissions</th></tr></thead>'
             f'<tbody>{"".join(rows)}</tbody></table></div>') if rows else '<p class="muted">No rounds yet.</p>'
    paused = '<div class="banner" role="note"><p><strong>Submissions are paused.</strong> The operator has switched them off for now.</p></div>' if cfg.killed() else ""
    body = f"""<section class="block"><p class="kicker">Submissions</p><h1>Rounds</h1>
<p class="lede">Each round publishes its seed commitments before it opens. You submit one Python file; after the deadline it is run in a sandbox on the committed instances, and the seeds are revealed.</p></section>
{paused}<section class="card"><h2>All rounds</h2>{table}</section>"""
    return layout(cfg, "Rounds", body)


def page_round(cfg, rid, flash=""):
    pr = rounds.public_round(cfg.base, rid)
    ok = pr["log_ok"]
    commits = "".join(f'<li class="mono small brk">{e(c)}</li>' for c in pr["commitments"])
    subs = "".join(f'<tr><td class="strong">{e(s["handle"])}</td><td class="mono small">{e(s["sha256"][:16])}...</td><td class="mono small">{e(utc(s["submitted_at"]))}</td>'
                   f'<td class="num mono">{s["seq"]}</td><td>{e(s["state"])}</td>'
                   f'<td>{result_cell(s)}</td><td><a href="/s/{e(rid)}/{e(s["id"])}">status</a></td></tr>' for s in pr["submissions"])
    table = ('<div class="scroll"><table class="lb"><thead><tr><th>Handle</th><th>File hash</th><th>Received</th><th class="num">Log #</th><th>State</th><th>Credit</th><th></th></tr></thead>'
             f'<tbody>{subs}</tbody></table></div>') if subs else '<p class="muted">No submissions yet.</p>'
    form = ""
    must_publish = not pr.get("allow_private", True)
    pub_required = " required" if must_publish else ""
    pub_suffix = " (this round requires it)" if must_publish else ""
    pub_hint = "" if must_publish else ('<p class="small muted">Leave it unticked and your solver stays private: after the reveal the public certificate carries only its '
                                        'fingerprint, nobody but the operator can run it, and others must trust the operator\'s sandbox for your timings.</p>')
    if pr["state"] == "open" and not cfg.killed():
        form = f"""<section class="card"><h2>Submit a solver</h2>
<form class="verify" method="post" action="/round/{e(rid)}/submit" enctype="multipart/form-data">
<label for="handle" class="small muted">Handle (public)</label><input id="handle" name="handle" type="text" maxlength="32" required autocomplete="off" placeholder="my_solver">
<label for="token" class="small muted">Token (only if you have already submitted under this handle this round)</label><input id="token" name="token" type="text" autocomplete="off">
<label for="file" class="small muted">Python file</label><input id="file" name="file" type="file" accept=".py" required>
<label class="small"><input type="checkbox" name="publish_source"{pub_required}> Publish my source after the seeds are revealed{pub_suffix}</label>{pub_hint}
<label class="small"><input type="checkbox" name="agree" required> I accept the rules ({e(RULES_VERSION)}, a draft: see RULES.md)</label>
<div class="btnrow"><button class="btn primary" type="submit">Check and submit</button></div></form>
<p class="small muted">Your file is read, never run, until the round closes. It should expose <span class="mono">solve</span> for this family; see the Compete page of the main site.</p></section>"""
    elif pr["state"] == "open":
        form = '<div class="banner" role="note"><p><strong>Submissions are paused.</strong></p></div>'
    seeds = ""
    if pr["state"] == "revealed":
        seeds = ('<section class="card"><h2>Revealed seeds</h2><p class="fine">Each seed hashes to one of the commitments above; check it on the main site\'s Pre-registrations page.</p><ul>'
                 + "".join(f'<li class="mono small brk">{e(s)}</li>' for s in pr["seeds"].values()) + "</ul></section>")
    flash_html = f'<div class="banner" role="status"><p>{e(flash)}</p></div>' if flash else ""
    logline = ("The log verifies: every entry chains to the one before it." if ok else f"LOG PROBLEM: {e(pr['log_error'])}")
    if pr["consistency_problems"]:
        logline += " CONSISTENCY PROBLEM: " + e("; ".join(pr["consistency_problems"][:3])) + ("..." if len(pr["consistency_problems"]) > 3 else "")
    body = f"""<section class="block"><p class="kicker">{e(pr["family"])} round</p><h1>{e(pr["title"])}</h1>
<p class="lede">Opens {e(utc(pr["opens_at"]))}. Closes {e(utc(pr["closes_at"]))}. Accepts up to {pr["max_submissions"]} submissions ({len(pr["submissions"])} so far). {pr["n"]} instances per size. State: {state_pill(pr["state"])}</p></section>{flash_html}{form}
<section class="card"><h2>Seed commitments</h2><p class="fine">SHA-256 of each secret seed, published when the round was created and recorded as entry 0 of the log. Instances are derived from the seeds, so they could not be chosen after seeing submissions.</p><ul>{commits}</ul></section>
<section class="card"><h2>Submissions</h2>{table}
<p class="fine">{logline} {pr["log_entries"]} entries, head <span class="mono small">{e((pr["log_head"] or "")[:16])}...</span>. <a href="/api/log/{e(rid)}.jsonl">Download the log</a> and <a href="/api/round/{e(rid)}.json">the round as JSON</a>.</p></section>{seeds}"""
    return layout(cfg, pr["title"], body)


def result_cell(s):
    res = s.get("result")
    if not res:
        return '<span class="muted small">pending</span>' if "result" not in s else '<span class="muted small">none</span>'
    return f'<span class="mono">{e(res["credit"])}</span> <span class="small muted">{e(res["status"])}</span>'


def page_submission(cfg, rid, sid):
    r = rounds.get_round(cfg.base, rid)
    m = rounds.public_submission(cfg.base, rid, rounds.get_submission(cfg.base, rid, sid), r)
    warns = "".join(f"<li>{e(w)}</li>" for w in m["warnings"])
    res = ""
    if "result" in m:
        res = (f'<dl class="facts"><div><dt>Credit</dt><dd class="mono">{e(m["result"]["credit"] if m["result"] else "none")}</dd></div>'
               f'<div><dt>Status</dt><dd>{e(m["result"]["status"] if m["result"] else m.get("reason", ""))}</dd></div></dl>')
    src = f'<details><summary>Source</summary><pre>{e(m["source"])}</pre></details>' if "source" in m else ""
    body = f"""<section class="block"><p class="kicker">Submission</p><h1>{e(m["handle"])}</h1></section>
<section class="card"><dl class="facts"><div><dt>Round</dt><dd><a href="/round/{e(rid)}">{e(r["title"])}</a></dd></div>
<div><dt>State</dt><dd>{e(m["state"])}</dd></div><div><dt>Received</dt><dd>{e(utc(m["submitted_at"]))}</dd></div>
<div><dt>File sha256</dt><dd class="mono small brk">{e(m["sha256"])}</dd></div>
<div><dt>Log entry</dt><dd class="mono small">#{m["seq"]}, hash {e(m["log_hash"])}</dd></div></dl>
{('<h3>Static-check warnings</h3><ul>' + warns + '</ul>') if warns else ''}{res}{src}
<p class="fine">To check this receipt, download the round's log and confirm entry #{m["seq"]} carries your file's hash and the chain verifies.</p></section>"""
    return layout(cfg, f"Submission {sid}", body)


def page_receipt(cfg, rid, out, handle):
    token = (f'<div class="banner" role="note"><p><strong>Keep this token: {e(out["token"])}</strong> It is shown once and proves the handle is yours; '
             'it is needed to submit again under this handle in this round. We store only its hash.</p></div>') if "token" in out else ""
    warns = "".join(f"<li>{e(w)}</li>" for w in out["warnings"])
    body = f"""<section class="block"><p class="kicker">Received</p><h1>Submission accepted</h1></section>{token}
<section class="card"><dl class="facts"><div><dt>Handle</dt><dd>{e(handle)}</dd></div><div><dt>File sha256</dt><dd class="mono small brk">{e(out["sha256"])}</dd></div>
<div><dt>Log entry</dt><dd class="mono small">#{out["seq"]}, hash {e(out["hash"])}</dd></div></dl>
{('<h3>Warnings</h3><ul>' + warns + '</ul><p class="fine">Warnings are not rejections; they list things the sandbox will block or treat as evasion.</p>') if warns else ''}
<p><a class="btn" href="/s/{e(rid)}/{e(out["id"])}">Status page</a> <a class="btn" href="/round/{e(rid)}">Back to the round</a></p></section>"""
    return layout(cfg, "Submission accepted", body)


# ------------------------------------------------------------------ http
class Server(ThreadingHTTPServer):
    # Request threads are daemon threads and the server counts its OWN in-flight requests. server_close() waits for that counter to reach
    # zero (bounded by drain_seconds, itself bounded by the 10 s socket timeout), so a restart during a submission cannot cut it between the
    # log append and the metadata write. Not using the standard library's non-daemon thread list is deliberate: how it tracks and prunes
    # finished threads has changed between Python versions, and a list that kept every finished thread would grow without bound.
    daemon_threads = True
    block_on_close = False
    request_queue_size = 64
    drain_seconds = 15

    def __init__(self, addr, handler, max_conns):
        # Set BEFORE super().__init__: if binding fails, TCPServer.__init__ calls server_close() from inside it, and server_close() uses
        # these. (Setting them afterwards masked the real "address already in use" with an AttributeError.)
        self._gate = threading.BoundedSemaphore(max_conns)
        self._idle = threading.Condition()
        self._active = 0
        super().__init__(addr, handler)

    def _finish(self):
        self._gate.release()
        with self._idle:
            self._active -= 1
            self._idle.notify_all()

    def wait_idle(self, timeout):
        """True once no request is being handled, False if `timeout` seconds pass first."""
        with self._idle:
            return self._idle.wait_for(lambda: self._active == 0, timeout)

    def process_request(self, request, client_address):
        if not self._gate.acquire(blocking=False):  # over the connection cap: refuse at once rather than queue threads (not counted)
            try:
                request.sendall(b"HTTP/1.1 503 Service Unavailable\r\nContent-Length: 0\r\nRetry-After: 5\r\nConnection: close\r\n\r\n")
            except OSError:
                pass
            self.shutdown_request(request)
            return
        with self._idle:
            self._active += 1
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._finish()  # the thread never started, so nothing else will release the slot
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._finish()

    def server_close(self):
        super().server_close()  # stop accepting first
        self.wait_idle(self.drain_seconds)  # then let the requests already in flight finish


class Handler(BaseHTTPRequestHandler):
    cfg = None
    timeout = 10  # seconds a client may stall on any read
    server_version = "ledger"
    sys_version = ""

    def log_message(self, *a):
        pass  # no access log: addresses are not recorded

    # -- guards
    def client_key(self):
        ip = self.client_address[0]
        if self.cfg.trust_proxy and ip in LOOPBACK:
            xff = (self.headers.get("X-Forwarded-For") or "").split(",")
            if xff and xff[-1].strip():  # the LAST hop is the one our own proxy appended; earlier entries are client-supplied
                ip = xff[-1].strip()
        return hashlib.sha256(self.cfg.ip_salt + ip.encode()).hexdigest()[:20]

    def _host_ok(self):
        host = (self.headers.get("Host") or "").lower()
        port = self.server.server_address[1]
        return host in self.cfg.allowed_hosts or host in (f"127.0.0.1:{port}", f"localhost:{port}")

    def _origin_ok(self):
        origin = (self.headers.get("Origin") or "").lower()
        if not origin:
            return self.headers.get("Sec-Fetch-Site") != "cross-site"  # no ambient credentials exist, so non-browser clients are fine
        port = self.server.server_address[1]
        allowed = {f"https://{h}" for h in self.cfg.allowed_hosts} | {f"http://{h}" for h in self.cfg.allowed_hosts}
        allowed |= {f"http://127.0.0.1:{port}", f"http://localhost:{port}"}
        return origin in allowed

    def _send(self, code, payload, ctype="text/html; charset=utf-8", cache="no-store", extra=()):
        if isinstance(payload, str):
            payload = payload.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
                         "script-src 'self'; img-src data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
        if self.cfg.allowed_hosts:  # a public deployment is served over HTTPS by the proxy; browsers ignore this header on plain HTTP
            self.send_header("Strict-Transport-Security", "max-age=31536000")
        for k, v in extra:
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(payload)

    def _text(self, code, msg, extra=()):
        self._send(code, msg, "text/plain; charset=utf-8", extra=extra)

    def send_error(self, code, message=None, explain=None):
        """Every protocol-level error (unsupported method, overlong URI, bad request line, bad version, too many headers) is answered here
        by the stdlib's own send_error, which would bypass our security headers and return an HTML page that reflects the request.
        Answer them with the same hardened plain-text response as everything else, and never reflect anything the client sent."""
        if self.request_version == "HTTP/0.9":  # a request line that did not parse: the stdlib would send a bare body with no headers
            self.request_version = "HTTP/1.0"
        self.close_connection = True
        try:
            extra = (("Allow", "GET, HEAD, POST"),) if code in (405, 501) else ()
            self._text(code, f"{code} {self.responses.get(code, ('error',))[0]}", extra=extra)
        except OSError:
            pass

    def _guard(self, limiter):
        if not self._host_ok():
            self._text(403, "forbidden: unexpected Host header")
            return False
        if not limiter.allow(self.client_key()):
            self._text(429, "too many requests", extra=(("Retry-After", "60"),))
            return False
        return True

    # -- routes
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/healthz":
            return self._text(200, "ok")
        if not self._guard(self.cfg.get_limiter):
            return
        try:
            rounds.close_due(self.cfg.base, self.cfg.clock())
            if path == "/":
                return self._send(200, page_rounds(self.cfg))
            if path == "/portal-assets/site.css":  # NOT /assets/: that path belongs to the static site on a single-domain deployment
                return self._send(200, site_assets.CSS + EXTRA_CSS, "text/css; charset=utf-8", cache="public, max-age=300")
            if path == "/portal-assets/site.js":
                return self._send(200, site_assets.JS, "text/javascript; charset=utf-8", cache="public, max-age=300")
            if path == "/api/rounds.json":
                return self._send(200, json.dumps([rounds.public_round(self.cfg.base, r["id"]) for r in rounds.list_rounds(self.cfg.base)]), "application/json")
            m = re.fullmatch(r"/api/log/submission/([0-9a-f]{64})\.json", path)
            if m and self.cfg.log_queue:
                st = logqueue.status(self.cfg.log_queue, m.group(1))
                if st is not None:
                    return self._send(200, json.dumps(st), "application/json")
            m = re.fullmatch(r"/round/([a-z0-9-]+)", path)
            if m:
                return self._send(200, page_round(self.cfg, m.group(1)))
            m = re.fullmatch(r"/s/([a-z0-9-]+)/([0-9a-f]{12})", path)
            if m:
                return self._send(200, page_submission(self.cfg, m.group(1), m.group(2)))
            m = re.fullmatch(r"/api/round/([a-z0-9-]+)\.json", path)
            if m:
                return self._send(200, json.dumps(rounds.public_round(self.cfg.base, m.group(1))), "application/json")
            m = re.fullmatch(r"/api/log/([a-z0-9-]+)\.jsonl", path)
            if m:
                with open(os.path.join(rounds.rdir(self.cfg.base, m.group(1)), "log.jsonl"), "rb") as f:
                    return self._send(200, f.read(), "application/x-ndjson")
            m = re.fullmatch(r"/api/cert(-full)?/([a-z0-9-]+)/([0-9a-f]{12})\.json", path)
            if m:
                full = bool(m.group(1))
                token = None
                if full:  # only the FULL certificate (it carries the solver's source) needs the owner's token; the public one never reads the header
                    auth = self.headers.get("Authorization") or ""
                    token = auth[7:].strip() if auth.lower().startswith("bearer ") else None  # a header, never the URL: URLs end up in logs and referrers
                try:
                    cert = rounds.cert_for_download(self.cfg.base, m.group(2), m.group(3), token, full)
                except rounds.Rejected as ex:
                    return self._send(403, json.dumps({"ok": False, "error": str(ex)}), "application/json")
                with open(cert, "rb") as f:
                    return self._send(200, f.read(), "application/json")
        except (KeyError, OSError):
            pass
        except Exception:  # a bug must be a clean 500 (nothing echoed), not a dropped connection; the service keeps running
            return self._text(500, "internal error")
        self._text(404, "not found")

    def _log_submit(self):
        """POST /api/log/submit: park a certificate or an attestation for the log's worker. Only shape and size are checked here; nothing is verified, run or signed."""
        if not self._host_ok():
            return self._text(403, "forbidden: unexpected Host header")
        if not self._origin_ok():
            return self._text(403, "forbidden: cross-site request")
        if not self.cfg.log_queue:
            return self._text(404, "not found")
        if self.cfg.killed():
            return self._text(503, "submissions are paused", extra=(("Retry-After", "3600"),))
        if not (self.cfg.log_submit_limiter.allow(self.client_key()) and self.cfg.global_log_limiter.allow("global")):
            return self._text(429, "too many submissions; try again later", extra=(("Retry-After", "3600"),))
        raw_len = self.headers.get("Content-Length") or ""
        if not re.fullmatch(r"[0-9]{1,9}", raw_len):
            return self._text(400, "invalid Content-Length")
        n = int(raw_len)
        if n > self.cfg.log_max_bytes:
            return self._text(413, "that file is too large")
        try:
            body = self.rfile.read(n)
        except OSError:
            self.close_connection = True
            return
        if len(body) < n:
            return self._text(400, "the upload ended early")
        try:
            sha, state = logqueue.submit(self.cfg.log_queue, body, self.cfg.log_max_bytes, self.cfg.log_max_pending)
        except logqueue.Refused as ex:
            return self._send(422, json.dumps({"ok": False, "error": str(ex)}), "application/json")
        except logqueue.QueueFull:
            return self._text(503, "the queue is full; try again later", extra=(("Retry-After", "600"),))
        except Exception:  # disk full, a bug: a clean 500, nothing echoed
            return self._text(500, "internal error")
        out = {"ok": True, "id": sha, "state": state, "status_url": f"/api/log/submission/{sha}.json"}
        if state == "known":
            out.update(logqueue.status(self.cfg.log_queue, sha) or {})
        self._send(200 if state == "known" else 202, json.dumps(out), "application/json")

    def do_POST(self):
        if self.path.split("?")[0] == "/api/log/submit":
            return self._log_submit()
        m = re.fullmatch(r"/round/([a-z0-9-]+)/submit", self.path.split("?")[0])
        if not self._host_ok():
            return self._text(403, "forbidden: unexpected Host header")
        if not self._origin_ok():
            return self._text(403, "forbidden: cross-site request")
        if not m:
            return self._text(404, "not found")
        rid = m.group(1)
        if self.cfg.killed():
            return self._text(503, "submissions are paused", extra=(("Retry-After", "3600"),))
        if not (self.cfg.submit_limiter.allow(self.client_key()) and self.cfg.global_submit_limiter.allow("global")):
            return self._text(429, "too many submissions; try again later", extra=(("Retry-After", "3600"),))
        raw_len = self.headers.get("Content-Length") or ""
        if not re.fullmatch(r"[0-9]{1,9}", raw_len):
            return self._text(400, "invalid Content-Length")
        n = int(raw_len)
        if n > rounds.MAX_UPLOAD + 20_000:
            return self._text(413, "that upload is too large")
        try:
            body = self.rfile.read(n)
        except OSError:  # includes socket.timeout: a stalled client is dropped, not waited for
            self.close_connection = True
            return
        if len(body) < n:
            return self._text(400, "the upload ended early")
        try:
            form = portal_core.parse_multipart(self.headers.get("Content-Type", ""), body)
        except Exception:
            return self._text(400, "could not read the form")
        if "file" not in form or "handle" not in form:
            return self._text(400, "missing handle or file")
        as_json = "application/json" in (self.headers.get("Accept") or "")  # command-line clients (svp.py) ask for JSON; browsers get the pages
        if "agree" not in form:
            if as_json:
                return self._send(422, json.dumps({"ok": False, "error": "you need to accept the rules to submit"}), "application/json")
            return self._send(422, page_round(self.cfg, rid, "You need to accept the rules to submit."))
        handle = form["handle"][1].decode("utf-8", "replace").strip()
        token = form.get("token", (None, b""))[1].decode("utf-8", "replace").strip()
        try:
            out = rounds.submit(self.cfg.base, rid, handle, token, form["file"][1], publish_source="publish_source" in form, now=self.cfg.clock())
        except rounds.Rejected as ex:
            if as_json:
                return self._send(422, json.dumps({"ok": False, "error": str(ex)}), "application/json")
            return self._send(422, page_round(self.cfg, rid, f"Rejected: {ex}"))
        except KeyError:
            return self._text(404, "no such round")
        except Exception:  # disk full, memory, a bug: a clean 500 with nothing echoed; rounds.submit has already removed any partial file
            return self._text(500, "internal error")
        if as_json:
            return self._send(200, json.dumps({"ok": True, "handle": handle, **out}), "application/json")
        self._send(200, page_receipt(self.cfg, rid, out, handle))


def make_server(cfg, bind="127.0.0.1", port=0):
    handler = type("H", (Handler,), {"cfg": cfg})
    return Server((bind, port), handler, cfg.max_conns)


def main():
    rounds.require_python()
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("serve")
    p.add_argument("--data", required=True)
    p.add_argument("--host", action="append", default=[], help="public host name(s) this service answers to (repeat); loopback always works")
    p.add_argument("--bind", default="127.0.0.1", help="leave as 127.0.0.1 and put a TLS reverse proxy in front")
    p.add_argument("--port", type=int, default=8080)
    p.add_argument("--trust-proxy", action="store_true", help="read the client address from X-Forwarded-For (only when bound to loopback behind your proxy)")
    p.add_argument("--site-url", default="", help="public URL of the static site, for the 'Main site' link")
    p.add_argument("--max-conns", type=int, default=64)
    p.add_argument("--log-queue", default=None, help="enable POST /api/log/submit: a directory where certificates and attestations for the public log wait for its worker (translog.py ingest)")
    a = ap.parse_args()
    if a.trust_proxy and a.bind not in LOOPBACK:
        raise SystemExit("REFUSED: --trust-proxy lets any client choose its address; use it only when bound to loopback behind your own proxy")
    os.umask(0o007)  # the operator (same group) must be able to write what this process creates, and others must not read it
    cfg = Config(a.data, a.host, a.trust_proxy, a.max_conns, a.site_url, log_queue=a.log_queue)
    try:
        srv = make_server(cfg, a.bind, a.port)
    except OSError as e:  # port taken, no permission, bad address: a sentence, not a traceback
        raise SystemExit(f"REFUSED: cannot listen on {a.bind}:{a.port} ({e.strerror or e}). Is another copy already running?")
    print(f"public portal on {a.bind}:{srv.server_address[1]} (data {cfg.base}; hosts {sorted(cfg.allowed_hosts) or 'loopback only'}; "
          f"evaluation happens elsewhere: ops.py worker)", flush=True)

    def stop(signum, frame):
        # shutdown() waits for serve_forever() to return, and serve_forever() runs in THIS thread (which is executing this handler),
        # so it must be called from another thread or it would deadlock.
        threading.Thread(target=srv.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)  # systemctl stop/restart
    signal.signal(signal.SIGINT, stop)
    try:
        srv.serve_forever()
    finally:
        srv.server_close()  # stops accepting, then WAITS for the handler threads still running: an in-flight submission is completed, not cut
    print("public portal stopped cleanly", flush=True)


if __name__ == "__main__":
    main()
