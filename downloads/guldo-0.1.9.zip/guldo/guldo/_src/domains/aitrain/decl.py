"""Declaration of an AI-training domain: train a small softmax classifier to a target held-out accuracy using as few operations as you can.

size = d, the number of input features. The training set holds N = 16 d points. Features are ILL-CONDITIONED on purpose: feature j is scaled by 30^(-j/(d-1)), so the
scales run from 1 down to 1/30, and the hidden teacher's weights are scaled inversely, so every feature matters equally to the label even though most of them are small.
Plain gradient descent crawls along the small features; feature scaling, momentum and adaptive steps are the techniques this domain exists to compare.

Neither the teacher nor the test set is shipped. The solver gets the training features (a pure function of one seed through a pinned SplitMix64 stream, the same one
`aiinfer` and `aidecode` use, so a counted solver regenerates them with tensorops.stream) and the training LABELS. The teacher (3 linear classes, labels = argmax of the
teacher's logits) and a 2000-point test set come from two OTHER seeds derived from the round's master seed with HMAC; nobody sees them until the seed is revealed after
the round, so the held-out accuracy cannot be computed in advance and there is nothing to train on but the training set.

The answer is the d x 3 weight matrix as a flat list of d*3 INTEGERS, row-major (feature j, class k at index 3*j + k), each in units of 2^-20 (the timed harness accepts only
integers, and a rounding error of about one millionth does not change a prediction). The judge accepts it iff its accuracy on the hidden test set is at least TARGET (0.85).
That is the "equivalent result" the saving is conditional on: stopping early, or training a worse model, fails the check; training longer than needed only costs operations.

The cost is counted operations (tflops.py): every tensor operation by shape, plus the solver's own Python instructions. It is the arithmetic the training asked for, not a
time, so two training techniques are compared on exactly the same instances, with no machine in the loop. It cannot see memory traffic, kernel quality or GPU speed.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aitrain"
VERSION = "aitrain-v1"        # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 48)
SIZE_STEP = 8
REFERENCE_SOLVER = "reference.py"
K = 3                         # classes
KAPPA = 30.0                  # ratio between the largest and smallest feature scale
N_PER_D = 16                  # training points per feature
N_TEST = 2000
TARGET = 0.85                 # held-out accuracy the weights must reach
SCALE = 2 ** 20               # the answer's integers are weights in units of 1/SCALE
LIMIT = 2 ** 62               # no weight integer may exceed this in size
DOC = ("solve(seed, d, N, labels): the N = 16 d training features are x[i][j] = u * 30^(-j/(d-1)) where u is the i*d+j-th float of the SplitMix64 stream under `seed` "
       "(tensorops.stream(seed, 0, N*d), the same floats as domains/aiinfer); labels is the list of N training classes (ints 0-2). Return the d x 3 weight matrix W as a flat "
       "list of d*3 integers, row-major, each W[j][k] in units of 2^-20, whose predictions argmax(x @ W) are right on at least 85% of a hidden test set drawn from the same "
       "distribution. Return None for no answer.")
REFERENCE_NOTE = ("Plain full-batch gradient descent on the softmax loss: learning rate 2.0, 12000 steps, no feature scaling and no momentum. The slowest of 90 calibration "
                  "instances needed 8580 steps to reach the target, so 12000 passes with margin. Known to be beaten by scaling each feature to unit size (about a hundred "
                  "times fewer steps), by momentum (about ten times fewer) and by adaptive step sizes.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _scales(d):
    return np.array([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])


def _features(seed, d, n):
    return _uniform(seed, 0, n * d).reshape(n, d) * _scales(d)


def _teacher(tseed, d):
    return _uniform(tseed, 0, d * K).reshape(d, K) / _scales(d)[:, None]


def _seed(master, tag, size, idx):
    return int.from_bytes(hmac.new(master, f"aitrain-v1:{tag}:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    d = size
    n = N_PER_D * d
    seed, tseed, vseed = (_seed(master, t, size, idx) for t in ("train", "teacher", "test"))
    Wt = _teacher(tseed, d)
    y = np.argmax(_features(seed, d, n) @ Wt, axis=1)
    planted = [int(v) for v in np.rint(Wt * SCALE).ravel()]
    return {"args": [seed, d, n, [int(v) for v in y]], "planted": planted, "teacher_seed": tseed, "test_seed": vseed}


def verify(inst: dict, ans) -> bool:
    seed, d, n, labels = inst["args"]
    if not isinstance(ans, list) or len(ans) != d * K:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    W = (np.array(ans, dtype=np.float64) / SCALE).reshape(d, K)
    Wt = _teacher(inst["teacher_seed"], d)
    Xt = _features(inst["test_seed"], d, N_TEST)
    return bool(np.mean(np.argmax(Xt @ W, axis=1) == np.argmax(Xt @ Wt, axis=1)) >= TARGET)
