"""Starter submission. Copy this file, change `solve`, run:  python3 submit_check.py solvers/my_solver.py

Contract (details in COMPETITORS.md):
  solve(basis, bound2) -> list[int] | None
  * basis: list of integer row vectors (a lattice basis); bound2: accept any NONZERO lattice vector with squared norm <= bound2
  * return the vector as plain ints, or None if you did not find one (a failure costs the full CPU cap)
  * deterministic, single-process, no files, no network; only fpylll and numpy are available in the judge's sandbox
"""
from fpylll import BKZ, LLL, IntegerMatrix


def solve(basis, bound2):
    n = len(basis)
    A = IntegerMatrix.from_matrix(basis)
    LLL.reduction(A)
    for beta in range(10, n + 1, 4):  # progressive BKZ: replace this with your algorithm
        if sum(x * x for x in A[0]) <= bound2:
            break
        BKZ.reduction(A, BKZ.Param(block_size=beta, flags=BKZ.AUTO_ABORT | BKZ.MAX_LOOPS, max_loops=8))
    v = [int(x) for x in A[0]]
    return v if sum(c * c for c in v) <= bound2 else None
