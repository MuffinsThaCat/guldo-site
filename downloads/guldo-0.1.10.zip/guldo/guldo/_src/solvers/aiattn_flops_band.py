"""aiattn in the counted-operations API, SPEEDUP: compute only the band. Blocks of 32 queries meet the 64 keys that can reach them (their own block and the one before), so no n x n matrix exists."""
import math

import tensorops as tp

D = 16
WINDOW = 32
QK = 3.0


def solve(seed, n):
    m = n * D
    W = WINDOW
    Q = tp.stream(seed, 0, m, (n, D)) * QK
    K = tp.stream(seed, m, m, (n, D)) * QK
    V = tp.stream(seed, 2 * m, m, (n, D))
    M = tp.causal_mask(2 * W)[W:2 * W, 0:2 * W] + tp.transpose(tp.causal_mask(2 * W), (1, 0))[1:W + 1, 0:2 * W]
    parts = []
    for b in range(n // W):
        lo = (b - 1) * W if b > 0 else 0
        Mb = M if b > 0 else M[0:W, W:2 * W]
        S = tp.einsum("id,jd->ij", Q[b * W:(b + 1) * W], K[lo:(b + 1) * W]) / math.sqrt(D) + Mb
        E = tp.exp(S - tp.max(S, 1, True))
        parts.append((E / tp.sum(E, 1, True)) @ V[lo:(b + 1) * W])
    return [int(x * 65536.0) for x in tp.reshape(tp.concat(parts, 0), (n * D,)).tolist()]
