"""Long-horizon, exact reconciliation: two lists that should record the same payments do not, and the agent must find every difference.

size = pages per list (2..10, step 2; 8 payments a page, so 16 to 80 payments a side). The BANK statement and the BOOKS list are only readable one page at a time (`page`) or one payment at a time
(`find`), in DIFFERENT orders, so nothing can be compared page against page: the agent has to read both lists, carry what it read, and match by reference. Three kinds of difference are planted, and
the answer is all of them and nothing else:
  missing_in_books  a payment the bank has and the books do not;   missing_in_bank   one the books have and the bank does not;
  amount_differs    the same reference with different amounts (often the same digits transposed, the classic slip).
Distractors: about a third of the matching payments carry a DIFFERENT description in the two lists, which is not a difference (only reference and amount count).
The judge checks the submitted JSON list against the planted differences exactly (no partial credit, no extra entries). Reading every page of both lists costs `2 * size` calls; targeted `find` calls are
cheaper per call but cannot discover a payment the agent does not already know to ask about, so a mixed strategy trades calls against tokens. The answer does not depend on the order or number of calls,
so the verdict is a pure function of the submitted answer and the instance; the recorded calls matter only for cost."""
import json

import agent_core

NAME = "reconcile"
VERSION = "reconcile-v1"
SIZE_RANGE = (2, 10)
SIZE_STEP = 2
PAGE = 8
KINDS = ("missing_in_books", "missing_in_bank", "amount_differs")
DOC = "Two lists should record the same payments (a bank statement and the books): find every payment that is missing from one list or whose amount differs, and submit them as JSON."
MAX_ANSWER_CHARS = 20000
_WORDS = ("freight", "rent", "payroll", "supplies", "licence", "insurance", "utilities", "travel", "repairs", "consulting", "software", "tax", "refund", "deposit", "catering", "printing")
_PLACES = ("north", "harbour", "central", "east", "west", "ridge", "valley", "lakeside")


def _shuffle(r, items):
    items = list(items)
    for i in range(len(items) - 1, 0, -1):
        j = r.randint(0, i)
        items[i], items[j] = items[j], items[i]
    return items


def _description(r):
    return "%s %s" % (r.choice(_WORDS), r.choice(_PLACES))


def _money(cents):
    return "%d.%02d" % (cents // 100, cents % 100)


def _different_amount(r, cents):
    """A wrong amount for the same payment: usually the same digits with two adjacent ones swapped, otherwise a nearby value. Never equal, always positive."""
    digits = list(str(cents))
    swaps = [i for i in range(len(digits) - 1) if digits[i] != digits[i + 1]]
    if swaps and r.randint(0, 2) > 0:
        i = swaps[r.randint(0, len(swaps) - 1)]
        digits[i], digits[i + 1] = digits[i + 1], digits[i]
        out = int("".join(digits))
        if out != cents and out > 0:
            return out
    while True:
        out = cents + r.randint(-4000, 4000)
        if out > 0 and out != cents:
            return out


def derive(seed, size):
    r = agent_core.Rng(seed)
    n = PAGE * size
    k = size + 2                                                                   # planted differences: 4 at the smallest size, 12 at the largest
    refs, seen = [], set()
    while len(refs) < n + k:
        ref = "P%05d" % r.randint(0, 99999)
        if ref not in seen:
            seen.add(ref)
            refs.append(ref)
    bank_refs, extra_refs = refs[:n], refs[n:]
    amount = {ref: r.randint(500, 250000) for ref in refs}
    desc = {ref: _description(r) for ref in refs}
    bank = [(ref, amount[ref], desc[ref]) for ref in _shuffle(r, bank_refs)]
    # which payments are tampered with, and how: every kind appears at least once
    kinds = [KINDS[i % 3] for i in range(k)]
    kinds = _shuffle(r, kinds)
    victims = _shuffle(r, bank_refs)
    books, truth = {}, []
    for ref in bank_refs:
        # a third of the matching rows get a different description in the books: a distractor, not a difference
        books[ref] = (ref, amount[ref], desc[ref] if r.randint(0, 2) else _description(r))
    vi = ei = 0
    for kind in kinds:
        if kind == "missing_in_bank":
            ref = extra_refs[ei]
            ei += 1
            books[ref] = (ref, amount[ref], desc[ref])
        else:
            ref = victims[vi]
            vi += 1
            if kind == "missing_in_books":
                del books[ref]
            else:
                books[ref] = (ref, _different_amount(r, amount[ref]), books[ref][2])
        truth.append({"ref": ref, "kind": kind})
    truth.sort(key=lambda d: d["ref"])
    books_rows = _shuffle(r, list(books.values()))
    bank_total, books_total = sum(x[1] for x in bank), sum(x[1] for x in books_rows)
    task = ("Statement %s: a bank statement (%d payments, printed total $%s) and the company's books (%d payments, printed total $%s) should record the same payments, each identified by a "
            "reference such as P01234, with an amount in dollars. They do not match. " % ("ST-%04d" % r.randint(0, 9999), len(bank), _money(bank_total), len(books_rows), _money(books_total))) + (
            "Find EVERY payment that is (a) in the bank statement but not in the books (missing_in_books), (b) in the books but not in the bank statement (missing_in_bank), or "
            "(c) in both with different amounts (amount_differs). A different description is NOT a difference: only the reference and the amount count. "
            "Read the lists with `page` (8 payments a page; the two lists are in different orders) or look one payment up with `find`. "
            "Submit a JSON list of objects {\"ref\": ..., \"kind\": ...}, one per difference, sorted by ref, and nothing else.")
    return {"public": {"task": task}, "private": {"bank": [list(x) for x in bank], "books": [list(x) for x in books_rows], "truth": truth}}


def prompt(public):
    return public["task"]


def tool_specs(public):
    src = {"type": "string", "enum": ["bank", "books"]}
    return [
        {"name": "page", "description": "One page (8 payments) of a list: its reference, amount and description.",
         "input_schema": {"type": "object", "properties": {"source": src, "number": {"type": "integer"}}, "required": ["source", "number"]}},
        {"name": "find", "description": "One payment of a list by its reference, or 'not found'.",
         "input_schema": {"type": "object", "properties": {"source": src, "ref": {"type": "string"}}, "required": ["source", "ref"]}},
    ]


def _line(row):
    return "%s %s %s" % (row[0], _money(row[1]), row[2])


class Env:
    def __init__(self, instance):
        self.lists = {"bank": instance["private"]["bank"], "books": instance["private"]["books"]}

    def pages(self, source):
        return (len(self.lists[source]) + PAGE - 1) // PAGE

    def call(self, name, args):
        if not isinstance(args, dict):
            return "error: arguments must be an object"
        source = args.get("source")
        if not isinstance(source, str) or source not in self.lists:                 # not `source not in dict` alone: an unhashable value (a list) would raise
            return "error: source must be 'bank' or 'books'"
        if name == "page":
            number = args.get("number")
            if not isinstance(number, int) or isinstance(number, bool) or not 1 <= number <= self.pages(source):
                return "error: no such page (the %s has pages 1 to %d)" % (source, self.pages(source))
            rows = self.lists[source][(number - 1) * PAGE:number * PAGE]
            return "%s page %d of %d\n" % (source, number, self.pages(source)) + "\n".join(_line(x) for x in rows)
        if name == "find":
            ref = args.get("ref")
            if not isinstance(ref, str):
                return "error: ref must be a string"
            hit = [x for x in self.lists[source] if x[0] == ref]
            return ("%s: %s" % (source, _line(hit[0]))) if hit else "%s: not found" % source
        return "error: unknown tool %r" % name


def make_env(instance):
    return Env(instance)


def parse_page(text):
    """(source, number, total pages, [(ref, cents, description)]) from a `page` result, or None. Used by the scripted agent and the checks."""
    lines = text.split("\n")
    parts = lines[0].split(" ")
    if len(parts) != 5 or parts[1] != "page" or parts[3] != "of":
        return None
    rows = []
    for ln in lines[1:]:
        ref, money, desc = ln.split(" ", 2)
        whole, cents = money.split(".")
        rows.append((ref, int(whole) * 100 + int(cents), desc))
    return parts[0], int(parts[2]), int(parts[4]), rows


def reference_answer(instance):
    return json.dumps(instance["private"]["truth"], sort_keys=True)


def reference_calls(instance):
    env = Env(instance)
    return [{"name": "page", "args": {"source": s, "number": i}} for s in ("bank", "books") for i in range(1, env.pages(s) + 1)]


def verify(instance, answer, calls):
    if isinstance(answer, list) and len(answer) <= 500:                            # a model may pass the list itself instead of its JSON text: same exactness, no penalty for the format
        got = answer
    elif isinstance(answer, str) and len(answer) <= MAX_ANSWER_CHARS:
        try:
            got = json.loads(answer)
        except (ValueError, RecursionError):
            return False, "the answer is not valid JSON"
    else:
        return False, "the answer must be a JSON text (or a list)"
    if not isinstance(got, list) or any(not isinstance(x, dict) or set(x) != {"ref", "kind"} or not isinstance(x["ref"], str) or x["kind"] not in KINDS for x in got):
        return False, "the answer must be a list of {\"ref\": string, \"kind\": one of %s}" % ", ".join(KINDS)
    pairs = [(x["ref"], x["kind"]) for x in got]
    if len(set(pairs)) != len(pairs):
        return False, "the same difference is listed twice"
    want = {(d["ref"], d["kind"]) for d in instance["private"]["truth"]}
    have = set(pairs)
    if have == want:
        return True, "ok"
    missed, spurious = len(want - have), len(have - want)
    return False, "%d difference(s) missed, %d wrong or extra" % (missed, spurious)
