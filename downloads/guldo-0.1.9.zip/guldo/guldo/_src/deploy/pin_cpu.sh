#!/usr/bin/env bash
# Run a command (normally the evaluation worker) so that every `docker run` it starts is pinned to the given CPU core(s).
#
#   bash deploy/pin_cpu.sh 1 -- python3 ops.py worker --data /srv/ledger/data --id lattice-1 --seed-dir /srv/ledger/seeds/lattice-1
#   bash deploy/pin_cpu.sh 2,3 -- ...        (a list or a range such as 2-3 also works)
#
# Why a wrapper: the harness builds its docker command in harness.py, which is one of the hashed files a round's fingerprint pins, so it must not change
# while a round is open. The wrapper changes nothing hashed: it puts a tiny `docker` shim first in PATH, and the shim adds `--cpuset-cpus <set>` right
# after `run` and otherwise passes everything through to the real docker unchanged. Pin to a core the web service and the operating system do not
# need (on a 2-core machine, core 1 leaves core 0 for them), and say which core you used when you publish the round's results: the harness records the
# CPU model but not the pinning.
set -euo pipefail

[ "$#" -ge 3 ] && [ "$2" = "--" ] || { sed -n '2,12p' "$0"; exit 2; }
SET="$1"; shift 2
[[ "$SET" =~ ^[0-9]+([,-][0-9]+)*$ ]] || { echo "bad CPU set: $SET (use e.g. 1, 2,3 or 2-3)"; exit 2; }

REAL="$(command -v docker || true)"
[ -n "$REAL" ] || { echo "docker not found in PATH"; exit 1; }
SHIM_DIR="$(mktemp -d)"
chmod 755 "$SHIM_DIR"   # mktemp makes it 0700: the worker usually runs as ANOTHER user (ledger-ops), which could not enter it and would silently get the real docker
trap 'rm -rf "$SHIM_DIR"' EXIT

cat > "$SHIM_DIR/docker" <<EOF
#!/usr/bin/env bash
if [ "\${1:-}" = "run" ]; then
  shift
  exec "$REAL" run --cpuset-cpus "$SET" "\$@"
fi
exec "$REAL" "\$@"
EOF
chmod +x "$SHIM_DIR/docker"

echo "pin_cpu: every docker run is pinned to CPU set $SET" >&2
PATH="$SHIM_DIR:$PATH" "$@"
