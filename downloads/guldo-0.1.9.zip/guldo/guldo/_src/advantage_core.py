"""Advantage statistics for DISTINGUISHING challenges (standard library only). New file: not in rounds.CODE_FILES or COUNT_FILES, so no open round's fingerprint changes.

A distinguishing attack does not return a witness. On each instance a hidden coin (derived from the committed seed, balanced: exactly half of the instances of a size have
coin 1) decides whether the instance is "real" (e.g. an LWE sample) or "random"; the solver returns its guess, 0 or 1. The guess space is {0, 1} BY DESIGN, so the speed
protocol's anti-guessing checks (junk rejected, no trivial answer) do not apply; the statistic replaces them:

    accuracy p = (correct guesses) / (instances), pooled over sizes;   advantage = 2p - 1   (0 = guessing, 1 = always right)
    credit of one seed = max(0, 2 * L - 1) where L is the exact one-sided Clopper-Pearson lower bound on p at level ALPHA;
    credit over several seeds = the MINIMUM (the speed protocol's convention).

An unanswered instance counts as a wrong guess (not as a coin flip, so refusing to answer is never rewarded). The bound is exact (not asymptotic): for a solver whose true
accuracy is 1/2 the chance of a credit above 0 is at most ALPHA per seed, whatever the sample size, and at most ALPHA ** seeds over all seeds. `null_rate` measures that.

What it does NOT know: that the real/random distributions are what the declaration says they are, or that a distinguisher at toy parameters says anything about real ones.
Advantage is also not "success of key recovery": a distinguisher that works is not a recovery attack unless the declaration turns it into one.
"""
import math
import random

ALPHA = 0.01


def _log_pmf(n, k, p):
    if p <= 0.0:
        return 0.0 if k == 0 else -math.inf
    if p >= 1.0:
        return 0.0 if k == n else -math.inf
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1) + k * math.log(p) + (n - k) * math.log1p(-p)


def binom_sf(n, k, p):
    """P(X >= k) for X ~ Binomial(n, p), summed in log space (exact up to float rounding; n up to a few hundred thousand is fine)."""
    if k <= 0:
        return 1.0
    if k > n:
        return 0.0
    terms = [_log_pmf(n, j, p) for j in range(k, n + 1)]
    m = max(terms)
    if m == -math.inf:
        return 0.0
    return min(1.0, math.exp(m) * sum(math.exp(t - m) for t in terms))


def lower_bound(n, k, alpha=ALPHA):
    """Exact one-sided Clopper-Pearson lower confidence bound on p after k successes in n trials: the p with P(X >= k | p) = alpha (0 if k = 0)."""
    if n < 1 or not 0 <= k <= n:
        raise ValueError("need 0 <= k <= n and n >= 1")
    if k == 0:
        return 0.0
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if binom_sf(n, k, mid) > alpha:
            hi = mid
        else:
            lo = mid
    return lo


def seed_credit(correct, total, alpha=ALPHA):
    """-> dict for one seed. `correct` counts right guesses among `total` committed instances (unanswered ones included in total, never in correct)."""
    if any(isinstance(v, bool) or not isinstance(v, int) for v in (correct, total)) or total < 1 or not 0 <= correct <= total:
        return {"accuracy": None, "lower": None, "advantage": None, "credit": None, "instances": total}
    lo = lower_bound(total, correct, alpha)
    return {"accuracy": correct / total, "lower": lo, "advantage": 2 * correct / total - 1, "credit": max(0.0, 2 * lo - 1), "instances": total}


def combine(credits):
    """Credit over seeds: the minimum, an unscorable seed counting as 0."""
    credits = list(credits)
    return min(0.0 if c is None else c for c in credits) if credits else 0.0


def balanced_coins(rng_bytes_fn, n):
    """n coins with exactly n//2 ones (n even), in an order fixed by rng_bytes_fn(i) -> sortable key. A declaration's derive() should use this idea: with exactly half real
    instances, always answering 0 scores exactly 1/2, and a coin read off the index parity or the order cannot be exploited."""
    if n % 2:
        raise ValueError("n must be even so that the coins balance")
    order = sorted(range(n), key=rng_bytes_fn)
    coin = [0] * n
    for rank, i in enumerate(order):
        coin[i] = rank % 2
    return coin


def null_rate(n, trials, alpha=ALPHA, seeds=1, seed=0):
    """Measured false-credit rate: a guesser with true accuracy 1/2 on n instances per seed, over `trials` repetitions (credit > 0 in ALL `seeds` seeds). Must be <= alpha ** seeds."""
    rng = random.Random(seed)
    hits = 0
    for _ in range(trials):
        if all(seed_credit(sum(rng.random() < 0.5 for _ in range(n)), n, alpha)["credit"] > 0 for _ in range(seeds)):
            hits += 1
    return hits / trials


def instances_needed(advantage, power=0.8, alpha=ALPHA, seeds=3, cap=20000):
    """The even n per seed at which a solver of TRUE advantage `advantage` is credited (> 0) in all seeds with probability >= power: the smallest such n up to 64, and above that the search
    steps by about 6%, so the answer can exceed the true minimum by up to that much (a slightly conservative plan, never an optimistic one). Exact (binomial), no simulation:
    the credit is > 0 iff the success count reaches the smallest k whose bound exceeds 1/2; P(all seeds) = P(X >= k) ** seeds."""
    p = (1 + advantage) / 2
    n = 8
    while n <= cap:
        k = next((j for j in range(n // 2 + 1, n + 1) if binom_sf(n, j, 0.5) < alpha), None)   # bound > 1/2 iff P(X >= j | p = 1/2) < alpha
        if k is not None and binom_sf(n, k, p) ** seeds >= power:
            return n
        n += 2 if n < 64 else max(2, (n // 16) // 2 * 2)
    return None


def pair_coin(first_bit, idx):
    """The pairing rule for a declaration's derive(): instances 2k and 2k+1 hold one coin of each value, `first_bit` (a bit derived from the seed and k) deciding the order. The number of
    1-coins is then EXACTLY n/2 for every even n, whatever n the round chooses, and the coin of one instance says nothing about the next one's without the seed."""
    return (first_bit & 1) ^ (idx & 1)
