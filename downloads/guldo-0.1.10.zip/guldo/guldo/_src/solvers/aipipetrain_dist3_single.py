"""aipipetrain in the cluster-counted API, TECHNIQUE (the one that cannot work): ONE device does everything, every activation of the whole batch kept: the 8 weight matrices, their gradients and 8 layers of activations of 8d rows are far over a device's capacity, so the run ends with an out-of-memory error."""
import math

import tensorops as tp


def ints(g):
    return list(map(int, (g * 1099511627776.0).tolist()))


def solve(seed, d, B, P):
    tp.use(0)
    x = tp.reshape(tp.stream(seed, 0, B * d), (B, d))
    T = tp.reshape(tp.stream(seed, B * d, B * d), (B, d))
    Ws = [tp.reshape(tp.stream(seed, 2 * B * d + l * d * d, d * d), (d, d)) * math.sqrt(3.0 / d) for l in range(8)]
    hs = [x]
    for l in range(7):
        hs.append(tp.relu(hs[-1] @ Ws[l]))
    g = (hs[-1] @ Ws[7] - T) * (1.0 / (B * d))
    grads = [None] * 8
    for l in range(7, -1, -1):
        grads[l] = tp.reshape(tp.transpose(hs[l], (1, 0)) @ g, (d * d,))
        if l:
            g = (g @ tp.transpose(Ws[l], (1, 0))) * (hs[l] / (hs[l] + 1e-300))
    return ints(tp.concat(grads, 0))
