"""Compare two submissions to each other on counted-OPERATIONS ladders (tflops.py), instance by instance.

  python3 tflops_compare.py compare BASELINE A B [--out F] [--rerun K|all --seed SEEDFILE]
  python3 tflops_compare.py check CLAIM BASELINE A B                    recompute a comparison file: it must be identical

BASELINE, A and B are ladders made by `tflops.py practice` (or a committed plan). A certificate compares one solver with a baseline; this compares two solvers with EACH
OTHER. Because a counted cost is exact and reproducible, the comparison can be paired: both solvers ran the very same instances, so for every instance the two costs are
set side by side and nothing about the machine, the clock or the sample enters. It reports how many instances each solver was cheaper on and the exact size of the gap in bits
(log2 of the cost ratio) at every size. A size where both solvers cost exactly the same on every instance (a fixed number of steps) is one exact fact and carries no p-value:
identical instances are not independent trials. Where costs vary between instances it also gives an exact sign test and a deterministic bootstrap interval, over those sizes only.
A side is called cheaper there only when BOTH agree: it wins significantly more often, and the interval of the mean gap excludes zero in its favour. Winning often by a hair while
losing rarely by a lot is a count of wins, not fewer operations (the sign test alone would call it a win), and is reported as "neither is shown".
--plan requires every ladder to be exactly a plan committed in advance, so the sizes and instances were not the prover's choice.

It REFUSES unless the three ladders are the same test: same family and declaration, same seed commitment, same budget, instance version, interpreter, counting program and
unit, the same instances, a baseline that is not either submission, and two different submissions. It re-checks every ladder's cost model first. With --rerun K it also
re-executes K records of each ladder, drawn at random (exact counts, no tolerance), as `tflops.py verify` does; the output then says it was only a sample. --rerun all
re-executes every record: the only full audit, and the only case in which the output says so. --solvers DIR names the folder holding the three solver files (each must match
the hash in its ladder; a name that is not a plain file name is refused).

What it shows: on these instances, which of two solvers asked for fewer operations, and by how many bits. What it does not show: a time, memory traffic, kernel or GPU speed;
a gap at sizes that were not measured; or anything about solvers that were not submitted. Instances where a solver did not solve (wrong, crashed, over budget) are charged
the budget by the ladder, which understates its true cost, so they are excluded from the gap and counted separately. A solver whose cost depends only on the size (a fixed
number of steps) gives the same cost on every instance of a size, so its evidence is per SIZE, not per instance: the per-size table says so.
"""
import argparse
import hashlib
import json
import math
import os
import statistics
import sys

import instances
import tflops
import tflops_mem

FORMAT = "svp-tflops-comparison-v1"
SAME_KEYS = ("family", "commit", "budget", "instance_version", "decl_sha256", "counter_sha256", "unit_ops", "python", "cost_model")
BOOTSTRAP = 2000
FIXED_MIN = 3         # a size counts as "fixed cost" only if at least this many paired instances cost exactly the same: two equal costs can be a coincidence of an adaptive solver


class CompareError(Exception):
    pass


def _load(path):
    try:
        meta, recs = tflops.read_ladder(path)
    except (OSError, ValueError) as e:
        raise CompareError(f"{os.path.basename(path)}: unreadable ({type(e).__name__})")
    if meta is None:
        raise CompareError(f"{os.path.basename(path)}: no header line")
    verifier = _verifier(meta)
    if verifier is None:
        raise CompareError(f"{os.path.basename(path)}: not a counted-operations ladder (cost model {meta.get('cost_model')!r})")
    ok, lines = verifier(path)
    if not ok:
        raise CompareError(f"{os.path.basename(path)} does not pass its own cost-model check: " + "; ".join(l for l in lines if l.startswith("FAIL"))[:300])
    ids = [r.get("id") for r in recs]
    if not all(isinstance(i, str) for i in ids):
        raise CompareError(f"{os.path.basename(path)}: an instance id is not text")
    if len(ids) != len(set(ids)):
        raise CompareError(f"{os.path.basename(path)}: an instance appears twice")
    return meta, {r["id"]: r for r in recs}


def _sign_p(a, b):
    """Exact two-sided sign test p-value for a wins against b wins (ties dropped)."""
    m = a + b
    if m == 0:
        return 1.0
    k = min(a, b)
    return min(1.0, 2.0 * sum(math.comb(m, i) for i in range(k + 1)) / 2.0 ** m)


def _resamples(seed, n, count):
    """`count` bootstrap resamples (each a list of n indices below n), drawn from SHA-256 in counter mode. Python's `random` is not promised to give the same stream on every
    version, and a saved comparison must recompute identically on whatever interpreter checks it, so nothing here depends on it."""
    stream, counter = b"", 0

    def draw():
        nonlocal stream, counter
        if len(stream) < 4:
            stream = hashlib.sha256(b"svp-bootstrap-v1:%d:%d" % (seed, counter)).digest()
            counter += 1
        v, stream = int.from_bytes(stream[:4], "big"), stream[4:]
        return v % n
    for _ in range(count):
        yield [draw() for _ in range(n)]


def _median_lower_bound(values):
    """A distribution-free one-sided 95% lower confidence bound for the MEDIAN of the population the values were drawn from: the k-th smallest value, k the largest integer with
    P(Binomial(n, 1/2) <= k-1) <= 0.05 (the number of observations below the true median is Binomial(n, 1/2), so the k-th smallest exceeds the median with at most that
    probability). None when n is too small for any value to be claimed (n < 5). No model of the costs is assumed: only that the instances are independent draws."""
    xs, n, k = sorted(values), len(values), 0
    for j in range(1, n + 1):
        if sum(math.comb(n, i) for i in range(j)) / 2.0 ** n <= 0.05:
            k = j
        else:
            break
    return xs[k - 1] if k else None


def _vs_baseline(bits):
    """Summary of one solver's gap to the baseline over EVERY instance whose baseline cost was measured, a failure being charged the whole budget (so it can only pull the bound
    down). `bits` are log2(baseline cost / this solver's cost), one per instance."""
    lo = _median_lower_bound(bits)
    return {"instances": len(bits), "median_bits": round(statistics.median(bits), 6) if bits else None,
            "lower95_median_bits": round(lo, 6) if lo is not None else None}


def _verifier(meta):
    """The cost-model check for a ladder's header: operations only (tflops.py) or operations, bytes and peak memory (tflops_mem.py)."""
    return {"tflops": tflops.verify_ladder, "tflops-mem": tflops_mem.verify_ladder}.get(meta.get("cost_model"))


METRICS = {"ops": "cpu", "bytes": "bytes", "peak": "peak_bytes"}
PHRASE = {"ops": "fewer operations", "bytes": "fewer bytes moved", "peak": "a smaller peak memory"}


def _cost(rec, metric="ops"):
    """The chosen cost of a SOLVED record (None if it was not solved): operations (the ladder's own cpu field), bytes moved, or peak live bytes. Never zero: a gap is a log ratio."""
    if rec["status"] != "solved":
        return None
    v = rec.get(METRICS[metric])
    if not isinstance(v, (int, float)) or isinstance(v, bool) or v <= 0:
        raise CompareError(f"record {rec.get('id')}: no usable {metric} cost")
    return v


def _digest(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def compare(base_path, a_path, b_path, rerun=0, master=None, plan_path=None, plan_hash=None, solver_dir=None, metric="ops"):
    """plan_path: a plan committed in advance (tflops.py plan); every ladder must be exactly that plan. plan_hash: the value published for it, which the plan file must match.
    solver_dir: where the three solver files are, for --rerun (default: this checkout's solvers/). A re-run refuses a file whose hash is not the one in the ladder."""
    if rerun != "all" and (isinstance(rerun, bool) or not isinstance(rerun, int) or rerun < 0):
        raise CompareError("--rerun takes a non-negative number of records, or `all`")
    if metric not in METRICS:
        raise CompareError("--metric is ops, bytes or peak")
    plan, plan_digest = None, None
    if plan_path:
        try:
            plan = tflops.load_plan(plan_path)
        except (OSError, ValueError) as e:
            raise CompareError(f"the plan cannot be read ({type(e).__name__})")
        plan_digest = tflops.plan_hash(plan)
    elif plan_hash:
        raise CompareError("--plan-hash needs --plan")
    mb, rb = _load(base_path)
    ma, ra = _load(a_path)
    mc, rc = _load(b_path)
    for key in SAME_KEYS:
        if not (mb.get(key) == ma.get(key) == mc.get(key)):
            raise CompareError(f"the ladders differ in {key}: they are not the same test")
    if metric != "ops" and mb.get("cost_model") != "tflops-mem":
        raise CompareError(f"--metric {metric} needs ladders made by `guldo tflops-mem` (tflops_mem.py; they record bytes and peak memory); these only count operations")
    if plan is not None:
        for path, meta, recs in ((base_path, mb, rb), (a_path, ma, ra), (b_path, mc, rc)):
            problems = tflops.check_plan(plan, meta, list(recs.values()), expect_hash=plan_hash)
            if problems:
                raise CompareError(f"{os.path.basename(path)} is not the committed plan: " + "; ".join(problems)[:300])
    shas = [mb["solver_sha256"], ma["solver_sha256"], mc["solver_sha256"]]
    if len(set(shas)) != 3:
        raise CompareError("two of the three ladders are for the same solver file: a comparison needs a baseline and two different submissions")
    if not (set(rb) == set(ra) == set(rc)):
        raise CompareError("the ladders do not hold the same instances")
    for iid in ra:
        try:
            size = int(iid.split(":")[0])
            int(iid.split(":")[1])
        except (ValueError, IndexError):
            raise CompareError(f"instance id {iid!r} is not of the form SIZE:INDEX")
        if not (ra[iid].get("dim") == rb[iid].get("dim") == rc[iid].get("dim") == size):
            raise CompareError(f"instance {iid}: the three ladders disagree about its size, or a record's size is not the one in its id")
    if rerun:
        for path, meta in ((base_path, mb), (a_path, ma), (b_path, mc)):      # every name is checked before anything is executed
            if not isinstance(meta["solver"], str) or meta["solver"] != os.path.basename(meta["solver"]) or meta["solver"] in ("", ".", ".."):
                raise CompareError(f"{os.path.basename(path)} names its solver {meta['solver']!r}, which is not a plain file name: it will not be looked up on disk")
        for path, meta in ((base_path, mb), (a_path, ma), (b_path, mc)):
            solver = os.path.join(solver_dir, meta["solver"]) if solver_dir else None      # others' solvers are re-run from the folder they were handed over in
            ok, lines = _verifier(meta)(path, rerun=rerun, master=master, solver_path=solver)
            if not ok:
                raise CompareError(f"re-execution of {os.path.basename(path)} did not reproduce it: " + "; ".join(l for l in lines if "FAIL" in l or "SKIP" in l)[:300])
    pairs, only_a, only_b, neither, per_dim, bits = 0, 0, 0, 0, {}, []
    a_cheaper = b_cheaper = ties = 0
    vs_base_a, vs_base_b = [], []
    exact_a, exact_b = [], []
    ops_pairs, baseline_unsolved = [], 0
    for iid in sorted(ra, key=lambda s: tuple(int(x) for x in s.split(":"))):
        dim = ra[iid]["dim"]
        ca, cb, c0 = _cost(ra[iid], metric), _cost(rc[iid], metric), _cost(rb[iid], metric)
        baseline_unsolved += c0 is None
        if metric != "ops":     # bytes and peak are counted only for tensor operations: the operations gap is always shown beside them (see the verdict)
            oa, ob = _cost(ra[iid], "ops"), _cost(rc[iid], "ops")
            if oa is not None and ob is not None:
                ops_pairs.append(math.log2(ob / oa))
        if c0 is not None and ca is not None:
            vs_base_a.append(math.log2(c0 / ca))
        if c0 is not None and cb is not None:
            vs_base_b.append(math.log2(c0 / cb))
        if c0 is not None and metric == "ops":      # the ladder's own cpu field: the measured cost if solved, the whole budget if not (bytes and peak have no budget to charge a failure)
            exact_a.append(math.log2(c0 / ra[iid]["cpu"]))
            exact_b.append(math.log2(c0 / rc[iid]["cpu"]))
        row = per_dim.setdefault(dim, {"instances": 0, "both_solved": 0, "a_solved": 0, "b_solved": 0, "a_cheaper": 0, "b_cheaper": 0, "ties": 0, "bits": [], "costs": []})
        row["instances"] += 1
        row["a_solved"] += ca is not None
        row["b_solved"] += cb is not None
        if ca is None and cb is None:
            neither += 1
        elif ca is None:
            only_b += 1
        elif cb is None:
            only_a += 1
        else:
            pairs += 1
            row["both_solved"] += 1
            b = math.log2(cb / ca)
            bits.append(b)
            row["bits"].append(b)
            row["costs"].append((ca, cb))
            if ca < cb:
                a_cheaper += 1
                row["a_cheaper"] += 1
            elif cb < ca:
                b_cheaper += 1
                row["b_cheaper"] += 1
            else:
                ties += 1
                row["ties"] += 1
    # A size where BOTH solvers cost exactly the same on every paired instance (a fixed number of steps) holds one fact, not many samples: it is reported exactly and carries
    # no p-value, because 8 identical instances are not 8 independent trials. The sign test and the bootstrap use only the sizes where costs actually vary.
    det, var_bits, va, vb, vt = {}, [], 0, 0, 0
    for dim, row in per_dim.items():
        cs = row["costs"]
        if len(cs) >= FIXED_MIN and len({c[0] for c in cs}) == 1 and len({c[1] for c in cs}) == 1:
            det[dim] = "A" if cs[0][0] < cs[0][1] else "B" if cs[0][1] < cs[0][0] else "equal"
        else:
            var_bits += row["bits"]
            va, vb, vt = va + row["a_cheaper"], vb + row["b_cheaper"], vt + row["ties"]
    seed = int(hashlib.sha256("".join(_digest(p) for p in (base_path, a_path, b_path)).encode()).hexdigest()[:16], 16)
    ci = None
    if len(var_bits) >= 2:
        reps = min(BOOTSTRAP, max(200, 4_000_000 // len(var_bits)))        # a huge ladder must not make the interval cost minutes: fewer resamples, still deterministic
        means = sorted(statistics.fmean(var_bits[i] for i in idx) for idx in _resamples(seed, len(var_bits), reps))
        ci = [round(means[int(0.025 * reps)], 6), round(means[int(0.975 * reps) - 1], 6)]
    has_var = va + vb + vt > 0
    var_mean = round(statistics.fmean(var_bits), 6) if var_bits else None
    p = _sign_p(va, vb) if has_var else None
    # At sizes where costs vary, a side is only called cheaper when TWO things agree: it wins significantly more often (sign test) AND the interval of the mean gap excludes zero in
    # its favour. Winning often by a hair while losing rarely by a lot is a count of wins, not fewer operations, and the sign test alone would call it a win.
    ahead = lambda side, count, other: ((bool(det) or has_var) and all(v == side for v in det.values())
                                        and (not has_var or (p <= 0.05 and count > other and ci is not None and (ci[0] > 0 if side == "A" else ci[1] < 0))))
    if not bits:
        verdict = ("A solved instances that B did not (B solved none of the ones A did); there is no operation count to compare" if only_a > only_b else
                   "B solved instances that A did not (A solved none of the ones B did); there is no operation count to compare" if only_b > only_a else
                   "no comparison: no instance was solved by both")
    elif ahead("A", va, vb):
        verdict = f"A used {PHRASE[metric]} than B" + (f" at every measured size ({len(det)})" if det and not has_var else "")
    elif ahead("B", vb, va):
        verdict = f"B used {PHRASE[metric]} than A" + (f" at every measured size ({len(det)})" if det and not has_var else "")
    else:
        verdict = f"neither is shown to use {PHRASE[metric]}"
    if bits and only_a != only_b:
        verdict += f"; {'A' if only_a > only_b else 'B'} also solved {abs(only_a - only_b)} more instance(s) than the other"
    ops_gap = round(statistics.median(ops_pairs), 6) if ops_pairs else None
    if metric != "ops" and ops_gap is not None and ((verdict.startswith("A used") and ops_gap <= -1) or (verdict.startswith("B used") and ops_gap >= 1)):
        verdict += (f"; but that side used {2 ** abs(ops_gap):.3g}x more operations, and bytes and peak memory are counted only for tensor operations, "
                    "so work done in plain Python is not in this count: read the two together")
    sizes = {}
    for dim, row in sorted(per_dim.items()):
        sizes[str(dim)] = {k: v for k, v in row.items() if k not in ("bits", "costs")}
        sizes[str(dim)]["median_bits_a_below_b"] = round(statistics.median(row["bits"]), 6) if row["bits"] else None
        sizes[str(dim)]["costs_are_fixed"] = dim in det
    dims_a_ahead = [d for d, r in sizes.items() if r["a_cheaper"] > r["b_cheaper"]]
    dims_b_ahead = [d for d, r in sizes.items() if r["b_cheaper"] > r["a_cheaper"]]
    evidence = "per size (costs do not vary within a size)" if det and not has_var else "per instance" if has_var and not det else "per size where costs are fixed, per instance elsewhere" if det else "none"
    practice = mb["commit"] == instances.commit(instances.PRACTICE_SEED)
    return {"format": FORMAT, "family": mb["family"], "commit": mb["commit"], "unit_ops": mb["unit_ops"], "python": mb["python"],
            "from": [_digest(base_path), _digest(a_path), _digest(b_path)],
            "baseline": mb["solver"], "a": ma["solver"], "b": mc["solver"],
            "instances": len(ra), "paired": pairs, "a_cheaper": a_cheaper, "b_cheaper": b_cheaper, "ties": ties,
            "only_a_solved": only_a, "only_b_solved": only_b, "neither_solved": neither,
            "median_bits_a_below_b": round(statistics.median(bits), 6) if bits else None,
            "mean_bits_a_below_b": round(statistics.fmean(bits), 6) if bits else None,
            "a_below_baseline_median_bits": round(statistics.median(vs_base_a), 6) if vs_base_a else None,
            "b_below_baseline_median_bits": round(statistics.median(vs_base_b), 6) if vs_base_b else None,
            "metric": metric, "ops_gap_median_bits": ops_gap, "baseline_unsolved": baseline_unsolved, "vs_baseline_exact": {"a": _vs_baseline(exact_a), "b": _vs_baseline(exact_b)} if metric == "ops" else None,
            "mean_bits_varying_sizes": var_mean, "bootstrap95_mean_bits": ci, "bootstrap_seed": seed, "sign_test_p": p, "sign_test_pairs": va + vb, "verdict": verdict,
            "evidence": evidence, "fixed_cost_sizes": {str(d): v for d, v in sorted(det.items())},
            "sizes": sizes, "sizes_where_a_cheaper": dims_a_ahead, "sizes_where_b_cheaper": dims_b_ahead,
            "practice_seed": practice, "plan_hash": plan_digest, "reexecuted": bool(rerun), "rerun": rerun,
            "limits": [tflops_mem.CLAIM_LIMITS if mb.get("cost_model") == "tflops-mem" else tflops.CLAIM_LIMITS,
                       "a positive gap means A asked for fewer operations: 1 bit is half the operations, 3 bits an eighth",
                       "instances a solver did not solve are left out of the gap and counted separately; if one solver fails where the other solves, that failure is not in the bits",
                       "a size where both solvers cost exactly the same on every instance (a fixed number of steps) is one exact fact about that size, not many samples: it carries no p-value, and nothing is said about sizes that were not measured",
                       "the sign test and the bootstrap interval use only the sizes where costs vary between instances",
                       *(["bytes and peak memory are counted only for tensor operations: arithmetic done in the solver's own Python moves no counted bytes (it pays in operations instead), so a bytes or peak verdict is only meaningful beside the operations gap"] if metric != "ops" else
                         ["the exact credit bounds the median of the instances pooled over the measured sizes, not the gap at any one size"]),
                       *([f"{baseline_unsolved} instance(s) that the baseline itself did not solve are left out of every gap (its cost there is unmeasured)"] if baseline_unsolved else []),
                       *(["the ladders used the public practice seed, so the hidden parts of every instance (the teacher and the test set) can be computed by anyone: this shows the method, not a certified result"] if practice else []),
                       *([] if plan_digest else ["the ladders were not required to match a plan committed in advance (--plan), so the sizes and instances were the prover's choice"]),
                       "the ladders were checked for internal consistency" + (" and EVERY record of all three was re-executed here with identical counts" if rerun == "all" else
                                                                             f" and a random sample of {rerun} record(s) per ladder was re-executed here with identical counts; the other records were checked for consistency only (use --rerun all for a full audit)" if rerun else
                                                                             "; they were not re-executed here (use --rerun)")]}


def render(c):
    out = [f"COUNTED COMPARISON on family {c['family']}, cost = {({'ops': 'operations', 'bytes': 'bytes moved', 'peak': 'peak memory'})[c['metric']]}: A = {c['a']}, B = {c['b']}, baseline {c['baseline']}  "
           f"({c['instances']} identical instances, {c['paired']} solved by both)"]
    out.append(f"  A cheaper on {c['a_cheaper']}, B cheaper on {c['b_cheaper']}, equal on {c['ties']}; solved only by A: {c['only_a_solved']}, only by B: {c['only_b_solved']}, by neither: {c['neither_solved']}")
    if c["median_bits_a_below_b"] is not None:
        out.append(f"  gap (A below B): median {c['median_bits_a_below_b']:+.3f} bits (about {2 ** c['median_bits_a_below_b']:.3g}x); mean {c['mean_bits_a_below_b']:+.3f}"
                   + ("; no sign test: every measured size has fixed costs, so each size is one exact fact" if c["sign_test_p"] is None else
                      f"; at the sizes where costs vary ({c['sign_test_pairs']} instances with a cheaper side): exact sign test p = {c['sign_test_p']:.3g}"
                      + (f"; mean gap there {c['mean_bits_varying_sizes']:+.3f} bits, 95% bootstrap interval [{c['bootstrap95_mean_bits'][0]:+.3f}, {c['bootstrap95_mean_bits'][1]:+.3f}]"
                         if c["bootstrap95_mean_bits"] else " (too few instances for an interval)")))
    out.append(f"  evidence: {c['evidence']}" + (f"; plan {c['plan_hash'][:16]}... committed in advance" if c["plan_hash"] else "; not tied to a committed plan")
               + ("; PRACTICE SEED (not a certified result)" if c["practice_seed"] else ""))
    if c["metric"] != "ops" and c["ops_gap_median_bits"] is not None:
        out.append(f"  for reference, the operations gap (A below B, median over the same instances): {c['ops_gap_median_bits']:+.3f} bits")
    fmt = lambda v: "none solved" if v is None else f"{v:+.3f} bits"
    out.append(f"  against the baseline (median over the instances each solved): A {fmt(c['a_below_baseline_median_bits'])}, B {fmt(c['b_below_baseline_median_bits'])}")
    vb = c["vs_baseline_exact"]
    fmt_lo = lambda s: "no bound (too few instances)" if s["lower95_median_bits"] is None else f">= {s['lower95_median_bits']:+.3f} bits (median {s['median_bits']:+.3f}, n = {s['instances']})"
    if vb is not None:
        out.append(f"  exact credit against the baseline, a distribution-free 95% lower bound on the median gap with failures charged the whole budget: A {fmt_lo(vb['a'])}; B {fmt_lo(vb['b'])}")
    else:
        out.append("  no credit bound for this cost: a failed run has no bytes or peak to charge, so only the instances both solvers solved are compared")
    for dim, r in c["sizes"].items():
        out.append(f"  size {dim}: {r['instances']} instances, solved A {r['a_solved']} / B {r['b_solved']}, A cheaper {r['a_cheaper']}, B cheaper {r['b_cheaper']}, "
                   f"median gap {'none (no instance solved by both)' if r['median_bits_a_below_b'] is None else format(r['median_bits_a_below_b'], '+.3f') + ' bits'}"
                   + ("  [fixed costs: one exact fact]" if r["costs_are_fixed"] else ""))
    out.append("  " + c["verdict"][0].upper() + c["verdict"][1:])
    out.append("  does not show: " + "; ".join(c["limits"]))
    return out


def check(claim, base_path, a_path, b_path, plan_path=None):
    if not isinstance(claim, dict) or claim.get("format") != FORMAT:
        return False, "not a comparison file"
    if claim.get("plan_hash") and not plan_path:
        return False, "this comparison was made against a committed plan: pass it with --plan so the ladders can be checked against it again"
    try:
        again = compare(base_path, a_path, b_path, plan_path=plan_path, metric=claim.get("metric", "ops"))
    except (CompareError, KeyError, TypeError, ValueError) as e:
        return False, str(e)
    keep = lambda d: {k: v for k, v in d.items() if k not in ("reexecuted", "rerun", "limits")}
    same = json.dumps(keep(again), sort_keys=True) == json.dumps(keep(claim), sort_keys=True)
    return same, ("recomputed identically" if same else "the recomputed comparison differs from the file")


def _prog():
    """The command that was actually typed: `guldo tflops-compare` when run through the installed `guldo` command, else `python3 tflops_compare.py`."""
    return sys.argv[0] if sys.argv and sys.argv[0].startswith("guldo ") else "python3 tflops_compare.py"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("compare")
    for name in ("baseline", "a", "b"):
        p.add_argument(name)
    p.add_argument("--out")
    p.add_argument("--metric", choices=sorted(METRICS), default="ops", help="the cost to compare: operations (default), bytes moved or peak memory (the last two need tflops_mem.py ladders)")
    p.add_argument("--rerun", type=lambda s: s if s == "all" else int(s), default=0, metavar="K|all")
    p.add_argument("--seed", help="the revealed seed file (needed for --rerun)")
    p.add_argument("--solvers", help="the folder holding the three solver files, for --rerun (default: this checkout's solvers/); each must match the hash in its ladder")
    p.add_argument("--plan", help="require every ladder to be exactly this plan, committed in advance (tflops.py plan)")
    p.add_argument("--plan-hash", help="the hash published for the plan: the plan file must hash to it")
    p = sub.add_parser("check")
    for name in ("claim", "baseline", "a", "b"):
        p.add_argument(name)
    p.add_argument("--plan", help="the plan the comparison was made against, if it was")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "check":
            with open(a.claim, encoding="utf-8") as f:
                ok, why = check(json.load(f), a.baseline, a.a, a.b, plan_path=a.plan)
            print(("CONFIRMED: " if ok else "NOT CONFIRMED: ") + why)
            return 0 if ok else 1
        master = None
        if a.seed:
            with open(a.seed, "rb") as f:
                master = f.read().strip()
        elif a.rerun:
            import instances
            master = instances.PRACTICE_SEED
        claim = compare(a.baseline, a.a, a.b, rerun=a.rerun, master=master, plan_path=a.plan, plan_hash=a.plan_hash, solver_dir=a.solvers, metric=a.metric)
    except CompareError as e:
        print(f"REFUSED: {e}", file=sys.stderr)
        return 1
    except (OSError, ValueError, KeyError, TypeError) as e:
        print(f"REFUSED: could not read the input ({type(e).__name__}: {str(e)[:120]})", file=sys.stderr)
        return 1
    print("\n".join(render(claim)))
    if a.out:
        if os.path.exists(a.out):
            print(f"REFUSED: {a.out} exists; a comparison file is never overwritten", file=sys.stderr)
            return 1
        fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(claim, f, indent=1, sort_keys=True)
        print(f"wrote {a.out} (anyone can confirm it: {_prog()} check {a.out} BASELINE A B)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
