"""Build the Guldo website (static, multi-page) from the saved ladders and pre-registration files.

  python3 build_site.py --out site [--reveal 755a57fd=/path/seedD.seed ...]

Every number comes from the saved ladders through extrapolate.py (the judge's own estimator); nothing is typed in by hand
except the prose. This script READS the results: it does not rescore (run `python3 judge.py rescore` first if the board
may predate the current estimator) and it never executes a solver. A revealed seed is checked against its published
commitment before it is shipped, and one that does not hash to the commitment is refused.
"""
import argparse
import hashlib
import html
import json
import os
import re
import shutil
import tempfile
import time

import families
import judge
import report_html as R
import site_assets

HERE = os.path.dirname(os.path.abspath(__file__))
esc = R.esc
MARKER = ".speedup-ledger-site"

PAGES = [("index.html", "Overview"), ("install.html", "Install"), ("domains.html", "Domains"), ("guide.html", "Guide"), ("method.html", "Method"), ("results.html", "Results"),
         ("preregistrations.html", "Pre-registrations"), ("compete.html", "Compete"), ("claims.html", "Other claims"), ("limits.html", "Limits")]

# what each registration became; the registration FILES are the record, this is only a label
PREREG_STATUS = {
    "2315b668": ("void", "Void: the run was killed and the harness changed before it finished. Superseded by seed C."),
    "14a1b0db": ("void", "Void: the run was killed and the harness changed before it finished. Superseded by seed D."),
    "755a57fd": ("done", "Completed. Criterion (a) met; see Results."),
    "88ecb627": ("done", "Positive control on a second domain (integer factoring). The written criteria are applied to the saved ladders on the Results page."),
}

EXTRA_CSS = """
.big{font-size:20px;margin:0 0 10px;max-width:none} .run{display:grid;gap:14px} .tv{margin-top:4px}
.crumbs{display:flex;flex-wrap:wrap;gap:8px 18px}
.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(300px,100%),1fr));gap:22px;align-items:start}
.fine{font-size:14px;color:var(--ink2)}
.gloss{display:grid;grid-template-columns:minmax(120px,max-content) 1fr;gap:8px 18px;margin:0;font-size:15px} .gloss dt{font-weight:600} .gloss dd{margin:0;color:var(--ink2)}
@media (max-width:560px){.gloss{grid-template-columns:1fr;gap:2px} .gloss dd{margin-bottom:10px}}
details.more{margin-top:12px} details.more summary{cursor:pointer;font-weight:600;color:var(--accent-ink)} details.more[open] summary{margin-bottom:8px}
.guide{min-width:0} .guide h2{margin-top:34px} .guide h3,.guide h4{margin-top:22px} .guide p,.guide li{max-width:72ch}
pre.codeblock{background:var(--chip);border:1px solid var(--line);border-radius:10px;padding:12px 14px;overflow-x:auto;font-family:var(--mono);font-size:13px;line-height:1.5}
.guide code{font-family:var(--mono);font-size:.92em;background:var(--chip);border-radius:5px;padding:1px 5px} .guide pre code{background:none;padding:0}
.toc{align-self:start;position:sticky;top:16px} .toc ul{margin:8px 0 0;padding-left:18px}
.bar{height:10px;min-width:90px;background:var(--line);border-radius:5px;overflow:hidden} .bar span{display:block;height:100%;background:var(--accent)}
"""

LOGO = ('<svg viewBox="0 0 28 28" width="26" height="26" aria-hidden="true"><rect x="1.5" y="1.5" width="25" height="25" rx="6" fill="none" '
        'stroke="var(--ink)" stroke-width="2"/><path d="M6 20h4v-4h4v-4h4V8h4" fill="none" stroke="var(--accent)" stroke-width="2.4" '
        'stroke-linecap="round" stroke-linejoin="round"/></svg>')
FAVICON = ("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 28 28'%3E%3Crect width='28' height='28' rx='6' fill='%232A78D6'/%3E"
           "%3Cpath d='M6 20h4v-4h4v-4h4V8h4' fill='none' stroke='white' stroke-width='2.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")
FONTS = ('<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
         '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600&family=Instrument+Sans:wght@400;600'
         '&family=JetBrains+Mono:wght@400;600&display=swap">')


# ---------------------------------------------------------------- shared layout
def layout(fname, title, description, body, runs_manifest=None):
    nav = "".join(f'<a href="{f}"' + (' aria-current="page"' if f == fname else "") + f'>{esc(t)}</a>' for f, t in PAGES)
    manifest = ""
    if runs_manifest is not None:
        manifest = '<script type="application/json" id="runs-manifest">' + json.dumps(runs_manifest).replace("</", "<\\/") + "</script>"
    stamp = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())
    return f"""<!doctype html>
<html lang="en" data-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)}</title><meta name="description" content="{esc(description)}">
<meta name="color-scheme" content="dark light"><link rel="icon" href="{FAVICON}">
<script>try{{if(localStorage.getItem('theme')==='light')document.documentElement.setAttribute('data-theme','light')}}catch(e){{}}</script>
{FONTS}<link rel="stylesheet" href="assets/site.css"></head>
<body><a class="skip" href="#main">Skip to content</a>
<div class="wrap"><header class="top"><a class="brand" href="index.html">{LOGO}Guldo</a>
<nav class="main" aria-label="Main">{nav}<button class="theme" id="theme-toggle" type="button" aria-pressed="true">Light mode</button></nav></header>
<main id="main">{body}</main>
<footer class="foot"><p>Generated {esc(stamp)} from the saved measurement files in <span class="mono">results/</span>; every figure on these pages is recomputed from that data by the judge's own scoring code.</p>
<p>No result on this site is official: they are all practice runs. <a href="limits.html">Why, and what would make one official</a>.</p></footer></div>
<div id="tip" role="tooltip"></div>{manifest}<script src="assets/site.js"></script></body></html>"""


def banner(text):
    return f'<div class="banner" role="note">{R.ICON["PROVISIONAL"]}<p>{text}</p></div>'


def cmd(text):
    return f'<div class="cmd"><code>{esc(text)}</code><button class="copy" type="button" data-copy="{esc(text)}">Copy</button></div>'


# ---------------------------------------------------------------- data
SELFTEST_CONTROLS = {"control_zero", "control_none"}  # the compiler's own self-test submissions (compile_domain.selftest): controls, not results


def collect(results_dir):
    specs = [s for s in R.find_pairs(results_dir) if s["name"] not in SELFTEST_CONTROLS]
    data = []
    for s in specs:
        try:
            data.append((s, R.load_pair(s["baseline"], s["submission"])))
        except (OSError, KeyError, ValueError, TypeError, AttributeError, IndexError) as e:  # an incomplete, empty or corrupt pair is listed as such, never charted, and never stops the build
            data.append((s, {"error": str(e)}))
    return data


def credit_of(d):
    return None if d.get("meas") is None else max(0.0, d["meas"][1])


def read_prereg(results_dir):
    out = []
    for fn in sorted(os.listdir(results_dir)):
        if not (fn.startswith("PREREGISTERED_") and fn.endswith(".txt")):
            continue
        with open(os.path.join(results_dir, fn), encoding="utf-8") as f:
            text = f.read()
        m = re.search(r"commitment \(sha256\): ([0-9a-f]{64})", text)
        d = re.search(r"^date: (\S+)", text, re.M)
        if not m:
            continue
        out.append({"file": fn, "text": text, "commit": m.group(1), "tag": m.group(1)[:8], "date": d.group(1) if d else "",
                    "title": text.splitlines()[0][:150]})
    return out


def load_reveals(pairs, prereg):
    commits = {p["commit"] for p in prereg}
    seeds = {}
    for item in pairs or []:
        tag, _, path = item.partition("=")
        raw = open(os.path.expanduser(path), "rb").read().strip()
        h = hashlib.sha256(raw).hexdigest()
        if h not in commits or not h.startswith(tag):
            raise SystemExit(f"REFUSED: {path} hashes to {h[:16]}..., which is not the registered commitment {tag}")
        seeds[h] = raw.decode()
    return seeds


# ---------------------------------------------------------------- pages
def compiler_sample():
    """A card of the compiler's REAL verdict for the first compiled domain installed (the text `compile_domain.py show NAME` prints), or
    nothing when none is installed. Never typed by hand, so it cannot show a result the compiler did not produce."""
    import compile_domain as CD
    for name, info in sorted(families.DECLARED.items()):
        try:
            _, lines = CD.verdict(info["compiled"])
        except (KeyError, TypeError, ValueError):
            continue
        # the summary only: the notes and the next-step commands are long, and the full card has them
        head = [ln for ln in lines if not ln.startswith(("  note", "  next:", "    "))]
        n_notes = sum(ln.startswith("  note") for ln in lines)
        if n_notes:
            head.append(f"  notes         : {n_notes} (listed on the full card)")
        return (f'<div><p class="kicker">Real compiler output, for the {esc(name)} example</p><div class="card">'
                f'<pre class="codeblock"><code>{esc(chr(10).join(head))}</code></pre>'
                f'<p class="fine">A shortened version of what <span class="mono">python3 compile_domain.py show {esc(name)}</span> prints. '
                f'<a href="domains.html#{esc(name)}">See the full card</a>.</p></div></div>')
    return ""


def page_index(data, board, prereg, notes=None):
    sample = compiler_sample()
    hero_side = ('<div><p class="kicker">An illustration, not a result</p><div class="card"><h3>Two solvers, the same questions</h3>'
                 '<p class="fine">Say two people each write a program that factors big numbers. Both are given the same 100 numbers, made from a secret number that nobody could see in advance. '
                 'The first program takes 40 seconds on the hard ones. The second takes 5. That is 8 times faster, or 3 bits. '
                 'This site is a way for a stranger to confirm a claim like that without taking anyone\'s word for it.</p></div>'
                 + (f'<details class="more"><summary>Show what the compiler really prints</summary>{sample}'
                    '<p class="fine">In that printout, the <em>size ladder</em> is the list of question sizes and the <em>CPU cap</em> is the time limit per question.</p></details>' if sample else "")
                 + '</div>')
    body = f"""
<section class="hero"><div><p class="kicker">Verified speedups, without trusting the claimant</p>
<h1>Declare a problem. Get a challenge <em style="font-style:normal;color:var(--accent-ink)">anyone can verify</em>.</h1>
<p class="lede">Someone says their algorithm is much faster than the standard one. How would you check? Describe the problem once. The compiler builds a fair test, runs it, and produces a report that anyone can re-check.</p>
<p class="fine">How we count speed: <strong>3 bits faster means 8 times faster</strong>, and 10 bits means about 1,000 times. Each extra bit doubles it.</p>
<div class="btnrow"><a class="btn primary" href="domains.html">See the domains</a><a class="btn" href="domains.html#add">Compile your own</a><a class="btn" href="method.html">How it works</a><a class="btn" href="install.html">Install the tool</a><a class="btn" href="preregistrations.html">Check a commitment yourself</a></div></div>
{hero_side}</section>
<section class="block"><p class="kicker">Start here</p><div class="grid3">
<div class="card"><h3>I have a problem</h3><p class="fine">You can say exactly when an answer is right, and you have a plain solver to compare against. The compiler turns that into a fair test.</p><p class="fine"><a href="domains.html#add">Compile your own</a></p></div>
<div class="card"><h3>I have a faster solver</h3><p class="fine">Write one Python file with a function called <span class="mono">solve</span>, check it locally, and see how it would be measured.</p><p class="fine"><a href="compete.html">Go to Compete</a> &middot; <a href="install.html">Install the tool</a></p></div>
<div class="card"><h3>I want to check a claim</h3><p class="fine">You do not have to trust anyone. Recompute a result from its file, check a commitment yourself, or read what a result does not prove.</p><p class="fine"><a href="guide.html">Read the guide</a> &middot; <a href="preregistrations.html">Check a commitment</a> &middot; <a href="limits.html">What it does not show</a></p></div></div></section>
{banner("<strong>Everything here is a practice result.</strong> A certified result has to be measured inside a strict test environment: a locked box that runs other people's programs so they can't cheat. That box has passed its own tests on real Linux machines, but no official result has been measured in it yet. So every number on this site was measured on the author's own computer, with the author's own programs. The numbers are real, but nothing is certified.")}
<section class="block"><p class="kicker">From a declaration to a certificate</p><div class="grid3">
<div class="card step"><span class="n">1</span><h3>Describe the problem</h3><p class="fine">Write three small pieces: how to make a test question from a secret number (with the answer hidden inside), how to check an answer exactly, and a plain baseline solver to compare against.</p>{cmd("python3 compile_domain.py init mything")}</div>
<div class="card step"><span class="n">2</span><h3>Compile it into a test</h3><p class="fine">The compiler checks that your problem can't be gamed, times your baseline, picks the test sizes and time limit, and works out what size of speedup it can actually prove. It ends with READY or NOT READY.</p>{cmd("python3 compile_domain.py compile mything")}</div>
<div class="card step"><span class="n">3</span><h3>Get a certificate</h3><p class="fine">After a round, one file holds the claim, the rules, the secret numbers and every raw measurement. Anyone can recompute the result from it, and checking it never runs the file's code unless you ask. It cannot show the CPU costs were honestly measured: that needs the verified sandbox, or re-running instances yourself.</p>{cmd("python3 certificate.py verify x.cert.json")}</div></div>
<p class="fine" style="margin-top:12px">The compiler and certificates are built and tested, but no round has run on a verified sandbox yet, so no certificate here is official. <a href="domains.html">Domains</a> shows what each test can and can't prove; <a href="guide.html">the guide</a> explains how to write a problem and check a certificate.</p></section>
<section class="block"><p class="kicker">How a test stays fair, in four steps</p><div class="grid4">
<div class="card step"><span class="n">1</span><h3>Commit</h3><p class="fine">Before anyone submits, the judge publishes a fingerprint (a hash) of a secret number. Every test question is generated from that number, so nobody can prepare answers in advance, and the judge can't swap the questions afterwards.</p></div>
<div class="card step"><span class="n">2</span><h3>Solve</h3><p class="fine">The submitted solver and the baseline get the same questions, one process each, with a time limit. Every question has a known answer hidden inside it, so every one can be solved.</p></div>
<div class="card step"><span class="n">3</span><h3>Check</h3><p class="fine">Every answer is checked exactly. A wrong or missing answer is charged the full time limit, so giving up on the hard questions can't look like being fast.</p></div>
<div class="card step"><span class="n">4</span><h3>Score</h3><p class="fine">Questions are grouped by how hard the baseline found them. The score is a cautious estimate of the speedup on the hardest groups: a number we are 95% sure the true speedup is at least as large as. A lucky run can't inflate it.</p></div></div></section>
<section class="block"><p class="kicker">Words used on this site</p><div class="card"><dl class="gloss">
<dt>Bits</dt><dd>How we count speed. Each bit doubles it: 3 bits is 8 times faster.</dd>
<dt>Baseline (reference solver)</dt><dd>The plain, standard solver every other solver is compared against.</dd>
<dt>Instance</dt><dd>One test question. A solver gets it and must return an answer.</dd>
<dt>Size ladder</dt><dd>The list of question sizes used, from easier to harder.</dd>
<dt>Time limit (CPU cap)</dt><dd>The most CPU time one question may take. Failing or timing out is charged the full limit.</dd>
<dt>Seed and commitment</dt><dd>A secret number that every question is generated from, and its published fingerprint. The fingerprint proves the questions were fixed before anyone submitted.</dd>
<dt>Certificate</dt><dd>One file with the claim, the rules and every raw measurement, so anyone can recompute the result.</dd>
<dt>Official (certified)</dt><dd>A result measured inside the strict, locked-box test environment, on three independent secret numbers. Everything on this site is a practice result instead.</dd>
<dt>Locked box (sandbox)</dt><dd>A sealed environment that runs other people's programs so they cannot read the answers, hide work or tamper with the timer.</dd>
<dt>Round</dt><dd>One contest: the secret numbers are fingerprinted first, solvers are submitted until a deadline, then everything is run and the secrets are revealed.</dd>
<dt>Lattice, factoring, dlog</dt><dd>The puzzle types used so far: finding a short vector in a grid of points; splitting a big number into smaller ones; finding the exponent in a modular power (the discrete logarithm).</dd>
<dt>Exact count (step counting)</dt><dd>Counting the Python instructions a program runs instead of timing it. Anyone on the same Python version gets the same number, so nobody has to trust a clock or a computer.</dd></dl></div></section>"""
    return layout("index.html", "Guldo: verifiable speedup claims", "A challenge compiler and a protocol for crediting claimed algorithmic speedups: declare a problem, get a calibrated challenge and a certificate anyone can recompute.", body)


def page_method():
    body = f"""
<section class="block"><p class="kicker">Method</p><h1>How a result is checked</h1>
<p class="lede">The test assumes whoever submits a solver may be mistaken, careless or cheating, and asks what can still be concluded. Every rule below closes a specific way a result could be gamed or misread.</p></section>
<section class="block"><h2>The rules</h2><div class="grid3">
<div class="card"><h3>Seed first, reveal later</h3><p class="fine">Before the deadline we publish a fingerprint of a secret number, the seed. After the deadline we reveal the seed. Every test question is computed from it, so nobody could have tuned a solver to the questions, and anyone can recompute them. You can run that check yourself on the <a href="preregistrations.html">pre-registrations page</a>.</p></div>
<div class="card"><h3>Every question has a known answer</h3><p class="fine">Each question is built around an answer we hid in it: a short point in a lattice, or two known primes multiplied together. So no question is impossible, and a table of old answers cannot cover new questions.</p></div>
<div class="card"><h3>Answers are checked exactly</h3><p class="fine">Whole-number arithmetic only. For lattices we check that the point is on the lattice and short enough; for factoring, that the number divides evenly. A solver can claim anything. The checker decides.</p></div>
<div class="card"><h3>Same question, both solvers</h3><p class="fine">The speedup on a question is <span class="mono">log2(baseline cost / your cost)</span>, measured on that same question. Runs under 0.5 s are ignored: a fixed startup cost would otherwise look like a speedup or a slowdown.</p></div>
<div class="card"><h3>Failing costs the maximum</h3><p class="fine">If the baseline runs out of time on a question, that question is dropped. If your solver fails, it is charged the full time limit. Dropping questions only when the <em>baseline</em> fails closes the trick of failing the hard ones on purpose.</p></div>
<div class="card"><h3>Grouped by difficulty</h3><p class="fine">Questions are grouped by how hard the baseline found them, each group costing about twice the one before. A group counts only if it has at least 5 questions and your solver's median cost there is at least 0.5 s. The credit comes from the three hardest groups that count.</p>
<p class="fine"><strong>For example:</strong> if the baseline takes about 1, 2, 4 and 8 seconds on four groups of questions, a group is used only when it holds at least 5 questions and your solver needs half a second or more on them. A solver that is so fast it finishes the easy groups in a blink simply has no say about those groups.</p></div></div></section>
<section class="block"><div class="two"><div><h2>The credit</h2>
<p>The credit is deliberately cautious: a number we are 95% sure the true speedup reaches or beats. It is found by re-running the whole analysis on many reshuffled copies of the data, including the step that picks the groups, so the choice of groups is part of the uncertainty. What the credit still cannot show is on the <a href="limits.html">Limits page</a>.</p>
<p>A second, exploratory claim covers only the hardest questions (baseline cost of 4 s or more). It picks nothing after the fact and is reported separately. It is promoted only if a pre-registered test on a fresh seed supports it.</p></div>
<div class="card"><h3>"Official" means all of this</h3><ul class="fine"><li>The locked-box environment, with a meter that bills every process a solver starts</li><li>At least three independent seeds, each with its fingerprint published first</li><li>The problem's full question count and time limit</li><li>The same computer, the same solver file and the same baseline file for every seed</li><li>The credit is the <strong>lowest</strong> over the seeds, and a seed with no conclusion counts as zero</li></ul></div></div></section>
<section class="block"><h2>Pre-registration</h2><p>Before the test on a fresh seed, we wrote the setup, the fingerprints of the code and the pass criteria into a file, and kept the file. The criteria are fixed in advance: whichever outcome occurs is the one the file says it is. A registration that is abandoned is marked void and kept, never edited; every one is listed on the <a href="preregistrations.html">pre-registrations page</a>.</p></section>
<section class="block"><h2>What a certificate adds</h2><p>A certificate is one file that carries everything needed to check a result on your own machine: the questions' seeds, every measured time, both solvers and the log showing the fingerprints came first. <a href="guide.html">The guide</a> says exactly what checking it proves, and what it cannot.</p></section>
<section class="block"><h2>Beyond speedups</h2><p>The same file can back other claims, such as a benchmark score on questions fixed in advance, or a result that nobody in a contest managed to beat a target. They are on the <a href="claims.html">Other claims</a> page, each with what it does not show.</p></section>"""
    return layout("method.html", "Method - Guldo", "The rules of the speedup-verification protocol and why each one exists.", body)


def control_verdict(credit, median):
    """The seed-E criteria, exactly as written in results/PREREGISTERED_seedE_factor.txt, applied mechanically.
    credit: None if inconclusive. Returns (outcome label, meaning)."""
    if credit is None:
        return "(d) inconclusive", "FAILS: a known large effect was not certifiable at this ladder"
    if credit < 2.5:
        return "(c) conclusive credit below 2.5 bits", "FAILS: the pipeline under-certifies a known effect"
    if 3.5 <= median <= 5.5:
        return "(a) credit at least 2.5 and median within [3.5, 5.5]", "the pipeline RECOVERS a known large speedup"
    return "(b) credit at least 2.5 but median outside [3.5, 5.5]", "FAILS as a recovery: the number disagrees with the calibration"


def prereg_cards(data, prereg, notes):
    cards = []
    for p in sorted(prereg, key=lambda p: p["date"]):
        note = notes.get(p["tag"], "")
        if p["tag"] == "755a57fd":
            c = R.prereg_card(os.path.join(HERE, "results", p["file"]), data, p["tag"], note)
            if c:
                cards.append(c)
        elif p["tag"] == "88ecb627":
            run = next(((s, d) for s, d in data if s["family"] == "factor" and s["tag"] == p["tag"][:8] and "error" not in d), None)
            if run:
                d = run[1]
                cr = credit_of(d)
                label, meaning = control_verdict(cr, d["meas"][0] if d["meas"] else None)
                shown = "inconclusive" if cr is None else f"{cr:.2f} bits (median {d['meas'][0]:.2f})"
                failed = note.strip().upper().startswith("FAILED")
                caveat = ('<div class="banner" role="note">' + R.ICON["PROVISIONAL"] + '<p><strong>The registered concurrency criterion failed.</strong> '
                          'The credit outcome above is real, but the timings it rests on were biased by running several jobs at once, so it must not be read '
                          'as a clean recovery of the known speedup. Treat it as: a speedup at least this large was certified under biased timings.</p></div>'
                          if failed else "")
                cards.append(f'<section class="card"><h2>Positive control, seed {esc(p["tag"])}</h2><p>The criteria were written before any data existed '
                             f'and are applied here without interpretation. The true effect was calibrated in-process at about 4.4 bits.</p>'
                             f'<dl class="facts"><div><dt>Primary claim</dt><dd>{esc(shown)}: outcome {esc(label)}, which means {esc(meaning)}.</dd></div>'
                             f'<div><dt>Concurrency check</dt><dd>{esc(note or "not recorded on this page yet")}</dd></div></dl>{caveat}</section>')
    return "".join(cards)


def page_results(data, board, prereg=None, notes=None, results_dir=None, certs_dir=None):
    import certs_site
    import dlog_experiment
    runs = []
    for s, d in data:
        if "error" in d:
            runs.append(f'<div class="card"><h3>{esc(s["name"])} <span class="muted">on {esc(s["family"])}, seed {esc(s["tag"])}</span></h3>'
                        f'<span class="pill idle">{R.ICON["INCONCLUSIVE"]}<span>Not shown</span></span>'
                        f'<p class="fine">The saved ladders cannot be charted yet: {esc(d["error"])}. A run still being written is expected to look like this; '
                        f'a page never charts a truncated ladder as if it were complete.</p></div>')
        else:
            runs.append(f'<div class="card">{R.run_section(s, d)}</div>')
    body = f"""
<section class="block"><p class="kicker">Results</p><h1>What has been measured</h1>
<p class="lede">Every number here comes from saved timings you can download and recompute. Each run below shows the data behind its number: the difficulty groups, every question, and a table of the same figures.</p></section>
{banner("<strong>None of these is an official result.</strong> They were run on one computer, with solvers I wrote, without the locked-box environment. &ldquo;Provisional&rdquo; means measured and reproducible from the saved data, not certified.")}
<section class="card"><h2>Leaderboard</h2>{R.leaderboard(board)}
<p class="fine" style="margin-top:14px">The credit on the board is the <strong>lowest over a submission's seeds</strong>, so one weak or small run pulls it down. A row that reads lower than the pre-registered result below it usually includes an early design run (12 questions per size, 60 s limit, the data the credit rule was built from). That is why each row lists its per-seed values and the reasons it is not official.</p></section>
{prereg_cards(data, prereg or [], notes or {})}
{dlog_experiment.card_html(results_dir) if results_dir else ""}
{certs_site.section_html(certs_dir)}
<section class="block"><h2>Runs</h2><div style="display:grid;gap:18px">{"".join(runs) or '<p class="muted">No ladders found.</p>'}</div></section>
<section class="card"><h2>Reading these charts</h2><ul class="fine"><li>Each bar is the typical (median) speedup in bits for questions grouped by how hard the <em>baseline</em> found them. Each bit is a factor of two.</li>
<li>Solid bars are the three hardest groups that count, and they make up the credit. Light bars count but are not among the hardest. Dashed bars have too few questions, or sit below the 0.5 s floor, so they do not count.</li>
<li>The dashed line is the credit. It sits below the bars on purpose: it is the cautious number, not the typical one.</li>
<li>The "speedup by problem size" chart asks a different question: does the speedup grow as the problem gets harder? It shows the typical speedup at each size with a 90% range. Where the baseline ran out of time, its cost is taken as the time limit, so those questions can only understate the speedup. Hollow points are sizes the credit does not use (too many baseline time-outs, or costs under the 0.5 s floor). They are lower bounds or reference points, not measurements, and nothing is guessed beyond them or joined by a line.</li>
<li>A group can show a negative speedup: a tuned solver with a fixed setup cost is slower on trivial questions. That is why the floor exists, and it is shown, not hidden.</li></ul></section>"""
    return layout("results.html", "Results - Guldo", "Measured speedups with the data behind each number.", body)


def page_prereg(prereg, seeds):
    manifest = [{"label": f"seed {p['tag']}: {p['title'][:70]}", "commit": p["commit"], "seed": seeds.get(p["commit"], "")} for p in prereg]
    items = []
    for p in sorted(prereg, key=lambda p: p["date"]):
        kind, why = PREREG_STATUS.get(p["tag"], ("run", ""))
        cls = "void" if kind == "void" else ""
        pill = {"void": '<span class="pill idle">' + R.ICON["INCONCLUSIVE"] + '<span>Void</span></span>',
                "done": '<span class="pill ok">' + R.ICON["OFFICIAL"] + '<span>Completed</span></span>',
                "run": '<span class="pill warn">' + R.ICON["PROVISIONAL"] + '<span>Registered</span></span>'}[kind]
        revealed = (f'<p class="small muted">Seed revealed: <span class="mono">{esc(seeds[p["commit"]][:12])}...</span> (shipped with the checker below)</p>'
                    if p["commit"] in seeds else '<p class="small muted">Seed not revealed yet.</p>')
        items.append(f'<div class="item {cls}"><div class="small muted mono">{esc(p["date"])}</div><h3>{esc(p["title"])}</h3>{pill}'
                     f'<p class="fine">{esc(why)}</p><p class="small mono" style="word-break:break-all">commitment {esc(p["commit"])}</p>{revealed}'
                     f'<details><summary>The registration, verbatim</summary><pre>{esc(p["text"])}</pre>'
                     f'<p class="small"><a href="prereg/{esc(p["file"])}">Download {esc(p["file"])}</a></p></details></div>')
    body = f"""
<section class="block"><p class="kicker">Pre-registrations</p><h1>Written before the data existed</h1>
<p class="lede">A claim that the method works is only worth something if the pass criteria were fixed before looking. Each registration here carries its date, the seed commitment, the criteria and the hashes of the code it will run.</p></section>
<section class="block"><div class="tl">{"".join(items)}</div></section>
<section class="card"><h2>Check a commitment yourself</h2>
<p class="fine">Pick a run, paste the revealed seed, and your own browser computes its SHA-256 and compares it with the commitment above. Nothing is sent anywhere.</p>
<form class="verify" id="verify" onsubmit="return false"><label for="v-run" class="small muted">Run</label><select id="v-run"></select>
<label for="v-seed" class="small muted">Seed</label><textarea id="v-seed" spellcheck="false" placeholder="paste the revealed seed (hex text)"></textarea>
<div class="btnrow"><button class="btn primary" id="v-check" type="button">Check</button><button class="btn" id="v-fill" type="button">Fill in the revealed seed</button></div>
<div class="vres" id="v-result" role="status" aria-live="polite"></div></form></section>"""
    return layout("preregistrations.html", "Pre-registrations - Guldo", "Dated registrations with seed commitments and unconditional criteria.", body, manifest)


def live_rounds(index, portal_url, sandbox_ok):
    """The 'Live rounds' block for the Compete page, from rounds.export_public's index (never hand-typed)."""
    if not index:
        return ""
    rows = []
    for r in index:
        title = (f'<a href="{esc(portal_url.rstrip("/"))}/round/{esc(r["id"])}">{esc(r["title"])}</a>' if portal_url else esc(r["title"]))
        when = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(r["closes_at"]))
        log = (f'<a href="ledger/log_{esc(r["id"])}.jsonl">log</a>, head <span class="mono small">{esc((r["log_head"] or "")[:12])}...</span>'
               if r["log_ok"] else '<span class="pill warn"><span>log does not verify</span></span>')
        rows.append(f'<tr><td class="strong">{title}</td><td>{esc(r["family"])}</td><td><span class="pill info"><span>{esc(r["state"])}</span></span></td>'
                    f'<td class="mono small">{esc(when)}</td><td class="num mono">{r["submissions"]}</td><td>{log}</td></tr>')
    gate = ("The operator reports the sandbox as verified for this deployment." if sandbox_ok else
            "The timing sandbox is <strong>not</strong> verified for this deployment, so timed rounds cannot be evaluated or produce an official result yet. Counted rounds (exact step counts, not seconds) can be evaluated, but they run on the operator's own machine without operating-system isolation.")
    return ('<section class="card"><h2>Live rounds</h2><div class="scroll"><table class="lb"><thead><tr><th>Round</th><th>Family</th><th>State</th><th>Closes</th>'
            '<th class="num">Submissions</th><th>Transparency log</th></tr></thead><tbody>' + "".join(rows) + '</tbody></table></div>'
            f'<p class="fine" style="margin-top:12px">{gate} Each round publishes its seed commitments before it opens, every accepted file\'s hash goes into a hash-chained log you can download and verify, '
            'and the seeds are revealed only after evaluation.</p></section>')


def declared_rows():
    """(name, signature, what to return) for every compiled declared domain (COMPILER.md), from its own declaration's SIGNATURE and DOC."""
    import declared
    out = []
    for name, info in sorted(families.DECLARED.items()):
        try:
            mod = declared.load_declaration(info["dir"])
        except declared.DeclarationError:
            continue
        sig = getattr(mod, "SIGNATURE", None)
        if not sig:  # default: the reference solver's own parameter list
            import ast
            try:
                with open(declared.reference_path(info["dir"], mod), "rb") as f:
                    fn = next(n for n in ast.parse(f.read()).body if isinstance(n, ast.FunctionDef) and n.name == "solve")
                sig = "solve(" + ", ".join(a.arg for a in fn.args.args) + ")"
            except (StopIteration, SyntaxError, OSError, declared.DeclarationError):
                sig = "solve(*args)"
        doc = getattr(mod, "DOC", "See the challenge page for this family.")
        m = re.match(r"^solve\([^)]*\):?\s*", doc)   # a DOC that opens with the signature would repeat the column beside it
        if m and m.end() < len(doc):
            doc = doc[m.end():]
            doc = doc[:1].upper() + doc[1:]
        out.append((name, sig, doc))
    return tuple(out)


# one plain sentence per problem, shown beside its name: the names themselves (gm, mlwe, dlog) mean nothing to a newcomer
PROBLEM_GLOSS = {
    "gm": "A lattice puzzle: find a short vector in a huge grid of points. Cryptography relies on this being hard.",
    "mlwe": "The same kind of lattice puzzle, in the shape that modern encryption schemes use.",
    "factor": "Factoring: split a large number into smaller whole numbers that multiply back to it.",
    "dlog": "Discrete logarithm: find the exponent x so that g to the power x leaves the remainder h, modulo a prime p.",
}


_LI = re.compile(r"^(\s*)([*-]|\d+\.) (.*)$")


def _inline(s):
    """Inline Markdown on ESCAPED text: `code`, **bold**, *italic*. Escaping first means nothing in the source can inject markup."""
    out = []
    for part in re.split(r"(`[^`]+`)", esc(s)):
        if len(part) > 1 and part.startswith("`") and part.endswith("`"):
            out.append(f"<code>{part[1:-1]}</code>")
            continue
        part = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", part)
        out.append(re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"<em>\1</em>", part))
    return "".join(out)


def _md_list(lines, i):
    """Parse consecutive list items (nested by indentation) starting at lines[i]. -> (html, next index)"""
    items = []
    while i < len(lines):
        m = _LI.match(lines[i])
        if m:
            items.append([len(m.group(1)), m.group(2)[0].isdigit(), m.group(3)])
        elif items and lines[i].strip() and lines[i].startswith("  ") and not lines[i].startswith("    "):
            items[-1][2] += " " + lines[i].strip()  # a wrapped continuation of the previous item
        else:
            break
        i += 1
    html, stack = [], []
    for indent, ordered, text in items:
        while stack and indent < stack[-1][0]:
            html.append(f"</li></{stack.pop()[1]}>")
        if stack and indent == stack[-1][0]:
            html.append("</li>")
        else:
            html.append("<ol>" if ordered else "<ul>")
            stack.append((indent, "ol" if ordered else "ul"))
        html.append(f"<li>{_inline(text)}")
    while stack:
        html.append(f"</li></{stack.pop()[1]}>")
    return "".join(html), i


def md_to_html(md):
    """A deliberately small Markdown subset (headings, paragraphs, nested lists, tables, indented code, inline code/bold/italic): what COMPILER.md
    uses and nothing else. -> (html, title, [(id, heading)]). All text is escaped; there is no raw-HTML passthrough."""
    lines, i, out, toc, title, used = md.splitlines(), 0, [], [], "", set()
    is_block = lambda ln: (ln.startswith(("#", "|", "    ")) or _LI.match(ln) is not None)
    while i < len(lines):
        ln = lines[i]
        if not ln.strip():
            i += 1
        elif ln.startswith("# "):
            title, i = ln[2:].strip(), i + 1
        elif re.match(r"^#{2,4} ", ln):
            level = len(ln) - len(ln.lstrip("#"))
            text = ln[level:].strip()
            slug = base = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "section"
            n = 2
            while slug in used:
                slug, n = f"{base}-{n}", n + 1
            used.add(slug)
            if level == 2:
                toc.append((slug, text))
            out.append(f'<h{level} id="{slug}">{_inline(text)}</h{level}>')
            i += 1
        elif ln.startswith("    "):
            block = []
            while i < len(lines) and (lines[i].startswith("    ") or (not lines[i].strip() and i + 1 < len(lines) and lines[i + 1].startswith("    "))):
                block.append(lines[i][4:])
                i += 1
            out.append('<pre class="codeblock"><code>' + esc("\n".join(block)) + "</code></pre>")
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            body_rows = [r for r in rows[2:]] if len(rows) > 1 and set("".join(rows[1])) <= set("-: ") else rows[1:]
            head = "".join(f"<th>{_inline(c)}</th>" for c in rows[0])
            out.append('<div class="scroll"><table class="lb"><thead><tr>' + head + "</tr></thead><tbody>"
                       + "".join("<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in r) + "</tr>" for r in body_rows) + "</tbody></table></div>")
        elif _LI.match(ln):
            html, i = _md_list(lines, i)
            out.append(html)
        else:
            para = []
            while i < len(lines) and lines[i].strip() and not is_block(lines[i]):
                para.append(lines[i].strip())
                i += 1
            out.append(f"<p>{_inline(' '.join(para))}</p>")
    return "\n".join(out), title, toc


def page_guide():
    """The compiler guide, rendered from COMPILER.md at build time so the page cannot drift from the document in the repository."""
    try:
        with open(os.path.join(HERE, "COMPILER.md"), encoding="utf-8") as f:
            html, title, toc = md_to_html(f.read())
    except OSError:
        html, title, toc = '<p class="fine">COMPILER.md is not present in this checkout, so this guide could not be generated.</p>', "The challenge compiler", []
    toc_html = ('<nav class="card toc" aria-label="On this page"><strong>On this page</strong><ul class="fine">'
                + "".join(f'<li><a href="#{esc(s)}">{_inline(t)}</a></li>' for s, t in toc) + "</ul></nav>") if toc else ""
    body = f"""
<section class="block"><p class="kicker">Guide</p><h1>{esc(title or "The challenge compiler")}</h1>
<p class="lede">How to describe a problem, turn it into a fair test, and check a certificate, including what each step can't do. This page is generated from <span class="mono">COMPILER.md</span> in the repository, so it matches the code. It is the technical reference: the later sections (counted rounds, the restricted subset, derived claims) assume you know the basics, and the plain-words version is on <a href="claims.html">Other claims</a>.</p></section>
<section class="block"><div class="card"><h2 style="margin-top:0">If you read only this</h2><ol class="fine">
<li>You write three small pieces: make a test question from a secret number, check an answer exactly, and a plain baseline solver.</li>
<li><span class="mono">compile_domain.py check NAME</span> takes seconds and tells you what to fix. <span class="mono">compile NAME --quick</span> gives a draft in minutes. <span class="mono">compile NAME</span> is the real one and can take hours.</li>
<li>A certificate lets anyone recompute a result, but only shows the costs were honestly measured if the verified sandbox or a re-run backs it. Checking one never runs its code unless you pass <span class="mono">--execute</span>.</li>
<li>Past speedups: a cost can be an exact instruction count that anyone reproduces, and a certificate can back a benchmark score or a verified negative result. These are newer and have never been run: see <a href="claims.html">Other claims</a>.</li></ol></div></section>
{banner("<strong>Practice stage.</strong> A certificate can show the arithmetic adds up, but not that the CPU costs were honestly measured. Nothing is certified as official until a full round has been evaluated in the strict test environment (the locked box) on a dedicated machine.")}
<section class="block"><div class="two guide-wrap">{toc_html}<div class="guide">{html}</div></div></section>"""
    return layout("guide.html", "Guide - Guldo", "How to declare a problem, compile it into a challenge, and verify a certificate.", body)


BUILTIN_FAMILIES = (("gm", "Lattice: a short vector", "Given a lattice (a regular grid of points in many dimensions), find a short non-zero point on it. Each test lattice has a short point hidden in it, so a good answer is known to exist."),
                    ("mlwe", "Lattice: encryption-style", "The same task on lattices of the kind used in some modern encryption schemes."),
                    ("factor", "Integer factoring", "Given a large number that is the product of two primes, find a factor of it."))


def _power_rows(compiled):
    rows = []
    for e, v in compiled["power"]["curve"].items():
        pct = round(100 * v["all_three"])
        rows.append(f'<tr><td class="num mono">{esc(e)}</td><td><div class="bar" role="img" aria-label="{pct}% of simulated three-seed rounds certify this speedup">'
                    f'<span style="width:{pct}%"></span></div></td><td class="num mono">{pct}%</td></tr>')
    return ('<div class="scroll"><table class="lb"><thead><tr><th class="num">Real speedup (bits)</th><th>Proven in all three rounds</th><th class="num">%</th></tr></thead>'
            '<tbody>' + "".join(rows) + '</tbody></table></div>')


def domain_card(name, info):
    """One compiled domain, entirely from its compiled.json and declaration: nothing on this card is typed by hand."""
    import compile_domain as CD
    import declared
    c = info["compiled"]
    level, _ = CD.verdict(c)
    cls = "ok" if level == "READY" else "idle" if level.startswith("NOT READY") else "warn"
    icon = R.ICON["OFFICIAL"] if cls == "ok" else R.ICON["INCONCLUSIVE"] if cls == "idle" else R.ICON["PROVISIONAL"]
    label = ("Ready" if level == "READY" else "Not ready" if level.startswith("NOT READY") else "Ready, with notes" if level.startswith("READY") else "Draft")
    meaning = {"Ready": "", "Ready, with notes": "Usable, but read the compiler's notes below: they say how far to trust the test.",
               "Draft": "Practice only until it passes the compiler's self-test.", "Not ready": "The compiler could not build a test that proves anything useful."}[label]
    try:
        doc = getattr(declared.load_declaration(info["dir"]), "DOC", "")
    except declared.DeclarationError:
        doc = ""
    pw, st = c["power"], (c.get("selftest") or {}).get("status", "pending")
    mce, top = pw["min_certifiable_effect"], pw.get("max_certifiable_effect")
    certifies = (f"speedups from about {mce:g} to {top:g} bits ({2 ** mce:.1f} to {2 ** top:.1f} times faster) than the baseline"
                 if mce is not None else "nothing yet: the test is too weak to prove a speedup")
    selftest = {"pass": "passed", "pending": "not finished yet", "skipped": "not run (draft)", "fail": "FAILED"}.get(st, st)
    notes = list(c["plan"]["notes"]) + list(pw["notes"])
    note_html = (f'<details class="more"><summary>Notes from the compiler ({len(notes)})</summary><ul class="fine">'
                 + "".join(f"<li>{esc(x)}</li>" for x in notes) + "</ul></details>") if notes else ""
    return (f'<article class="card" id="{esc(name)}"><span class="pill {cls}">{icon}<span>{esc(label)}</span></span>'
            f'<h3 style="margin-top:10px">{esc(name)}</h3>'
            + (f'<p class="fine">{esc(doc)}</p>' if doc else "")
            + f'<p><strong>What it can prove:</strong> {esc(certifies)}.</p>'
            + (f'<p class="fine">{esc(meaning)}</p>' if meaning else "")
            + f'<ul class="fine"><li><strong>The test:</strong> problem sizes {esc(c["dims"])}, {esc(c["official"]["n"])} questions per size, time limit {esc(c["official"]["budget"])} s per question; '
              f'about {esc(c["cpu_hours"]["expected"])} CPU-hours to score one solver.</li>'
              f'<li><strong>The baseline:</strong> {esc(c.get("reference_note") or "the author has not said what it is or what is known to beat it, so a speedup over it may be easy.")}</li>'
              f'<li><strong>Compiler self-test:</strong> {esc(selftest)}. It checks that the baseline against itself scores about 0, that a solver which never answers scores 0, and that a known 1-bit speedup is recovered.</li></ul>'
            + '<h4>How often a real speedup of each size would be proven</h4>' + _power_rows(c)
            + f'<p class="fine">Assumes a solver\'s speed varies about {esc(pw["pair_noise"])} bit from question to question. The real figure is unknown until someone submits.</p>'
            + note_html
            + f'<p class="fine">Version <span class="mono">{esc(c.get("version"))}</span>, fingerprint <span class="mono">{esc(c["decl_sha256"][:12])}</span>.</p>'
            + '<p class="fine">Check the compiler\'s arithmetic yourself (it recomputes the whole table from the saved record and says if anything differs):</p>'
            + cmd(f"python3 compile_domain.py recheck {name}")
            + cmd(f"python3 submit_check.py my_solver.py --family {name}") + '</article>')


def page_domains():
    cards = [domain_card(n, i) for n, i in sorted(families.DECLARED.items())]
    # a reason can quote an exception or a path from the operator's machine: this page is public, so show the sentence, not the filesystem
    scrub = lambda s: re.sub(r"(/[\w.@+\-]+){2,}", "<path>", str(s).replace(HERE, "."))[:300]
    errors = [(k, scrub(v)) for k, v in sorted(families.DECLARED_ERRORS.items())]
    builtin = "".join(
        f'<article class="card" id="{n}"><span class="pill info"><span>Built in</span></span><h3 style="margin-top:10px">{esc(n)}: {esc(t)}</h3><p class="fine">{esc(d)}</p>'
        f'<ul class="fine"><li><strong>The test:</strong> problem sizes {esc(families.DEFAULT_DIMS[n])}, {esc(families.OFFICIAL[n]["n"])} questions per size, '
        f'time limit {esc(families.OFFICIAL[n]["budget"])} s per question</li><li>Set up by hand, not by the compiler. What has been measured is on the <a href="results.html">Results page</a> and its limits on the <a href="limits.html">Limits page</a>.</li></ul></article>'
        for n, t, d in BUILTIN_FAMILIES)
    err_html = ("<section class=\"block\"><h2>Declared but not registered</h2><p class=\"fine\">A declaration is registered only while its compiled record matches "
                "its files. These are not, and why:</p><ul class=\"fine\">" + "".join(f"<li><span class=\"mono\">{esc(k)}</span>: {esc(v)}</li>" for k, v in errors) + "</ul></section>") if errors else ""
    body = f"""
<section class="block"><p class="kicker">Domains</p><h1>Problems you can test speedups on</h1>
<p class="lede">Each card is a problem we can measure speedups on, and says what size of speedup its test can prove. The built-in ones were set up by hand. The others were made by the compiler from a short description, and every number on their cards is read from the compiler's own record.</p></section>
{banner("<strong>These are practice results too.</strong> None of these problems can produce a certified result until the locked-box test environment has been tried on a real machine.")}
<section class="block"><h2>Compiled domains</h2>{('<div class="two">' + "".join(cards) + '</div>') if cards else '<p class="fine">No compiled domain is installed in this build.</p>'}</section>
{err_html}
<section class="block"><h2>Built-in families</h2><div class="two">{builtin}</div></section>
<section class="block" id="add"><h2>Add your own</h2><div class="two"><div>
<p>You write three small pieces: how to make a test question from a secret number with the answer hidden inside (<span class="mono">derive</span>), how to check an answer exactly (<span class="mono">verify</span>), and a plain baseline solver. The first command below creates a working example to edit.</p>
{cmd("python3 compile_domain.py init mything")}{cmd("python3 compile_domain.py check mything")}{cmd("python3 compile_domain.py compile mything --quick")}{cmd("python3 compile_domain.py compile mything")}{cmd("python3 compile_domain.py show mything")}
<p class="fine">New to this? <a href="guide.html">The guide</a> walks through it, including what the compiler checks, how to verify a certificate, and the limits.</p>
</div><div class="card"><h3>What the compiler turns down</h3><ul class="fine"><li>Questions that change depending on the clock, chance or the machine</li><li>A checker that accepts junk such as nothing, 0 or 1, or an answer read straight off the question</li><li>An answer hidden in the question text, or one answer that fits every question</li><li>A baseline that gets answers wrong, or that depends on the judge's own code</li></ul>
<h3 style="margin-top:14px">What it can't do</h3><ul class="fine"><li>Judge whether your baseline is a good algorithm. A certificate only says "faster than this baseline"</li><li>Prove a problem has no shortcut</li><li>Prove speedups above about 5 bits (about 32 times faster) with a 120 s time limit</li></ul></div></div></section>"""
    return layout("domains.html", "Domains - Guldo", "Problems the protocol can measure, built in and compiled from a declaration.", body)


def page_compete(rounds_index=None, portal_url="", sandbox_ok=False):
    rows ="".join(f'<tr><td class="strong">{esc(k)}' + (f'<br><span class="fine">{esc(PROBLEM_GLOSS[k])}</span>' if k in PROBLEM_GLOSS else "") + f'</td><td class="mono">{esc(a)}</td><td>{esc(b)}</td></tr>'
                   for k, a, b in (("gm", "solve(basis, bound2)", "Return any nonzero lattice vector, as a list of ints, with squared norm at most bound2 (1.05 x the Gaussian heuristic)."),
                                   ("mlwe", "solve(basis, bound2)", "The same call on module-LWE-shaped lattices; the target is 1.5 x the planted short vector's norm."),
                                   ("factor", "solve(n)", "Return any nontrivial divisor of n, as an int.")) + declared_rows())
    body = f"""
<section class="block"><p class="kicker">Compete</p><h1>Submit a solver</h1>
<p class="lede">Write one Python file with a function called <span class="mono">solve</span>. The judge announces which problem is being tested, and the problem decides what <span class="mono">solve</span> receives.</p></section>
{banner("<strong>Submissions are taken in rounds.</strong> Your file is read, never run, while a round is open; it is run only after the round closes, on instances fixed by seeds committed before the round opened: in a container for a timed round, and inside the step counter's restricted subset of Python for a counted round. Nothing is official until the sandbox has been verified on the operator's host; a counted round is certified by exact, re-executable step counts instead." if rounds_index else "<strong>No public submission service exists yet.</strong> Running other people's code safely needs the sandbox verified on a real host. Today you can check a solver locally against the same verifiers the judge uses; the judge cannot yet evaluate it officially.")}
{live_rounds(rounds_index, portal_url, sandbox_ok)}
<section class="card"><h2>What you write</h2><div class="scroll"><table class="lb"><thead><tr><th>Problem</th><th>Your function</th><th>What it returns</th></tr></thead><tbody>{rows}</tbody></table></div>
<ul class="fine" style="margin-top:14px"><li>Return a whole number, a list of whole numbers, or <span class="mono">None</span>. Anything else counts as a crash, and a failure is charged the full time limit.</li>
<li>Give the same output every time, use one process, and do not read files or use the network. Only <span class="mono">fpylll</span>, <span class="mono">numpy</span> and the standard library exist in the locked box.</li>
<li><span class="mono">print()</span> is safe: it goes to the error stream and cannot corrupt your answer.</li>
<li>Some rounds count Python instructions instead of seconds (the round's page says so). Then your solver must be plain computation: loops, arithmetic, lists and dictionaries, and only these imports: <span class="mono">math</span>, <span class="mono">itertools</span>, <span class="mono">heapq</span>, <span class="mono">bisect</span>, <span class="mono">functools</span>, <span class="mono">collections</span>, <span class="mono">fractions</span>. No files, no <span class="mono">sys</span>, no <span class="mono">getattr</span>. Only the factoring problem can be counted so far. Try <span class="mono">python3 counted.py check my_solver.py --family factor --dim 38</span> to see whether yours runs.</li></ul></section>
<section class="block"><div class="two"><div><h2>Check it first</h2><p class="fine">The pre-flight check looks for anything the locked box blocks, runs your file on small public practice questions, checks every answer, and tests that it gives the same output each time. Passing means well-formed, not fast.</p>
{cmd("python3 submit_check.py solvers/my_solver.py --family gm")}{cmd("python3 submit_check.py solvers/my_solver.py --family factor")}</div>
<div><h2>See how you'd be measured</h2><p class="fine">Work out the cost of an official run before using machine time, and read the baseline solver for each problem.</p>
{cmd("python3 official.py plan --family gm")}{cmd("ls solvers/baseline_bkz.py solvers/factor_trial_py.py")}</div></div></section>
<section class="card"><h2>From the command line</h2><p class="fine">All of this is also one command, <span class="mono">guldo</span>. It checks your file, uploads it, and confirms your receipt in the round's public log using its own copy of the chain. It follows the round, and once the seeds are revealed it downloads your certificate and checks it on your own computer. No browser is needed. The <a href="install.html">Install page</a> has the download and the three steps; the full guide is <span class="mono">SUBMIT.md</span> in the repository.</p>
{cmd("guldo practice my_solver.py --family dlog")}{cmd("guldo submit my_solver.py --round ROUND --handle NAME --accept-rules")}{cmd("guldo verify --round ROUND --id SUBMISSION_ID")}
<p class="fine">The first command runs your solver on three seeds of your own and certifies the run, with no server involved. It is provisional by construction. Checking a certificate proves the arithmetic and the fairness, and it says whether the timings came from the locked box or from a plain local run.</p></section>
<section class="card"><h2>What wins</h2><p>Bits of speedup, certified: the cautious number described on the <a href="method.html">Method page</a>, taken as the lowest over at least three seeds. A fast solver that fails the hard questions earns nothing, and so does one that only wins on trivial questions. A result that cannot be told apart from noise is reported as inconclusive.</p>
<p class="fine"><strong>Your algorithm can stay private.</strong> If you choose to publish your source, your certificate carries it and anyone can re-run it. If you don't, the public certificate carries only your solver's fingerprint: everyone can still check the log, the questions and the arithmetic, but only the operator can run your solver, so your timings rest on the operator's sandbox. If you publish the file later, anyone can check it against that fingerprint and re-run it.</p></section>"""
    return layout("compete.html", "Compete - Guldo", "How to write, check and submit a solver.", body)


def package_zip(out):
    """Stage the installable package (build_package.py) and zip it into out/downloads/. -> (file name, sha256, size in bytes). The page shows the hash, so a visitor can
    check what they downloaded; the zip is built from the same checkout as this site, so its protocol files are the ones every certificate here was made with."""
    import build_package
    name = f"{build_package.NAME}-{build_package.DEFAULT_VERSION}"
    os.makedirs(os.path.join(out, "downloads"), exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        build_package.stage(td, build_package.DEFAULT_VERSION)
        shutil.make_archive(os.path.join(out, "downloads", name), "zip", root_dir=td, base_dir=build_package.NAME)
    path = os.path.join(out, "downloads", name + ".zip")
    with open(path, "rb") as f:
        data = f.read()
    return name + ".zip", hashlib.sha256(data).hexdigest(), len(data)


def page_install(zip_name, zip_sha, zip_size):
    """How to install the command-line tool, in plain words, with the honest status of the package."""
    z = esc(zip_name)
    body = f"""
<section class="block"><p class="kicker">Install</p><h1>Install the command-line tool</h1>
<p class="lede">One command, <span class="mono">guldo</span>, lets you try a solver on your own computer, submit it to a round, and check any certificate yourself. No account, no browser.</p></section>
{banner("<strong>Honest status.</strong> This package was built and tried on the author's own computer: it was installed once (with <span class='mono'>pip</span>; <span class='mono'>pipx</span> itself has not been tried) and used to check one real certificate. It is not on the public Python package index, and it has not been installed on a clean computer by anyone else. Exact step counting and the extra claims pass their own tests. A counted test round has run end to end on the project's server and a first real round is open, but no outside participant has used any of it yet.")}
<section class="block"><p class="kicker">Three steps</p><div class="grid3">
<div class="card step"><span class="n">1</span><h3>Download</h3><p class="fine"><a href="downloads/{z}">{z}</a> ({zip_size // 1024} KB). To check what you got, compare its SHA-256 with this one:</p><p class="mono fine" style="word-break:break-all">{esc(zip_sha)}</p>{cmd("shasum -a 256 " + zip_name)}<p class="fine">On Linux the command is <span class="mono">sha256sum</span>.</p></div>
<div class="card step"><span class="n">2</span><h3>Install</h3><p class="fine">The easy way is <span class="mono">pipx</span>, which keeps the tool in its own private folder:</p>{cmd("pipx install ./" + zip_name)}<p class="fine">Or use a virtual environment:</p>{cmd("python3 -m venv ~/.guldo-venv && ~/.guldo-venv/bin/pip install ./" + zip_name)}</div>
<div class="card step"><span class="n">3</span><h3>Check it works</h3><p class="fine">You should see a version number and a list of the other tools:</p>{cmd("guldo --version")}{cmd("guldo tools")}<p class="fine">With a virtual environment, run <span class="mono">~/.guldo-venv/bin/guldo</span> instead.</p></div></div></section>
<section class="block"><div class="two"><div class="card"><h2>What you need</h2><ul class="fine"><li>A Mac or a Linux computer. Windows is not supported.</li><li>Python 3.9 or newer. Exact step counting needs Python 3.12 or newer.</li><li>The numerical library <span class="mono">numpy</span>, which is installed for you.</li><li>Optional: <span class="mono">pip install "./{z}[attest]"</span> in a virtual environment adds signed attestations; <span class="mono">[lattice]</span> adds the library the lattice problems use.</li></ul></div>
<div class="card"><h2>Try it</h2><ul class="fine"><li>Check a solver before you submit: <span class="mono">guldo lint my_solver.py --family factor</span></li><li>See what a practice run on three secret numbers of your own would cost: <span class="mono">guldo practice my_solver.py --family factor --count --dims 38 40 42</span>. It only prints the plan; add <span class="mono">--yes</span> to run it, which can take hours.</li><li>Check a certificate someone gave you: <span class="mono">guldo verify their.cert.json</span></li><li>Work out a benchmark score from it: <span class="mono">guldo claims correctness their.cert.json</span></li><li>See a round and submit: <span class="mono">guldo rounds --server URL</span></li></ul></div></div></section>
<section class="card"><h2>Good to know</h2><ul class="fine"><li><strong>Checking is safe, re-running is not.</strong> <span class="mono">guldo verify FILE</span> never runs any code from the certificate. Adding <span class="mono">--rerun all --execute</span> re-runs the solvers inside it on your machine, with no protection: do that only on a throwaway computer or virtual machine.</li>
<li>Your receipts and tokens are kept in <span class="mono">~/.svp</span>, readable only by you. A submission token is shown once; keep it.</li>
<li>Some commands write under the tool's own folder, which is why <span class="mono">pipx</span> or a virtual environment is the right way to install it. A problem you compile yourself is saved there too, and an upgrade would replace it: keep your own problem declarations in a copy of the repository.</li>
<li>To update, install the newer file over the old one: <span class="mono">pipx install --force ./new-file.zip</span>. To remove it: <span class="mono">pipx uninstall guldo</span>.</li>
<li>Prefer to build it yourself? In a checkout of the repository, <span class="mono">make package</span> creates the same folder, and the hash of this download changes with every build of this site, so always compare against the hash shown above.</li></ul>
<p class="fine">What each result does and does not prove is on the <a href="limits.html">Limits</a> page, and the plain-words list of extra claims is on <a href="claims.html">Other claims</a>.</p></section>"""
    return layout("install.html", "Install - Guldo", "Install the guldo command-line tool: download, check the hash, install with pipx, and try it.", body)


def page_claims():
    """What else a verified certificate can back (claims.py, counted.py). Plain words; every card says what the claim does NOT show."""
    items = [
        ("Exact cost, not seconds", "Instead of timing a program, count the Python instructions it runs. For a program that behaves the same way every time, anyone with the same Python version gets exactly the same number, so a re-run proves the recorded cost without trusting anyone's computer, clock or sealed box.",
         "It is not a time. Work done inside one built-in function (sorting, big-number arithmetic) counts as a single instruction, so it only means something for plain Python on both sides. The solver must be written in a restricted, pure-computation subset of Python.",
         "guldo practice my_solver.py --family factor --count --dims 38 40 42"),
        ("Rounds that count", "A contest can announce, before anyone submits, that every solver will be counted on the same question sizes. The sizes, the cap, the Python version and the counting program are written into the round's first log entry. Every source is public, so anyone can re-run any count.",
         "It is called COUNTED, not official: official means timed inside the verified locked box. Today it is for the factoring problem only, and the operator's machine still runs the submitted code, so it needs a throwaway user or machine.",
         "guldo ops round-new --count --count-dims 38 40 42 ..."),
        ("A benchmark score", "How many of the questions fixed in advance did a program answer correctly, with an uncertainty range, for both the submitted solver and the baseline. The questions come from secret numbers fingerprinted before the program was seen, so nobody could have trained on them.",
         "It is a rate on this question set, under the time limit, for this kind of puzzle. It says nothing about other questions. With seconds as the cost, 'within the limit' depends on the measuring computer; an exact-count certificate removes that.",
         "guldo claims correctness x.cert.json"),
        ("A verified negative result", "'Nobody in this contest reached a speedup of T bits.' The claim holds only if there is a certificate for every submission the round's log accepted and the log shows the round was closed, so nobody can hide the attempt that worked.",
         "It covers the programs actually submitted, not every possible approach. The credit is deliberately cautious, so 'did not reach T' means 'T was not shown', not 'T is impossible'. A submission whose evaluation failed makes the claim incomplete.",
         "guldo claims negative a.cert.json b.cert.json --threshold 2"),
        ("The worst case seen", "For an exact-count certificate: the largest number of instructions seen at each question size, and the chance that one more question from the same source would need more (at most 1 in n+1).",
         "It is the largest value seen, not a guarantee for every possible input of that size. A size where any question timed out or failed has no bound at all.",
         "guldo claims worst-case x.cert.json"),
    ]
    cards = "".join(f'<div class="card"><h3>{esc(t)}</h3><p>{esc(a)}</p><p class="fine"><strong>What it does not show:</strong> {esc(b)}</p>{cmd(c)}</div>' for t, a, b, c in items)
    body = f"""
<section class="block"><p class="kicker">Other claims</p><h1>What else a certificate can prove</h1>
<p class="lede">A certificate records one plain fact: this program, on questions fixed before anyone saw it, gave these answers at this cost. A speedup is just one thing you can read off it. These are others.</p></section>
{banner("<strong>Tested, not yet used.</strong> Everything on this page passes its own tests on the author's computer, and the claims have been worked out from one real certificate. Nobody else has used any of it, and no real round has finished yet (a counted test round has run end to end on the project's server, and a first real round is open), so expect rough edges before anyone relies on it.")}
<section class="block"><div class="run">{cards}</div></section>
<section class="card"><h2>How these stay honest</h2><ul class="fine"><li>Each claim is recomputed from a certificate that has first been checked: nothing is read off a file that does not verify.</li>
<li>A claim file is not trusted either. <span class="mono">guldo claims check CLAIM.json CERT.json</span> recomputes it and demands the same answer.</li>
<li>Every claim prints what it does not show, every time.</li></ul>
<p class="fine">The guide on this site explains how to check a certificate; the <a href="limits.html">Limits</a> page lists what checking cannot prove.</p></section>"""
    return layout("claims.html", "Other claims - Guldo", "Exact costs, benchmark scores, verified negative results and worst-case figures: what else a certificate can back.", body)


# (limit, what would close it, status). The status is "Open" until the evidence exists (limits_plan.py finds it; RESOLVE.md has the steps) and "Stays" for a property of the method.
LIMIT_PLAN = [
    ("The sandbox that runs other people's code has passed its tests on real Linux machines, but not yet on a dedicated machine that is separate from the web service", "A separate, dedicated-CPU evaluation machine where the sandbox's own tests and self-test pass, and a full timed round evaluated there", "Open"),
    ("No result is official", "An official round: three independent secret numbers, run inside the verified sandbox at the problem's full size", "Open"),
    ("Runs used several jobs at once", "Official runs evaluate one question at a time inside the sandbox", "Open"),
    ("One seed is one sample", "Three or more fresh-seed runs, each registered before its data and judged against its written criteria", "Open"),
    ("The factoring control is not a clean recovery of a known number", "A calibrated pair at the ladder's own sizes, run one job at a time in the sandbox", "Open"),
    ("Differences between computers are not measured", "Re-measurements from two or more different computers", "Open"),
    ("The paper's own code cannot be used as a baseline", "A stronger solver for the baseline (research, not engineering)", "Open"),
    ("The certifiable range is about 1.5 to 3 bits, with a ceiling near 5", "Nothing removes it: it follows from the 0.5 s cost floor and the time limit. Bigger rounds stretch it", "Stays on this page"),
    ("A private solver's timings rest on the operator's sandbox", "Would need trusted hardware or proofs of execution, which are not feasible for solvers that run for minutes", "Stays on this page"),
    ("The baseline decides what counts", "It is a judgement: authors state what beats their baseline and independent baselines help", "Stays on this page"),
]


def page_limits():
    limits = R.LIMITS
    body = f"""
<section class="block"><p class="kicker">Limits</p><h1>What this does not show</h1>
<p class="lede">The most useful part of a verification site is a list of what it has not verified. This page is kept as plain as the results.</p></section>
<section class="card"><h2>What a checked result still does not prove</h2><p class="fine">A certificate can be checked by anyone, and checking it proves the arithmetic and the fairness. It does not, by itself, prove the timings were honest.</p>
<ul class="fine"><li><strong>Proven by checking:</strong> the seeds' fingerprints were public first, the questions are exactly the ones the seeds produce, the rules are the ones named, and the credit follows from the recorded timings.</li>
<li><strong>Not proven by checking:</strong> that the recorded timings are what a real run took. Someone who runs the test could write plausible numbers. What helps: the locked-box environment (its tests have passed on real Linux machines, but no official result has been measured in it yet), and other people re-measuring on their own computers. A re-measurement only counts as independent if you chose to trust whoever made it: a signature shows who signed, not that they are unconnected to the operator.</li>
<li><strong>One way to prove a cost exactly:</strong> instead of seconds, count the Python instructions a solver executes. That number is the same on every computer, so anyone can re-run a few questions and must get identical counts, trusting nobody's machine or clock. It has limits: it is not a time, it cannot see work done inside a built-in C function (which counts as one instruction however long it runs), it needs a recent Python and pure-Python solvers, and, unless a counted round declared the sizes in its first log entry before any submission, the question sizes are chosen by whoever ran it, so it is not an official round result.</li>
<li><strong>The baseline decides what counts:</strong> a speedup is only as meaningful as the solver it beats. A weak baseline makes big speedups cheap. Each problem's author is asked to say what the baseline is and what is known to beat it, and the problem's card shows when they have not.</li>
<li><strong>Computers differ:</strong> a speedup is a ratio, which mostly cancels differences in machine speed, but the spread across different machines has not been measured yet, so the tolerance for re-measurement is deliberately loose.</li>
<li><strong>Private solvers are hidden from the public, not from the operator:</strong> a submitter may keep their solver private, and then the public certificate shows only its fingerprint. Everyone can still verify the log, the questions and the arithmetic, but nobody except the operator can inspect or re-run it, so its timings rest on the operator's sandbox alone. If the owner later publishes the file, anyone can check it against the fingerprint. Hiding a solver from the operator as well would need special hardware or a zero-knowledge proof, and neither is feasible for solvers that run for minutes.</li></ul></section>
<section class="card"><h2>Open limits</h2><ul>{"".join(f"<li>{esc(x)}</li>" for x in limits)}</ul>
<ul><li>Several jobs at once: runs use several processes on one computer at the same time. Re-measuring one job at a time shifted the baseline by -0.050 bits and the tuned solver by -0.084, so the speedup was slightly underestimated, not inflated. The pass line was a shift under 0.10.</li>
<li>That effect depends on the solver. On the factoring control, re-measured one job at a time, the baseline (a plain Python loop) moved by -0.033 bits, but the numpy solver ran 1.16 bits faster than it had with six jobs at once, against a pre-registered limit of 0.10. So that check failed. The bias happened to favour the baseline, which makes the credit cautious, but for another pair of solvers it could point the other way. Runs with several jobs at once are therefore valid only after re-measuring both sides one job at a time, and official runs use one question at a time in the locked box.</li>
<li>The factoring control's known effect (about 4.4 bits) was calibrated on 44 to 52-bit numbers. The 4.2 bits measured at 58 to 64 bits agrees with it partly because the several-jobs bias cancels a real increase with size. It is not a clean recovery of a known number.</li>
<li>One seed is one sample. The pre-registered result is a single test on a fresh seed, not a replication.</li></ul></section>
<section class="card"><h2>What would close each limit</h2><p class="fine">Some limits can be closed with more work, and this table says what that work is. Others are properties of the method and will stay on this page.</p>
<div class="scroll"><table class="lb"><thead><tr><th>Limit</th><th>What would close it</th><th>Status</th></tr></thead><tbody>{"".join(f'<tr><td>{esc(a)}</td><td class="fine">{esc(b)}</td><td><strong>{esc(c)}</strong></td></tr>' for a, b, c in LIMIT_PLAN)}</tbody></table></div></section>
<section class="block"><h2>Related work</h2><p class="fine">Public challenges already exist in this area. The <a href="https://www.latticechallenge.org/svp-challenge/index.php" rel="noopener">Darmstadt SVP challenge</a> and its LWE counterpart publish instances and record solutions. <a href="https://www.bankless.com/read/news/eigen-labs-launches-yukon-for-open-ai-research" rel="noopener">Yukon</a>, from Eigen Labs, is an open platform where people and AI agents compete on posted technical challenges. This project is about checking claims: seeds committed before the questions exist, a public log, and certificates anyone can recompute.</p></section>"""
    return layout("limits.html", "Limits - Guldo", "What this does not show: open limits of the protocol and its results.", body)


# ---------------------------------------------------------------- build
def build(out, results_dir, reveals, notes=None, ledger_data=None, portal_url="", certs_dir=None, cname=None):
    data = collect(results_dir)
    board = []
    if os.path.exists(judge.BOARD):
        with open(judge.BOARD, encoding="utf-8") as f:
            board = json.load(f)
    prereg = read_prereg(results_dir)
    seeds = load_reveals(reveals, prereg)
    for what, src in (("--certs", certs_dir), ("the results directory", results_dir), ("--ledger-data", ledger_data)):
        if src:  # the build deletes and recreates `out`: an input that lives inside it would be destroyed first
            s, o = os.path.realpath(src), os.path.realpath(out)
            if s == o or s.startswith(o + os.sep):
                raise SystemExit(f"REFUSED: {what} ({src}) is inside the output directory {out}, which this build deletes and recreates. Keep inputs outside it.")
    if os.path.exists(out):
        # never delete a directory this script did not create: --out ~ or --out . must not be able to wipe anything
        if not (os.path.isdir(out) and os.path.exists(os.path.join(out, MARKER))):
            if os.path.isdir(out) and not os.listdir(out):
                pass  # an empty directory is safe to reuse
            else:
                raise SystemExit(f"REFUSED: {out} exists and is not a site this script built (no {MARKER} marker); "
                                 "choose a new directory or remove it yourself")
        else:
            shutil.rmtree(out)
    os.makedirs(os.path.join(out, "assets"), exist_ok=True)
    os.makedirs(os.path.join(out, "prereg"), exist_ok=True)
    os.makedirs(os.path.join(out, "data"), exist_ok=True)
    with open(os.path.join(out, MARKER), "w", encoding="utf-8") as f:
        f.write("built by build_site.py; this directory may be deleted and rebuilt by it\n")
    if cname:   # for a static host that serves this folder under a custom domain (GitHub Pages reads CNAME; .nojekyll stops it processing the files)
        if not re.fullmatch(r"[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+", cname):
            raise SystemExit(f"REFUSED: --cname {cname!r} is not a plain domain name like example.org")
        with open(os.path.join(out, "CNAME"), "w", encoding="utf-8") as f:
            f.write(cname + "\n")
        with open(os.path.join(out, ".nojekyll"), "w", encoding="utf-8") as f:
            f.write("")
    rounds_index, sandbox_ok = None, False
    if ledger_data:  # the public competition's rounds, exported (tokens and unrevealed sources are never in the export)
        import portal_core
        import rounds
        rounds_index = rounds.export_public(ledger_data, os.path.join(out, "ledger"))
        sandbox_ok = portal_core.sandbox_verified(os.path.abspath(ledger_data))
    with open(os.path.join(out, "assets", "site.css"), "w", encoding="utf-8") as f:
        f.write(site_assets.CSS + EXTRA_CSS)
    with open(os.path.join(out, "assets", "site.js"), "w", encoding="utf-8") as f:
        f.write(site_assets.JS)
    for p in prereg:
        with open(os.path.join(out, "prereg", p["file"]), "w", encoding="utf-8") as f:
            f.write(p["text"])
    import dlog_experiment
    import certs_site
    certs_site.copy_files(certs_dir, out)
    exp_reg = os.path.join(results_dir, dlog_experiment.PREREG)
    if os.path.exists(exp_reg):  # not in `prereg` (its commitments are on separate lines), but the card links it
        shutil.copy(exp_reg, os.path.join(out, "prereg", dlog_experiment.PREREG))
    for s, d in data:
        if "error" not in d:
            for path in (s["baseline"], s["submission"]):
                shutil.copy(path, os.path.join(out, "data", os.path.basename(path)))
    zip_name, zip_sha, zip_size = package_zip(out)   # the installable tool, built from this same checkout and shipped with the site
    pages = {"index.html": page_index(data, board, prereg, notes), "install.html": page_install(zip_name, zip_sha, zip_size), "domains.html": page_domains(), "guide.html": page_guide(), "method.html": page_method(), "results.html": page_results(data, board, prereg, notes, results_dir, certs_dir),
             "preregistrations.html": page_prereg(prereg, seeds), "compete.html": page_compete(rounds_index, portal_url, sandbox_ok), "claims.html": page_claims(), "limits.html": page_limits()}
    for fn, text in pages.items():
        with open(os.path.join(out, fn), "w", encoding="utf-8") as f:
            f.write(text)
    return sorted(pages), len(data), sum(1 for _, d in data if "error" in d)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(HERE, "site"))
    ap.add_argument("--reveal", action="append", metavar="TAG=SEEDFILE", help="ship a revealed seed (checked against its commitment)")
    ap.add_argument("--note", action="append", metavar="TAG=TEXT",
                    help="one-line concurrency re-measurement summary shown on that registration's card (TAG = first 8 hex of its commitment)")
    ap.add_argument("--ledger-data", help="the public competition's data directory (ops.py --data): adds its rounds to the Compete page")
    ap.add_argument("--portal-url", default="", help="public URL of the submission service (public_portal.py), linked from the Compete page")
    ap.add_argument("--certs", help="a directory of NAME.cert.json, NAME.*.att.json and trusted.txt: each certificate is re-verified and shown on the Results page")
    ap.add_argument("--cname", help="a custom domain for a static host (writes CNAME and .nojekyll into the site), e.g. guldo.org")
    a = ap.parse_args()
    notes = dict(n.partition("=")[::2] for n in a.note or [])
    pages, n, bad = build(a.out, os.path.join(HERE, "results"), a.reveal, notes, a.ledger_data, a.portal_url, a.certs, a.cname)
    print(f"wrote {len(pages)} pages to {a.out} ({n} ladder pair(s), {bad} not chartable)")


if __name__ == "__main__":
    main()
