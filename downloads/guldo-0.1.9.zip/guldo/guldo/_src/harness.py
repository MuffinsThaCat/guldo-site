"""Run a solver over a size ladder on derived instances of any registered domain (families.py); verify every answer; log CPU.

Cost = user+sys CPU seconds of the solver process tree: that child's own wait4 rusage (bare local mode) or the root meter's
RUSAGE_CHILDREN (Docker), minus the cost of a no-op solver (interpreter + import overhead). The solver receives only
solve(*instance["args"]) - for lattices (basis, bound2), for factoring (N,) - never the master seed or the planted witness.
With --jobs K, K instances run concurrently (local mode only; see drift_check.py / remeasure.py for the measured bias).
"""
import argparse
import hashlib
import json
import os
import platform
import resource
import select
import signal
import statistics
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

import families
import instances

HERE = os.path.dirname(os.path.abspath(__file__))
NOOP = os.path.join(HERE, "solvers", "noop.py")


TAIL_LIMIT = {"out": 4 << 20, "err": 64 << 10}  # bytes kept per stream in local mode (the docker meter keeps its last 4 MB too)


def backstop(budget):
    """Wall-clock limit for a local run: the backstop for a solver that ignores SIGXCPU (macOS) or just sleeps."""
    return budget * 1.5 + 10


def max_safe_jobs():
    """Largest --jobs that keeps every worker on a performance core with two cores to spare. Counting efficiency cores
    would let workers land on slower cores and bias timings; validated range is 4-8 jobs on a 10-P-core machine."""
    n = os.cpu_count() or 1
    if sys.platform == "darwin":
        try:
            perf = int(subprocess.run(["sysctl", "-n", "hw.perflevel0.logicalcpu"], capture_output=True, text=True,
                                      timeout=10).stdout.strip())
            n = min(n, perf)
        except (ValueError, OSError, subprocess.TimeoutExpired):
            pass
    return max(1, n - 2)


def _exec_local(solver, payload, budget):
    """Bare local process. CPU is that child's OWN rusage from wait4 (user+sys, including descendants it waited for), not
    a process-wide delta, so several instances can run concurrently without corrupting each other's timings."""
    env = {"PATH": os.environ.get("PATH", ""), "PYTHONHASHSEED": "0", "OMP_NUM_THREADS": "1",
           "SVP_CPU_LIMIT": str(int(budget) + 1)}  # applied by runner.py; no preexec_fn (unsafe with threads)
    bufs = {}
    stop = threading.Event()
    with tempfile.TemporaryDirectory() as cwd:
        # own session: leftover orphans (they share the child's process group) can be killed when the child is done
        p = subprocess.Popen([sys.executable, os.path.join(HERE, "runner.py"), solver],
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             cwd=cwd, env=env, start_new_session=True)

        def feed():
            try:
                p.stdin.write(payload.encode())
            except OSError:
                pass
            finally:
                try:
                    p.stdin.close()
                except OSError:
                    pass

        def drain(name, stream):
            """Non-blocking, stoppable reader. A blocking read() would sit forever if an orphan holds the pipe open, and
            closing the stream from another thread then blocks on its lock (a sleeping orphan used to hang the harness)."""
            fd = stream.fileno()
            os.set_blocking(fd, False)
            limit = TAIL_LIMIT[name]
            buf = bytearray()  # only the TAIL is kept: the answer is the last stdout line and only the end of stderr is reported
            while True:
                ready, _, _ = select.select([fd], [], [], 0.2)
                if ready:
                    try:
                        data = os.read(fd, 1 << 16)
                    except BlockingIOError:
                        continue
                    except OSError:
                        break
                    if not data:  # EOF: every writer closed
                        break
                    buf += data
                    if len(buf) > 2 * limit:  # a solver that prints without end must not grow the harness's memory without bound
                        del buf[:len(buf) - limit]
                elif stop.is_set():
                    break
            bufs[name] = bytes(buf[-limit:])

        threads = [threading.Thread(target=feed, daemon=True),
                   threading.Thread(target=drain, args=("out", p.stdout), daemon=True),
                   threading.Thread(target=drain, args=("err", p.stderr), daemon=True)]
        for t in threads:
            t.start()

        def kill():
            try:
                p.kill()
            except OSError:
                pass

        # Wall backstop for a solver that ignores SIGXCPU (macOS does not SIGKILL at the hard limit; Linux does). CPU-bound
        # solvers have wall ~ CPU as long as jobs <= cores (main() refuses oversubscription), so 1.5x + 10 s is generous.
        timer = threading.Timer(backstop(budget), kill)
        timer.start()
        try:
            _, status, ru = os.wait4(p.pid, 0)
        finally:
            timer.cancel()
        grace = time.time() + 2.0  # normally the readers see EOF at once; an orphan still writing gets 2 s
        for t in threads[1:]:
            t.join(timeout=max(grace - time.time(), 0))
        try:
            os.killpg(p.pid, signal.SIGKILL)  # orphans left in the child's session (bare local mode cannot bill them)
        except OSError:
            pass
        stop.set()
        for t in threads:
            t.join(timeout=5)
        for stream in (p.stdin, p.stdout, p.stderr):  # we manage the pipes ourselves: close them, or each run leaks 3 fds
            try:
                stream.close()
            except OSError:
                pass
    rc = -os.WTERMSIG(status) if os.WIFSIGNALED(status) else os.WEXITSTATUS(status)
    p.returncode = rc
    return (rc, bufs.get("out", b"").decode(errors="replace"), bufs.get("err", b"").decode(errors="replace"),
            ru.ru_utime + ru.ru_stime)


DOCKER_SLACK = 60  # seconds beyond the meter's own wall deadline before the host gives up on `docker run`


def cpu_brand():
    """Human-readable CPU model, so ladders run on different machines can be refused."""
    try:
        if sys.platform == "darwin":
            return subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True,
                                  timeout=10).stdout.strip() or "unknown"
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    return line.split(":", 1)[1].strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    return platform.processor() or "unknown"


def image_id(image="svp-solver"):
    try:
        r = subprocess.run(["docker", "image", "inspect", "--format", "{{.Id}}", image], capture_output=True,
                           text=True, timeout=30)
        return r.stdout.strip() if r.returncode == 0 else "unknown"
    except (OSError, subprocess.TimeoutExpired):
        return "unknown"


def _exec_docker(solver, payload, budget, image="svp-solver"):
    """Run in the hardened container; CPU is metered inside it by sandbox/meter.py (see sandbox/README.md).
    UNTESTED against a real Docker daemon since the meter rewrite; the control flow is tested with a fake `docker`."""
    name = "svp-" + uuid.uuid4().hex[:12]
    cmd = ["docker", "run", "--rm", "-i", "--name", name, "--network", "none", "--read-only", "--tmpfs", "/tmp",
           "--cpus", "1", "--memory", "4g", "--pids-limit", "64", "--cap-drop", "ALL", "--cap-add", "SETUID",
           "--cap-add", "SETGID", "--cap-add", "KILL", "--security-opt", "no-new-privileges", "-e", f"BUDGET={budget}",
           "-v", f"{solver}:/work/submission.py:ro", image, "/work/submission.py"]
    try:
        r = subprocess.run(cmd, input=payload.encode(), capture_output=True, timeout=budget * 3 + DOCKER_SLACK)
    except subprocess.TimeoutExpired:
        # subprocess.run kills only the docker CLI; the container would keep burning CPU and skew later timings
        subprocess.run(["docker", "kill", name], capture_output=True)
        subprocess.run(["docker", "rm", "-f", name], capture_output=True)
        return -signal.SIGKILL, "", "docker timeout", budget * 3
    try:
        m = json.loads(r.stdout.decode().strip().splitlines()[-1])
    except Exception:
        return r.returncode or 1, "", "meter produced no result: " + r.stderr.decode(errors="replace")[-300:], 0.0
    return (-signal.SIGXCPU if m.get("overrun") else m["rc"]), m["out"], m["err"], m["cpu"]


def run_one(solver, inst, budget, sandbox=None):
    payload = json.dumps({"args": inst["args"]})  # domain-neutral: the solver is called as solve(*args)
    t0 = time.time()
    rc, out, err, cpu = (_exec_docker if sandbox == "docker" else _exec_local)(solver, payload, budget)
    rec = {"id": inst["id"], "dim": inst["dim"], "cpu": cpu, "wall": time.time() - t0}
    if rc == -signal.SIGXCPU or cpu > budget or (sandbox != "docker" and rc == -signal.SIGKILL and rec["wall"] >= backstop(budget) - 1):
        rec["status"] = "timeout"  # CPU cap, CPU over budget, or killed by the wall backstop (e.g. a solver that only sleeps)
    elif rc != 0:
        rec["status"] = "crash"
        rec["err"] = err[-1500:]
    elif not out.strip():
        # exit status 0 but nothing on the answer channel: the runner never reached its write (e.g. os._exit(0) inside solve).
        # That is not a wrong answer, and it must not look like one on the board.
        rec["status"] = "crash"
        rec["err"] = "solver exited 0 without writing an answer (no answer line)"
    else:
        try:
            ans = json.loads(out.strip().splitlines()[-1])  # the answer is the LAST line; anything earlier is noise
            ok = families.verify(inst, ans)
        except Exception:
            ans, ok = 0, False
        rec["status"] = "solved" if ok else ("failed" if ans is None else "wrong")
    return rec


def calibrate(sandbox=None, reps=7):
    inst = families.derive("gm", instances.PRACTICE_SEED, 10, 0)
    return statistics.median(run_one(NOOP, inst, 30, sandbox)["cpu"] for _ in range(reps))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--solver", required=True)
    ap.add_argument("--dims", type=int, nargs="+", required=True)
    ap.add_argument("--n", type=int, default=5, help="instances per dimension")
    ap.add_argument("--budget", type=float, default=60, help="CPU-second cap per instance")
    ap.add_argument("--seed-file", help="file holding the master seed bytes (default: public practice seed)")
    ap.add_argument("--family", default="gm", choices=sorted(families.FAMILIES))
    ap.add_argument("--sandbox", choices=["docker"], help="run each instance in the hardened container")
    ap.add_argument("--jobs", type=int, default=1, help="instances run concurrently (local mode only). Timings stay "
                    "valid only while the machine is not oversubscribed; validate with `drift_check.py` first")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    if a.jobs > 1 and a.sandbox:
        raise SystemExit("REFUSED: --jobs > 1 is local-mode only (concurrent sandbox runs are untested)")
    if a.jobs > max_safe_jobs():
        raise SystemExit(f"REFUSED: --jobs {a.jobs} exceeds the safe maximum {max_safe_jobs()} for this machine (performance "
                         "cores minus 2): contention or efficiency cores would distort timings, and the wall backstop "
                         "assumes wall time ~ CPU time")
    a.solver = os.path.abspath(a.solver)
    with open(a.solver, "rb") as f:
        solver_sha = hashlib.sha256(f.read()).hexdigest()  # recorded so seeds scored with different code are never combined
    master = open(a.seed_file, "rb").read().strip() if a.seed_file else instances.PRACTICE_SEED
    if not a.sandbox:
        print("WARNING: local mode is NOT safe for untrusted solvers (can read the seed, can orphan processes to hide "
              "CPU). Use --sandbox docker for anything you did not write.", file=sys.stderr, flush=True)
    overhead = calibrate(a.sandbox)
    print(f"family={a.family} sandbox={a.sandbox} commitment sha256={instances.commit(master)}  overhead={overhead:.3f}s", flush=True)
    with open(a.out, "w") as f:
        f.write(json.dumps({"meta": True, "solver": os.path.basename(a.solver), "commit": instances.commit(master),
                            "overhead": overhead, "budget": a.budget, "family": a.family, "sandbox": a.sandbox,
                            "instance_version": families.VERSIONS[a.family],
                            "image": image_id() if a.sandbox == "docker" else None,
                            "host": platform.platform() + " / " + platform.processor(),
                            "cpu": cpu_brand(), "ncpu": os.cpu_count(), "jobs": a.jobs, "solver_sha256": solver_sha}) + "\n")
        def work(task):
            dim, idx = task
            rec = run_one(a.solver, families.derive(a.family, master, dim, idx), a.budget, a.sandbox)
            rec["cpu_net"] = max(rec["cpu"] - overhead, 1e-3)
            return rec

        tasks = [(dim, idx) for dim in a.dims for idx in range(a.n)]
        with ThreadPoolExecutor(max_workers=max(a.jobs, 1)) as ex:
            for rec in ex.map(work, tasks):  # results come back in task order, so the file is deterministic
                f.write(json.dumps(rec) + "\n")
                f.flush()
                print(f'{a.solver.split("/")[-1]:22s} {rec["id"]:>7s} {rec["status"]:8s} {rec["cpu_net"]:8.2f}s', flush=True)


if __name__ == "__main__":
    main()
