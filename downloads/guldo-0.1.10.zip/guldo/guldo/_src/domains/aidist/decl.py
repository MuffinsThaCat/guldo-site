"""Declaration of a DISTRIBUTED-training domain: the exact gradient of a two-layer network over a batch, on a cluster of 8 devices, with as little TIME as the machine allows.

size = d. A network with input d, hidden h = 4 d (ReLU) and output c = 8, on a batch of B = 8 d vectors; squared loss  L = 0.5 * mean over the B*c entries of (relu(x W1^T) W2 - Y)^2.
x (B x d), W1T (h x d, scaled by sqrt(3/d)), W2 (h x c, scaled by sqrt(3/h)) and Y (B x c) are the SplitMix64 stream under `seed` (tensorops.stream, the same floats as domains/aiinfer), in that order, row-major.
The answer is the gradient [dL/dW1T (h x d) , dL/dW2 (h x c)] as ONE flat list of h*d + h*c INTEGERS in units of 2^-40, and the judge accepts it within 1e-6 of its norm. A gradient that was not
summed over the whole batch, a stale or partial reduction, or a shard missing from the gather fails the check.

Where the time goes. One device does all the arithmetic. Eight devices can split it, and then must COMMUNICATE: data parallelism gives each device B/8 of the batch and sums the gradients with an all-reduce (the whole
parameter gradient crosses the network, whatever the batch); tensor parallelism gives each device h/8 of the hidden units and all-reduces only the B x c output (and, because the answer must be assembled, gathers the
gradient shards). Which is faster depends on the machine: a network with high latency punishes many messages, one with low bandwidth punishes many bytes, a fast one makes either worth it.

The cost compared is the one of tflops_dist.py (tensorops_dist.py defines the machine): per run, the critical-path WORK (the busiest device between barriers), the message ROUNDS and the BYTES per device, from which
the run's time on ANY interconnect, T(alpha, beta) = wcrit + steps + alpha * rounds + beta * bytes, is exact; two solvers are compared on every machine at once and the crossover is computed, not measured. It is an accounting convention over
identical devices and links (ring and tree collectives, a barrier at every collective, no overlap, no congestion): not a measurement of any cluster.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aidist"
VERSION = "aidist-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 48)
SIZE_STEP = 8
REFERENCE_SOLVER = "reference.py"
RANKS = 8                     # devices the instance has
C = 8                         # output width
SCALE = 2 ** 40
LIMIT = 2 ** 62
REL_TOL = 1e-6
DOC = ("solve(seed, d, B, P): x (B x d), W1T (h x d, h = 4d, times sqrt(3/d)), W2 (h x 8, times sqrt(3/h)) and Y (B x 8) are the SplitMix64 stream under `seed` (tensorops.stream, u in [-1, 1), row-major, in that order; "
       "B = 8d); loss = 0.5 * mean over the B*8 entries of (relu(x W1T^T) W2 - Y)^2. P = 8 devices are available (tp.use(k), tp.all_reduce, tp.reduce_scatter, tp.all_gather, tp.broadcast). Return the gradient "
       "[dL/dW1T (h x d row-major), dL/dW2 (h x 8 row-major)] as one flat list of h*d + h*8 integers in units of 2^-40, within 1e-6 of its norm. Return None for no answer.")
REFERENCE_NOTE = ("One device does everything: no communication, all the arithmetic on device 0. Known to be beaten, on a machine whose network is fast enough relative to its compute, by data parallelism (each device "
                  "takes a slice of the batch, one all-reduce of the gradient) and by tensor parallelism (each device takes a slice of the hidden units, an all-reduce of the output and a gather of the shards).")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def parts(seed, d):
    B, h = 8 * d, 4 * d
    x = _uniform(seed, 0, B * d).reshape(B, d)
    W1T = _uniform(seed, B * d, h * d).reshape(h, d) * math.sqrt(3.0 / d)
    W2 = _uniform(seed, B * d + h * d, h * C).reshape(h, C) * math.sqrt(3.0 / h)
    Y = _uniform(seed, B * d + h * d + h * C, B * C).reshape(B, C)
    return x, W1T, W2, Y


def gradient(seed, d):
    x, W1T, W2, Y = parts(seed, d)
    B = len(x)
    a = x @ W1T.T
    h1 = np.maximum(a, 0.0)
    dy = (h1 @ W2 - Y) / (B * C)
    dW2 = h1.T @ dy
    dh = (dy @ W2.T) * (a > 0)
    dW1T = dh.T @ x
    return np.concatenate([dW1T.ravel(), dW2.ravel()])


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aidist-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    return {"args": [seed, size, 8 * size, RANKS], "planted": [int(v) for v in np.rint(gradient(seed, size) * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, d, B, P = inst["args"]
    n = 4 * d * d + 4 * d * C
    if not isinstance(ans, list) or len(ans) != n:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    true = gradient(seed, d)
    got = np.array(ans, dtype=np.float64) / SCALE
    return bool(np.linalg.norm(got - true) <= REL_TOL * np.linalg.norm(true) + n * 2.0 ** -40)
