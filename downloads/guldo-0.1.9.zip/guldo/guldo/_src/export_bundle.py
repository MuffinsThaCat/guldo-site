"""Export a compiled domain as a platform-neutral CHALLENGE BUNDLE: everything another leaderboard needs to host the challenge and to say how
much of a measured speedup is real, with no copy of this repository.

    python3 export_bundle.py export NAME [--out DIR] [--field FIELD] [--no-selftest]    (also: compile_domain.py export NAME)
    python3 export_bundle.py verify DIR [--selftest]                                    re-check a bundle's hashes (and run its self-test)

A bundle holds the declaration (derive/verify), the reference solver, the compiled ladder and power analysis, a standalone checker
(`checker/check.py`: derive instances, verify answers, self-test), a standalone scorer (`checker/score.py`: the protocol's difficulty-stratified
credit, and a head-to-head `compare` of two solvers), a byte copy of the estimator, a manifest of every file's sha256, a README, and the
intake text a platform like Yukon asks a proposer for (PROPOSAL.md). Export refuses a stale compile, and refuses to emit a bundle that fails
its own self-test in a clean interpreter (`python3 -I`, empty directory): a bundle that only works inside this checkout is not a bundle.

Export executes the declaration and the reference solver (the self-test does), unsandboxed, like `compile`: export only declarations you
have read. It never overwrites an existing directory.
"""
import argparse
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

import declared

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATES = os.path.join(HERE, "bundle_templates")
FORMAT = "guldo-challenge-bundle-v1"
RESERVED = {"decl", "reference", "estimator", "check", "score", "challenge", "quality_core", "qcheck", "qscore"}   # module names the bundle itself uses
MAX_VENDORED = 12
SELFTEST_TIMEOUT = 900
STD = set(sys.stdlib_module_names)


class ExportError(Exception):
    """Nothing was written; the message says what to fix."""


def sha256_file(path):
    return declared.sha256_file(path)


def imports_of(path):
    with open(path, encoding="utf-8") as f:
        tree = ast.parse(f.read(), path)
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                raise ExportError(f"{os.path.basename(path)} uses a relative import; a bundle cannot resolve it")
            if node.module:
                names.add(node.module.split(".")[0])
    return names


def resolve_imports(entry, search_dirs, seen=None, vendored=None, third=None):
    """Walk the imports of the declaration. A module that lives beside it or in the project is VENDORED (copied byte for byte); anything
    else that is not standard library is a third-party requirement the bundle names but cannot ship. Imports made through importlib with a
    string are invisible here: the clean-interpreter self-test is what catches those."""
    seen = set() if seen is None else seen
    vendored = {} if vendored is None else vendored
    third = set() if third is None else third
    for name in sorted(imports_of(entry)):
        if name in STD or name in seen:
            continue
        seen.add(name)
        src = next((os.path.join(d, name + ".py") for d in search_dirs if os.path.isfile(os.path.join(d, name + ".py"))), None)
        if src is None:
            third.add(name)
            continue
        if name in RESERVED:
            raise ExportError(f"the declaration imports a module called {name!r}, which the bundle uses for itself; rename it")
        vendored[name] = src
        if len(vendored) > MAX_VENDORED:
            raise ExportError(f"the declaration pulls in more than {MAX_VENDORED} project modules ({sorted(vendored)}...): it is not portable as written")
        resolve_imports(src, search_dirs, seen, vendored, third)
    return vendored, third


PROBE = r'''
import importlib.util, json, os, sys
d, here, sizes = sys.argv[1], sys.argv[2], [int(x) for x in sys.argv[3:]]
opened = set()
def hook(event, args):
    if event == "open" and args and isinstance(args[0], (str, bytes, os.PathLike)):
        opened.add(os.fsdecode(args[0]))
sys.addaudithook(hook)
sys.path[:0] = [d, here]
spec = importlib.util.spec_from_file_location("probe_decl", os.path.join(d, "decl.py"))
decl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(decl)
for size in sizes:
    for idx in range(3):
        inst = dict(decl.derive(b"practice-seed-public", size, idx))
        for ans in [decl.witness(inst) if hasattr(decl, "witness") else inst["planted"], None, 0, [], "x"]:
            try:
                decl.verify(inst, ans)
            except Exception:
                pass
rd, rh = os.path.realpath(d), os.path.realpath(here)
found, data, foreign = {}, set(), set()
for name, mod in list(sys.modules.items()):
    f = getattr(mod, "__file__", None)
    if f and "." not in name and name != "probe_decl":
        rp = os.path.realpath(f)
        if rp == os.path.join(rd, name + ".py") or rp == os.path.join(rh, name + ".py"):
            found[name] = rp
for p in opened:
    if not os.path.isabs(p):
        continue
    rp = os.path.realpath(p)
    if not os.path.isfile(rp) or rp.endswith((".py", ".pyc")) or "__pycache__" in rp:
        continue
    if rp.startswith(rd + os.sep):
        data.add(os.path.relpath(rp, rd))
    elif rp.startswith(rh + os.sep):
        foreign.add(rp)
print(json.dumps({"modules": found, "data": sorted(data), "foreign": sorted(foreign)}))
'''


def probe_imports(domain_dir, sizes):
    """Run the declaration (import, then derive and verify several practice instances at every practice size, the witness and a few junk answers) and
    report what it ACTUALLY touched: project or sibling modules it loaded (importlib.import_module("x"), __import__, imports inside functions that
    run), and data files it opened (an audit hook sees every open()). The static import walk cannot see either. What this still misses: a code path
    none of those calls takes. The clean-interpreter self-test is the backstop."""
    with tempfile.TemporaryDirectory() as empty:
        try:
            r = subprocess.run([sys.executable, "-B", "-c", PROBE, domain_dir, HERE] + [str(s) for s in sizes], cwd=empty, capture_output=True, text=True,
                               timeout=SELFTEST_TIMEOUT)
        except subprocess.TimeoutExpired:
            raise ExportError("the declaration did not finish deriving its practice instances while probing it")
    if r.returncode != 0:
        tail = "\n".join(r.stderr.strip().splitlines()[-8:])
        hint = ("\n(a data file must be opened by a path relative to the declaration itself, e.g. os.path.join(os.path.dirname(__file__), 'x.json'), "
                "not relative to the working directory)" if "FileNotFoundError" in tail else "")
        raise ExportError("the declaration failed while probing it:\n" + tail + hint)
    return json.loads(r.stdout.strip().splitlines()[-1])


def simulation_block(compiled):
    """What `score.py` needs to re-run the power simulation at a different noise or threshold: the compiled profile."""
    plan = compiled.get("plan") or {}
    try:
        return {"cap": plan["cap"], "sizes": [int(s) for s in plan["sizes"]], "median_log2": {str(k): v for k, v in plan["median_log2"].items()}, "sigma": plan["sigma"]}
    except (KeyError, TypeError, ValueError, AttributeError):
        return None


def read_template(name):
    with open(os.path.join(TEMPLATES, name), "rb") as f:
        return f.read()


def write_bytes(path, data, mode=0o644):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)
    os.chmod(path, mode)


def copy_exact(src, dst):
    with open(src, "rb") as f:
        write_bytes(dst, f.read())


def power_block(compiled):
    cp = compiled.get("power") or {}
    return {
        "threshold_bits": cp.get("threshold", 1.0),
        "target_power": cp.get("target_power", 0.8),
        "target_effect_bits": cp.get("target_effect"),
        "pair_noise_bits": cp.get("pair_noise"),
        "min_certifiable_bits": cp.get("min_certifiable_effect"),
        "max_certifiable_bits": cp.get("max_certifiable_effect"),
        "curve": {str(e): {"single": v["single"], "all_seeds": v["all_three"], "inconclusive": v.get("inconclusive")}
                  for e, v in (cp.get("curve") or {}).items()},
        "notes": list(cp.get("notes") or []),
    }


def status_of(compiled, power):
    reasons = []
    st = (compiled.get("selftest") or {}).get("status", "pending")
    if st != "pass":
        reasons.append(f"the compiler's own self-test is {st!r}, not 'pass'")
    if power["min_certifiable_bits"] is None:
        reasons.append("the power analysis found no speedup this ladder can certify")
    if not compiled.get("reference_note"):
        reasons.append("the declaration states no REFERENCE_NOTE: nobody can tell how strong the baseline is")
    if not compiled.get("plan", {}).get("confirmed", True):
        reasons.append("the ladder's predicted costs were not confirmed by measurement")
    return ("READY" if not reasons else "DRAFT"), reasons


def table(power):
    rows = ["| true speedup (bits) | P(one seed credited) | P(all seeds credited) |", "|---|---|---|"]
    rows += [f"| {e} | {100 * v['single']:.0f}% | {100 * v['all_seeds']:.0f}% |" for e, v in power["curve"].items()]
    return "\n".join(rows)


def readme(ch):
    pw, lad, name = ch["power"], ch["ladder"], ch["name"]
    rng = (f"from about {pw['min_certifiable_bits']} to about {pw['max_certifiable_bits']} bits" if pw["min_certifiable_bits"] is not None
           else "NONE: this challenge is too weak to certify anything")
    reasons = "".join(f"\n* {r}" for r in ch["status_reasons"])
    return f"""# {name} ({ch['version']}): challenge bundle, status {ch['status']}
{('The bundle is a DRAFT because:' + reasons) if reasons else ''}

{ch['problem']['doc']}

* solver: {ch['solver_contract']}
* sizes {lad['dims']}; {lad['n']} instances per size; CPU cap {lad['budget_seconds']} s per instance; credit needs {ch['protocol']['seeds_required']} committed seeds
* reference: {ch['reference']['note'] or 'NOT STATED by the declaration author'}
* this ladder can certify speedups {rng} (simulated through the real estimator; assumed per-instance pair noise {pw['pair_noise_bits']} bit)

{table(pw)}

## What is in here

| path | what |
|---|---|
| `challenge.json` | the manifest: problem, ladder, protocol, power, provenance, requirements, and the sha256 of every pinned file |
| `checker/decl.py`, `checker/reference.py` | the declaration (instances are a pure function of seed, size, index; `verify` is exact) and the baseline, byte-for-byte what was compiled |
| `checker/check.py` | `info`, `selftest`, `commit`, `derive`, `verify`, `rerun` (sandboxed re-measurement of a claimed result; `--repeat`, `--save`), `spread` (merge several machines' saved measurements into a tolerance), `keygen`, `attest-check`, `log append|verify|checkpoint`: the operator's instance generator and answer checker, a verifier's tools, and signed attestations. `selftest`, `derive` and `verify` run sandboxed by default. Standard library only. `selftest` tests the verifier on a fresh random seed (printed), including answers derived from the instance itself and random answers of the witness's shape |
| `checker/score.py` | `score` (one solver against the reference), `compare` (is solver A really faster than solver B?), `power` (re-simulable), `recheck`. Needs numpy |
| `checker/estimator.py` | byte copy of the protocol's estimator (`extrapolate.py`); its hash is in the manifest |
| `checker/vendor/` | project modules the declaration imports, copied byte-for-byte (empty if none) |
| `compiled.json` | the compiler's full record, for audit |
| `MANIFEST.sha256` | `sha256sum -c MANIFEST.sha256` (macOS: `shasum -a 256 -c MANIFEST.sha256`), run in this directory |
| `PROPOSAL.md` | the text a platform's proposal form asks for, pre-filled from this record |

## Before you run anything here

`checker/check.py derive|verify|selftest` import and run `checker/decl.py`, and `selftest` runs `checker/reference.py`. That is the author's code, and the manifest
hashes prove only that the files are the ones listed, not that they are safe. All three therefore re-run themselves INSIDE an OS sandbox by default (macOS
`sandbox-exec`, tested; Linux `bwrap`, tested on one real machine (Ubuntu 26.04, kernel 7.0, bubblewrap 0.11.1, as root: an attack probe and 63 unit tests passed). On Linux it
gives no network for any process, a read-only root, a writable scratch directory and masked credential directories, but does NOT restrict which programs may run. Ubuntu
restricts unprivileged user namespaces (AppArmor), so bwrap may be unusable for a normal user unless installed from the distribution package, which carries the exemption;
the tools say so when that happens): no network, no writes outside a scratch directory, no running any program except the Python interpreter,
`~/.ssh`, `~/.aws`, `~/.gnupg` and the keychain unreadable. Where there is no sandbox they warn and run as you; `export_bundle.py verify --selftest` instead refuses unless you pass `--unsandboxed`. A sandbox stops
the practical damage, not a determined attacker with a kernel exploit, and your own `--sandbox off` runs are as you. `check.py rerun` sandboxes a COMPETITOR's solver the same
way. (`score.py` runs nothing from the ladders it reads.) Export runs its own self-test sandboxed too, so a declaration that secretly needs to write a file or reach the
network fails at export, not for the next person. Cost: the sandbox adds about 75 ms to each call (measured on `verify`: 57 ms unsandboxed, 130 ms sandboxed), which is
nothing for a few hundred verifications per submission; for bulk verification of a bundle you have read, pass `--sandbox off` or run the whole batch inside your own VM.

## Hosting it on a board

A board needs three things from its own side; the bundle supplies the rest.

1. **Seeds.** Pick at least {ch['protocol']['seeds_required']} secret seeds, publish `python3 checker/check.py commit --seed-file S` for each BEFORE the deadline, reveal after. Instances are
   `python3 checker/check.py derive --seed-file S --size N --idx I`; nothing can be precomputed.
2. **A meter.** Run each submission once per instance, one at a time on one core, charge failures the cap, and write a ladder file: a first line
   `{{"meta": true, "commit": "<the seed's sha256>", "budget": {lad['budget_seconds']}}}`, then one line per instance, ids `SIZE:0` .. `SIZE:{lad['n'] - 1}` for every size:
   `{{"id": "28:0", "dim": 28, "status": "solved", "cost": 3.41}}` (cost > 0; statuses solved, timeout, crash, failed, wrong). Do the same for the reference
   (`checker/reference.py`). Answers are checked with `python3 checker/check.py verify --seed-file S --size N --idx I --answer @answer.json`.
3. **A scorer run.** `python3 checker/score.py score --pair REF_SEED1.jsonl SUB_SEED1.jsonl --pair ... --pair ... --out result.json` prints the credit and writes JSON.
   `python3 checker/score.py compare --a A1 A2 A3 --b B1 B2 B3` answers "is #1 really ahead of #2, or is that noise?". Anyone can then run
   `python3 checker/score.py recheck result.json`, and a verifier with the revealed seed can run
   `python3 checker/check.py rerun --seed-file S --solver sub.py --claimed SUB_SEED1.jsonl --baseline REF_SEED1.jsonl` on their own machine.

Competitors can try the contract with `python3 checker/check.py derive --practice --size {lad['practice_dims'][0]} --idx 0`.

## What a score does not show (read before publishing one)

* **`score.py` does not know how the costs were measured**, but `check.py rerun` can test them. `rerun` takes the seed, the solver and the two claimed ladders,
  picks a random sample of instances (the verifier's own choice: the operator must not know it in advance), re-runs the reference and the solver on THIS machine,
  checks the answers, and compares the re-measured speedup with the claimed one instance by instance. Costs typed into a file, or a solver slower than claimed, show as a
  gap; a baseline ladder that was not measured on one machine shows as a spread. What it does not show: a meter whose bias is the same on every instance; ladders
  from a different hardware class (it reports the machine factor, which cancels in a ratio only if it is the same at every size); instances you did not sample. The
  default tolerance is 2 bits for pure Python and 3.5 bits when the challenge uses a numerical library (numpy, scipy, torch, ...), loose on purpose and set from the three
  real measurements below; a looser tolerance also lets a larger false claim pass, and the attestation records the one used. `rerun --repeat N` measures THIS machine's own timing noise
  (real dlog claims: 0.01 bit), and `rerun --sample-seed S --save F` on two or more machines followed by `check.py spread F1 F2 ...` turns their disagreement into a recommended
  tolerance (needs 2+ distinct machines and 3+ shared instances; one machine is refused, not faked; never below 1 bit; files of different solvers or seeds are not merged). Three real
  measurements between an Apple M4 Pro (macOS) and a Hetzner x86 server (Linux), one machine pair, and they disagree about how far a speedup travels. A pure-Python domain (dlog;
  machines about 0.5 bit apart in raw speed) agreed to a median 0.01 bit, worst 0.03 bit. Two numpy domains did NOT: aiinfer (a float32 batched matmul solver against a float64
  reference) was +3.3 bits on the Mac and +0.03 bit on the server, a 3.4-bit disagreement, because the Mac's matmul ran 46x faster (815 vs 18 GFLOP/s); aidecode (a KV-cache
  decoder, small kernels) was +5.2 on the Mac and +7.4 on the server, a 2.2-bit disagreement in the OTHER direction (the server's reference was 8x slower, its solver only 1.8x).
  So 2 bits fits pure Python and fails honest numpy claims on a different machine class; `rerun` says so before measuring and again when this machine's reference differs from the claimant's by 1 bit or more. Under bubblewrap, `rerun` also checks that the CPU meter works at
  all: it refuses if an empty Python start measures ~0, and fails if the reference reads ~0 where its published cost is seconds. It also fails a claim when a run took over
  half a second of wall time (the scorer ignores costs below 0.5 s anyway) but its CPU share is under 60% of the share the reference got on the same instance (30% absolute when the reference ran under 0.5 s): a solver that waits, or that forks its work and returns without waiting (on Linux that child's CPU escapes the kernel's
  accounting; measured: 2.0 s of work read as 0.02 s without the sandbox, and a solver padding its CPU to 34% still faked 1.0 bit against a fixed 30% rule). Judged against the reference, a
  loaded machine does not fail an honest solver, and the most a solver can still hide is about 0.7 bit. `--sandbox off` is for solvers you trust. It runs the solver and the reference in the OS sandbox described above (and additionally hides the seed and
  your signing key from them) and refuses to run at all where there is none unless you pass `--sandbox off`. It is not a proof of isolation: CPU, memory and the kernel are
  shared, and `sandbox-exec` is deprecated by Apple. (On macOS the profile also denies every Mach service lookup except user-name lookups, so a solver using `ctypes` cannot
  talk to LaunchServices, the pasteboard or the preferences daemon: measured, all three were reachable before.)
  Run the meter you trust, on one machine, one instance at a time, the same CPU for the reference and the submission.
* **The credit is the speedup over THIS reference**, in bits, on the instances the reference finds hard (cost above 0.5 s). A weak reference makes
  big speedups cheap. The declaration author's statement of what the reference is: {ch['reference']['note'] or 'not stated'}
* **It measures speed, not quality.** The cost is one number per instance (seconds, or any unit that plays the role of seconds against the 0.5 s floor, for
  example counted bytecode steps scaled to seconds). A challenge whose score is accuracy, size or a trade-off is not expressible here; the verifier is
  all-or-nothing per instance.
* **A speedup beyond the certifiable range cannot be certified**: a very fast solver costs less than the 0.5 s floor on the instances that matter, so
  they stop counting. Above the range the result is inconclusive or flat, not a measure of how fast. `score.py` says so in those words, gives the raw
  median gap as description (never as a bound), and says what it would take: the slower solver must cost about 0.5 s x 2^gap on the hard instances, and if that is
  above the cap, no ladder under this cap can resolve it (raise the cap or use a stronger reference, and recompile).
* **The power table assumed a per-instance noise; `score.py` measures it.** Each pair's within-bin noise is reported; if it is clearly above the assumed value the
  scorer says the table is optimistic and re-simulates the certifiable range at the observed value. `python3 checker/score.py power --pair-noise X --min-gap G` re-simulates
  on demand from the compiled profile (Monte-Carlo error is printed). It is a simulation of ladders drawn from the compile-time profile, not of your solver.
* **`compare` resolves only gaps on instances where the slower solver costs at least 0.5 s** (and the faster one does too). It prints its own simulated power at the
  observed noise, including how often a true gap of 0 would be declared. The `--min-gap` threshold itself (default 0.5 bit) is a convention, not a pre-registered test.
* **A result can be re-checked, not trusted.** `score.py --out` records the sha256 of every input ladder, of this challenge, of the estimator and of the scorer;
  `score.py recheck RESULT.json` recomputes from the ladders and fails on any difference: tamper-evidence for a published number.
* **Attestations and a log, with their honest limits.** `check.py keygen` makes an Ed25519 key (pure Python, checked against the RFC 8032 vectors); `rerun --sign KEY
  --attest-out F` signs the outcome (sample, per-instance gaps, solver and ladder hashes, machine, sandboxed or not); `attest-check` verifies signatures and counts only
  keys YOU pinned (`--trusted`, obtained out of band; an operator can make five keys) as vouched, while a valid signed dissent from ANY key fails the check. Each attestation
  also records whether the solver ran sandboxed, which generation of `rerun` defences made it (`rerun_checks`: 2 = the CPU-hiding, detached-process and dead-meter checks) and whether
  the detached-process scan could run; `attest-check` prints "weaker evidence" for an unsandboxed run, an older tool or a skipped scan, and `--strict` makes such a PASS not count
  (a FAIL from any run always counts). These fields are signed statements by the verifier, not proofs: a dishonest verifier can write any of them.
  `check.py log append|verify` is an append-only hash chain of submissions, results or attestations: it detects an edited, removed or reordered entry. Appending holds a file
  lock from reading the log to writing the entry (POSIX; concurrent appends queue up instead of corrupting the chain, tested with 16 at once; elsewhere it refuses). A truncated copy
  still verifies ALONE, so anyone (the operator, a competitor, a watcher) can `log checkpoint LOG --key K --out C`, a signed (head, count); `log verify LOG --checkpoint C`
  then fails for a log that no longer contains it, whether truncated or forked into a different but internally valid history. Checkpoints only help if someone other
  than the operator keeps them (and, for it to mean independence, you pinned their key). The time in an entry is the logger's clock, not evidence. None of this is a
  trusted clock or a trusted-hardware proof; for claims that must hold against an adversarial operator, the full protocol (guldo certificates, rounds) is still stronger.
* **Malformed or hostile input is refused with a message, not crashed on**: ladders, result files, attestations, measurements, checkpoints, logs, answers and every numeric
  command-line option (fuzz-tested in the guldo project). Options have bounds (`--boot` 1..5000, `-k` 1..1000, `--repeat` 1..50, `derive`/`verify` sizes inside the
  challenge's declared range, ...), so no option can request an unbounded computation or hand the author's `derive()` a size it was never meant for. Files named on the
  command line must be REGULAR files under a size cap (1 MB for seeds and key lists, 16 MB for JSON, 32 MB for ladders, 64 MB for logs and answers): a FIFO, a device such as
  `/dev/zero` (also behind a symlink), a socket or a directory is refused in one line, because opening a FIFO blocks for ever and a device never ends. A result file that asks
  for an unreasonable bootstrap count or leaves an input ladder unbound is refused up front.
* **The verifier is tested, not proved.** `check.py selftest` tries a fixed list of junk answers AND answers derived from each instance (its arguments and their
  neighbours, other instances' witnesses, that instances really differ between seeds, witnesses with every part damaged; a witness with one part changed only warns, because a verifier with a
  tolerance accepts it by design, and 100 random answers of the witness's type, length and magnitude per instance) on the public practice seed and on a fresh random seed.
  Reuse checks are rates over many pairs: more than 50% fails and more than 25% warns, because at small sizes instances can share factors and chance hits cluster. So a
  mildly small answer space is a warning; a lookup-table verifier (accepts nearly every other instance's answer) fails. A verifier that accepts only something outside
  all of that still passes.
* **Not tied to any particular platform.** `PROPOSAL.md` is pre-filled intake text; no platform has reviewed or accepted this bundle.

Provenance: compiled {ch['provenance']['compiled_at']}, compiler self-test {ch['provenance']['selftest']}, decl {ch['files']['checker/decl.py'][:16]}..., reference {ch['files']['checker/reference.py'][:16]}...
"""


def proposal(ch, field):
    pw, lad = ch["power"], ch["ladder"]
    rng = (f"about {pw['min_certifiable_bits']} to {pw['max_certifiable_bits']} bits" if pw["min_certifiable_bits"] is not None else "none yet")
    return f"""# Proposal text for {ch['name']} (pre-filled; edit before sending)

Written from the bundle's own record. Nothing here has been reviewed by any platform. Bundle status: {ch['status']}.
{('Fix first: ' + '; '.join(ch['status_reasons'])) if ch['status_reasons'] else ''}

**Name:** [you]
**Email:** [you]
**Institution / affiliation:** [you]
**Field:** {field}

## The Problem
{ch['problem']['doc']}

Goal metric: speedup over a stated reference solver, in bits (log2 of the cost ratio), measured on instances the reference finds hard
(cost above 0.5 s), reported as a one-sided 95% lower bound and, across {ch['protocol']['seeds_required']} committed seeds, the minimum. The reference is: {ch['reference']['note'] or '[state what the reference is and what is known to beat it]'}
Why it matters: [one or two sentences about why a faster solver for this problem is worth having].

## The Verifier
* Instances are a pure function of (seed, size, index), derived by the declaration's `derive`; the seed's sha256 is published before the deadline and the seed after, so nothing can be precomputed.
* `verify(instance, answer)` is exact and rejects junk (checked: None, 0, 1, -1, booleans, empty and nested lists, strings, floats, huge ints).
* Cost is CPU seconds of the whole process tree, one instance at a time on one core, with a cap of {lad['budget_seconds']} s per instance; a failure is charged the cap.
* Sizes {lad['dims']}, {lad['n']} instances per size. By simulation through the real estimator this ladder can certify speedups of {rng}; the full power table is in the bundle.
* A standalone checker, a scorer and the estimator are in the bundle, with a sha256 manifest. `python3 checker/check.py selftest` runs in seconds, on a fresh random seed.
* Claimed results can be re-measured by a verifier (`check.py rerun`, random sample, own machine) and re-computed by anyone (`score.py recheck`).

## Link
[URL of the published bundle]

## Honest limits to state up front
* The bundle measures speed only, and the credit is only as meaningful as the reference.
* The scorer takes measured costs as input; it does not itself provide a sandbox or meter (the re-measurement tool samples; it does not replace a meter).
* Speedups beyond the certifiable range read as inconclusive, with a statement of what cap would be needed to resolve them.
"""


def build(arg, out=None, field="Computer Science", selftest=True):
    import compile_domain  # lazy: it imports the whole project, and `verify` must not need that
    d = compile_domain._resolve(arg)
    mod = compile_domain._load(d, arg)
    compiled = declared.read_compiled(d)
    is_q = (compiled or {}).get("kind") == "quality"
    if is_q:
        import compile_quality
        problems = compile_quality.freshness_problems(d, mod, compiled)
    else:
        problems = declared.freshness_problems(d, mod, compiled)
    if problems:
        raise ExportError("REFUSED: " + "; ".join(problems) + " (compile it again)")   # answers are scored, not the clock: a different scorer, power analysis and README (see COMPILER.md, "Quality challenges")
    d = os.path.abspath(d)
    ref_path = declared.reference_path(d, mod)
    safe_version = re.sub(r"[^A-Za-z0-9._-]", "_", mod.VERSION)   # the author's string becomes a directory name
    out = os.path.abspath(out or os.path.join(d, "out", f"bundle-{safe_version}-{compiled['decl_sha256'][:8]}"))
    if os.path.exists(out):
        raise ExportError(f"{out} exists; this tool never overwrites (choose another --out, or remove it yourself)")
    os.makedirs(os.path.dirname(out), exist_ok=True)

    vendored, third = resolve_imports(os.path.join(d, declared.DECL), [d, HERE])
    dynamic = {}
    probed = probe_imports(d, compiled["practice_dims"][:3])   # what the walk could not see: imports made at run time, and data files opened
    if probed["foreign"]:
        raise ExportError("the declaration reads project files that cannot travel with a bundle: " + ", ".join(os.path.relpath(p, HERE) for p in probed["foreign"])
                          + ". Put the data beside decl.py (it is then copied), or remove the dependency.")
    data_files = sorted(probed["data"])
    for name, path in probed["modules"].items():
        if name not in vendored:
            if name in RESERVED:
                raise ExportError(f"the declaration loads a module called {name!r} at run time, which the bundle uses for itself; rename it")
            dynamic[name] = path
    for name, path in sorted(dynamic.items()):
        vendored[name] = path
    for path in list(dynamic.values()):
        resolve_imports(path, [d, HERE], set(vendored) | STD, vendored, third)
    ref_vendored, ref_third = resolve_imports(ref_path, [d, HERE])
    if ref_vendored:
        raise ExportError(f"the reference solver imports project modules {sorted(ref_vendored)}; it runs in a sandbox that has only the standard library, "
                          "numpy and fpylll, so it must not")
    third |= ref_third

    stage = tempfile.mkdtemp(prefix=".bundle-stage-", dir=os.path.dirname(out))
    try:
        files = {}

        def put(rel, src):
            copy_exact(src, os.path.join(stage, rel))
            files[rel] = sha256_file(os.path.join(stage, rel))   # the hash of what was written, not of a source that could change meanwhile

        put("checker/decl.py", os.path.join(d, declared.DECL))
        put("checker/reference.py", ref_path)
        put("checker/quality_core.py" if is_q else "checker/estimator.py", os.path.join(HERE, "quality_core.py" if is_q else "extrapolate.py"))
        put("compiled.json", os.path.join(d, declared.COMPILED))
        for name, src in sorted(vendored.items()):
            put(f"checker/vendor/{name}.py", src)
        for rel in data_files:   # beside decl.py in the domain, beside checker/decl.py in the bundle: a path relative to __file__ keeps working
            if rel in ("compiled.json",) or rel.split(os.sep)[0] in ("out",):
                continue
            put("checker/" + rel.replace(os.sep, "/"), os.path.join(d, rel))
        write_bytes(os.path.join(stage, "checker", "check.py"), read_template("check.py"), 0o755)
        write_bytes(os.path.join(stage, "checker", "score.py"), read_template("score.py"), 0o755)
        if is_q:
            write_bytes(os.path.join(stage, "checker", "qscore.py"), read_template("qscore.py"), 0o755)
            write_bytes(os.path.join(stage, "checker", "qcheck.py"), read_template("qcheck.py"), 0o755)

        import extrapolate as E
        power = power_block(compiled)
        status, reasons = status_of(compiled, power)
        ch = {
            "format": FORMAT, "name": mod.NAME, "version": mod.VERSION, "status": status, "status_reasons": reasons,
            "problem": {"doc": getattr(mod, "DOC", "(the declaration gives no DOC string)"), "signature": getattr(mod, "SIGNATURE", None)},
            "solver_contract": "one Python file defining a top-level solve(*args) returning an int, a list of ints, or None; deterministic, one process, no files, no network",
            "reference": {"file": "checker/reference.py", "note": compiled.get("reference_note")},
            "ladder": {"dims": compiled["dims"], "practice_dims": compiled["practice_dims"], "size_range": compiled.get("size_range"),
                       "size_step": compiled.get("size_step"), "n": compiled["official"]["n"], "budget_seconds": compiled["official"]["budget"]},
            "protocol": {"seeds_required": compiled_seeds(), "commitment": "sha256 of the seed file's bytes (surrounding whitespace stripped)",
                         "instances": "a pure function of (seed, size, idx): checker/check.py derive",
                         "cost_floor_seconds": E.FLOOR_ABS, "min_instances_per_bin": E.MIN_BIN, "top_bins_pooled": E.TOP_K,
                         "credit": "one-sided 95% joint-bootstrap lower bound of the pooled median log2 speedup over the hardest usable difficulty bins; min over seeds; inconclusive = 0"},
            "power": power,
            "provenance": {"compiled_at": compiled.get("compiled_at"), "compiler_sha256": compiled.get("compiler_sha256"),
                           "selftest": (compiled.get("selftest") or {}).get("status", "pending"), "cpu_hours": compiled.get("cpu_hours"),
                           "exported_with": f"python {sys.version.split()[0]}"},
            "requires": {"third_party": sorted(third), "vendored": sorted(vendored), "vendored_found_only_at_run_time": sorted(dynamic), "data_files": [x for x in files if x.startswith("checker/") and not x.startswith(("checker/vendor/", "checker/decl.py", "checker/reference.py", "checker/estimator.py", "checker/quality_core.py"))],
                         "checker": "standard library", "scorer": "numpy"},
            "simulation": simulation_block(compiled),
            "files": dict(sorted(files.items())),
        }
        if is_q:
            ch = quality_challenge(ch, compiled)
            status, reasons = ch["status"], ch["status_reasons"]   # what build() returns and prints: the speed record's reasons above do not apply
        write_bytes(os.path.join(stage, "challenge.json"), (json.dumps(ch, indent=1, sort_keys=True) + "\n").encode())
        write_bytes(os.path.join(stage, "README.md"), (readme_quality(ch) if is_q else readme(ch)).encode())
        write_bytes(os.path.join(stage, "PROPOSAL.md"), (proposal_quality(ch, field) if is_q else proposal(ch, field)).encode())
        write_manifest(stage)
        if selftest:   # a fixed fresh seed (from the declaration's hash) keeps an export reproducible; `check.py selftest` run later draws a new one each time
            run_selftest(stage, hashlib.sha256((compiled["decl_sha256"] + ":fresh").encode()).hexdigest()[:32])
        os.chmod(stage, 0o755)   # mkdtemp makes it 0700; a bundle is meant to be copied and shared
        os.rename(stage, out)
    except BaseException:
        shutil.rmtree(stage, ignore_errors=True)
        raise
    return out, status, reasons


def quality_challenge(ch, compiled):
    """The manifest of a QUALITY bundle: `ch` is the speed-shaped record built above; everything that describes speed is replaced."""
    import compile_quality
    qc = compiled["quality"]
    pw = qc["power"]
    reasons = []
    st = (compiled.get("selftest") or {}).get("status", "pending")
    if st != "pass":
        reasons.append(f"the compiler's own self-test is {st!r}, not 'pass'")
    if pw["min_certifiable"] is None:
        reasons.append("the power analysis found no gain this ladder can certify")
    if not compiled.get("reference_note"):
        reasons.append("the declaration states no REFERENCE_NOTE: nobody can tell how strong the baseline is")
    reasons += [n for n in qc.get("notes", []) if "NOT reproducible" in n]   # a baseline that cannot be re-run cannot be verified
    out = dict(ch)
    out.update({
        "metric": "quality", "status": "READY" if not reasons else "DRAFT", "status_reasons": reasons,
        "solver_contract": "one Python file defining a top-level solve(*args) returning a JSON value the declaration's verify() accepts; deterministic or not, one process, no files, no network; "
                           f"it gets {qc['budget']:g} CPU seconds per instance",
        "protocol": {"seeds_required": compiled_seeds(), "commitment": "sha256 of the seed file's bytes (surrounding whitespace stripped)",
                     "instances": "a pure function of (seed, size, idx): checker/check.py derive",
                     "credit": "conservative lower bound (1st percentile of a bootstrap within each size) of the mean paired quality difference (solver minus reference), averaged over sizes; "
                               "max(0, .) per seed; min over seeds. An instance without a verified answer scores 0."},
        "power": {"threshold": pw["threshold"], "target_power": pw["target_power"], "target_effect": pw["target_effect"], "noise": pw["noise"], "noise_assumed": pw["noise_assumed"],
                  "min_certifiable": pw["min_certifiable"], "max_certifiable": pw["max_certifiable"], "curve": pw["curve"], "notes": list(pw["notes"]) + list(qc.get("notes", []))},
        "quality": {"budget_seconds": qc["budget"], "min_gain": qc["min_gain"], "headroom_mean_cap": qc["headroom_mean_cap"],
                    "reference_profile": {s: {"mean": v["mean"], "sd": v["sd"], "timeouts": v["timeouts"]} for s, v in qc["profile"]["sizes"].items()}},
        "simulation": qc["simulation"],
    })
    out["provenance"] = dict(out["provenance"], cpu_hours=qc["cpu_hours"], quality_compiler_sha256=compiled.get("quality_compiler_sha256"))
    out["requires"] = dict(out["requires"], scorer="standard library", checker="standard library")
    return out


def readme_quality(ch):
    pw, lad, name = ch["power"], ch["ladder"], ch["name"]
    reasons = "".join(f"\n* {r}" for r in ch["status_reasons"])
    rng = (f"from about {pw['min_certifiable']:g} to about {pw['max_certifiable']:g}" if pw["min_certifiable"] is not None else "NONE: this challenge is too weak to certify anything")
    rows = ["| true mean gain (quality points) | P(one seed credited) | P(all seeds credited) |", "|---|---|---|"]
    rows += [f"| {float(e):g} | {100 * v['single']:.0f}% | {100 * v['all_seeds']:.0f}% |" for e, v in pw["curve"].items()]
    prof = "\n".join(f"  * size {s}: reference mean quality {v['mean']:.3f} (sd {v['sd']:.3f}, {v['timeouts']} timeouts in the profile)" for s, v in ch["quality"]["reference_profile"].items()
                     if int(s) in set(lad["dims"]))
    return f"""# {name} ({ch['version']}): QUALITY challenge bundle, status {ch['status']}
{('The bundle is a DRAFT because:' + reasons) if reasons else ''}

{ch['problem']['doc']}

* **What is scored:** the QUALITY of each answer (0 to 1, from the declaration's `quality(inst, ans)`), at the same CPU budget for everyone: {lad['budget_seconds']} s per instance. A solver that is
  faster but no better gets nothing; one that finds better answers inside the budget gets the difference. An instance with no verified answer scores 0.
* solver: {ch['solver_contract']}
* sizes {lad['dims']}; {lad['n']} instances per size; credit needs {ch['protocol']['seeds_required']} committed seeds
* reference: {ch['reference']['note'] or 'NOT STATED by the declaration author'}
{prof}
* this ladder can certify mean gains {rng} quality points over the reference (threshold {pw['threshold']:g}, simulated; assumed per-instance noise {pw['noise']:g}, an ASSUMPTION that `qscore.py` replaces by the value it measures)

{chr(10).join(rows)}

## What is in here

| path | what |
|---|---|
| `challenge.json` | the manifest (`"metric": "quality"`): problem, ladder, protocol, power, provenance, requirements, the sha256 of every pinned file |
| `checker/decl.py`, `checker/reference.py` | the declaration (`derive`, `verify`, `quality`) and the baseline, byte-for-byte what was compiled |
| `checker/check.py` | `info`, `selftest`, `commit`, `derive`, `keygen`, `attest-check`, `log`: the speed bundle's tools, which work here. `selftest` tests `verify` AND `quality()` (range, determinism, that no answer needing no search scores above 0.9). `rerun` and `spread` are speed tools and refuse |
| `checker/qcheck.py` | `run` (run a solver on every instance, sandboxed, and write the ladder), `verify` (valid? and its quality), `qrerun` (re-run a random sample of a CLAIMED result; `--sign`; `--save`), `qspread` (merge saved measurements from different machines: how far does quality move between them?) |
| `checker/qscore.py` | `score` (one solver against the reference), `compare` (is A really better than B?), `power` (re-simulable), `recheck`. Standard library only |
| `checker/quality_core.py` | the statistics (paired difference, stratified bootstrap bound, power simulation); its hash is in the manifest |
| `checker/score.py` | the speed scorer's readers, reused by `qscore.py`; its speed commands refuse on this bundle |
| `checker/vendor/` | project modules the declaration imports, copied byte-for-byte (empty if none) |
| `compiled.json` | the compiler's full record, for audit |
| `MANIFEST.sha256` | `sha256sum -c MANIFEST.sha256` (macOS: `shasum -a 256 -c MANIFEST.sha256`), run in this directory |
| `PROPOSAL.md` | intake text pre-filled from this record |

## Before you run anything here

`check.py derive|selftest` and `qcheck.py verify` import and run `checker/decl.py` (and `selftest` the reference): that is the author's code, and the manifest hashes prove only that the files are the
ones listed, not that they are safe. They re-run themselves inside an OS sandbox by default (macOS `sandbox-exec`; Linux `bwrap`: no network, no writes outside a scratch directory, credentials
unreadable) and warn where there is none. `qcheck.py run` and `qrerun` execute a COMPETITOR's solver the same way and REFUSE to run without a sandbox unless you pass `--sandbox off`. They also
call `decl.verify()` and `decl.quality()` in the parent process, unsandboxed: read `decl.py` first. A sandbox stops the practical damage, not a determined attacker.

## Hosting it on a board

1. **Seeds.** Pick at least {ch['protocol']['seeds_required']} secret seeds, publish `python3 checker/check.py commit --seed-file S` for each BEFORE the deadline, reveal after.
2. **A meter.** `python3 checker/qcheck.py run --seed-file S --solver sub.py --out SUB_S.jsonl` runs the solver on every instance (one at a time, CPU-limited to the budget, sandboxed), writes the
   ladder, and prints each size's mean quality. Do the same with `--solver checker/reference.py` for the baseline ladder. A ladder is JSON lines: a first line
   `{{"meta": true, "commit": "<the seed's sha256>", "budget": {lad['budget_seconds']}}}`, then `{{"id": "SIZE:IDX", "dim": SIZE, "status": "solved", "quality": 0.873}}` for every instance
   (statuses solved, timeout, crash, failed, wrong; anything but solved scores 0).
3. **A scorer run.** `python3 checker/qscore.py score --pair REF_S1.jsonl SUB_S1.jsonl --pair ... --pair ... --out result.json` prints the credit in quality points and writes JSON;
   `python3 checker/qscore.py compare --a A1 A2 A3 --b B1 B2 B3` answers "is #1 really ahead of #2?"; anyone can `qscore.py recheck result.json`; a verifier with the revealed seed can
   `python3 checker/qcheck.py qrerun --seed-file S --solver sub.py --claimed SUB_S1.jsonl --baseline REF_S1.jsonl --sign KEY --attest-out A.json` on their own machine, and
   `check.py attest-check` counts attestations from keys you pinned.

Competitors can try the contract with `python3 checker/qcheck.py run --practice --solver my.py` (public practice seed, sizes {lad['practice_dims']}).

## What a score does not show (read before publishing one)

* **The credit is only as meaningful as `quality()`.** The scorer averages whatever the declaration returns. If quality() rewards the wrong thing, the score does too. It is checked
  to be a finite number in [0, 1], deterministic, and not high for answers that need no search; whether it measures what you care about is not checkable by a tool.
* **The credit is the gain over THIS reference, in quality points, at THIS budget.** A weak reference makes gains cheap; a saturated one (the reference already near 1) makes every solver tie:
  the compiler drops sizes where the reference averages above {ch['quality']['headroom_mean_cap']}, and `qscore.py` warns when half the reference's answers are at the top. Declaration author's statement of
  the reference: {ch['reference']['note'] or 'not stated'}
* **Equal weight per size, equal budget for everyone.** The mean is over sizes, so a gain on the largest size counts as much as one on the smallest. A solver that does better by
  using more CPU than the budget is not credited: `run` scores an answer that came after the cap as 0 and `qrerun` fails a solver whose CPU exceeds it. Wall-clock, memory and
  parallelism are NOT limited beyond the sandbox: the budget is CPU seconds of the process tree, and a solver that hides its CPU (waits, or forks work it never waits for) is detected only
  when more than 70% is hidden. A solver that leaves a DETACHED process running (a hidden helper that keeps computing past the budget or feeds later instances) is found by the process scan
  `run_solver` does after each run: `run` scores that instance 0 and `qrerun` FAILS the claim (on any machine, never INCONCLUSIVE). Where `ps` is unavailable the scan cannot run, and both say so.
* **The power table assumed a per-instance noise; `qscore.py` measures it** (pooled within-size sd of the paired differences) and, if the ladders show clearly more, re-simulates the
  certifiable range at the observed value. The assumption itself is a share of the reference's own spread, not measured on any competitor.
* **Randomised solvers do not reproduce exactly.** `qrerun` compares claimed and re-measured qualities within a tolerance (default 0.05); a solver whose own run-to-run spread is larger
  will fail it, which is honest: its claimed number was not reproducible.
* **Machine speed matters here in a way it does not for a speed bundle's ratios:** an anytime solver does more work per CPU second on a faster machine, so the same budget gives a better
  answer. `qcheck.py run` therefore records a machine calibration in each ladder (CPU seconds of a fixed pure-Python workload through the same meter and sandbox; stable to about 3% on one machine, also
  under CPU load), and `qscore.py` REFUSES to compare ladders whose calibrations differ by more than 1.25x (`--lenient` allows it, and the result is PROVISIONAL). `qrerun` prints when the verifier's machine
  differs from the one that produced a ladder, because a gap there is expected. The calibration catches a machine mismatch; it does not correct for one, and it is pure-Python speed, not your solver's
  (a numpy or memory-bound solver may scale differently). On a machine of a different speed a `qrerun` that does not reproduce is INCONCLUSIVE (exit 2) and is never signed, because it is neither a
  confirmation nor a refutation; a claimant can force INCONCLUSIVE by writing a false calibration into their ladder, which is why INCONCLUSIVE is not PASS. `qrerun --save` plus `qspread` measure the
  actual spread. The one measurement so far: the same time-limited annealing solver on one Apple M4 Pro's performance cores vs its efficiency cores (calibration 5.3x apart) scored up to 0.12 lower
  (median 0.08) on the slow cores, at a budget where it was not saturated, while the reference (a fixed algorithm) moved by 0. That is two CPU classes of one chip, not two machines. The Python version matters as much: on the same cores the calibration ranged 1.0x to 1.53x across 3.14, 3.13, 3.12 and 3.9, and quality
  spread with it, so run the reference and every solver under the same interpreter (this bundle was exported under the one in `provenance.exported_with`).
* **A result can be re-checked, not trusted.** `qscore.py --out` records the sha256 of every input ladder, of this challenge and of the scorer; `recheck` recomputes and fails on any difference.
* **Hostile input is refused, not crashed on** (ladders, result files, answers, options), with the speed bundle's size caps and bounds. The quality code paths were added later than the
  speed ones and have had less testing.
* **Not tied to any particular platform.** `PROPOSAL.md` is intake text; no platform has reviewed or accepted this bundle.

Provenance: compiled {ch['provenance']['compiled_at']}, compiler self-test {ch['provenance']['selftest']}, decl {ch['files']['checker/decl.py'][:16]}..., reference {ch['files']['checker/reference.py'][:16]}...
"""


def proposal_quality(ch, field):
    pw, lad = ch["power"], ch["ladder"]
    rng = (f"about {pw['min_certifiable']:g} to {pw['max_certifiable']:g} quality points" if pw["min_certifiable"] is not None else "none yet")
    return f"""# Proposal text for {ch['name']} (pre-filled; edit before sending)

Written from the bundle's own record. Nothing here has been reviewed by any platform. Bundle status: {ch['status']}.
{('Fix first: ' + '; '.join(ch['status_reasons'])) if ch['status_reasons'] else ''}

**Name:** [you]
**Email:** [you]
**Institution / affiliation:** [you]
**Field:** {field}

## The Problem
{ch['problem']['doc']}

Goal metric: the QUALITY of the answer (0 to 1) at a fixed CPU budget of {lad['budget_seconds']} s per instance, as a gain over a stated reference solver. The score is a conservative lower bound (the 1st percentile of a within-size bootstrap, calibrated on real solves: 3% single-seed false credit measured)
of the mean paired quality difference, bootstrapped within each size, and across {ch['protocol']['seeds_required']} committed seeds the minimum. The reference is: {ch['reference']['note'] or '[state what the reference is and what is known to beat it]'}
Why it matters: [one or two sentences about why better answers to this problem are worth having].

## The Verifier
* Instances are a pure function of (seed, size, index); the seed's sha256 is published before the deadline and the seed after, so nothing can be precomputed.
* `verify(instance, answer)` decides validity; `quality(instance, answer)` scores a valid answer in [0, 1] (checked: finite, in range, deterministic, and no answer that needs no search scores above 0.9). An instance without a verified answer scores 0.
* CPU seconds of the whole process tree, one instance at a time, a cap of {lad['budget_seconds']} s per instance, the same for the reference and every submission.
* Sizes {lad['dims']}, {lad['n']} instances per size. By simulation this ladder can certify mean gains of {rng}; the full power table is in the bundle.
* A standalone checker (`check.py`, `qcheck.py`), a scorer (`qscore.py`) and the statistics module are in the bundle, with a sha256 manifest. `python3 checker/check.py selftest` runs in seconds on a fresh random seed.
* Claimed results can be re-run by a verifier on their own machine (`qcheck.py qrerun`, random sample, signed attestation) and re-computed by anyone (`qscore.py recheck`).

## Link
[URL of the published bundle]

## Honest limits to state up front
* The score is only as meaningful as `quality()`; the tools check its range and determinism, not its meaning.
* The scorer takes measured qualities as input; `qcheck.py run` is a sandboxed local meter, not a hosted, isolated one.
* Cross-machine reproducibility of quality (an anytime solver does more per CPU second on a faster machine) has not been measured.
"""


def compiled_seeds():
    import compile_domain
    return compile_domain.SEEDS


def write_manifest(root):
    lines = []
    for dp, dns, fns in os.walk(root):
        dns[:] = sorted(x for x in dns if x != "__pycache__")
        for fn in sorted(fns):
            if fn == "MANIFEST.sha256" or fn.endswith(".pyc"):
                continue
            p = os.path.join(dp, fn)
            lines.append(f"{sha256_file(p)}  {os.path.relpath(p, root)}")
    write_bytes(os.path.join(root, "MANIFEST.sha256"), ("\n".join(sorted(lines, key=lambda s: s.split("  ", 1)[1])) + "\n").encode())


def manifest_problems(root):
    path = os.path.join(root, "MANIFEST.sha256")
    if not os.path.isfile(path):
        return ["MANIFEST.sha256 is missing"]
    listed, out = {}, []
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                h, _, rel = line.rstrip("\n").partition("  ")
                listed[rel] = h
    for rel, h in sorted(listed.items()):
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            out.append(f"missing: {rel}")
        elif sha256_file(p) != h:
            out.append(f"changed: {rel}")
    for dp, dns, fns in os.walk(root):
        dns[:] = [x for x in dns if x != "__pycache__"]
        for fn in fns:
            rel = os.path.relpath(os.path.join(dp, fn), root)
            if rel != "MANIFEST.sha256" and not fn.endswith(".pyc") and rel not in listed:
                out.append(f"not in the manifest: {rel}")
    return out


def run_selftest(root, fresh_seed=None, sandbox="auto", require=False):
    """check.py selftest in a clean interpreter (-I: no PYTHONPATH, no user site, no script directory; -B: leave no bytecode in the bundle) from an empty working
    directory, inside the OS sandbox unless sandbox="off" (so a declaration that secretly needs to write files or reach the network fails HERE, at export, not for
    the next person). require=True refuses to run at all where no sandbox exists."""
    with tempfile.TemporaryDirectory() as empty:
        env = {"PATH": os.environ.get("PATH", ""), "HOME": empty, "PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1"}
        if require:
            env["GULDO_REQUIRE_SANDBOX"] = "1"
        try:
            cmd = ([sys.executable, "-I", "-B", os.path.join(root, "checker", "check.py"), "selftest", "--sandbox", sandbox]
                   + (["--fresh-seed", fresh_seed] if fresh_seed else []))
            r = subprocess.run(cmd, cwd=empty, env=env,
                               capture_output=True, text=True, timeout=SELFTEST_TIMEOUT)
        except subprocess.TimeoutExpired:
            raise ExportError(f"the bundle's self-test did not finish in {SELFTEST_TIMEOUT} s")
    if r.returncode != 0:
        tail = "\n".join((r.stdout + r.stderr).strip().splitlines()[-15:])
        raise ExportError("the bundle FAILS its own self-test in a clean interpreter, so it is not portable as written:\n" + tail)
    return r.stdout


def verify_bundle(root, selftest=False, unsandboxed=False):
    """Hashes and pins, and with selftest=True the bundle's own self-test. That runs the bundle's decl.py and reference, which are its AUTHOR's code, so it runs
    inside the OS sandbox and refuses to run at all where there is none, unless unsandboxed=True."""
    problems = manifest_problems(root)
    if not problems:
        try:
            with open(os.path.join(root, "challenge.json"), encoding="utf-8") as f:
                ch = json.load(f)
            if ch.get("format") != FORMAT:
                problems.append(f"challenge.json has format {ch.get('format')!r}, expected {FORMAT!r}")
            for rel, h in ch.get("files", {}).items():
                p = os.path.join(root, rel)
                if not os.path.isfile(p) or sha256_file(p) != h:
                    problems.append(f"challenge.json pins {rel} but it differs")
        except (OSError, ValueError) as e:
            problems.append(f"challenge.json unreadable: {e}")
    if selftest and not problems:
        try:
            run_selftest(root, None, "off" if unsandboxed else "auto", require=not unsandboxed)
        except ExportError as e:
            problems.append(str(e))
    return problems


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] not in ("export", "verify") and not argv[0].startswith("-"):
        argv = ["export"] + argv   # `guldo export NAME` (the form the docs show) means `export NAME`; `guldo export export NAME` also still works
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("export", help="write a bundle for a compiled, fresh domain")
    p.add_argument("name", metavar="NAME_or_dir")
    p.add_argument("--out", help="bundle directory (default domains/NAME/out/bundle-VERSION-DECLHASH); never overwritten")
    p.add_argument("--field", default="Computer Science", help="the Field entry PROPOSAL.md pre-fills (default: Computer Science)")
    p.add_argument("--no-selftest", action="store_true", help="skip the clean-interpreter self-test (the bundle is then not known to be portable)")
    p = sub.add_parser("verify", help="re-check a bundle's hashes (and optionally run its self-test)")
    p.add_argument("dir")
    p.add_argument("--selftest", action="store_true", help="ALSO run the bundle's self-test, which executes its decl.py and reference (its author's code): inside the OS sandbox, "
                   "and refusing to run where there is none")
    p.add_argument("--unsandboxed", action="store_true", help="with --selftest: run it as you, without the sandbox (only for a bundle you have read)")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "export":
            out, status, reasons = build(a.name, a.out, a.field, not a.no_selftest)
            print(f"wrote {out}")
            print(f"status: {status}" + "".join(f"\n  - {r}" for r in reasons))
            print("next: python3 " + os.path.join(out, "checker", "check.py") + " selftest      (and read " + os.path.join(out, "README.md") + ")")
            return 0
        bad = verify_bundle(a.dir, a.selftest, a.unsandboxed)
        print("bundle OK" if not bad else "bundle PROBLEMS:\n  " + "\n  ".join(bad))
        return 1 if bad else 0
    except ExportError as e:
        print(str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
