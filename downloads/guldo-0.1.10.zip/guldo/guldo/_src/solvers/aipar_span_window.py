"""aipar in the work-and-span counted API, CHEAT: a Hillis-Steele scan stopped after three levels, so each h_t sums only the last 8 steps. Shallow and cheap, and wrong: the channels' memory is
far longer than 8 steps, so the judge must reject it."""
import tensorops as tp


def solve(seed, T, C):
    A = tp.reshape(tp.stream(seed, 0, T * C), (T, C)) * 0.049 + 0.95
    B = tp.reshape(tp.stream(seed, T * C, T * C), (T, C))
    s = 1
    while s < 8:
        Ap = tp.concat([tp.zeros((s, C)) + 1.0, A[0:T - s]], 0)
        Bp = tp.concat([tp.zeros((s, C)), B[0:T - s]], 0)
        B = A * Bp + B
        A = A * Ap
        s *= 2
    return list(map(int, (tp.reshape(B, (T * C,)) * 1073741824.0).tolist()))
