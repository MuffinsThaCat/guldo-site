"""Keep the published certificate log fresh: sign a heartbeat head, rebuild ONLY the Log page and /log, check them, deploy, check the live site. Run: python3 log_refresh.py

The published log is static files, so nothing else refreshes its head, and a reader's freshness check (`guldo log check --max-age-hours`) starts failing after 48 hours. This is the stand-in for
deploy/log-heartbeat.timer until the log runs on a server. It changes nothing except log.html and log/ in the site folder: other pages (including another session's unreviewed work in the
build) are never republished by it. It fails closed: a log that does not verify before the deploy is not deployed, and a live log that does not verify afterwards exits non-zero.

Needs: the operator key (outside the log directory), the Vercel CLI logged in, and the site folder ~/guldo-site (DEPLOY_SITE.md). No git."""
import argparse
import fcntl
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
HOME = os.path.expanduser("~")
LOG = os.path.join(HOME, "guldo-log")
KEY = os.path.join(HOME, ".guldo-operator.key")
SITE = os.path.join(HOME, "guldo-site")
LIVE = "https://guldo.org/log"
ARCHIVE_URL = LIVE + "/checkpoint.json"
# Not secrets: they name the Vercel project (DEPLOY_SITE.md). This CLI version refuses --scope in non-interactive mode, so the IDs go in the environment.
VERCEL_ENV = {"VERCEL_ORG_ID": "team_qZuBQHG3IO2GXGmydla4GfyL", "VERCEL_PROJECT_ID": "prj_r8iNQZFarkY9NTrg2KahoafJto4V"}
DEPLOY_TIMEOUT = 600


class RefreshError(Exception):
    pass


def default_run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def log_key(log_dir):
    import json
    with open(os.path.join(log_dir, "log.json"), encoding="utf-8") as f:
        return json.load(f)["pubkey"]


def step(run, what, cmd, **kw):
    try:
        r = run(cmd, **kw)
    except subprocess.TimeoutExpired:
        raise RefreshError(f"{what}: did not finish in time")
    if r.returncode != 0:
        tail = ((r.stderr or "") + (r.stdout or "")).strip().splitlines()[-3:]
        raise RefreshError(f"{what}: exit {r.returncode}: " + " | ".join(tail)[:400])
    return r


def best_effort(run, what, cmd, warnings, **kw):
    """A step whose failure is reported but never stops the refresh: the third parties it talks to (public calendars, the Internet Archive) are outside our control and often throttle."""
    try:
        r = run(cmd, **kw)
    except subprocess.TimeoutExpired:
        warnings.append(f"{what}: did not finish in time")
        return None
    if r.returncode != 0:
        tail = ((r.stdout or "") + (r.stderr or "")).strip().splitlines()[-2:]
        warnings.append(f"{what}: exit {r.returncode}: " + " | ".join(t.strip() for t in tail)[:300])
    return r


def refresh(log_dir=LOG, key=KEY, site=SITE, live=LIVE, run=default_run, deploy=True, py=sys.executable, workdir=None, now=time.time, anchors=True, archive_url=ARCHIVE_URL):
    """One refresh. Returns a one-line summary; raises RefreshError on any failure of the log's own integrity (nothing is deployed after a failure before the deploy step).
    With anchors=True the head is also timestamped in Bitcoin and pending timestamps are upgraded BEFORE the build (so the published proofs are current), and after a verified deploy the
    Internet Archive is asked to keep a copy of checkpoint.json. Those steps are best effort: their failures are warnings in the summary, never a reason to withhold a heartbeat."""
    pub = log_key(log_dir)
    own = workdir is None
    work = workdir or tempfile.mkdtemp(prefix="guldo-refresh-")
    warnings = []
    tl = os.path.join(HERE, "translog.py")
    anchors = anchors and deploy         # a dry run (--no-deploy) contacts no third party: stamping sends the head's hash to public calendars, and the Archive step fetches our live site
    try:
        step(run, "sign a heartbeat head", [py, tl, "sign", log_dir, "--key", key])
        if anchors:
            best_effort(run, "timestamp the head in Bitcoin", [py, tl, "anchor-ots", log_dir], warnings, timeout=180)
            best_effort(run, "upgrade pending Bitcoin timestamps", [py, tl, "anchor-upgrade", log_dir], warnings, timeout=180)
        out = os.path.join(work, "build")
        step(run, "build the Log page", [py, os.path.join(HERE, "build_site.py"), "--out", out, "--cname", "guldo.org", "--log", log_dir], cwd=HERE)
        for need in ("log.html", os.path.join("log", "checkpoint.json"), os.path.join("log", "entries.jsonl")):
            if not os.path.exists(os.path.join(out, need)):
                raise RefreshError(f"the build did not produce {need}")
        step(run, "check the log before deploying it", [py, os.path.join(HERE, "translog.py"), "check", "--log", os.path.join(out, "log"), "--log-key", pub, "--recheck"])
        if not deploy:
            return "built and checked locally (deploy skipped)" + ("; WARNINGS (nothing blocked): " + " ;; ".join(warnings) if warnings else "")
        if not os.path.isdir(site):
            raise RefreshError(f"the site folder {site} does not exist")
        shutil.copy2(os.path.join(out, "log.html"), os.path.join(site, "log.html"))
        dst = os.path.join(site, "log")
        shutil.rmtree(dst, ignore_errors=True)
        shutil.copytree(os.path.join(out, "log"), dst)
        stage = os.path.join(work, "deploy")
        shutil.copytree(site, stage, ignore=shutil.ignore_patterns(".git", ".vercel"))
        env = dict(os.environ, **VERCEL_ENV)
        step(run, "deploy", ["vercel", "deploy", "--prod", "--yes"], cwd=stage, env=env, timeout=DEPLOY_TIMEOUT)
        step(run, "check the LIVE log", [py, os.path.join(HERE, "translog.py"), "check", "--log", live, "--log-key", pub, "--recheck"], timeout=300)
        if anchors and archive_url:
            best_effort(run, "ask the Internet Archive to keep a copy of the head", [py, tl, "archive-save", log_dir, "--url", archive_url], warnings, timeout=420)
        return "refreshed, deployed and the live log verifies" + ("; WARNINGS (nothing blocked): " + " ;; ".join(warnings) if warnings else "")
    finally:
        if own:
            shutil.rmtree(work, ignore_errors=True)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--no-deploy", action="store_true", help="sign, build and check locally; publish nothing")
    ap.add_argument("--no-anchors", action="store_true", help="skip the Bitcoin timestamp and the Internet Archive copy (a heartbeat and a deploy only)")
    ap.add_argument("--force-laptop", action="store_true", help="run even though the log is hosted (see LOG.md, Hosting). Signing from a second place forks the log's story: only for an emergency, after a fresh `log_blob.py pull`")
    ap.add_argument("--log", default=LOG)
    ap.add_argument("--key", default=KEY)
    ap.add_argument("--site", default=SITE)
    a = ap.parse_args(argv)
    if os.path.exists(os.path.join(HOME, ".guldo", "log-hosted")) and not a.force_laptop:
        print("log_refresh: this log is hosted (the heartbeat runs on the website's own hosting; the store is the source of truth). Signing from this machine too would fork the log's story. "
              "Nothing done. See LOG.md, Hosting; --force-laptop overrides.", file=sys.stderr)
        return 2
    os.makedirs(os.path.join(HOME, ".guldo"), exist_ok=True)
    lock = open(os.path.join(HOME, ".guldo", "log-refresh.lock"), "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("log_refresh: another refresh is running; nothing done", file=sys.stderr)
        return 0
    stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    try:
        msg = refresh(a.log, a.key, a.site, deploy=not a.no_deploy, anchors=not a.no_anchors)
    except RefreshError as e:
        print(f"{stamp} FAILED {e}", file=sys.stderr)
        return 1
    print(f"{stamp} OK {msg}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
