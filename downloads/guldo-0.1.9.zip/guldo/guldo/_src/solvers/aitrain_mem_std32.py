"""aitrain with bytes counted (tflops_mem.py), TECHNIQUE: the same method as aitrain_flops_std (scale every feature to unit size, 40 gradient steps) but with the features, labels
and weights held in fp32. The operations are the same; the bytes moved are about half."""
import math

import tensorops as tp

K = 3
KAPPA = 30.0
STEPS = 40
LR = 1.0


def solve(seed, d, n, labels):
    sc = tp.tensor([math.exp(-j * math.log(KAPPA) / (d - 1)) for j in range(d)])
    X = tp.reshape(tp.stream(seed, 0, n * d), (n, d)) * sc
    inv = 1.0 / tp.sqrt(tp.mean(X * X, 0))
    Xs = tp.cast(X * inv, "fp32")
    Y = tp.cast(tp.tensor([[1.0 if labels[i] == k else 0.0 for k in range(K)] for i in range(n)]), "fp32")
    Xt = tp.transpose(Xs, (1, 0))
    W = tp.cast(tp.zeros((d, K)), "fp32")
    for step in range(STEPS):
        Z = Xs @ W
        E = tp.exp(Z - tp.max(Z, 1, True))
        W = W - (Xt @ (E / tp.sum(E, 1, True) - Y)) * (LR / n)
    return [int(x * 1048576.0) for x in tp.reshape(W * tp.reshape(inv, (d, 1)), (d * K,)).tolist()]
