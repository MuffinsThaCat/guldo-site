"""Declaration of an activation-checkpointing domain: compute the EXACT gradient of a deep unrolled network's loss with respect to its shared weight, using as little peak memory as you can.

size = L, the number of unrolled steps (the depth). The model is a residual ReLU recurrence with one shared weight matrix W (w x w, w = 24) applied to a batch of B = 48 vectors:
    h_0 = X,      h_{t+1} = h_t + ALPHA * relu(h_t @ W)   (t = 0 .. L-1),      ALPHA = 0.5 / L,      loss = 0.5 * mean over the B*w entries of (h_L - T)^2.
X (B x w), W (w x w, scaled by sqrt(3/w)) and the target T (B x w) are the SplitMix64 stream under `seed` (the same floats as domains/aiinfer: X first, then W, then T). The answer is dLoss/dW (w x w) as a
flat list of w*w INTEGERS, row-major, in units of 2^-40. The judge recomputes the gradient in float64 and accepts an answer within 1e-6 of its Frobenius norm. That is the "equivalent result" the
saving is conditional on: a truncated backward pass (gradient through only the last k steps), a gradient of the wrong sign or scale, or a stale activation fails the check.

Backpropagation needs the activations of the forward pass. The straightforward way keeps all L of them (and each step's ReLU mask), so peak memory grows linearly with L. ACTIVATION CHECKPOINTING keeps
only every s-th activation, and recomputes each segment's forward pass from its checkpoint just before that segment's backward pass: peak memory about L/s + 2s activations instead of 2L, for one extra
forward pass of arithmetic (about a third more operations). With s about sqrt(L/2) the footprint falls like sqrt(L). The cost compared is PEAK MEMORY (tflops_mem.py: the most bytes of tensors alive at one
instant, a view counted as a copy), with operations and bytes moved shown beside it: it is an accounting convention anyone can recompute exactly, not a measurement of any allocator or device. Checkpointing
buys CAPACITY, not speed: it also moves more bytes (the recomputed activations are written and read again), so when everything fits in memory the store-everything version is at least as fast on every device the roofline
covers, and roofline.py says so exactly. The reason to checkpoint is a model or a batch that would not otherwise fit.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aickpt"
VERSION = "aickpt-v1"         # bump whenever derive() or the task definition changes
SPEEDUP = "ai-training"
SIZE_RANGE = (16, 64)
SIZE_STEP = 16
REFERENCE_SOLVER = "reference.py"
WIDTH = 24
BATCH = 48
SCALE = 2 ** 40               # the answer's integers are gradient entries in units of 1/SCALE
LIMIT = 2 ** 62
REL_TOL = 1e-6                # the answer must be within REL_TOL * |true gradient|_F (plus the rounding of the integers) of the true gradient
DOC = ("solve(seed, L, w, B): X, W, T are the SplitMix64 stream under `seed` (tensorops.stream, in that order: X is B x w at offset 0, W is w x w at offset B*w scaled by sqrt(3/w), "
       "T is B x w at offset B*w + w*w). Run h_0 = X, h_{t+1} = h_t + (0.5/L) * relu(h_t @ W) for t = 0..L-1, loss = 0.5 * mean((h_L - T)^2) over its B*w entries, and return the gradient "
       "dLoss/dW as a flat list of w*w integers, row-major, in units of 2^-40, within 1e-6 of its norm. Return None for no answer.")
REFERENCE_NOTE = ("Store every activation and ReLU mask of the forward pass, then run the backward pass over them: peak memory about 2L activations. Known to be beaten on peak memory by activation "
                  "checkpointing (about sqrt(L) activations, for one extra forward pass of operations) and by recomputing everything (minimal memory, quadratic operations).")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _parts(seed, L, w=WIDTH, B=BATCH):
    X = _uniform(seed, 0, B * w).reshape(B, w)
    W = _uniform(seed, B * w, w * w).reshape(w, w) * math.sqrt(3.0 / w)
    T = _uniform(seed, B * w + w * w, B * w).reshape(B, w)
    return X, W, T


def gradient(seed, L, w=WIDTH, B=BATCH):
    """The exact gradient dLoss/dW in float64 (store-everything backpropagation)."""
    X, W, T = _parts(seed, L, w, B)
    alpha = 0.5 / L
    hs, ms, h = [X], [], X
    for _ in range(L):
        a = h @ W
        ms.append((a > 0).astype(np.float64))
        h = h + alpha * np.maximum(a, 0.0)
        hs.append(h)
    delta = (h - T) / (B * w)
    dW = np.zeros((w, w))
    for t in range(L - 1, -1, -1):
        gm = delta * ms[t]
        dW += alpha * (hs[t].T @ gm)
        delta = delta + alpha * (gm @ W.T)
    return dW


def _seed(master, size, idx):
    return int.from_bytes(hmac.new(master, f"aickpt-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = _seed(master, size, idx)
    dW = gradient(seed, size)
    return {"args": [seed, size, WIDTH, BATCH], "planted": [int(v) for v in np.rint(dW.ravel() * SCALE)]}


def verify(inst: dict, ans) -> bool:
    seed, L, w, B = inst["args"]
    if not isinstance(ans, list) or len(ans) != w * w:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    true = gradient(seed, L, w, B)
    got = np.array(ans, dtype=np.float64).reshape(w, w) / SCALE
    return bool(np.linalg.norm(got - true) <= REL_TOL * np.linalg.norm(true) + w * 2.0 ** -40)
