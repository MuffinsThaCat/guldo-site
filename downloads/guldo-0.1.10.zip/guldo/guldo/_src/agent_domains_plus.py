"""Extra task domains, registered WITHOUT editing agent_core.py, agent_harness.py or the existing domain files.

Why this module exists. Every ladder records the hashes of agent_core.py, agent_harness.py and its domain's file (`agent_core.source_hashes`), and verification refuses a ladder whose hashes differ from the
files on disk. The committed real-run evidence (agent_eval/real_runs_*/) therefore stays verifiable only while those files are byte-for-byte what it was produced with. A new domain would normally mean
adding its name to the registry tuple INSIDE agent_core.py, which would silently invalidate all of that evidence. So the registry is extended here, at import time, instead: this module appends the names
to `agent_core.BASE_DOMAIN_NAMES`/`DOMAIN_NAMES` (every reader looks them up as attributes, so the change is seen everywhere) and attaches each domain's scripted test agent to
`agent_providers.ScriptedAgent`. Every module that loads a ladder's domain by NAME imports it (agent_eval, agent_site, agent_witness, agent_attest, agent_safety, agent_proxy; the others reach it through
agent_eval), and test_frozen_evidence.py fails if a module that does so does not, and the moment a pinned file changes.

A domain added this way is NOT sealed-capable (its wording is public, like dataanalysis, toolstate and coding): sealing needs entries in agent_core's own tables.
"""
import agent_core

EXTRA_DOMAINS = ("reconcile",)


def _reconcile(self, prompt, messages, n):
    """The scripted agent for the reconcile domain. lean: read page 1 of each list, then every other page in ONE reply, then submit. bare: one page a turn. cheat: submit nothing useful."""
    from agent_domains import reconcile
    if self.style == "cheat":
        return "", [self._submit("[]")]
    have = {"bank": {}, "books": {}}
    total = {}
    for call, content in self._call_results(messages):
        if call["name"] == "page":
            got = reconcile.parse_page(content) if not content.startswith("error") else None
            if got:
                source, number, pages, rows = got
                have[source][number] = rows
                total[source] = pages
    wanted = [(s, k) for s in ("bank", "books") for k in range(1, total.get(s, 1) + 1) if k not in have[s]]
    if wanted:
        calls = [{"name": "page", "args": {"source": s, "number": k}} for s, k in wanted]
        if self.style == "bare":
            calls = calls[:1]
        return "", calls
    side = {s: {ref: cents for rows in have[s].values() for ref, cents, _d in rows} for s in have}
    found = []
    for ref in sorted(set(side["bank"]) | set(side["books"])):
        if ref not in side["books"]:
            found.append({"ref": ref, "kind": "missing_in_books"})
        elif ref not in side["bank"]:
            found.append({"ref": ref, "kind": "missing_in_bank"})
        elif side["bank"][ref] != side["books"][ref]:
            found.append({"ref": ref, "kind": "amount_differs"})
    if self._fails():                                                              # failure injection, as the other scripted agents do: an answer that is wrong
        found = found[1:] if found else [{"ref": "P00000", "kind": "amount_differs"}]
    import json
    return "", [self._submit(json.dumps(found))]


_SOLVERS = {"reconcile": _reconcile}


def register():
    """Idempotent. Adds the extra names to the registry and attaches their scripted agents."""
    for name in EXTRA_DOMAINS:
        if name not in agent_core.BASE_DOMAIN_NAMES:
            agent_core.BASE_DOMAIN_NAMES = agent_core.BASE_DOMAIN_NAMES + (name,)
    agent_core.DOMAIN_NAMES = agent_core.BASE_DOMAIN_NAMES + tuple(n + agent_core.SEALED_SUFFIX for n in agent_core.SEALED_CAPABLE)
    import agent_providers
    for name, fn in _SOLVERS.items():
        if not hasattr(agent_providers.ScriptedAgent, "_" + name):
            setattr(agent_providers.ScriptedAgent, "_" + name, fn)


register()
