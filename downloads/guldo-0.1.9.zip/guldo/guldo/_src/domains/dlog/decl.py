"""Declaration of a domain the compiler was NOT written for: discrete logarithms in Z_p^*, by exhaustive search.

A solver receives (p, g, h) and returns any exponent x with g^x = h (mod p). size = the bit length of the planted exponent, so the
reference's linear scan costs ~2^size steps and every extra bit doubles it; a baby-step/giant-step solver is the speedup this
domain exists to certify (about size/2 bits at large sizes). Judge-side, the verifier is one modular exponentiation.
"""
import hashlib
import hmac
import random

import instances  # the project's Miller-Rabin test

NAME = "dlog"
VERSION = "dlog-v1"           # bump whenever derive() changes
SIZE_RANGE = (16, 40)         # sizes (exponent bits) the compiler may use
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
DOC = "solve(p, g, h): return an integer x with pow(g, x, p) == h, 0 <= x < p - 1. Any valid x counts; return None for no answer."


def _prime(rng, bits):
    while True:
        c = rng.getrandbits(bits) | (1 << (bits - 1)) | 1
        if instances._is_prime(c):
            return c


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"dlog-v1:{size}:{idx}".encode(), hashlib.sha256).digest())
    p = _prime(rng, size + 2)
    while True:
        g = rng.randrange(2, p - 1)
        x = rng.randrange(1, 1 << size)
        if x < p - 1:
            break
    return {"args": [p, g, pow(g, x, p)], "planted": x}


def verify(inst: dict, ans) -> bool:
    p, g, h = inst["args"]
    return isinstance(ans, int) and not isinstance(ans, bool) and 0 <= ans < p - 1 and pow(g, ans, p) == h
