"""Reference for aidistill: the whole 4-member teacher on the whole batch, float64, one batched product per layer per member."""
import math

import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, Q):
    H, o, members = 4 * d, 0, []
    for _ in range(4):
        W1 = _uniform(seed, o, H * d).reshape(H, d) * math.sqrt(3.0 / d)
        o += H * d
        b = _uniform(seed, o, H) + 1.0
        o += H
        W2 = _uniform(seed, o, 10 * H).reshape(10, H) * math.sqrt(3.0 / H) / 4
        o += 10 * H
        members.append((W1, b, W2))
    X = _uniform(seed, o, Q * d).reshape(Q, d)
    L = sum(np.maximum(X @ W1.T + b, 0.0) @ W2.T for W1, b, W2 in members)
    return [int(v) for v in np.argmax(L, axis=1)]
