"""Reference for aimoe: dense float64 mixture of experts with top-2 gating.

The model definition (the contract a submission must reproduce): SplitMix64 counter stream under `seed`, element k = finalise((k+1)*GOLD + seed), mapped to [-1, 1) as
(z >> 11) * 2^-52 - 1. Stream layout, in order: X (n x 32, scale 1), router Wg (32 x 8, scale 3 sqrt(3/32)), W1 (8 x 32 x 64, scale sqrt(3/32)), W2 (8 x 64 x 32, scale sqrt(3/64)), all row-major.
Token i: scores s = x Wg; the two largest (lowest index on a tie) are the experts; the weights are the softmax of those two scores; the output is the weighted sum of
relu(x W1[e]) W2[e] over the two. The answer is the n x 32 output as integers in units of 2^-16.
"""
import math

import numpy as np

_D, _F, _E = 32, 64, 8


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, n):
    o = 0

    def take(shape, scale):
        nonlocal o
        m = int(np.prod(shape))
        a = (_uniform(seed, o, m) * scale).reshape(shape)
        o += m
        return a
    X = take((n, _D), 1.0)
    Wg = take((_D, _E), 3.0 * math.sqrt(3.0 / _D))
    W1 = take((_E, _D, _F), math.sqrt(3.0 / _D))
    W2 = take((_E, _F, _D), math.sqrt(3.0 / _F))
    S = X @ Wg
    G = np.zeros((n, _E))
    for i in range(n):
        a, b = np.argsort(-S[i], kind="stable")[:2]
        pa = 1.0 / (1.0 + math.exp(S[i, b] - S[i, a]))
        G[i, a], G[i, b] = pa, 1.0 - pa
    out = np.zeros((n, _D))
    for e in range(_E):
        out += G[:, e:e + 1] * (np.maximum(X @ W1[e], 0.0) @ W2[e])
    return [int(v) for v in np.rint(out * 65536.0).ravel()]
