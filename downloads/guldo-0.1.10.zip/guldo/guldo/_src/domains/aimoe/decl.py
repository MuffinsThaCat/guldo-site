"""Declaration of an AI mixture-of-experts domain: run one sparse MoE layer over n tokens, to the same output, with as few operations as you can.

size = n, the number of tokens. Each token is a 32-vector; the layer has a router (32 x 8) and 8 experts, each a two-matrix ReLU network (32 -> 64 -> 32). A token goes to its TWO highest-scoring experts
only, and the output is the sum of those two experts' outputs weighted by a softmax over just those two router scores: the other six experts have exactly zero weight. That is the layer's definition
(top-2 gating, as in Mixtral or Switch-style models), not an approximation of a dense one. Tokens, router and experts are a pure function of one seed through the pinned SplitMix64 stream the other
AI domains use (layout in reference.py), so a counted solver regenerates them with tensorops.stream.

The reference is the unoptimised way to run it: push every token through every expert and mask the results with the gate (zeros for the six unused experts). A solver that routes -- sends each
token only to the two experts that have weight on it, in a batch per expert -- does a quarter of the expert arithmetic (2 of 8 experts) with the same output, and the saving does not depend on n.
The speedup is in OPERATIONS, so the counted mode (tflops.py) certifies it on any machine. The routing decision itself (which two experts) is done with the solver's own Python on the gate scores, and
is charged: one unit per instruction.

The answer is the n x 32 output matrix as a flat list of n*32 INTEGERS, row-major, in units of 2^-16; the judge recomputes the float64 output and accepts iff every entry is within TOL (1e-3).
A solver that uses only the top expert, or drops tokens that overflow an expert's capacity (a real MoE serving practice that changes the output), gets different numbers and fails. That is the
"equivalent output" the saving is conditional on.

What this cannot show: the cost of moving tokens between devices (the all-to-all of expert parallelism), load imbalance on real hardware, or kernel efficiency: it counts the arithmetic.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aimoe"
VERSION = "aimoe-v1"          # bump whenever derive() or the layer definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (256, 1024)
SIZE_STEP = 128
REFERENCE_SOLVER = "reference.py"
D, F, E, TOPK = 32, 64, 8, 2
ROUTER_SCALE = 3.0            # a peaked router: the two chosen experts carry clearly unequal weight, so dropping one is visible
SCALE = 2 ** 16               # the answer's integers are outputs in units of 1/SCALE
TOL = 1e-3
LIMIT = 2 ** 40
DOC = ("solve(seed, n): from the SplitMix64 stream under `seed` (tensorops.stream, layout in domains/aimoe/reference.py) take X (n x 32, scale 1), router Wg (32 x 8, scale 3 sqrt(3/32)), "
       "expert matrices W1 (8 x 32 x 64, scale sqrt(3/32)) and W2 (8 x 64 x 32, scale sqrt(3/64)). Token i goes to its two largest router scores s = X Wg (a, b); its output is "
       "p_a relu(x W1[a]) W2[a] + p_b relu(x W1[b]) W2[b] with (p_a, p_b) the softmax of (s_a, s_b). Return the n x 32 output matrix as a flat list of n*32 integers, row-major, in units of 2^-16; "
       "every entry must be within 1e-3 of the exact value. Return None for no answer.")
REFERENCE_NOTE = ("Dense: every token through all 8 experts, then multiplied by the gate matrix (zero on the six unused experts), in float64. Known to be beaten by routing: a batch of tokens "
                  "per expert, each token only to its two experts. About 4 times fewer expert operations (8 experts down to 2), whatever n is.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _layer(seed, n):
    o = [0]

    def take(shape, scale):
        m = int(np.prod(shape))
        a = (_uniform(seed, o[0], m) * scale).reshape(shape)
        o[0] += m
        return a
    X = take((n, D), 1.0)
    Wg = take((D, E), ROUTER_SCALE * math.sqrt(3.0 / D))
    W1 = take((E, D, F), math.sqrt(3.0 / D))
    W2 = take((E, F, D), math.sqrt(3.0 / F))
    return X, Wg, W1, W2


def _truth(seed, n):
    X, Wg, W1, W2 = _layer(seed, n)
    S = X @ Wg
    top = np.argsort(-S, axis=1, kind="stable")[:, :TOPK]
    sel = np.take_along_axis(S, top, axis=1)
    p = np.exp(sel - sel.max(axis=1, keepdims=True))
    p /= p.sum(axis=1, keepdims=True)
    out = np.zeros((n, D))
    for e in range(E):
        Y = np.maximum(X @ W1[e], 0.0) @ W2[e]
        for s in range(TOPK):
            m = top[:, s] == e
            out[m] += p[m, s:s + 1] * Y[m]
    return out


_CACHE = {}


def _cached_truth(seed, n):
    key = (seed, n)
    if key not in _CACHE:
        if len(_CACHE) >= 4:
            _CACHE.clear()
        _CACHE[key] = _truth(seed, n)
    return _CACHE[key]


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aimoe-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    return {"args": [seed, size], "planted": [int(v) for v in np.rint(_cached_truth(seed, size) * SCALE).ravel()]}


def verify(inst: dict, ans) -> bool:
    seed, n = inst["args"]
    if not isinstance(ans, list) or len(ans) != n * D:
        return False
    if any(isinstance(v, bool) or not isinstance(v, int) or abs(v) > LIMIT for v in ans):
        return False
    got = np.array(ans, dtype=np.float64).reshape(n, D) / SCALE
    return bool(np.max(np.abs(got - _cached_truth(seed, n))) <= TOL)
