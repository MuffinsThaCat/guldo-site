"""Bytes, precision and peak memory for counted solvers: a run-time layer over tensorops.py, used by tflops_mem_runner.py in the counting child process ONLY.

tensorops.py (and the cost model in it) is not modified: `install(tensorops)` wraps its functions and its Tensor class in this process so that, besides the operation count, three more
exact numbers are produced. They are an ACCOUNTING CONVENTION, like the operation table: computed from shapes and declared precisions alone, so anyone re-running the same solver
gets them exactly, on any machine, with no profiler and no GPU. They are not measurements of any memory system.

Precision. Every tensor carries a width in bits, 64 by default (the values are float64). `cast(x, "fp32" | "fp16")` returns a tensor whose values are ROUNDED to that format and whose
width is 32 or 16. The result of an operation is as wide as its widest tensor operand (a Python number has no width) and is rounded to that width, so a solver that works in fp16 gets
fp16 arithmetic results, not float64 ones relabelled: a technique that loses accuracy by lowering precision loses it here too, and the judge's accuracy check sees it. (Products are
accumulated in float64 and then rounded, as a matrix unit accumulating in higher precision does.) Casting costs one operation per element.

Bytes moved. Each operation is charged the bytes it reads and writes, with no cache: elementwise, matmul, einsum, exp, sqrt, relu, sum, max, mean and cast read every tensor operand
once and write the result; stream, zeros, tensor and causal_mask write their result; take reads and writes the gathered rows; concat reads every operand and writes the result;
argmax and tolist read the tensor; reshape, transpose and slicing are views and move nothing; an item assignment moves the bytes it assigns. There is no operator fusion: two
operations are two passes. So the bytes a technique saves are the ones a shape-and-precision accounting can see: lower precision, fewer or smaller passes, smaller tensors.

Peak memory. The most bytes of tensors alive at one instant (width times elements; a view counts as a copy, as in tensorops.py). CPython frees a tensor the moment its last name
goes, so a solver that drops a tensor it no longer needs (`X = 0`) lowers the peak, and the count is deterministic.

What this is not: a time, a kernel measurement, a cache model or a hardware counter. It certifies "fewer bytes / a smaller footprint under these rules", which anyone can recompute.
"""
import numpy as np

BITS = {"fp64": 64, "fp32": 32, "fp16": 16}
_BYTES = [0]
_LIVE = [0]
_PEAK = [0]
_PROFILE = {}      # (flops, bytes) of ONE operation -> how many operations had exactly that cost


def reset():
    _BYTES[0] = _LIVE[0] = _PEAK[0] = 0
    _PROFILE.clear()


def profile():
    """The run's operations grouped by their exact (flops, bytes): [[flops, bytes, count], ...], sorted. Their sums are the run's flops and bytes. A device's time for a sequence of operations is the SUM of each operation's
    roofline time, so two runs with the same totals can differ in speed: this is what roofline.py compares."""
    return [[f, b, n] for (f, b), n in sorted(_PROFILE.items())]


def _note(flops, nbytes):
    if flops or nbytes:
        _PROFILE[(flops, nbytes)] = _PROFILE.get((flops, nbytes), 0) + 1


def counters():
    """(bytes moved, peak live bytes) so far in this process."""
    return _BYTES[0], _PEAK[0]


def _round(a, bits):
    with np.errstate(over="ignore", invalid="ignore"):
        if bits == 32:
            return a.astype(np.float32).astype(np.float64)
        if bits == 16:
            return a.astype(np.float16).astype(np.float64)
    return a


def install(tp):
    """Wrap the tensorops module `tp` in this process. Idempotent only in the sense that it must be called once, before any solver code runs."""
    Base = tp.Tensor

    class MemTensor(Base):
        __slots__ = ("_b",)

        def __del__(self):
            try:
                _LIVE[0] -= self._a.size * self._b // 8
            except (AttributeError, TypeError):      # never registered, or the interpreter is shutting down
                pass
            Base.__del__(self)

    def bits_of(t):
        return getattr(t, "_b", 64)

    def nbytes(t):
        return t._a.size * bits_of(t) // 8

    def tensors_in(args):
        out = []
        for a in args:
            if isinstance(a, Base):
                out.append(a)
            elif isinstance(a, (list, tuple)):
                out += [x for x in a if isinstance(x, Base)]
        return out

    def register(t, bits):
        if bits < 64:
            t._a = _round(t._a, bits)
        t._b = bits
        _LIVE[0] += t._a.size * bits // 8
        if _LIVE[0] > _PEAK[0]:
            _PEAK[0] = _LIVE[0]
        return t

    def widest(ts):
        return max([bits_of(t) for t in ts] or [64])

    def wrap(fn, mode):
        def wrapper(*args, **kw):
            ts = tensors_in(args)
            f0, b0 = tp._FLOPS[0], _BYTES[0]
            r = fn(*args, **kw)
            bits = widest(ts)
            read = sum(nbytes(t) for t in ts) if mode in ("rw", "read") else 0
            if isinstance(r, Base):
                register(r, bits)
                if mode in ("rw", "w"):
                    _BYTES[0] += read + nbytes(r)
                elif mode == "gather":
                    _BYTES[0] += 2 * nbytes(r)
                else:
                    _BYTES[0] += read
            else:
                _BYTES[0] += read
            _note(tp._FLOPS[0] - f0, _BYTES[0] - b0)
            return r
        wrapper.__name__ = getattr(fn, "__name__", "op")
        return wrapper

    def method(fn, mode):
        def wrapper(self, *args):
            return wrap(fn, mode)(self, *args)
        wrapper.__name__ = getattr(fn, "__name__", "op")
        return wrapper

    for name in ("__add__", "__radd__", "__sub__", "__rsub__", "__mul__", "__rmul__", "__truediv__", "__rtruediv__", "__neg__", "__matmul__"):
        setattr(MemTensor, name, method(getattr(Base, name), "rw"))
    setattr(MemTensor, "__getitem__", method(Base.__getitem__, "view"))
    setattr(MemTensor, "tolist", method(Base.tolist, "read"))

    base_setitem = Base.__setitem__

    def setitem(self, k, v):
        key = tp._key(k)
        b0 = _BYTES[0]
        region = self._a[key].size * bits_of(self) // 8
        base_setitem(self, k, v)
        if bits_of(self) < 64:
            self._a[key] = _round(self._a[key], bits_of(self))
        _BYTES[0] += region + (nbytes(v) if isinstance(v, Base) else 0)
        _note(0, _BYTES[0] - b0)
    setattr(MemTensor, "__setitem__", setitem)

    tp.Tensor = MemTensor            # the module's own functions build `Tensor(...)` by global name: from now on they build MemTensors
    for name, mode in (("stream", "w"), ("tensor", "w"), ("zeros", "w"), ("causal_mask", "w"), ("take", "gather"), ("concat", "rw"), ("reshape", "view"), ("transpose", "view"),
                       ("einsum", "rw"), ("exp", "rw"), ("sqrt", "rw"), ("relu", "rw"), ("sum", "rw"), ("max", "rw"), ("mean", "rw"), ("argmax", "read")):
        setattr(tp, name, wrap(getattr(tp, name), mode))

    def cast(x, fmt):
        if not isinstance(x, Base):
            raise TypeError("cast: a Tensor")
        if not isinstance(fmt, str) or fmt not in BITS:
            raise ValueError("cast: 'fp64', 'fp32' or 'fp16'")
        f0, b0 = tp._FLOPS[0], _BYTES[0]
        tp._charge(x._a.size)
        r = MemTensor(x._a.copy())
        register(r, BITS[fmt])
        _BYTES[0] += nbytes(x) + nbytes(r)
        _note(tp._FLOPS[0] - f0, _BYTES[0] - b0)
        return r
    tp.cast = cast
    return MemTensor
