"""Roofline reasoning over EXACT counts: what two techniques' operations say about their speed on ANY device, with no device and no clock.

TWO LEVELS, and the difference matters (an audit found the first had been presented as the second). A run is a SEQUENCE of operations; on a device with balance beta its time is the SUM of each
operation's roofline time, T(beta) = sum over operations of max(f / beta, b) (in byte-times). The functions `sequential` and `summarise` compare two runs' exact operation profiles ([flops, bytes, count]
groups recorded by tflops_mem.py) and decide, in exact rational arithmetic, for which beta each is faster. That is the statement about speed. The older functions that take only TOTAL flops and bytes
(`relation`, `crossover`, `summarise_totals`, `describe_totals`) describe max(total flops / beta, total bytes), which is only a LOWER BOUND on T(beta) (it assumes the operations overlap perfectly); two runs
with identical totals can differ by up to 2x in T(beta) (a compute-only kernel plus a memory-only kernel against two balanced ones), so a verdict from totals is a statement about lower bounds, never about speed.

A kernel cannot finish faster than the larger of its compute time and its memory time: time >= max(flops / F, bytes / B) for a device with peak compute F (flop/s) and memory bandwidth B (byte/s). Divide by
B and the device collapses to ONE number, its balance beta = F / B (flops per byte); measured in byte-times, a workload with `f` flops and `b` bytes takes max(f / beta, b). Everything below is exact
arithmetic on the counted flops and bytes (tflops_mem.py), so anyone can recompute it, and none of it depends on how any particular GPU behaves.

Two exact consequences, the first of which needs no assumption about the device at all:
  * DOMINANCE. If A needs no more flops AND no more bytes than B, then max(fA/beta, bA) <= max(fB/beta, bB) for every beta: A is at least as fast on EVERY device the model covers.
  * CROSSOVER. If A spends more flops to save bytes (fA > fB and bA < bB; recomputation, say), then A is at least as fast exactly when beta >= fA / bB, and slower below that. (Derivation: for beta >= fA/bB
    the compute time fA/beta is at most bB, so A's time is at most bB, which is at most B's; below it, fA/beta exceeds both bB and fB/beta, so A's time exceeds B's.) The symmetric statement holds for B.

What this is NOT: a measurement, a promise about any real kernel (real kernels can fall short of the roofline, fuse operations the count does not, or hit the launch overhead at small sizes), or a model of the
host (Python steps are not tensor work). It is the best a device could possibly do on the counted work, under the counting convention (no cache, no fusion), and the comparison it supports is exact. How well the
roofline form predicts REAL times is a separate, empirical question: gpu_roofline.py measures it on whatever device you have.
"""


def relation(fa, ba, fb, bb):
    """'equal', 'A dominates', 'B dominates' or 'trade-off' for two workloads' (flops, bytes)."""
    a_le = fa <= fb and ba <= bb
    b_le = fb <= fa and bb <= ba
    if a_le and b_le:
        return "equal"
    if a_le:
        return "A dominates"
    if b_le:
        return "B dominates"
    return "trade-off"


def crossover(fa, ba, fb, bb):
    """-> {"relation", "balance", "faster_above"}. For a trade-off, `balance` is the device balance (flops per byte) at which the two tie, and `faster_above` is the side that wins on every device whose balance
    is at least that (the side that spends flops to save bytes); below it the other side wins. Otherwise both are None."""
    rel = relation(fa, ba, fb, bb)
    if rel != "trade-off":
        return {"relation": rel, "balance": None, "faster_above": None}
    if fa > fb and ba < bb:
        return {"relation": rel, "balance": fa / bb, "faster_above": "A"}
    return {"relation": rel, "balance": fb / ba, "faster_above": "B"}


def byte_time(flops, nbytes, balance):
    """The roofline time of a workload on a device of the given balance, in units of 'one byte moved at full bandwidth'."""
    return max(flops / balance, nbytes)


def summarise_totals(per_size):
    """per_size: {size: (fa, ba, fb, bb)} medians for each measured size -> {"relation", "balance", "faster_above", "sizes"}: the verdict over ALL the sizes together.
    A side dominates overall only if it dominates (or ties) at every size; a trade-off overall reports the largest crossover balance when every size trades off the same way, and 'mixed' otherwise."""
    rows = {s: crossover(*v) for s, v in per_size.items()}
    rels = {r["relation"] for r in rows.values()}
    if not rows:
        return {"relation": "none", "balance": None, "faster_above": None, "sizes": {}}
    if rels <= {"equal"}:
        overall = {"relation": "equal", "balance": None, "faster_above": None}
    elif rels <= {"equal", "A dominates"}:
        overall = {"relation": "A dominates", "balance": None, "faster_above": None}
    elif rels <= {"equal", "B dominates"}:
        overall = {"relation": "B dominates", "balance": None, "faster_above": None}
    else:
        sides = {r["faster_above"] for r in rows.values() if r["relation"] == "trade-off"}
        pure = rels <= {"trade-off", "equal"} and len(sides) == 1
        if pure:
            side = next(iter(sides))
            overall = {"relation": "trade-off", "balance": max(r["balance"] for r in rows.values() if r["relation"] == "trade-off"), "faster_above": side}
        else:
            overall = {"relation": "mixed", "balance": None, "faster_above": None}
    overall["sizes"] = rows
    return overall


def describe_totals(overall, a="A", b="B"):
    """One plain sentence for a summarise() result."""
    rel = overall["relation"]
    if rel == "equal":
        return f"{a} and {b} need exactly the same flops and bytes: no device can tell them apart on this count"
    if rel == "A dominates":
        return f"{a} needs no more flops and no more bytes than {b} at every measured size, so it is at least as fast as {b} on every device the roofline model covers"
    if rel == "B dominates":
        return f"{b} needs no more flops and no more bytes than {a} at every measured size, so it is at least as fast as {a} on every device the roofline model covers"
    if rel == "trade-off":
        win, lose = (a, b) if overall["faster_above"] == "A" else (b, a)
        return (f"{win} spends more flops to save bytes: it is at least as fast as {lose} on every device whose peak-flops-to-bandwidth ratio is at least {overall['balance']:.3g} flop/byte, "
                f"and slower on a device below that")
    if rel == "mixed":
        return "neither dominates, and the sizes trade off in different directions: the roofline verdict depends on the device and the size (see the per-size table)"
    return "no paired sizes to analyse"


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- the sequential model
from fractions import Fraction


def _curve(profile, x):
    """T at x = 1/beta, in byte-times: the sum over every operation of max(f * x, b)."""
    return sum(n * max(f * x, b) for f, b, n in profile)


def sequential(pa, pb):
    """Compare two runs' operation profiles ([[flops, bytes, count], ...]) for EVERY device balance, exactly.

    With x = 1 / beta, T_A(x) and T_B(x) are convex piecewise-linear and D = T_A - T_B is piecewise linear with breakpoints at b/f of every operation; so D is decided completely by its values at the breakpoints, its
    value at x = 0 (the memory-bound limit, a device with unbounded compute: sum of bytes) and its slope beyond the last breakpoint (the compute-bound limit: sum of flops). All of it is computed in exact fractions.

    -> {"relation": "equal" | "A dominates" | "B dominates" | "device-dependent", "crossovers": the balances (flop/byte) at which the faster side changes, ascending, "faster_at_high_balance", "faster_at_low_balance"
        ('A', 'B' or 'tie': the side that is faster on a device with enormous compute, i.e. fewer total bytes; and on one with enormous bandwidth, i.e. fewer total flops)}.
    "A dominates" means T_A(beta) <= T_B(beta) for every beta > 0."""
    pa = [(int(f), int(b), int(n)) for f, b, n in pa]
    pb = [(int(f), int(b), int(n)) for f, b, n in pb]
    pts = sorted({Fraction(b, f) for f, b, n in pa + pb if f > 0 and b > 0})
    xs = [Fraction(0)] + pts
    ds = [_curve(pa, x) - _curve(pb, x) for x in xs]
    slope_right = sum(f * n for f, b, n in pa) - sum(f * n for f, b, n in pb)
    crossings = []                                                        # values of x where D changes sign
    for (x1, d1), (x2, d2) in zip(zip(xs, ds), zip(xs[1:], ds[1:])):
        if d1 * d2 < 0:
            crossings.append(x1 + (x2 - x1) * d1 / (d1 - d2))
    if ds and ds[-1] * slope_right < 0:
        crossings.append(xs[-1] - ds[-1] / slope_right)
    signs = {(-1 if d < 0 else 1 if d > 0 else 0) for d in ds} | {(-1 if slope_right < 0 else 1 if slope_right > 0 else 0)}
    if signs == {0}:
        rel = "equal"
    elif signs <= {-1, 0} and not crossings:
        rel = "A dominates"
    elif signs <= {1, 0} and not crossings:
        rel = "B dominates"
    else:
        rel = "device-dependent"
    side = lambda v: "A" if v < 0 else "B" if v > 0 else "tie"
    return {"relation": rel, "crossovers": sorted(float(f"{float(1 / x):.9g}") for x in crossings if x > 0),
            "faster_at_high_balance": side(ds[0]), "faster_at_low_balance": side(slope_right), "kernels": [sum(n for _, _, n in pa), sum(n for _, _, n in pb)]}


def summarise(pairs_by_size):
    """pairs_by_size: {size: [(profile_A, profile_B), ...]} for every instance both solved -> the verdict over ALL instances at ALL sizes: dominance only if it holds on every one of them (one reversed
    instance is enough to refuse it), else 'device-dependent' with the range of crossover balances and, where every instance agrees, the side that wins at each extreme."""
    rows = {s: [sequential(a, b) for a, b in v] for s, v in pairs_by_size.items() if v}
    allrows = [r for v in rows.values() for r in v]
    if not allrows:
        return {"model": "sequential", "relation": "none", "crossovers": [], "instances": 0, "sizes": {}}
    rels = {r["relation"] for r in allrows}
    counts = {rel: sum(r["relation"] == rel for r in allrows) for rel in sorted(rels)}
    if rels <= {"equal"}:
        rel = "equal"
    elif rels <= {"equal", "A dominates"}:
        rel = "A dominates"
    elif rels <= {"equal", "B dominates"}:
        rel = "B dominates"
    else:
        rel = "device-dependent"
    cross = sorted(c for r in allrows for c in r["crossovers"])
    same = lambda key: (lambda vals: next(iter(vals)) if len(vals) == 1 else "varies")({r[key] for r in allrows})
    return {"model": "sequential", "relation": rel, "relations": counts, "instances": len(allrows), "crossovers": cross[:1] + cross[-1:] if cross else [],
            "faster_at_high_balance": same("faster_at_high_balance"), "faster_at_low_balance": same("faster_at_low_balance"),
            "kernels": [allrows[0]["kernels"][0], allrows[0]["kernels"][1]] if len({tuple(r["kernels"]) for r in allrows}) == 1 else "varies",
            "sizes": {s: {rel_: sum(r["relation"] == rel_ for r in v) for rel_ in sorted({r["relation"] for r in v})} for s, v in rows.items()}}


def describe(overall, a="A", b="B"):
    """One plain sentence for a summarise() result."""
    rel = overall["relation"]
    tail = " (kernels run one after another, each limited by the larger of its compute time and its memory time; launch overhead is not modelled)"
    if rel == "equal":
        return f"{a} and {b} have identical operation profiles: no roofline device can tell them apart{tail}"
    if rel == "A dominates":
        return f"{a} is at least as fast as {b} on every roofline device at every paired instance{tail}"
    if rel == "B dominates":
        return f"{b} is at least as fast as {a} on every roofline device at every paired instance{tail}"
    if rel == "device-dependent":
        parts = []
        hi, lo = overall.get("faster_at_high_balance"), overall.get("faster_at_low_balance")
        name = {"A": a, "B": b}
        if hi in name and lo in name and hi != lo:
            parts.append(f"{name[hi]} is faster on devices with high compute for their bandwidth (it moves fewer bytes) and {name[lo]} on devices with low compute (it needs fewer flops)")
        if overall.get("crossovers"):
            c = overall["crossovers"]
            parts.append("the faster side changes at " + (f"{c[0]:.3g} flop/byte" if len(c) == 1 or c[0] == c[-1] else f"balances between {c[0]:.3g} and {c[-1]:.3g} flop/byte, depending on the instance"))
        return "neither wins on every device: " + "; ".join(parts or ["the verdict depends on the device"]) + tail
    return "no paired instances to analyse"
