"""Critical-path DEPTH for counted solvers: a run-time layer over tensorops.py, used by tflops_par_runner.py in the counting child process ONLY.

tensorops.py (and its cost table) is not modified: `install(tensorops)` wraps its functions and its Tensor class in this process so that, besides the operation count, one more exact number is
produced: the DEPTH of the run, the length of the longest chain of tensor operations in which each one needs the result of the one before. It is the number of time steps an idealised parallel machine
with unlimited processors would need, one step per layer of operations. Like the operation table it is an ACCOUNTING CONVENTION computed from shapes and data dependencies alone: anyone re-running the
same solver gets it exactly, on any machine, with no profiler, no threads and no hardware.

How depth is assigned (every tensor carries one number, the depth of the operation that made it; constants start at 0):
  elementwise  + - * / neg exp sqrt relu       1 + the deepest operand
  matmul       (..., m, k) @ (k, n)            1 + ceil(log2 k) + the deepest operand   (one layer of products, then a balanced tree of k-term sums)
  einsum       two operands                    1 + ceil(log2 c) + the deepest operand, c = the product of the summed-out index extents
  sum max mean over n elements                 ceil(log2 n) + the operand's depth       (a balanced tree; n = 1 adds nothing)
  stream tensor take concat                    1 + the deepest operand (stream/tensor/take: or the host depth, below)
  zeros causal_mask                            the host depth
  reshape transpose slicing                    the operand's depth (they make a COPY here, so a write into a slice can never change its parent behind the counter's back)
  item assignment  x[k] = v                    x becomes 1 + max(x's depth, v's depth)   (depth is kept per TENSOR, not per element: a loop that writes rows one by one is one long chain.
                                               Build results with concat instead if the writes are independent)
THE HOST. Reading a value into Python (item, tolist, argmax) is a synchronisation: whatever Python then does may depend on everything read so far. The run keeps one number, the deepest value
read, and every operation that takes a Python number or list as an operand (a scalar multiply, stream, tensor, take, zeros) is at least that deep. So a dependency cannot be hidden by passing it
through Python; the price is that a solver which reads values back every iteration pays for it, as on a real device.

This is a CONSERVATIVE bound on the span: the true data-dependence depth is never larger than the number reported (per-tensor granularity and the host rule only ever add), so a solver cannot make
itself look more parallel than it is. It can look LESS parallel than it is: a solver that writes independent rows into one tensor one by one is charged a chain.

What this is not: a time, a thread count, a model of communication, synchronisation cost, load imbalance or memory contention. See tflops_par.py for what the work and the depth together bound.
"""
import re

import numpy as np

_MAXD = [0]        # the deepest operation of the run
_HOST = [0]        # the deepest value read back into Python so far


def reset():
    _MAXD[0] = 0
    _HOST[0] = 0


def counters():
    """The depth of the run so far: the deepest operation anywhere (dead code included: it could run alongside the rest, so it only matters if it is deeper)."""
    return _MAXD[0]


def clog2(n):
    return 0 if n <= 1 else (int(n) - 1).bit_length()


def install(tp):
    """Wrap the tensorops module `tp` in this process, once, before any solver code runs."""
    Base = tp.Tensor

    class ParTensor(Base):
        __slots__ = ("_d",)

        def __init__(self, a):
            Base.__init__(self, a)
            self._d = 0

    def dep(x):
        return x._d if isinstance(x, ParTensor) else None

    def done(r, d):
        r._d = d
        if d > _MAXD[0]:
            _MAXD[0] = d
        return r

    def read(d):
        if d > _HOST[0]:
            _HOST[0] = d

    def operand_depth(*xs):
        """The deepest of the operands; a Python number counts as the host depth."""
        out = 0
        for x in xs:
            d = dep(x)
            out = max(out, _HOST[0] if d is None else d)
        return out

    def binop(name):
        fn = getattr(Base, name)

        def wrapper(self, o):
            r = fn(self, o)
            return done(r, 1 + operand_depth(self, o))
        return wrapper

    for name in ("__add__", "__radd__", "__sub__", "__rsub__", "__mul__", "__rmul__", "__truediv__", "__rtruediv__"):
        setattr(ParTensor, name, binop(name))

    base_neg, base_matmul, base_getitem, base_setitem = Base.__neg__, Base.__matmul__, Base.__getitem__, Base.__setitem__
    base_item, base_tolist = Base.item, Base.tolist

    def neg(self):
        return done(base_neg(self), 1 + self._d)

    def matmul(self, o):
        k = self._a.shape[-1] if self._a.ndim else 1
        r = base_matmul(self, o)
        return done(r, 1 + clog2(k) + max(self._d, o._d))

    def getitem(self, k):
        r = base_getitem(self, k)
        r._a = r._a.copy()
        return done(r, self._d)

    def setitem(self, k, v):
        base_setitem(self, k, v)
        d = 1 + max(self._d, _HOST[0] if dep(v) is None else v._d)
        done(self, d)

    def item(self):
        read(self._d)
        return base_item(self)

    def tolist(self):
        read(self._d)
        return base_tolist(self)

    ParTensor.__neg__, ParTensor.__matmul__, ParTensor.__getitem__, ParTensor.__setitem__, ParTensor.item, ParTensor.tolist = neg, matmul, getitem, setitem, item, tolist
    tp.Tensor = ParTensor            # the module's own functions build `Tensor(...)` by global name: from now on they build ParTensors

    def wrap(name, depth_of):
        fn = getattr(tp, name)

        def wrapper(*args, **kw):
            r = fn(*args, **kw)
            if isinstance(r, ParTensor):
                done(r, depth_of(args, kw, r))
            return r
        wrapper.__name__ = name
        setattr(tp, name, wrapper)

    def unary(args, kw, r):
        return 1 + args[0]._d

    def reduce_(args, kw, r):
        x = args[0]
        n = x._a.size // r._a.size if r._a.size else 1
        return x._d + clog2(n)

    def view(args, kw, r):
        r._a = r._a.copy()
        return args[0]._d

    def host(args, kw, r):
        return _HOST[0]

    def host_plus_one(args, kw, r):
        return 1 + _HOST[0]

    def take(args, kw, r):
        return 1 + max(args[0]._d, _HOST[0])

    def concat(args, kw, r):
        return 1 + max([t._d for t in args[0]] or [0])

    def einsum(args, kw, r):
        sa, sb, out = re.match(r"^([a-z]+),([a-z]+)->([a-z]*)$", args[0]).groups()
        ext = {}
        for sub, t in ((sa, args[1]), (sb, args[2])):
            for ch, n in zip(sub, t._a.shape):
                ext[ch] = n
        c = 1
        for ch, n in ext.items():
            if ch not in out:
                c *= n
        return 1 + clog2(c) + max(args[1]._d, args[2]._d)

    for name, f in (("exp", unary), ("sqrt", unary), ("relu", unary), ("sum", reduce_), ("max", reduce_), ("mean", reduce_), ("reshape", view), ("transpose", view),
                    ("stream", host_plus_one), ("tensor", host_plus_one), ("zeros", host), ("causal_mask", host), ("take", take), ("concat", concat), ("einsum", einsum)):
        wrap(name, f)

    base_argmax = tp.argmax

    def argmax(x):
        read(x._d + clog2(x._a.size))
        return base_argmax(x)
    tp.argmax = argmax
    return ParTensor
