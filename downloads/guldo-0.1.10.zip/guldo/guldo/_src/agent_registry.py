"""The verifier's registry: every round it opens, closes or voids, in a signed, hash-chained, append-only file.

WHY. A certificate says "this agent beat that baseline on these instances, p = 0.002". It cannot say how many OTHER rounds the same agent entered and quietly lost: with enough tries, p = 0.05 is
guaranteed. The multiple-comparisons problem is solved by disclosure, and disclosure needs a record the entrant cannot curate. The verifier writes one line when a round OPENS (before any instance is
served: plan hash, seed commitment, arms with their configuration hashes, the joint-seed record), one when it CLOSES (the round log's head, every arm's ladder digest, the results hash), and one when it
is VOIDED (with a reason: a bug, a crash, a withdrawn vendor). A reader asks the registry how many rounds a configuration (or a handle) was entered in, and what became of each. A round that is not
in the registry, or whose open entry came after the evaluation, is not a round this verifier vouches for.

WHAT IT DOES NOT PROVE. That the verifier registered everything: a verifier that runs unregistered rounds is lying by omission, and only the verifier's reputation (and the vendors' own receipts: they
know every session they ran) exposes it. A registry makes honest disclosure checkable and dishonest omission a signed lie when caught, not impossible. Time is the verifier's own clock.

ENTRY  {"seq", "ts", "kind", "data", "prev", "hash", "sig", "pubkey"}   hash = sha256(prev + canonical JSON of the entry without hash/sig); sig = Ed25519 over `hash`.

  python3 agent_registry.py open   --registry F --key K --base B --round R [--joint joint.json]
  python3 agent_registry.py close  --registry F --key K --base B --round R
  python3 agent_registry.py void   --registry F --key K --round R --reason TEXT
  python3 agent_registry.py list   --registry F [--config-sha256 H] [--handle NAME]
  python3 agent_registry.py check  --registry F --trusted KEYS
"""
import argparse
import fcntl
import json
import os
import sys
import time

import agent_core
import agent_sig
from agent_core import canon, sha256_hex

START = "0" * 64
ROUND_KINDS = ("round_open", "round_close", "round_void")
KEY_KINDS = ("key_inception", "key_rotation", "key_retire")
KINDS = ROUND_KINDS + KEY_KINDS


class RegistryError(Exception):
    pass


def read(path):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        out = []
        for ln in f:
            if ln.strip():
                try:
                    out.append(json.loads(ln))
                except ValueError:
                    raise RegistryError("the registry has a line that is not JSON")
    return out


def _entry_hash(e):
    return sha256_hex(e["prev"] + canon({k: v for k, v in e.items() if k not in ("hash", "sig")}))


def append(path, secret, kind, data, now=None):
    """Append one signed entry under an exclusive file lock (two writers cannot fork the chain). Returns the entry."""
    if kind not in KINDS:
        raise RegistryError("unknown kind %r" % kind)
    lock = path + ".lock"
    with open(lock, "a") as lf:
        fcntl.flock(lf, fcntl.LOCK_EX)
        try:
            rows = read(path)
            prev = rows[-1]["hash"] if rows else START
            e = {"seq": len(rows), "ts": round(time.time() if now is None else now, 3), "kind": kind, "data": data, "prev": prev, "pubkey": agent_sig.public_key(secret).hex()}
            e["hash"] = _entry_hash(e)
            e["sig"] = agent_sig.sign(secret, e["hash"].encode("ascii")).hex()
            problems = check(rows + [e], None, _internal=True)
            if problems:
                raise RegistryError("REFUSED: " + problems[0])
            with open(path, "a", encoding="utf-8") as f:
                f.write(canon(e) + "\n")
                f.flush()
                os.fsync(f.fileno())
            return e
        finally:
            fcntl.flock(lf, fcntl.LOCK_UN)


def _commit(pubhex):
    return sha256_hex(bytes.fromhex(pubhex))


def _valid_commit(c, allow_none=True):
    return (c is None and allow_none) or (isinstance(c, str) and len(c) == 64 and all(ch in "0123456789abcdef" for ch in c))


def walk(rows):
    """(problems, terms). Replays the registry as a state machine: the chain, every signature, the ORDER of round events (open, then at most one close or void) and the KEY STATE.

    KEY STATE (pre-rotation, as in KERI): the first entry names the identity's first key and may COMMIT to the hash of the NEXT key (`key_inception`). Every later entry must be signed by the active
    key, except a `key_rotation`, which must be signed by the key whose hash was committed: so a thief of the current key cannot take the identity over, only the holder of the pre-committed key
    can. A rotation commits to the key after it (or to none, which freezes the identity), may declare the old key COMPROMISED from a registry position (`compromised_since`), and is refused while
    any round is open (so every signature of one round, sessions, certificate, open and close, is by ONE key). `key_retire` ends the identity. An old registry with no inception entry is read as an
    identity that can never rotate. `terms` lists each key's term: {key, from_seq, to_seq, compromised_since}."""
    probs, terms = [], []
    prev, state, last_ts = START, {}, 0
    active, next_commit, retired = None, None, False
    for i, e in enumerate(rows):
        try:
            if e.get("seq") != i:
                probs.append("entry %d is numbered %r" % (i, e.get("seq")))
            if e.get("prev") != prev:
                probs.append("entry %d does not follow the one before it" % i)
            if e.get("hash") != _entry_hash(e):
                probs.append("entry %d's hash is not its content's" % i)
            pk = e["pubkey"]
            if not agent_sig.verify(bytes.fromhex(pk), e["hash"].encode("ascii"), bytes.fromhex(e["sig"])):
                probs.append("entry %d's signature is not valid" % i)
            if not isinstance(e.get("ts"), (int, float)) or isinstance(e.get("ts"), bool) or e["ts"] < last_ts:
                probs.append("entry %d's time runs backwards" % i)
            else:
                last_ts = e["ts"]
            kind, data = e.get("kind"), e.get("data")
            if kind not in KINDS or not isinstance(data, dict):
                probs.append("entry %d is not a recognised event" % i)
                prev = e["hash"]
                continue
            if retired:
                probs.append("entry %d comes after the identity was retired" % i)
            if i == 0:
                if kind in ("key_rotation", "key_retire"):
                    probs.append("the first entry cannot be a %s: there is no key to hand over from" % kind[4:])
                active = pk
                next_commit = data.get("next") if kind == "key_inception" else None
                if kind == "key_inception" and not _valid_commit(data.get("next")):
                    probs.append("the inception's next-key commitment is malformed")
                    next_commit = None
                terms.append({"key": pk, "from_seq": 0, "to_seq": None, "compromised_since": None})
            elif kind == "key_inception":
                probs.append("entry %d: an inception is only valid as the first entry" % i)
            if kind == "key_rotation" and i > 0:
                np_, cs = data.get("new_pubkey"), data.get("compromised_since")
                if pk != np_:
                    probs.append("entry %d: a rotation must be signed by the NEW key it names" % i)
                elif next_commit is None or _commit(np_) != next_commit:
                    probs.append("entry %d: the new key is not the one the previous key committed to (a rotation needs the pre-committed key, which a thief of the current key does not have)" % i)
                elif any(v == "open" for v in state.values()):
                    probs.append("entry %d: a key rotation while a round is open" % i)
                elif not _valid_commit(data.get("next")) or not (cs is None or (isinstance(cs, int) and not isinstance(cs, bool) and terms[-1]["from_seq"] <= cs <= i - 1)):
                    probs.append("entry %d: the rotation's next-key commitment or compromise point is malformed" % i)
                else:
                    terms[-1]["to_seq"], terms[-1]["compromised_since"] = i - 1, cs
                    active, next_commit = np_, data.get("next")
                    terms.append({"key": np_, "from_seq": i, "to_seq": None, "compromised_since": None})
            elif i > 0 and pk != active:
                probs.append("entry %d is signed by a key that is not the active key" % i)
            if kind == "key_retire":
                retired = True
                terms[-1]["to_seq"] = i
            if kind in ROUND_KINDS:
                rid = data.get("round")
                if not isinstance(rid, str):
                    probs.append("entry %d names no round" % i)
                elif kind == "round_open":
                    if rid in state:
                        probs.append("entry %d opens round %s a second time" % (i, rid))
                    state[rid] = "open"
                else:
                    if state.get(rid) != "open":
                        probs.append("entry %d %ss round %s, which is %s" % (i, kind[6:], rid, "not open" if rid not in state else state[rid]))
                    state[rid] = "closed" if kind == "round_close" else "void"
            prev = e["hash"]
        except (KeyError, TypeError, ValueError, AttributeError):
            probs.append("entry %d is malformed" % i)
            break
    return probs, terms


def trusted_from(terms, trusted):
    """The first registry position from which the entries are authenticated by YOUR pins: the start of the first key term whose key you pinned (None if none). Pinning a LATER key vouches only for
    its own term onwards: a chain of earlier keys leading to it could have been made up by whoever holds that later key."""
    pins = set(trusted or [])
    starts = [t["from_seq"] for t in terms if t["key"] in pins]
    return min(starts) if starts else None


def term_at(terms, seq):
    for t in terms:
        if t["from_seq"] <= seq and (t["to_seq"] is None or seq <= t["to_seq"]):
            return t
    return None


def check(rows, trusted, _internal=False):
    """Problems with a registry (see `walk`), and, given the keys YOU pinned, whether any of the registry's key terms is one of them. Empty = consistent."""
    probs, terms = walk(rows)
    if not _internal and trusted is not None:
        if not rows:
            probs.append("the registry is empty")
        elif not probs and trusted_from(terms, trusted) is None:
            probs.append("the registry is signed by no key you pinned")
    return probs


def identity_of(rows):
    """The registry's identity: the key it began with (the inception key), which a rotated identity keeps."""
    return rows[0]["pubkey"] if rows else None


def arms_of(base, rid):
    """[{eid, handle, label, spec, config_sha256}] of a round, from its own files."""
    import agent_rounds as AR
    d = AR._require(base, rid)
    r = AR.R._read_json(os.path.join(d, "round.json"))
    out = [{"eid": "baseline", "handle": None, "label": r["baseline"]["label"], "spec": r["baseline"]["agent"], "config_sha256": AR.config_sha(r["baseline"])}]
    for e in AR._entries(d):
        out.append({"eid": e["eid"], "handle": e["handle"], "label": e["config"]["label"], "spec": e["config"]["agent"], "config_sha256": e["config_sha256"]})
    return out, r


def open_data(base, rid, joint_doc=None):
    """The facts an open entry records, from the round's own files (no state check: `open_round` is the guarded way to register)."""
    arms, r = arms_of(base, rid)
    return {"round": rid, "domain": r["domain"], "plan_hash": r["plan_hash"], "commitment": r["commitment"], "practice": r["practice"], "arms": arms,
            "joint_sha256": sha256_hex(canon(joint_doc)) if joint_doc is not None else None}, r["state"]


def open_round(path, secret, base, rid, joint_doc=None, now=None):
    """Register a round BEFORE any instance is served: it must be closed to entries and not yet evaluated. (A verifier that wants to register late has to bypass this on purpose, and the audit
    then reports that the round was registered AFTER it ran.)"""
    import agent_rounds as AR
    import rounds as R
    data, state = open_data(base, rid, joint_doc)
    if state != "closed":
        raise RegistryError("register a round when it is CLOSED (entries fixed) and not yet evaluated: it is %s" % state)
    d = AR._require(base, rid)
    with AR._lock(d):
        if any(e["kind"] == "registered" for e in R.read_log(d)):
            raise RegistryError("round %s is already registered" % rid)
        # RECOVERY: a crash (a full disk, a killed process) between the two writes leaves the registry holding this round's open entry while the round's log lacks the `registered` event, and a plain
        # retry would be refused ("opens the round a second time") with no way forward. If the entry is there, and is exactly what the round says, only the missing log event is written.
        existing = rounds(read(path)).get(rid)
        if existing is not None:
            if existing["open"]["data"] != data or existing["status"] != "open":
                raise RegistryError("the registry already holds a DIFFERENT open entry (or an ended one) for round %s: not completing it" % rid)
            e = existing["open"]
        else:
            e = append(path, secret, "round_open", data, now)
        # the registration also goes into the ROUND'S OWN hash-chained log, so "registered before the first arm ran" is a fact about chain positions (which cannot be back-dated), not about two
        # clocks the same party controls
        R.append_log(d, "registered", {"registry_hash": e["hash"], "registry_seq": e["seq"], "registry_pubkey": e["pubkey"]}, time.time() if now is None else now)
    return e


def close_round(path, secret, base, rid, now=None):
    """Register the outcome of a REVEALED, verifying round."""
    import agent_rounds as AR
    import rounds as R
    problems = AR.verify_round(base, rid)
    if problems:
        raise RegistryError("REFUSED: the round does not verify (%s)" % problems[0])
    d = AR._require(base, rid)
    r = AR.R._read_json(os.path.join(d, "round.json"))
    if r["state"] != "revealed":
        raise RegistryError("close a round after the reveal: it is %s" % r["state"])
    log = R.read_log(d)
    ev = {e["data"]["eid"]: e["data"]["digest"] for e in log if e["kind"] == "evaluated"}
    res = next((e["data"]["results_sha256"] for e in log if e["kind"] == "results"), None)
    return append(path, secret, "round_close", {"round": rid, "log_head": log[-1]["hash"], "log_entries": len(log), "ladder_digests": ev, "results_sha256": res}, now)


def void_round(path, secret, rid, reason, now=None):
    return append(path, secret, "round_void", {"round": rid, "reason": str(reason)[:300]}, now)


# ---- the identity's keys: inception, rotation, retirement ---------------------------------------------------------------------------------------------------

def init_identity(path, secret, next_pubkey=None, now=None):
    """The registry's FIRST entry, committing to the hash of the NEXT key (generate it now, keep it OFFLINE; it is what saves the identity if this key is stolen). `next_pubkey=None` commits to no
    successor: the identity can never rotate. Refused on a registry that already has entries (an old registry without this entry reads as non-rotatable)."""
    if read(path):
        raise RegistryError("the identity must be declared in the FIRST entry; this registry already has entries (it reads as an identity that cannot rotate)")
    return append(path, secret, "key_inception", {"next": _commit(next_pubkey) if next_pubkey else None}, now)


def rotate(path, new_secret, next_pubkey=None, compromised_since=None, now=None):
    """Hand the identity to the pre-committed key. `new_secret` is the NEW key's secret (the pre-committed one): only its holder can do this, which is the point. `compromised_since` is the registry
    position from which the OLD key's entries are no longer vouched for (if it was stolen: audits refuse a round opened or closed at or after it). Refused while any round is open."""
    return append(path, new_secret, "key_rotation", {"new_pubkey": agent_sig.public_key(new_secret).hex(), "next": _commit(next_pubkey) if next_pubkey else None,
                                                    "compromised_since": compromised_since}, now)


def retire(path, secret, now=None):
    """End the identity: nothing may be appended afterwards."""
    return append(path, secret, "key_retire", {}, now)


def rounds(rows):
    """{round id: {"open": entry, "end": entry or None, "status": open|closed|void}}"""
    out = {}
    for e in rows:
        if e["kind"] not in ROUND_KINDS:
            continue
        rid = e["data"]["round"]
        if e["kind"] == "round_open":
            out[rid] = {"open": e, "end": None, "status": "open"}
        elif rid in out:
            out[rid]["end"], out[rid]["status"] = e, ("closed" if e["kind"] == "round_close" else "void")
    return out


def attempts(rows, config_sha256=None, handle=None, domain=None, exclude=None):
    """Every OTHER round in which this configuration (by hash) or handle was entered: [(round id, status, arm)]. This is the disclosure a reader needs to judge one certificate."""
    out = []
    for rid, info in rounds(rows).items():
        if rid == exclude:
            continue
        o = info["open"]["data"]
        if domain is not None and o.get("domain") != domain:
            continue
        for a in o["arms"]:
            if (config_sha256 is not None and a["config_sha256"] == config_sha256) or (handle is not None and a.get("handle") == handle):
                out.append((rid, info["status"], a["eid"]))
    return sorted(out)


def binding(rows, rid):
    """What a certificate may quote about its round from the registry."""
    info = rounds(rows).get(rid)
    if info is None:
        return None
    return {"registry_entries": len(rows), "registry_head": rows[-1]["hash"], "open_hash": info["open"]["hash"], "end_hash": info["end"]["hash"] if info["end"] else None, "status": info["status"]}


def round_problems(rows, base, rid, joint_doc=None):
    """Does the registry's account of round `rid` match the round's own files? (Run on a REVEALED round.) Returns a list of problems."""
    import agent_rounds as AR
    import rounds as R
    info = rounds(rows).get(rid)
    if info is None:
        return ["round %s is not in the registry" % rid]
    probs = []
    o = info["open"]["data"]
    arms, r = arms_of(base, rid)
    if o["plan_hash"] != r["plan_hash"] or o["commitment"] != r["commitment"] or o["domain"] != r["domain"] or o["practice"] != r["practice"]:
        probs.append("the registry's open entry names a different plan, seed commitment or domain than the round")
    if o["arms"] != arms:
        probs.append("the arms the registry recorded at opening are not the round's arms")
    if (o.get("joint_sha256") is None) != (joint_doc is None) or (joint_doc is not None and o["joint_sha256"] != sha256_hex(canon(joint_doc))):
        probs.append("the joint-seed record is not the one registered at opening" if joint_doc is not None else "the round was registered with a joint seed but none was supplied")
    d = AR._require(base, rid)
    log = R.read_log(d)
    reg_at = next((i for i, e in enumerate(log) if e["kind"] == "registered" and e["data"].get("registry_hash") == info["open"]["hash"]), None)
    first_eval = next((i for i, e in enumerate(log) if e["kind"] == "evaluated"), None)
    if reg_at is None:
        probs.append("the round's own log does not record this registration: it was not registered before it ran (or the registry's open entry is not the one the round saw)")
    elif first_eval is not None and reg_at > first_eval:
        probs.append("the round was registered AFTER its first arm was evaluated: not a pre-registration")
    elif log[reg_at]["data"].get("registry_pubkey") != info["open"]["pubkey"]:
        probs.append("the round's log names a different registry key than the registry entry")
    if info["status"] == "void":
        probs.append("the registry says this round was VOIDED: %s" % info["end"]["data"].get("reason"))
    elif info["status"] != "closed":
        probs.append("the registry has no close entry for this round")
    else:
        c = info["end"]["data"]
        heads = [e["hash"] for e in log]
        if c["log_head"] not in heads:
            probs.append("the registry's closing log head is not in the round's log")
        ev = {e["data"]["eid"]: e["data"]["digest"] for e in log if e["kind"] == "evaluated"}
        if c["ladder_digests"] != ev:
            probs.append("the ladder digests the registry recorded at closing are not the round's")
    return probs


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("open", "close", "void", "list", "check"):
        p = sub.add_parser(name)
        p.add_argument("--registry", required=True)
        if name in ("open", "close", "void"):
            p.add_argument("--key", required=True)
            p.add_argument("--round", required=True)
        if name in ("open", "close"):
            p.add_argument("--base", default=".")
        if name == "open":
            p.add_argument("--joint")
        if name == "void":
            p.add_argument("--reason", required=True)
        if name == "list":
            p.add_argument("--config-sha256")
            p.add_argument("--handle")
        if name == "check":
            p.add_argument("--trusted", required=True)
    p = sub.add_parser("init-identity")
    p.add_argument("--registry", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--next-pubkey", help="the public key of the NEXT key (made now, kept offline); omit to make the identity non-rotatable")
    p = sub.add_parser("rotate")
    p.add_argument("--registry", required=True)
    p.add_argument("--new-key", required=True, help="the secret of the PRE-COMMITTED next key")
    p.add_argument("--next-pubkey", help="the public key of the key after this one (omit to freeze the identity)")
    p.add_argument("--compromised-since", type=int, help="registry position from which the old key's entries are no longer vouched for")
    p = sub.add_parser("retire")
    p.add_argument("--registry", required=True)
    p.add_argument("--key", required=True)
    p = sub.add_parser("identity")
    p.add_argument("--registry", required=True)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "init-identity":
            e = init_identity(a.registry, agent_sig.load_secret(a.key), a.next_pubkey)
            print("identity declared: key %s...; %s" % (e["pubkey"][:16], "next key committed" if e["data"]["next"] else "NO successor committed (cannot rotate)"))
            return 0
        if a.cmd == "rotate":
            e = rotate(a.registry, agent_sig.load_secret(a.new_key), a.next_pubkey, a.compromised_since)
            print("rotated to %s... at entry %d" % (e["pubkey"][:16], e["seq"]))
            return 0
        if a.cmd == "retire":
            e = retire(a.registry, agent_sig.load_secret(a.key))
            print("identity retired at entry %d" % e["seq"])
            return 0
        if a.cmd == "identity":
            probs, terms = walk(read(a.registry))
            for t in terms:
                print("key %s...  entries %s..%s%s" % (t["key"][:16], t["from_seq"], "now" if t["to_seq"] is None else t["to_seq"],
                                                       ("  COMPROMISED from entry %d" % t["compromised_since"]) if t["compromised_since"] is not None else ""))
            for p_ in probs:
                print("FAIL  " + p_)
            return 1 if probs else 0
        if a.cmd in ("open", "close", "void"):
            secret = agent_sig.load_secret(a.key)
            if a.cmd == "open":
                joint = None
                if a.joint:
                    with open(a.joint, "r", encoding="utf-8") as jf:
                        joint = json.load(jf)
                e = open_round(a.registry, secret, a.base, a.round, joint)
            elif a.cmd == "close":
                e = close_round(a.registry, secret, a.base, a.round)
            else:
                e = void_round(a.registry, secret, a.round, a.reason)
            print("registered %s of %s as entry %d (hash %s...)" % (e["kind"], a.round, e["seq"], e["hash"][:16]))
            return 0
        rows = read(a.registry)
        if a.cmd == "list":
            for rid, info in sorted(rounds(rows).items(), key=lambda kv: kv[1]["open"]["seq"]):
                o = info["open"]["data"]
                hit = [x for x in o["arms"] if (a.config_sha256 and x["config_sha256"] == a.config_sha256) or (a.handle and x.get("handle") == a.handle)]
                if (a.config_sha256 or a.handle) and not hit:
                    continue
                print("%-20s %-7s %s  arms: %s" % (rid, info["status"], o["domain"], ", ".join("%s=%s" % (x["eid"], x["label"]) for x in o["arms"])))
            return 0
        probs = check(rows, agent_sig.read_trusted(a.trusted))
        for p in probs:
            print("FAIL  " + p)
        print("REGISTRY OK: %d entries, %d rounds" % (len(rows), len(rounds(rows))) if not probs else "REGISTRY NOT OK")
        return 1 if probs else 0
    except (RegistryError, OSError, ValueError, KeyError, agent_core.AgentEvalError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1
    except Exception as e:
        if type(e).__name__ == "Rejected":
            print("error: %s" % e, file=sys.stderr)
            return 1
        raise


if __name__ == "__main__":
    sys.exit(main())
