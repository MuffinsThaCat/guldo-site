# Adversarial speedup verification: lattice SVP track

Goal: credit a claim of the form "my algorithm is X bits faster than the baseline" without trusting the claimant.
A solution is NP-checkable; a speedup is not. This protocol converts the second into the first plus a conservative
statistical bound.

## Interface
A submission is one Python file exposing `solve(basis: list[list[int]], bound2: int) -> list[int] | None`.
It must return a nonzero lattice vector with squared norm <= `bound2` (1.05 x Gaussian heuristic, squared). It receives
nothing else: no seed, no instance index, no network, no files.

## Instances (instances.py, instances_mlwe.py, families.py)
Three families (two lattice, one integer factoring: `factor`, semiprimes of a given bit size, accepting any nontrivial divisor),
each a pure function of (master_seed, dim, idx) via HMAC-SHA256, each with a judge-side planted witness so every instance is
provably solvable (the solver never sees it). The two lattice families:
- `gm`: Goldstein-Mayer SVP-challenge lattices (accept any vector <= 1.05 x Gaussian heuristic). A typical-length vector is
  planted. Without planting, some small-dimension instances had NO vector within the bound (two seen at dims 40 and 45,
  confirmed by exhaustive enumeration; 2 of ~160 small-dimension baseline runs recorded).
- `mlwe`: Kannan-embedding lattice of a module-LWE-shaped instance (Z_3329[x]/(x^4+1), rank k, dim 8k+1, Gaussian error
  sigma=8; ladder 97,105,...,137). The judge accepts any short lattice vector, checked by modular arithmetic, not only the
  planted secret. Ring dimension 4 (not 8) so the ladder steps by 8: with step 16 only one dimension fell between the
  0.5 s floor and the timeout ceiling and the family could never produce a credit. Calibration (baseline BKZ, 3 instances,
  60 s cap): 97: 0.3 s, 105: 0.5 s, 113: 0.7 s, 121: ~1.5 s (1 of 3 timed out), 129: 2-5 s (1 of 3), 137: 24 s (2 of 3).
  Measured with BOTH solvers (practice seed, 6 instances/dim, tuned_bkz vs baseline_bkz, medians in seconds):
  105: 0.52 / 0.55, 113: 0.58 / 0.74, 121: 1.77 / 2.04 (baseline 1 of 6 timed out), 129: 32.4 / 2.00 (baseline 3 of 6
  timed out). All four clear the 0.5 s floor, but 105 does so by a hair and 129 sits exactly at the 50% baseline-timeout
  drop threshold, so with other seeds or n the usable set can shrink to two or three dimensions. Per-dimension speedup
  of tuned over baseline: -0.25, -0.38, +0.45, +2.69 bits; Tier-1 credit 0 (pooled over 113/121/129: median 0.4, lower
  bound -0.1). So the ladder can produce a measurement, but this solver pair has no certifiable speedup on it. (An
  earlier version of this note, on the old N=8 ladder with 12 instances, found only dim 113 usable.)
1. Judge draws a 256-bit master seed and publishes sha256(seed) **before** the submission deadline (`judge.py new-seed`).
2. Submissions are frozen at the deadline.
3. Judge reveals the seed; anyone can check the commitment (`judge.py check`) and regenerate every instance.
Consequence: a submission cannot contain answers for, or be tuned to, the judged instances. The public practice seed is
for development only; `solvers/cheat_lookup.py` demonstrates the attack this blocks.

## Cost
CPU seconds (user+sys) of the solver process TREE, minus the cost of a no-op solver, strictly sequential.
In the Docker sandbox (the only mode `judge.py evaluate` accepts by default) `sandbox/meter.py` runs as root, drops the
solver to uid 10001, and after the solver exits waits for and reaps every descendant (orphans, double-forked daemons)
so their CPU is billed; stragglers are killed at the wall deadline and the instance counts as a timeout.
Failures (timeout, crash, no answer, invalid answer) are censored at the budget, so they count against the solver.
Bare local mode exists only for your own solvers (`--insecure-local`): a solver there can read the seed and the judge's
code and can orphan processes to hide CPU. Both exploits were reproduced against the bare harness
(solvers/planted_peek.py, solvers/orphan_cpu_hider.py).
STATUS OF THE SANDBOX (be precise): the first meter was verified against a hostile probe (non-root uid, no forging the
meter's output, no setuid, read-only filesystem, no network, pid cap). The CURRENT meter (descendant reaping, subreaper,
kill-all-at-deadline) and its tests in test_sandbox.py have NOT been run against a real Docker daemon: Docker became
unavailable during testing. Treat orphan-CPU billing and the hang protection as unverified until
`python3 -m unittest test_sandbox` passes. The harness's Docker control flow (flags, parsing, timeout cleanup) is
tested against a fake `docker` (test_docker_shim.py), which says nothing about the sandbox itself.
A results file records `instance_version`, `budget`, `sandbox` and the image ID; `extrapolate.py` refuses to compare
ladders that differ in any of them. Seeds must live outside the project tree (`judge.py new-seed` enforces it).

## Claim (extrapolate.py)
s(n) = median over instances of log2(baseline cost / submission cost) on the same instance, per dimension n on the
ladder (`families.DEFAULT_DIMS`, tuned to the default baseline; `--dims` overrides it for another baseline; cap per
`families.OFFICIAL`). A dimension is used only if both solvers' median
cost is at least 0.5 s (fixed-cost guard: setup costs fade with n and would fake a speedup that grows with n; the
floor is absolute so genuinely fast solvers are not penalized). Consequence: a speedup can only be certified in a
regime where the faster solver still costs >= 0.5 s, so the ladder must reach dimensions that are expensive enough.
Censoring only ever hurts the claimant: a baseline timeout understates its cost and a submission timeout overstates
the submission's, and both shrink s(n). A ladder where the baseline mostly times out is a bad ladder, not a big
speedup; pick dimensions the baseline can finish.
Two tiers, reported separately:

**Tier 1, MEASURED (this is the credit): difficulty-stratified.** Group instances (all dimensions together) into octaves
of the BASELINE's cost, starting at 0.5 s: [0.5,1), [1,2), [2,4), ... A bin is usable when it holds >= 5 instances and
the submission's median cost in it is >= 0.5 s (fixed-cost guard). Take the 3 hardest usable bins, pool their paired
per-instance log2(baseline cost / submission cost), and report the one-sided 95% JOINT-bootstrap lower bound of the pooled
median: every resample redraws instances from the whole eligible pool and RE-SELECTS the usable and hardest bins, so the
uncertainty of that selection is inside the bound (a resample with fewer than 2 usable bins counts as 0 bits). An earlier
version resampled within fixed bins; by simulation its bound exceeded the truth 5-9% of the time instead of <= 5%, and on
real seed-A data it overstated the credit (1.3 bits vs 0.1 corrected). Instances the baseline timed out on are excluded (unknown cost:
conservative); submission failures stay in at the budget cost. No model, no extrapolation: "on instances the baseline
found hard, this solver is at least X bits faster". Needs >= 2 usable bins, else inconclusive. Leaderboard credit is
the MIN over >= 3 independent committed seeds; an inconclusive seed counts as 0.
Why not by dimension: on real data the baseline's cost is heavy-tailed and non-monotone in dimension (median 1.2 s at
dim 66, 60 s at 68, 4.6 s at 70, 60 s at 72 on one seed), so choosing "the largest dimensions" was erratic and dropped
the dimensions where the effect was large. Selecting by the baseline's own cost depends only on the reference solver,
so it cannot favour the submission. The rule (top-3 hardest bins, bin size, floor) was fixed BEFORE computing any
credit with it, but the author had looked at the seed-A bin medians while designing it; independent data was checked
afterwards (see Real-data checks). The old dimension-pooled claim is still printed as an informational line.

**Tier 2, EXTRAPOLATED (information, never credit).** Four growth models (constant, linear, power-law, log-decay) are
fit to the per-dimension medians, each tested out-of-sample (fit without the largest dimension, predict it, reject if
off by > 1 bit); the extrapolated bits at the target dimension are min(min over surviving models, bootstrap 5th
percentile, 2 x the largest measured speedup). No surviving model => inconclusive. It is model-dependent and
statistically weak at realistic noise (see Statistical power), which is why it is not the credit.

**What makes a leaderboard credit official** (`judge.py leaderboard`): >= 3 distinct seeds, each run in the Docker
sandbox, with the family's official instances per dimension and CPU cap (`families.OFFICIAL`: gm 24 instances / 120 s,
mlwe 12 / 60 s), an instance version, and a seed verified against a
commitment published beforehand (`judge.py evaluate --published-commit HEX`). Credit = MIN over those seeds, an
inconclusive seed counts as 0. Anything else is shown as PROVISIONAL with the reasons; board entries record n, budget,
commitment, sandbox, instance version and image ID. `judge.py rescore` rebuilds entries from saved ladder files after
a rule change.

Both tiers use paired speedups (same instance, both solvers). A dimension is dropped when more than half of the
BASELINE's instances time out (its cost there is unmeasured) or when either solver costs under 0.5 s. A dimension is
NOT dropped because the submission failed there: failures count at the budget cost and pull the pooled speedup down.
(An earlier rule dropped dimensions on submission timeouts too; a solver that failed every instance at dims >= 66
then earned the same credit as one that solved them all. Fixed, with regression tests.) `solvers/fixed_overhead_ref.py` (reference with 1 CPU-second of fixed setup cost) shows a
fading advantage earning < 1 bit at the top dimensions (test_extrapolate.py).

## What this does NOT guarantee
- The credit is a measured lower bound at the dimensions the ladder reaches (about 60-72 for GM). It says nothing
  certain about NIST-scale dimensions; the extrapolated tier is a model, not a proof.
- CPU seconds depend on hardware; judges must run baseline and submission on the same pinned machine.
- The Docker sandbox is a container, not a VM, and its current meter is unverified (see Cost). Run it on a dedicated
  judge machine with a pinned core.
- "dimension" means different things in the two families (GM dimension vs 16k+1), so compare within a family only.
- A speedup is certifiable only where the faster solver still costs >= 0.5 s (fixed-cost floor) and the baseline mostly
  finishes within the cap; a speedup of a few tenths of a bit is below what 1.5-2.8 bits of per-instance noise allows.

## Statistical power of the earlier DIMENSION-POOLED estimator (superseded as the credit; kept as an informational line)
NOTE: everything in this section describes pooling by dimension. The credit is now the difficulty-stratified claim; its
real-data checks and real-noise power are in "Real-data checks" above.
(simulated; Gaussian per-instance noise sd 2.2 bits, the measured range is 1.5-2.8)
12 instances/dimension, dims 56..72 step 2, effect rising 0.2 -> 5.5 bits (the tuned-vs-baseline trend measured):
| claim | zero effect credited >= 1 bit | tuned-like effect credited >= 1 bit | constant 0.5-bit effect |
|---|---|---|---|
| Tier 1 measured | 0/150 (CI 0-2%) | 139/150 = 93% (CI 87-96%) | 0/150 |
| Tier 2 extrapolated | 0/120 | 2/120 = 2% (n=12), 50% only at 64/dim | n/a |
The Tier 2 claim was nearly unusable at realistic noise, which is why Tier 1 is the credit. These are simulations of
the estimator under an assumed noise model, not measurements of the real pipeline; real noise is heavier-tailed.

**Caveat: the Tier-1 power above does NOT transfer to the real ladder as configured.** The simulation assumed the top
three usable dimensions are uncensored and reach 72, where the tuned-like effect is ~4.7 bits. In real data the
baseline times out on most instances at the top dimensions (cap 60 s), those dimensions are dropped, and the usable
ones sit where the effect is small. Real-data check (GM v1, practice seed, tuned vs baseline, 12 instances/dim; HISTORICAL: these ladders predate the `instance_version` field and
the current estimator refuses them, so these numbers cannot be re-scored today and are kept for the reasoning, not as current results): usable
dims {60, 65}; pooled median 0.23 bits, one-sided lower bound -0.49, i.e. credit 0, although the same solver is 4.6 bits
faster at dim 70 (censored, dropped). Certifying a real speedup therefore needs a CPU budget large enough that the
baseline mostly finishes at the dimensions where the effect is large (budget vs dimension is the binding constraint),
or a baseline that scales more gently. Treat "93%" as the estimator's power given such data, not as the pipeline's
power. A second real-data run (GM, fresh seed, 12 instances/dim, 60 s cap, fixed rules) agrees: usable dims {64, 66, 70}
(68 and 72 dropped for 58% baseline timeouts), per-dimension speedups 0.7 / 0.17 / 1.31 bits, credit 0.0.
**Minimum detectable effect (simulated power curve).** A constant true effect at every dimension, per-instance noise
sd 2.2 bits (the measured range is 1.5-2.8), costs high enough that the 0.5 s floor does not bind, 120 trials per cell;
cell = probability that the Tier-1 credit is >= 1 bit:
| true effect | 1.0 bit | 1.5 bits | 2.0 bits | 2.5 bits | 3.0 bits |
|---|---|---|---|---|---|
| n = 12 per dimension | 10% | 35% | 75% | 93% | 100% |
| n = 24 per dimension | 9% | 58% | 91% | 100% | 100% |
A back-of-envelope formula (credit = median - 1.645 x 1.25 x sigma / sqrt(3n)) puts the break-even at about 1.8 bits
(n=12) and 1.5 bits (n=24); that is the ~50% point, NOT a power guarantee. For 80% power plan on about 2.1 bits at n=12
and about 1.8 bits at n=24 (hence gm official n=24). A real speedup of 0.5-1 bit is inconclusive by design, and the
honest tuned-vs-unpruned pair (about 0.2-1.3 bits at the dimensions where the baseline finishes) sits below that.
With floor and censoring effects the real thresholds are higher than these clean-case figures.
Two independent runs of the same baseline differ by only +0.03 bits median (worst dimension +0.08), so timing
drift is not the limiting factor; per-instance difficulty noise (1.5-2.8 bits) and censoring are.

## Parallel local runs (`harness.py --jobs K`, local mode only)
The official GM config is hours of CPU, so local runs can use K concurrent instances. CPU time is each child's own
`wait4` rusage, so concurrent runs do not corrupt each other's accounting. Concurrency does slow each process a little,
and that varies between runs (absolute time +0.01 to +0.10 bits at 4-10 jobs on this machine). What matters for the credit
is the SPEEDUP estimate, a ratio in which a uniform slowdown cancels: `drift_check.py` measured it shifting by only
-0.02 bits (sd 0.04) at 4, 6 and 8 jobs, baseline vs tuned, same instances, against a sequential noise floor of 0.01.
Both ladders of a comparison must use the same `--jobs` (`extrapolate.py` refuses otherwise); the sandbox path is
sequential only. Re-run `drift_check.py --solver ... --solver2 ...` on a new machine before using --jobs there.

## Real-data checks of the difficulty-stratified claim
(`extrapolate.py`; `power.py` for the noise/power numbers; baseline = baseline_bkz, submission = tuned_bkz unless stated)
| data | result |
|---|---|
| GM v2, fresh seed A, 12 inst/dim, dims 56-72, cap 60 s (in-sample: used to design the rule) | credit 0.1 bits (median 2.2) with the corrected joint bootstrap (1.3 with the withdrawn fixed-bin bootstrap); the credit pools the three hardest usable bins, 1-2 s (+0.54 bits, 5 instances), 2-4 s (+2.2, 8) and 16-32 s (+5.0, 7), each holding only 5-8 instances; the 0.5-1 s bin (+0.17, 15 instances) is usable but not among the three hardest, and 4-8 s (+1.9, 4 instances), 8-16 s and 32-64 s (1 each) are not usable; exploratory hard-pool claim >= 2.3 bits (n=13), also in-sample (its 4 s threshold was chosen after seeing this table) |
| GM v1, practice seed, independent older ladder (HISTORICAL: the files predate `instance_version`, so the current estimator refuses them and this row cannot be re-scored; kept as the record of what was found then) | credit 0.00 (median 0.6); effects +4 to +5.5 bits exist but sit in bins with 1-3 instances (< 5) |
| **GM v2, seed D, PRE-REGISTERED, 24 inst/dim, dims 64-72, cap 120 s, 6 jobs (OUT-OF-SAMPLE)** | **primary credit 2.6 bits (median 4.1)**: the credit pools the three hardest USABLE bins: 4-8 s (+2.56 bits, 11 instances), 16-32 s (+4.91, 13) and 32-64 s (+5.04, 5); the 2-4 s bin (+2.28, 10) is usable but not among the three hardest, and 64-128 s has 1 instance so it is not usable; criterion (a) >= 1.0 MET. Exploratory hard-pool claim 2.9 bits (30 instances, submission median cost 0.96 s): first out-of-sample support for promoting it. Cheapest bin (0.5-1 s) is -0.86 bits: the tuned solver's fixed cost makes it slower there, which is why the cost floor exists |
| seed D concurrency check (pre-registered, baseline only) | 25 baseline instances re-measured sequentially: median -0.050 bits, per-octave medians -0.041 to -0.074, none solved differently; criteria (median within +-0.10, no octave beyond +-0.20) MET |
| **factoring positive control, seed E, PRE-REGISTERED, sizes 58-64 bits, 24/size, cap 120 s, 6 jobs** | credit 4.1 bits (median 4.2) vs the calibrated ~4.4: credit criterion (a) met. **Concurrency criterion FAILED** (pre-registered, both ladders): baseline re-measured sequentially -0.033 bits (passes), numpy submission **-1.160 bits** (n=16, sd 0.08; limit 0.10). The sequential speedup is therefore probably ~5.2-5.6 bits (inference, not measured), and the match with 4.4 is partly a coincidence of two offsetting effects. Solver-dependent concurrency bias is a measurement hazard of `--jobs > 1` |
| seed D concurrency, tuned ladder (POST-HOC, not pre-registered) | all 113 tuned instances at >= 0.5 s re-measured: median -0.084 bits. The baseline is slowed by concurrency 0.050 bits and the tuned solver 0.084, so the speedup is UNDERestimated by about 0.034 bits: concurrency makes this credit slightly conservative |
| two independent runs of the SAME baseline (true effect 0) | inconclusive; every bin -0.03 to -0.05 bits (timing drift) |
| module-LWE v2, n=6 | inconclusive (1 usable bin) |
| fixed-overhead fallacy (reference = baseline + 1 s) | no credit: its +3.2-bit easy bin is below the floor |
| cheat on the PUBLIC seed (lookup table) | no credit: its cost is milliseconds, below the floor (commit-reveal is the real defence) |
Real per-instance noise inside difficulty bins is 0.5-1.5 bits (vs ~2.2 pooling by dimension). `power.py` with that real
noise on the seed-A ladder size (12/dim, 60 s cap), CORRECTED estimator, RE-RUN 2026-11-19 with the default settings (200 trials per
effect, seed 0; output saved as results/power_seedA_default.txt): false credit 0%, and P(credit >= 1) = 0.5% at a true effect of 1 bit,
1.0% at 1.5 and 0% from 2 to 4 bits (inconclusive 28% at 2.5, 58% at 3, 66% at 4). An earlier version of this paragraph quoted "0% at every
effect" and inconclusive 61% / 79% at 3 and 4 bits; the re-run does not reproduce those exactly (the 4-bit figure is outside sampling noise).
The conclusion stands: that ladder is too small to certify anything with the corrected bound. (The figures 12% / 46% / 41% / 31% / 6% / 27% quoted in earlier versions came from the withdrawn
fixed-bin bootstrap.) Larger true effects get HARDER to certify here because
the submission's cost falls under the 0.5 s floor in the bins where the baseline is cheap, leaving too few hard
instances. This is inherent to a cost floor (subtracting each solver's measured fixed cost instead was rejected: a solver
could inflate that measurement on trivial instances and make every real instance look free). More instances per
dimension and a larger cap fill the hard bins; the gm official config (24/dim, 120 s) exists for that reason and has been run once
(seed D, above).

**Power at the OFFICIAL configuration (measured; re-run 2026-11-19).** `power.py` on the seed-D pair (24/dim, 120 s cap, REAL per-instance
noise, 200 trials per effect, default settings; output saved as results/power_seedD_default.txt). P(credit >= 1 bit) for a CONSTANT true
speedup: 0% at 0 bits (no false credit), 6.5% at 1, 70.5% at 1.5, 98% at 2, 100% at 2.5, 73% at 3 and **1% at 4 bits**. Power FALLS for
large effects at n=24. Mechanism (checked, not assumed): at 4 bits the point estimate is still exactly right (4.00 bits) but the 95% lower bound
is 0.00 in every trial, because only 2-3 hard bins remain usable (this ladder has 13, 5 and 1 instances above 16 s and none at 8-16 s), some
of them marginal (5 instances), and the joint bootstrap re-selects bins in every resample, so the bound collapses when the usable set is
unstable. That is a property of how many HARD baseline instances the ladder has, not of the estimator being blind.

**More instances help, up to a hard ceiling.** `power.py --copies K --resample` builds each synthetic ladder with K x the instances per size, drawn at
random WITH REPLACEMENT from the real seed-D baseline records (so the number of hard instances varies from ladder to ladder, as it would for a genuinely
larger ladder of fresh instances); outputs saved as results/power_seedD_copies2_resample.txt and _copies4_resample.txt, 100 trials per effect.
P(credit >= 1):

| true speedup | n=24 (official) | n=48 | n=96 |
|---|---|---|---|
| 3 bits | 73% | 99% | 100% |
| 4 bits | 1% | 68% | 100% |
| 5 bits | not run | 50% | 98% |
| 6 bits | not run | 0% (inconclusive 93%) | 0% (inconclusive 66%) |

(An earlier version of this section used `--copies` WITHOUT `--resample`, which repeats the observed instances exactly and so guarantees K times
seed D's hard-instance count: that gave 99% at 4 bits and 73% at 5 bits for n=48, and 100% for both at n=96, results/power_seedD_copies2.txt and
_copies4.txt. Those are the optimistic case where a larger ladder happens to have exactly the observed composition; the resampled numbers above are
the honest ones, and they differ materially at n=48.)

So a round that expects a 4 to 5-bit speedup should set `n` to about 96 (`ops.py round-new --n 96`; logged in the round's first entry, accepted by the
board because the rule is n >= the minimum; the price is proportionally more machine time): n=48 is borderline (68% at 4 bits, 50% at 5). But NO n
removes the ceiling: at 6 bits the submission
costs under 0.5 s on every instance the baseline finished in under 32 s, only the 32-128 s bins could be usable, and the credit needs at least two
usable bins with 5 instances each, so the result is inconclusive. **The practical ceiling of the solver-versus-solver design at a 120 s cap is
about 5 bits.** The formula that stood here before, "maximum certifiable effect is about log2(hardest-bin baseline cost / 0.5 s), at most ~7 bits
at a 60 s cap" is therefore not attainable and is WITHDRAWN as a statement of what can be certified. Caveats: the simulation applies one constant
effect to every instance, while a real solver's effect varies (tuned BKZ's grows with dimension and it WAS certified at 2.6 bits at n=24), and
`--copies` assumes a larger ladder would have the same cost distribution as seed D's (a different seed or solver pair could have more or fewer hard
instances), and every cell carries roughly +-10 points of simulation noise: `power.py` draws 150 bootstrap resamples per trial while the real estimator
draws 300, and a re-run at 300 (results/power_seedD_boot300_n24.txt and _n48_resample.txt, 100 trials) gave 64% at 3 bits for n=24 (73% at 150), and
61% and 54% at 4 and 5 bits for n=48 (68% and 50% at 150), with the same regime in every cell and 0% false credit. So these show the shape of the limits, not a prediction for any particular
solver. Claims above about 5 bits need a different design (a baseline that is a model rather than a solver: EGG.md, "Ways forward" 2); not built.

**What to expect from the official run of the real pair (bootstrap of the real instances, n=24 only).** `power.py --real-pairs` resamples seed D's REAL
paired instances (the solver's real, instance-dependent speedup and its real failures) into 300 fresh ladders of the same size (boot 300; output saved as
results/power_seedD_realpairs_n24.txt). Credit per ladder: median 2.56 (the run itself gave 2.58), 5th percentile 1.15, 95th 2.94. P(one seed's credit >= 1
bit) = 96.7% and P(ALL THREE seeds >= 1 bit) = 91.0% (100 independent triples); the board credit is the minimum over seeds, so the likely official figure
sits near the low end of those. Caveats: this bootstraps ONE seed's instances, so it captures instance-sampling variation but not seed-to-seed or machine
variation; seed D ran with 6 concurrent jobs, which slowed the tuned solver more than the baseline (about 0.03 bits post hoc), so a sequential sandbox run
is, if anything, slightly better for this pair; the 1-bit threshold is the one registered for seed D, and the official run's own criteria are written when
it is registered. The same bootstrap scaled to 2x and 4x the instances is REFUSED by `power.py`: duplicating observed submission costs duplicates their
noise, so the bootstrap believes it has more information and reports an inflated credit (median 2.56 -> 2.94 -> 3.67); the invalid attempt is kept as
results/INVALID_power_seedD_realpairs_n48_duplicated_noise.txt and _n96_. Larger-ladder power comes from the synthetic mode above, where the noise is
redrawn for every instance.

**Exploratory hard-pool claim.** Because the bin-selection step is what makes small samples fragile, `extrapolate.py` also
prints a selection-free claim: pool every instance the baseline solved at cost >= 4 s (threshold fixed in advance as 8 x the
floor), require >= 12 of them and a submission median cost >= 0.5 s, and bootstrap the median normally. It is NOT the
credit; it is reported beside it so a validation run can say whether it should become the credit. Its 4 s threshold was
fixed after the author had seen seed A's bin table, so only runs pre-registered afterwards count as validation.

**Harness fixes found by audit:** the CPU cap used to be applied with `subprocess` `preexec_fn`, documented as unsafe when
spawning from several threads (possible deadlock); it is now set inside `runner.py` (soft = hard, set before the solver is
imported, so the solver cannot raise it). The hand-managed pipes also leaked 3 descriptors per run (macOS default limit
256); they are closed explicitly. Both have tests (test_harness_local.py), including 72 spawns at 12 jobs and an
fd-leak check. `remeasure.py` re-runs a stratified sample of a finished ladder sequentially to check, per cost octave,
that concurrent timings of HARD instances match sequential ones (end-to-end check on the sequential seed-A baseline ladder:
12 instances up to 38 s reproduced within +-0.06 bits each, median -0.012).

A second audit found the first fix introduced a hang: with an orphan holding the output pipe, the reader thread stayed
blocked in `read()` and my explicit `close()` then blocked on the stream's lock, so the harness never returned (reproduced:
no return after 90 s on a 2 s budget). Readers are now non-blocking and stoppable (select with a stop flag), the child runs
in its own session, and after a 2 s grace period everything left in that session is killed. Regression tests cover a
sleeping orphan and a CPU-burning orphan. KNOWN LIMIT of bare local mode: a solver that calls `setsid()` escapes that
cleanup and its daemon keeps running (and burning CPU) after the harness returns, unbilled; only the Linux/Docker meter
(unverified) can bill and kill such descendants. Local mode is for your own solvers.
Also found: on macOS a solver that ignores SIGXCPU is not killed at the CPU limit (Linux kills at the hard limit); it ran to
18.95 s CPU on a 3 s budget before the wall timer stopped it. It is still billed and marked a timeout, so there is no credit
advantage, but it stalls a run. The local wall backstop is now 1.5 x budget + 10 s (a solver killed by it, e.g. one that only
sleeps, is labelled `timeout`, not `crash`). `--jobs` above the safe maximum is refused. The maximum counts PERFORMANCE
cores only, minus 2 (8 on this 10-P-core machine, the range the drift check validated): jobs beyond that would run on
efficiency cores or oversubscribe, distorting timings and making wall time exceed CPU time, which the backstop assumes.

## Related work (checked by web search, not from memory)
The TU Darmstadt SVP Challenge and LWE Challenge are long-running fixed-instance lattice challenges with checkable
solutions and public records (SVP up to dimension ~180); they rank by capability (dimension solved), not by paired
bits-of-speedup over a reference under a committed seed. A 2024 benchmarking paper (arXiv 2408.00882) calls the Darmstadt
challenges the only concrete LWE benchmark and notes they omit standardized-parameter (small-secret, ring/module) cases.
This protocol is a complement to those, not the first lattice competition.

## Reproducing the baseline
`python3 judge.py evaluate --seed <seed> --submission solvers/baseline_bkz.py` must credit ~0 bits. If it doesn't, the
verifier is biased and results should not be trusted.
