"""Calibration solver for gpu_meter.py: does nothing. One request to a child running this measures the fixed per-call cost of the parent/child pipe plus two device
synchronizes. The meter records that number in the ladder header (`call_overhead_s`) for transparency and does NOT subtract it from any time."""


def solve(*args):
    return [0]
