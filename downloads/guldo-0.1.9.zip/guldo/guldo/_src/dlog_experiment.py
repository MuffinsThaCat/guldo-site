"""Judge the pre-registered dlog experiment (results/PREREGISTERED_dlog_realsolver.txt) mechanically, with no reinterpretation.

  python3 dlog_experiment.py              print each criterion as PASS / FAIL / PENDING, and the numbers behind it
  python3 dlog_experiment.py --json       the same, as JSON

Reads only saved files: the three baseline ladders, the two submissions' ladders and the primary estimator's claim file next to each (written
by judge.py at evaluation time). It also re-hashes every code file the registration lists and says so if any changed since, because a result
measured with different code is not the registered experiment.

Definitions fixed here, in code, before the data were read: a claim is the MINIMUM of the three seeds' credits (judge.py's rule: any seed with
no conclusion makes the claim inconclusive); the "pooled paired median" is the median over all three seeds of log2(baseline cost / solver cost)
on every instance both solvers solved whose BASELINE cost is at least the estimator's 0.5 s floor (the same instances the credit may use).
The all-pairs median (no floor) is reported beside it and is not used by any criterion.
"""
import hashlib
import json
import math
import os
import re
import statistics
import sys

import extrapolate as E

HERE = os.path.dirname(os.path.abspath(__file__))
PREREG = "PREREGISTERED_dlog_realsolver.txt"
TAGS = ("e5dab2c8", "d00100a7", "e70be0d8")     # the first 8 hex of the three registered seed commitments
A_SOLVER, B_SOLVER = "dlog_stride4.py", "dlog_bsgs.py"
BASELINE = "reference.py"


def _ladder(results, tag, role, name):
    return os.path.join(results, f"judged_dlog_{tag}_{role}_{name}.jsonl")


def _records(path):
    with open(path, encoding="utf-8") as f:
        return [r for r in map(json.loads, (ln for ln in f if ln.strip())) if not r.get("meta")]


def _claim(path):
    p = path + ".claim.json"
    if not os.path.exists(p):
        return "missing"
    with open(p, encoding="utf-8") as f:
        return json.load(f)["measured"]          # None = inconclusive


def registered_hashes(results):
    with open(os.path.join(results, PREREG), encoding="utf-8") as f:
        return re.findall(r"^([0-9a-f]{64})  (\S+)$", f.read(), re.M)


def code_changed(results):
    bad = []
    for want, rel in registered_hashes(results):
        p = os.path.join(HERE, rel)
        got = None
        if os.path.exists(p):
            with open(p, "rb") as f:
                got = hashlib.sha256(f.read()).hexdigest()
        if got != want:
            bad.append(rel)
    return bad


def paired_medians(results, name):
    """(median over floor-eligible pairs, median over all pairs, number of eligible pairs); None when a ladder is missing."""
    elig, allp = [], []
    for tag in TAGS:
        bp, sp = _ladder(results, tag, "baseline", BASELINE), _ladder(results, tag, "submission", name)
        if not (os.path.exists(bp) and os.path.exists(sp)):
            return None
        sub = {r["id"]: r for r in _records(sp)}
        for b in _records(bp):
            s = sub.get(b["id"])
            if s and b["status"] == "solved" and s["status"] == "solved":
                x = math.log2(b["cpu_net"] / max(s["cpu_net"], 1e-3))
                allp.append(x)
                if b["cpu_net"] >= E.FLOOR_ABS:
                    elig.append(x)
    return (statistics.median(elig) if elig else None, statistics.median(allp) if allp else None, len(elig))


def seed_claims(results, name):
    out = []
    for tag in TAGS:
        sp = _ladder(results, tag, "submission", name)
        out.append("missing" if not os.path.exists(sp) else _claim(sp))
    return out


def _fmt(c):
    return "pending" if c == "missing" else "inconclusive" if c is None else f"{c:.2f}"


def judge(results=None):
    results = results or os.path.join(HERE, "results")
    out = []
    changed = code_changed(results)
    out.append({"criterion": "code unchanged", "status": "fail" if changed else "pass",
                "detail": ("changed since registration: " + ", ".join(changed) + ". Results measured with different code are not the registered experiment") if changed
                else f"all {len(registered_hashes(results))} registered code hashes still match"})
    for key, name in (("A", A_SOLVER), ("B", B_SOLVER)):
        claims = seed_claims(results, name)
        pm = paired_medians(results, name)
        if "missing" in claims or pm is None:
            out.append({"criterion": f"{key}: all seeds evaluated", "status": "pending", "detail": f"per-seed claims so far: {[_fmt(c) for c in claims]}"})
            continue
        conclusive = all(c is not None for c in claims)
        claim = min(claims) if conclusive else None
        elig, allm, n = pm
        shown = f"claim {_fmt(claim) if conclusive else 'inconclusive'} bits (per seed {[_fmt(c) for c in claims]}); pooled paired median {'n/a' if elig is None else f'{elig:.2f}'} bits over {n} eligible pairs (all-pairs median {allm:.2f})"
        if key == "A":
            out.append({"criterion": "A1: every seed conclusive", "status": "pass" if conclusive else "fail", "detail": shown})
            if conclusive:
                ok2 = 0.7 <= claim <= 1.7 and (elig is None or claim <= elig + 0.3)
                out.append({"criterion": "A2: claim in [0.7, 1.7] and not above the paired median + 0.3", "status": "pass" if ok2 else "fail", "detail": shown})
                out.append({"criterion": "A3: claim >= 1.0 bit", "status": "pass" if claim >= 1.0 else "fail",
                            "detail": shown + ("" if claim >= 1.0 else ". A miss, not explained away: A's true effect sits at the lower edge of the stated range")})
            else:
                out += [{"criterion": c, "status": "fail", "detail": "an inconclusive seed: " + shown} for c in ("A2: claim in [0.7, 1.7] and not above the paired median + 0.3", "A3: claim >= 1.0 bit")]
        else:
            big = conclusive and claim >= 5.0
            out.append({"criterion": "B1: not credited at 5 bits or more (the ceiling is real)", "status": "fail" if big else "pass", "detail": shown})
            out.append({"criterion": "B2: paired median reported beside the claim", "status": "pass",
                        "detail": shown + ". The gap between them is the ceiling's size, not a failure"})
    return out


def overall(res):
    st = {r["status"] for r in res}
    return "FAIL" if "fail" in st else "PENDING" if "pending" in st else "PASS"


def card_html(results=None):
    """A Results-page card, or "" when the registration is absent. Pending criteria are shown as pending, never hidden."""
    results = results or os.path.join(HERE, "results")
    if not os.path.exists(os.path.join(results, PREREG)):
        return ""
    import html
    res = judge(results)
    label = {"pass": "Met", "fail": "Not met", "pending": "Not run yet"}
    rows = "".join(f'<tr><td>{html.escape(r["criterion"])}</td><td><strong>{label[r["status"]]}</strong></td><td class="fine">{html.escape(r["detail"])}</td></tr>' for r in res)
    return ('<section class="card"><h2>Does the compiler\'s prediction match real solvers? (dlog)</h2>'
            '<p class="fine">Two real solvers were run through the full pipeline on three fresh seeds. What would count as success was written down before any data existed '
            f'(<a href="prereg/{PREREG}">the registration</a>), and each criterion below is applied exactly as written, with no reinterpretation. '
            'Local mode, one computer, no locked box: even a full pass is provisional.</p>'
            f'<div class="scroll"><table class="lb"><thead><tr><th>Criterion</th><th>Outcome</th><th>The numbers</th></tr></thead><tbody>{rows}</tbody></table></div>'
            f'<p class="fine">Overall: <strong>{overall(res)}</strong>.</p></section>')


def main(argv=None):
    res = judge()
    if "--json" in (argv if argv is not None else sys.argv[1:]):
        print(json.dumps(res, indent=1))
    else:
        for r in res:
            print(f"  {r['status'].upper():7s} {r['criterion']}: {r['detail']}")
        print(f"\noverall: {overall(res)}")
    sys.exit(0 if overall(res) == "PASS" else 1)


if __name__ == "__main__":
    main()
