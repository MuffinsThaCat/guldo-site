"""Module-LWE-shaped planted instances as Kannan-embedding lattices, with an exact NP-checkable verifier.

A = k x k block matrix of negacyclic ring multiplications over Z_q[x]/(x^N+1) (Kyber's ring structure, small N).
b = A s + e mod q with centered-binomial s and rounded-Gaussian e (sigma SIGMA). Lattice of (x, y, t) in Z^(m+n+1) with x = t*b - A*y (mod q);
the planted vector is (e, s, 1). The judge accepts ANY nonzero lattice vector with squared norm <= bound2, so a
competitor is not required to recover the planted secret, and the check is just modular arithmetic.
Lattice dimension d = 2*N*k + 1.
"""
import hashlib
import hmac
import random

Q = 3329
N = 4  # ring dimension; dim = 2*N*k + 1, so the ladder steps by 8 (N=8 stepped by 16: too coarse, 1 usable dimension)
ETA = 2  # secret: centered binomial
SIGMA = 8.0  # error: rounded Gaussian std (noise rate alpha = SIGMA / Q); calibrated so BKZ cost grows with dimension
SLACK = 1.5  # accepted norm = SLACK * (expected norm of the planted vector)


def _cbd(rng, eta):
    return sum(rng.getrandbits(1) for _ in range(eta)) - sum(rng.getrandbits(1) for _ in range(eta))


def derive(master: bytes, dim: int, idx: int) -> dict:
    if dim < 2 * N + 1 or (dim - 1) % (2 * N):
        raise ValueError(f"mlwe dim must be 2*{N}*k+1, got {dim}")
    k = (dim - 1) // (2 * N)
    n = m = N * k
    rng = random.Random(hmac.new(master, f"mlwe-v2:{dim}:{idx}".encode(), hashlib.sha256).digest())
    A = [[0] * n for _ in range(m)]
    for bi in range(k):
        for bj in range(k):
            a = [rng.randrange(Q) for _ in range(N)]
            for r in range(N):
                for c in range(N):
                    i = r - c
                    A[bi * N + r][bj * N + c] = a[i] if i >= 0 else (-a[i + N]) % Q
    s = [_cbd(rng, ETA) for _ in range(n)]
    e = [int(round(rng.gauss(0, SIGMA))) for _ in range(m)]
    b = [(sum(A[i][j] * s[j] for j in range(n)) + e[i]) % Q for i in range(m)]
    d = m + n + 1
    basis = []
    for i in range(m):
        row = [0] * d
        row[i] = Q
        basis.append(row)
    for j in range(n):
        row = [0] * d
        for i in range(m):
            row[i] = -A[i][j]
        row[m + j] = 1
        basis.append(row)
    basis.append(list(b) + [0] * n + [1])
    expected2 = m * SIGMA ** 2 + n * ETA / 2 + 1
    return {"id": f"{dim}:{idx}", "dim": d, "idx": idx, "q": Q, "m": m, "n": n, "A": A, "b": b,
            "basis": basis, "bound2": int(SLACK * SLACK * expected2), "planted": e + s + [1]}


def verify(inst: dict, v) -> bool:
    d, m, n, q, A, b = inst["dim"], inst["m"], inst["n"], inst["q"], inst["A"], inst["b"]
    if not isinstance(v, list) or len(v) != d or not all(isinstance(c, int) and not isinstance(c, bool) for c in v):
        return False
    if all(c == 0 for c in v):
        return False
    x, y, t = v[:m], v[m:m + n], v[m + n]
    for i in range(m):
        if (x[i] - t * b[i] + sum(A[i][j] * y[j] for j in range(n))) % q:
            return False
    return sum(c * c for c in v) <= inst["bound2"]
