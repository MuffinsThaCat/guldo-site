"""aimoe in the counted-operations API, TECHNIQUE: a loop over the experts, each run on EVERY token and masked by that token's gate weight (the usual dense-MoE implementation). Same output as the reference, none of the routing saving."""
import math

import tensorops as tp

D, F, E = 32, 64, 8
ROUTER = 3.0


def solve(seed, n):
    o = n * D
    X = tp.stream(seed, 0, o, (n, D))
    Wg = tp.stream(seed, o, D * E, (D, E)) * (ROUTER * math.sqrt(3.0 / D))
    o += D * E
    W1 = tp.stream(seed, o, E * D * F, (E, D, F)) * math.sqrt(3.0 / D)
    o += E * D * F
    W2 = tp.stream(seed, o, E * F * D, (E, F, D)) * math.sqrt(3.0 / F)
    S = (X @ Wg).tolist()
    G = [[0.0] * n for e in range(E)]
    for i in range(n):
        row = S[i]
        a = 0
        for e in range(1, E):
            if row[e] > row[a]:
                a = e
        b = 1 if a == 0 else 0
        for e in range(E):
            if e != a and row[e] > row[b]:
                b = e
        pa = 1.0 / (1.0 + math.exp(row[b] - row[a]))
        G[a][i] = pa
        G[b][i] = 1.0 - pa
    out = tp.zeros((n, D))
    for e in range(E):
        out = out + (tp.relu(X @ W1[e]) @ W2[e]) * tp.reshape(tp.tensor(G[e]), (n, 1))
    return [int(x * 65536.0) for x in tp.reshape(out, (n * D,)).tolist()]
