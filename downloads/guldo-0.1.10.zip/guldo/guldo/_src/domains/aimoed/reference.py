"""Reference for aimoed: one device runs the whole mixture-of-experts layer (float64), expert by expert."""
import math

import numpy as np

BIAS = (0.0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9, 1.05)


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, T, P):
    X = _uniform(seed, 0, T * d).reshape(T, d)
    R = _uniform(seed, T * d, d * 8).reshape(d, 8) * math.sqrt(3.0 / d)
    ids = np.argmax(X @ R + np.array(BIAS), axis=1)
    out, o = np.zeros((T, d)), T * d + d * 8
    for e in range(8):
        W1 = _uniform(seed, o, 2 * d * d).reshape(d, 2 * d) * math.sqrt(6.0 / d)
        W2 = _uniform(seed, o + 2 * d * d, 2 * d * d).reshape(2 * d, d) * math.sqrt(3.0 / (2 * d))
        o += 4 * d * d
        out[ids == e] = np.maximum(X[ids == e] @ W1, 0.0) @ W2
    return [int(v) for v in np.rint(out.ravel() * 2 ** 30)]
