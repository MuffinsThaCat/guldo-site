"""Reference for dlog: exhaustive search, one multiplication per candidate exponent."""


def solve(p, g, h):
    cur = 1
    for x in range(p - 1):
        if cur == h:
            return x
        cur = cur * g % p
    return None
