"""aikvc with bytes counted (tflops_mem.py), REFERENCE: the full float64 K and V (n x 32 each), read in full at every one of the 64 steps."""
import math

import tensorops as tp

D, R, S = 32, 4, 64


def solve(seed, n):
    o = 2 * n * R
    Zk = tp.stream(seed, 0, n * R, (n, R))
    Zv = tp.stream(seed, n * R, n * R, (n, R))
    Bk = tp.stream(seed, o, R * D, (R, D)) * (2.0 * 3.0 / math.sqrt(R))
    Bv = tp.stream(seed, o + R * D, R * D, (R, D)) * (3.0 / math.sqrt(R))
    base = tp.stream(seed, o + 2 * R * D, S * D, (S, D)) * 2.0
    K = Zk @ Bk
    V = Zv @ Bv
    prev = tp.zeros((D,))
    outs = []
    for t in range(S):
        s = (K @ (base[t] + prev * 4.0)) / math.sqrt(D)
        e = tp.exp(s - tp.max(s))
        prev = (e / tp.sum(e)) @ V
        outs.append(prev)
    return [int(x * 65536.0) for x in tp.concat(outs, 0).tolist()]
