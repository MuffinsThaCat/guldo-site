"""Vercel Blob as the certificate log's home: a minimal client over Blob's REST API and a mirror of a log directory to and from a store. Standard library only. Run the tests: python3 -m unittest test_log_blob -v

Why. A serverless function has no disk that outlives a request, so a log that is kept fresh by a scheduled function on the website's own hosting needs somewhere to live. The store is PUBLIC
(readers fetch https://<store>.public.blob.vercel-storage.com/log/... with no credentials) and the function holds the one credential that can write it: the store-scoped read-write token,
which can touch this store and nothing else on the account. The store is the single source of truth for a hosted log; a directory on someone's laptop is a mirror (`pull`) and a place to add
entries before a `push`. Never sign heads from two places at once.

Protocol (read from the official @vercel/blob SDK, v2.9): PUT https://vercel.com/api/blob/?pathname=P with `authorization: Bearer <token>`, `x-api-version: 13`, `x-vercel-blob-access: public`,
`x-content-type`, `x-add-random-suffix: 0`, `x-allow-overwrite: 1`, `x-cache-control-max-age`; the token is `vercel_blob_rw_<storeId>_<secret>` and the store's public host is the lower-cased id.
Reads are plain GETs of the public URL. `_manifest.json` lists every path with its sha256 so a push uploads only what changed and a pull needs no list call. Network access is injected."""
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://vercel.com/api/blob"
API_VERSION = "13"
PREFIX = "log/"
MANIFEST = "_manifest.json"
MAX_FILE = 64 << 20
CACHE_SECONDS = 60              # Blob's minimum: a new head is visible to readers within a minute
CORE = ("log.json", "entries.jsonl", "checkpoints.jsonl", "cosigs.jsonl", "anchors.jsonl", "checkpoint.json", "trusted.txt")
DIRS = {"certs": re.compile(r"[0-9a-f]{64}\.cert\.json"), "attestations": re.compile(r"[0-9a-f]{64}\.att\.json"), "proofs": re.compile(r"[0-9]{1,9}\.json"),
        "anchors": re.compile(r"ots-[0-9]{1,9}-[0-9a-f]{16}\.ots")}
USER_AGENT = "guldo-log-blob/1"


class BlobError(Exception):
    pass


def store_id(token):
    parts = token.split("_")
    if len(parts) < 5 or parts[:3] != ["vercel", "blob", "rw"] or not parts[3]:
        raise BlobError("not a Vercel Blob read-write token")
    return parts[3]


def public_base(token_or_id):
    sid = store_id(token_or_id) if token_or_id.startswith("vercel_blob_") else token_or_id
    return f"https://{sid.lower()}.public.blob.vercel-storage.com"


def content_type(path):
    if path.endswith(".json"):
        return "application/json"
    if path.endswith((".jsonl", ".txt")):
        return "text/plain; charset=utf-8"
    return "application/octet-stream"


def allowed(rel):
    """A path this module will ever read or write under the log prefix: the core files, and the four known sub-directories with their exact name shapes. Nothing else crosses."""
    if rel in CORE or rel == MANIFEST or rel == "status.json":
        return True
    d, _, name = rel.partition("/")
    return d in DIRS and bool(name) and "/" not in name and bool(DIRS[d].fullmatch(name))


def sha256(b):
    return hashlib.sha256(b).hexdigest()


def default_http(method, url, headers=None, data=None, timeout=60):
    """-> (status, body). https only. Never raises for an HTTP status; raises BlobError for a network failure."""
    if not url.startswith("https://"):
        raise BlobError("refusing a non-https address")
    req = urllib.request.Request(url, data=data, method=method, headers=dict(headers or {}, **{"User-Agent": USER_AGENT}))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read(MAX_FILE + 1)[:MAX_FILE]
    except urllib.error.HTTPError as e:
        try:
            return e.code, e.read(4000)
        except OSError:
            return e.code, b""
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise BlobError(f"network failure: {type(e).__name__}")


class Store:
    def __init__(self, token, http=default_http, base=None, now=time.time):
        self.token, self.http, self.now = token, http, now
        self.sid = store_id(token)
        self.base = base or public_base(token)

    def put(self, rel, data, cache=CACHE_SECONDS):
        if not allowed(rel):
            raise BlobError(f"refusing to write {rel!r}")
        if len(data) > MAX_FILE:
            raise BlobError(f"{rel} is over {MAX_FILE >> 20} MB")
        headers = {"authorization": f"Bearer {self.token}", "x-api-version": API_VERSION, "x-vercel-blob-access": "public", "x-content-type": content_type(rel),
                   "x-add-random-suffix": "0", "x-allow-overwrite": "1", "x-cache-control-max-age": str(cache), "x-vercel-blob-store-id": self.sid}
        status, body = self.http("PUT", f"{API}/?{urllib.parse.urlencode({'pathname': PREFIX + rel})}", headers, data)
        if status != 200:
            raise BlobError(f"PUT {rel}: HTTP {status}")
        try:
            got = json.loads(body.decode("utf-8")).get("pathname")
        except (ValueError, AttributeError):
            got = None
        if got != PREFIX + rel:
            raise BlobError(f"PUT {rel}: the store answered with a different pathname ({str(got)[:60]!r}); a random suffix or rename would break every URL")
        return True

    def get(self, rel):
        """The bytes at rel, or None if absent. A cache-busting query makes the CDN fetch from the origin, so a run always starts from the latest write."""
        if not allowed(rel):
            raise BlobError(f"refusing to read {rel!r}")
        status, body = self.http("GET", f"{self.base}/{PREFIX}{rel}?v={int(self.now())}", {})
        if status == 404:
            return None
        if status != 200:
            raise BlobError(f"GET {rel}: HTTP {status}")
        return body

    def manifest(self):
        raw = self.get(MANIFEST)
        if raw is None:
            return {}
        try:
            m = json.loads(raw.decode("utf-8"))
            files = m["files"]
            if not isinstance(files, dict) or not all(isinstance(k, str) and isinstance(v, str) and allowed(k) for k, v in files.items()):
                raise ValueError("bad manifest")
            return files
        except (ValueError, KeyError, TypeError, UnicodeDecodeError):
            raise BlobError("the store's manifest is unreadable")


def local_files(path):
    """{relative path: bytes} for every allowed file in a log directory (symlinks and anything unexpected are ignored)."""
    out = {}
    for rel in CORE:
        p = os.path.join(path, rel)
        if os.path.isfile(p) and not os.path.islink(p):
            out[rel] = open(p, "rb").read()
    for d, pat in DIRS.items():
        base = os.path.join(path, d)
        if os.path.isdir(base):
            for fn in sorted(os.listdir(base)):
                p = os.path.join(base, fn)
                if pat.fullmatch(fn) and os.path.isfile(p) and not os.path.islink(p):
                    out[f"{d}/{fn}"] = open(p, "rb").read()
    return out


def push(path, store, only=None, force_all=False):
    """Upload what changed in the directory since the store's manifest, then the new manifest LAST (readers never see a manifest naming a file that is not there yet).
    -> {"uploaded": [paths], "unchanged": n}. `only` limits the upload to those paths (the manifest keeps every other entry as it was)."""
    files = local_files(path)
    old = store.manifest()
    new = dict(old)
    todo = []
    for rel, data in files.items():
        if only is not None and rel not in only:
            continue
        h = sha256(data)
        if force_all or old.get(rel) != h:
            todo.append((rel, data, h))
    for rel, data, h in todo:
        store.put(rel, data)
        new[rel] = h
    if todo or set(new) != set(old):
        store.put(MANIFEST, json.dumps({"format": "guldo-log-manifest-v1", "files": dict(sorted(new.items()))}, sort_keys=True, indent=1).encode() + b"\n", cache=CACHE_SECONDS)
    return {"uploaded": [r for r, _, _ in todo], "unchanged": len(files) - len(todo)}


def pull(path, store, names=None):
    """Download the store's files into a directory (created if needed). With `names`, only those (plus nothing else); otherwise everything the manifest lists.
    Every byte is checked against the manifest's sha256 before it is written: a corrupted or truncated download never lands on disk. -> [paths written]."""
    man = store.manifest()
    wanted = [n for n in (names if names is not None else man) if allowed(n) and n != MANIFEST]
    got = []
    os.makedirs(path, exist_ok=True)
    for rel in wanted:
        data = store.get(rel)
        if data is None:
            if names is not None and rel not in man:
                continue
            raise BlobError(f"the manifest lists {rel} but the store does not serve it")
        if rel in man and sha256(data) != man[rel]:
            raise BlobError(f"{rel} does not match the store's manifest (a stale or corrupted copy): try again")
        dest = os.path.join(path, rel)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        tmp = dest + ".tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, dest)
        got.append(rel)
    return got


def read_token(path=None, env=None):
    """The store's read-write token from, in order, a file (raw, or a `BLOB_READ_WRITE_TOKEN="..."` line as `vercel env pull` writes it), the environment, ~/.guldo/blob-token."""
    env = os.environ if env is None else env
    candidates = [path] if path else []
    if not path:
        if env.get("BLOB_READ_WRITE_TOKEN"):
            return env["BLOB_READ_WRITE_TOKEN"].strip()
        candidates.append(os.path.expanduser("~/.guldo/blob-token"))
    for p in candidates:
        if p and os.path.isfile(p):
            text = open(p, encoding="utf-8").read()
            m = re.search(r"BLOB_READ_WRITE_TOKEN\s*=\s*[\"']?(vercel_blob_rw_[A-Za-z0-9_]+)", text)
            tok = m.group(1) if m else text.strip()
            store_id(tok)
            return tok
    raise BlobError("no store token: pass --token-file, set BLOB_READ_WRITE_TOKEN, or save it as ~/.guldo/blob-token (mode 600)")


def main(argv=None, http=default_http):
    import argparse
    import sys
    ap = argparse.ArgumentParser(description="Mirror a certificate log directory to and from its Vercel Blob store.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, help_ in (("push", "upload what changed (after `translog.py add` on a fresh pull)"), ("pull", "download the whole log into a directory (a backup mirror)")):
        s = sub.add_parser(name, help=help_)
        s.add_argument("dir")
        s.add_argument("--token-file")
    a = ap.parse_args(argv)
    try:
        store = Store(read_token(a.token_file), http)
        if a.cmd == "push":
            r = push(a.dir, store)
            print(f"uploaded {len(r['uploaded'])} files ({r['unchanged']} unchanged)" + "".join(f"\n  {p}" for p in r["uploaded"][:20]))
        else:
            got = pull(a.dir, store)
            print(f"wrote {len(got)} files to {a.dir}")
        return 0
    except BlobError as e:
        print(f"log_blob: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    import sys
    sys.exit(main())
