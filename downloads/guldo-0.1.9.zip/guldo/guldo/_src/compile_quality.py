"""Compiler for QUALITY challenges (see COMPILER.md, "Quality challenges"). A declaration that defines `quality(inst, ans) -> float in [0, 1]` is a quality challenge:
every solver gets the same CPU budget per instance and is scored on how good its answer is, not how fast it is.

    decl.py (extra, all optional except quality)
        quality(inst, ans)   called ONLY on answers verify() accepted; 0.0 = worst valid answer, 1.0 = best known/possible. Pure and deterministic.
        QUALITY_BUDGET       CPU seconds per instance for everyone, the reference included (default 30)
        QUALITY_MIN_GAIN     the smallest mean gain (in quality points, 0..1) worth certifying (default 0.02); power is computed at this threshold

The compiler validates quality(), measures the reference's quality over the size range on the public profiling seed, keeps the sizes where the reference leaves headroom,
chooses the instances per size from a power simulation, and writes compiled.json with kind "quality". A quality domain is deliberately NOT registered as a speed family:
the judge, harness and portal would score it by speed. Its product is the challenge bundle: `compile_domain.py export NAME`.

What this compiler does not know: whether quality() measures what you care about, or whether the reference is a strong baseline (say so in REFERENCE_NOTE).
"""
import json
import math
import os
import random
import statistics
import time

import compile_domain as CD
import declared
import harness
import quality_core as Q

KIND = "quality"
QUALITY_FORMAT = "svp-compiled-quality-v1"   # NOT declared.FORMAT, on purpose: declared.load_all then refuses to register the domain as a speed family (the judge, harness and portal rank by the clock)
DEFAULT_BUDGET = 30
DEFAULT_MIN_GAIN = 0.02
NS = (12, 24, 48, 96, 192)
MAX_SIZES = 5
HEADROOM_MEAN = 0.95      # a size where the reference averages above this leaves too little room to show a gain
NOISE_FLOOR, NOISE_CAP = 0.02, 0.25
NOISE_SHARE = 1.0         # ASSUMED: a solver's per-instance gain varies as much as the reference's own quality does (one real pair on maxcut: gain sd 0.036 vs reference sd 0.02-0.04;
                          # qscore.py measures the real value and re-simulates)
SEEDS = 3
REPRO_TOLERANCE = 0.02    # two runs of the reference on the same instance may differ by this much in quality (qcheck.py qrerun's default tolerance is 0.05)


def is_quality(mod):
    return callable(getattr(mod, "quality", None))


def settings(mod):
    """-> (budget seconds, min_gain). Raises CD.CompileError on a malformed value."""
    budget, gain = getattr(mod, "QUALITY_BUDGET", DEFAULT_BUDGET), getattr(mod, "QUALITY_MIN_GAIN", DEFAULT_MIN_GAIN)
    num = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)   # noqa: E731
    if not (num(budget) and 1 <= budget <= 600):
        raise CD.CompileError("QUALITY_BUDGET must be a number of CPU seconds from 1 to 600")
    if not (num(gain) and 0 < gain <= 0.5):
        raise CD.CompileError("QUALITY_MIN_GAIN must be a number in (0, 0.5]: the smallest mean quality gain worth certifying, in quality points")
    return float(budget), float(gain)


def score_answer(mod, inst, ans):
    """The quality of a verified answer, checked to be a finite number in [0, 1]. The scorer treats a violation as the declaration's bug, never as a score."""
    q = mod.quality(inst, ans)
    if isinstance(q, bool) or not isinstance(q, (int, float)) or not math.isfinite(q) or not 0.0 <= q <= 1.0:
        raise CD.CompileError(f"quality() returned {q!r} (type {type(q).__name__}); it must return a finite number in [0, 1]")
    return float(q)


def measure(mod, ref, master, size, idx, budget):
    """Run the reference once on one instance under the CPU budget -> {"status", "quality", "cpu"}. An unanswered or invalid instance scores 0."""
    derive, verify = declared.make_spec(mod)
    inst = derive(master, size, idx)
    rc, out, err, cpu = harness._exec_local(ref, json.dumps({"args": inst["args"]}), budget)
    import signal
    if rc == -signal.SIGXCPU or cpu > budget or rc == -signal.SIGKILL:
        return {"status": "timeout", "quality": 0.0, "cpu": min(cpu, budget)}
    if rc != 0 or not out.strip():
        return {"status": "crash", "quality": 0.0, "cpu": cpu, "err": err[-300:]}
    try:
        ans = json.loads(out.strip().splitlines()[-1])
        ok = bool(verify(inst, ans))
    except Exception:
        return {"status": "wrong", "quality": 0.0, "cpu": cpu}
    if not ok:
        return {"status": "failed" if ans is None else "wrong", "quality": 0.0, "cpu": cpu}
    return {"status": "solved", "quality": score_answer(mod, inst, ans), "cpu": cpu}


# ------------------------------------------------------------------------------------------------------------------------ validation
def freshness_problems(d, mod, compiled):
    """declared.freshness_problems for a quality record: the hashes, version and shape checks apply unchanged, but the record's format differs from a speed record's ON PURPOSE
    (it is what keeps declared.load_all, which is pinned by running rounds and the dlog pre-registration, from registering it), so that one finding is replaced by its own check."""
    if (compiled or {}).get("format") != QUALITY_FORMAT and compiled is not None:
        return [f"compiled.json has format {compiled.get('format')!r}, expected {QUALITY_FORMAT!r}"]
    return [p for p in declared.freshness_problems(d, mod, compiled) if not p.startswith("compiled.json has format")]


def quality_validation(mod, dirpath):
    """The checks specific to quality(): its settings, range and determinism on planted witnesses, and that it is not a constant."""
    out = []
    try:
        budget, gain = settings(mod)
    except CD.CompileError as e:
        return [CD.R("quality settings", "fail", str(e))]
    out.append(CD.R("quality settings", "pass", f"budget {budget:g} s per instance, certification threshold {gain:g} quality points"))
    derive, verify = declared.make_spec(mod)
    lo, hi = mod.SIZE_RANGE
    step = getattr(mod, "SIZE_STEP", 1)
    sizes = sorted({lo, lo + ((hi - lo) // (2 * step)) * step, hi})
    master = b"svp-compiler-validate-A"
    seen = []
    try:
        for s in sizes:
            for i in range(3):
                x = derive(master, s, i)
                w = CD._witness(mod, x)
                if not verify(x, w):
                    raise CD.CompileError(f"verify() rejected the planted witness at size {s}: quality() is only defined on verified answers")
                q1, q2 = score_answer(mod, x, w), score_answer(mod, x, w)
                if q1 != q2:
                    raise CD.CompileError(f"quality() gave {q1} then {q2} for the same answer at size {s}: it must be deterministic")
                seen.append(q1)
        out.append(CD.R("quality range", "pass", f"finite, in [0, 1] and deterministic on {len(seen)} planted witnesses (range {min(seen):.3f}..{max(seen):.3f})"))
    except CD.CompileError as e:
        out.append(CD.R("quality range", "fail", str(e)))
    except Exception as e:   # the author's code can raise anything
        out.append(CD.R("quality range", "fail", f"quality() raised {type(e).__name__}: {e}"))
    return out


# ------------------------------------------------------------------------------------------------------------------------ profile + plan
def candidate_sizes(mod, limit=8):
    lo, hi = mod.SIZE_RANGE
    step = getattr(mod, "SIZE_STEP", 1)
    allsz = list(range(lo, hi + 1, step))
    if len(allsz) <= limit:
        return allsz
    return sorted({allsz[round(i * (len(allsz) - 1) / (limit - 1))] for i in range(limit)})


def profile(mod, ref, budget, k, log=CD._log):
    """{size: {"q": [...], "status": [...], "cpu": [...]}} for the reference on the public profiling seed."""
    pts = {}
    for s in candidate_sizes(mod):
        recs = [measure(mod, ref, CD.PROFILE_SEED, s, i, budget) for i in range(k)]
        pts[s] = {"q": [r["quality"] for r in recs], "status": [r["status"] for r in recs], "cpu": [r["cpu"] for r in recs]}
        crashed = [r for r in recs if r["status"] == "crash"]
        if crashed:
            raise CD.CompileError(f"the reference crashed at size {s}: {crashed[0].get('err', '')[-200:]}")
        log(f"profile: size {s}: reference quality mean {statistics.fmean(pts[s]['q']):.3f} (n={k}, "
            f"{sum(x == 'timeout' for x in pts[s]['status'])} timeouts, median cpu {statistics.median(pts[s]['cpu']):.2f}s)")
    return pts


def choose_sizes(pts, notes):
    """The sizes with headroom, thinned to at most MAX_SIZES evenly (always keeping the largest)."""
    usable = [s for s in sorted(pts) if statistics.fmean(pts[s]["q"]) <= HEADROOM_MEAN]
    if not usable:
        raise CD.CompileError(f"the reference averages above {HEADROOM_MEAN} quality at every size in SIZE_RANGE: no headroom to show a gain. Raise SIZE_RANGE's upper end or weaken the "
                              "reference's claim on the problem (a saturated baseline makes every solver tie)")
    dropped = [s for s in sorted(pts) if s not in usable]
    if dropped:
        notes.append(f"sizes {dropped} dropped: the reference is already above {HEADROOM_MEAN} quality there")
    if len(usable) > MAX_SIZES:
        usable = sorted({usable[round(i * (len(usable) - 1) / (MAX_SIZES - 1))] for i in range(MAX_SIZES)})
    return usable


def profile_for_power(pts, sizes):
    return {"sizes": sizes, "mean": {str(s): statistics.fmean(pts[s]["q"]) for s in sizes},
            "sd": {str(s): statistics.pstdev(pts[s]["q"]) if len(pts[s]["q"]) > 1 else 0.0 for s in sizes}}


def plan_power(prof, gain, target_power, trials, boot, log=CD._log):
    """Smallest n (from NS) whose all-seeds power at a true gain of 2 x threshold reaches target_power, then the power curve at that n."""
    sd = statistics.fmean(prof["sd"].values())
    noise = min(max(NOISE_SHARE * sd, NOISE_FLOOR), NOISE_CAP)
    target = round(2 * gain, 4)
    rng = random.Random(0)
    tried, chosen = {}, NS[-1]
    for n in NS:
        p = Q.power_at(prof, n, target, noise, gain, SEEDS, trials, boot, rng)
        tried[n] = round(p["all_seeds"], 3)
        log(f"power: n={n}: P(all {SEEDS} seeds >= {gain:g} | true gain {target:g}) = {p['all_seeds']:.2f}")
        chosen = n
        if p["all_seeds"] >= target_power:
            break
    effects = Q.effects_for(gain)
    table = Q.power_table(prof, chosen, noise, gain, SEEDS, trials, boot, effects, seed=1)
    lo, hi = Q.certifiable_range(table, target_power)
    notes = []
    if tried[chosen] < target_power:
        notes.append(f"even n={chosen} (the largest allowed) certifies a gain of {target:g} only {100 * tried[chosen]:.0f}% of the time")
    if table[0]["single"] > 0.10:
        notes.append(f"FALSE-CREDIT RATE {100 * table[0]['single']:.0f}% at zero gain (> 10%): the lower bound is not holding on this ladder")
    return {"n": chosen, "noise": round(noise, 4), "noise_assumed": True, "target_effect": target, "target_power": target_power, "trials": trials, "boot": boot,
            "threshold": gain, "tried": {str(k): v for k, v in tried.items()}, "min_certifiable": lo, "max_certifiable": hi,
            "curve": {str(e): {"single": round(v["single"], 3), "all_seeds": round(v["all_seeds"], 3)} for e, v in table.items()}, "notes": notes}


def selftest(prof, n, gain, noise, boot=60):
    """Controls on the estimator, with ladders drawn from the compiled profile (the bundle's own selftest covers the declaration and the pipeline):
    zero gain must credit 0; a solver that never answers must credit 0; a known gain of 3 x threshold must be credited at least the threshold."""
    rng = random.Random(7)
    base, same_ = Q.synth_ladders(prof, n, 0.0, 0.0, rng)
    zero = Q.seed_credit(base, {d: dict(v) for d, v in base.items()}, rng, boot)["credit_quality"]
    none = Q.seed_credit(base, {d: {i: 0.0 for i in v} for d, v in base.items()}, rng, boot)["credit_quality"]
    b2, s2 = Q.synth_ladders(prof, n, 3 * gain, 0.0, rng)
    known = Q.seed_credit(b2, s2, rng, boot)["credit_quality"]
    controls = [CD.R("zero gain", "pass" if zero == 0 else "fail", f"reference vs itself credits {zero:.4f} (must be 0)"),
                CD.R("never answers", "pass" if none == 0 else "fail", f"a solver with no valid answer credits {none:.4f} (must be 0)"),
                CD.R("known gain", "pass" if known >= gain else "fail", f"a true gain of {3 * gain:g} is credited {known:.4f} (must reach {gain:g})")]
    return {"status": CD.worst(controls) if CD.worst(controls) != "warn" else "pass", "controls": controls,
            "kind": "estimator controls on synthetic ladders from the profile; the exported bundle's `check.py selftest` covers the declaration itself"}


def verdict(compiled):
    name, qc = compiled["name"], compiled["quality"]
    pw = qc["power"]
    st = (compiled.get("selftest") or {}).get("status", "pending")
    notes = list(qc.get("notes", [])) + list(pw["notes"])
    mce, top = pw["min_certifiable"], pw["max_certifiable"]
    if st == "fail" or mce is None:
        level = "NOT READY"
    elif st in ("skipped", "pending"):
        level = "DRAFT (no self-test)"
    elif notes:
        level = "READY, WITH NOTES (read them)"
    else:
        level = "READY"
    cost = qc["cpu_hours"]
    lines = [f"{name}: {level}   [quality challenge]",
             f"  the challenge : sizes {compiled['dims']}, {qc['budget']:g} CPU s per instance, {compiled['official']['n']} instances per size; one submission costs up to {cost['worst_case']} CPU-hours",
             "  it can certify: " + (f"mean quality gains from about {mce:g} to about {top:g} (on the 0-1 quality scale) over the reference (threshold {pw['threshold']:g}, {SEEDS} seeds, "
                                      f"{int(100 * pw['target_power'])}% power)" if mce is not None else "NOTHING on the grid tried: the ladder is too weak (see the notes)"),
             f"  noise assumed : {pw['noise']:g} quality points per instance (an ASSUMPTION; `score.py` measures the real value and re-simulates)",
             f"  self-test     : {st}"] + [f"  note          : {x}" for x in notes]
    nxt = [f"python3 compile_domain.py export {name}      # the challenge bundle: checker, scorer, power analysis"]
    if st in ("skipped", "pending"):
        nxt.insert(0, f"python3 compile_domain.py compile {name}      # the full compile with the self-test")
    return level, lines + ["  next:"] + [f"    {x}" for x in nxt]


# ------------------------------------------------------------------------------------------------------------------------ the compile
def compile_dir(dirpath, *, quick=False, k=None, target_power=0.8, trials=None, boot=None, skip_selftest=False, log=CD._log):
    dirpath = os.path.abspath(dirpath)
    mod, ref, res = CD.parse(dirpath)
    log("parse:")
    CD._print(res)
    if CD.worst(res) == "fail":
        raise CD.CompileError("the declaration did not parse")
    if not is_quality(mod):
        raise CD.CompileError("this declaration has no quality(inst, ans) function: it is a speed challenge (use compile_domain.py compile)")
    k = k or (3 if quick else 8)
    trials = trials or (8 if quick else 30)
    boot = boot or 60   # quality_core.MIN_BOOT: fewer resamples make the bound anti-conservative, so a quick compile saves time elsewhere (fewer trials), not here
    quality_checks = quality_validation(mod, dirpath)
    budget, gain = settings(mod) if CD.worst(quality_checks) != "fail" else (DEFAULT_BUDGET, DEFAULT_MIN_GAIN)
    log("validate:")
    val = CD.validate(mod, dirpath, ref, quality=mod.quality) + quality_checks
    CD._print(val)
    if CD.worst(val) == "fail":
        raise CD.CompileError("validation failed; nothing was compiled. Fix the FAIL items above.")
    with CD.provisional(mod):
        pts = profile(mod, ref, budget, k, log)
    notes = []
    sizes = choose_sizes(pts, notes)
    with CD.provisional(mod):   # the reference's quality must reproduce: a baseline ladder that cannot be re-run is a baseline nobody can verify (found by compiling a randomised reference: it passed)
        again = [measure(mod, ref, CD.PROFILE_SEED, sizes[-1], i, budget)["quality"] for i in range(min(3, k))]
    drift = max(abs(x - y) for x, y in zip(again, pts[sizes[-1]]["q"]))
    if drift > REPRO_TOLERANCE:
        notes.append(f"the reference is NOT reproducible: the same instances scored up to {drift:.3f} apart on two runs. Baseline ladders will not re-run to the same numbers, so `qrerun` "
                     "will fail an honest baseline; seed the reference's random generator")
    allq = [q for s in pts for q in pts[s]["q"]]
    if len(set(allq)) == 1:
        raise CD.CompileError(f"the reference scores exactly {allq[0]} on every instance at every size: a constant measures nothing")
    prof = profile_for_power(pts, sizes)
    pw = plan_power(prof, gain, target_power, trials, boot, log)
    n = pw["n"]
    hist = {s: statistics.median(pts[s]["cpu"]) for s in sizes}
    cost = {"worst_case": round(len(sizes) * n * budget * 2 * SEEDS / 3600.0, 2),
            "reference_expected": round(sum(statistics.fmean(pts[s]["cpu"]) for s in sizes) * n * SEEDS / 3600.0, 2)}
    practice = [s for s in sorted(pts) if all(x == "solved" for x in pts[s]["status"]) and statistics.median(pts[s]["cpu"]) <= 1.0][:2] or [sizes[0]]
    if any(x == "timeout" for s in sizes for x in pts[s]["status"]):
        notes.append("the reference times out on some instances: they count 0 for the baseline, so ANY valid answer there is a gain (intended? say so in REFERENCE_NOTE)")
    compiled = {
        "format": QUALITY_FORMAT, "kind": KIND, "name": mod.NAME, "version": mod.VERSION, "compiled_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "decl_sha256": declared.sha256_file(os.path.join(dirpath, declared.DECL)), "reference_sha256": declared.sha256_file(ref),
        "compiler_sha256": declared.sha256_file(os.path.abspath(CD.__file__)), "quality_compiler_sha256": declared.sha256_file(os.path.abspath(__file__)),
        "reference_note": (getattr(mod, "REFERENCE_NOTE", "") or "").strip(), "size_range": list(mod.SIZE_RANGE), "size_step": getattr(mod, "SIZE_STEP", 1),
        "official": {"n": n, "budget": budget}, "dims": sizes, "practice_dims": practice,
        "quality": {"budget": budget, "min_gain": gain, "power": pw, "cpu_hours": cost, "notes": notes, "headroom_mean_cap": HEADROOM_MEAN,
                    "profile": {"seed": CD.PROFILE_SEED.decode(), "k": k, "median_cpu": {str(s): round(v, 3) for s, v in hist.items()},
                                "sizes": {str(s): {"mean": round(statistics.fmean(pts[s]["q"]), 4), "sd": round(prof["sd"].get(str(s), statistics.pstdev(pts[s]["q"])), 4),
                                                   "timeouts": sum(x == "timeout" for x in pts[s]["status"]), "q": [round(q, 4) for q in pts[s]["q"]]} for s in sorted(pts)}},
                    "simulation": prof},
        "validation": res + val, "selftest": {"status": "skipped"} if skip_selftest or quick else {"status": "pending"}}
    if compiled["selftest"]["status"] == "pending":
        compiled["selftest"] = selftest(prof, n, gain, pw["noise"], boot)
    CD.write_compiled(dirpath, compiled)
    log(f"compiled: sizes {sizes}, n={n}, budget {budget:g} s, certifiable gain {pw['min_certifiable']}..{pw['max_certifiable']} points, worst case {cost['worst_case']} CPU-h per submission")
    for note in notes + pw["notes"]:
        log("  NOTE " + note)
    if compiled["selftest"].get("controls"):
        log("selftest:")
        CD._print(compiled["selftest"]["controls"])
    return compiled
