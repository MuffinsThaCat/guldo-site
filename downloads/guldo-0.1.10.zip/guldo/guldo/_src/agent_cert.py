"""Agent-evaluation CERTIFICATES: one document that states a result and that anyone can re-derive from the published ladders and the revealed seed.

  agent_cert.py build  --base B --round ID --entry e001 [--min-factor F] [--min-solve-rate R] [--key SECRET] --out CERT.json
  agent_cert.py verify CERT.json --baseline BASE.jsonl --candidate CAND.jsonl (--seed FILE | --practice) [--round-base B] [--trusted KEYS]
  agent_cert.py show   CERT.json

A certificate is the comparison of ONE entry with the round's baseline, bound to the round: the plan hash, the seed commitment, the log head at the time it was built, the SHA-256 of both
ladder files, and the entry's configuration. The STATEMENT is generated mechanically from the numbers (never written by hand), and `verify` regenerates it, so the text cannot claim more
than the data. `verify` does not trust the certificate: it re-verifies both ladders from the seed (re-derive every instance, re-run every verifier, replay every tool call, recompute every
cost, check every chain), recomputes the whole comparison, regenerates the statement and the claims, and, given the round's files, checks the log head and the entry's configuration hash
against the log. An optional Ed25519 signature (agent_sig.py) says WHO issued it; it adds nothing to what the data prove.

WHAT A CERTIFICATE DOES NOT SAY (printed in it): that a model produced the trajectories unless attestation receipts were used (agent_attest.py; this module does not require them); that
tokens are billed tokens (they are proxy tokens); that the result holds off this domain, these sizes and these caps; that the agent behaved safely; or anything about a run on a practice seed
(anyone can derive every instance of one: it is marked, and its statement says so).
"""
import argparse
import json
import os
import sys

import agent_compare
import agent_core
import agent_eval
import agent_harness
import agent_rounds as AR
import rounds as R
from agent_core import canon

FORMAT = "guldo-agent-certificate-v1"
ATTESTATION_KIND = "recording-proxy-v1"
NOT_SHOWN = ["That a particular model produced the trajectories: the operator ran the agents; this is not attested unless receipts are attached (agent_attest.py).",
             "That tokens are billed tokens: they are proxy tokens (ceil(utf-8 bytes / 4) of the exact context sent each turn plus the output).",
             "That the result holds on other tasks, other sizes or other caps, or that the agent behaved safely.",
             "A practice-seed certificate shows the method only: anyone can derive every instance."]


def statement_text(c):
    s, k = c["comparison"]["success"], c["comparison"]["cost"]
    cand, base = c["comparison"]["candidate"]["summary"], c["comparison"]["baseline"]["summary"]
    parts = []
    if c["round"]["practice"]:
        parts.append("[PRACTICE SEED: a demonstration, not a certified result]")
    parts.append("Round %s (domain %s; plan %s...; seed commitment %s...): configuration '%s' (handle %s) against baseline '%s' on %d committed instances, %d trial(s) each."
                 % (c["round"]["id"], c["round"]["domain"], c["round"]["plan_hash"][:12], c["round"]["commitment"][:12], c["candidate"]["label"], c["candidate"]["handle"],
                    c["baseline"]["label"], cand["instances"], c["comparison"]["candidate"]["summary"].get("trials", 0) // max(cand["instances"], 1)))
    parts.append("Solved: candidate %d of %d (95%% one-sided lower bound on the solve rate %.3f), baseline %d of %d." % (cand["solved_instances"], cand["instances"], cand["solve_rate_lower95"],
                                                                                                                 base["solved_instances"], base["instances"]))
    parts.append("Success: candidate-only %d, baseline-only %d, both %d, neither %d; exact sign test p=%.3g: %s." % (s["candidate_only"], s["baseline_only"], s["both"], s["neither"],
                                                                                                                  s["sign_p_candidate_better"], s["verdict"]))
    if "mean_bits" in k:
        parts.append("Cost on the %d instances both solved: the candidate used %.2fx %s proxy tokens (mean gap %.2f bits; 95%% one-sided lower bound %.2f bits = %.2fx): %s."
                     % (k["both_solved"], 2 ** abs(k["mean_bits"]), "fewer" if k["mean_bits"] >= 0 else "more", k["mean_bits"], k["lower95_bits_one_sided"], k["factor_lower95"], k["verdict"]))
    else:
        parts.append("Cost: " + k["verdict"] + ".")
    bb = [n for n, s in (("baseline", base), ("candidate", cand)) if s.get("mode")]
    if bb:
        parts.append("BLACK-BOX: the %s was a vendor's own agent driven through the evaluator's tool service: the evaluator saw only its tool calls and the results, never its model, prompts or reasoning, "
                     "so its cost is INTERACTION tokens (not comparable with proxy tokens) and nothing here shows how the work was done or by what." % " and the ".join(bb))
        note = c["comparison"].get("budget_note")
        if note:
            parts.append("NOTE: " + note + ".")
    eb, ec = base.get("agent_error_trials", 0), cand.get("agent_error_trials", 0)
    if eb or ec:
        parts.append("WARNING: %d of the baseline's and %d of the candidate's trials ended in an AGENT ERROR (usually the operator's infrastructure, not the model), and count as failures." % (eb, ec))
    att = c.get("attestation")
    if att:
        parts.append("ATTESTED: all %d model calls of this round (arms %s) match receipts signed by %d pinned key(s) in a recording-proxy log (SHA-256 %s...); the token counts above are still the "
                     "harness's proxy counts, and the proxy proves the calls were made, not which model answered beyond the model id the provider reported."
                     % (att["exchanges"], ", ".join(att["arms"]), len(att["proxy_keys"]), att["proxy_log_sha256"][:12]))
    parts.append("Each verdict is one-sided at 5%.")
    return " ".join(parts)


def _config_matches_header(cfg, hdr):
    """A displayed configuration is the one the ladder was run with: same agent spec and label, same tool list, and the system prompt the header recorded (the default when the config has none)."""
    if not isinstance(cfg, dict) or not isinstance(hdr.get("agent"), dict):
        return False
    if hdr.get("mode"):                                       # a black-box arm has no system prompt the evaluator controls: the config must not claim one, nor the header record one
        return (cfg.get("agent") == hdr["agent"].get("spec") and cfg.get("label") == hdr["agent"].get("label") and cfg.get("allow_tools") == hdr.get("allow_tools")
                and cfg.get("system") is None and hdr.get("system") is None)
    system = cfg.get("system") if cfg.get("system") is not None else agent_harness.SYSTEM
    return (cfg.get("agent") == hdr["agent"].get("spec") and cfg.get("label") == hdr["agent"].get("label") and cfg.get("allow_tools") == hdr.get("allow_tools") and system == hdr.get("system"))


def _claims(comparison, min_factor, min_solve_rate):
    return [{"text": t, "confirmed": bool(ok)} for t, ok in agent_compare.claim_check(comparison, min_factor, min_solve_rate)]


def build(base, rid, eid, min_factor=None, min_solve_rate=None, key_path=None, proxy_log=None, proxy_trusted=None):
    """Build a certificate for one entry of a REVEALED round whose files verify. With `proxy_log` (the recording proxy's log, agent_proxy.py) and `proxy_trusted` (the verifier's public keys) the
    whole round is first ATTESTED against it (every model call of every arm matches a signed exchange, none is left over); a round that does not attest is refused, and the attestation is
    embedded so a verifier can re-check it."""
    d = AR._require(base, rid)
    r = R._read_json(os.path.join(d, "round.json"))
    if r["state"] != "revealed":
        raise AR.Rejected("certificates need a revealed round; it is %s" % r["state"])
    probs = AR.verify_round(base, rid)
    if probs:
        raise AR.Rejected("REFUSED: the round does not verify (%s)" % probs[0])
    entries = {e["eid"]: e for e in AR._entries(d)}
    if eid not in entries:
        raise AR.Rejected("no such entry: %s" % eid)
    bpath, cpath = os.path.join(d, "ladders", "baseline.jsonl"), os.path.join(d, "ladders", eid + ".jsonl")
    bh, br = agent_core.read_ladder(bpath)
    ch, cr = agent_core.read_ladder(cpath)
    comparison = json.loads(json.dumps(agent_compare.compare(bh, br, ch, cr)))
    ok, n, head, _ = R.verify_log(d)
    e = entries[eid]
    cert = {"format": FORMAT,
            "round": {"id": rid, "domain": r["domain"], "plan_hash": r["plan_hash"], "commitment": r["commitment"], "practice": r["practice"], "log_head": head, "log_entries": n},
            "baseline": {"label": r["baseline"]["label"], "config": r["baseline"], "ladder_sha256": agent_core.file_sha256(bpath), "digest": agent_compare.ladder_digest(bh, br)},
            "candidate": {"eid": eid, "label": e["config"]["label"], "handle": e["handle"], "config": e["config"], "config_sha256": e["config_sha256"],
                          "ladder_sha256": agent_core.file_sha256(cpath), "digest": agent_compare.ladder_digest(ch, cr)},
            "comparison": comparison, "claims": _claims(comparison, min_factor, min_solve_rate), "claim_thresholds": {"min_factor": min_factor, "min_solve_rate": min_solve_rate},
            "not_shown": NOT_SHOWN}
    if proxy_log:
        if not proxy_trusted:
            raise AR.Rejected("attestation needs the verifier's public key(s): without a pinned key a signature proves only that SOME key signed")
        import agent_proxy
        log = agent_proxy.read_log(proxy_log)
        aprobs, info = agent_proxy.verify_round_http(base, rid, log, set(proxy_trusted))
        if aprobs:
            raise AR.Rejected("REFUSED: the proxy log does not attest this round (%s)" % aprobs[0])
        cert["attestation"] = {"kind": ATTESTATION_KIND, "proxy_log_sha256": agent_core.file_sha256(proxy_log), "proxy_keys": sorted(proxy_trusted), "arms": info["arms"], "exchanges": len(log)}
    cert["statement"] = statement_text(cert)
    if key_path:
        import agent_sig
        return agent_sig.sign_statement(cert, agent_sig.load_secret(key_path))
    return cert


def verify_certificate(doc, baseline_path, candidate_path, master, trusted=None, round_base=None, proxy_log=None, proxy_trusted=None):
    """Returns a list of (check, ok, detail). All ok = the certificate says exactly what the data say. If the certificate CLAIMS an attestation, it is re-checked here from `proxy_log` and the
    verifier's own `proxy_trusted` keys (and the round's files, `round_base`); a claimed attestation that cannot be re-checked FAILS (it is never taken on trust)."""
    out = []

    def add(name, ok, detail=""):
        out.append((name, bool(ok), detail))
    cert = doc
    if isinstance(doc, dict) and "signature" in doc and "statement" in doc:
        import agent_sig
        if not isinstance(doc["statement"], dict):
            add("signature is valid", False, "the signed statement is not an object")
            return out
        add("signature is valid", agent_sig.statement_ok(doc))
        pub = doc["statement"].get("pubkey")
        if trusted is not None:
            add("signer is a trusted key", isinstance(pub, str) and pub in set(trusted), str(pub)[:16])
        cert = {k: v for k, v in doc["statement"].items() if k != "pubkey"}
    elif trusted is not None:
        add("signer is a trusted key", False, "the certificate is not signed")
    if not isinstance(cert, dict) or cert.get("format") != FORMAT:
        add("format", False, "not a %s document" % FORMAT)
        return out
    try:
        add("baseline ladder file is the certified one", agent_core.file_sha256(baseline_path) == cert["baseline"]["ladder_sha256"])
        add("candidate ladder file is the certified one", agent_core.file_sha256(candidate_path) == cert["candidate"]["ladder_sha256"])
        add("the seed matches the committed seed commitment", agent_core.commitment(master) == cert["round"]["commitment"])
        add("practice flag matches the seed", cert["round"]["practice"] is (master == agent_core.PRACTICE_SEED))
        for label, path in (("baseline", baseline_path), ("candidate", candidate_path)):
            probs, _ = agent_eval.verify_ladder(path, master)
            add("%s ladder verifies from the seed" % label, not probs, (probs[0] if probs else "every trial re-derived, re-verified, replayed, recomputed"))
        bh, br = agent_core.read_ladder(baseline_path)
        ch, cr = agent_core.read_ladder(candidate_path)
        add("ladders were made under the certified plan", bh.get("plan_hash") == ch.get("plan_hash") == cert["round"]["plan_hash"])
        add("ladder digests match", agent_compare.ladder_digest(bh, br) == cert["baseline"]["digest"] and agent_compare.ladder_digest(ch, cr) == cert["candidate"]["digest"])
        comparison = json.loads(json.dumps(agent_compare.compare(bh, br, ch, cr)))
        add("the comparison recomputes identically", comparison == cert["comparison"])
        th = cert.get("claim_thresholds", {})
        add("the claims recompute identically", _claims(comparison, th.get("min_factor"), th.get("min_solve_rate")) == cert["claims"])
        add("the statement is exactly what the data generate", statement_text(dict(cert, comparison=comparison)) == cert["statement"])
        # The displayed configurations and the caveats are part of what a reader is told, so they are part of what is checked (a second audit found that editing them, or deleting the caveats,
        # failed no check at all).
        add("the limits (not_shown) are the standard ones, none removed or edited", cert.get("not_shown") == NOT_SHOWN)
        add("the candidate's displayed configuration hashes to the certified value", AR.config_sha(cert["candidate"]["config"]) == cert["candidate"]["config_sha256"])
        for who, cfg, hdr in (("baseline", cert["baseline"]["config"], bh), ("candidate", cert["candidate"]["config"], ch)):
            add("the %s's displayed configuration is the one its ladder was run with" % who, _config_matches_header(cfg, hdr) and cert[who]["label"] == cfg.get("label"),
                "agent, label, system prompt and tool list must equal the ladder header's")
    except (KeyError, TypeError, ValueError, AttributeError, agent_core.AgentEvalError, agent_compare.CompareError) as e:
        add("the certificate is well formed and its ladders readable", False, type(e).__name__ + ": " + str(e)[:100])
        return out
    if round_base is not None:
        try:
            rid = cert["round"]["id"]
            probs = AR.verify_round(round_base, rid)
            add("the round's own files verify", not probs, probs[0] if probs else "")
            try:
                log = R.read_log(AR.rdir(round_base, rid))
            except Exception:
                log = []
            heads = [i for i, e in enumerate(log) if e.get("hash") == cert["round"]["log_head"]]
            add("the certificate's log head is in the round's log", bool(heads))
            add("the certificate's log length is the position of that head", bool(heads) and cert["round"]["log_entries"] == heads[0] + 1)
            add("the entry's configuration hash is the logged one", any(e["kind"] == "entry" and e["data"]["config_sha256"] == cert["candidate"]["config_sha256"] and e["data"]["eid"] == cert["candidate"]["eid"] for e in log))
            add("the handle named in the statement is the one the log recorded for that entry", any(e["kind"] == "entry" and e["data"]["eid"] == cert["candidate"]["eid"] and e["data"]["handle"] == cert["candidate"]["handle"] for e in log))
        except (KeyError, TypeError, AttributeError, ValueError) as e:
            add("the round check could be run on this certificate", False, type(e).__name__ + ": " + str(e)[:100])
    att = cert.get("attestation")
    if att is not None:
        if not (proxy_log and proxy_trusted and round_base is not None):
            add("the claimed attestation is re-checked", False, "the certificate claims an attestation: give --proxy-log, --proxy-trusted (YOUR pinned keys) and --round-base to check it")
        else:
            try:
                import agent_proxy
                log = agent_proxy.read_log(proxy_log)
                aprobs, info = agent_proxy.verify_round_http(round_base, cert["round"]["id"], log, set(proxy_trusted))
                add("the proxy log attests every model call of every arm under the verifier's pinned keys", not aprobs, aprobs[0] if aprobs else "")
                add("the attestation's log hash, arms and exchange count are the proxy log's own",
                    isinstance(att, dict) and att.get("kind") == ATTESTATION_KIND and att.get("proxy_log_sha256") == agent_core.file_sha256(proxy_log) and att.get("arms") == info.get("arms")
                    and att.get("exchanges") == len(log))
                add("every key the certificate names is one the verifier pinned", isinstance(att, dict) and set(att.get("proxy_keys", [])) <= set(proxy_trusted))
            except (OSError, KeyError, TypeError, ValueError, AttributeError, agent_core.AgentEvalError) as e:
                add("the claimed attestation is re-checked", False, type(e).__name__ + ": " + str(e)[:100])
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("build")
    p.add_argument("--base", default=".")
    p.add_argument("--round", required=True)
    p.add_argument("--entry", required=True)
    p.add_argument("--min-factor", type=float)
    p.add_argument("--min-solve-rate", type=float)
    p.add_argument("--key")
    p.add_argument("--proxy-log", help="the recording proxy's log: the whole round is attested against it first, and the attestation embedded")
    p.add_argument("--proxy-trusted", help="file of the verifier's public keys (one hex per line) that must have signed the proxy log")
    p.add_argument("--out", required=True)
    p = sub.add_parser("verify")
    p.add_argument("cert")
    p.add_argument("--baseline", required=True)
    p.add_argument("--candidate", required=True)
    p.add_argument("--seed")
    p.add_argument("--practice", action="store_true")
    p.add_argument("--round-base")
    p.add_argument("--trusted")
    p.add_argument("--proxy-log", help="the recording proxy's log, to re-check a claimed attestation")
    p.add_argument("--proxy-trusted", help="file of YOUR pinned proxy public keys")
    p = sub.add_parser("show")
    p.add_argument("cert")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "build":
            ptrusted = None
            if args.proxy_trusted:
                import agent_sig
                ptrusted = agent_sig.read_trusted(args.proxy_trusted)
            doc = build(args.base, args.round, args.entry, args.min_factor, args.min_solve_rate, args.key, args.proxy_log, ptrusted)
            with open(args.out, "w", encoding="utf-8") as f:
                f.write(json.dumps(doc, indent=1, sort_keys=True) + "\n")
            cert = doc.get("statement") if "signature" in doc else doc
            print(cert["statement"] if "statement" in cert else "")
            print("wrote " + args.out + (" (signed)" if "signature" in doc else " (unsigned)"))
        elif args.cmd == "verify":
            master = agent_core.read_master(args.seed, args.practice)
            with open(args.cert, "r", encoding="utf-8") as f:
                doc = json.load(f)
            trusted = None
            if args.trusted:
                import agent_sig
                trusted = agent_sig.read_trusted(args.trusted)
            ptrusted = None
            if args.proxy_trusted:
                import agent_sig
                ptrusted = agent_sig.read_trusted(args.proxy_trusted)
            rows = verify_certificate(doc, args.baseline, args.candidate, master, trusted, args.round_base, args.proxy_log, ptrusted)
            for name, ok, detail in rows:
                print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  (" + detail + ")") if detail else ""))
            good = all(ok for _, ok, _ in rows)
            print("CERTIFICATE %s" % ("VERIFIED" if good else "NOT VERIFIED"))
            return 0 if good else 1
        elif args.cmd == "show":
            with open(args.cert, "r", encoding="utf-8") as f:
                doc = json.load(f)
            cert = doc["statement"] if "signature" in doc else doc
            print(cert["statement"])
            for cl in cert["claims"]:
                print("%s: %s" % ("CONFIRMED" if cl["confirmed"] else "NOT CONFIRMED", cl["text"]))
            print("Not shown:")
            for line in cert["not_shown"]:
                print("  - " + line)
    except (AR.Rejected, agent_core.AgentEvalError, OSError, ValueError, KeyError) as e:
        print("error: %s" % (e.args[0] if e.args else e), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
