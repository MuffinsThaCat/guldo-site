"""aiinfer speedup 1: the same float64 network, the whole batch in one BLAS matmul per layer.
"""
import math

import numpy as np

_GOLD = 0x9E3779B97F4A7C15
_C1 = 0xBF58476D1CE4E5B9
_C2 = 0x94D049BB133111EB
_CLASSES = 10


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0



def _model(seed, d, batch):
    s = math.sqrt(3.0 / d)
    o = 0
    W1 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W2 = (_uniform(seed, o, d * d) * s).reshape(d, d)
    o += d * d
    W3 = (_uniform(seed, o, _CLASSES * d) * s).reshape(_CLASSES, d)
    o += _CLASSES * d
    X = _uniform(seed, o, batch * d).reshape(batch, d)
    return W1, W2, W3, X

def solve(seed, d, batch):
    W1, W2, W3, X = _model(seed, d, batch)
    h = np.maximum(X @ W1.T, 0.0)
    h = np.maximum(h @ W2.T, 0.0)
    return [int(c) for c in (h @ W3.T).argmax(axis=1)]
