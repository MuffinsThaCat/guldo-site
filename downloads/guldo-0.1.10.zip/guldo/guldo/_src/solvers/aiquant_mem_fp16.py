"""aiquant with bytes counted (tflops_mem.py), SPEEDUP: the embeddings, weights and positions are cast to fp16 once, so every step reads them at fewer bytes (the arithmetic is rounded to fp16 too: the judge sees any loss)."""
import math

import tensorops as tp

V, D, H = 64, 128, 512
W_SCALE, POS_SCALE = 4.0, 3.0


def rms(x):
    return x / tp.sqrt(tp.mean(x * x, -1, True) + 1e-6)


def solve(seed, T):
    sd, sf = W_SCALE * math.sqrt(3.0 / D), W_SCALE * math.sqrt(3.0 / H)
    n0 = V * D
    n1 = D * H
    E = tp.stream(seed, 0, n0, (V, D)) * math.sqrt(3.0)
    W1 = tp.stream(seed, n0, n1, (D, H)) * sd
    W2 = tp.stream(seed, n0 + n1, n1, (H, D)) * sf
    pos = tp.stream(seed, n0 + 2 * n1, T * D, (T, D)) * (POS_SCALE * math.sqrt(3.0))
    tok = min(int((tp.stream(seed, n0 + 2 * n1 + T * D, 1).tolist()[0] + 1.0) * 0.5 * V), V - 1)
    E = tp.cast(E, "fp16")
    W1 = tp.cast(W1, "fp16")
    W2 = tp.cast(W2, "fp16")
    pos = tp.cast(pos, "fp16")
    ET = tp.transpose(E, (1, 0))
    out = []
    for t in range(T):
        x = tp.take(E, tok) + pos[t]
        y = x + tp.relu(rms(x) @ W1) @ W2
        tok = tp.argmax(rms(y) @ ET)
        out.append(tok)
    return out
