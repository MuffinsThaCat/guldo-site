"""Declaration of a hidden-number-problem domain (the lattice attack on ECDSA/DSA with biased nonces, in a clean form).

A solver receives (p, K, ts, us): p a prime of `size` bits, K = 4, and for a hidden alpha in [1, p-1] the leak u_i = the top K bits of
(alpha * t_i mod p), i.e. u_i = ((alpha * t_i) mod p) >> (bitlen(p) - K), for m = size // 2 + 6 random multipliers t_i. It returns an integer
alpha' in [1, p-1] consistent with every leak. At these parameters alpha is the only consistent value with overwhelming probability.
size = bit length of p; the reference is exhaustive search over alpha (2^size). Boneh-Venkatesan style lattice attacks solve this in polynomial time.
"""
import hashlib
import hmac
import random

import instances  # the project's Miller-Rabin test

NAME = "hnp"
VERSION = "hnp-v1"           # bump whenever derive() changes
SIZE_RANGE = (22, 31)
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
K = 4
DOC = ("solve(p, K, ts, us): return an integer alpha with 1 <= alpha < p and ((alpha * t) % p) >> (p.bit_length() - K) == u for every pair (t, u) in "
       "(ts, us). Return None for no answer.")
REFERENCE_NOTE = ("The reference is exhaustive search over alpha (2^size) with a one-sample pre-check. Lattice reduction (CVP/SVP embedding, Boneh-Venkatesan) is "
                  "known to solve it in polynomial time given enough leaked bits; no claim is made about which is fastest. Scope: toy moduli "
                  "(<= 31 bits, 4 leaked bits per sample), NOT evidence about attacks on real ECDSA deployments, and a certificate here must not be read as one.")


def _prime(rng, bits):
    while True:
        c = rng.getrandbits(bits) | (1 << (bits - 1)) | 1
        if instances._is_prime(c):
            return c


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"hnp-v1:{size}:{idx}".encode(), hashlib.sha256).digest())
    p = _prime(rng, size)
    alpha = rng.randrange(1, p)
    m = size // 2 + 6
    ts = [rng.randrange(1, p) for _ in range(m)]
    sh = size - K
    us = [((alpha * t) % p) >> sh for t in ts]
    return {"args": [p, K, ts, us], "planted": alpha}


def verify(inst: dict, ans) -> bool:
    p, k, ts, us = inst["args"]
    if isinstance(ans, bool) or not isinstance(ans, int) or not 1 <= ans < p:
        return False
    sh = p.bit_length() - k
    return all(((ans * t) % p) >> sh == u for t, u in zip(ts, us))
