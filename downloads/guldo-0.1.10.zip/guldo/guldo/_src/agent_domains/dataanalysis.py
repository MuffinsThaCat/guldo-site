"""Data analysis: answer one aggregate question about a hidden table that can only be reached through tools.

size = number of rows (200..1000). Difficulty grows with the table (more rows to get through without the right tool) and with the number of conditions in the question
(1 to 3). The table, the question and the answer are a pure function of the instance seed. The agent is never given the table: `describe` gives the columns, `rows` pages
through it 50 rows at a time (expensive: every page is re-sent in the context of every later turn), and `aggregate` computes count/sum/mean/min/max over any filter in one call.
An agent that knows to use `aggregate` is far cheaper than one that reads the table, and both can be right: that difference is exactly what a cost-and-success certificate measures.

The answer is a number. A mean is accepted within 0.0051 of the true value (the question asks for 2 decimals); every other answer must be exact.
"""
import agent_core

NAME = "dataanalysis"
VERSION = "dataanalysis-v1"
SIZE_RANGE = (200, 1000)
SIZE_STEP = 200
DOC = "Answer a numeric aggregate question about a table you can only query through the tools. Submit the number."
GROUPS = ["alpha", "bravo", "charlie", "delta", "echo"]
COLUMNS = ["id", "g", "x", "y", "z"]
PAGE = 50
MEAN_TOL = 0.0051
OPS = ("count", "sum", "mean", "min", "max")
CMPS = ("==", "!=", ">", ">=", "<", "<=")


def _rows(r, size):
    return [{"id": i, "g": r.choice(GROUPS), "x": r.randint(0, 100), "y": r.randint(-500, 1500), "z": r.randint(1, 9)} for i in range(size)]


def _match(row, where):
    for col, cmp_, val in where:
        a = row[col]
        ok = {"==": a == val, "!=": a != val, ">": a > val, ">=": a >= val, "<": a < val, "<=": a <= val}[cmp_]
        if not ok:
            return False
    return True


def aggregate(rows, op, column, where):
    sel = [row for row in rows if _match(row, where)]
    if op == "count":
        return len(sel)
    vals = [row[column] for row in sel]
    if not vals:
        return None
    if op == "sum":
        return sum(vals)
    if op == "mean":
        return sum(vals) / float(len(vals))
    if op == "min":
        return min(vals)
    if op == "max":
        return max(vals)
    raise ValueError(op)


def _where_text(where):
    parts = []
    for col, cmp_, val in where:
        parts.append("%s %s %s" % (col, cmp_, ("'%s'" % val) if isinstance(val, str) else val))
    return " and ".join(parts)


def derive(seed, size):
    r = agent_core.Rng(seed)
    nfilters = 1 + (size - SIZE_RANGE[0]) // SIZE_STEP // 2
    for _ in range(200):
        rows = _rows(r, size)
        pool = [("g", "==", r.choice(GROUPS)), ("x", ">", r.randint(20, 80)), ("x", "<=", r.randint(30, 90)), ("z", ">=", r.randint(2, 7)), ("y", ">", r.randint(-200, 900))]
        used, where = set(), []
        for cand in r.sample(pool, len(pool)):
            if cand[0] in used or len(where) >= nfilters:
                continue
            used.add(cand[0])
            where.append(cand)
        op = r.choice(OPS)
        column = "id" if op == "count" else r.choice(["x", "y", "z"])
        sel = [row for row in rows if _match(row, where)]
        if len(sel) < 3:
            continue
        answer = aggregate(rows, op, column, where)
        if op == "mean":
            answer = round(answer, 2)
        what = {"count": "the number of rows", "sum": "the sum of %s" % column, "mean": "the mean of %s" % column, "min": "the minimum of %s" % column, "max": "the maximum of %s" % column}[op]
        rounding = " Round to 2 decimals." if op == "mean" else ""
        question = "Over the rows where %s, what is %s?%s Submit the number." % (_where_text(where), what, rounding)
        return {"public": {"question": question, "columns": COLUMNS, "n_rows": size},
                "private": {"rows": rows, "answer": answer, "op": op, "column": column, "where": [list(w) for w in where]}}
    raise RuntimeError("could not derive a non-degenerate instance")


def prompt(public):
    return "%s\nThe table has %d rows and is reachable only through the tools." % (public["question"], public["n_rows"])


def tool_specs(public):
    return [
        {"name": "describe", "description": "Columns and number of rows of the table.", "input_schema": {"type": "object", "properties": {}}},
        {"name": "rows", "description": "A page of raw rows as CSV, at most %d rows." % PAGE,
         "input_schema": {"type": "object", "properties": {"offset": {"type": "integer"}, "limit": {"type": "integer"}}, "required": ["offset"]}},
        {"name": "aggregate", "description": "Compute an aggregate over the rows matching ALL conditions in `where` (a list of [column, comparison, value]).",
         "input_schema": {"type": "object", "properties": {"op": {"type": "string", "enum": list(OPS)}, "column": {"type": "string"},
                                                           "where": {"type": "array", "items": {"type": "array"}}}, "required": ["op", "column"]}},
    ]


class Env:
    def __init__(self, instance):
        self.rows = instance["private"]["rows"]

    def call(self, name, args):
        if not isinstance(args, dict):
            return "error: arguments must be an object"
        if name == "describe":
            return "columns: %s; rows: %d; g is one of %s" % (",".join(COLUMNS), len(self.rows), ",".join(GROUPS))
        if name == "rows":
            # a null for an optional value means "the default" (real models send null for what they do not want to set: seen on the first real run)
            off, lim = args.get("offset"), args.get("limit", PAGE)
            off = 0 if off is None else off
            lim = PAGE if lim is None else lim
            if not isinstance(off, int) or isinstance(off, bool) or not isinstance(lim, int) or isinstance(lim, bool) or off < 0 or lim < 1:
                return "error: offset and limit must be non-negative integers"
            lim = min(lim, PAGE)
            page = self.rows[off:off + lim]
            return "\n".join(",".join(str(row[c]) for c in COLUMNS) for row in page) if page else "(no more rows)"
        if name == "aggregate":
            op, col, where = args.get("op"), args.get("column"), args.get("where", [])
            if op == "count" and col is None:
                col = "id"                                         # a count needs no column; models pass null or omit it (seen on the first real run)
            if where is None:
                where = []
            if op not in OPS or col not in COLUMNS or not isinstance(where, list):
                return "error: bad op, column or where"
            conds = []
            for w in where:
                if not isinstance(w, (list, tuple)) or len(w) != 3 or w[0] not in COLUMNS or w[1] not in CMPS:
                    return "error: each condition is [column, comparison, value]"
                if (w[0] == "g") != isinstance(w[2], str) or isinstance(w[2], bool) or not isinstance(w[2], (int, str)):
                    return "error: value type does not fit the column"
                conds.append((w[0], w[1], w[2]))
            res = aggregate(self.rows, op, col, conds)
            return "none (no rows match)" if res is None else (("%.4f" % res) if isinstance(res, float) else str(res))
        return "error: unknown tool %r" % name


def make_env(instance):
    return Env(instance)


def reference_answer(instance):
    return instance["private"]["answer"]


def verify(instance, answer, calls):
    truth = instance["private"]["answer"]
    try:
        if isinstance(answer, bool):
            raise ValueError
        a = float(answer) if not isinstance(answer, str) else float(answer.strip())
    except (TypeError, ValueError):
        return False, "answer is not a number"
    if a != a or a in (float("inf"), float("-inf")):
        return False, "answer is not finite"
    if instance["private"]["op"] == "mean":
        return (abs(a - truth) <= MEAN_TOL), ("ok" if abs(a - truth) <= MEAN_TOL else "wrong value")
    return (a == truth), ("ok" if a == truth else "wrong value")
