"""Declaration of an AI-quantisation domain: greedy generation from a small residual-MLP language model, token for token correct, with as few BYTES moved as you can.

size = T, the number of tokens to generate after a 1-token prompt. The model (vocabulary 64, width 128, hidden 512, tied output embedding, learned absolute positions, RMS norms, one
residual ReLU block) is a pure function of one seed through the pinned SplitMix64 stream the other AI domains use (layout in reference.py), so a counted solver regenerates it with
tensorops.stream. Each new token depends on the previous one, so the steps cannot be batched: every step reads all the weights. That is the memory-bound regime quantisation is for.

A count of operations cannot see quantisation (an fp16 multiply is one operation like an fp64 one), so this domain is measured with tflops_mem.py, which counts BYTES moved and PEAK memory
as well, under a declared precision per tensor (`tp.cast(x, "fp16")`); tflops_compare.py compares two solvers on bytes. The reference runs in float64. Holding the weights in fp16 (or
fp32) moves a quarter (a half) of the bytes of every step; an accuracy loss from the lower precision is not hidden, because the arithmetic is really rounded to that width.

Verification is TEACHER-FORCED: the judge runs the model once, in float64 and in parallel, over the prompt and the submitted tokens and accepts iff every submitted token's logit is within
TOL_SIGMA (0.05) standard deviations of the best logit at its position. fp16 weights pass (their rounding is far inside that); a technique that damages the model (skipping the MLP block,
pruning weights hard, repeating a token) fails at the first position where it disagrees. Weights are scaled (W_SCALE, POS_SCALE) so the greedy output is NOT degenerate: with small
scales the model repeats one or two tokens for ever (measured, and why the scales are what they are).

What this cannot show: a real memory system. Bytes are an accounting convention over shapes and declared widths (no cache, no fusion). It certifies "N times fewer bytes under these
rules", not "N times faster", and integer (int8/int4) formats are not in the accounting: only fp64, fp32 and fp16.
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aiquant"
VERSION = "aiquant-v1"        # bump whenever derive() or the model definition changes
SPEEDUP = "ai-inference"
SIZE_RANGE = (64, 384)
SIZE_STEP = 64
REFERENCE_SOLVER = "reference.py"
V, D, H = 64, 128, 512
W_SCALE, POS_SCALE = 4.0, 3.0
TOL_SIGMA = 0.05
DOC = ("solve(seed, T): rebuild the model from `seed` (SplitMix64 stream via tensorops.stream, layout in domains/aiquant/reference.py), start from the 1-token prompt and generate T tokens "
       "greedily, each from the previous token and its position: x = E[prev] + pos[t]; y = x + relu(rms(x) W1) W2; logits = rms(y) E^T; the token is the argmax. Return the list of T "
       "token ids. Every returned token must be, at its position, within 0.05 standard deviations of the best logit given your own earlier tokens (fp16 weights pass; a skipped block, "
       "heavy pruning or a repeated token do not). Return None for no answer.")
REFERENCE_NOTE = ("float64 throughout: every step reads the full weight matrices at 8 bytes per value. Known to be beaten, on bytes moved, by holding the weights in fp32 (half) or fp16 "
                  "(a quarter) once at the start, with no change in the tokens; the saving approaches the width ratio as T grows.")


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _params(seed, T):
    o = [0]

    def take(shape, scale):
        n = int(np.prod(shape))
        a = (_uniform(seed, o[0], n) * scale).reshape(shape)
        o[0] += n
        return a
    sd, sf = W_SCALE * math.sqrt(3.0 / D), W_SCALE * math.sqrt(3.0 / H)
    P = {"E": take((V, D), math.sqrt(3.0)), "W1": take((D, H), sd), "W2": take((H, D), sf), "pos": take((T, D), POS_SCALE * math.sqrt(3.0))}
    P["first"] = min(int((_uniform(seed, o[0], 1)[0] + 1.0) * 0.5 * V), V - 1)
    return P


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def _logits(P, toks):
    """Logits at every position at once: toks[t] is the INPUT token of position t. The judge's definition of the model."""
    x = P["E"][toks] + P["pos"][:len(toks)]
    y = x + np.maximum(_rms(x) @ P["W1"], 0.0) @ P["W2"]
    return _rms(y) @ P["E"].T


def _greedy(P, T):
    tok, out = P["first"], []
    for t in range(T):
        tok = int(np.argmax(_logits(P, [tok] * (t + 1))[t]))      # position t only needs its own input; the others are ignored
        out.append(tok)
    return out


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aiquant-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    return {"args": [seed, size], "planted": _greedy(_params(seed, size), size)}


def verify(inst: dict, ans) -> bool:
    seed, T = inst["args"]
    if not isinstance(ans, list) or len(ans) != T:
        return False
    if any(isinstance(c, bool) or not isinstance(c, int) or not 0 <= c < V for c in ans):
        return False
    P = _params(seed, T)
    L = _logits(P, [P["first"]] + [int(c) for c in ans[:-1]])
    tol = TOL_SIGMA * float(L.std())
    return bool(np.all(L[np.arange(T), np.asarray(ans)] >= L.max(axis=1) - tol))
