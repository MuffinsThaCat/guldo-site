"""Counted-OPERATIONS costs for AI workloads: the one cost for tensor code that anyone can reproduce exactly, on any machine.

  python3 tflops.py practice SOLVER --baseline REF --family aidecode --dims 64 96 128 --n 8 --cap 2000 [--seed SEEDFILE]
  python3 tflops.py claim BASELINE_LADDER SUBMISSION_LADDER          the estimator's credit on the two ladders (extrapolate.py, unchanged)
  python3 tflops.py verify LADDER [LADDER ...] [--rerun K] [--seed SEEDFILE]
  python3 tflops.py selfcheck SOLVER --family aidecode --dim 64      does the same instance count the same twice?

A solver is written in the restricted subset PLUS `import tensorops as tp` (tensorops.py): every tensor operation charges an analytic cost computed from shapes, and
its own Python is charged one unit per bytecode instruction (tflops_runner.py). cost = flops + steps; one "counted second" = 1e7 such operations, so the estimator's
0.5 s floor is 5e6 operations. Ladders are written in the ordinary format, so extrapolate.py reads them unchanged; `verify` redoes every cost from its record and, with
--rerun K, re-executes K records per ladder, drawn at random by the verifier (the draw's seed is printed), and demands IDENTICAL status, flops and steps: no tolerance, and no
trust in anyone's clock or hardware. A ladder with a fraction f of fabricated records passes a sample of K only with probability (1-f)^K, which is printed; the records
not sampled are checked for internal consistency only. `--rerun all` re-executes every record: a full audit.

SAFETY: the solver runs in the operator's process tree with NO container. What contains it is the restricted subset (no files, frames, getattr, eval, imports beyond math,
itertools and tensorops), the size and live-memory caps on tensors (tensorops.py), and a PARENT-side watchdog that samples the child's resident memory every 50 ms and
kills it past MAX_RSS_MB (so a Python-level allocation such as `[0.0] * 10**9` is stopped on macOS too, overshooting by at most what one 50 ms interval can touch). It is not
an operating-system sandbox: there is no file, network or process isolation beyond the restricted subset. Run untrusted solvers as an unprivileged throwaway user on a
machine you can lose; this tool refuses to run as root.

What a verified ladder shows, printed with every verdict: how many OPERATIONS the solver asked for versus the baseline. It is not a time. It cannot see memory traffic,
cache, vectorisation, dtype or kernel quality, so it certifies "N times fewer operations" (a KV cache, pruning, early exit, a smaller model at equal output) and cannot
certify "faster at the same arithmetic"; use a timed domain for that. Work inside one C call other than a tensor op is one instruction (as in counted.py). It needs
Python 3.12+. It is NOT wired into rounds, the portal or certificate.py: `verify` here is the checker. The counting program (tflops_runner.py, tensorops.py and the
unchanged count_runner.py it reuses) is pinned by hash in every ladder; a different counter is named as such.
"""
import argparse
import hashlib
import json
import os
import random
import secrets
import subprocess
import sys
import tempfile
import time

import declared
import instances

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(HERE, "tflops_runner.py")
UNIT_OPS = 10_000_000             # 1 "counted second" = 1e7 operations (a unit, not a duration). Chosen so the estimator's 0.5 s floor is 5e6 operations: a KV-cached
#                                   decoder costs about 0.8e6 operations per token, so with 1e9 it would stay under the floor until T ~ 600 (where the reference costs ~150
#                                   units) and nothing smaller could ever be certified; with 1e7 it clears the floor at small T and the reference is still affordable to count
SLOW_OPS_PER_SECOND = 20_000_000  # pessimistic wall throughput: used only for the wall-clock backstop
MAX_RSS_MB = 4096                 # the most resident memory a counted solver may reach (the timed sandbox allows 4 GB too); enforced by the parent on every platform
MIN_PYTHON = (3, 12)
COUNTER_FILES = ("tflops_runner.py", "tensorops.py", "count_runner.py")
CLAIM_LIMITS = ("A count is not a time. It measures arithmetic asked for (tensor operations by shape, plus the solver's own Python instructions), not speed: memory traffic, "
                "cache, vectorisation, dtype and kernel quality are invisible to it, so it can show 'N times fewer operations' and cannot show 'faster at the same arithmetic'. "
                "The ladder is the prover's unless it was fixed in advance.")


def python_version():
    v = sys.version_info
    return f"{sys.implementation.name} {v.major}.{v.minor}.{v.micro}"


def counter_sha256():
    h = hashlib.sha256()
    for name in COUNTER_FILES:
        with open(os.path.join(HERE, name), "rb") as f:
            h.update(name.encode() + b"\0" + hashlib.sha256(f.read()).digest())
    return h.hexdigest()


def sha256_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def load_family(name):
    d = os.path.join(declared.domains_dir(), name)
    mod = declared.load_declaration(d)
    derive, verify = declared.make_spec(mod)
    return mod, derive, verify, d


def _rss_mb(pid):
    """Resident memory of a process in MB, read by the PARENT with `ps` (works on macOS and Linux). 0 when it cannot be read (the process is gone)."""
    try:
        out = subprocess.run(["ps", "-o", "rss=", "-p", str(pid)], capture_output=True, text=True, timeout=5).stdout.strip()
        return int(out) / 1024.0 if out else 0.0
    except (OSError, ValueError, subprocess.SubprocessError):
        return 0.0


def _run_watched(argv, payload, env, cwd, wall_timeout, max_rss_mb, poll=0.05):
    """Run a child with a PARENT-side memory and wall-clock watchdog. -> (stdout, stderr, killed) with killed in (None, "memory", "wall").
    Why the parent: a solver can allocate gigabytes in ONE C call (`[0.0] * 10**9`), which holds the GIL, so a watchdog thread inside the child would never get to run, and
    macOS has no working address-space limit. A separate process sampling the child's resident size every `poll` seconds does not depend on either."""
    p = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, cwd=cwd)
    deadline, first = time.time() + wall_timeout, True
    while True:
        try:
            out, err = p.communicate(input=payload if first else None, timeout=poll)
            return out, err, None
        except subprocess.TimeoutExpired:
            first = False
        killed = "memory" if _rss_mb(p.pid) > max_rss_mb else "wall" if time.time() > deadline else None
        if killed:
            p.kill()
            out, err = p.communicate()
            return out, err, killed


def count_instance(solver, inst, verify, cap, max_rss_mb=MAX_RSS_MB):
    """Run `solver` on `inst` under operation counting. -> a ladder record: id, dim, status (solved/failed/wrong/crash/timeout), steps, flops, cpu, cpu_net, wall.
    A child whose resident memory passes `max_rss_mb` is killed and recorded as a crash charged the cap."""
    limit = int(cap * UNIT_OPS)
    rec = {"id": inst["id"], "dim": inst["dim"]}
    payload = json.dumps({"args": inst["args"], "limit": limit}).encode()
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "1", "PATH": os.environ.get("PATH", "")}
    t0 = time.time()
    with tempfile.TemporaryDirectory() as empty:
        stdout, stderr, killed = _run_watched([sys.executable, "-B", RUNNER, os.path.abspath(solver)], payload, env, empty, limit / SLOW_OPS_PER_SECOND + 120, max_rss_mb)
    rec["wall"] = time.time() - t0
    if killed == "wall":
        rec.update({"status": "timeout", "steps": None, "flops": None, "wall_timeout": True, "cpu": cap, "cpu_net": cap})
        return rec
    if killed == "memory":
        rec.update({"status": "crash", "steps": None, "flops": None, "cpu": cap, "cpu_net": cap, "err": f"killed: resident memory passed {max_rss_mb} MB"})
        return rec
    lines = [ln for ln in stdout.decode(errors="replace").splitlines() if ln.strip()]
    try:
        out = json.loads(lines[-1])
        steps, flops, status = int(out["steps"]), int(out["flops"]), out["status"]
    except (IndexError, ValueError, KeyError, TypeError):
        rec.update({"status": "crash", "steps": None, "flops": None, "cpu": cap, "cpu_net": cap,
                    "err": "the counter produced no result: " + stderr.decode(errors="replace")[-300:]})
        return rec
    rec["steps"], rec["flops"] = steps, flops
    if status == "limit":
        rec.update({"status": "timeout", "cpu": cap, "cpu_net": cap})
    elif status == "error":
        rec.update({"status": "crash", "cpu": cap, "cpu_net": cap, "err": str(out.get("err", ""))[-1500:]})
    else:
        ans = out.get("ans")
        try:
            ok = bool(verify(inst, ans))
        except Exception as e:     # a verifier that RAISES is the operator's bug, not a wrong answer: say so in the record instead of passing for `wrong`
            ok = False
            rec["verify_error"] = f"{type(e).__name__}: {str(e)[:200]}"
        rec["status"] = "solved" if ok else ("failed" if ans is None else "wrong")
        rec["cpu"] = (steps + flops) / UNIT_OPS
        rec["cpu_net"] = max(rec["cpu"], 1e-3)
        if rec["status"] != "solved":
            rec["cpu"] = rec["cpu_net"] = cap
    return rec


def ladder_header(solver, family, mod, decl_dir, master, cap):
    return {"meta": True, "solver": os.path.basename(solver), "commit": instances.commit(master), "overhead": 0.0, "budget": cap, "family": family,
            "sandbox": "tflops", "instance_version": mod.VERSION, "image": None, "host": "analytic operation counting (no machine timing)",
            "cpu": "none: operation counts", "ncpu": 1, "jobs": 1, "solver_sha256": sha256_file(solver),
            "cost_model": "tflops", "unit_ops": UNIT_OPS, "python": python_version(), "counter_sha256": counter_sha256(),
            "decl_sha256": sha256_file(os.path.join(decl_dir, "decl.py"))}


def evaluate_ladder(solver, family, master, dims, n, cap, out_path, progress=None):
    if os.path.exists(out_path):
        raise FileExistsError(out_path)
    mod, derive, verify, d = load_family(family)
    fd = os.open(out_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    recs = []
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps(ladder_header(solver, family, mod, d, master, cap)) + "\n")
        for dim in dims:
            for idx in range(n):
                rec = count_instance(solver, derive(master, dim, idx), verify, cap)
                f.write(json.dumps(rec) + "\n")
                f.flush()
                recs.append(rec)
                if progress:
                    progress(os.path.basename(solver), rec)
    return recs


def read_ladder(path):
    with open(path, encoding="utf-8") as f:
        rows = [json.loads(ln) for ln in f if ln.strip()]
    meta = rows[0] if rows and rows[0].get("meta") else None
    return meta, [r for r in rows if not r.get("meta")]


def _master(args, meta=None):
    if args.seed:
        with open(args.seed, "rb") as f:
            return f.read().strip()
    return instances.PRACTICE_SEED


def verify_ladder(path, rerun=0, master=None, solver_path=None, sample_seed=None):
    """-> (ok, [lines]). The cost-model check on every record; with rerun > 0 also the exact re-execution of that many instances, or of ALL of them with rerun="all".
    The sample is drawn by the VERIFIER, at random (the draw's seed is printed, so a run can be reproduced): a prover cannot know which records will be re-executed, so one
    who fabricated a fraction f of the records escapes a sample of k only with probability (1-f)^k, which is also printed."""
    lines, ok = [], True
    meta, recs = read_ladder(path)
    if meta is None or meta.get("cost_model") != "tflops":
        return False, [f"FAIL {os.path.basename(path)}: not a tflops ladder"]
    cap, unit = meta.get("budget"), meta.get("unit_ops")
    if isinstance(cap, bool) or not isinstance(cap, (int, float)) or cap <= 0 or "solver_sha256" not in meta or "commit" not in meta:
        return False, [f"FAIL {os.path.basename(path)}: the header lacks a positive budget, a seed commitment or a solver hash"]
    if not recs:
        return False, [f"FAIL {os.path.basename(path)}: the ladder holds no records (an empty ladder certifies nothing, and a full audit of nothing would pass vacuously)"]
    if unit != UNIT_OPS:
        ok = False
        lines.append(f"FAIL unit: the ladder's unit is {unit}, this checkout's is {UNIT_OPS}")
    if meta.get("counter_sha256") != counter_sha256():
        ok = False
        lines.append("FAIL counter: the ladder was counted by a different counting program (hash differs from this checkout's): re-measure with this one")
    bad = 0
    isint = lambda v: isinstance(v, int) and not isinstance(v, bool) and v >= 0
    for r in recs:
        try:
            if r["status"] == "solved":
                if not (isint(r["steps"]) and isint(r["flops"])):
                    bad += 1                       # a solved record must carry the exact counts the cost is made of
                    continue
                exp = (r["steps"] + r["flops"]) / UNIT_OPS
                if abs(r["cpu"] - exp) > 1e-12 or abs(r["cpu_net"] - max(exp, 1e-3)) > 1e-12:
                    bad += 1
            elif r["cpu_net"] != cap:
                bad += 1
        except (KeyError, TypeError):              # a malformed or hand-edited record is a failed check, never a crash
            bad += 1
    lines.append(f"{'PASS' if not bad else 'FAIL'} cost model: every solved cost = (flops + steps) / {UNIT_OPS:g} and every unsolved instance is charged the cap" + (f" ({bad} records disagree)" if bad else ""))
    ok = ok and not bad
    if rerun:
        if meta.get("python") != python_version():
            lines.append(f"SKIP re-run: ladder counted on {meta.get('python')}, this interpreter is {python_version()} (counts are only comparable on the same one)")
            ok = False                                 # a re-run that was asked for and did not happen is not a pass
        else:
            solver = solver_path or os.path.join(HERE, "solvers", meta["solver"])
            if not os.path.exists(solver) or sha256_file(solver) != meta["solver_sha256"]:
                lines.append(f"FAIL re-run: the solver file {meta['solver']} is missing here or its hash differs from the ladder's")
                return False, lines
            mod, derive, verify, d = load_family(meta["family"])
            if sha256_file(os.path.join(d, "decl.py")) != meta.get("decl_sha256"):
                lines.append("FAIL re-run: this checkout's decl.py differs from the one the ladder was made with")
                return False, lines
            if instances.commit(master) != meta["commit"]:
                lines.append("SKIP re-run: the seed given does not match the ladder's commitment (pass the revealed seed with --seed)")
                return False, lines                    # asked for, not done: not a pass
            k = len(recs) if rerun == "all" else min(int(rerun), len(recs))
            if k >= len(recs):
                pick = list(recs)
                lines.append(f"FULL AUDIT: all {len(recs)} records are re-executed")
            else:
                seed = secrets.randbits(64) if sample_seed is None else sample_seed
                pick = random.Random(seed).sample(recs, k)
                lines.append(f"sample: {k} of {len(recs)} records drawn at random (sample seed {seed}); a ladder with a fraction f of fabricated records passes only with "
                             f"probability (1-f)^{k}, i.e. under 5% once f exceeds {100 * (1 - 0.05 ** (1.0 / k)):.0f}%")
            same = 0
            for r in pick:
                dim, idx = r["id"].split(":")
                again = count_instance(solver, derive(master, int(dim), int(idx)), verify, cap)
                if (again.get("status"), again.get("steps"), again.get("flops")) == (r["status"], r.get("steps"), r.get("flops")):
                    same += 1
                else:
                    lines.append(f"  differs at {r['id']}: recorded {r['status']} {r.get('steps')}+{r.get('flops')}, re-run {again.get('status')} {again.get('steps')}+{again.get('flops')}")
            good = same == len(pick)
            lines.append(f"{'PASS' if good else 'FAIL'} re-run: {same}/{len(pick)} instances re-executed with identical status, flops and steps")
            ok = ok and good
    return ok, lines


def baseline_reusable(path, solver, family, master, dims, n, cap):
    """-> (ok, why). An existing baseline ladder may be reused only if its header is identical to the one that would be written now (same seed, solver bytes, family and
    declaration, budget, interpreter and counter) and it holds exactly the expected instances, each once: a ladder left half-written by an interrupted run must not pass."""
    try:
        meta, recs = read_ladder(path)
    except (OSError, ValueError) as e:
        return False, f"unreadable ({type(e).__name__})"
    mod, derive, verify, d = load_family(family)
    if meta != ladder_header(solver, family, mod, d, master, cap):
        return False, "its header differs from the one this run would write (different seed, solver, declaration, budget, interpreter or counter)"
    want = {f"{dim}:{i}" for dim in dims for i in range(n)}
    got = [r.get("id") for r in recs]
    if len(got) != len(set(got)) or set(got) != want:
        return False, f"it holds {len(set(got) & want)} of the {len(want)} expected instances (an interrupted run, or a different ladder)"
    return True, ""


PLAN_FORMAT = "svp-ladder-plan-v1"


def plan_hash(plan):
    """The value to PUBLISH before any submission: sha256 of the plan's canonical JSON."""
    return hashlib.sha256(json.dumps(plan, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def plan_new(cost_model, family, dims, n, cap, master, extra=None):
    """A ladder plan: everything the prover would otherwise choose (the family, the sizes, how many instances per size, the budget, the seed commitment, the declaration
    and, for counted ladders, the counter) fixed in advance. Publish plan_hash(plan) somewhere the operator cannot edit BEFORE any solver is submitted; a ladder then
    verifies against the plan only if it matches it exactly. `extra` carries mode-specific pins (counter hash and unit for tflops, the device for the GPU meter)."""
    mod, derive, verify, d = load_family(family)
    plan = {"format": PLAN_FORMAT, "cost_model": cost_model, "family": family, "dims": sorted({int(x) for x in dims}), "n": int(n), "cap": cap,
            "commit": instances.commit(master), "instance_version": mod.VERSION, "decl_sha256": sha256_file(os.path.join(d, "decl.py")),
            "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    plan.update(extra or {})
    return plan


def check_plan(plan, meta, recs, expect_hash=None):
    """-> [problems] (empty: the ladder is exactly the planned one). Header fields, the pins in `extra`, and the exact instance set, each instance once."""
    problems = []
    if not isinstance(plan, dict) or plan.get("format") != PLAN_FORMAT:
        return [f"not a {PLAN_FORMAT} file"]
    if expect_hash is not None and plan_hash(plan) != expect_hash:
        problems.append("the plan file does not hash to the published value: it is not the plan that was committed to")
    for plan_key, meta_key in (("cost_model", "cost_model"), ("family", "family"), ("commit", "commit"), ("cap", "budget"), ("instance_version", "instance_version"),
                               ("decl_sha256", "decl_sha256"), ("counter_sha256", "counter_sha256"), ("unit_ops", "unit_ops"), ("cpu", "cpu")):
        if plan_key in plan and plan[plan_key] != meta.get(meta_key):
            problems.append(f"{meta_key}: the ladder has {meta.get(meta_key)!r}, the plan says {plan[plan_key]!r}")
    want = {f"{d}:{i}" for d in plan.get("dims", []) for i in range(int(plan.get("n", 0)))}
    got = [r.get("id") for r in recs]
    if len(got) != len(set(got)):
        problems.append("the ladder holds some instance more than once")
    if set(got) != want:
        problems.append(f"the ladder's instances are not the planned ones ({len(set(got) & want)} of {len(want)} planned present, {len(set(got) - want)} unplanned)")
    return problems


def load_plan(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def cmd_plan(a):
    master = _master(a)
    plan = plan_new("tflops", a.family, a.dims, a.n, a.cap, master, {"counter_sha256": counter_sha256(), "unit_ops": UNIT_OPS})
    fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)       # never overwrites a plan
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(plan, f, indent=1, sort_keys=True)
    print(f"plan written to {a.out}\nplan hash: {plan_hash(plan)}\nPublish this hash (somewhere the operator cannot edit) BEFORE any solver is submitted.")


def cmd_practice(a):
    master = _master(a)
    tag = instances.commit(master)[:8]
    if a.plan:
        plan = load_plan(a.plan)
        if (plan.get("family"), sorted(set(a.dims)), a.n, a.cap, plan.get("commit")) != (a.family, plan.get("dims"), plan.get("n"), plan.get("cap"), instances.commit(master)):
            sys.exit("refused: the dims, n, budget, family or seed on the command line are not the plan's. A planned ladder is run exactly as planned.")
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    paths = []
    for role, solver in (("baseline", a.baseline), ("submission", a.solver)):
        p = os.path.join(HERE, "results", f"tflops_{a.family}_{tag}_{role}_{os.path.basename(solver)}.jsonl")
        if os.path.exists(p) and role == "baseline" and a.reuse_baseline:
            ok, why = baseline_reusable(p, solver, a.family, master, a.dims, a.n, a.cap)
            if not ok:
                sys.exit(f"{p} exists but cannot be reused: {why}. Move it aside and run again.")
            paths.append(p)
            continue
        evaluate_ladder(solver, a.family, master, a.dims, a.n, a.cap, p, progress=lambda name, rec: print(f"  {name} {rec['id']}: {rec['status']} {rec.get('steps')}+{rec.get('flops')} ops", flush=True))
        paths.append(p)
    print("ladders:\n  " + "\n  ".join(paths))
    print("next: python3 tflops.py claim " + " ".join(paths))


def cmd_claim(a):
    r = subprocess.run([sys.executable, os.path.join(HERE, "extrapolate.py"), "--baseline", a.baseline, "--submission", a.submission], capture_output=True, text=True, cwd=HERE)
    print(r.stdout + r.stderr)
    if r.returncode:
        sys.exit(r.returncode)
    with open(a.submission + ".claim.json", encoding="utf-8") as f:
        c = json.load(f)
    print(f"credit (difficulty-stratified lower bound): {c.get('measured')} bits\n\nWhat this does NOT show: {CLAIM_LIMITS}")


def cmd_verify(a):
    master = _master(a)
    allok = True
    plan = load_plan(a.plan) if a.plan else None
    if a.plan_hash and not plan:
        sys.exit("--plan-hash needs --plan")
    for p in a.ladders:
        ok, lines = verify_ladder(p, a.rerun, master, sample_seed=a.sample_seed)
        if plan is not None:
            meta, recs = read_ladder(p)
            problems = check_plan(plan, meta or {}, recs, a.plan_hash)
            lines.append(("FAIL plan: " + "; ".join(problems)) if problems else "PASS plan: the ladder is exactly the committed plan" + ("" if a.plan_hash else " (no --plan-hash given: the plan file itself was not checked against a published hash)"))
            ok = ok and not problems
        print(p)
        for ln in lines:
            print("  " + ln)
        allok = allok and ok
    print(("\nVERIFIED (costs consistent and re-executed as requested)" if a.rerun else "\nCONSISTENT ONLY: the cost arithmetic checks out, but nothing was re-executed (use --rerun K or --rerun all)") if allok else "\nNOT VERIFIED")
    print("What this does NOT show: " + CLAIM_LIMITS)
    sys.exit(0 if allok else 1)


def cmd_selfcheck(a):
    mod, derive, verify, d = load_family(a.family)
    inst = derive(instances.PRACTICE_SEED, a.dim, 0)
    x, y = count_instance(a.solver, inst, verify, a.cap), count_instance(a.solver, inst, verify, a.cap)
    same = (x["status"], x.get("steps"), x.get("flops")) == (y["status"], y.get("steps"), y.get("flops"))
    print(f"run 1: {x['status']} steps {x.get('steps')} flops {x.get('flops')}\nrun 2: {y['status']} steps {y.get('steps')} flops {y.get('flops')}\n" + ("IDENTICAL" if same else "DIFFERENT: not countable"))
    sys.exit(0 if same and x["status"] == "solved" else 1)


def main(argv=None):
    if sys.version_info < MIN_PYTHON:
        sys.exit("tflops needs Python 3.12 or newer")
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        sys.exit("tflops refuses to run as root: the solver is contained by a restricted subset, not a sandbox. Use an unprivileged throwaway user.")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("practice")
    p.add_argument("solver")
    p.add_argument("--baseline", required=True)
    p.add_argument("--family", required=True)
    p.add_argument("--dims", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, default=8)
    p.add_argument("--cap", type=float, default=2000, help="budget in counted seconds (1 = 1e7 operations)")
    p.add_argument("--seed")
    p.add_argument("--reuse-baseline", action="store_true")
    p.add_argument("--plan", help="run exactly this committed plan (refuses anything else)")
    p.set_defaults(fn=cmd_practice)
    p = sub.add_parser("plan", help="fix the ladder in advance and print the hash to publish")
    p.add_argument("--family", required=True)
    p.add_argument("--dims", type=int, nargs="+", required=True)
    p.add_argument("--n", type=int, required=True)
    p.add_argument("--cap", type=float, required=True)
    p.add_argument("--seed")
    p.add_argument("--out", required=True)
    p.set_defaults(fn=cmd_plan)
    p = sub.add_parser("claim")
    p.add_argument("baseline")
    p.add_argument("submission")
    p.set_defaults(fn=cmd_claim)
    p = sub.add_parser("verify")
    p.add_argument("ladders", nargs="+")
    p.add_argument("--rerun", type=lambda s: s if s == "all" else int(s), default=0, help="K random records to re-execute, or `all` for a full audit")
    p.add_argument("--sample-seed", type=int, help="fix the random draw (default: fresh; the seed used is printed)")
    p.add_argument("--plan", help="also require the ladder to be exactly this committed plan")
    p.add_argument("--plan-hash", help="the hash published for the plan: the plan file must hash to it")
    p.add_argument("--seed")
    p.set_defaults(fn=cmd_verify)
    p = sub.add_parser("selfcheck")
    p.add_argument("solver")
    p.add_argument("--family", required=True)
    p.add_argument("--dim", type=int, required=True)
    p.add_argument("--cap", type=float, default=2000, help="budget in counted seconds (1 = 1e7 operations)")
    p.set_defaults(fn=cmd_selfcheck)
    a = ap.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
