# Proposing a problem: domain intake

Anyone can propose a problem for the compiler (COMPILER.md): "here is how to generate instances, here is how to check an answer, here is the
plain baseline". The operator reads the proposal, runs it through a screen and a limited trial, and only then puts it under `domains/`. Accepting
a domain does not compile it, does not make it a family, and does not open a round: each of those is a separate, later decision.

    proposer:  init -> edit -> screen -> pack -> send ONE file          operator:  receive -> read -> trial -> accept | reject
    (any machine with the project)                                       (laptop or throwaway box; never the live server)

## If you are proposing a problem

    pipx install guldo-cli                          # 0.2.0 or later: this gives the `guldo` command; no repository is needed
    export SVP_DOMAINS_DIR=$HOME/my-domains         # otherwise an installed package writes new domains inside its own folder
    guldo compile init mything                      # a working example in $SVP_DOMAINS_DIR/mything/ (the lines marked EDIT are yours)
    guldo compile check mything                     # seconds: shape, determinism, anti-cheat, the reference solves
    guldo intake screen $SVP_DOMAINS_DIR/mything    # the same static screen the operator runs; fix every FAIL
    guldo intake pack $SVP_DOMAINS_DIR/mything --out mything.bundle.json --contact "your-github-handle"

From a checkout of the project the same four steps are `python3 compile_domain.py init mything`, `python3 compile_domain.py check mything`,
`python3 intake.py screen domains/mything` and `python3 intake.py pack domains/mything --out mything.bundle.json --contact ...`.

**Where to send it:** open an issue at https://github.com/MuffinsThaCat/guldo-site/issues/new titled `Proposal: mything` and paste the whole bundle file in a code
block (a bundle is plain JSON text, usually a few KB; if it is over GitHub's issue length limit, attach it as a `.txt` file). **The issue is public**, and so are the
code and the `--contact` line you put in the bundle: use a GitHub handle there, not a private address. The bundle holds exactly `decl.py`, `reference.py` and an optional `NOTES.md` (why this problem, who you
are, what you know about faster methods); anything else in the folder (`compiled.json`, `out/`) stays behind, because the operator compiles it again.

**What the screen allows.** `decl.py` and `reference.py` are plain Python with: imports from `math itertools functools collections fractions heapq
bisect struct array statistics random hashlib hmac binascii decimal` (and, in `decl.py` only, `instances._is_prime`); constants; function
definitions. No classes, decorators, async code, `global`, `match` statements, top-level statements other than imports/constants/`def`, `print`,
`open`, `eval`, `exec`, `getattr`, `.format()` (use f-strings), `SystemExit`/`BaseException`/`KeyboardInterrupt`, double-underscore names, private
module names, or assigning to an attribute. Every top-level name is bound once (the screen reads one definition and the interpreter runs the last).
`REFERENCE_SOLVER` is `"reference.py"`.
`numpy`, `fpylll`, `operator` and `string` are not available through intake; if the problem truly needs one, say so in `NOTES.md`. Type hints work without importing `typing`
(`list[int]`, `dict[str, int]`, `tuple[int, ...]` on Python 3.9+). `intake_fixtures/` holds three realistic proposals (subset sum, planted 3-SAT, square roots mod p) that must keep passing the screen.
Limits: `decl.py` and `reference.py` at most 64 KiB each, `NOTES.md` 16 KiB, the bundle 256 KiB; `SIZE_RANGE` must end at or below 100000.

**Say which kind of speedup it tests.** Add one line to `decl.py`, `SPEEDUP = "lattice"`, naming a class from the fixed list (`guldo intake classes`: lattice, number-theory,
combinatorial, ai-inference, ai-training, quantum, other; `speedup_classes.py` holds it). The queue (`intake list`) and the Domains page group problems by it, so related problems sit together.
It is a filing label, not a ranking: each problem is measured against its own baseline, so results are compared only on the same problem. A missing line is a warning and the proposal is listed as *unsorted*; at `accept` the operator is told to add the line to `domains/NAME/decl.py` before compiling; a name
that is not on the list fails the screen. Pick the closest class, or `other` and say why in `NOTES.md`; the operator adds a class when several proposals land in `other`.
Declarations already in `domains/` are not edited to add the line (a registered declaration must match its compiled record), so their class is the table in `speedup_classes.py`.

**What a proposal must contain.** `NAME` (2-16 lowercase letters), `VERSION`, `SIZE_RANGE` wide enough for a ladder of at least three sizes (a declaration with `KIND = "advantage"`, `"oracle"`, `"precomp"` or `"quantum"`, see COMPILER.md, needs only one),
`derive(master, size, idx)`, `verify(inst, ans)`, and a **`REFERENCE_NOTE`** of at least 40 characters saying what the reference algorithm is and
what is known to beat it. A baseline nobody described is the main way a challenge becomes cheap, and nothing else can detect it, so a proposal
without the note is not acceptable. `DOC` (what `solve()` receives and returns) is strongly advised.

**What you should expect.** The operator may decline, ask for a stronger baseline, or ask for another NAME, in their own time: no response time is promised.
Accepted declarations are public: a certificate names the declaration's hashes, so anyone can read exactly what was measured against what. Nothing here
promises a round. One proposal per issue: an issue that holds two different bundles is refused, so there is never a doubt which one you meant.

**What you agree to.** You keep the copyright in what you send. By opening the issue you confirm that you wrote the code or have the right to share it; that
it is public the moment you post it (a rejected proposal stays public too: GitHub keeps an issue's edit history, and only the repository's owner can delete an
issue, so ask the operator if something must come down); and that you give the Guldo project permission to use,
run, modify and publish your declaration and reference as part of a challenge and its certificates, and to credit the GitHub handle you gave. If you want your
files under a particular licence, say so in `NOTES.md` and the project will tell you if it cannot accept that.

## If you are the operator

Everything below runs on your machine in the project folder; the queue lives in `intake/` (override with `SVP_INTAKE_DIR`), accepted domains go
to `domains/` (`SVP_DOMAINS_DIR`). Run `trial` and any later `compile` as an unprivileged user, ideally a throwaway user or VM (`trial` refuses root).

    python3 intake.py receive mything.bundle.json   # re-screens from scratch (the proposer's pass does not count), quarantines, logs
    gh issue view 12 --repo MuffinsThaCat/guldo-site --json body --jq .body | python3 intake.py receive -   # the same, straight from an issue's code block
    # READ intake/mything/<hash>/decl.py and reference.py, in full
    python3 intake.py trial mything                 # the compiler's parse + validate passes in a limited child; writes REVIEW.md next to the files
    python3 intake.py accept mything --i-read-it    # copies decl.py + reference.py into domains/mything; refuses unless the trial passed
    python3 intake.py reject mything --reason "baseline is a strawman"
    python3 intake.py list                          # the queue, and whether the hash-chained log is intact

`mything` can be `mything/<first 6+ hash characters>` when several proposals share a NAME; an ambiguous name is an error, never a guess.

**Triage.** Give incoming issues a `proposal` label and look at who actually opened each one before you `receive` it. Always receive from the issue's body text (the
`gh ... | receive -` line above), never from a copy you retyped, so what you read is what the tool hashed. To refuse one, run `reject --reason "..."` and paste the
same reason on the issue before closing it, so the log and the issue agree. Nobody is owed an answer by a date; say so if someone asks.

**What stands between a proposal and `domains/`:** (1) the screen at `receive`, on your side; (2) you reading both files (`REVIEW.md` ends with a
checklist); (3) a passing `trial`; (4) `--i-read-it`; (5) the quarantined files are re-hashed against the bundle at `trial` and at `accept`, so an
edit after receipt is refused; (6) `accept` never overwrites an existing `domains/NAME` and never takes a built-in name, and it is all-or-nothing: if a write or the log append fails, the directory it just made is removed and the log never says accepted (`receive` is the same: no quarantine folder survives without its log line). The log also records which screener looked at each proposal (rules version and Python version). Every step is a line in
`intake/log.jsonl`, hash-chained: a changed, removed or reordered line makes `list` exit 1 and makes `receive`, `accept`, `reject` and `trial` refuse
to extend it. Back the file up with the rest of the project, and **write down the head hash `list` prints** somewhere you cannot quietly edit: the
chain shows a changed or removed middle, but only a recorded head shows that the last lines were cut off.

With the installed package the same commands are `guldo intake ...`; set `SVP_INTAKE_DIR` to a folder you back up first (it refuses to keep the log
inside the package's own folder, which an upgrade replaces).

**After accept** (the domain is registered only once it is compiled): `python3 compile_domain.py compile NAME` (tens of minutes to hours; the
compiler imports `decl.py` and runs the reference in a bare local process, so use the same throwaway user), `show NAME`, then deploy
`domains/NAME` with the code and, when you choose, `ops.py round-new ... --family NAME`. Never edit an accepted domain's `decl.py`,
`reference.py` or `compiled.json` while a round on it is open: its fingerprint covers them and the evaluator refuses.

## What this does not do (read before trusting it)

- **The screen is an AST filter, not a sandbox.** It catches accidents and the obvious, and it was written against a list of known bypasses
  (`operator.attrgetter` and `string.Formatter` walk attributes from strings; `fractions.sys`, `fractions.operator` and `random._os` reach other modules,
  including through a variable; `match` class patterns read attributes by name; `numpy.fromfile` reads files; `print` writes to the runner's channel;
  string `.format`; rebinding `derive` or `NAME` after the screen read them), all refused. It cannot prove a file safe: an infinite loop or a memory
  hog passes it, and a bypass nobody has thought of would too. Most of the holes above were found by reading the screen adversarially after
  it already passed its tests, which is the reason reading stays the control.
- **`trial` limits resources, not access.** The child gets a CPU limit, a file-size limit, a memory watcher (next point), a wall-clock kill, a minimal environment (PATH, a scratch HOME and TMPDIR) and a scratch working directory, and the tool refuses to run as root. The child
  can still read any file the user can and use the network. On Linux an address-space limit is also set; on macOS the watcher is the only memory control.
  The tests run on macOS (Python 3.12 to 3.14) and in CI on Linux (Python 3.9, 3.11 and 3.13, as an unprivileged user), including the signal, memory and process-tree cases.
- **The memory limit covers the whole trial, and never silently turns off.** A watcher adds up the resident memory of every process of the trial and kills them
  all above the limit. The compiler runs the reference in a session of its own, so the watcher finds it through the process tree and the trial's unique scratch
  directory name (which survives a symlinked TMPDIR), not through the process group. If the process table cannot be read the trial refuses to start (as with
  BusyBox `ps`: install procps); if it stops being readable mid-trial the trial is stopped, never run without a memory limit.
- **A trial cannot be forged by what the declaration prints, and does not outlive you.** The verdict is read from a structured result file that a small
  driver writes after calling the compiler's own parse and validate passes, plus the child's exit status; the child's printed text is shown as untrusted
  and never decides anything, so an exception message full of fake `PASS` lines or a fake final verdict is just text. If you interrupt the trial (Ctrl-C),
  or it is sent SIGTERM or SIGHUP, every process of the trial, the reference included, is killed before the tool exits and no result is recorded; if the tool is
  killed outright (SIGKILL, which nothing can handle), the child notices within about half a second that its parent is gone and kills the trial's processes
  itself, unless it is inside a single long C call, in which case its CPU limit ends it (the reference has its own, shorter CPU budget). `REVIEW.md` shows the proposer's text with markup and link syntax neutralised.
- **Reading is the control.** `--i-read-it` is an honour flag; the tooling cannot know whether you read. Everything else is there so that reading
  is not the only thing, and so that what you read is what runs.
- **It cannot judge the problem.** Whether the baseline is honest, whether the cost grows with size, whether anyone cares: that is your call, and
  the compiler's power analysis afterwards says what the challenge can and cannot certify.
- **The channel is public and unmoderated.** Anyone can open an issue, so expect noise, and treat every body as hostile text: `receive` only looks for a code
  block holding a bundle and then applies the same strict checks and screen as for a file. The bundle's `contact` line is whatever its author typed: look at
  who actually opened the issue, and remember that editing the issue afterwards changes nothing, because `receive` keeps its own copy under a hash. There is no upload page; to move the channel, change
  `PROPOSALS_URL` in `intake.py` and the two places the guide names it.

Files: `intake.py` (the tool), `test_intake.py` (it includes a check that every program the screen accepts is also clean at the bytecode level, a check that this guide still matches the code, a guard that fails any test leaving process-wide state changed, and tests that start real child processes, some of which deliberately hang, spin or hog memory to check that everything the trial started is killed).
