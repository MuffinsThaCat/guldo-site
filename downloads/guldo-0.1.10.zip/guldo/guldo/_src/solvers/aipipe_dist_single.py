"""aipipe in the cluster-counted API, REFERENCE: one device does all 8 layers on the whole batch. No communication; every operation is on device 0."""
import math

import tensorops as tp


def solve(seed, d, B, P):
    tp.use(0)
    h = tp.reshape(tp.stream(seed, 0, B * d), (B, d))
    for l in range(8):
        h = tp.relu(h @ (tp.reshape(tp.stream(seed, B * d + l * d * d, d * d), (d, d)) * math.sqrt(6.0 / d)))
    return list(map(int, (tp.reshape(h, (B * d,)) * 1073741824.0).tolist()))
