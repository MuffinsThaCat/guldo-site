import itertools


def solve(q, A, b):
    n = len(A[0])
    for s in itertools.product((-1, 0, 1), repeat=n):
        ok = True
        for row, bi in zip(A, b):
            r = (bi - sum(a * x for a, x in zip(row, s))) % q
            if r not in (0, 1, q - 1):
                ok = False
                break
        if ok:
            return 1
    return 0
