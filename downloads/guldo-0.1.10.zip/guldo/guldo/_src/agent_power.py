"""The power pass for agent evaluations: how many instances and trials does a claim need, and what will the run cost, BEFORE any money is spent.

The speed compiler has a power pass (which speedups a challenge can and cannot certify). Agent runs cost real API money per trial, so the question matters more here and `--n 20` must not be a guess.
Every function states the decision rule it computes power for, and that rule is the one the comparison tools actually apply:

  solve_rate_power(n, p, claim)        P(the exact one-sided 95% Clopper-Pearson lower bound on the pooled solve rate is >= claim), EXACT (sum over the binomial)
  stratified_power(...)                the same for the difficulty-stratified bound (Bonferroni over sizes, agent_strata), by seeded simulation
  success_diff_power(n, qc, qb)        P(the exact sign test on the discordant instances calls "candidate solves more"), EXACT. qc / qb = per-instance probability that ONLY the candidate / ONLY the
                                       baseline solves the instance; discordant_from_marginals() derives them from the two solve rates and how correlated their outcomes are
  cost_power(n_both, mu, sigma, F)     P(agent_compare's verdict "candidate uses fewer tokens" AND factor lower bound >= F) when the per-instance gap in bits is Normal(mu, sigma) on the n_both
                                       instances both agents solve: seeded simulation of the REAL rule (deterministic bootstrap + exact sign test)
  need_*                               the smallest n whose power reaches the target and stays there for the next 10 values (power is a sawtooth in n for exact discrete tests)
  from_pilot(base, cand)               assumptions estimated from a small pilot pair of ladders, with the sigma inflated for the pilot's own uncertainty
  budget(...)                          dollars, from the pilot's tokens per trial and prices YOU supply (none are built in), as a range because proxy tokens are not billed tokens

What it assumes, and where it can mislead: instances are independent draws (they are: distinct HMAC seeds); the per-instance gap in bits is roughly Normal on the instances both solve (check the pilot's
histogram: heavy tails need more instances); the pilot's rates are the truth (they are noisy: a pilot of 10 instances cannot support a plan, which `from_pilot` says); the number of instances that BOTH
agents solve is about n * P(both solve). More TRIALS per instance sharpen each instance's majority outcome (see trials_table) but do not add instances: the claims' power comes from n.
"""
import argparse
import json
import math
import sys
from statistics import NormalDist

import agent_compare
import agent_core
import agent_strata

ALPHA = agent_core.ALPHA
STAY = 10                     # a need_* answer must keep its power for this many larger n


def _logpmf(n, k, p):
    if p <= 0.0:
        return 0.0 if k == 0 else float("-inf")
    if p >= 1.0:
        return 0.0 if k == n else float("-inf")
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1) + k * math.log(p) + (n - k) * math.log(1.0 - p)


def binom_pmf(n, p):
    return [math.exp(_logpmf(n, k, p)) if _logpmf(n, k, p) != float("-inf") else 0.0 for k in range(n + 1)]


def binom_sf(n, p, k):
    """P(X >= k)."""
    if k <= 0:
        return 1.0
    return min(1.0, sum(binom_pmf(n, p)[k:]))


def instance_solve_prob(p_trial, K):
    """P(an instance counts as solved) = P(more than half of K trials pass) when each trial passes with probability p_trial."""
    return binom_sf(K, p_trial, K // 2 + 1)


def trials_table(p_trial, Ks=(1, 3, 5, 7)):
    return [{"K": K, "instance_solve_prob": round(instance_solve_prob(p_trial, K), 6)} for K in Ks]


# ---- the pooled solve-rate bound (exact) --------------------------------------------------------------------------------------------------------

def _k_needed(n, claim, alpha):
    """Smallest number of solved instances whose Clopper-Pearson lower bound reaches `claim`, or None."""
    if agent_core.cp_lower(n, n, alpha) < claim:
        return None
    lo, hi = 0, n
    while lo < hi:
        mid = (lo + hi) // 2
        if agent_core.cp_lower(mid, n, alpha) >= claim:
            hi = mid
        else:
            lo = mid + 1
    return lo


def solve_rate_power(n, p, claim, alpha=ALPHA):
    k = _k_needed(n, claim, alpha)
    return 0.0 if k is None else binom_sf(n, p, k)


FINE_UP_TO = 120              # below this n the search steps by 1 (cheap, and the true minimum is found); above it by 5% and then refines


def _first_stable(power_fn, target, n_start, n_max):
    """Smallest n whose power reaches `target` and keeps it for the next STAY values. Exact (step 1) up to FINE_UP_TO; beyond that a coarse scan in ~5% steps finds the first stable
    n, which is then refined downwards inside the last step, so the answer is within one coarse step of a true minimum in the (rare) case a sawtooth dip hides an earlier one.
    Memoised: the windows of neighbouring n overlap, and an unmemoised scan of a hard target took minutes."""
    memo = {}

    def pw(n):
        if n not in memo:
            memo[n] = power_fn(n)
        return memo[n]

    def stable(n):
        return pw(n) >= target and all(pw(n + j) >= target for j in range(1, STAY + 1))
    n = max(1, n_start)
    prev = n - 1
    while n <= n_max:
        if stable(n):
            for m in range(prev + 1, n):
                if stable(m):
                    return m
            return n
        prev = n
        n += 1 if n < FINE_UP_TO else max(1, int(n * 0.05))
    return None


def need_solve_rate(p, claim, power=0.8, n_max=1500, alpha=ALPHA):
    if p <= claim:
        return None
    return _first_stable(lambda n: solve_rate_power(n, p, claim, alpha), power, 1, n_max)


# ---- the stratified bound (seeded simulation) ----------------------------------------------------------------------------------------------------

def stratified_power(n_per_size, p_by_size, claim, alpha=ALPHA, sims=400, seed=b"power-strat"):
    """P(agent_strata.stratified_lower >= claim) with equal weights, when size s has solve probability p_by_size[s]. Simulated with the deterministic generator, so the answer repeats."""
    rng = agent_core.Rng(seed)
    hits = 0
    sizes = sorted(p_by_size)
    for _ in range(sims):
        strata = [(s, sum(1 for _ in range(n_per_size) if rng.random() < p_by_size[s]), n_per_size) for s in sizes]
        if agent_strata.stratified_lower(strata, alpha=alpha) >= claim:
            hits += 1
    return hits / float(sims)


def need_stratified(p_by_size, claim, power=0.8, n_max=300, sims=300):
    n = 5
    while n <= n_max:
        if all(stratified_power(m, p_by_size, claim, sims=sims) >= power for m in (n, n + 3, n + 6)):
            return n
        n += 5
    return None


# ---- the paired success test (exact) -------------------------------------------------------------------------------------------------------------

def discordant_from_marginals(pb, pc, rho=0.0):
    """Per-instance P(only candidate solves), P(only baseline solves) from the two solve rates and the correlation rho of the two agents' outcomes on the same instance (0 = independent).
    Outcomes on shared instances are usually positively correlated (hard instances are hard for both). For a FIXED gap between the solve rates that makes the discordant instances fewer but more
    lopsided towards the better agent, which RAISES the sign test's power (computed, not assumed: see test_marginals_to_discordance). So rho = 0 (independent) is the CONSERVATIVE planning choice
    and is the default; a negative rho (an agent that wins exactly where the other loses) would lower the power."""
    both = pb * pc + rho * math.sqrt(max(0.0, pb * (1 - pb) * pc * (1 - pc)))
    qc, qb = pc - both, pb - both
    if qc < -1e-12 or qb < -1e-12 or both > min(pb, pc) + 1e-12:
        raise agent_core.AgentEvalError("that correlation is impossible for these solve rates")
    return max(qc, 0.0), max(qb, 0.0)


def _sign_critical(n_disc, alpha):
    """Smallest number of candidate-only wins out of n_disc discordant instances at which the exact one-sided sign test calls it (p <= alpha); None if none."""
    for w in range(n_disc // 2 + 1, n_disc + 1):
        if agent_core.sign_test_p(w, n_disc - w) <= alpha:
            return w
    return None


def success_diff_power(n, qc, qb, alpha=ALPHA):
    d_tot = qc + qb
    if n <= 0 or d_tot <= 0.0:
        return 0.0
    pc_given = qc / d_tot
    d_pmf = binom_pmf(n, d_tot)
    total = 0.0
    for d in range(1, n + 1):
        if d_pmf[d] < 1e-14:
            continue
        w_min = _sign_critical(d, alpha)
        if w_min is not None:
            total += d_pmf[d] * binom_sf(d, pc_given, w_min)
    return total


def need_success_diff(qc, qb, power=0.8, n_max=1200, alpha=ALPHA):
    if qc <= qb:
        return None
    return _first_stable(lambda n: success_diff_power(n, qc, qb, alpha), power, 4, n_max)


# ---- the cost-uplift verdict (seeded simulation of the real rule) --------------------------------------------------------------------------------

def _normals(rng, n, mu, sigma):
    out = []
    while len(out) < n:
        u1, u2 = max(rng.random(), 1e-12), rng.random()
        r = math.sqrt(-2.0 * math.log(u1))
        out.append(mu + sigma * r * math.cos(2 * math.pi * u2))
        if len(out) < n:
            out.append(mu + sigma * r * math.sin(2 * math.pi * u2))
    return out


def cost_power(n_both, mu, sigma, factor=1.0, alpha=ALPHA, sims=200, reps=500, seed=b"power-cost", sampler=None):
    """P(the comparison says 'candidate uses fewer tokens' and its factor lower bound >= `factor`). Uses agent_core.bootstrap_mean and the exact sign test, with `reps` bootstrap
    resamples per simulated study (fewer than the real 2000, to be affordable: the real bound is slightly less noisy), and the SAME tail correction as agent_compare (one pessimistic
    pseudo-observation, agent_core.pessimistic_gap). `sampler(rng, n)` replaces the Normal(mu, sigma) draw: give it a skewed one to see the false-verdict rate (mu = 0) on realistic data."""
    if n_both < 2:
        return 0.0
    rng = agent_core.Rng(seed)
    bar = math.log2(factor)
    hits = 0
    for s in range(sims):
        bits = sampler(rng, n_both) if sampler else _normals(rng, n_both, mu, sigma)
        _, lo, _ = agent_core.bootstrap_mean(bits + [agent_core.pessimistic_gap(bits)], seed + s.to_bytes(4, "big"), reps)
        cw = sum(1 for x in bits if x > 1e-12)
        cl = sum(1 for x in bits if x < -1e-12)
        if lo is not None and lo >= bar and lo > 0 and agent_core.sign_test_p(cw, cl) <= alpha:
            hits += 1
    return hits / float(sims)


def need_cost_uplift(mu, sigma, factor=1.0, power=0.8, n_max=2000, sims=200):
    """Smallest number of instances BOTH agents solve. Starts from the normal-approximation answer and walks up in 8% steps until the simulated power reaches the target twice in a row, and returns the first size of that pair (the second only confirms it against simulation noise)."""
    bar = math.log2(factor)
    if mu <= bar or sigma < 0:
        return None
    z = NormalDist().inv_cdf
    n = max(4, int(math.ceil(((z(1 - ALPHA) + z(power)) * max(sigma, 1e-9) / (mu - bar)) ** 2)))
    ok, first = 0, None
    while n <= n_max:
        if cost_power(n, mu, sigma, factor, sims=sims) >= power:
            ok += 1
            if ok == 1:
                first = n
            if ok == 2:
                return first                  # the FIRST size of the confirmed pair: returning the second (an 8% step higher) overstated the answer by up to a step, and made `plan` print "power 0.97 at 66 (needs 71)"
        else:
            ok, first = 0, None
        n = int(math.ceil(n * 1.08)) + (1 if ok == 0 else 0)
    return None


PROXY_TO_BILLED = 2.2      # billed tokens per proxy token, measured on 155 real calls (agent_eval/real_runs_2026-11-27/anthropic_live; 2.18x input, 2.43x output overall)
CALIBRATED_HIGH = 4.0      # a high figure that covers the one real two-model study (cost 2.8x the proxy-token mid because one arm was dearer per token); one study is not a bound


# ---- money ---------------------------------------------------------------------------------------------------------------------------------------

def budget(instances, trials, arms, tokens_per_trial, usd_per_mtok_in, usd_per_mtok_out, in_fraction=0.9):
    """Dollars for instances x trials x arms trials of `tokens_per_trial` proxy tokens each, with the prices YOU pass (nothing is built in: prices change). `in_fraction` is the share of
    tokens that are input; context is re-sent every turn, so it is usually large. Reported as a range: proxy tokens are not billed tokens, and thinking tokens (not in the proxy count) are billed."""
    n_trials = instances * trials * arms
    mid = n_trials * tokens_per_trial * (in_fraction * usd_per_mtok_in + (1.0 - in_fraction) * usd_per_mtok_out) / 1e6
    return {"trials": n_trials, "tokens_total": n_trials * tokens_per_trial, "usd_mid": round(mid, 2), "usd_low": round(0.5 * mid, 2), "usd_high": round(2.5 * mid, 2),
            "usd_calibrated_mid": round(PROXY_TO_BILLED * mid, 2), "usd_calibrated_high": round(CALIBRATED_HIGH * mid, 2),
            "note": "usd_low/usd_mid/usd_high are the proxy-token estimate and a 0.5x-2.5x band chosen by judgment: NOT a confidence interval or a bound. MEASURED on real runs (27 Nov, claude-haiku-4-5 and "
                    "claude-sonnet-5-5): the provider billed about 2.2x the proxy token count, and a two-model study whose arms were priced differently cost 2.8x the mid figure, ABOVE the 2.5x 'high'. "
                    "usd_calibrated_mid (x%.1f) and usd_calibrated_high (x%.1f) use that: they cover the one real study but come from one domain and two models, and this function takes ONE price pair "
                    "for every arm, so an arm on a dearer model is not priced here. Run ONE instance first and scale from its actual usage (agent_preflight's calibration, or the pilot ladder's own usage numbers)."
                    % (PROXY_TO_BILLED, CALIBRATED_HIGH)}


# ---- from a pilot -------------------------------------------------------------------------------------------------------------------------------

def from_pilot(base_header, base_recs, cand_header, cand_recs):
    """Assumptions for planning, estimated from a small pilot pair of ladders (same plan). Returns the estimates AND how little they can be trusted."""
    b, c = agent_compare.per_instance(base_header, base_recs), agent_compare.per_instance(cand_header, cand_recs)
    keys = sorted(b)
    n = len(keys)
    pb = sum(1 for k in keys if b[k]["solved"]) / float(n)
    pc = sum(1 for k in keys if c[k]["solved"]) / float(n)
    qc = sum(1 for k in keys if c[k]["solved"] and not b[k]["solved"]) / float(n)
    qb = sum(1 for k in keys if b[k]["solved"] and not c[k]["solved"]) / float(n)
    both = [k for k in keys if b[k]["solved"] and c[k]["solved"]]
    bits = [math.log2(b[k]["tokens"] / c[k]["tokens"]) for k in both]
    m = len(bits)
    mu = sum(bits) / m if m else None
    sd = math.sqrt(sum((x - mu) ** 2 for x in bits) / (m - 1)) if m > 1 else None
    sd_hi = sd * (1.0 + 1.645 / math.sqrt(2.0 * (m - 1))) if sd is not None else None
    toks = [r["tokens"] for r in base_recs + cand_recs]
    warn = []
    if n < 20:
        warn.append("the pilot has %d instances: its solve rates are very noisy; use it to sanity-check the plan, not to size it" % n)
    if m < 8:
        warn.append("only %d instances were solved by both: the cost estimate is nearly meaningless" % m)
    return {"pilot_instances": n, "p_base": pb, "p_cand": pc, "q_cand_only": qc, "q_base_only": qb, "both_solved": m, "mean_bits": mu, "sd_bits": sd, "sd_bits_conservative": sd_hi,
            "p_both": len(both) / float(n), "mean_tokens_per_trial": sum(toks) / float(len(toks)) if toks else None, "warnings": warn}


# ---- one answer -----------------------------------------------------------------------------------------------------------------------------------

def advise(sizes, solve_claim=None, p_cand=None, diff=None, cost=None, power=0.8, trials=1):
    """Combine the requested claims into one instance count. `diff` = (qc, qb); `cost` = (mean_bits, sd_bits, factor, p_both). Returns the per-claim needs and the plan to use (the largest)."""
    needs = {}
    if solve_claim is not None:
        if p_cand is None:
            raise agent_core.AgentEvalError("a solve-rate claim needs p_cand, the candidate's assumed per-instance solve probability")
        needs["solve_rate_claim"] = need_solve_rate(p_cand, solve_claim, power)
    if diff is not None:
        needs["success_difference"] = need_success_diff(diff[0], diff[1], power)
    if cost is not None:
        mu, sd, factor, p_both = cost
        nb = need_cost_uplift(mu, sd, factor, power)
        needs["cost_uplift"] = None if nb is None else int(math.ceil(nb / max(p_both, 1e-9)))
    asked = [v for v in needs.values()]
    if not asked or any(v is None for v in asked):
        return {"needs": needs, "plan": None, "why": "at least one claim cannot be reached at that power with the stated assumptions (effect too small or n_max exceeded)"}
    total = max(asked)
    per_size = int(math.ceil(total / float(len(sizes))))
    return {"needs": needs, "plan": {"n_per_size": per_size, "instances_total": per_size * len(sizes), "trials": trials, "power_target": power}}


def plan_report(n_total, power=0.8, p_cand=None, solve_claim=None, p_base=None, rho=0.0, mean_bits=None, sd_bits=None, factor=1.0, p_both=0.8):
    """For a plan of `n_total` instances: the power it has for each stated claim under the stated assumptions, the instance count each claim needs, and whether the plan is adequate.
    A list of {claim, power_at_plan, needed_instances, adequate}. Only the claims whose assumptions were given are reported; with none given the list is empty."""
    rows = []
    if solve_claim is not None:
        if p_cand is None:
            raise agent_core.AgentEvalError("a solve-rate claim needs --assume-p-cand")
        need = need_solve_rate(p_cand, solve_claim, power)
        rows.append({"claim": "candidate solve-rate lower bound >= %g (assuming true rate %g)" % (solve_claim, p_cand), "power_at_plan": round(solve_rate_power(n_total, p_cand, solve_claim), 4),
                     "needed_instances": need})
    if p_base is not None:
        if p_cand is None:
            raise agent_core.AgentEvalError("a success-difference claim needs --assume-p-cand and --assume-p-base")
        qc, qb = discordant_from_marginals(p_base, p_cand, rho)
        need = need_success_diff(qc, qb, power)
        rows.append({"claim": "candidate solves more instances (assuming solve rates %g vs %g, outcome correlation %g)" % (p_cand, p_base, rho),
                     "power_at_plan": round(success_diff_power(n_total, qc, qb), 4), "needed_instances": need})
    if mean_bits is not None:
        if sd_bits is None:
            raise agent_core.AgentEvalError("a cost claim needs --assume-sd-bits")
        nb = need_cost_uplift(mean_bits, sd_bits, factor, power)
        rows.append({"claim": "candidate uses >= %gx fewer tokens (assuming mean gap %g bits, sd %g, %g of instances solved by both)" % (factor, mean_bits, sd_bits, p_both),
                     "power_at_plan": round(cost_power(int(n_total * p_both), mean_bits, sd_bits, factor), 4), "needed_instances": None if nb is None else int(math.ceil(nb / max(p_both, 1e-9)))})
    for r in rows:
        r["adequate"] = r["power_at_plan"] >= power
    return rows


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("solve-rate", help="power / needed n for 'the solve-rate lower bound reaches CLAIM'")
    p.add_argument("--p", type=float, required=True, help="the agent's true per-instance solve probability (assumed)")
    p.add_argument("--claim", type=float, required=True)
    p.add_argument("--n", type=int)
    p.add_argument("--power", type=float, default=0.8)
    p = sub.add_parser("success-diff", help="power / needed n for 'candidate solves more than baseline'")
    p.add_argument("--p-base", type=float, required=True)
    p.add_argument("--p-cand", type=float, required=True)
    p.add_argument("--rho", type=float, default=0.0, help="correlation of the two agents' outcomes on one instance (default 0 = independent, the CONSERVATIVE case: positive correlation raises the power)")
    p.add_argument("--n", type=int)
    p.add_argument("--power", type=float, default=0.8)
    p = sub.add_parser("cost-uplift", help="needed n for 'candidate uses at least FACTOR-fold fewer tokens'")
    p.add_argument("--mean-bits", type=float, required=True, help="assumed mean of log2(baseline tokens / candidate tokens) on instances both solve")
    p.add_argument("--sd-bits", type=float, required=True)
    p.add_argument("--factor", type=float, default=1.0)
    p.add_argument("--p-both", type=float, default=0.8, help="fraction of instances BOTH agents solve")
    p.add_argument("--n-both", type=int)
    p.add_argument("--power", type=float, default=0.8)
    p = sub.add_parser("pilot", help="assumptions and a recommended plan from a small pilot pair of ladders")
    p.add_argument("baseline")
    p.add_argument("candidate")
    p.add_argument("--factor", type=float, default=2.0)
    p.add_argument("--solve-claim", type=float)
    p.add_argument("--power", type=float, default=0.8)
    p.add_argument("--trials", type=int, default=1)
    p.add_argument("--usd-per-mtok-in", type=float)
    p.add_argument("--usd-per-mtok-out", type=float)
    p = sub.add_parser("budget")
    p.add_argument("--instances", type=int, required=True)
    p.add_argument("--trials", type=int, default=1)
    p.add_argument("--arms", type=int, default=2)
    p.add_argument("--tokens-per-trial", type=float, required=True)
    p.add_argument("--usd-per-mtok-in", type=float, required=True)
    p.add_argument("--usd-per-mtok-out", type=float, required=True)
    p.add_argument("--in-fraction", type=float, default=0.9)
    p = sub.add_parser("trials", help="how K trials per instance change the chance an instance counts as solved")
    p.add_argument("--p", type=float, required=True)
    args = ap.parse_args(argv)
    try:
        if args.cmd == "solve-rate":
            out = {"needed_n": need_solve_rate(args.p, args.claim, args.power)}
            if args.n:
                out["power_at_n"] = solve_rate_power(args.n, args.p, args.claim)
        elif args.cmd == "success-diff":
            qc, qb = discordant_from_marginals(args.p_base, args.p_cand, args.rho)
            out = {"q_cand_only": qc, "q_base_only": qb, "needed_n": need_success_diff(qc, qb, args.power)}
            if args.n:
                out["power_at_n"] = success_diff_power(args.n, qc, qb)
        elif args.cmd == "cost-uplift":
            nb = need_cost_uplift(args.mean_bits, args.sd_bits, args.factor, args.power)
            out = {"needed_n_both_solved": nb, "needed_instances": None if nb is None else int(math.ceil(nb / args.p_both))}
            if args.n_both:
                out["power_at_n_both"] = cost_power(args.n_both, args.mean_bits, args.sd_bits, args.factor)
        elif args.cmd == "pilot":
            bh, br = agent_core.read_ladder(args.baseline)
            ch, cr = agent_core.read_ladder(args.candidate)
            est = from_pilot(bh, br, ch, cr)
            out = {"pilot": est}
            if est["mean_bits"] is not None and est["sd_bits_conservative"] is not None:
                sizes = bh["sizes"]
                out["advice"] = advise(sizes, args.solve_claim, est["p_cand"], (est["q_cand_only"], est["q_base_only"]) if est["q_cand_only"] > est["q_base_only"] else None,
                                       (est["mean_bits"], est["sd_bits_conservative"], args.factor, max(est["p_both"], 0.05)), args.power, args.trials)
                plan = out["advice"].get("plan")
                if plan and args.usd_per_mtok_in is not None and args.usd_per_mtok_out is not None and est["mean_tokens_per_trial"]:
                    out["budget"] = budget(plan["instances_total"], args.trials, 2, est["mean_tokens_per_trial"], args.usd_per_mtok_in, args.usd_per_mtok_out)
        elif args.cmd == "budget":
            out = budget(args.instances, args.trials, args.arms, args.tokens_per_trial, args.usd_per_mtok_in, args.usd_per_mtok_out, args.in_fraction)
        else:
            out = trials_table(args.p)
    except agent_core.AgentEvalError as e:
        print("error: " + str(e), file=sys.stderr)
        return 1
    print(json.dumps(out, indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
