"""PRECOMPUTATION challenges: an attack that pays once for a big table or database about a PUBLIC parameter and then answers many instances cheaply (CVPP, baby-step tables, rainbow-style
tables, amortised sieving). New file: nothing in rounds.CODE_FILES or COUNT_FILES changes; it runs the solver through count_runner.py unedited.

The solver defines two functions:
    preprocess(public) -> state      sees ONLY the declaration's public(master, size): never an instance. `state` is JSON (a list/dict of ints is typical)
    solve(state, *args) -> answer    once per instance, in a FRESH process that is handed `state` (no `preprocess`: the public parameters themselves): nothing else survives between instances
Declaration (operator code): public(master, size) -> JSON;  derive/verify as usual;  HORIZON (instances the preprocessing is amortised over, default 12);  STATE_MAX_BYTES (default 8 MiB).

Cost: exact instruction counts (count_runner.py), so reproducible by anyone. Preprocessing is charged to the instances it serves: cost_i = (online_i + pre / HORIZON) in counted steps, so a
solver that precomputes more than it saves LOSES against a baseline with no table, and the table cannot be hidden in import-time work (count_runner counts the module body in BOTH phases).
The record also carries `pre_steps` and `state_bytes` separately and the summary prints the BREAK-EVEN: the number of instances beyond which precomputation pays. A claim is therefore
"at horizon N, with a table of this size, this much cheaper"; a bigger table is a different claim, not a free win.

What it does NOT show: memory beyond the state's size on disk (a table built and used inside one phase is not stored, and the restricted subset's 2 GiB address-space limit applies on Linux only),
or wall-clock time (a count is not a time), or anything about a precomputation that depends on the instance (that is cheating by construction here: preprocess never sees one).
"""
import ast
import hashlib
import json
import os
import subprocess
import sys
import tempfile

import count_runner

HERE = os.path.dirname(os.path.abspath(__file__))
STEPS_PER_UNIT = 1_000_000          # one "counted second" (counted.STEPS_PER_SECOND), restated here because counted.py is pinned and not imported
DEFAULT_HORIZON = 12
DEFAULT_STATE_MAX = 8 << 20
STEP_LIMIT = 400_000_000


def settings(mod):
    h, m = getattr(mod, "HORIZON", DEFAULT_HORIZON), getattr(mod, "STATE_MAX_BYTES", DEFAULT_STATE_MAX)
    ok = lambda v, lo, hi: isinstance(v, int) and not isinstance(v, bool) and lo <= v <= hi   # noqa: E731
    if not (ok(h, 1, 10000) and ok(m, 1, 256 << 20)):
        raise ValueError("HORIZON must be an integer 1..10000 and STATE_MAX_BYTES an integer 1..268435456")
    return h, m


def is_precomp(mod):
    return callable(getattr(mod, "public", None))


def _count(path, args, limit, entry):
    """One counted run of `entry` ('preprocess' or 'solve') of the solver file at `path`. -> {"status", "steps", "ans", "err"}.
    Runs count_runner.py as it is: for `preprocess` a copy of the source with `solve = preprocess` appended is run (the module body, which is counted, is the same)."""
    with open(path, "rb") as f:
        text = f.read().decode("utf-8")
    if entry == "preprocess":
        text += "\n\nsolve = preprocess\n"
    env = {"PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "PATH": os.environ.get("PATH", "")}
    try:
        payload = json.dumps({"args": args, "limit": limit}).encode()
    except (ValueError, TypeError, RecursionError):   # arguments that are not JSON cannot cross the process boundary: a refusal, not a traceback
        return {"status": "error", "steps": None, "ans": None, "err": "the arguments are not JSON-serialisable"}
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "solver.py")
        with open(p, "w", encoding="utf-8") as f:
            f.write(text)
        try:
            r = subprocess.run([sys.executable, "-B", os.path.join(HERE, "count_runner.py"), p], input=payload, capture_output=True, env=env,
                               cwd=d, timeout=limit / 3e5 + 60)
        except subprocess.TimeoutExpired:
            return {"status": "timeout", "steps": None, "ans": None, "err": "wall-clock backstop"}
    lines = [ln for ln in r.stdout.decode(errors="replace").splitlines() if ln.strip()]
    try:
        out = json.loads(lines[-1])
        return {"status": out["status"], "steps": int(out["steps"]), "ans": out.get("ans"), "err": str(out.get("err", ""))[-300:]}
    except (IndexError, ValueError, KeyError, TypeError):
        return {"status": "error", "steps": None, "ans": None, "err": "the counter produced no result"}


def has_entry(path, name):
    with open(path, "rb") as f:
        try:
            tree = ast.parse(f.read())
        except (SyntaxError, ValueError, RecursionError, MemoryError):
            return False
    return any(isinstance(n, ast.FunctionDef) and n.name == name for n in tree.body)   # a TOP-LEVEL def: a comment or string that spells it does not count


def preprocess(solver, public, state_max=DEFAULT_STATE_MAX, limit=STEP_LIMIT):
    """-> {"status": ok|..., "steps", "state", "state_bytes", "state_sha256"}. A solver with no `preprocess` gets the PUBLIC parameters themselves as its state, at zero preprocessing cost
    (that is what the reference usually does: solve(public, *args))."""
    if not has_entry(solver, "preprocess"):
        blob = json.dumps(public, sort_keys=True, separators=(",", ":"), allow_nan=False)
        return {"status": "ok", "steps": 0, "state": public, "state_bytes": len(blob), "state_sha256": hashlib.sha256(blob.encode()).hexdigest()}
    r = _count(solver, [public], limit, "preprocess")
    if r["status"] != "ok":
        return dict(r, state=None, state_bytes=0, state_sha256=None)
    try:
        blob = json.dumps(r["ans"], sort_keys=True, separators=(",", ":"), allow_nan=False)
    except (ValueError, TypeError, RecursionError) as e:   # NaN / infinity, or a shape that is not plain JSON: the state is refused, it does not crash the evaluator
        return {"status": "error", "steps": r["steps"], "state": None, "state_bytes": 0, "state_sha256": None, "err": f"the state is not strict JSON ({type(e).__name__})"}
    if len(blob) > state_max:
        return {"status": "state_too_big", "steps": r["steps"], "state": None, "state_bytes": len(blob), "state_sha256": None, "err": f"state is {len(blob)} bytes; the limit is {state_max}"}
    return {"status": "ok", "steps": r["steps"], "state": r["ans"], "state_bytes": len(blob), "state_sha256": hashlib.sha256(blob.encode()).hexdigest()}


def evaluate_size(mod, solver, master, size, n, step_limit=STEP_LIMIT):
    """Preprocess once for `size`, then solve instances 0..n-1. -> (header, [record]). Every record's cost includes its 1/HORIZON share of the preprocessing; an instance that is not solved is
    charged the step limit, and a failed preprocessing makes every instance of the size unsolved (charged the limit)."""
    horizon, state_max = settings(mod)
    pre = preprocess(solver, mod.public(master, size), state_max, step_limit)
    header = {"size": size, "pre_status": pre["status"], "pre_steps": pre["steps"], "state_bytes": pre["state_bytes"], "state_sha256": pre["state_sha256"], "horizon": horizon}
    recs = []
    for idx in range(n):
        x = mod.derive(master, size, idx)
        rec = {"id": f"{size}:{idx}", "dim": size}
        if pre["status"] != "ok":
            rec.update({"status": "timeout", "online_steps": None})
            steps = step_limit
        else:
            r = _count(solver, [pre["state"]] + list(x["args"]), step_limit, "solve")
            rec["online_steps"] = r["steps"]
            if r["status"] == "ok":
                try:
                    ok = bool(mod.verify(x, r["ans"]))
                except Exception:
                    ok = False
                rec["status"] = "solved" if ok else ("failed" if r["ans"] is None else "wrong")
                rec["ans"] = r["ans"]
                steps = r["steps"] + pre["steps"] / horizon
            else:
                rec["status"] = "timeout" if r["status"] in ("limit", "timeout") else "crash"
                steps = step_limit
        if rec["status"] != "solved":
            steps = step_limit
        rec["cpu"] = rec["cpu_net"] = max(steps / STEPS_PER_UNIT, 1e-3)
        recs.append(rec)
    return header, recs


def breakeven(ref_online, sol_online, pre_steps):
    """The number of instances N* beyond which the solver's total (pre + N * online) beats the reference's (N * online): pre / (ref_mean - sol_mean). None if it never does."""
    if not ref_online or not sol_online:
        return None
    gain = sum(ref_online) / len(ref_online) - sum(sol_online) / len(sol_online)
    return None if gain <= 0 else pre_steps / gain


def replay_size(mod, solver, master, size, header, recs, step_limit=STEP_LIMIT):
    """Independent re-run of one size. -> (ok, [reasons]): the same state hash and preprocessing steps, and for every record the same status, answer and online steps."""
    why = []
    top = 0
    for b in recs:   # pair by ID, not by position: a ladder that lacks some index must not shift every later record onto the wrong instance
        try:
            top = max(top, int(str(b.get("id")).split(":")[1]) + 1)
        except (IndexError, ValueError):
            return False, [f"a record has no usable id: {b.get('id')!r}"]
    fresh_header, fresh = evaluate_size(mod, solver, master, size, top, step_limit)
    for k in ("pre_status", "pre_steps", "state_bytes", "state_sha256"):
        if fresh_header[k] != header.get(k):
            why.append(f"{k}: {fresh_header[k]!r} != recorded {header.get(k)!r}")
    by_id = {a["id"]: a for a in fresh}
    for b in recs:
        a = by_id.get(b.get("id"))
        if a is None:
            why.append(f"{b.get('id')}: not an instance of size {size}")
            continue
        for k in ("status", "online_steps", "ans"):
            if a.get(k) != b.get(k):
                why.append(f"{a['id']} {k}: {a.get(k)!r} != recorded {b.get(k)!r}")
    return (not why), why[:10]
