#!/usr/bin/env python3
"""Tools for a QUALITY challenge (answers are scored, not the clock). Python standard library only; check.py supplies the sandbox, the CPU limits and the verifier.

    python3 qcheck.py run   --seed-file F --solver S.py --out LADDER.jsonl      run a solver on every instance of the ladder, sandboxed; write the ladder qscore.py reads
    python3 qcheck.py run   --practice   --solver S.py --out LADDER.jsonl       the same on the public practice seed and sizes (no seed needed)
    python3 qcheck.py verify --seed-file F --size N --idx I --answer JSON        {"valid": ..., "quality": ...}; exit 0 if valid
    python3 qcheck.py qrerun --seed-file F --solver S.py --claimed SUB.jsonl --baseline REF.jsonl [-k 5] [--sign KEY --attest-out FILE]
                                                                                 re-run a random sample of a CLAIMED result on this machine: do the claimed qualities reproduce?

    python3 qcheck.py qrerun ... --sample-seed S --save F [--machine-label NAME]      also write the per-instance measurements (the machine is a HASH, never a host name)
    python3 qcheck.py qspread F1 F2 ...                                         merge saved measurements from DIFFERENT machines: how much does quality move between them?

Everything else (`info`, `selftest`, `commit`, `derive`, `keygen`, `attest-check`, `log`) is check.py's, and works on quality bundles. `run` and `qrerun` EXECUTE the solver file
in child processes with a CPU limit equal to the challenge's budget, inside an OS sandbox by default (no network, no writes outside a scratch directory, the seed and your
keys unreadable); where there is none they refuse unless you pass --sandbox off. It is not a proof of isolation. They also import and run decl.py's verify() and quality()
in this process: that is the bundle author's code (see check.py's WARNING).
"""
import argparse
import hashlib
import json
import os
import statistics
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import check as C  # noqa: E402
import qscore as QS  # noqa: E402

QMEASURE_FORMAT = "guldo-bundle-qmeasurement-v1"
DEFAULT_TOLERANCE = 0.05   # quality points the median claimed-vs-re-measured gap may reach: a randomised solver does not reproduce its own answers exactly


def manifest():
    ch = C.manifest()
    if ch.get("metric") != "quality":
        raise SystemExit("this bundle is a SPEED challenge: use check.py")
    return ch


def solver_scratch(a, deny):
    """-> (prefix, scratch dir). The sandbox runs the solver; no sandbox and no --sandbox off means refuse."""
    import atexit
    import shutil
    scratch = os.path.realpath(tempfile.mkdtemp(prefix="qrun-"))
    atexit.register(shutil.rmtree, scratch, True)
    prefix, why_not = C.working_sandbox(a.sandbox, deny, scratch)
    if prefix is None:
        raise SystemExit("no sandbox is available here (needs macOS sandbox-exec or Linux bwrap" + (f"; the tool exists but cannot run: {why_not}" if why_not else "")
                         + "). To run the solver anyway, unsandboxed, as you, pass --sandbox off (only for a solver you have read).")
    return prefix, scratch


def score_run(decl, inst, run):
    """One solver run -> (status, quality). The record's status follows the guldo ladder statuses; anything but a verified answer scores 0."""
    status, ans, cpu, err = run
    if status == "timeout":
        return "timeout", 0.0
    if status != "ran":
        return "crash", 0.0
    try:
        valid, q = C.quality_of(decl, inst, ans)
    except ValueError as e:
        raise SystemExit(f"the declaration is defective, not the solver: {e}")
    if not valid:
        return ("failed" if ans is None else "wrong"), 0.0
    return "solved", q


BENCH = "def solve(*a):\n    s = 0\n    for i in range(3000000):\n        s += i * i % 7\n    return None\n"


def machine_bench(scratch, prefix, reps=3):
    """CPU seconds (median of `reps`, through the SAME meter and sandbox the solvers run under, empty-start overhead removed) of a fixed pure-Python workload: a yardstick for this machine's
    speed. An anytime solver does more per CPU second on a faster machine, so two quality ladders are only comparable if their yardsticks agree."""
    path = os.path.join(scratch, "bench.py")
    with open(path, "w") as f:
        f.write(BENCH)
    overhead = C.solver_overhead(os.path.join(scratch, "noop2.py"), prefix, scratch)
    runs = [C.run_solver(path, [], 60, prefix, scratch) for _ in range(reps)]
    if any(r[0] != "ran" for r in runs):
        raise SystemExit("the machine calibration workload did not run here: " + (runs[0][3] or runs[0][0]))
    return max(statistics.median(r[2] for r in runs) - overhead, 1e-3)


def over_budget(run, overhead, cap):
    """The solver's CPU past the budget by more than the meter's slack: an answer that came after the cap does not count."""
    return run[2] - overhead > cap * 1.02 + 0.1


def cmd_run(a):
    ch = manifest()
    decl = C.load_decl()
    master = C.master_from(a)
    cap = ch["ladder"]["budget_seconds"]
    sizes = ch["ladder"]["practice_dims"] if a.practice else ch["ladder"]["dims"]
    n = a.n if a.n else (3 if a.practice else ch["ladder"]["n"])
    out = None
    if a.out:   # opened BEFORE the solver runs, not after: a bad path must fail now, not after hours of solving; records are written as they are made, so an interrupted run leaves a short ladder
        try:             # (which the scorer refuses for not covering the ladder) rather than nothing
            out = open(a.out, "x", encoding="utf-8")
        except FileExistsError:
            raise SystemExit(f"{a.out} exists: this tool never overwrites")
        except OSError as e:
            raise SystemExit(f"cannot write {a.out}: {e.strerror}")
    prefix, scratch = solver_scratch(a, [a.seed_file])
    print(f"solver {os.path.basename(a.solver)} sha256 {C.sha256_file(a.solver)[:16]}...; " + ("sandboxed" if prefix else "UNSANDBOXED: the solver runs as you")
          + f"; budget {cap} s per instance; {len(sizes)} sizes x {n} instances" + ("  (PRACTICE: not a challenge ladder)" if a.practice or a.n else ""))
    overhead = C.solver_overhead(os.path.join(scratch, "noop.py"), prefix, scratch)
    bench = machine_bench(scratch, prefix)
    print(f"machine calibration: {bench:.3f} CPU s for a fixed pure-Python workload (recorded in the ladder; qscore.py refuses to compare ladders whose calibrations differ by more than {QS.MACHINE_RATIO:g}x)")
    def emit(record):
        if out:
            out.write(json.dumps(record) + "\n")
            out.flush()
    scan_skipped = False
    emit({"meta": True, "commit": hashlib.sha256(master).hexdigest(), "budget": cap, "bench_cpu": round(bench, 4)})
    for size in sizes:
        qs, counts = [], {}
        for idx in range(n):
            inst = C.instance(decl, master, size, idx)
            run = C.run_solver(a.solver, inst["args"], cap, prefix, scratch)
            status, q = score_run(decl, inst, run)
            if status == "solved" and over_budget(run, overhead, cap):
                status, q = "timeout", 0.0
            if status == "solved" and C.hides_cpu(run, run[2]):
                status, q = "crash", 0.0     # waits or forks its work where the CPU meter cannot see it: the budget cannot be enforced, so the answer does not count
                print(f"  {size}:{idx}: over a second of wall time but under 30% of it as CPU: the budget cannot be enforced on this run; scored 0")
            if getattr(run, "strays", ()):   # a detached child (killed by run_solver) is work outside the budget, and can feed later instances through the scratch directory
                status, q = "crash", 0.0
                print(f"  {size}:{idx}: the solver left a detached process running after it returned (killed): the budget cannot be enforced on this run; scored 0")
            if not getattr(run, "scan_ran", True):
                scan_skipped = True
            counts[status] = counts.get(status, 0) + 1
            qs.append(q)
            emit({"id": inst["id"], "dim": size, "status": status, "quality": round(q, 6), "cpu": round(run[2], 3)})
        print(f"  size {size}: mean quality {statistics.fmean(qs):.4f}  ({', '.join(f'{k} {v}' for k, v in sorted(counts.items()))})")
    if scan_skipped:
        print("note: `ps` was unavailable, so detached processes could NOT be checked for (that is not the same as none found)")
    if out:
        out.close()
        print(f"wrote {a.out}")
    return 0


def cmd_verify(a):
    ch = manifest()
    bad = C.size_idx_problem(ch, a.size, a.idx)
    if bad:
        raise SystemExit(bad)
    decl = C.load_decl()
    inst = C.instance(decl, C.master_from(a), a.size, a.idx)
    try:
        valid, q = C.quality_of(decl, inst, C.read_answer(a.answer))
    except ValueError as e:
        raise SystemExit(f"the declaration is defective: {e}")
    print(json.dumps({"valid": valid, "quality": q}))
    return 0 if valid else 1


def ladder_qualities(path, master, ch):
    """{id: quality} of a ladder, refusing one run on a different seed than `master`."""
    try:
        meta, by_dim, _, _, _ = QS.load_ladder(path, ch["ladder"]["budget_seconds"])
    except QS.Refused as e:
        raise SystemExit(f"REFUSED: {e}")
    commit = meta.get("commit")
    if commit is not None and commit != hashlib.sha256(master).hexdigest():
        raise SystemExit(f"{path} was run on a different seed (its commitment is not this seed's sha256)")
    return {i: q for d in by_dim for i, q in by_dim[d].items()}


def cmd_qrerun(a):
    """Re-run a random sample of a claimed result on THIS machine with THIS verifier's own choice of instances, and compare the claimed qualities (solver AND reference)
    with the re-measured ones. A quality typed into a ladder, or a baseline weakened to inflate the gap, shows as a difference."""
    import random
    try:
        import resource  # noqa: F401
    except ImportError:
        raise SystemExit("qrerun needs a POSIX system (resource limits)")
    ch = manifest()
    decl = C.load_decl()
    master = C.master_from(a)
    cap = ch["ladder"]["budget_seconds"]
    base, claimed = ladder_qualities(a.baseline, master, ch), ladder_qualities(a.claimed, master, ch)
    allowed = set(ch["ladder"]["dims"]) | set(ch["ladder"]["practice_dims"])
    outside = sorted(i for i in set(base) | set(claimed) if int(i.split(":")[0]) not in allowed or int(i.split(":")[1]) >= 1000)
    if outside:   # an id is an instruction to derive() at that size: a ladder must not be able to choose what the verifier computes (a size of 999999 is minutes of work and gigabytes)
        raise SystemExit(f"REFUSED: {len(outside)} ladder id(s) are outside the challenge's sizes {sorted(allowed)} (index under 1000), e.g. {outside[0]!r}: not a ladder of this challenge")
    ids = sorted(set(base) & set(claimed))
    if not ids:
        raise SystemExit("the two ladders share no instance: nothing to re-run")
    sample_seed = a.sample_seed or os.urandom(8).hex()
    chosen = random.Random(sample_seed).sample(ids, min(a.k, len(ids)))
    print(f"sample seed {sample_seed} (an independent verifier picks their own; the operator must not know it in advance): {len(chosen)} of {len(ids)} instances")
    secret = C.read_key(a.sign) if a.sign else None
    if a.sign and not a.attest_out:
        raise SystemExit("--sign needs --attest-out FILE")
    if a.attest_out and os.path.exists(a.attest_out):
        raise SystemExit(f"{a.attest_out} exists: this tool never overwrites")
    if a.save and os.path.exists(a.save):
        raise SystemExit(f"{a.save} exists: this tool never overwrites")
    for dest in (a.save, a.attest_out):   # before the solver runs, not after: a mistyped directory must not cost a whole re-run
        if dest and not os.access(os.path.dirname(os.path.abspath(dest)), os.W_OK | os.X_OK):
            raise SystemExit(f"cannot write {dest}: its directory is missing or not writable")
    solver_sha = C.sha256_file(a.solver)
    prefix, scratch = solver_scratch(a, [a.seed_file, a.sign])
    print(f"solver {os.path.basename(a.solver)} sha256 {solver_sha[:16]}...; " + ("sandboxed" if prefix else "UNSANDBOXED: the solver runs as you"))
    overhead = C.solver_overhead(os.path.join(scratch, "noop.py"), prefix, scratch)
    ref_path = os.path.join(C.ROOT, ch["reference"]["file"])
    mine, theirs = machine_bench(scratch, prefix), [QS.load_ladder(p, cap)[0].get("bench_cpu") for p in (a.claimed, a.baseline)]
    mismatch = False
    for label, t in zip(("claimed", "baseline"), theirs):
        t = QS.S.finite_float(t)
        if t and max(t, mine) / min(t, mine) > QS.MACHINE_RATIO:
            mismatch = True
            print(f"note: this machine's calibration is {mine:.3f} s, the {label} ladder's {t:.3f} s ({max(t, mine) / min(t, mine):.2f}x apart): an anytime solver reaches different "
                  "qualities at the same CPU budget on a different machine, so a gap below is expected and is NOT evidence of a false claim")
    rows, hidden, over, left_behind, scan_skipped = [], [], [], [], False
    for iid in chosen:
        size, idx = (int(x) for x in iid.split(":"))
        inst = C.instance(decl, master, size, idx)
        rr, sr = (C.run_solver(p, inst["args"], cap, prefix, scratch) for p in (ref_path, a.solver))
        (rst, rq), (sst, sq) = score_run(decl, inst, rr), score_run(decl, inst, sr)
        if sst == "solved" and C.hides_cpu(sr, sr[2]):
            hidden.append(iid)
        if sst == "solved" and over_budget(sr, overhead, cap):
            over.append(iid)
        if getattr(sr, "strays", ()):
            left_behind.append(iid)
        if not getattr(sr, "scan_ran", True):
            scan_skipped = True
        rows.append((iid, claimed[iid], sq, base[iid], rq, sst))
        print(f"  {iid:>8}: solver claimed {claimed[iid]:.3f}, re-measured {sq:.3f} ({sst}); reference claimed {base[iid]:.3f}, re-measured {rq:.3f} ({rst})")
        if sst not in ("solved", "wrong", "failed") and sr[3]:
            print(f"            solver stderr: {sr[3]}" + ("   <- the sandbox probably blocked something the solver tried to do" if any(w in sr[3] for w in C.DENIAL_WORDS) else ""))
    solver_gaps = [abs(c - n) for _, c, n, _, _, _ in rows]
    base_gaps = [abs(c - n) for _, _, _, c, n, _ in rows]
    inflated = statistics.fmean(c - n for _, c, n, _, _, _ in rows)            # the solver's claims above what re-ran here: the direction a cheat pushes
    weakened = statistics.fmean(n - c for _, _, _, c, n, _ in rows)            # the reference's re-measured quality above what its ladder claims: a baseline made weaker to widen the gap
    # A median alone passes a ladder in which up to half the claims are invented, so the signed MEANS are checked too: randomness moves them either way and averages out, a cheat does not.
    ok = (not hidden and not over and not left_behind and statistics.median(solver_gaps) <= a.tolerance and statistics.median(base_gaps) <= a.tolerance
          and inflated <= a.tolerance and weakened <= a.tolerance)
    print(f"median |claimed - re-measured|: solver {statistics.median(solver_gaps):.3f}, reference {statistics.median(base_gaps):.3f} quality points (tolerance {a.tolerance:g}); "
          f"the solver's claims are {inflated:+.3f} on average above what re-ran here, the reference's {weakened:+.3f} below")
    if inflated > a.tolerance:
        print(f"FAIL: the solver's claimed qualities are {inflated:.3f} higher on average than what re-ran here (above the {a.tolerance:g} tolerance)")
    if weakened > a.tolerance:
        print(f"FAIL: the reference re-runs {weakened:.3f} better on average than its ladder claims: the baseline was weakened")
    if hidden:
        print(f"FAIL: on {sorted(set(hidden))} the solver ran over a second of wall time but its CPU is under 30% of it: it waits, or its work runs where the CPU meter cannot see it, "
              "so the budget cannot be enforced and the claimed quality is not confirmed")
    if over:
        print(f"FAIL: on {sorted(set(over))} the solver used more CPU than the {cap} s budget here; those answers would not count")
    if left_behind:
        print(f"FAIL: on {sorted(set(left_behind))} the solver left a detached process running after it returned (killed). Work done there is outside the budget, and it can feed later instances")
    if scan_skipped:
        print("note: `ps` was unavailable, so detached processes could NOT be checked for (that is not the same as none found)")
    if statistics.median(base_gaps) > a.tolerance:
        print("FAIL: the REFERENCE's re-measured qualities differ from the baseline ladder's: the baseline was not produced by this reference on this seed, or the reference is randomised")
    if statistics.median(solver_gaps) > a.tolerance:
        print("FAIL: the solver's re-measured qualities differ from its ladder's by more than the tolerance (median)")
    # On a machine of a different speed a failure to reproduce is expected whether or not the claim is true (found by re-running an honest anytime solver on this Mac's efficiency
    # cores: 5.9x slower, claims 0.07 high, outcome FAIL, and --sign would have signed that as a dissent against an honest claimant). So it is INCONCLUSIVE, never signed.
    # A claimant can force INCONCLUSIVE by writing a false calibration into their ladder: INCONCLUSIVE is not PASS, and is resolved on a machine whose calibration matches.
    # Only a failure to REPRODUCE qualities can be a machine-speed effect. Hidden CPU or an over-budget run is a violation of the budget on any machine, so a claimant cannot turn
    # it into INCONCLUSIVE by writing a false calibration into their ladder (found by probing: a sleeping solver with a "slow machine" ladder was excused).
    inconclusive = mismatch and not ok and not hidden and not over and not left_behind
    print("QRERUN " + ("PASS: the sampled claims reproduce" if ok else "INCONCLUSIVE: the machines differ in speed, so this is neither a confirmation nor a refutation (re-run on a machine whose calibration matches the ladder's)"
                       if inconclusive else "FAIL"))
    if inconclusive and secret:
        print("NOT SIGNING: an attestation says PASS or FAIL, and neither is true of this run")
        secret = None
    if a.save:
        import platform
        ident = f"{platform.platform()}|{platform.processor()}|{platform.node()}|{a.machine_label or ''}"
        saved = {"format": QMEASURE_FORMAT, "challenge_json_sha256": C.sha256_file(os.path.join(C.ROOT, "challenge.json")), "claimed_sha256": C.sha256_file(a.claimed),
                 "baseline_sha256": C.sha256_file(a.baseline), "machine_id": hashlib.sha256(ident.encode()).hexdigest()[:16], "machine_label": a.machine_label, "platform": platform.platform(),
                 "bench_cpu": round(mine, 4), "sample_seed": sample_seed, "solver_sha256": solver_sha,
                 "instances": [{"id": r[0], "claimed_quality": r[1], "solver_quality": r[2], "baseline_claimed": r[3], "reference_quality": r[4], "solver_status": r[5]} for r in rows]}
        try:
            with open(a.save, "x", encoding="utf-8") as f:
                json.dump(saved, f, indent=1, sort_keys=True)
        except OSError as e:
            raise SystemExit(f"cannot write {a.save}: {e.strerror}")
        print(f"saved the measurements to {a.save} (merge several machines' files with `qspread`)")
    if secret:
        import platform
        import time
        statement = {
            "format": C.ATTEST_FORMAT, "kind": "qrerun",
            "challenge": {"name": ch["name"], "version": ch["version"], "challenge_json_sha256": C.sha256_file(os.path.join(C.ROOT, "challenge.json"))},
            "solver_sha256": solver_sha, "claimed_sha256": C.sha256_file(a.claimed), "baseline_sha256": C.sha256_file(a.baseline),
            "seed_commit": hashlib.sha256(master).hexdigest(), "sample_seed": sample_seed, "k": len(chosen), "tolerance_quality": a.tolerance,
            "sandboxed": bool(prefix), "process_scan": not scan_skipped, "outcome": "PASS" if ok else "FAIL", "median_gap_quality": round(statistics.median(solver_gaps), 4),
            "instances": [{"id": r[0], "claimed_quality": round(r[1], 4), "remeasured_quality": round(r[2], 4), "baseline_claimed": round(r[3], 4), "baseline_remeasured": round(r[4], 4),
                           "solver_status": r[5]} for r in rows],
            "machine": {"platform": platform.platform(), "python": platform.python_version(), "processor": platform.processor() or platform.machine()},
            "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        C.write_attestation(a.attest_out, statement, secret)
    return 0 if ok else 2 if inconclusive else 1


def cmd_qspread(a):
    """Merge `qrerun --save` files from DIFFERENT machines for the SAME instances (same --sample-seed) and report how far the re-measured quality moves between machines, for the
    solver and for the reference, next to the machines' calibration ratio. An estimate from the machines and instances you give it, not a bound."""
    import math
    by_machine, problems, chash = {}, [], None
    for path in a.files:
        try:
            rec = json.loads(C.read_text(path, C.LIMIT_JSON))
            assert rec["format"] == QMEASURE_FORMAT and isinstance(rec["machine_id"], str) and isinstance(rec["instances"], list) and isinstance(rec["challenge_json_sha256"], str)
            bench = QS.S.finite_float(rec["bench_cpu"])
            assert bench and bench > 0
            rows = {}
            for r in rec["instances"]:
                sq, rq = QS.S.finite_float(r["solver_quality"]), QS.S.finite_float(r["reference_quality"])
                if sq is not None and rq is not None and 0 <= sq <= 1 and 0 <= rq <= 1:
                    rows[str(r["id"])] = (sq, rq)
        except (OSError, ValueError, KeyError, TypeError, AssertionError, AttributeError, RecursionError, OverflowError, C.FileRefused):
            problems.append(f"{path}: not a measurement file this tool writes (ignored)")
            continue
        if chash is not None and rec["challenge_json_sha256"] != chash:
            problems.append(f"{path}: measured a different challenge bundle (ignored)")
            continue
        chash = rec["challenge_json_sha256"]
        m = by_machine.setdefault(rec["machine_id"], {"bench": bench, "rows": {}, "label": str(rec.get("machine_label"))[:40]})
        m["rows"].update(rows)
    for p in problems:
        print("note: " + p)
    if len(by_machine) < 2:
        print(f"{len(by_machine)} distinct machine(s): a machine against itself is not machine-to-machine spread. Run `qrerun --sample-seed S --save F` with the SAME sample seed "
              "on at least two different machines and merge the files.")
        return 1
    names = sorted(by_machine)
    shared = {i for i in by_machine[names[0]]["rows"] if all(i in by_machine[n]["rows"] for n in names[1:])}
    if len(shared) < 3:
        print(f"only {len(shared)} instance(s) measured on every machine (need 3): use the same --sample-seed and a larger -k")
        return 1
    solver_rng = sorted(max(by_machine[n]["rows"][i][0] for n in names) - min(by_machine[n]["rows"][i][0] for n in names) for i in shared)
    ref_rng = sorted(max(by_machine[n]["rows"][i][1] for n in names) - min(by_machine[n]["rows"][i][1] for n in names) for i in shared)
    gain_rng = sorted(max(by_machine[n]["rows"][i][0] - by_machine[n]["rows"][i][1] for n in names) - min(by_machine[n]["rows"][i][0] - by_machine[n]["rows"][i][1] for n in names) for i in shared)
    bench = [by_machine[n]["bench"] for n in names]
    med = lambda v: v[len(v) // 2]   # noqa: E731
    print(f"{len(names)} machines ({', '.join(by_machine[n]['label'] if by_machine[n]['label'] != 'None' else n for n in names)}), calibration ratio {max(bench) / min(bench):.2f}x, {len(shared)} shared instances")
    print(f"re-measured quality differs between machines: solver median {med(solver_rng):.3f}, worst {solver_rng[-1]:.3f}; reference median {med(ref_rng):.3f}, worst {ref_rng[-1]:.3f}; "
          f"the solver-minus-reference GAIN median {med(gain_rng):.3f}, worst {gain_rng[-1]:.3f} (quality points)")
    rec_tol = max(0.02, math.ceil(max(solver_rng[-1], ref_rng[-1]) * 100) / 100)
    print(f"recommended qrerun --tolerance: {rec_tol:g} (the worst observed range rounded up to 0.01, never below 0.02; run-to-run noise on one machine is not in this number). "
          + ("Above the default of " + str(DEFAULT_TOLERANCE) + ": quality is NOT comparable across these machines at this budget." if rec_tol > DEFAULT_TOLERANCE else "An estimate from these machines and instances, not a bound."))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sandbox_help = "auto (default): run the solver without network, without writes outside a scratch directory and without reading the seed or keys, or refuse if the system has no sandbox; off: run it as you"
    p = sub.add_parser("run")
    p.add_argument("--seed-file")
    p.add_argument("--practice", action="store_true")
    p.add_argument("--solver", required=True)
    p.add_argument("--out", help="the ladder to write (never overwrites); without it the per-size summary is only printed")
    p.add_argument("--n", type=C.int_arg(1, 1000), help="instances per size (default: the challenge's; 3 with --practice). Anything but the default is NOT a challenge ladder")
    p.add_argument("--sandbox", choices=["auto", "off"], default="auto", help=sandbox_help)
    p = sub.add_parser("verify")
    p.add_argument("--seed-file")
    p.add_argument("--practice", action="store_true")
    p.add_argument("--size", type=C.int_arg(-10 ** 12, 10 ** 12), required=True)
    p.add_argument("--idx", type=C.int_arg(-10 ** 12, 10 ** 12), required=True)
    p.add_argument("--answer", required=True)
    p.add_argument("--sandbox", choices=["auto", "off"], default="auto", help="auto: re-run this command inside the OS sandbox, because it runs decl.py (the author's code)")
    p = sub.add_parser("qrerun")
    p.add_argument("--seed-file")
    p.add_argument("--practice", action="store_true")
    p.add_argument("--solver", required=True)
    p.add_argument("--claimed", required=True, help="the claimed ladder of that solver")
    p.add_argument("--baseline", required=True, help="the claimed ladder of the reference on the same seed")
    p.add_argument("-k", type=C.int_arg(1, 1000), default=5, help="instances to re-run (1..1000, default 5)")
    p.add_argument("--sample-seed", help="fix the sample (default: random, printed)")
    p.add_argument("--tolerance", type=C.float_arg(0, 1), default=DEFAULT_TOLERANCE, help=f"quality points the median claimed-vs-re-measured gap may reach (default {DEFAULT_TOLERANCE})")
    p.add_argument("--sandbox", choices=["auto", "off"], default="auto", help=sandbox_help)
    p.add_argument("--sign", metavar="KEYFILE", help="sign the outcome as an attestation (check.py keygen); needs --attest-out")
    p.add_argument("--attest-out", metavar="FILE")
    p.add_argument("--save", metavar="FILE", help="write the per-instance measurements (the machine is a hash) so several machines' runs can be merged with `qspread`")
    p.add_argument("--machine-label", help="a name for this machine (or, for an experiment, this CPU class) mixed into the machine hash and printed by qspread; it is whatever you type")
    p = sub.add_parser("qspread", help="merge `qrerun --save` files from different machines: how far does quality move between them?")
    p.add_argument("files", nargs="+")
    a = ap.parse_args(argv)
    if a.cmd == "verify" and a.sandbox == "auto":
        code = C.reexec_sandboxed(argv if argv is not None else sys.argv[1:], os.path.abspath(__file__))
        if code is not None:
            return code
    try:
        return {"run": cmd_run, "verify": cmd_verify, "qrerun": cmd_qrerun, "qspread": cmd_qspread}[a.cmd](a)
    except C.FileRefused as e:
        print(f"REFUSED: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
