"""Which open limits can be closed, and what evidence of closing exists on disk right now. Read-only: it runs nothing, evaluates nothing, writes nothing.

  python3 limits_plan.py [--data D] [--spread FILE FILE ...]

  --data D          the operator's data directory (ops.py --data): checks the sandbox marker there
  --spread F F ...  `compile_domain.py recheck NAME --measure K --save FILE` files from DIFFERENT machines: checks that a tolerance can be recommended

Each limit is one of
  CLOSABLE        engineering or more data closes it: the line says what, and RESOLVE.md has the commands
  NOT CLOSABLE    a property of the method, stated on the website for good (the site keeps these)
Evidence is only what is findable: a human still judges each pre-registered run against the criteria it wrote down. "evidence found" means the necessary
artefacts exist, not that the limit may be removed from the website; RESOLVE.md says which text to change when it is.
"""
import argparse
import glob
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(HERE, "results")


def _headers(pattern):
    """The first (header) line of every ladder file matching `pattern` in results/, as dicts."""
    out = []
    for p in sorted(glob.glob(os.path.join(RESULTS, pattern))):
        try:
            with open(p, encoding="utf-8") as f:
                h = json.loads(f.readline())
            if isinstance(h, dict) and h.get("meta"):
                out.append(h)
        except (OSError, ValueError):
            continue
    return out


def _preregs():
    """[(file name, text)] of every registration in results/."""
    out = []
    for p in sorted(glob.glob(os.path.join(RESULTS, "PREREGISTERED_*.txt"))):
        try:
            with open(p, encoding="utf-8") as f:
                out.append((os.path.basename(p), f.read()))
        except OSError:
            continue
    return out


def _completed(text):
    """A registration counts as run when ladders exist for its first seed commitment (the tag is the first 8 hex)."""
    m = re.search(r"commitment[^:\n]*:\s*([0-9a-f]{64})", text)
    return bool(m) and bool(glob.glob(os.path.join(RESULTS, f"judged_*_{m.group(1)[:8]}_*.jsonl")))


def check_sandbox(a):
    if not a.data:
        return None, "pass --data D (the operator's data directory) to look for the marker `portal.py verify-sandbox` writes"
    try:
        import portal_core
        ok = portal_core.sandbox_verified(os.path.abspath(a.data))
    except Exception as e:   # (any import or read problem: report, do not guess)
        return None, f"could not check: {type(e).__name__}"
    return ok, ("the marker is present and matches the sandbox files" if ok else "no valid marker: run `python3 launch_gates.py --with-docker --data D` on the Linux box")


def check_official(a):
    try:
        import judge
        with open(judge.BOARD, encoding="utf-8") as f:
            board = json.load(f)
        rows = judge.leaderboard_rows(board)
    except (OSError, ValueError, ImportError):
        return False, "no leaderboard on disk"
    official = [r for r in rows if r["status"] == "OFFICIAL"]
    return bool(official), (f"{len(official)} OFFICIAL row(s): " + ", ".join(f"{r['name']} ({r['family']}) {r['credit']} bits" for r in official)) if official else \
        f"no OFFICIAL row among {len(rows)} (an official row needs 3 seeds, the docker sandbox, the family's full n and cap)"


def check_one_job(a):
    n = [h for h in _headers("judged_*_submission_*.jsonl") if h.get("sandbox") == "docker" and h.get("jobs") == 1]
    return bool(n), (f"{len(n)} submission ladder(s) measured in the docker sandbox with one job at a time" if n else
                     "no ladder was measured in the docker sandbox with --jobs 1 (every ladder on disk is local-mode or several jobs at once)")


def check_fresh_seed(a):
    regs = _preregs()
    done = []
    for n, t in regs:
        fam = re.search(r"family\s+(\w+)", t)
        void = re.search(r"(?:this|the)\s+(?:pre-?)?registration\s+is\s+void", t, re.I)    # (a file that merely mentions voided predecessors is not void itself)
        if fam and fam.group(1) in ("gm", "mlwe") and not void and _completed(t):
            done.append(n)
    return len(done) >= 3, (f"{len(regs)} registration(s) on disk; {len(done)} completed, non-void lattice run(s): {', '.join(done) or 'none'}. Closing needs at least 3 FRESH-seed lattice runs "
                            "(the first fresh-seed run counts), each registered before its data and judged against its written criteria (a person judges: see Results)")


def check_clean_control(a):
    hits = []
    for n, t in _preregs():
        fam = re.search(r"family\s+(\w+)", t)
        if fam and fam.group(1) == "factor" and re.search(r"--jobs\s+1\b|jobs\s*[:=]\s*1\b", t) and re.search(r"docker", t) and _completed(t):
            hits.append(n)
    return bool(hits), (f"a factoring control run one job at a time in docker: {', '.join(hits)}" if hits else
                        "no registered factoring control was run in docker with one job at a time (the seed E control ran six jobs at once, locally)")


def check_spread(a):
    if not a.spread:
        return None, "pass --spread FILE FILE ... (measurement files from at least two different machines) to check whether a tolerance can be recommended"
    try:
        import recheck
        res, rec = recheck.spread(a.spread)
    except Exception as e:
        return None, f"could not read them: {type(e).__name__}: {str(e)[:100]}"
    return rec is not None, (f"recommended tolerance {rec:g} bits from {len(a.spread)} file(s)" if rec is not None else "; ".join(f"{r['check']}: {r['detail']}" for r in res if r["status"] != "pass")[:300])


# (id, the limit in a few words, closable?, what closes it, evidence function or None, RESOLVE.md section, website text to change when it is closed)
LIMITS = [
    ("sandbox", "The Docker sandbox has never been verified on a real host", True, "a Linux host: `launch_gates.py --with-docker --data D` (test_sandbox + verify-sandbox)", check_sandbox, "1",
     "the first item of report_html.LIMITS, the 'locked box has not been tried' banner on the home page, 'never yet run on a real machine' on Limits"),
    ("official", "No result is official (3 seeds, sandbox, full n and cap)", True, "an official round: `ops.py round-new` with 3 seeds, worker, reveal, certs", check_official, "2",
     "the second item of report_html.LIMITS and the footer 'No result on this site is official'"),
    ("one-job", "Runs used several jobs at once (a solver-dependent bias)", True, "the official worker evaluates one question at a time in the sandbox: the first docker ladder with jobs=1", check_one_job, "3",
     "the two 'Several jobs at once' bullets on Limits"),
    ("fresh-seed", "One seed is one sample; the credit rule was designed on seed A", True, "3+ pre-registered fresh-seed lattice runs (prereg_templates/fresh_seed_replication.criteria.txt)", check_fresh_seed, "4",
     "'One seed is one sample' and the seed A item of report_html.LIMITS"),
    ("clean-control", "The factoring control is not a clean recovery of a known number", True, "a calibrated pair at the ladder's own sizes, docker, one job (prereg_templates/clean_factoring_control.criteria.txt)", check_clean_control, "5",
     "the factoring-control bullet on Limits"),
    ("spread", "Cross-machine spread is unmeasured, so the re-measurement tolerance is loose", True, "`compile_domain.py recheck NAME --measure K --save F` on 2+ machines, then `spread`", check_spread, "6",
     "'Computers differ' on Limits and certificate.RERUN_TOLERANCE"),
    ("egg", "The paper's own code cannot yet be used as a baseline", True, "research, not engineering: a sieve that reaches the target past dimension 30", None, "7",
     "the last item of report_html.LIMITS"),
    ("range", "The certifiable range is about 1.5 to 3 bits (ceiling near 5)", False, "set by the 0.5 s cost floor and the cap; a larger n per round extends it but nothing removes the ceiling", None, "-", "stays on the website"),
    ("private", "A private solver's timings rest on the operator's sandbox", False, "would need trusted hardware or zero-knowledge proofs of execution: not feasible for solvers that run for minutes", None, "-", "stays on the website"),
    ("baseline", "The baseline decides what counts", False, "authors state what beats their baseline and independent baselines help, but it stays a judgement", None, "-", "stays on the website"),
]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--data")
    ap.add_argument("--spread", nargs="+")
    a = ap.parse_args(argv)
    for key, title, closable, how, fn, section, site in LIMITS:
        if not closable:
            print(f"NOT CLOSABLE  {title}\n              {how}. {site}.\n")
            continue
        ok, detail = (fn(a) if fn else (False, "needs research; there is nothing to check on disk"))
        tag = "evidence found" if ok else ("unknown" if ok is None else "open")
        print(f"CLOSABLE ({tag})  {title}\n              closes with: {how}\n              evidence: {detail}\n              RESOLVE.md section {section}; when closed, change: {site}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
