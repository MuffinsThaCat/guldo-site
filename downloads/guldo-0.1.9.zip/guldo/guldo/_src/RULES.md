# Competition rules (DRAFT, version draft-1)

**This is a draft written by the developer of the software, not legal advice. The operator must decide the bracketed items and
have the text reviewed before publishing it. The submission form refers to it as "draft-1".**

1. **What you submit.** One Python file that defines `solve` for the round's family (see the Compete page). You may submit up to 3
   files per round under one handle. You need the file's rights to submit it.
2. **How it is run.** While a round is open your file is only parsed, never run. After the round closes it is run in a sandbox
   without network or file access, on instances generated from seeds whose hashes were published before the round opened, against
   a reference solver, with a CPU cap per instance. The seeds are revealed after evaluation.
3. **What counts.** Credit is a statistical lower bound on speedup, taken as the minimum over at least three seeds (PROTOCOL.md).
   A result the method cannot separate from noise is reported as inconclusive. [Prize, if any, and how it is decided: operator to fill in.]
4. **Fair play.** Do not try to leave the sandbox, read the judge's files or seeds, hide CPU use from the meter, detect that you are
   being measured, or attack the service. Such a submission is disqualified and may be reported. Do not test against the live
   service for vulnerabilities without the operator's written permission; [security contact: operator to fill in].
5. **What is published.** Your handle, the SHA-256 of each file, the time it was received and its result are public and permanent
   (the log is append-only). Your source is published after the seeds are revealed **only if you tick the box** when you submit.
   [Licence you grant for the source you choose to publish: operator to choose.]
6. **What is collected.** The handle and the file. No account, email or IP address is stored by this software. The operator's web
   server or proxy may keep its own logs: [operator to state].
7. **Your token.** The token shown at your first submission is the only proof a handle is yours. We cannot recover it.
8. **Removal.** Before the deadline you cannot withdraw a submission from the log (that would defeat the log), but you can submit
   another. After the reveal you may ask for your published source to be removed; its hash stays in the log.
9. **No guarantee.** Results are measurements on specific hardware and may be provisional or inconclusive. The operator may pause,
   cancel or rerun a round, and says so in the log when it does. [Governing law and venue: operator to fill in.]
