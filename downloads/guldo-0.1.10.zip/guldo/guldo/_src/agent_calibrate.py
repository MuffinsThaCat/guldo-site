"""Fit the TOKEN CALIBRATION (provider-billed tokens against this project's proxy count) for ANY model, from real ladders, and record it where `agent_preflight` reads it. Standard library + agent_core + agent_eval.

  agent_calibrate.py fit   LADDER... (--practice | --seed FILE) [--allow-unverified]       fit and print per model; changes NOTHING
  agent_calibrate.py write LADDER... (--practice | --seed FILE) [--file F] [--replace]      fit, check the gates, record in the data file (the old file is kept as F.prev)

Why. `agent_preflight` prices a run from a calibration: per call, billed_input = A * proxy_in + B, and billed_output = R * proxy_out. Two models were measured by hand (haiku and sonnet, 27 November);
every other model is priced from the WORST measured values and labelled NOT calibrated. Calibrating a new model is now: run a small pilot (`preflight` prints the command), then `write` on its ladder.
A fit from the 27 November ladders reproduces the hand-measured numbers exactly (haiku: 92 calls, A 1.477, B 387.2, R 2.13, R^2 0.997; sonnet: 63 calls, 1.589, 250.6, 3.55, 0.9854), tested.

What a ladder gives. Every assistant turn records `proxy_in`/`proxy_out` (this project's counter) and the provider's own `usage`. The fit is ordinary least squares over all such calls.

What stops a bad entry (all must hold to WRITE; `fit` just reports them):
  * the ladder VERIFIES from its seed (a hand-edited usage number breaks the hash chain, which `read_ladder` alone does not notice): --practice or --seed is required, and --allow-unverified only lets
    `fit` look, never `write`;
  * at least 30 calls from at least 3 trials, and enough spread in the context sizes to tell the slope from the intercept;
  * R^2 of the input fit >= 0.90, and a leave-one-trial-out check: the fit made WITHOUT a trial predicts that trial's billed input within 10%;
  * A in [0.5, 6], B in [0, 5000], R in [0.5, 10] (the loader enforces the same ranges, so a hand-edited data file cannot put nonsense into a cost estimate);
  * an existing entry is not replaced by one built on FEWER calls unless --replace.
What it does not give: a calibration for another domain, long contexts, prompt caching or retries (only what the ladders contain); the usage numbers are the ladder's own copy unless it was attested through
a recording proxy and checked against the proxy log (`agent_proxy.py verify`), which this module does not do for you; the fit says how this model was billed on those calls, not what a different model will cost."""
import argparse
import hashlib
import json
import math
import os
import shutil
import sys

import agent_core
import agent_eval

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_FILE = os.path.join(HERE, "agent_calibration.json")
FORMAT = "guldo-token-calibration-v1"
MIN_CALLS, MIN_TRIALS, MIN_R2, MAX_LOO_ERR = 30, 3, 0.90, 0.10
A_RANGE, B_RANGE, R_RANGE = (0.5, 6.0), (0.0, 5000.0), (0.5, 10.0)
MAX_FILE_BYTES = 200_000
MAX_KEY = 120


class CalibrationError(Exception):
    pass


def model_key(spec):
    """'anthropic:claude-haiku-4-5-20251001' -> 'claude-haiku-4-5-20251001'; 'anthropic:claude-sonnet-5-5:medium' -> 'claude-sonnet-5-5:medium'; 'compat:qwen2.5:3b' -> 'qwen2.5:3b'.
    The key `agent_preflight` looks for inside an agent spec. The EFFORT setting stays in the key: it changes how many hidden thinking tokens are billed as output, so the output ratio of one effort level
    says nothing about another (found by audit: they were being averaged into one entry). A spec without an effort suffix matches the plain key, whatever effort it later runs at: record each level you use."""
    provider, _, rest = str(spec).partition(":")
    return rest.lower().strip()


def match_key(keys, agent_spec):
    """The recorded key that prices this agent spec, or None. EXACT on the model id: the spec's model part (after the provider) must equal the key, or be the key plus an effort suffix (':high'), so a
    key `gpt-4` never prices `gpt-4o`, a different model with different billing (substring matching would, and 'longest key first' cannot help when only the shorter key exists). An effort-specific
    key beats a plain one. The tool itself always writes exact ids (`model_key`)."""
    model = str(agent_spec).lower().partition(":")[2]
    best = None
    for k in keys:
        if model == k or model.startswith(k + ":"):
            if best is None or len(k) > len(best):
                best = k
    return best


def _sha(path):
    return agent_core.file_sha256(path)


def collect(paths, verify_with=None):
    """-> {model key: {"points": [(proxy_in, billed_in, proxy_out, billed_out, trial)], "sources": [...], "domains": set, "verified": bool}}.
    `verify_with` = a master seed: every ladder is verified from it first, and a ladder that does not verify is refused."""
    out = {}
    for path in paths:
        verified = False
        if verify_with is not None:
            probs, _ = agent_eval.verify_ladder(path, verify_with, None, None, True)
            if probs:
                raise CalibrationError("%s does not verify (%d problems, first: %s): a ladder that does not verify is never used for a calibration" % (path, len(probs), str(probs[0])[:120]))
            verified = True
        header, records = agent_core.read_ladder(path)
        spec = (header.get("agent") or {}).get("spec")
        if not spec:
            raise CalibrationError("%s names no agent spec" % path)
        entry = out.setdefault(model_key(spec), {"points": [], "sources": [], "domains": set(), "verified": True})
        entry["verified"] = entry["verified"] and verified
        entry["sources"].append({"file": os.path.basename(path), "sha256": _sha(path)})
        entry["domains"].add(header.get("domain"))
        for rec in records:
            for t in rec.get("turns", []):
                u = t.get("usage")
                if t.get("role") != "assistant" or not isinstance(u, dict):
                    continue
                vals = (t.get("proxy_in"), u.get("input_tokens"), t.get("proxy_out"), u.get("output_tokens"))
                if all(isinstance(v, int) and not isinstance(v, bool) and v >= 0 for v in vals) and vals[0] > 0:
                    entry["points"].append(vals + ("%s#%s#%s" % (os.path.basename(path), rec.get("instance"), rec.get("trial")),))
    return out


def _ols(pts):
    n = len(pts)
    sx, sy = sum(p[0] for p in pts), sum(p[1] for p in pts)
    sxx, sxy = sum(p[0] * p[0] for p in pts), sum(p[0] * p[1] for p in pts)
    den = n * sxx - sx * sx
    if den == 0:
        raise CalibrationError("every call had the same context size: the slope cannot be separated from the intercept")
    a = (n * sxy - sx * sy) / den
    return a, (sy - a * sx) / n


def fit_points(pts):
    """Least squares over (proxy_in, billed_in, proxy_out, billed_out, trial) tuples -> a dict of the fit and its checks."""
    if len(pts) < 3:
        raise CalibrationError("too few calls to fit anything")
    a, b = _ols(pts)
    ybar = sum(p[1] for p in pts) / len(pts)
    ss_tot = sum((p[1] - ybar) ** 2 for p in pts)
    ss_res = sum((p[1] - (a * p[0] + b)) ** 2 for p in pts)
    r2 = 1 - ss_res / ss_tot if ss_tot else 0.0
    po, bo = sum(p[2] for p in pts), sum(p[3] for p in pts)
    r = bo / po if po else float("nan")
    trials = sorted({p[4] for p in pts})
    loo = 0.0
    if len(trials) >= 3:
        for tr in trials:
            rest = [p for p in pts if p[4] != tr]
            try:
                a2, b2 = _ols(rest)
            except CalibrationError:
                continue
            mine = [p for p in pts if p[4] == tr]
            actual = sum(p[1] for p in mine)
            loo = max(loo, abs(sum(a2 * p[0] + b2 for p in mine) - actual) / actual if actual else 0.0)
    xs = [p[0] for p in pts]
    return {"A": a, "B": b, "R_out": r, "n_calls": len(pts), "n_trials": len(trials), "r2_in": r2, "loo_max_err": loo, "x_min": min(xs), "x_max": max(xs)}


def gates(fit, verified):
    """The reasons a fit may NOT be recorded (empty = it may)."""
    why = []
    if not verified:
        why.append("the ladder was not verified from its seed (give --practice or --seed): an unverified ladder could carry edited usage numbers")
    if fit["n_calls"] < MIN_CALLS:
        why.append("%d calls: at least %d are needed" % (fit["n_calls"], MIN_CALLS))
    if fit["n_trials"] < MIN_TRIALS:
        why.append("%d trials: at least %d are needed (one trial's calls are not independent evidence)" % (fit["n_trials"], MIN_TRIALS))
    if fit["x_max"] - fit["x_min"] < 50 or fit["x_max"] < 1.5 * fit["x_min"]:
        why.append("the context sizes barely vary (%d to %d tokens): the slope and the intercept cannot be told apart" % (fit["x_min"], fit["x_max"]))
    if not (fit["r2_in"] >= MIN_R2):
        why.append("R^2 of the input fit is %.3f, below %.2f: billing is not linear in the proxy count for these calls" % (fit["r2_in"], MIN_R2))
    if fit["loo_max_err"] > MAX_LOO_ERR:
        why.append("the leave-one-trial-out check is off by %.1f%% on its worst trial (limit %.0f%%)" % (100 * fit["loo_max_err"], 100 * MAX_LOO_ERR))
    for name, key, (lo, hi) in (("A", "A", A_RANGE), ("B", "B", B_RANGE), ("R", "R_out", R_RANGE)):
        v = fit[key]
        if not (isinstance(v, float) and math.isfinite(v) and lo <= v <= hi):
            why.append("%s = %s is outside the plausible range [%s, %s]" % (name, v, lo, hi))
    return why


# ---- the data file ---------------------------------------------------------------------------------------------------------------------------------------

def _entry_problem(key, e):
    if not (isinstance(key, str) and 0 < len(key) <= MAX_KEY and key == key.lower() and all(c.isalnum() or c in "-._:" for c in key)):
        return "a model key %r is not a lower-case model id" % (key,)
    if not isinstance(e, dict):
        return "the entry for %s is not an object" % key
    for name, (lo, hi) in (("A", A_RANGE), ("B", B_RANGE), ("R_out", R_RANGE)):
        v = e.get(name)
        if not (isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and lo <= v <= hi):
            return "%s for %s is not a number in [%s, %s]" % (name, key, lo, hi)
    n, r2 = e.get("n_calls"), e.get("r2_in")
    if not (isinstance(n, int) and not isinstance(n, bool) and n >= MIN_CALLS):
        return "n_calls for %s is not an integer >= %d" % (key, MIN_CALLS)
    if not (isinstance(r2, (int, float)) and not isinstance(r2, bool) and math.isfinite(r2) and MIN_R2 <= r2 <= 1.0):
        return "r2_in for %s is not in [%s, 1]" % (key, MIN_R2)
    return None


def read_file(path=None):
    """-> {key: entry}. Raises CalibrationError for anything wrong: this file prices real spending, so a damaged one is refused, never partly used."""
    path = path or DEFAULT_FILE
    if not os.path.exists(path):
        return {}
    if os.path.getsize(path) > MAX_FILE_BYTES:
        raise CalibrationError("the calibration file is larger than %d bytes" % MAX_FILE_BYTES)
    try:
        with open(path, "r", encoding="utf-8") as f:
            doc = json.load(f)
    except (OSError, ValueError, RecursionError) as e:
        raise CalibrationError("the calibration file cannot be read (%s)" % type(e).__name__)
    if not isinstance(doc, dict) or doc.get("format") != FORMAT or not isinstance(doc.get("models"), dict):
        raise CalibrationError("the calibration file is not a %s document" % FORMAT)
    for k, e in doc["models"].items():
        bad = _entry_problem(k, e)
        if bad:
            raise CalibrationError(bad)
    return doc["models"]


def load_table(path=None):
    """-> ({key: (A, B, R_out, n_calls, r2_in)}, problem or None). A bad file gives an EMPTY table and the reason, never a crash and never a partly trusted file."""
    try:
        return {k: (float(e["A"]), float(e["B"]), float(e["R_out"]), int(e["n_calls"]), float(e["r2_in"])) for k, e in read_file(path).items()}, None
    except CalibrationError as e:
        return {}, str(e)


def record(key, fit, collected, path=None, replace=False):
    """Add or replace ONE model's entry; the previous file is kept as <file>.prev; the write is atomic. Returns the entry."""
    path = path or DEFAULT_FILE
    if not collected.get("verified"):                                                 # the gates check this too; repeated here so no other caller can record from an unverified ladder
        raise CalibrationError("the ladders were not verified from their seed: nothing is recorded from them")
    models = read_file(path)
    old = models.get(key)
    if old and old["n_calls"] > fit["n_calls"] and not replace:
        raise CalibrationError("%s already has an entry built on %d calls; this one has %d. Refusing to replace better evidence with less (--replace to override)" % (key, old["n_calls"], fit["n_calls"]))
    entry = {"A": round(fit["A"], 4), "B": round(fit["B"], 2), "R_out": round(fit["R_out"], 4), "n_calls": fit["n_calls"], "n_trials": fit["n_trials"], "r2_in": round(fit["r2_in"], 5),
             "loo_max_err": round(fit["loo_max_err"], 5), "domains": sorted(d for d in collected["domains"] if d), "sources": collected["sources"], "ladders_verified": bool(collected["verified"])}
    bad = _entry_problem(key, entry)
    if bad:
        raise CalibrationError("the fitted entry would not pass the loader's own checks: " + bad)
    models[key] = entry
    if os.path.exists(path):
        shutil.copyfile(path, path + ".prev")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"format": FORMAT, "models": models}, f, indent=1, sort_keys=True)
        f.write("\n")
    os.replace(tmp, path)
    return entry


# ---- command line ----------------------------------------------------------------------------------------------------------------------------------------

def _describe(key, fit, why):
    return ("%s: %d calls from %d trials; billed_in = %.3f * proxy_in + %.1f (R^2 %.4f, worst leave-one-trial-out error %.1f%%); billed_out = %.2f * proxy_out" %
            (key, fit["n_calls"], fit["n_trials"], fit["A"], fit["B"], fit["r2_in"], 100 * fit["loo_max_err"], fit["R_out"]) + ("" if not why else "\n    NOT RECORDABLE: " + "\n    NOT RECORDABLE: ".join(why)))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["fit", "write"])
    ap.add_argument("ladders", nargs="+")
    ap.add_argument("--seed")
    ap.add_argument("--practice", action="store_true")
    ap.add_argument("--allow-unverified", action="store_true", help="fit only: look at an unverified ladder (never recordable)")
    ap.add_argument("--file", default=DEFAULT_FILE)
    ap.add_argument("--replace", action="store_true")
    a = ap.parse_args(argv)
    try:
        master = agent_core.read_master(a.seed, a.practice) if (a.seed or a.practice) else None
        if master is None and not (a.cmd == "fit" and a.allow_unverified):
            print("REFUSED: give --practice or --seed so the ladders are verified first (fit alone may use --allow-unverified).")
            return 2
        got = collect(a.ladders, master)
        status = 0
        for key, c in sorted(got.items()):
            fit = fit_points(c["points"]) if len(c["points"]) >= 3 else None
            if fit is None:
                print("%s: %d usable calls: nothing to fit (does the ladder carry provider usage?)" % (key, len(c["points"])))
                status = 1
                continue
            why = gates(fit, c["verified"])
            print(_describe(key, fit, why))
            if a.cmd == "write":
                if why:
                    status = 1
                    continue
                entry = record(key, fit, c, a.file, a.replace)
                print("  recorded in %s (%d calls)" % (a.file, entry["n_calls"]))
        return status
    except (CalibrationError, agent_core.AgentEvalError, OSError, ValueError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
