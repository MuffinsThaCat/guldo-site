"""svp: submit a solver to a round and verify the result, entirely from the command line.

  svp.py rounds      [--server URL]                          the rounds a server is running
  svp.py round ID    [--server URL]                          one round: deadline, family, commitments, submissions
  svp.py submit FILE --round ID --handle NAME --accept-rules [--publish-source] [--token T]
                                                             check the file locally, upload it, and confirm your receipt in the public log
  svp.py status      --round ID [--id SID | --handle NAME] [--wait SECONDS]
  svp.py certificate --round ID --id SID [--out FILE] [--full]   download the public certificate (after the reveal); --full = YOUR full one, with your source
  svp.py verify      --round ID --id SID [--rerun K --execute]   download it AND check it against the server's log and your own receipt
  svp.py verify      FILE.cert.json [--rerun K --execute]    check a certificate file you already have (offline)
  svp.py verify      ... --source SOLVER.py                  a private-solver certificate + the solver its owner published: hash-check it, then re-run it
  svp.py receipts                                            what this machine has submitted
  svp.py practice SOLVER --family F [--n N] [--yes]          no server: run your solver on three seeds of your own and certify the run (PROVISIONAL)

The server is --server URL or $SVP_SERVER. Receipts and tokens live in $SVP_HOME (default ~/.svp), mode 0600.

PRIVATE SOLVERS. Submit without --publish-source and your solver stays private: the public certificate carries its hash but not its source (and no
failure messages, which quote code). Everyone can still verify the log, the fingerprints, the questions and the credit arithmetic; nobody but the
operator can inspect or re-run it, so its timings rest on the operator's sandbox. If you later publish the file, `verify --source FILE` upgrades the
certificate to fully re-checkable. A private solver is hidden from the public, not from the operator, who ran it.

What `verify` proves: the seeds' fingerprints were public before any submission, the questions are exactly the seeds' own, the rules are the ones
named, the credit follows from the recorded timings, the log the certificate carries is the server's own, and (when you have a receipt) the file
that was evaluated is the one you uploaded. What it does NOT prove: that the recorded timings are what a real run took. A certificate says whether
they came from the locked-box sandbox or from a bare local run (then it is only PROVISIONAL); `--rerun K --execute` re-measures K instances on
your machine, running the certificate's code unsandboxed (use a throwaway VM).

Exit status: 0 = done / verified, 1 = a check failed, 2 = could not do it (bad usage, network, not ready yet).
"""
import argparse
import contextlib
import fcntl
import json
import os
import re
import secrets
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

import certificate
import rounds
import submit_check

PROG = "svp.py"   # the name shown in --help; the installed package's `guldo` command sets it to "guldo"

MAX_JSON = 16 * 2 ** 20           # bytes accepted from a server in one response (a log or a round description)
MAX_CERT = 64 * 2 ** 20           # a certificate carries every raw timing record
TIMEOUT = 30
LOOPBACK = ("127.0.0.1", "localhost", "::1", "[::1]")
RULES_URL_HINT = "RULES.md in this repository (the version a server shows is in its submission form)"


class SvpError(Exception):
    """Something the user can act on: shown as one line, exit status 2."""


def clean(text, n=300):
    """Server-supplied text goes to a terminal: keep printable ASCII only, so it cannot drive the terminal."""
    if isinstance(text, bytes):
        text = text.decode("utf-8", "replace")
    return re.sub(r"[^\x20-\x7e]", "?", str(text))[:n]


# ------------------------------------------------------------------------------------------------------------- network
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None  # a redirect would forward the Authorization header (your token) to wherever the server points: refused instead


_OPENER = urllib.request.build_opener(_NoRedirect)


def normalize_server(url):
    if not url:
        raise SvpError("no server: pass --server https://host or set SVP_SERVER")
    u = urllib.parse.urlsplit(url if "://" in url else "https://" + url)
    if u.scheme not in ("http", "https") or not u.hostname:
        raise SvpError(f"{clean(url, 80)!r} is not an http(s) server address")
    if u.username or u.password:
        raise SvpError("put no credentials in the server address")
    try:
        u.port  # a malformed port raises here, with an unhelpful message later if we let it through
    except ValueError:
        raise SvpError(f"{clean(url, 80)!r} has an invalid port")
    return f"{u.scheme}://{u.netloc.lower()}"


def _loopback(server):
    return (urllib.parse.urlsplit(server).hostname or "") in LOOPBACK


def check_transport(server, sends_secret, allow_insecure_http=False):
    if sends_secret and server.startswith("http://") and not _loopback(server) and not allow_insecure_http:
        raise SvpError(f"{server} is plain http: your token or source would cross the network unencrypted. Use https, or pass --allow-insecure-http if you "
                       "really mean it")


MAX_SECONDS = 120                 # for a whole small response; a certificate may take longer (MAX_SECONDS_CERT)
MAX_SECONDS_CERT = 900


def _read_limited(resp, limit, seconds):
    """Read at most limit+1 bytes within `seconds` IN TOTAL. The socket timeout only bounds each read, so a server that drips one byte every 29 s
    would otherwise hold this client for hours."""
    end, chunks, n = time.monotonic() + seconds, [], 0
    while n <= limit:
        if time.monotonic() > end:
            raise SvpError(f"the server is too slow (more than {seconds} s for one response): giving up")
        b = resp.read(min(65536, limit + 1 - n))
        if not b:
            break
        chunks.append(b)
        n += len(b)
    return b"".join(chunks)


def request(server, path, method="GET", data=None, headers=None, limit=MAX_JSON):
    req = urllib.request.Request(server + path, data=data, method=method, headers=dict(headers or {}))
    seconds = MAX_SECONDS if limit <= MAX_JSON else MAX_SECONDS_CERT
    try:
        with _OPENER.open(req, timeout=TIMEOUT) as r:
            status, body = r.status, _read_limited(r, limit, seconds)
    except urllib.error.HTTPError as e:
        status, body = e.code, _read_limited(e, limit, seconds)
        if 300 <= status < 400:
            raise SvpError(f"the server redirected {path} (HTTP {status}); refused, because a redirect could send your token elsewhere. Use the final address")
    except (urllib.error.URLError, OSError) as e:
        raise SvpError(f"cannot reach {server}: {clean(getattr(e, 'reason', e), 120)}")
    if len(body) > limit:
        raise SvpError(f"the response to {path} is larger than {limit // 2 ** 20} MiB: refused")
    return status, body


def get_json(server, path, headers=None, limit=MAX_JSON):
    status, body = request(server, path, headers=headers, limit=limit)
    if status != 200:
        raise SvpError(f"{path}: HTTP {status}: {clean(body, 160)}")
    try:
        return json.loads(body)
    except ValueError:
        raise SvpError(f"{path}: the server did not return JSON")


def multipart(fields, filename, content):
    filename = re.sub(r"[^A-Za-z0-9._-]", "_", filename)[:80] or "solver.py"   # a file NAME can hold quotes or CRLF: never put it in a header raw
    boundary = "svp" + secrets.token_hex(12)
    parts = []
    for k, v in fields.items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n'.encode() + v.encode() + b"\r\n")
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{filename}"\r\nContent-Type: text/x-python\r\n\r\n'.encode()
                 + content + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


# ------------------------------------------------------------------------------------------------------------- local store
class Store:
    """Receipts and handle tokens on THIS machine: the receipt is what lets `verify` say the evaluated file is the one you uploaded."""

    def __init__(self, home=None):
        self.home = os.path.abspath(os.path.expanduser(home or os.environ.get("SVP_HOME") or "~/.svp"))
        self.path = os.path.join(self.home, "receipts.json")

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                d = json.load(f)
        except FileNotFoundError:
            return {"receipts": {}, "tokens": {}}
        except (OSError, ValueError):
            d = None
        if isinstance(d, dict) and isinstance(d.get("receipts"), dict) and isinstance(d.get("tokens"), dict):
            return d
        # an unreadable store is NEVER treated as empty: the next save would overwrite it, destroying tokens that were shown only once
        raise SvpError(f"{self.path} is damaged. Move it aside (it may still hold tokens you need) and run again; nothing was changed")

    def save(self, d):
        os.makedirs(self.home, mode=0o700, exist_ok=True)
        tmp = self.path + f".{os.getpid()}.tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1, sort_keys=True)
        os.replace(tmp, self.path)

    @contextlib.contextmanager
    def locked(self):
        """Two svp processes at once must not overwrite each other's receipts: a token is shown only once."""
        os.makedirs(self.home, mode=0o700, exist_ok=True)
        fd = os.open(os.path.join(self.home, ".lock"), os.O_CREAT | os.O_RDWR, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    @staticmethod
    def rkey(server, rid, sid):
        return f"{server}|{rid}|{sid}"

    @staticmethod
    def tkey(server, rid, handle):
        return f"{server}|{rid}|{handle.lower()}"

    def add(self, server, rid, receipt, token=None):
        with self.locked():
            d = self.load()
            d["receipts"][self.rkey(server, rid, receipt["id"])] = receipt
            if token:
                d["tokens"][self.tkey(server, rid, receipt["handle"])] = token
            self.save(d)

    def token(self, server, rid, handle):
        return self.load()["tokens"].get(self.tkey(server, rid, handle))

    def receipt(self, server, rid, sid):
        return self.load()["receipts"].get(self.rkey(server, rid, sid))

    def receipts(self, server=None, rid=None):
        out = []
        for k, v in sorted(self.load()["receipts"].items()):
            s, r, _ = k.split("|", 2)
            if (server is None or s == server) and (rid is None or r == rid):
                out.append((s, r, v))
        return out


# ------------------------------------------------------------------------------------------------------------- the public log
def parse_log(body):
    out = []
    for line in body.decode("utf-8", "replace").splitlines():
        if line.strip():
            try:
                out.append(json.loads(line))
            except ValueError:
                raise SvpError("the server's log is not valid JSON lines")
    return out


def check_receipt_in_log(entries, commitments, receipt, local_sha):
    """-> (ok, message): the log's hash chain verifies, and entry `seq` is a submission carrying exactly the hash of the file you uploaded."""
    ok, why = certificate.commit_published(entries, commitments)
    if not ok:
        return False, f"the server's public log does not verify: {why}"
    seq = receipt.get("seq")
    if not isinstance(seq, int) or not 0 <= seq < len(entries):
        return False, f"log entry #{clean(seq, 20)} does not exist"
    e = entries[seq]
    if e.get("kind") != "submission" or (e.get("data") or {}).get("sha256") != local_sha:
        return False, f"log entry #{seq} is not a submission of the file you uploaded (hash {local_sha[:16]}...)"
    if e.get("hash") != receipt.get("hash"):
        return False, f"log entry #{seq} has a different hash from your receipt"
    return True, f"entry #{seq} of {len(entries)} carries your file's hash ({local_sha[:16]}...) and the chain verifies"


def log_is_prefix(cert_log, live):
    """The certificate's log must be the server's own log (or the start of it, if the round has moved on): same entries, same order."""
    if len(cert_log) > len(live):
        return False
    return all(rounds.canonical(a) == rounds.canonical(b) for a, b in zip(cert_log, live))


# ------------------------------------------------------------------------------------------------------------- commands
def _server(a):
    return normalize_server(getattr(a, "server", None) or os.environ.get("SVP_SERVER"))


def _fmt_time(ts):
    return time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(ts)) if isinstance(ts, (int, float)) else "?"


def cmd_rounds(a):
    server = _server(a)
    data = get_json(server, "/api/rounds.json")
    if not isinstance(data, list) or not all(isinstance(r, dict) for r in data):
        raise SvpError("the server's list of rounds is malformed")
    if a.json:
        print(json.dumps(data, indent=1))
        return 0
    if not data:
        print("no rounds")
    for r in data:
        subs = r.get("submissions")
        count = len(subs) if isinstance(subs, list) else subs if isinstance(subs, int) else "?"   # /api/rounds.json lists them; an export index counts them
        print(f"{clean(r.get('id'), 41):24s} {clean(r.get('family'), 12):10s} {clean(r.get('state'), 12):11s} closes {_fmt_time(r.get('closes_at'))}  "
              f"{count} submission(s)  {clean(r.get('title'), 60)}")
    return 0


def _round(server, rid):
    if not rounds.ROUND_ID_RE.match(rid or ""):
        raise SvpError("a round id is 2-41 characters of a-z, 0-9 and '-'")
    r = get_json(server, f"/api/round/{rid}.json")
    subs = r.get("submissions") if isinstance(r, dict) else None
    commits = r.get("commitments") if isinstance(r, dict) else None
    if not (isinstance(subs, list) and all(isinstance(s, dict) for s in subs) and isinstance(commits, list)
            and all(isinstance(c, str) for c in commits)):
        raise SvpError(f"the server's description of round {rid} is malformed")   # a hostile or buggy server must cost one line, not a traceback
    return r


def cmd_round(a):
    server = _server(a)
    r = _round(server, a.id)
    if a.json:
        print(json.dumps(r, indent=1))
        return 0
    print(f"{clean(r.get('title'), 80)}  [{clean(r.get('id'), 41)}]\n  family {clean(r.get('family'), 12)}, state {clean(r.get('state'), 12)}, "
          f"{clean(r.get('n', '?'), 10)} questions per size, {clean(r.get('budget', '?'), 10)} s CPU limit\n  opens {_fmt_time(r.get('opens_at'))}, closes {_fmt_time(r.get('closes_at'))}")
    print(f"  log: {r.get('log_entries', '?')} entries, {'verifies' if r.get('log_ok') else 'DOES NOT VERIFY'}, head {clean(r.get('log_head'), 16)}")
    print("  solvers: " + ("every submission must publish its source (after the reveal)" if r.get("allow_private") is False else
                           "may stay private (then the public certificate carries only the solver's hash and its timings rest on the operator's sandbox)"))
    cnt = r.get("count") if r.get("cost_model") == "count" and isinstance(r.get("count"), dict) else None
    if cnt:   # a COUNTED round: the cost is an instruction count, so the "CPU limit" above is in counted seconds and the whole ladder is a public rule
        print(f"  cost model: STEP COUNTING (not seconds) on {clean(cnt.get('python'), 30)}: sizes {clean(cnt.get('dims'), 80)}, {clean(cnt.get('n'), 10)} per size, cap "
              f"{clean(cnt.get('cap'), 10)} counted seconds (one counted second = {clean(cnt.get('steps_per_second'), 12)} instructions). Declared before any submission; anyone can re-execute "
              "the counts (`svp.py verify ... --rerun K --execute`, on that Python). Solvers run unsandboxed, so test yours with `python3 counted.py check` first.")
    print("  seed fingerprints (public from the first log entry):")
    for c in r.get("commitments", []):
        print("    " + clean(c, 64))
    for s in r.get("submissions", []):
        res = s.get("result")
        shown = ("pending" if "result" not in s else f"{clean(res.get('credit'), 20)} bits, {clean(res.get('status'), 40)}" if isinstance(res, dict)
                 else "no result: " + clean(s.get("reason"), 60))
        print(f"  #{clean(s.get('seq'), 10)} {clean(s.get('handle'), 32):20s} {clean(s.get('id'), 12)}  {clean(s.get('state'), 10):9s} {shown}")
    return 0


def cmd_submit(a):
    server = _server(a)
    if not a.accept_rules:
        raise SvpError(f"you must pass --accept-rules to confirm you have read the rules ({RULES_URL_HINT}); the server records that you did")
    try:
        with open(a.file, "rb") as f:
            content = f.read()
    except OSError as e:
        raise SvpError(f"cannot read {a.file}: {e.strerror}")
    if not content:
        raise SvpError("the file is empty")
    if len(content) > rounds.MAX_UPLOAD:
        raise SvpError(f"the file is {len(content)} bytes; the limit is {rounds.MAX_UPLOAD}")
    local_sha = rounds.sha256(content)
    if not a.no_check:
        try:
            warnings, fatal = submit_check.lint(a.file)
        except (SyntaxError, ValueError, RecursionError) as e:
            warnings, fatal = [], [f"could not parse: {type(e).__name__}"]
        if fatal:
            raise SvpError("the file would be rejected: " + "; ".join(fatal) + " (fix it, or use --no-check to let the server decide)")
        for w in warnings:
            print(f"  note: {w}")
    r = _round(server, a.round)
    if r.get("state") != "open":
        raise SvpError(f"round {a.round} is {clean(r.get('state'), 12)}, not open: nothing was sent")
    if r.get("allow_private") is False and not a.publish_source:
        raise SvpError(f"round {a.round} requires every solver to be published (a public rule logged in its first entry): add --publish-source. Your source "
                       "becomes public only after the seeds are revealed. Nothing was sent")
    if r.get("cost_model") == "count" and not a.no_check:   # the same rule the server applies to a counted round, so a rejection still costs nothing
        import counted
        tam = counted.source_problems(content.decode("utf-8", "replace"))
        if tam:
            raise SvpError(f"round {a.round} counts instructions and runs solvers in a restricted subset of Python (pure computation: no sys, files, frames, getattr/type/eval, "
                           "dunder attributes); your source is outside it: " + "; ".join(tam[:5]) + ". Fix it, or use --no-check to let the server decide. Nothing was sent")
    store = Store(a.home)
    try:
        with store.locked():    # can the receipt and token be KEPT? Find out before anything is sent: the token is shown only once
            store.load()
    except OSError as e:
        raise SvpError(f"cannot keep your receipt and token in {store.home} ({e.strerror or e}): nothing was sent. Use --home or $SVP_HOME for a writable directory")
    token = a.token or store.token(server, a.round, a.handle)
    check_transport(server, True, a.allow_insecure_http)   # the source itself is private until the reveal, so plain http to a remote host is refused regardless
    fields = {"handle": a.handle, "agree": "on"}
    if token:
        fields["token"] = token
    if a.publish_source:
        fields["publish_source"] = "on"
    body, ctype = multipart(fields, os.path.basename(a.file), content)
    status, resp = request(server, f"/round/{a.round}/submit", method="POST", data=body, headers={"Content-Type": ctype, "Accept": "application/json"})
    try:
        out = json.loads(resp)
    except ValueError:
        raise SvpError(f"HTTP {status}: {clean(resp, 160)}")
    if status != 200 or not out.get("ok"):
        raise SvpError(f"the server did not accept it (HTTP {status}): {clean(out.get('error', resp), 200)}")
    if out.get("sha256") != local_sha:
        print(f"FAIL: the server says it stored a file with hash {clean(out.get('sha256'), 64)}, but the file you sent hashes to {local_sha}. "
              "Do not trust this submission.", file=sys.stderr)
        return 1
    # what we are about to SAVE (and later put in a header or a store key) must have the exact shape a real receipt has
    tok = out.get("token")
    if not (isinstance(out.get("id"), str) and re.fullmatch(r"[0-9a-f]{12}", out["id"]) and isinstance(out.get("seq"), int) and not isinstance(out.get("seq"), bool)
            and isinstance(out.get("hash"), str) and re.fullmatch(r"[0-9a-f]{64}", out["hash"]) and isinstance(out.get("handle"), str)
            and (tok is None or (isinstance(tok, str) and re.fullmatch(r"[A-Za-z0-9_-]{8,128}", tok)))):
        raise SvpError("the server's receipt is malformed: nothing was saved (your file may still have been accepted: check `svp.py status`)"
                       + (f". The reply also carried this token, which you may need if it was accepted: {clean(tok, 64)}" if isinstance(tok, str) and tok else ""))
    receipt = {k: out.get(k) for k in ("id", "handle", "seq", "hash", "sha256", "round")}
    receipt.update({"file": os.path.basename(a.file), "submitted_at_local": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "confirmed_in_log": False})
    try:
        store.add(server, a.round, receipt, out.get("token"))   # saved BEFORE the log check: the token is shown once and must never be lost to a network error
        saved = True
    except (OSError, SvpError) as e:
        # the upload already succeeded: whatever happens to the local file, the user must still SEE the receipt and the one-time token
        saved = False
        print(f"WARNING: could not save your receipt and token on this machine ({clean(e, 120)}). WRITE THEM DOWN NOW:\n"
              f"  round {a.round}  submission {receipt['id']}  handle {receipt['handle']}  token {out.get('token') or '(none: the handle already existed)'}", file=sys.stderr)
    print(f"accepted: submission {receipt['id']} as {receipt['handle']}, log entry #{receipt['seq']}")
    for w in out.get("warnings") or []:
        print(f"  warning: {clean(w)}")
    if not a.publish_source:
        print("  Your solver stays PRIVATE: after the reveal the public certificate carries only its hash (no source, no failure messages). The operator still ran it,\n"
              "  and others must trust the operator's sandbox for your timings. If you publish the file later, anyone can check it with `svp.py verify ... --source FILE`.")
    if out.get("token"):
        print(f"TOKEN (shown once, {'saved in ' + store.path if saved else 'NOT SAVED: write it down'}): {out['token']}\n  Keep it: it is the only way to submit again as "
              f"{receipt['handle']} in this round, and to download your certificate if you did not publish your source.")
    # the receipt is worthless unless the PUBLIC log shows it: check that now, with your own copy of the chain
    status, logbody = request(server, f"/api/log/{a.round}.jsonl")
    if status != 200:
        print(f"could not fetch the public log to confirm the receipt (HTTP {status}); run `svp.py status` later", file=sys.stderr)
        return 2
    ok, msg = check_receipt_in_log(parse_log(logbody), r.get("commitments", []), receipt, local_sha)
    print(("CONFIRMED in the public log: " if ok else "FAIL: ") + msg)
    if ok:
        receipt["confirmed_in_log"] = True
        try:
            store.add(server, a.round, receipt)
        except (OSError, SvpError):
            pass   # the receipt was already saved (or the warning above was shown); failing to mark it confirmed must not turn a good submission into an error
        print(f"Your file is read, never run, until the round closes ({_fmt_time(r.get('closes_at'))}). Then: svp.py status --round {a.round} --id {receipt['id']}")
    return 0 if ok else 1


def _find(round_json, a, store, server):
    subs = round_json.get("submissions", [])
    if getattr(a, "id", None):
        hit = [s for s in subs if s.get("id") == a.id]
    elif getattr(a, "handle", None):
        hit = [s for s in subs if str(s.get("handle", "")).lower() == a.handle.lower()]
    else:
        mine = {rc["id"] for _, _, rc in store.receipts(server, round_json.get("id"))}
        hit = [s for s in subs if s.get("id") in mine]
    if not hit:
        raise SvpError("no matching submission in that round (give --id or --handle, or submit from this machine first)")
    return hit


def cmd_status(a):
    server, store = _server(a), Store(a.home)
    deadline = time.time() + (a.wait or 0)
    last = None
    while True:
        r = _round(server, a.round)
        hit = _find(r, a, store, server)
        done = r.get("state") in ("evaluated", "revealed")
        if a.json:
            shown = json.dumps({"round_state": r.get("state"), "submissions": hit}, indent=1)
        else:
            lines = [f"round {a.round}: {clean(r.get('state'), 12)}"]
            for s in hit:
                res = s.get("result")
                line = f"  {clean(s.get('handle'), 32)} {clean(s.get('id'), 12)}  {clean(s.get('state'), 10)}"
                if "result" in s:
                    line += (f"  credit {clean(res.get('credit'), 20)} bits, {clean(res.get('status'), 40)}" if isinstance(res, dict)
                             else f"  no result ({clean(s.get('reason'), 80)})")
                lines.append(line)
                if s.get("certificate"):
                    lines.append(f"    certificate ready: svp.py verify --round {a.round} --id {s.get('id')}")
            shown = "\n".join(lines)
        if shown != last:   # while waiting, print only when something changed
            print(shown, flush=True)
            last = shown
        if done or time.time() >= deadline:
            break
        time.sleep(min(30, max(1, deadline - time.time())))
    return 0 if done or not a.wait else 2


def _cert_path(rid, sid, full=False):
    if not rounds.ROUND_ID_RE.match(rid or "") or not re.fullmatch(r"[0-9a-f]{12}", sid or ""):
        raise SvpError("a submission id is 12 hex characters (svp.py status shows it) and a round id is 2-41 characters of a-z, 0-9 and '-'")
    return f"/api/cert-full/{rid}/{sid}.json" if full else f"/api/cert/{rid}/{sid}.json"


def fetch_certificate(server, rid, sid, store, token=None, allow_insecure_http=False, full=False):
    """The PUBLIC certificate (default): no token is ever sent, and a damaged receipts file cannot matter. It carries the solver's source only if its owner
    published it; otherwise it is a private-solver copy. `full`: YOUR full certificate with the source, which needs the handle's token."""
    headers = None
    if full:
        token = token or None
        if token is None:
            rc = store.receipt(server, rid, sid)
            if rc:
                token = store.token(server, rid, rc["handle"])
        if not token:
            raise SvpError("the full certificate contains the solver's source, which only its owner may fetch: it needs the handle's token "
                           "(use the machine you submitted from, or --token)")
        check_transport(server, True, allow_insecure_http)
        headers = {"Authorization": "Bearer " + token}
    status, body = request(server, _cert_path(rid, sid, full), headers=headers, limit=MAX_CERT)
    if status == 404:
        raise SvpError("no certificate for that submission yet: certificates exist only after the seeds are revealed (svp.py status shows when)")
    if status == 403:
        if full:
            raise SvpError("that token is not accepted for the full certificate of this submission (it must be the token of the handle that submitted it)")
        try:   # the PUBLIC certificate was refused: no token was involved, so say what the server said (e.g. it is not ready for public release)
            why = json.loads(body).get("error", "") if isinstance(json.loads(body), dict) else ""
        except ValueError:
            why = ""
        raise SvpError("the server refused to release this certificate" + (f": {clean(why, 200)}" if why else ""))
    if status != 200:
        raise SvpError(f"HTTP {status}: {clean(body, 160)}")
    try:
        cert = json.loads(body)
    except ValueError:
        raise SvpError("the server did not return a certificate")
    if not isinstance(cert, dict) or cert.get("format") != certificate.FORMAT:
        raise SvpError("what the server returned is not a speedup certificate")
    return cert, body


def cmd_certificate(a):
    server, store = _server(a), Store(a.home)
    cert, body = fetch_certificate(server, a.round, a.id, store, a.token, getattr(a, "allow_insecure_http", False), getattr(a, "full", False))
    out = a.out or f"{a.round}-{a.id}" + (".full" if getattr(a, "full", False) else "") + ".cert.json"
    if os.path.exists(out):
        raise SvpError(f"{out} exists; a certificate is never overwritten")
    fd = os.open(out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(fd, "wb") as f:
        f.write(body)
    print(f"saved {out}. Check it with: svp.py verify {out}")
    return 0


def _sandbox_of(cert):
    try:
        lad = next(iter(cert["ladders"].values()))
        return json.loads(lad["submission"].splitlines()[0]).get("sandbox")
    except (KeyError, ValueError, IndexError, StopIteration, AttributeError):
        return None


def verify_certificate(cert, a, extra=None):
    """Run every check and print them. `extra` = checks that only a server round-trip can make. -> (ok, [checks])"""
    if a.execute:
        print("NOTE: --execute runs code from the certificate on this machine, unsandboxed. Do this only in a throwaway VM or container.", file=sys.stderr)
    res = certificate.verify(cert, rerun=a.rerun, execute=a.execute, tolerance=a.tolerance, sample_seed=a.sample_seed, source=getattr(a, "source_data", None))
    checks = list(extra or []) + res["checks"]
    ok = all(c["status"] != "fail" for c in checks)
    return ok, checks, res


def cmd_verify(a):
    store = Store(a.home)
    extra, cert = [], None
    a.source_data = None
    if getattr(a, "source", None):   # a solver its owner has published, to check against a private-solver certificate (BYTES: the committed hash is of the exact file)
        try:
            with open(a.source, "rb") as f:
                a.source_data = f.read()
        except OSError as e:
            raise SvpError(f"cannot read {clean(a.source, 80)}: {e.strerror}")
    if a.file:
        try:
            with open(a.file, encoding="utf-8") as f:
                cert = json.load(f)
        except (OSError, ValueError) as e:
            raise SvpError(f"cannot read {clean(a.file, 80)} as a certificate: {type(e).__name__}")
        server = rid = sid = None
    else:
        if not (a.round and a.id):
            raise SvpError("give a certificate file, or --round and --id (and --server)")
        server, rid, sid = _server(a), a.round, a.id
        cert, _ = fetch_certificate(server, rid, sid, store, a.token, getattr(a, "allow_insecure_http", False), getattr(a, "full", False))
        r = _round(server, rid)
        status, logbody = request(server, f"/api/log/{rid}.jsonl")
        live = parse_log(logbody) if status == 200 else None
        add = lambda name, ok, detail: extra.append({"check": name, "status": "pass" if ok else "fail", "detail": detail})
        add("server: round revealed", r.get("state") == "revealed", f"the round is {clean(r.get('state'), 12)}")
        add("server: same seed fingerprints", sorted(cert.get("commitments", [])) == sorted(r.get("commitments", [])),
            "the certificate's commitments are the round's own" if sorted(cert.get("commitments", [])) == sorted(r.get("commitments", []))
            else "the certificate names different seed fingerprints from the round")
        if live is None:
            extra.append({"check": "server: log matches", "status": "skip", "detail": f"could not fetch the server's log (HTTP {status})"})
        else:
            same = log_is_prefix(cert.get("log") or [], live)
            add("server: log matches", same, "the certificate's log is the server's own log" if same else
                "the certificate's log DIFFERS from the log the server publishes (the operator may be showing different logs to different people)")
    # your own receipt: was the evaluated file the one you uploaded?
    cert_sha = (cert.get("submission") or {}).get("sha256") if isinstance(cert.get("submission"), dict) else None
    log = cert.get("log") if isinstance(cert.get("log"), list) else []
    in_log = lambda rc: any(isinstance(e, dict) and e.get("kind") == "submission" and e.get("hash") == rc.get("hash")
                            and (e.get("data") or {}).get("sha256") == rc.get("sha256") for e in log)
    try:
        cands = [rc for _, _, rc in store.receipts(server, rid) if rc.get("sha256") == cert_sha and (sid is None or rc.get("id") == sid)]
        store_problem = None
    except SvpError as e:   # your receipts are an extra check, not a requirement: a damaged file must not stop the verification itself
        cands, store_problem = [], str(e)
    mine = next((rc for rc in cands if in_log(rc)), None)
    if store_problem:
        extra.append({"check": "your receipt", "status": "skip", "detail": "not checked: " + clean(store_problem, 200)})
    elif mine:
        extra.append({"check": "your receipt", "status": "pass",
                      "detail": f"the evaluated file is the one you uploaded ({mine['sha256'][:16]}...) and your logged entry #{mine.get('seq')} is in the certificate's log"})
    elif cands and sid is not None:
        # you asked for THIS submission and you have a receipt for exactly this file, yet the log entry you were given is not in the certificate
        extra.append({"check": "your receipt", "status": "fail",
                      "detail": "your receipt's log entry is NOT in this certificate's log: this may not be the evaluation of your file"})
    else:
        # offline, or no receipt for this file: a file submitted to several rounds must not make an unrelated certificate FAIL
        extra.append({"check": "your receipt", "status": "skip", "detail": "none of the receipts on this machine is for this certificate, so it is not "
                      "checked that the evaluated file is yours"})
    ok, checks, res = verify_certificate(cert, a, extra)
    report(ok, checks, res, cert, a.json)
    return 0 if ok else 1


def report(ok, checks, res, cert, as_json):
    sandbox = _sandbox_of(cert)
    private, revealed, counted = bool(res.get("private")), bool(res.get("source_revealed")), bool(res.get("counted"))
    if as_json:
        print(json.dumps({"verified": ok, "claim": res.get("claim"), "measured_in": "step counting" if counted else (sandbox or "local mode"),
                          "cost_model": "count" if counted else "time", "private_solver": private, "source_checked": revealed, "checks": checks}, indent=1))
        return
    for c in checks:
        print(f"  {c['status'].upper():4s} {clean(c['check'], 60)}: {clean(c['detail'], 400)}")
    if ok and res.get("claim"):
        c = res["claim"]
        print(f"\nVERIFIED{' (PRIVATE SOLVER)' if private and not revealed else ''}: {c['credit_bits']} bits, {c['status']}.")
        if counted:
            print("  measured by: deterministic STEP COUNTING (Python bytecode instructions), not by a clock.")
            log0 = cert["log"][0] if isinstance(cert, dict) and isinstance(cert.get("log"), list) and cert["log"] and isinstance(cert["log"][0], dict) else {}
            declared = isinstance(log0.get("data"), dict) and log0["data"].get("cost_model") == "count"   # (a verified certificate: the log check ties this to the ladder)
            print("  This proves the arithmetic and the fairness. The costs are exactly reproducible: `--rerun K --execute` on the same Python version must give IDENTICAL "
                  "step counts, and that equality is a proof of the recorded costs that trusts nobody's machine or sandbox. It is NOT a timing, it cannot see work done inside "
                  "a C function (one instruction however long it runs), and "
                  + ("the ladder (sizes, questions per size, cap) was declared by the round in its first log entry before any submission, the same for every participant."
                     if declared else "the ladder was chosen by whoever ran it, so it is not an official round result."))
        else:
            print(f"  measured in: {'the ' + sandbox + ' sandbox' if sandbox else 'bare local mode (so at most PROVISIONAL)'}.")
            print("  This proves the arithmetic and the fairness. It does not prove the recorded timings were honest: only the sandbox, or re-measuring"
                  " (`--rerun K --execute`), addresses that.")
        logged = bool(cert.get("log")) if isinstance(cert, dict) else False
        if private and not revealed:
            print("  PRIVATE SOLVER: its source is not part of this certificate, so you could not inspect it or re-run it. The timings therefore rest on the operator's "
                  "sandbox alone. " + ("The solver's hash is the one the round's log committed to before the seeds were revealed: " if logged else
                                       "The solver's hash is recorded in this certificate (it was built outside a round, so no log committed to it): ")
                  + "if its owner publishes the file, check it with `--source FILE`.")
        elif private and revealed:
            print("  The solver you supplied is exactly the one this certificate measured" + (" (same hash as the round's log committed to)." if logged else "."))
    else:
        print("\nNOT VERIFIED. Do not rely on this certificate.")


# ------------------------------------------------------------------------------------------------------------- practice: certify a local run, no server
_RUN = subprocess.run          # tests replace these two
_RESULTS_DIR = None            # where judge.py writes ladders (None = this project's results/)


def _c_extension_imports(path):
    """Libraries whose work happens inside C and so counts as ONE instruction however long it runs (see counted.py): a counted run that leans on them says almost nothing."""
    import counted   # one list for the client and for round creation (counted.family_problem)
    return counted.c_extension_imports(path)


def cmd_practice(a):
    """Run YOUR solver against a family on three fresh seeds of your own, in bare local mode, and build a certificate you can verify. No server
    and no sandbox, so the result is PROVISIONAL and the seeds were yours (nothing was committed publicly first): it shows what your solver earns
    under this protocol, not an official result."""
    import families
    import official
    if a.family not in families.FAMILIES:
        raise SvpError(f"unknown family {clean(a.family, 40)!r}; one of {', '.join(sorted(families.FAMILIES))}")
    solver = os.path.abspath(a.solver)
    if not os.path.isfile(solver):
        raise SvpError(f"cannot read {clean(a.solver, 80)}")
    try:
        warnings, fatal = submit_check.lint(solver)
    except (SyntaxError, ValueError, RecursionError) as e:
        warnings, fatal = [], [f"could not parse: {type(e).__name__}"]
    if fatal:
        raise SvpError("the file would be rejected: " + "; ".join(fatal))
    if (a.n is not None and a.n < 1) or (a.budget is not None and a.budget < 1):
        raise SvpError("--n and --budget must be positive")
    counting = bool(getattr(a, "count", False))
    out = a.out or f"{os.path.splitext(os.path.basename(solver))[0]}.{a.family}.practice.cert.json"
    if os.path.exists(out):
        raise SvpError(f"{out} exists; a certificate is never overwritten")
    if counting:
        import counted
        import judge
        if not counted.supported():
            raise SvpError(f"--count needs Python {counted.MIN_PYTHON[0]}.{counted.MIN_PYTHON[1]} or newer (this is {counted.python_version()})")
        dims = list(getattr(a, "dims", None) or [])
        if not dims or min(dims) < 1:
            raise SvpError("--count needs --dims: the sizes to count, small enough that counting (about 100x slower than running) finishes, e.g. --family factor --dims 38 40 42 --cap 40")
        n = a.n or 8
        cap = a.cap if getattr(a, "cap", None) is not None else 20.0
        if n < 1 or not (0 < cap <= certificate.MAX_COUNTED_CAP):   # `not (...)` also catches NaN; the verifier refuses any larger cap, so the run would be wasted
            raise SvpError(f"--n must be positive and --cap a number between 0 and {certificate.MAX_COUNTED_CAP:g} counted seconds")
        if a.budget is not None:
            print("note: --budget is for clock measurement and is ignored with --count (use --cap).", file=sys.stderr)
        baseline = judge.default_baseline(a.family)
        bext = _c_extension_imports(baseline)
        if bext:   # a credit is a ratio against the baseline: if its work hides in C (1 instruction), any counted "speedup" over it is an artefact
            raise SvpError(f"REFUSED: the default baseline for {a.family} imports {', '.join(bext)}, so its work happens inside C and counts as almost nothing: a counted "
                           "credit against it would be meaningless. Step counting needs a pure-Python baseline; measure this family by clock instead (drop --count).")
        with open(solver, encoding="utf-8", errors="replace") as f:
            tam = counted.source_problems(f.read())
        if tam:   # the counter runs solvers in a restricted subset of Python and enforces it itself: find out before spending any time
            raise SvpError("REFUSED: the counter runs solvers in a restricted subset of Python (pure computation: no sys, files, frames, getattr/type/eval, dunder attributes) "
                           "and your solver is outside it: " + "; ".join(tam[:5]))
        for label, path in (("your solver", solver),):
            ext = _c_extension_imports(path)
            if ext:
                print(f"WARNING: {label} imports {', '.join(ext)}. Work done inside C libraries counts as ONE instruction however long it runs, so counted costs for "
                      "it say almost nothing: step counting is meaningful only for pure-Python work on both sides.", file=sys.stderr)
        print(f"{a.family}: STEP COUNTING on sizes {dims}, {n} questions per size, cap {cap:g} counted seconds ({int(cap * counted.STEPS_PER_SECOND):,} instructions), "
              f"3 seeds of your own.\n  Counting is roughly 100x slower than running: worst case about {counted.worst_case_seconds(dims, n, cap) / 60:.0f} minutes "
              "(every question spending its whole cap), usually far less. The baseline is counted too.")
    else:
        n = a.n or families.OFFICIAL[a.family]["n"]
        budget = a.budget or families.OFFICIAL[a.family]["budget"]
        plan = official.plan_cost(a.family, 3, n=n, budget=budget)
        print(f"{a.family}: sizes {plan['dims']}, {n} questions per size, {budget:g} s CPU limit, 3 seeds of your own, bare local mode.\n"
              f"  Worst case {plan['worst_case_cpu_hours']:.1f} CPU-hours (every question failing at the limit); a solver that works costs far less. "
              "The baseline is measured too.")
    if not a.yes:
        print("Nothing was run. Re-run with --yes to start (it can take a long time; --n and --budget shrink it, and the certificate records what you used)."
              if not counting else "Nothing was run. Re-run with --yes to start (--n, --cap and --dims shrink it, and the certificate records what you used).")
        return 2
    if counting:   # a program whose count changes between two identical runs cannot be certified this way: find out BEFORE spending the time
        for label, path in (("the baseline", baseline), ("your solver", solver)):
            same, x, y = counted.selfcheck(path, a.family, min(dims), cap)
            problem = counted.selfcheck_problem(label, same, x, y)
            if problem:
                raise SvpError(problem)
    import shutil
    import tempfile
    work = tempfile.mkdtemp(prefix="svp-practice-")     # the seeds live outside the project tree
    results = _RESULTS_DIR or os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
    tags = set()
    try:
        seed_dir = os.path.join(work, "seeds")
        tags = {c[:8] for c in official.make_commitments(seed_dir, 3)}   # the ladders this run writes are named by these, and only these
        env = dict(os.environ, SVP_BOARD=os.path.join(work, "board.json"))   # never touch the project's own leaderboard
        for i, (seed_file, _) in enumerate(official.verified_seeds(seed_dir), 1):
            if counting:
                print(f"seed {i}/3: counting (baseline, then your solver) ...", flush=True)
                counted.evaluate_seed(a.family, seed_file, solver, baseline, dims, n, cap, results)
                continue
            print(f"seed {i}/3: evaluating (baseline, then your solver) ...", flush=True)
            cmd = [sys.executable, "judge.py", "evaluate", "--seed", seed_file, "--submission", solver, "--family", a.family, "--insecure-local",
                   "--reuse-baseline", "--n", str(n), "--budget", str(budget)]
            r = _RUN(cmd, cwd=os.path.dirname(os.path.abspath(__file__)), env=env, capture_output=True, text=True)
            if r.returncode:
                raise SvpError(f"the evaluation failed on seed {i}: {clean((r.stdout + r.stderr)[-300:], 300)}")
        try:
            cert = certificate.build(a.family, solver, seed_dir, reveal_seeds=True, results_dir=_RESULTS_DIR, private=getattr(a, "private", False))
        except (certificate.CertificateError, SystemExit) as e:
            raise SvpError(f"could not build the certificate: {clean(e, 200)}")
        fd = os.open(out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(cert, f, indent=1, sort_keys=True)
    finally:
        # the certificate carries every raw timing record, so the ladder files this run created are redundant. Remove exactly the files named by THIS
        # run's own seed tags: anything else in results/ (another process's ladders, even for the same family) is never touched
        for fn in (os.listdir(results) if os.path.isdir(results) else []):
            if any(fn.startswith(f"judged_{a.family}_{t}_") for t in tags):
                try:
                    os.remove(os.path.join(results, fn))
                except OSError:
                    pass
        shutil.rmtree(work, ignore_errors=True)
    print(f"wrote {out}\n")
    args = argparse.Namespace(execute=False, rerun=0, tolerance=certificate.RERUN_TOLERANCE, sample_seed=0)
    ok, checks, res = verify_certificate(cert, args)
    report(ok, checks, res, cert, False)
    if counting:
        print(f"\nThis was YOUR counted run on YOUR seeds. Anyone on the same Python can re-execute it and must get IDENTICAL step counts: "
              f"svp.py verify {out} --rerun 5 --execute (throwaway VM: it runs the solvers).")
    else:
        print(f"\nThis was YOUR run on YOUR seeds in bare local mode: PROVISIONAL by construction. Anyone can re-check it: svp.py verify {out}")
    return 0 if ok else 1


def cmd_receipts(a):
    store = Store(a.home)
    rows = store.receipts()
    if not rows:
        print(f"no receipts in {store.path}")
    for s, r, rc in rows:
        print(f"{s}  round {r}  submission {rc['id']}  as {rc['handle']}  log #{rc['seq']}  "
              f"{'confirmed in the public log' if rc.get('confirmed_in_log') else 'NOT confirmed in the log'}  file {clean(rc.get('file'), 60)}  sha256 {rc['sha256'][:16]}...")
    return 0


# ------------------------------------------------------------------------------------------------------------- entry point
def build_parser():
    ap = argparse.ArgumentParser(prog=PROG, description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog="\n".join(__doc__.split("\n")[2:]))
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--server", help="https://host of the submission service (or $SVP_SERVER)")
    common.add_argument("--home", help="where receipts and tokens are kept (default $SVP_HOME or ~/.svp)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("rounds", parents=[common])
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("round", parents=[common])
    p.add_argument("id")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("submit", parents=[common])
    p.add_argument("file")
    p.add_argument("--round", required=True)
    p.add_argument("--handle", required=True)
    p.add_argument("--accept-rules", action="store_true")
    p.add_argument("--publish-source", action="store_true", help="publish your source after the seeds are revealed (needed for anyone else to verify your certificate)")
    p.add_argument("--token", help="the handle's token, if you submitted under it before (saved automatically on this machine)")
    p.add_argument("--no-check", action="store_true", help="skip the local pre-flight lint")
    p.add_argument("--allow-insecure-http", action="store_true")
    p = sub.add_parser("status", parents=[common])
    p.add_argument("--round", required=True)
    p.add_argument("--id")
    p.add_argument("--handle")
    p.add_argument("--wait", type=int, default=0, metavar="SECONDS", help="poll until the round is evaluated, up to this long")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("certificate", parents=[common])
    p.add_argument("--round", required=True)
    p.add_argument("--id", required=True)
    p.add_argument("--out")
    p.add_argument("--token")
    p.add_argument("--full", action="store_true", help="YOUR full certificate, with your solver's source (needs your handle's token; the default is the public certificate)")
    p.add_argument("--allow-insecure-http", action="store_true", help="send the token over plain http to a remote host (never do this on a real network)")
    p = sub.add_parser("verify", parents=[common])
    p.add_argument("file", nargs="?", help="a certificate file (offline); or give --round and --id to download it")
    p.add_argument("--round")
    p.add_argument("--id")
    p.add_argument("--token")
    p.add_argument("--rerun", type=certificate.rerun_count, default=0, metavar="K|all", help="re-measure K instances here, or `all` of them (needs --execute)")
    p.add_argument("--execute", action="store_true", help="run the certificate's code on this machine, unsandboxed: a throwaway VM only")
    p.add_argument("--tolerance", type=float, default=certificate.RERUN_TOLERANCE)
    p.add_argument("--sample-seed", type=int, default=None, help="which instances --rerun re-measures (default: a fresh random draw: yours alone)")
    p.add_argument("--full", action="store_true", help="YOUR full certificate, with your solver's source (needs your handle's token)")
    p.add_argument("--source", metavar="FILE", help="a solver its owner has PUBLISHED, to check against a private-solver certificate: it must hash to the value the round's log "
                   "committed to; with --rerun --execute it is then re-measured")
    p.add_argument("--allow-insecure-http", action="store_true", help="send the token over plain http to a remote host (never do this on a real network)")
    p.add_argument("--json", action="store_true")
    sub.add_parser("receipts", parents=[common])
    p = sub.add_parser("practice", help="run YOUR solver on three seeds of your own, locally, and certify it (no server; PROVISIONAL)")
    p.add_argument("solver")
    p.add_argument("--family", required=True)
    p.add_argument("--n", type=int, help="questions per size (default: the family's official number; smaller = faster, recorded in the certificate)")
    p.add_argument("--budget", type=int, help="CPU limit per question in seconds (default: the family's official limit)")
    p.add_argument("--out")
    p.add_argument("--private", action="store_true", help="write a PRIVATE-SOLVER certificate: no source and no failure text, so you can share it without revealing your solver")
    p.add_argument("--count", action="store_true", help="measure by exact bytecode-instruction COUNTING instead of by clock: the costs are then exactly reproducible by anyone "
                   "on the same Python (needs 3.12+, pure-Python solvers, and --dims). See `python3 counted.py --help` for what that proves and what it cannot")
    p.add_argument("--dims", type=int, nargs="+", help="with --count: the sizes to count (small: counting is ~100x slower than running), e.g. 16 18 20")
    p.add_argument("--cap", type=float, help="with --count: the most counted seconds (x 1e6 instructions) one question may use (default 20). A size is only usable if "
                   "the solver's typical cost there reaches 0.5, so the baseline must cost a few counted seconds")
    p.add_argument("--yes", action="store_true", help="start the run (it can take hours: read the plan first)")
    return ap


def main(argv=None):
    a = build_parser().parse_args(argv)
    if a.cmd == "verify" and a.sample_seed is None:
        a.sample_seed = secrets.randbelow(2 ** 31)   # the operator cannot know which instances you will re-measure
    try:
        return {"rounds": cmd_rounds, "round": cmd_round, "submit": cmd_submit, "status": cmd_status, "certificate": cmd_certificate,
                "verify": cmd_verify, "receipts": cmd_receipts, "practice": cmd_practice}[a.cmd](a)
    except SvpError as e:
        print(f"svp: {e}", file=sys.stderr)
        return 2
    except (KeyError, TypeError, ValueError, AttributeError, IndexError) as e:
        # a server (or a file) that sends data in a shape we did not expect is a failed request, never a traceback
        print(f"svp: unexpected data ({type(e).__name__}: {clean(e, 100)}): the server or the file is not what this client expects", file=sys.stderr)
        return 2
    except OSError as e:   # a file or directory we cannot read or write: one line (network errors are turned into SvpError in request())
        print(f"svp: file error: {clean(e.strerror or e, 120)}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("svp: interrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
