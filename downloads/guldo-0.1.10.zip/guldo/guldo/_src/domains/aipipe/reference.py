"""Reference for aipipe: one device does all 8 layers on the whole batch (float64)."""
import math

import numpy as np


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(0x9E3779B97F4A7C15) + u(seed)
        z = (z ^ (z >> u(30))) * u(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> u(27))) * u(0x94D049BB133111EB)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def solve(seed, d, B, P):
    h = _uniform(seed, 0, B * d).reshape(B, d)
    for l in range(8):
        h = np.maximum(h @ (_uniform(seed, B * d + l * d * d, d * d).reshape(d, d) * math.sqrt(6.0 / d)), 0.0)
    return [int(v) for v in np.rint(h.ravel() * 2 ** 30)]
