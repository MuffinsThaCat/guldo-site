"""aispec with bytes counted (tflops_mem.py), SPEEDUP: speculative decoding. Draft K tokens with the rank-8 factors, verify all K positions with the full matrices in ONE batched pass, keep the agreeing prefix plus the full model's own next token."""
import math

import tensorops as tp

V, D, H, R = 64, 128, 1024, 8
W_SCALE, POS_SCALE, DELTA = 4.0, 3.0, 0.15
K = 4


def rms(x):
    return x / tp.sqrt(tp.mean(x * x, -1, True) + 1e-6)


def build(seed, T):
    o = V * D
    E = tp.stream(seed, 0, o, (V, D)) * math.sqrt(3.0)
    pos = tp.stream(seed, o, T * D, (T, D)) * (POS_SCALE * math.sqrt(3.0))
    o += T * D
    A1 = tp.stream(seed, o, D * R, (D, R))
    o += D * R
    B1 = tp.stream(seed, o, R * H, (R, H))
    o += R * H
    A2 = tp.stream(seed, o, H * R, (H, R))
    o += H * R
    B2 = tp.stream(seed, o, R * D, (R, D))
    o += R * D
    N1 = tp.stream(seed, o, D * H, (D, H)) * (W_SCALE / math.sqrt(D))
    o += D * H
    N2 = tp.stream(seed, o, H * D, (H, D)) * (W_SCALE / math.sqrt(H))
    o += H * D
    first = min(int((tp.stream(seed, o, 1).tolist()[0] + 1.0) * 0.5 * V), V - 1)
    c1 = W_SCALE / math.sqrt(D) * 3.0 / math.sqrt(R)
    c2 = W_SCALE / math.sqrt(H) * 3.0 / math.sqrt(R)
    return E, pos, A1 * c1, B1, A2 * c2, B2, N1, N2, first


def solve(seed, T):
    E, pos, A1, B1, A2, B2, N1, N2, last = build(seed, T)
    W1 = A1 @ B1 + N1 * DELTA
    W2 = A2 @ B2 + N2 * DELTA
    N1 = 0
    N2 = 0
    ET = tp.transpose(E, (1, 0))
    out = []
    while len(out) < T:
        t0 = len(out)
        k = min(K, T - t0)
        drafted = []
        prev = last
        for j in range(k):
            x = tp.take(E, prev) + pos[t0 + j]
            y = x + ((tp.relu((rms(x) @ A1) @ B1)) @ A2) @ B2
            prev = tp.argmax(rms(y) @ ET)
            drafted.append(prev)
        ins = [last] + drafted[:k - 1]
        X = tp.take(E, ins) + pos[t0:t0 + k]
        Y = X + tp.relu(rms(X) @ W1) @ W2
        L = tp.reshape(rms(Y) @ ET, (k * V,)).tolist()
        for j in range(k):
            row = L[j * V:(j + 1) * V]
            best = 0
            for c in range(1, V):
                if row[c] > row[best]:
                    best = c
            out.append(best)
            if best != drafted[j]:
                break
        last = out[-1]
    return out
