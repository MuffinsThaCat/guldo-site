"""aidist in the cluster-counted API, TECHNIQUE: TENSOR parallelism. Each device holds h/P of the hidden units (a slice of W1T's rows and of W2's rows, regenerated from its own range of the stream) and the whole batch. The partial outputs are summed by one all-reduce of the B x c output; the gradient shards need no reduction at all (each device owns its rows), and one all-gather assembles them for the answer. Little of the arithmetic is duplicated (the batch and targets are), and the communication is the output, not the parameters."""
import math

import tensorops as tp

C = 8


def ints(g):
    """g: a 1-D tensor on device 0 -> the answer's integers (units of 2^-40)."""
    return list(map(int, (g * 1099511627776.0).tolist()))


def local_grads(x, W1T, W2, Y, B):
    """The gradient pieces for the batch rows in x (the loss is averaged over the WHOLE batch B, so each piece is already scaled by 1/(B*C))."""
    a = x @ tp.transpose(W1T, (1, 0))
    h1 = tp.relu(a)
    dy = (h1 @ W2 - Y) * (1.0 / (B * C))
    dh = (dy @ tp.transpose(W2, (1, 0))) * (h1 / (tp.sqrt(a * a) + 1e-300))
    return tp.transpose(dh, (1, 0)) @ x, tp.transpose(h1, (1, 0)) @ dy


def flat(a, b):
    return tp.concat([tp.reshape(a, (a.shape[0] * a.shape[1],)), tp.reshape(b, (b.shape[0] * b.shape[1],))], 0)


def solve(seed, d, B, P):
    h = 4 * d
    hs = h // P
    xs, ws, w2s, ys, h1s, ps = [], [], [], [], [], []
    for r in range(P):
        tp.use(r)
        x = tp.reshape(tp.stream(seed, 0, B * d), (B, d))
        W1r = tp.reshape(tp.stream(seed, B * d + r * hs * d, hs * d), (hs, d)) * math.sqrt(3.0 / d)
        W2r = tp.reshape(tp.stream(seed, B * d + h * d + r * hs * C, hs * C), (hs, C)) * math.sqrt(3.0 / h)
        Y = tp.reshape(tp.stream(seed, B * d + h * d + h * C, B * C), (B, C))
        a = x @ tp.transpose(W1r, (1, 0))
        h1 = tp.relu(a)
        xs.append(x)
        w2s.append(W2r)
        ys.append(Y)
        h1s.append((h1, a))
        ps.append(h1 @ W2r)
    out = tp.all_reduce(ps)
    pieces = []
    for r in range(P):
        h1, a = h1s[r]
        dy = (out[r] - ys[r]) * (1.0 / (B * C))
        dh = (dy @ tp.transpose(w2s[r], (1, 0))) * (h1 / (tp.sqrt(a * a) + 1e-300))
        pieces.append(flat(tp.transpose(dh, (1, 0)) @ xs[r], tp.transpose(h1, (1, 0)) @ dy))
    G = tp.reshape(tp.all_gather(pieces)[0], (P, hs * d + hs * C))
    return ints(flat(tp.reshape(G[:, 0:hs * d], (h, d)), tp.reshape(G[:, hs * d:hs * d + hs * C], (h, C))))
