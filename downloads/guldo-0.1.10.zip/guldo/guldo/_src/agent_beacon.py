"""A public randomness beacon (drand) as an independent CLOCK and an independent contributor to a round's seed.

drand ("quicknet": a threshold network run by a League of Entropy of independent organisations) publishes a signed random value every 3 seconds. Round R's value does not exist before round R's time:
no party, and no coalition below the threshold, can compute it earlier. A joint seed that includes the value of a FUTURE round R therefore could not be known, by anyone, when the parties committed
to their shares: it fixes, with no clock any of the parties controls, that the instances did not exist before time(R). Everything else in the evaluation pipeline (agent_joint, agent_registry, the
transparency log) can then be ordered against it.

  verify(chain, round, signature_hex)   -> randomness hex; raises BeaconError unless the BLS signature is valid under the PINNED public key (agent_bls, pure Python, ~0.2 s)
  fetch(chain, round)                   -> a beacon record, fetched from public relays and VERIFIED here (a relay is not trusted: it cannot forge the signature)
  round_at(chain, t) / round_time(chain, r)
  chain_hash(params)                    drand's chain id, recomputed from the pinned parameters (period, genesis time, public key, group hash, beacon id)

TRUST. You trust the pinned public key (obtained here from drand's published info and cross-checked by recomputing the chain hash), that a threshold of the League did not collude, and your own clock when you
say what time it is now. You do NOT trust any relay, nor this project: the signature is checked locally. What a beacon does not do: it says nothing about who knew the OTHER inputs to the seed, only that
the seed could not have been fixed before time(R). Only the unchained G1 scheme (quicknet) is supported; any other chain is refused, not guessed at.
"""
import hashlib
import json
import urllib.error
import urllib.request

import agent_bls

QUICKNET = {"beacon_id": "quicknet", "scheme": "bls-unchained-g1-rfc9380", "period": 3, "genesis_time": 1692803367,
            "public_key": "83cf0f2896adee7eb8b5f01fcad3912212c437e0073e911fb90022d3e760183c8c4b450b6a0a6c3ac6a5776a2d1064510d1fec758c921cc22b0e17e63aaf4bcb5ed66304de9cf809bd274ca73bab4af5a6e9c76a4bc09e76eae8991ef5ece45a",
            "group_hash": "f477d5c89f21a17c863a7f937c6a6d15859414d2be09cd448d4279af331c5d3e", "hash": "52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971"}
RELAYS = ("https://api.drand.sh", "https://api2.drand.sh", "https://api3.drand.sh", "https://drand.cloudflare.com")
MAX_RESPONSE = 4096
MAX_ROUND = 1 << 62


class BeaconError(Exception):
    pass


def chain_hash(p):
    """drand's chain id: sha256(period u32 || genesis u64 || public key || group hash || beacon id) (the beacon id is left out for the 'default' one)."""
    h = hashlib.sha256(p["period"].to_bytes(4, "big") + p["genesis_time"].to_bytes(8, "big") + bytes.fromhex(p["public_key"]) + bytes.fromhex(p["group_hash"]))
    if p["beacon_id"] != "default":
        h.update(p["beacon_id"].encode())
    return h.hexdigest()


assert chain_hash(QUICKNET) == QUICKNET["hash"], "the pinned quicknet parameters do not hash to its published chain id"
KNOWN = {QUICKNET["hash"]: QUICKNET}


def chain_for(chain_id):
    """The pinned parameters of a chain by id, or BeaconError (an unknown chain is refused: anyone can invent a beacon with their own key)."""
    p = KNOWN.get(chain_id) if isinstance(chain_id, str) else None
    if p is None:
        raise BeaconError("unknown beacon chain %r: only pinned chains are accepted (%s)" % (str(chain_id)[:20], ", ".join(KNOWN)[:70]))
    return p


def round_time(chain, r):
    """Unix time at which round r is released."""
    if not isinstance(r, int) or isinstance(r, bool) or not 1 <= r <= MAX_ROUND:
        raise BeaconError("a beacon round is a positive integer")
    return chain["genesis_time"] + (r - 1) * chain["period"]


def round_at(chain, t):
    """The latest round released at unix time t (0 before the chain's genesis)."""
    return 0 if t < chain["genesis_time"] else int((t - chain["genesis_time"]) // chain["period"]) + 1


def message_for(r):
    return hashlib.sha256(r.to_bytes(8, "big")).digest()


def verify(chain, r, signature_hex, randomness_hex=None):
    """The beacon's randomness for round r (hex), after checking the BLS signature under the chain's pinned public key. Raises BeaconError otherwise."""
    round_time(chain, r)
    if chain["scheme"] != "bls-unchained-g1-rfc9380":
        raise BeaconError("only the unchained G1 scheme is supported")
    try:
        sig = bytes.fromhex(signature_hex)
    except (ValueError, TypeError):
        raise BeaconError("the signature is not hex")
    if len(sig) != 48:
        raise BeaconError("a quicknet signature is 48 bytes")
    if not agent_bls.verify_g1_signature(bytes.fromhex(chain["public_key"]), message_for(r), sig, agent_bls.DST_SIG_G1):
        raise BeaconError("the beacon signature for round %d is NOT valid under the pinned key" % r)
    rand = hashlib.sha256(sig).hexdigest()
    if randomness_hex is not None and randomness_hex != rand:
        raise BeaconError("the stated randomness is not the hash of the signature")
    return rand


def record(chain, r, signature_hex):
    """A verified beacon record: {chain, round, randomness, signature}."""
    return {"chain": chain["hash"], "round": r, "randomness": verify(chain, r, signature_hex), "signature": signature_hex}


def check_record(rec):
    """Verify a stored beacon record (the chain must be a pinned one). Returns the record's randomness."""
    if not isinstance(rec, dict) or set(rec) != {"chain", "round", "randomness", "signature"}:
        raise BeaconError("not a beacon record")
    return verify(chain_for(rec["chain"]), rec["round"], rec["signature"], rec["randomness"])


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def default_http(url, timeout=15):
    op = urllib.request.build_opener(_NoRedirect)
    with op.open(urllib.request.Request(url, headers={"User-Agent": "guldo-beacon/1"}), timeout=timeout) as r:
        return r.status, r.read(MAX_RESPONSE + 1)


def fetch(chain, r, http=default_http, relays=RELAYS):
    """Fetch round r from the first relay that answers, VERIFY it locally, return the record. A relay that lies is simply refused and the next is tried."""
    round_time(chain, r)
    errors = []
    for relay in relays:
        try:
            status, body = http("%s/%s/public/%d" % (relay, chain["hash"], r))
            if status != 200 or len(body) > MAX_RESPONSE:
                raise BeaconError("HTTP %s" % status)
            d = json.loads(body.decode("utf-8"))
            if not isinstance(d, dict) or d.get("round") != r or not isinstance(d.get("signature"), str):
                raise BeaconError("a malformed or wrong-round reply")
            return record(chain, r, d["signature"])
        except (BeaconError, OSError, ValueError, urllib.error.URLError) as e:
            errors.append("%s: %s" % (relay, str(e)[:60]))
    raise BeaconError("no relay gave a verifiable beacon for round %d (%s)" % (r, "; ".join(errors)))
