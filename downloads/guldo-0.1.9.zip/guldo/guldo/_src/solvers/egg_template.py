"""Template for an executable egg (see EGG.md). Deliberately NOT a working solver: fill in `solve` with a real
implementation of the optimizations being claimed, keeping the contract below. Running the harness on this file as-is
yields 'crash' on every instance, which is the correct outcome for an unimplemented submission.

Contract: solve(basis, bound2) -> nonzero lattice vector (list[int]) with squared norm <= bound2, or None.
"""
from fpylll import BKZ, LLL, IntegerMatrix  # noqa: F401  (stock tools available inside the sandbox image)


def solve(basis, bound2):
    raise NotImplementedError("implement the egg's optimizations here; see EGG.md")
