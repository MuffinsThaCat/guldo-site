"""Example solver for step counting (`make practice-count SOLVER=solvers/factor_trial_fast_py.py`): trial division by 6k +/- 1 only, in plain Python.

It tests 2 candidates per 6 numbers instead of the baseline's 3 per 6 (every odd), so it should execute about half as many instructions: a modest, honest
constant-factor speedup and a realistic first thing to certify. (An expectation from reading the loops, not a measurement: the certificate is what measures it.) Pure Python on purpose: step counting cannot see work done inside C functions, so a counted claim means something only for loops like this one.
Deterministic: no clock, no randomness, no dependence on memory addresses.
"""


def solve(n):
    if n % 2 == 0:
        return 2
    if n % 3 == 0:
        return 3
    d = 5
    while d * d <= n:
        if n % d == 0:
            return d
        if n % (d + 2) == 0:
            return d + 2
        d += 6
    return n  # n is prime: no nontrivial divisor (the verifier rejects this, which is correct)
