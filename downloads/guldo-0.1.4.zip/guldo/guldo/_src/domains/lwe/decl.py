"""Declaration of a recovery domain: plain LWE secret recovery with m = 2n samples.

A solver receives (q, A, b, W): A is an m x n matrix over Z_q (q = 3329), b = A s + e mod q, s ternary (coefficients in {-1, 0, 1}),
e in [-W, W]^m. It returns s as a list of n ints. Any ternary s whose residual b - A s (centred mod q) lies in [-W, W]^m is accepted; at
these parameters the planted s is the only one with overwhelming probability. size = n; the reference is a meet-in-the-middle search over the secret (about 3^(n/2) work).
Unlike rlwe, the m = 2n samples are unstructured and plentiful, so sample-hungry attacks (BKW, Arora-Ge, the dual attack combined with
guessing, hybrid attacks on the small secret) are in scope alongside primal lattice reduction.
"""
import hashlib
import hmac
import random

NAME = "lwe"
VERSION = "lwe-v3"           # bump whenever derive() changes
SIZE_RANGE = (22, 27)
SIZE_STEP = 1
REFERENCE_SOLVER = "reference.py"
Q = 3329
W = 2
DOC = ("solve(q, A, b, W): A is a list of m = 2n rows of n ints mod q, b a list of m ints, b = A s + e (mod q). Return the secret s as a list of "
       "n ints in {-1, 0, 1} such that every entry of b - A s (reduced mod q, centred) has absolute value <= W. Return None for no answer.")
REFERENCE_NOTE = ("The reference is a meet-in-the-middle search over ternary secrets (about 3^(n/2) work: a two-row bucket key, 25 noise offsets, a third-row filter). Primal lattice reduction, the dual attack "
                  "with guessing, hybrid attacks, BKW-style and Arora-Ge algebraic attacks are known to beat it as n grows; no claim is made about which "
                  "is fastest. Scope: toy dimensions (n <= 27, ternary secret, noise <= 2), where lattice reduction wins by a very large margin; NOT "
                  "evidence about attacks on cryptographic parameters, and a certificate here must not be read as one.")


def _centre(x, q):
    x %= q
    return x - q if x > q // 2 else x


def derive(master: bytes, size: int, idx: int) -> dict:
    rng = random.Random(hmac.new(master, f"lwe-v3:{size}:{idx}".encode(), hashlib.sha256).digest())
    n, m = size, 2 * size
    A = [[rng.randrange(Q) for _ in range(n)] for _ in range(m)]
    while True:
        s = [rng.choice((-1, 0, 1)) for _ in range(n)]
        if sum(map(bool, s)) >= n // 2:  # not the zero or a near-zero secret
            break
    e = [rng.randint(-W, W) for _ in range(m)]
    b = [(sum(x * y for x, y in zip(row, s)) + ei) % Q for row, ei in zip(A, e)]
    return {"args": [Q, A, b, W], "planted": s}


def verify(inst: dict, ans) -> bool:
    q, A, b, w = inst["args"]
    n = len(A[0])
    if not isinstance(ans, list) or len(ans) != n:
        return False
    for c in ans:
        if isinstance(c, bool) or not isinstance(c, int) or c not in (-1, 0, 1):
            return False
    return all(abs(_centre(bi - sum(x * y for x, y in zip(row, ans)), q)) <= w for row, bi in zip(A, b))
