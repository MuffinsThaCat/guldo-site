"""Declaration of a counted-operations puzzle: decode with a transformer whose feed-forward weights are HIDDEN LOW-RANK PRODUCTS, using as few operations as you can.

Same model family as `aidecode` (2 layers, d=128, 4 heads, vocab 64, tied output embedding, greedy decoding, teacher-forced verification) with one change: each layer's two feed-forward
matrices are generated as products of thin factors,  W1 = A1 @ B1  (128 x 8 times 8 x 512)  and  W2 = A2 @ B2  (512 x 8 times 8 x 128),  and the stream hands out the FACTORS.
A solver that first builds the dense W1 and W2 pays for 128*8*512*2 operations per matrix and then 128*512*2 operations per token per matrix; one that keeps the factors pays only
(128*8 + 8*512)*2 per token. The tokens are identical either way (the products are associative), so the saving is exact, not an approximation: the puzzle is to notice it, and then
to find the next one. The verifier is aidecode's: every submitted token must be within TOL_SIGMA * std(logits) of the best logit given the submitted prefix.

Weight scales (W_SCALE, POS_SCALE) are chosen, as in aidecode, so the greedy output is not degenerate (checked: test_aifactor).
"""
import hashlib
import hmac
import math

import numpy as np

NAME = "aifactor"
VERSION = "aifactor-v1"
SIZE_RANGE = (256, 4096)
SIZE_STEP = 32
REFERENCE_SOLVER = "reference.py"
V, D, H, DH, FF, L, PROMPT, R = 64, 128, 4, 32, 512, 2, 8, 8
W_SCALE, POS_SCALE = 4.0, 3.0
TOL_SIGMA = 1e-3
DOC = ("solve(seed, prompt_len, T): rebuild the model and prompt from `seed` (SplitMix64 stream, layout in domains/aifactor/reference.py), generate T tokens greedily and return the list of "
       "T token ids. Per layer the stream gives Wq, Wk, Wv, Wo (128x128), then the FACTORS A1 (128x8), B1 (8x512), A2 (512x8), B2 (8x128); the feed-forward matrices are W1 = A1 B1 and "
       "W2 = A2 B2. Every returned token must be, at its position, within 1e-3 standard deviations of the best logit given the prompt and your own earlier tokens. Return None for no answer.")
REFERENCE_NOTE = ("A KV cache with the dense feed-forward matrices materialised once (the factors multiplied out). Known to be beaten by keeping the factors and applying them "
                  "one after the other, which turns a 128x512 matrix-vector product into 128x8 then 8x512.")

_GOLD = 0x9E3779B97F4A7C15
_C1 = 0xBF58476D1CE4E5B9
_C2 = 0x94D049BB133111EB


def _uniform(seed, start, n):
    u = np.uint64
    with np.errstate(over="ignore"):
        z = (np.arange(start, start + n, dtype=u) + u(1)) * u(_GOLD) + u(seed)
        z = (z ^ (z >> u(30))) * u(_C1)
        z = (z ^ (z >> u(27))) * u(_C2)
        z = z ^ (z >> u(31))
    return (z >> u(11)).astype(np.float64) * 2.0 ** -52 - 1.0


def _params(seed, T):
    o = [0]

    def take(shape, scale):
        n = int(np.prod(shape))
        a = (_uniform(seed, o[0], n) * scale).reshape(shape)
        o[0] += n
        return a
    sd = W_SCALE * math.sqrt(3.0 / D)
    P = {"tok": take((V, D), math.sqrt(3.0)), "layers": []}
    for _ in range(L):
        l = {"Wq": take((D, D), sd), "Wk": take((D, D), sd), "Wv": take((D, D), sd), "Wo": take((D, D), sd)}
        l["A1"], l["B1"] = take((D, R), sd), take((R, FF), math.sqrt(3.0 / R))
        l["A2"], l["B2"] = take((FF, R), W_SCALE * math.sqrt(3.0 / FF)), take((R, D), math.sqrt(3.0 / R))
        l["W1"], l["W2"] = l["A1"] @ l["B1"], l["A2"] @ l["B2"]          # the dense matrices the factors stand for (judge side)
        P["layers"].append(l)
    P["pos"] = take((PROMPT + T, D), POS_SCALE * math.sqrt(3.0))
    P["prompt"] = np.minimum(((_uniform(seed, o[0], PROMPT) + 1.0) * 0.5 * V).astype(np.int64), V - 1)
    return P


def _rms(x):
    return x / np.sqrt((x * x).mean(axis=-1, keepdims=True) + 1e-6)


def _forward(P, toks):
    n = len(toks)
    x = P["tok"][toks] + P["pos"][:n]
    mask = np.triu(np.full((n, n), -1e30), 1)
    for l in P["layers"]:
        h = _rms(x)
        q, k, v = [(h @ l[w]).reshape(n, H, DH).transpose(1, 0, 2) for w in ("Wq", "Wk", "Wv")]
        s = q @ k.transpose(0, 2, 1) / math.sqrt(DH) + mask
        s -= s.max(-1, keepdims=True)
        a = np.exp(s)
        a /= a.sum(-1, keepdims=True)
        x = x + (a @ v).transpose(1, 0, 2).reshape(n, D) @ l["Wo"]
        x = x + np.maximum(_rms(x) @ l["W1"], 0.0) @ l["W2"]
    return _rms(x) @ P["tok"].T


def _greedy_cached(P, T):
    n = PROMPT + T
    K = [np.zeros((n, D)) for _ in range(L)]
    Vv = [np.zeros((n, D)) for _ in range(L)]
    seq = [int(t) for t in P["prompt"]]
    out = []
    for p in range(n - 1):
        x = P["tok"][seq[p]] + P["pos"][p]
        for li, l in enumerate(P["layers"]):
            h = _rms(x)
            q = (h @ l["Wq"]).reshape(H, DH)
            K[li][p], Vv[li][p] = h @ l["Wk"], h @ l["Wv"]
            kc = K[li][:p + 1].reshape(p + 1, H, DH)
            vc = Vv[li][:p + 1].reshape(p + 1, H, DH)
            s = np.einsum("hd,thd->ht", q, kc) / math.sqrt(DH)
            s -= s.max(-1, keepdims=True)
            a = np.exp(s)
            a /= a.sum(-1, keepdims=True)
            x = x + np.einsum("ht,thd->hd", a, vc).reshape(D) @ l["Wo"]
            x = x + np.maximum(_rms(x) @ l["W1"], 0.0) @ l["W2"]
        if p >= PROMPT - 1:
            t = int(np.argmax(_rms(x) @ P["tok"].T))
            out.append(t)
            seq.append(t)
    return out


def derive(master: bytes, size: int, idx: int) -> dict:
    seed = int.from_bytes(hmac.new(master, f"aifactor-v1:{size}:{idx}".encode(), hashlib.sha256).digest()[:8], "big") >> 1
    return {"args": [seed, PROMPT, size], "planted": _greedy_cached(_params(seed, size), size)}


def verify(inst: dict, ans) -> bool:
    seed, plen, T = inst["args"]
    if not isinstance(ans, list) or len(ans) != T:
        return False
    if any(isinstance(c, bool) or not isinstance(c, int) or not 0 <= c < V for c in ans):
        return False
    P = _params(seed, T)
    seq = np.concatenate([P["prompt"], np.asarray(ans, dtype=np.int64)])
    L_ = _forward(P, seq[:-1])[PROMPT - 1:]
    tol = TOL_SIGMA * float(L_.std())
    return bool(np.all(L_[np.arange(T), np.asarray(ans)] >= L_.max(axis=1) - tol))
