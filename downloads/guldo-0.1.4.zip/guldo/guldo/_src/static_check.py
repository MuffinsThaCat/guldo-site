"""Static sanity check that EXECUTES NONE of the project's code: it reads source files as text and parses them.

  python3 static_check.py                 the AI / counted-ops / GPU files added in November 2026
  python3 static_check.py FILE [FILE ...] any files

Reports: syntax errors; names used but defined nowhere in scope; `module.attr` references to a project module that does not define `attr` at top level; calls to a project
function (`module.f(...)` or a local `f(...)`) whose arguments cannot match its signature (too many positional, an unknown keyword, a missing required argument).

What it does NOT find: anything about values (wrong dict keys, wrong types, wrong logic), method calls on objects, or whether a test would pass. It exists for the cases where
nothing may be run (it caught nothing in the files above, and it does catch deliberately planted errors of each kind); it is a complement to `make test`, never a substitute.
"""
import ast
import builtins
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
BUILTINS = set(dir(builtins)) | {"__file__", "__name__", "__doc__"}
DEFAULT_FILES = ["tensorops.py", "tflops_runner.py", "tflops.py", "test_tflops.py", "gpu_meter.py", "gpu_runner.py", "test_gpu_meter.py", "test_aidecode.py", "test_aiinfer.py",
                 "build_site.py", "test_site_ai.py", "test_site_schedule.py", "opgolf.py", "test_opgolf.py", "test_aifactor.py", "aidecode_counted_experiment.py",
                 "domains/aidecode/decl.py", "domains/aidecode/reference.py", "domains/aiinfer/decl.py", "domains/aiinfer/reference.py",
                 "solvers/aidecode_kv.py", "solvers/aidecode_kv_f32.py", "solvers/aidecode_lossy.py", "solvers/aidecode_repeat.py", "solvers/aidecode_flops_ref.py",
                 "solvers/aidecode_flops_kv.py", "solvers/aidecode_flops_lossy.py", "solvers/aiinfer_batched.py", "solvers/aiinfer_f32.py", "solvers/aiinfer_lossy.py",
                 "solvers/aiinfer_gpu_ref.py", "solvers/aiinfer_gpu_batched.py", "solvers/gpu_noop.py"]


def load(path):
    with open(path, "rb") as f:
        return ast.parse(f.read(), filename=path)


def bound_names(node):
    """Names bound directly by the statements of `node`'s body (nested function/class bodies are separate scopes; their own names are bound here)."""
    out = set()

    def targets(t):
        if isinstance(t, ast.Name):
            out.add(t.id)
        elif isinstance(t, (ast.Tuple, ast.List)):
            for e in t.elts:
                targets(e)
        elif isinstance(t, ast.Starred):
            targets(t.value)

    def visit(n):
        if isinstance(n, ast.Import):
            for a in n.names:
                out.add((a.asname or a.name).split(".")[0])
        elif isinstance(n, ast.ImportFrom):
            for a in n.names:
                out.add(a.asname or a.name)
        elif isinstance(n, ast.Assign):
            for t in n.targets:
                targets(t)
        elif isinstance(n, (ast.AugAssign, ast.AnnAssign)):
            targets(n.target)
        elif isinstance(n, (ast.For, ast.AsyncFor)):
            targets(n.target)
        elif isinstance(n, (ast.With, ast.AsyncWith)):
            for it in n.items:
                if it.optional_vars is not None:
                    targets(it.optional_vars)
        elif isinstance(n, ast.ExceptHandler) and n.name:
            out.add(n.name)
        elif isinstance(n, ast.NamedExpr):
            targets(n.target)
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            out.update(n.names)
        for c in ast.iter_child_nodes(n):
            if isinstance(c, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                out.add(c.name)
            elif not isinstance(c, (ast.Lambda, ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
                visit(c)
    for stmt in getattr(node, "body", []):
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            out.add(stmt.name)
        else:
            visit(stmt)
    return out


def args_of(fn):
    a = fn.args
    names = [x.arg for x in a.posonlyargs + a.args + a.kwonlyargs]
    if a.vararg:
        names.append(a.vararg.arg)
    if a.kwarg:
        names.append(a.kwarg.arg)
    return set(names)


def signatures(tree):
    out = {}
    for n in tree.body:
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            a = n.args
            pos = a.posonlyargs + a.args
            names = [x.arg for x in pos] + [x.arg for x in a.kwonlyargs]
            required = [x.arg for x in pos[:len(pos) - len(a.defaults)]] + [x.arg for x, d in zip(a.kwonlyargs, a.kw_defaults) if d is None]
            out[n.name] = (len(pos), names, required, a.vararg is not None, a.kwarg is not None)
    return out


class Checker:
    def __init__(self, path, tree, modtops, modsigs):
        self.path, self.tree, self.modtops, self.modsigs = path, tree, modtops, modsigs
        self.problems = []
        self.module_names = bound_names(tree)
        self.aliases = {}
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                for a in n.names:
                    if a.name in modtops:
                        self.aliases[a.asname or a.name] = a.name
        self.local_sigs = modsigs.get(os.path.splitext(os.path.basename(path))[0], {})

    def report(self, node, msg):
        self.problems.append(f"{os.path.relpath(self.path, ROOT)}:{getattr(node, 'lineno', '?')}: {msg}")

    def run(self):
        for child in ast.iter_child_nodes(self.tree):
            self.walk(child, [self.module_names])
        return self.problems

    def walk(self, n, chain):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for d in n.decorator_list + n.args.defaults + [d for d in n.args.kw_defaults if d]:
                self.walk(d, chain)
            inner = args_of(n) | bound_names(n)
            for c in n.body:
                self.walk(c, chain + [inner])
            return
        if isinstance(n, ast.Lambda):
            self.walk(n.body, chain + [args_of(n)])
            return
        if isinstance(n, ast.ClassDef):
            for d in n.decorator_list + n.bases:
                self.walk(d, chain)
            inner = bound_names(n)
            for c in n.body:
                self.walk(c, chain + [inner])
            return
        if isinstance(n, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            comp = {t.id for g in n.generators for t in ast.walk(g.target) if isinstance(t, ast.Name)}
            chain2 = chain + [comp]
            for g in n.generators:
                self.walk(g.iter, chain2)
                for i in g.ifs:
                    self.walk(i, chain2)
            for part in ([n.key, n.value] if isinstance(n, ast.DictComp) else [n.elt]):
                self.walk(part, chain2)
            return
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in BUILTINS and not any(n.id in s for s in chain):
            self.report(n, f"undefined name {n.id!r}")
        if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in self.aliases and not any(n.value.id in s for s in chain[1:]):
            mod = self.aliases[n.value.id]
            if n.attr not in self.modtops[mod]:
                self.report(n, f"{mod} has no top-level name {n.attr!r}")
        if isinstance(n, ast.Call):
            self.check_call(n, chain)
        for c in ast.iter_child_nodes(n):
            self.walk(c, chain)

    def check_call(self, call, chain):
        sig, label, f = None, None, call.func
        if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id in self.aliases and not any(f.value.id in s for s in chain[1:]):
            mod = self.aliases[f.value.id]
            sig, label = self.modsigs.get(mod, {}).get(f.attr), f"{mod}.{f.attr}"
        elif isinstance(f, ast.Name) and f.id in self.local_sigs and not any(f.id in s for s in chain[1:]):
            sig, label = self.local_sigs[f.id], f.id
        if sig is None or any(isinstance(a, ast.Starred) for a in call.args) or any(k.arg is None for k in call.keywords):
            return
        _, names, required, has_var, has_kw = sig
        if len(call.args) > len(names) and not has_var:
            self.report(call, f"{label}() takes at most {len(names)} positional arguments, {len(call.args)} given")
        kw = {k.arg for k in call.keywords}
        for k in kw:
            if k not in names and not has_kw:
                self.report(call, f"{label}() has no parameter {k!r}")
        supplied = set(names[:len(call.args)]) | kw
        missing = [r for r in required if r not in supplied]
        if missing:
            self.report(call, f"{label}() missing required argument(s) {missing}")


def main(argv):
    files = [os.path.abspath(a) for a in argv] or [os.path.join(ROOT, f) for f in DEFAULT_FILES]
    trees, modtops, modsigs, syntax = {}, {}, {}, 0
    for name in os.listdir(ROOT):                    # every top-level project module, so cross-module references can be resolved
        if name.endswith(".py"):
            files_extra = os.path.join(ROOT, name)
            try:
                tree = load(files_extra)
            except SyntaxError:
                continue
            mod = name[:-3]
            modtops[mod], modsigs[mod], trees[files_extra] = bound_names(tree), signatures(tree), tree
    total = 0
    for p in files:
        try:
            tree = trees.get(p) or load(p)
        except (SyntaxError, OSError) as e:
            print(f"{os.path.relpath(p, ROOT)}: {'SYNTAX ERROR line ' + str(e.lineno) + ': ' + e.msg if isinstance(e, SyntaxError) else e}")
            syntax += 1
            continue
        for line in Checker(p, tree, modtops, modsigs).run():
            print(line)
            total += 1
    print(f"checked {len(files)} file(s): {total} problem(s), {syntax} unreadable or syntax error(s)")
    return 1 if total or syntax else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
